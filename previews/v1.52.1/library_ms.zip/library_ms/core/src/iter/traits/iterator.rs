// ign-tidy-filelength Fail ini hampir secara eksklusif terdiri daripada definisi `Iterator`.
// Kami tidak dapat membaginya menjadi beberapa fail.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Antara muka untuk berurusan dengan iterator.
///
/// Ini adalah iterator utama trait.
/// Untuk lebih lanjut mengenai konsep iterator secara umum, sila lihat [module-level documentation].
/// Khususnya, anda mungkin ingin mengetahui cara [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Jenis elemen yang diulang.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Memajukan iterator dan mengembalikan nilai seterusnya.
    ///
    /// Mengembalikan [`None`] apabila lelaran selesai.
    /// Pelaksanaan iterator individu boleh memilih untuk meneruskan iterasi, dan dengan itu memanggil `next()` sekali lagi mungkin atau mungkin akhirnya tidak kembali [`Some(Item)`] pada suatu ketika.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Panggilan ke next() mengembalikan nilai seterusnya ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... dan kemudian Tiada setelah selesai.
    /// assert_eq!(None, iter.next());
    ///
    /// // Lebih banyak panggilan mungkin atau tidak akan mengembalikan `None`.Di sini, mereka selalu akan.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Mengembalikan batas pada baki panjang iterator.
    ///
    /// Secara khusus, `size_hint()` mengembalikan tuple di mana elemen pertama adalah batas bawah, dan elemen kedua adalah batas atas.
    ///
    /// Separuh kedua tuple yang dikembalikan adalah [`Option`]`<`[`usize`] `>`.
    /// [`None`] di sini bermaksud bahawa sama ada tidak ada batas atas yang diketahui, atau batas atas lebih besar daripada [`usize`].
    ///
    /// # Catatan pelaksanaan
    ///
    /// Tidak dipaksakan bahawa pelaksanaan iterator menghasilkan jumlah elemen yang dinyatakan.Iterator buggy boleh menghasilkan kurang daripada batas bawah atau lebih tinggi daripada elemen atas.
    ///
    /// `size_hint()` terutamanya bertujuan untuk digunakan untuk pengoptimuman seperti menempah ruang untuk unsur-unsur iterator, tetapi tidak boleh dipercayai untuk menghilangkan pemeriksaan had dalam kod yang tidak selamat.
    /// Pelaksanaan `size_hint()` yang salah tidak boleh menyebabkan pelanggaran keselamatan memori.
    ///
    /// Yang mengatakan, pelaksanaan harus memberikan perkiraan yang tepat, kerana jika tidak, itu akan melanggar protokol trait.
    ///
    /// Pelaksanaan lalai mengembalikan `(0,` [None`]`)` yang betul untuk setiap iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Contoh yang lebih kompleks:
    ///
    /// ```
    /// // Nombor genap dari sifar hingga sepuluh.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Kami mungkin berulang dari sifar hingga sepuluh kali.
    /// // Mengetahui bahawa lima betul-betul tidak akan dapat dilakukan tanpa menjalankan filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Mari tambah lima nombor lagi dengan chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // kini kedua-dua had meningkat lima
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Mengembalikan `None` untuk batas atas:
    ///
    /// ```
    /// // iterator tanpa had tidak mempunyai batas atas dan batas bawah maksimum yang mungkin
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Menggunakan iterator, mengira bilangan lelaran dan mengembalikannya.
    ///
    /// Kaedah ini akan memanggil [`next`] berulang kali sehingga [`None`] ditemui, mengembalikan berapa kali ia melihat [`Some`].
    /// Perhatikan bahawa [`next`] harus dipanggil sekurang-kurangnya sekali walaupun iterator tidak mempunyai unsur.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Kelakuan Limpahan
    ///
    /// Kaedah ini tidak melindungi terhadap limpahan, jadi menghitung elemen berulang dengan lebih daripada elemen [`usize::MAX`] sama ada menghasilkan hasil yang salah atau panics.
    ///
    /// Sekiranya penegasan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika iterator mempunyai lebih daripada elemen [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Menggunakan iterator, mengembalikan elemen terakhir.
    ///
    /// Kaedah ini akan menilai iterator sehingga mengembalikan [`None`].
    /// Semasa melakukannya, ia terus mengikuti elemen semasa.
    /// Selepas [`None`] dikembalikan, `last()` kemudian akan mengembalikan elemen terakhir yang dilihatnya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Memajukan iterator dengan elemen `n`.
    ///
    /// Kaedah ini akan melangkau elemen `n` dengan bersemangat dengan memanggil [`next`] hingga `n` kali sehingga [`None`] ditemui.
    ///
    /// `advance_by(n)` akan mengembalikan [`Ok(())`][Ok] jika iterator berjaya maju dengan elemen `n`, atau [`Err(k)`][Err] jika [`None`] ditemui, di mana `k` adalah bilangan elemen yang dilanjutkan oleh iterator sebelum kehabisan elemen (iaitu
    /// panjang iterator).
    /// Perhatikan bahawa `k` selalu kurang dari `n`.
    ///
    /// Memanggil `advance_by(0)` tidak memakan sebarang unsur dan selalu mengembalikan [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // hanya `&4` dilangkau
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Mengembalikan elemen `n` ke atas iterator.
    ///
    /// Seperti kebanyakan operasi pengindeksan, kiraannya bermula dari sifar, jadi `nth(0)` mengembalikan nilai pertama, `nth(1)` yang kedua, dan seterusnya.
    ///
    /// Perhatikan bahawa semua elemen sebelumnya, serta elemen yang dikembalikan, akan habis digunakan dari iterator.
    /// Ini bermaksud bahawa elemen sebelumnya akan dibuang, dan juga bahawa memanggil `nth(0)` beberapa kali pada iterator yang sama akan mengembalikan elemen yang berbeza.
    ///
    ///
    /// `nth()` akan mengembalikan [`None`] jika `n` lebih besar daripada atau sama dengan panjang iterator.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Memanggil `nth()` berkali-kali tidak mengundurkan iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Mengembalikan `None` jika terdapat kurang daripada elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Membuat iterator bermula pada titik yang sama, tetapi melangkah dengan jumlah yang diberikan pada setiap lelaran.
    ///
    /// Catatan 1: Elemen pertama iterator akan selalu dikembalikan, tanpa mengira langkah yang diberikan.
    ///
    /// Catatan 2: Masa di mana elemen yang diabaikan ditarik tidak tetap.
    /// `StepBy` berkelakuan seperti urutan `next(), nth(step-1), nth(step-1),…`, tetapi juga bebas berkelakuan seperti urutan
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cara mana yang digunakan boleh berubah untuk beberapa iterator atas sebab prestasi.
    /// Cara kedua akan memajukan iterator lebih awal dan boleh menggunakan lebih banyak item.
    ///
    /// `advance_n_and_return_first` adalah bersamaan dengan:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Kaedahnya akan panic jika langkah yang diberikan adalah `0`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Mengambil dua iterator dan membuat iterator baru ke atas kedua-dua secara berurutan.
    ///
    /// `chain()` akan mengembalikan iterator baru yang pertama akan mengulang nilai dari iterator pertama dan kemudian lebih dari nilai dari iterator kedua.
    ///
    /// Dengan kata lain, ia menghubungkan dua iterator bersama-sama, dalam rantai.🔗
    ///
    /// [`once`] biasanya digunakan untuk mengadaptasi satu nilai menjadi rantai lelaran jenis lain.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oleh kerana argumen untuk `chain()` menggunakan [`IntoIterator`], kita dapat menyampaikan apa sahaja yang boleh ditukar menjadi [`Iterator`], bukan hanya [`Iterator`] itu sendiri.
    /// Contohnya, potongan (`&[T]`) melaksanakan [`IntoIterator`], dan seterusnya boleh dihantar ke `chain()` secara langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sekiranya anda bekerja dengan Windows API, anda mungkin ingin menukar [`OsStr`] ke `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip ke atas' dua iterator menjadi satu iterator pasangan.
    ///
    /// `zip()` mengembalikan iterator baru yang akan berulang pada dua iterator lain, mengembalikan tuple di mana elemen pertama berasal dari iterator pertama, dan elemen kedua berasal dari iterator kedua.
    ///
    ///
    /// Dengan kata lain, ia mengikat dua iterator bersama-sama, menjadi satu.
    ///
    /// Sekiranya salah satu iterator mengembalikan [`None`], [`next`] dari iterator zip akan mengembalikan [`None`].
    /// Sekiranya iterator pertama mengembalikan [`None`], `zip` akan litar pintas dan `next` tidak akan dipanggil pada iterator kedua.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Oleh kerana argumen untuk `zip()` menggunakan [`IntoIterator`], kita dapat menyampaikan apa sahaja yang boleh ditukar menjadi [`Iterator`], bukan hanya [`Iterator`] itu sendiri.
    /// Contohnya, potongan (`&[T]`) melaksanakan [`IntoIterator`], dan seterusnya boleh dihantar ke `zip()` secara langsung:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` sering digunakan untuk zip iterator tak terhingga ke yang terhingga.
    /// Ini berfungsi kerana iterator terhingga akhirnya akan mengembalikan [`None`], mengakhiri ritsleting.Zipping dengan `(0..)` boleh kelihatan seperti [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Membuat iterator baru yang meletakkan salinan `separator` antara item bersebelahan dari iterator asal.
    ///
    /// Sekiranya `separator` tidak melaksanakan [`Clone`] atau perlu dikira setiap masa, gunakan [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Elemen pertama dari `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pemisah.
    /// assert_eq!(a.next(), Some(&1));   // Elemen seterusnya dari `a`.
    /// assert_eq!(a.next(), Some(&100)); // Pemisah.
    /// assert_eq!(a.next(), Some(&2));   // Elemen terakhir dari `a`.
    /// assert_eq!(a.next(), None);       // Pengulangan selesai.
    /// ```
    ///
    /// `intersperse` sangat berguna untuk menyertai item iterator menggunakan elemen umum:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Membuat iterator baru yang meletakkan item yang dihasilkan oleh `separator` antara item bersebelahan dari iterator asal.
    ///
    /// Penutupan akan dipanggil tepat sekali setiap kali item diletakkan di antara dua item bersebelahan dari iterator yang mendasari;
    /// secara khusus, penutupan tidak dipanggil jika iterator yang mendasari menghasilkan kurang dari dua item dan setelah item terakhir dihasilkan.
    ///
    ///
    /// Sekiranya item iterator menerapkan [`Clone`], mungkin lebih mudah menggunakan [`intersperse`].
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Elemen pertama dari `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pemisah.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Elemen seterusnya dari `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Pemisah.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Elemen terakhir dari dari `v`.
    /// assert_eq!(it.next(), None);               // Pengulangan selesai.
    /// ```
    ///
    /// `intersperse_with` boleh digunakan dalam situasi di mana pemisah perlu dikira:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Penutupan secara mutlak meminjam konteksnya untuk menghasilkan item.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Mengambil penutupan dan membuat iterator yang memanggil penutupan pada setiap elemen.
    ///
    /// `map()` mengubah satu iterator ke yang lain, dengan hujahnya:
    /// sesuatu yang melaksanakan [`FnMut`].Ia menghasilkan iterator baru yang memanggil penutupan ini pada setiap elemen iterator asal.
    ///
    /// Sekiranya anda pandai berfikir dalam jenis, anda boleh memikirkan `map()` seperti ini:
    /// Sekiranya anda mempunyai iterator yang memberi anda elemen dari beberapa jenis `A`, dan anda menginginkan iterator dari beberapa jenis `B` yang lain, anda boleh menggunakan `map()`, melewati penutupan yang memerlukan `A` dan mengembalikan `B`.
    ///
    ///
    /// `map()` secara konseptual serupa dengan gelung [`for`].Namun, kerana `map()` malas, ia paling baik digunakan ketika anda sudah bekerja dengan iterator lain.
    /// Sekiranya anda melakukan perulangan untuk kesan sampingan, dianggap lebih idiomatik untuk menggunakan [`for`] daripada `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sekiranya anda melakukan kesan sampingan, pilih [`for`] daripada `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // jangan buat ini:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ia bahkan tidak akan dilaksanakan, kerana ia malas.Rust akan memberi amaran kepada anda mengenai perkara ini.
    ///
    /// // Sebaliknya, gunakan untuk:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Memanggil penutupan pada setiap elemen iterator.
    ///
    /// Ini sama dengan menggunakan gelung [`for`] pada iterator, walaupun `break` dan `continue` tidak mungkin dilakukan dari penutupan.
    /// Secara amnya lebih idiomatik untuk menggunakan gelung `for`, tetapi `for_each` mungkin lebih mudah dibaca ketika memproses item pada akhir rantai iterator yang lebih panjang.
    ///
    /// Dalam beberapa kes, `for_each` mungkin juga lebih cepat daripada gelung, kerana ia akan menggunakan lelaran dalaman pada penyesuai seperti `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Untuk contoh kecil seperti itu, gelung `for` mungkin lebih bersih, tetapi `for_each` mungkin lebih baik untuk mengekalkan gaya berfungsi dengan iterator yang lebih panjang:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Membuat iterator yang menggunakan penutupan untuk menentukan apakah elemen harus dihasilkan.
    ///
    /// Diberi elemen penutupan mesti mengembalikan `true` atau `false`.Pengulangan yang dikembalikan hanya akan menghasilkan elemen yang mana penutupan kembali benar.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kerana penutupan yang diteruskan ke `filter()` memerlukan rujukan, dan banyak pengulangan berulang atas rujukan, ini membawa kepada situasi yang mungkin membingungkan, di mana jenis penutupan adalah rujukan berganda:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // perlukan dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Adalah biasa untuk menggunakan destructuring pada hujah untuk menghilangkan satu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // kedua-duanya dan *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// atau kedua-duanya:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dua &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// lapisan ini.
    ///
    /// Perhatikan bahawa `iter.filter(f).next()` bersamaan dengan `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Membuat iterator yang menyaring dan memetakan.
    ///
    /// Iterator yang dikembalikan menghasilkan hanya `nilai` yang mana penutupan yang dibekalkan mengembalikan `Some(value)`.
    ///
    /// `filter_map` boleh digunakan untuk menjadikan rantai [`filter`] dan [`map`] lebih ringkas.
    /// Contoh di bawah menunjukkan bagaimana `map().filter().map()` dapat disingkat menjadi satu panggilan ke `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Inilah contoh yang sama, tetapi dengan [`filter`] dan [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Membuat iterator yang memberikan kiraan lelaran semasa dan juga nilai seterusnya.
    ///
    /// Iterator yang dikembalikan menghasilkan pasangan `(i, val)`, di mana `i` adalah indeks lelaran semasa dan `val` adalah nilai yang dikembalikan oleh iterator.
    ///
    ///
    /// `enumerate()` mengekalkan kiraannya sebagai [`usize`].
    /// Sekiranya anda ingin mengira dengan bilangan bulat yang berbeza, fungsi [`zip`] menyediakan fungsi yang serupa.
    ///
    /// # Kelakuan Limpahan
    ///
    /// Kaedah ini tidak melindungi terhadap limpahan, jadi menghitung lebih daripada elemen [`usize::MAX`] sama ada menghasilkan hasil yang salah atau panics.
    /// Sekiranya penegasan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Iterator yang dikembalikan mungkin panic jika indeks yang akan dikembalikan akan melimpah [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Membuat iterator yang boleh menggunakan [`peek`] untuk melihat elemen iterator seterusnya tanpa memakannya.
    ///
    /// Menambah kaedah [`peek`] ke iterator.Lihat dokumentasinya untuk maklumat lebih lanjut.
    ///
    /// Perhatikan bahawa iterator yang mendasari masih maju ketika [`peek`] dipanggil untuk pertama kalinya: Untuk mendapatkan elemen seterusnya, [`next`] dipanggil pada iterator yang mendasari, oleh itu sebarang kesan sampingan (iaitu
    ///
    /// apa-apa selain mengambil nilai seterusnya) kaedah [`next`] akan berlaku.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() mari kita lihat future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // kita dapat peek() berkali-kali, iterator tidak akan maju
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // setelah iterator selesai, begitu juga peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Membuat iterator bahawa elemen [`skip`] berdasarkan predikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` mengambil penutup sebagai hujah.Ini akan memanggil penutupan ini pada setiap elemen iterator, dan mengabaikan elemen sehingga mengembalikan `false`.
    ///
    /// Setelah `false` dikembalikan, tugas `skip_while()`'s selesai, dan elemen selebihnya dihasilkan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kerana penutupan yang diteruskan ke `skip_while()` memerlukan rujukan, dan banyak pengulangan berulang atas rujukan, ini membawa kepada situasi yang mungkin membingungkan, di mana jenis argumen penutupan adalah rujukan berganda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // perlukan dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti selepas `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // walaupun ini salah, kerana kita sudah mendapat yang salah, skip_while() tidak digunakan lagi
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Membuat iterator yang menghasilkan elemen berdasarkan predikat.
    ///
    /// `take_while()` mengambil penutup sebagai hujah.Ia akan memanggil penutupan ini pada setiap elemen iterator, dan menghasilkan elemen semasa mengembalikan `true`.
    ///
    /// Setelah `false` dikembalikan, tugas `take_while()`'s selesai, dan elemen-elemen lain tidak diambil kira.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kerana penutupan yang diteruskan ke `take_while()` memerlukan rujukan, dan banyak pengulangan berulang atas rujukan, ini menyebabkan situasi yang mungkin membingungkan, di mana jenis penutupan adalah rujukan berganda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // perlukan dua * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti selepas `false` awal:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Kami mempunyai lebih banyak elemen yang kurang dari sifar, tetapi kerana kami sudah mendapat yang salah, take_while() tidak lagi digunakan
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kerana `take_while()` perlu melihat nilainya untuk melihat apakah itu harus disertakan atau tidak, iterator yang memakan akan melihat bahawa ia dihapus:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` tidak lagi ada, kerana digunakan untuk melihat apakah lelaran harus berhenti, tetapi tidak dimasukkan kembali ke iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Membuat iterator yang kedua-duanya menghasilkan elemen berdasarkan predikat dan peta.
    ///
    /// `map_while()` mengambil penutup sebagai hujah.
    /// Ia akan memanggil penutupan ini pada setiap elemen iterator, dan menghasilkan elemen semasa mengembalikan [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Inilah contoh yang sama, tetapi dengan [`take_while`] dan [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Berhenti selepas [`None`] awal:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Kami mempunyai lebih banyak elemen yang sesuai dengan u32 (4, 5), tetapi `map_while` mengembalikan `None` untuk `-3` (ketika `predicate` mengembalikan `None`) dan `collect` berhenti pada `None` pertama yang dihadapi.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Kerana `map_while()` perlu melihat nilainya untuk melihat apakah itu harus disertakan atau tidak, iterator yang memakan akan melihat bahawa ia dihapus:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` tidak lagi ada, kerana digunakan untuk melihat apakah lelaran harus berhenti, tetapi tidak dimasukkan kembali ke iterator.
    ///
    /// Perhatikan bahawa tidak seperti [`take_while`] iterator ini **tidak** menyatu.
    /// Ia juga tidak dinyatakan apa yang dikembalikan oleh iterator ini setelah [`None`] pertama dikembalikan.
    /// Sekiranya anda memerlukan iterator bersatu, gunakan [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Membuat iterator yang melangkau elemen `n` pertama.
    ///
    /// Setelah habis, unsur-unsur selebihnya akan dihasilkan.
    /// Daripada mengatasi kaedah ini secara langsung, sebaliknya mengatasi kaedah `nth`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Membuat iterator yang menghasilkan elemen `n` pertama.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` sering digunakan dengan iterator yang tidak terhingga, untuk menjadikannya terhingga:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sekiranya terdapat kurang daripada elemen `n`, `take` akan mengehadkan dirinya pada ukuran iterator yang mendasari:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Penyesuai iterator serupa dengan [`fold`] yang menahan keadaan dalaman dan menghasilkan iterator baru.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` mengambil dua argumen: nilai awal yang menghasilkan keadaan dalaman, dan penutupan dengan dua argumen, yang pertama adalah rujukan yang dapat berubah untuk keadaan dalaman dan yang kedua adalah elemen berulang.
    ///
    /// Penutupan boleh memberikan kepada keadaan dalaman untuk berkongsi keadaan antara lelaran.
    ///
    /// Pada iterasi, penutupan akan diterapkan pada setiap elemen iterator dan nilai kembali dari penutupan, [`Option`], dihasilkan oleh iterator.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // setiap lelaran, kita akan menggandakan keadaan dengan elemen
    ///     *state = *state * x;
    ///
    ///     // maka, kita akan menghasilkan penolakan negara
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Membuat iterator yang berfungsi seperti peta, tetapi meratakan struktur bersarang.
    ///
    /// Penyesuai [`map`] sangat berguna, tetapi hanya apabila argumen penutupan menghasilkan nilai.
    /// Sekiranya menghasilkan iterator, terdapat lapisan tidak langsung tambahan.
    /// `flat_map()` akan membuang lapisan tambahan ini dengan sendirinya.
    ///
    /// Anda boleh menganggap `flat_map(f)` sebagai semantik setara dengan ping [`map`], dan kemudian [`ratakan`] seperti di `map(f).flatten()`.
    ///
    /// Cara lain untuk berfikir tentang `flat_map()`: Penutupan [peta] mengembalikan satu item untuk setiap elemen, dan penutupan `flat_map()`'s mengembalikan iterator untuk setiap elemen.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan lelaran
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Membuat lelaran yang merata struktur bersarang.
    ///
    /// Ini berguna apabila anda mempunyai pengulangan iterator atau iterator perkara yang boleh diubah menjadi iterator dan anda ingin membuang satu tahap pengarahan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Pemetaan dan kemudian meratakan:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan lelaran
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Anda juga boleh menulis semula ini dari segi [`flat_map()`], yang lebih disukai dalam kes ini kerana menyampaikan maksud dengan lebih jelas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() mengembalikan lelaran
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Meratakan hanya menghilangkan satu tahap bersarang pada satu masa:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Di sini kita melihat bahawa `flatten()` tidak melakukan pelepasan "deep".
    /// Sebaliknya, hanya satu tahap bersarang yang dikeluarkan.Maksudnya, jika anda `flatten()` susunan tiga dimensi, hasilnya akan menjadi dua dimensi dan bukan satu dimensi.
    /// Untuk mendapatkan struktur satu dimensi, anda perlu `flatten()` lagi.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Membuat iterator yang berakhir selepas [`None`] pertama.
    ///
    /// Selepas iterator mengembalikan [`None`], panggilan future mungkin atau tidak akan menghasilkan [`Some(T)`] lagi.
    /// `fuse()` menyesuaikan iterator, memastikan bahawa setelah [`None`] diberikan, ia akan selalu mengembalikan [`None`] selamanya.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // iterator yang bergantian antara Beberapa dan Tiada
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // jika ia sama rata, Some(i32), yang lain Tiada
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // kita dapat melihat iterator kita berulang-alik
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // namun, setelah kita menggabungkannya ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ia akan sentiasa mengembalikan `None` selepas kali pertama.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Melakukan sesuatu dengan setiap elemen iterator, meneruskan nilai.
    ///
    /// Semasa menggunakan iterator, anda sering menyatukan beberapa daripadanya.
    /// Semasa mengusahakan kod tersebut, anda mungkin ingin melihat apa yang berlaku di pelbagai bahagian di saluran paip.Untuk melakukan itu, masukkan panggilan ke `inspect()`.
    ///
    /// Adalah lebih biasa untuk `inspect()` digunakan sebagai alat debug daripada yang ada dalam kod akhir anda, tetapi aplikasi mungkin berguna dalam situasi tertentu ketika kesalahan perlu dicatat sebelum dibuang.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // urutan iterator ini kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // mari tambah beberapa panggilan inspect() untuk menyiasat apa yang berlaku
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ini akan mencetak:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Kesalahan log sebelum membuangnya:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ini akan mencetak:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Meminjam iterator, dan bukannya memakannya.
    ///
    /// Ini berguna untuk membenarkan penggunaan penyesuai iterator sambil masih mengekalkan pemilikan iterator asal.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // jika kita cuba menggunakannya lagi, ia tidak akan berjaya.
    /// // Garis berikut memberikan "ralat: penggunaan nilai yang dipindahkan: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // mari cuba lagi
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // sebaliknya, kami menambah .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // sekarang ini baik-baik saja:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Mengubah iterator menjadi koleksi.
    ///
    /// `collect()` boleh mengambil apa-apa perkara berulang, dan mengubahnya menjadi koleksi yang relevan.
    /// Ini adalah salah satu kaedah yang lebih kuat di perpustakaan standard, yang digunakan dalam pelbagai konteks.
    ///
    /// Corak paling asas di mana `collect()` digunakan adalah mengubah satu koleksi menjadi koleksi yang lain.
    /// Anda mengambil koleksi, memanggil [`iter`] di atasnya, melakukan banyak transformasi, dan kemudian `collect()` di akhir.
    ///
    /// `collect()` juga boleh membuat contoh jenis yang bukan koleksi khas.
    /// Sebagai contoh, [`String`] boleh dibina dari [`char`], dan iterator item [`Result<T, E>`][`Result`] dapat dikumpulkan menjadi `Result<Collection<T>, E>`.
    ///
    /// Lihat contoh di bawah untuk maklumat lanjut.
    ///
    /// Kerana `collect()` begitu umum, ia boleh menyebabkan masalah dengan jenis inferens.
    /// Oleh itu, `collect()` adalah salah satu daripada beberapa kali anda akan melihat sintaks yang dikenali sebagai 'turbofish': `::<>`.
    /// Ini membantu algoritma inferensi memahami secara spesifik koleksi mana yang ingin anda kumpulkan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Perhatikan bahawa kami memerlukan `: Vec<i32>` di sebelah kiri.Ini kerana kita dapat mengumpulkan, sebagai contoh, [`VecDeque<T>`] sebagai gantinya:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Menggunakan 'turbofish' dan bukannya memberi anotasi `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Kerana `collect()` hanya mengambil berat tentang apa yang anda kumpulkan, anda masih boleh menggunakan petunjuk jenis separa, `_`, dengan turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Menggunakan `collect()` untuk membuat [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Sekiranya anda mempunyai senarai [`Hasil<T, E>`][`Result`] s, anda boleh menggunakan `collect()` untuk melihat apakah ada yang gagal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // memberi kita kesalahan pertama
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // memberi kami senarai jawapan
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Menggunakan iterator, membuat dua koleksi daripadanya.
    ///
    /// Predikat yang diteruskan ke `partition()` dapat mengembalikan `true`, atau `false`.
    /// `partition()` mengembalikan sepasang, semua elemen di mana ia mengembalikan `true`, dan semua elemen yang mana ia mengembalikan `false`.
    ///
    ///
    /// Lihat juga [`is_partitioned()`] dan [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Susun semula elemen iterator ini *di tempat* mengikut predikat yang diberikan, sehingga semua yang mengembalikan `true` mendahului semua yang mengembalikan `false`.
    ///
    /// Mengembalikan bilangan elemen `true` yang dijumpai.
    ///
    /// Urutan relatif item yang dipartisi tidak dijaga.
    ///
    /// Lihat juga [`is_partitioned()`] dan [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Pembahagian di antara evens dan odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: haruskah kita bimbang tentang jumlah yang melimpah?Satu-satunya cara untuk memiliki lebih daripada
        // `usize::MAX` rujukan yang boleh diubah adalah dengan ZST, yang tidak berguna untuk membahagi ...

        // Fungsi penutupan "factory" ini wujud untuk mengelakkan kegunaan `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Berulang kali mencari `false` pertama dan menukarnya dengan `true` terakhir.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Memeriksa apakah elemen iterator ini dipartisi mengikut predikat yang diberikan, sehingga semua yang mengembalikan `true` mendahului semua yang mengembalikan `false`.
    ///
    ///
    /// Lihat juga [`partition()`] dan [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Sama ada semua item menguji `true`, atau klausa pertama berhenti di `false` dan kami memastikan tidak ada lagi item `true` selepas itu.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Kaedah iterator yang menerapkan fungsi selagi ia berjaya kembali, menghasilkan satu, nilai akhir.
    ///
    /// `try_fold()` mengambil dua argumen: nilai awal, dan penutupan dengan dua argumen: 'accumulator', dan elemen.
    /// Penutupan sama ada berjaya kembali, dengan nilai yang harus dimiliki oleh penumpuk untuk lelaran seterusnya, atau mengembalikan kegagalan, dengan nilai ralat yang disebarkan kembali ke pemanggil segera (short-circuiting).
    ///
    ///
    /// Nilai awal adalah nilai yang akan dimiliki oleh penumpuk pada panggilan pertama.Sekiranya menerapkan penutupan berjaya terhadap setiap elemen berulang, `try_fold()` mengembalikan penumpuk akhir sebagai kejayaan.
    ///
    /// Lipat berguna setiap kali anda mempunyai koleksi sesuatu, dan ingin menghasilkan satu nilai daripadanya.
    ///
    /// # Catatan kepada Pelaksana
    ///
    /// Beberapa kaedah (forward) lain mempunyai implementasi lalai dari yang satu ini, jadi cubalah menerapkannya secara eksplisit jika dapat melakukan sesuatu yang lebih baik daripada pelaksanaan gelung `for` lalai.
    ///
    /// Khususnya, cuba buat panggilan ini `try_fold()` pada bahagian dalaman dari mana iterator ini disusun.
    /// Sekiranya banyak panggilan diperlukan, pengendali `?` mungkin sesuai untuk merantai nilai penumpuk, tetapi berhati-hatilah dengan sebarang invarian yang perlu dijaga sebelum pengembalian awal.
    /// Ini adalah kaedah `&mut self`, jadi lelaran perlu disambung semula setelah melakukan kesalahan di sini.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah yang diperiksa untuk semua elemen larik
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Jumlah ini melimpah ketika menambahkan elemen 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Oleh kerana ia berlitar pintas, unsur-unsur yang tersisa masih boleh didapati melalui iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Kaedah iterator yang menerapkan fungsi yang salah pada setiap item dalam iterator, berhenti pada ralat pertama dan mengembalikan ralat itu.
    ///
    ///
    /// Ini juga boleh dianggap sebagai bentuk [`for_each()`] yang salah atau sebagai versi [`try_fold()`] tanpa status.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Ia bersirkit pendek, jadi item yang tersisa masih dalam iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Lipat setiap elemen ke dalam penumpuk dengan menerapkan operasi, mengembalikan hasil akhir.
    ///
    /// `fold()` mengambil dua argumen: nilai awal, dan penutupan dengan dua argumen: 'accumulator', dan elemen.
    /// Penutupan mengembalikan nilai yang seharusnya dimiliki oleh penumpuk untuk lelaran seterusnya.
    ///
    /// Nilai awal adalah nilai yang akan dimiliki oleh penumpuk pada panggilan pertama.
    ///
    /// Setelah menerapkan penutupan ini ke setiap elemen iterator, `fold()` mengembalikan penumpuk.
    ///
    /// Operasi ini kadang-kadang dipanggil 'reduce' atau 'inject'.
    ///
    /// Lipat berguna setiap kali anda mempunyai koleksi sesuatu, dan ingin menghasilkan satu nilai daripadanya.
    ///
    /// Note: `fold()`, dan kaedah serupa yang melintasi keseluruhan iterator, mungkin tidak berakhir untuk iterator yang tidak terbatas, walaupun pada traits yang hasilnya dapat ditentukan dalam waktu yang terbatas.
    ///
    /// Note: [`reduce()`] dapat digunakan untuk menggunakan elemen pertama sebagai nilai awal, jika jenis akumulator dan jenis item sama.
    ///
    /// # Catatan kepada Pelaksana
    ///
    /// Beberapa kaedah (forward) lain mempunyai implementasi lalai dari yang satu ini, jadi cubalah menerapkannya secara eksplisit jika dapat melakukan sesuatu yang lebih baik daripada pelaksanaan gelung `for` lalai.
    ///
    ///
    /// Khususnya, cuba buat panggilan ini `fold()` pada bahagian dalaman dari mana iterator ini disusun.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah semua unsur larik
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Mari ikuti setiap langkah lelaran di sini:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Oleh itu, hasil akhir kami, `6`.
    ///
    /// Adalah biasa bagi orang yang tidak banyak menggunakan iterator untuk menggunakan gelung `for` dengan senarai perkara untuk membina hasil.Mereka boleh berubah menjadi `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // untuk gelung:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // mereka sama
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Mengurangkan elemen menjadi satu, dengan menggunakan operasi pengurangan berulang kali.
    ///
    /// Sekiranya iterator kosong, mengembalikan [`None`];jika tidak, mengembalikan hasil pengurangan.
    ///
    /// Untuk iterator dengan sekurang-kurangnya satu elemen, ini sama dengan [`fold()`] dengan elemen pertama iterator sebagai nilai awal, melipat setiap elemen berikutnya ke dalamnya.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Cari nilai maksimum:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Menguji jika setiap elemen iterator sesuai dengan predikat.
    ///
    /// `all()` mengambil penutupan yang mengembalikan `true` atau `false`.Ini menerapkan penutupan ini pada setiap elemen iterator, dan jika semuanya mengembalikan `true`, maka begitu juga `all()`.
    /// Sekiranya ada yang mengembalikan `false`, ia akan mengembalikan `false`.
    ///
    /// `all()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja menemui `false`, memandangkan apa pun yang berlaku, hasilnya juga akan menjadi `false`.
    ///
    ///
    /// Pengulang kosong mengembalikan `true`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Berhenti pada `false` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Menguji jika ada unsur iterator yang sesuai dengan predikat.
    ///
    /// `any()` mengambil penutupan yang mengembalikan `true` atau `false`.Ini menerapkan penutupan ini pada setiap elemen iterator, dan jika ada dari mereka mengembalikan `true`, maka begitu juga `any()`.
    /// Sekiranya semuanya mengembalikan `false`, ia akan mengembalikan `false`.
    ///
    /// `any()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja menemui `true`, memandangkan apa pun yang berlaku, hasilnya juga akan menjadi `true`.
    ///
    ///
    /// Pengulang kosong mengembalikan `false`.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Berhenti pada `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Mencari elemen iterator yang memenuhi predikat.
    ///
    /// `find()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini pada setiap elemen iterator, dan jika ada yang mengembalikan `true`, maka `find()` akan mengembalikan [`Some(element)`].
    /// Sekiranya semuanya mengembalikan `false`, ia akan mengembalikan [`None`].
    ///
    /// `find()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja penutupan mengembalikan `true`.
    ///
    /// Kerana `find()` mengambil rujukan, dan banyak iterator mengulangi rujukan, ini membawa kepada situasi yang mungkin membingungkan di mana argumennya adalah rujukan berganda.
    ///
    /// Anda dapat melihat kesan ini dalam contoh di bawah, dengan `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Berhenti pada `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Perhatikan bahawa `iter.find(f)` bersamaan dengan `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Berlaku fungsi pada elemen iterator dan mengembalikan hasil pertama tanpa hasil.
    ///
    ///
    /// `iter.find_map(f)` bersamaan dengan `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Berlaku fungsi pada elemen iterator dan mengembalikan hasil benar pertama atau kesalahan pertama.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Mencari elemen dalam iterator, mengembalikan indeksnya.
    ///
    /// `position()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini pada setiap elemen iterator, dan jika salah satunya mengembalikan `true`, maka `position()` mengembalikan [`Some(index)`].
    /// Sekiranya semuanya mengembalikan `false`, ia akan mengembalikan [`None`].
    ///
    /// `position()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja menemui `true`.
    ///
    /// # Kelakuan Limpahan
    ///
    /// Kaedah ini tidak melindungi terhadap limpahan, jadi jika terdapat lebih daripada elemen [`usize::MAX`] yang tidak sepadan, ia menghasilkan hasil yang salah atau panics.
    ///
    /// Sekiranya penegasan debug diaktifkan, panic dijamin.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika iterator mempunyai lebih daripada `usize::MAX` elemen yang tidak sepadan.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Berhenti pada `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indeks yang dikembalikan bergantung kepada keadaan iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Mencari elemen dalam iterator dari kanan, mengembalikan indeksnya.
    ///
    /// `rposition()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ini menerapkan penutupan ini pada setiap elemen iterator, bermula dari akhir, dan jika salah satu daripadanya mengembalikan `true`, maka `rposition()` mengembalikan [`Some(index)`].
    ///
    /// Sekiranya semuanya mengembalikan `false`, ia akan mengembalikan [`None`].
    ///
    /// `rposition()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja menemui `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Berhenti pada `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tidak perlu pemeriksaan limpahan di sini, kerana `ExactSizeIterator` menunjukkan bahawa bilangan elemen sesuai dengan `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Mengembalikan elemen maksimum iterator.
    ///
    /// Sekiranya beberapa elemen sama maksimum, elemen terakhir dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Mengembalikan elemen minimum iterator.
    ///
    /// Sekiranya beberapa elemen sama minimum, elemen pertama dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Mengembalikan elemen yang memberikan nilai maksimum dari fungsi yang ditentukan.
    ///
    ///
    /// Sekiranya beberapa elemen sama maksimum, elemen terakhir dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Mengembalikan elemen yang memberikan nilai maksimum berkenaan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// Sekiranya beberapa elemen sama maksimum, elemen terakhir dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Mengembalikan elemen yang memberikan nilai minimum dari fungsi yang ditentukan.
    ///
    ///
    /// Sekiranya beberapa elemen sama minimum, elemen pertama dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Mengembalikan elemen yang memberikan nilai minimum berkenaan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// Sekiranya beberapa elemen sama minimum, elemen pertama dikembalikan.
    /// Sekiranya iterator kosong, [`None`] dikembalikan.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Membalikkan arah iterator.
    ///
    /// Biasanya, iterator berulang dari kiri ke kanan.
    /// Setelah menggunakan `rev()`, iterator sebaliknya akan berulang dari kanan ke kiri.
    ///
    /// Ini hanya mungkin dilakukan jika iterator berakhir, jadi `rev()` hanya berfungsi pada [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Menukar iterator pasangan menjadi sepasang bekas.
    ///
    /// `unzip()` menggunakan keseluruhan iterator pasangan, menghasilkan dua koleksi: satu dari elemen kiri pasangan, dan satu dari elemen kanan.
    ///
    ///
    /// Fungsi ini, dari segi tertentu, bertentangan dengan [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Membuat iterator yang menyalin semua elemennya.
    ///
    /// Ini berguna apabila anda mempunyai iterator lebih dari `&T`, tetapi anda memerlukan iterator lebih dari `T`.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // disalin sama dengan .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Membuat iterator yang [`clone`] semua elemennya.
    ///
    /// Ini berguna apabila anda mempunyai iterator lebih dari `&T`, tetapi anda memerlukan iterator lebih dari `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // diklon adalah sama dengan .map(|&x| x), untuk bilangan bulat
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Mengulangi iterator tanpa henti.
    ///
    /// Daripada berhenti di [`None`], iterator sebaliknya akan bermula lagi, dari awal.Setelah berulang lagi, ia akan bermula pada awal lagi.Dan lagi.
    /// Dan lagi.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Merumuskan unsur-unsur pengulangan.
    ///
    /// Mengambil setiap elemen, menambahkannya bersama, dan mengembalikan hasilnya.
    ///
    /// Pengulang kosong mengembalikan nilai sifar dari jenisnya.
    ///
    /// # Panics
    ///
    /// Semasa memanggil `sum()` dan jenis bilangan bulat primitif dikembalikan, kaedah ini akan panic jika pengiraan limpahan dan penegasan debug diaktifkan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Berulang pada keseluruhan iterator, mengalikan semua elemen
    ///
    /// Iterator kosong mengembalikan satu nilai jenis.
    ///
    /// # Panics
    ///
    /// Semasa memanggil `product()` dan jenis bilangan bulat primitif dikembalikan, kaedah akan panic jika pengiraan limpahan dan penegasan debug diaktifkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan unsur [`Iterator`] ini dengan elemen yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan unsur [`Iterator`] ini dengan elemen yang lain berkenaan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan unsur [`Iterator`] ini dengan elemen yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) membandingkan unsur [`Iterator`] ini dengan elemen yang lain berkenaan dengan fungsi perbandingan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Menentukan sama ada unsur [`Iterator`] ini sama dengan unsur yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Menentukan sama ada unsur [`Iterator`] ini sama dengan unsur lain berkenaan dengan fungsi persamaan yang ditentukan.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Menentukan sama ada unsur [`Iterator`] ini tidak sama dengan unsur yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Menentukan sama ada unsur [`Iterator`] ini [lexicographically](Ord#lexicographical-comparison) kurang daripada yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Menentukan sama ada unsur [`Iterator`] ini [lexicographically](Ord#lexicographical-comparison) kurang atau sama dengan unsur yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Menentukan sama ada unsur [`Iterator`] ini [lexicographically](Ord#lexicographical-comparison) lebih besar daripada unsur yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Menentukan sama ada unsur [`Iterator`] ini [lexicographically](Ord#lexicographical-comparison) lebih besar daripada atau sama dengan unsur yang lain.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Memeriksa sama ada unsur iterator ini disusun.
    ///
    /// Maksudnya, untuk setiap elemen `a` dan elemen berikut `b`, `a <= b` mesti dipegang.Sekiranya iterator menghasilkan tepat sifar atau satu elemen, `true` dikembalikan.
    ///
    /// Perhatikan bahawa jika `Self::Item` hanya `PartialOrd`, tetapi tidak `Ord`, definisi di atas menunjukkan bahawa fungsi ini mengembalikan `false` jika ada dua item berturut-turut tidak dapat dibandingkan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Memeriksa apakah unsur-unsur iterator ini disusun menggunakan fungsi pembanding yang diberikan.
    ///
    /// Daripada menggunakan `PartialOrd::partial_cmp`, fungsi ini menggunakan fungsi `compare` yang diberikan untuk menentukan susunan dua elemen.
    /// Selain itu, ia setara dengan [`is_sorted`];lihat dokumentasinya untuk maklumat lebih lanjut.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Memeriksa apakah unsur-unsur iterator ini disusun menggunakan fungsi pengekstrakan kunci yang diberikan.
    ///
    /// Daripada membandingkan unsur iterator secara langsung, fungsi ini membandingkan kunci elemen, seperti yang ditentukan oleh `f`.
    /// Selain itu, ia setara dengan [`is_sorted`];lihat dokumentasinya untuk maklumat lebih lanjut.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Lihat [TrustedRandomAccess]
    // Nama yang tidak biasa adalah untuk mengelakkan pelanggaran nama dalam penyelesaian kaedah lihat #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}