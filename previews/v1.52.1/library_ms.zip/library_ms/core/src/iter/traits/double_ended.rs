use crate::ops::{ControlFlow, Try};

/// Iterator dapat menghasilkan unsur dari kedua hujungnya.
///
/// Sesuatu yang menerapkan `DoubleEndedIterator` mempunyai satu kemampuan tambahan daripada sesuatu yang menerapkan [`Iterator`]: kemampuan untuk mengambil `Item` dari belakang, dan juga depan.
///
///
/// Penting untuk diperhatikan bahawa kedua-dua bolak-balik berfungsi pada jarak yang sama, dan tidak melintasi: lelaran berakhir ketika mereka bertemu di tengah.
///
/// Dengan cara yang serupa dengan protokol [`Iterator`], sekali `DoubleEndedIterator` mengembalikan [`None`] dari [`next_back()`], memanggilnya sekali lagi mungkin atau mungkin tidak pernah mengembalikan [`Some`] lagi.
/// [`next()`] dan [`next_back()`] boleh ditukar ganti untuk tujuan ini.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Mengeluarkan dan mengembalikan elemen dari hujung iterator.
    ///
    /// Mengembalikan `None` apabila tidak ada unsur lagi.
    ///
    /// Dokumen [trait-level] mengandungi lebih banyak butiran.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elemen yang dihasilkan oleh kaedah `DoubleEndedIterator" mungkin berbeza dengan elemen yang dihasilkan oleh kaedah [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Memajukan iterator dari belakang dengan elemen `n`.
    ///
    /// `advance_back_by` adalah versi terbalik [`advance_by`].Kaedah ini akan melangkau elemen `n` dengan bersemangat bermula dari belakang dengan memanggil [`next_back`] hingga `n` kali sehingga [`None`] ditemui.
    ///
    /// `advance_back_by(n)` akan mengembalikan [`Ok(())`] jika iterator berjaya maju dengan elemen `n`, atau [`Err(k)`] jika [`None`] ditemui, di mana `k` adalah bilangan elemen yang dilanjutkan oleh iterator sebelum kehabisan elemen (iaitu
    /// panjang iterator).
    /// Perhatikan bahawa `k` selalu kurang dari `n`.
    ///
    /// Memanggil `advance_back_by(0)` tidak memakan sebarang unsur dan selalu mengembalikan [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // hanya `&3` dilangkau
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Mengembalikan elemen `n` dari hujung iterator.
    ///
    /// Ini pada dasarnya adalah versi [`Iterator::nth()`] terbalik.
    /// Walaupun seperti kebanyakan operasi pengindeksan, kiraannya bermula dari sifar, jadi `nth_back(0)` mengembalikan nilai pertama dari akhir, `nth_back(1)` yang kedua, dan seterusnya.
    ///
    ///
    /// Perhatikan bahawa semua elemen antara elemen akhir dan yang dikembalikan akan habis digunakan, termasuk elemen yang dikembalikan.
    /// Ini juga bermaksud bahawa memanggil `nth_back(0)` berkali-kali pada iterator yang sama akan mengembalikan elemen yang berbeza.
    ///
    /// `nth_back()` akan mengembalikan [`None`] jika `n` lebih besar daripada atau sama dengan panjang iterator.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Memanggil `nth_back()` berkali-kali tidak mengundurkan iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Mengembalikan `None` jika terdapat kurang daripada elemen `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ini adalah versi terbalik dari [`Iterator::try_fold()`]: ia memerlukan elemen bermula dari belakang iterator.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Oleh kerana ia berlitar pintas, unsur-unsur yang tersisa masih boleh didapati melalui iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Kaedah iterator yang mengurangkan elemen iterator menjadi satu, nilai akhir, bermula dari belakang.
    ///
    /// Ini adalah versi terbalik [`Iterator::fold()`]: ia memerlukan elemen bermula dari belakang iterator.
    ///
    /// `rfold()` mengambil dua argumen: nilai awal, dan penutupan dengan dua argumen: 'accumulator', dan elemen.
    /// Penutupan mengembalikan nilai yang seharusnya dimiliki oleh penumpuk untuk lelaran seterusnya.
    ///
    /// Nilai awal adalah nilai yang akan dimiliki oleh penumpuk pada panggilan pertama.
    ///
    /// Setelah menerapkan penutupan ini ke setiap elemen iterator, `rfold()` mengembalikan penumpuk.
    ///
    /// Operasi ini kadang-kadang dipanggil 'reduce' atau 'inject'.
    ///
    /// Lipat berguna setiap kali anda mempunyai koleksi sesuatu, dan ingin menghasilkan satu nilai daripadanya.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // jumlah semua unsur a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Contoh ini membina rentetan, bermula dengan nilai awal dan meneruskan setiap elemen dari belakang hingga depan:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Mencari elemen iterator dari belakang yang memenuhi predikat.
    ///
    /// `rfind()` mengambil penutupan yang mengembalikan `true` atau `false`.
    /// Ia menerapkan penutupan ini pada setiap elemen iterator, bermula pada akhir, dan jika ada yang mengembalikan `true`, maka `rfind()` mengembalikan [`Some(element)`].
    /// Sekiranya semuanya mengembalikan `false`, ia akan mengembalikan [`None`].
    ///
    /// `rfind()` adalah litar pintas;dengan kata lain, ia akan berhenti diproses sebaik sahaja penutupan mengembalikan `true`.
    ///
    /// Kerana `rfind()` mengambil rujukan, dan banyak iterator mengulangi rujukan, ini membawa kepada situasi yang mungkin membingungkan di mana argumennya adalah rujukan berganda.
    ///
    /// Anda dapat melihat kesan ini dalam contoh di bawah, dengan `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Berhenti pada `true` pertama:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // kita masih boleh menggunakan `iter`, kerana terdapat lebih banyak elemen.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}