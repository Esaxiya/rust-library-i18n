use crate::iter::{FusedIterator, TrustedLen};

/// Membuat iterator baru yang mengulangi elemen jenis `A` tanpa henti dengan menerapkan penutupan yang disediakan, pengulang, `F: FnMut() -> A`.
///
/// Fungsi `repeat_with()` memanggil pengulang berulang-ulang kali.
///
/// Pengulangan tanpa had seperti `repeat_with()` sering digunakan dengan penyesuai seperti [`Iterator::take()`], untuk menjadikannya terhingga.
///
/// Sekiranya jenis elemen iterator yang anda perlukan menerapkan [`Clone`], dan tidak perlu menyimpan elemen sumber dalam ingatan, anda seharusnya menggunakan fungsi [`repeat()`].
///
///
/// Iterator yang dihasilkan oleh `repeat_with()` bukan [`DoubleEndedIterator`].
/// Sekiranya anda memerlukan `repeat_with()` untuk mengembalikan [`DoubleEndedIterator`], sila buka masalah GitHub yang menjelaskan kes penggunaan anda.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::iter;
///
/// // mari kita anggap kita mempunyai beberapa nilai jenis yang bukan `Clone` atau yang tidak mahu ada dalam ingatannya kerana ia mahal:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // nilai tertentu selamanya:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Menggunakan mutasi dan tidak terbatas:
///
/// ```rust
/// use std::iter;
///
/// // Dari sifar hingga kekuatan ketiga dari dua:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... dan sekarang kita sudah selesai
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iterator yang mengulangi elemen jenis `A` tanpa henti dengan menerapkan penutupan `F: FnMut() -> A` yang disediakan.
///
///
/// `struct` ini dibuat oleh fungsi [`repeat_with()`].
/// Lihat dokumentasinya untuk lebih lanjut.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}