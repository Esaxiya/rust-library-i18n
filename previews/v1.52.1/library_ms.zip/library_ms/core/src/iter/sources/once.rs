use crate::iter::{FusedIterator, TrustedLen};

/// Membuat iterator yang menghasilkan elemen tepat sekali.
///
/// Ini biasanya digunakan untuk menyesuaikan satu nilai menjadi [`chain()`] jenis lelaran lain.
/// Mungkin anda mempunyai iterator yang merangkumi hampir semua perkara, tetapi anda memerlukan kes khas tambahan.
/// Mungkin anda mempunyai fungsi yang berfungsi pada iterator, tetapi anda hanya perlu memproses satu nilai.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::iter;
///
/// // satu adalah nombor paling sepi
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // hanya satu, itu sahaja yang kita dapat
/// assert_eq!(None, one.next());
/// ```
///
/// Berantai bersama dengan iterator lain.
/// Katakanlah bahawa kita ingin melakukan iterasi pada setiap fail direktori `.foo`, tetapi juga fail konfigurasi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // kita perlu menukar dari iterator DirEntry-s ke iterator PathBufs, jadi kita menggunakan peta
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // sekarang, iterator kami hanya untuk fail konfigurasi kami
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // rantai dua iterator bersama menjadi satu iterator besar
/// let files = dirs.chain(config);
///
/// // ini akan memberi kita semua fail dalam .foo dan juga .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator yang menghasilkan elemen tepat sekali.
///
/// `struct` ini dibuat oleh fungsi [`once()`].Lihat dokumentasinya untuk lebih lanjut.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}