use crate::fmt;

/// Membuat iterator baru di mana setiap lelaran memanggil penutupan `F: FnMut() -> Option<T>` yang disediakan.
///
/// Ini membolehkan membuat iterator tersuai dengan tingkah laku tanpa menggunakan sintaks yang lebih verbose iaitu membuat jenis khusus dan melaksanakan [`Iterator`] trait untuknya.
///
/// Perhatikan bahawa iterator `FromFn` tidak membuat andaian mengenai tingkah laku penutupan, dan oleh itu secara konservatif tidak menerapkan [`FusedIterator`], atau menimpa [`Iterator::size_hint()`] dari `(0, None)` lalai.
///
///
/// Penutupan dapat menggunakan tangkapan dan persekitarannya untuk mengesan keadaan di seluruh lelaran.Bergantung pada bagaimana iterator digunakan, ini mungkin memerlukan menentukan kata kunci [`move`] pada penutupan.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Mari kita laksanakan semula iterator kaunter dari [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Tingkatkan jumlah kami.Inilah sebabnya mengapa kami bermula pada sifar.
///     count += 1;
///
///     // Periksa untuk mengetahui sama ada kita sudah selesai mengira atau tidak.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterator di mana setiap lelaran memanggil penutupan yang disediakan `F: FnMut() -> Option<T>`.
///
/// `struct` ini dibuat oleh fungsi [`iter::from_fn()`].
/// Lihat dokumentasinya untuk lebih lanjut.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}