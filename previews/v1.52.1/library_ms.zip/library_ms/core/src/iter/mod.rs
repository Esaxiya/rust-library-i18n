//! Pengulangan luaran yang boleh digubah.
//!
//! Sekiranya anda mempunyai koleksi semacam itu, dan perlu melakukan operasi pada elemen-elemen koleksi tersebut, anda akan mengalami 'iterators' dengan cepat.
//! Iterator banyak digunakan dalam kod Rust yang idiomatik, oleh itu perlu menjadi biasa dengan mereka.
//!
//! Sebelum menerangkan lebih lanjut, mari kita bincangkan bagaimana modul ini disusun:
//!
//! # Organization
//!
//! Modul ini sebahagian besarnya disusun mengikut jenis:
//!
//! * [Traits] adalah bahagian inti: traits ini menentukan jenis iterator yang ada dan apa yang boleh anda lakukan dengannya.Kaedah traits ini bernilai menghabiskan masa belajar tambahan.
//! * [Functions] berikan beberapa kaedah yang berguna untuk membuat beberapa iterator asas.
//! * [Structs] selalunya merupakan jenis pengembalian dari pelbagai kaedah pada traits modul ini.Anda biasanya ingin melihat kaedah yang menghasilkan `struct`, bukannya `struct` itu sendiri.
//! Untuk lebih terperinci mengenai sebabnya, lihat '[Implementasi Iterator](#implementasi-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Itu sahaja!Mari kita menggali iterator.
//!
//! # Iterator
//!
//! Hati dan jiwa modul ini adalah [`Iterator`] trait.Inti [`Iterator`] kelihatan seperti ini:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator mempunyai kaedah, [`next`], yang apabila dipanggil, mengembalikan [`Option`]`<Item>".
//! [`next`] akan mengembalikan [`Some(Item)`] selagi ada elemen, dan setelah semuanya habis, akan mengembalikan `None` untuk menunjukkan bahawa lelaran selesai.
//! Pengulangan individu boleh memilih untuk meneruskan iterasi, dan dengan itu memanggil [`next`] sekali lagi mungkin atau akhirnya tidak akan kembali mengembalikan [`Some(Item)`] pada suatu ketika (misalnya, lihat [`TryIter`]).
//!
//!
//! Definisi penuh ["Iterator"] merangkumi sebilangan kaedah lain juga, tetapi ia adalah kaedah lalai, dibina di atas [`next`], dan oleh itu anda mendapatkannya secara percuma.
//!
//! Iterator juga boleh digabungkan, dan lazimnya mengaitkannya untuk melakukan proses pemprosesan yang lebih kompleks.Lihat bahagian [Adapters](#adapters) di bawah untuk maklumat lebih lanjut.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tiga bentuk lelaran
//!
//! Terdapat tiga kaedah biasa yang boleh membuat berulang dari koleksi:
//!
//! * `iter()`, yang berulang lebih dari `&T`.
//! * `iter_mut()`, yang berulang lebih dari `&mut T`.
//! * `into_iter()`, yang berulang lebih dari `T`.
//!
//! Pelbagai perkara di perpustakaan standard dapat menerapkan satu atau lebih dari tiga, jika sesuai.
//!
//! # Melaksanakan Iterator
//!
//! Membuat iterator anda sendiri melibatkan dua langkah: membuat `struct` untuk menahan keadaan iterator, dan kemudian melaksanakan [`Iterator`] untuk `struct` tersebut.
//! Inilah sebabnya mengapa terdapat begitu banyak `struktur` dalam modul ini: ada satu untuk setiap penyesuai iterator dan iterator.
//!
//! Mari buat iterator bernama `Counter` yang dikira dari `1` hingga `5`:
//!
//! ```
//! // Pertama, struktur:
//!
//! /// Iterator yang dikira dari satu hingga lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami mahu kiraan kami bermula dari satu, jadi mari tambah kaedah new() untuk membantu.
//! // Ini tidak semestinya diperlukan, tetapi senang.
//! // Perhatikan bahawa kita memulakan `count` pada sifar, kita akan melihat mengapa dalam pelaksanaan `next()`'s di bawah.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kemudian, kami melaksanakan `Iterator` untuk `Counter` kami:
//!
//! impl Iterator for Counter {
//!     // kita akan mengira dengan penggunaan
//!     type Item = usize;
//!
//!     // next() adalah satu-satunya kaedah yang diperlukan
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Tingkatkan jumlah kami.Inilah sebabnya mengapa kami bermula pada sifar.
//!         self.count += 1;
//!
//!         // Periksa untuk mengetahui sama ada kita sudah selesai mengira atau tidak.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Dan sekarang kita boleh menggunakannya!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Memanggil [`next`] dengan cara ini berulang.Rust mempunyai konstruk yang boleh memanggil [`next`] pada iterator anda, sehingga mencapai `None`.Mari kita bahas seterusnya.
//!
//! Juga perhatikan bahawa `Iterator` menyediakan pelaksanaan kaedah lalai seperti `nth` dan `fold` yang memanggil `next` secara dalaman.
//! Walau bagaimanapun, juga mungkin untuk menulis pelaksanaan kaedah khusus seperti `nth` dan `fold` jika iterator dapat menghitungnya dengan lebih berkesan tanpa memanggil `next`.
//!
//! # `for` gelung dan `IntoIterator`
//!
//! Sintaks gelung `for` Rust sebenarnya gula untuk berulang.Berikut adalah contoh asas `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ini akan mencetak nombor satu hingga lima, masing-masing pada baris mereka sendiri.Tetapi anda akan melihat sesuatu di sini: kami tidak pernah memanggil apa-apa di vector kami untuk menghasilkan iterator.Apa yang memberi?
//!
//! Terdapat trait di perpustakaan standard untuk menukar sesuatu menjadi iterator: [`IntoIterator`].
//! trait ini mempunyai satu kaedah, [`into_iter`], yang mengubah perkara yang melaksanakan [`IntoIterator`] menjadi iterator.
//! Mari kita lihat gelung `for` itu lagi, dan apa yang dikompilasikannya menjadi:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-gula ini menjadi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pertama, kita memanggil nilai `into_iter()`.Kemudian, kita sepadan dengan iterator yang kembali, memanggil [`next`] berulang-ulang sehingga kita melihat `None`.
//! Pada ketika itu, kami `break` keluar dari gelung, dan kami selesai berulang kali.
//!
//! Terdapat satu lagi yang halus di sini: pustaka standard mengandungi pelaksanaan [`IntoIterator`] yang menarik:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Dengan kata lain, semua [`Iterator`] melaksanakan [`IntoIterator`], dengan hanya mengembalikan diri mereka sendiri.Ini bermaksud dua perkara:
//!
//! 1. Sekiranya anda menulis [`Iterator`], anda boleh menggunakannya dengan gelung `for`.
//! 2. Sekiranya anda membuat koleksi, menerapkan [`IntoIterator`] untuk koleksi itu akan membolehkan koleksi anda digunakan dengan gelung `for`.
//!
//! # Pengulangan melalui rujukan
//!
//! Oleh kerana [`into_iter()`] mengambil nilai `self`, menggunakan gelung `for` untuk melakukan lelaran ke atas koleksi yang memakan koleksi tersebut.Selalunya, anda mungkin mahu melakukan iterasi pada koleksi tanpa memakannya.
//! Banyak koleksi menawarkan kaedah yang memberikan rujukan berulang-ulang, yang secara konvensional disebut `iter()` dan `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` masih dimiliki oleh fungsi ini.
//! ```
//!
//! Sekiranya jenis koleksi `C` menyediakan `iter()`, biasanya juga menerapkan `IntoIterator` untuk `&C`, dengan implementasi yang hanya memanggil `iter()`.
//! Begitu juga, koleksi `C` yang menyediakan `iter_mut()` secara amnya menerapkan `IntoIterator` untuk `&mut C` dengan mewakilkan ke `iter_mut()`.Ini membolehkan singkatan mudah:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sama dengan `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama dengan `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Walaupun banyak koleksi menawarkan `iter()`, tidak semua menawarkan `iter_mut()`.
//! Sebagai contoh, memutuskan kunci [`HashSet<T>`] atau [`HashMap<K, V>`] dapat menjadikan koleksi menjadi tidak konsisten jika hash kunci berubah, jadi koleksi ini hanya menawarkan `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Fungsi yang mengambil [`Iterator`] dan mengembalikan [`Iterator`] yang lain sering disebut 'adaptor iterator', kerana mereka adalah bentuk 'penyesuai
//! pattern'.
//!
//! Penyesuai iterator biasa termasuk [`map`], [`take`], dan [`filter`].
//! Untuk lebih lanjut, lihat dokumentasi mereka.
//!
//! Sekiranya penyesuai iterator panics, iterator akan berada dalam keadaan yang tidak ditentukan (tetapi selamat memori).
//! Keadaan ini juga tidak dijamin akan tetap sama di seluruh versi Rust, jadi anda harus mengelakkan dari bergantung pada nilai tepat yang dikembalikan oleh iterator yang panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterator (dan iterator [adapters](#adapters))*malas*. Ini bermaksud bahawa membuat iterator tidak _do_ banyak sekali. Tidak ada yang benar-benar berlaku sehingga anda memanggil [`next`].
//! Ini kadang-kadang menjadi sumber kekeliruan ketika membuat iterator semata-mata untuk kesan sampingannya.
//! Sebagai contoh, kaedah [`map`] memanggil penutupan pada setiap elemen yang diulanginya:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ini tidak akan mencetak nilai apa pun, kerana kami hanya membuat iterator, dan bukannya menggunakannya.Penyusun akan memberi amaran kepada kami mengenai tingkah laku seperti ini:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Cara idiomatik untuk menulis [`map`] untuk kesan sampingannya adalah dengan menggunakan gelung `for` atau memanggil kaedah [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Kaedah umum lain untuk menilai iterator adalah dengan menggunakan kaedah [`collect`] untuk menghasilkan koleksi baru.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Pengulangan tidak semestinya terbatas.Sebagai contoh, rentang terbuka adalah berulang yang tidak terbatas:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Adalah biasa menggunakan penyesuai iterator [`take`] untuk mengubah iterator tak terhingga menjadi terhingga:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ini akan mencetak nombor `0` hingga `4`, masing-masing pada baris mereka sendiri.
//!
//! Ingatlah bahawa kaedah untuk iterator yang tidak terbatas, bahkan kaedah yang hasilnya dapat ditentukan secara matematik dalam waktu yang terbatas, mungkin tidak akan berakhir.
//! Secara khusus, kaedah seperti [`min`], yang pada umumnya memerlukan melintasi setiap elemen dalam iterator, kemungkinan tidak akan berjaya kembali untuk setiap iterator yang tidak terhingga.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh tidak!Gelung yang tidak terhingga!
//! // `ones.min()` menyebabkan gelung tak terhingga, jadi kami tidak akan sampai ke tahap ini!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;