#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Menyediakan jenis metadata penunjuk dari jenis runcing ke.
///
/// # Metadata penunjuk
///
/// Jenis penunjuk mentah dan jenis rujukan dalam Rust boleh dianggap terdiri daripada dua bahagian:
/// penunjuk data yang mengandungi alamat memori nilai, dan beberapa metadata.
///
/// Untuk jenis bersaiz statik (yang menerapkan `Sized` traits) dan juga untuk jenis `extern`, penunjuk dikatakan "tipis": metadata berukuran sifar dan jenisnya adalah `()`.
///
///
/// Petunjuk ke [dynamically-sized types][dst] dikatakan "lebar" atau "gemuk", mereka mempunyai metadata bukan ukuran sifar:
///
/// * Untuk struktur yang medan terakhirnya adalah DST, metadata adalah metadata untuk medan terakhir
/// * Untuk jenis `str`, metadata adalah panjang dalam bait sebagai `usize`
/// * Untuk jenis potongan seperti `[T]`, metadata adalah panjang item sebagai `usize`
/// * Untuk objek trait seperti `dyn SomeTrait`, metadata adalah [`DynMetadata<Self>`][DynMetadata] (mis. `DynMetadata<dyn SomeTrait>`)
///
/// Dalam future, bahasa Rust mungkin memperoleh jenis jenis baru yang mempunyai metadata penunjuk yang berbeza.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # The `Pointee` trait
///
/// Titik trait ini adalah jenis yang berkaitan dengan `Metadata`, iaitu `()` atau `usize` atau `DynMetadata<_>` seperti yang dijelaskan di atas.
/// Ia dilaksanakan secara automatik untuk setiap jenis.
/// Ini dapat diandaikan untuk dilaksanakan dalam konteks umum, bahkan tanpa batas yang sesuai.
///
/// # Usage
///
/// Penunjuk mentah dapat diuraikan ke alamat data dan komponen metadata dengan kaedah [`to_raw_parts`] mereka.
///
/// Sebagai alternatif, metadata sahaja boleh diekstrak dengan fungsi [`metadata`].
/// Rujukan boleh dihantar ke [`metadata`] dan dipaksakan secara tersirat.
///
/// Penunjuk (possibly-wide) dapat disatukan kembali dari alamat dan metadata dengan [`from_raw_parts`] atau [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Jenis untuk metadata dalam penunjuk dan merujuk kepada `Self`.
    #[lang = "metadata_type"]
    // NOTE: Simpan trait bounds di `static_assert_expected_bounds_for_metadata`
    //
    // dalam `library/core/src/ptr/metadata.rs` selari dengan yang ada di sini:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Petunjuk kepada jenis yang melaksanakan alias trait ini "nipis".
///
/// Ini termasuk jenis `` Saiz '' statik dan jenis `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: jangan stabilkan ini sebelum alias trait stabil dalam bahasa?
pub trait Thin = Pointee<Metadata = ()>;

/// Ekstrak komponen metadata penunjuk.
///
/// Nilai jenis `*mut T`, `&T`, atau `&mut T` dapat diteruskan terus ke fungsi ini kerana secara implisit memaksakan ke `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // KESELAMATAN: Mengakses nilai dari kesatuan `PtrRepr` selamat kerana * const T
    // dan PtrComponents<T>mempunyai susun atur memori yang sama.
    // Hanya std yang boleh membuat jaminan ini.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Membentuk penunjuk mentah (possibly-wide) dari alamat data dan metadata.
///
/// Fungsi ini selamat tetapi penunjuk yang dikembalikan tidak semestinya selamat untuk dihentikan.
/// Untuk kepingan, lihat dokumentasi [`slice::from_raw_parts`] untuk keperluan keselamatan.
/// Untuk objek trait, metadata mesti berasal dari penunjuk ke jenis asas yang sama.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // KESELAMATAN: Mengakses nilai dari kesatuan `PtrRepr` selamat kerana * const T
    // dan PtrComponents<T>mempunyai susun atur memori yang sama.
    // Hanya std yang boleh membuat jaminan ini.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Melakukan fungsi yang sama dengan [`from_raw_parts`], kecuali bahawa penunjuk `*mut` mentah dikembalikan, berbanding penunjuk `* const` mentah.
///
///
/// Lihat dokumentasi [`from_raw_parts`] untuk maklumat lebih lanjut.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // KESELAMATAN: Mengakses nilai dari kesatuan `PtrRepr` selamat kerana * const T
    // dan PtrComponents<T>mempunyai susun atur memori yang sama.
    // Hanya std yang boleh membuat jaminan ini.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Implan manual diperlukan untuk mengelakkan `T: Copy` terikat.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Implan manual diperlukan untuk mengelakkan `T: Clone` terikat.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadata untuk jenis objek `Dyn = dyn SomeTrait` trait.
///
/// Ini adalah penunjuk ke meja vabel (jadual panggilan maya) yang mewakili semua maklumat yang diperlukan untuk memanipulasi jenis konkrit yang disimpan di dalam objek trait.
/// Meja ini mengandungi:
///
/// * ukuran jenis
/// * penjajaran jenis
/// * penunjuk ke implan `drop_in_place` jenis (mungkin bukan op untuk data biasa-lama)
/// * menunjuk kepada semua kaedah untuk pelaksanaan jenis trait
///
/// Perhatikan bahawa tiga yang pertama adalah istimewa kerana mereka perlu memperuntukkan, menjatuhkan, dan menyahpindah mana-mana objek trait.
///
/// Adalah mungkin untuk menamakan struktur ini dengan parameter jenis yang bukan objek `dyn` trait (contohnya `DynMetadata<u64>`) tetapi tidak memperoleh nilai bermakna bagi struktur tersebut.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Awalan umum semua vtables.Ia diikuti oleh penunjuk fungsi untuk kaedah trait.
///
/// Perincian pelaksanaan peribadi `DynMetadata::size_of` dll.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Mengembalikan ukuran jenis yang berkaitan dengan vtable ini.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Mengembalikan penjajaran jenis yang berkaitan dengan vtable ini.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Mengembalikan ukuran dan penjajaran bersama-sama sebagai `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // KESELAMATAN: penyusun memancarkan vtable ini untuk jenis Rust konkrit yang
        // diketahui mempunyai susun atur yang sah.Rasional yang sama seperti `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Implan manual diperlukan untuk mengelakkan had `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}