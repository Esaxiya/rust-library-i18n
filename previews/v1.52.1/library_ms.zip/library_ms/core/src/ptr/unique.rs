use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Pembungkus di sekitar `*mut T` mentah-mentah yang menunjukkan bahawa pemilik pembungkus ini memiliki rujukan.
/// Berguna untuk membina abstraksi seperti `Box<T>`, `Vec<T>`, `String`, dan `HashMap<K, V>`.
///
/// Tidak seperti `*mut T`, `Unique<T>` berkelakuan "as if" itu adalah contoh `T`.
/// Ia melaksanakan `Send`/`Sync` jika `T` adalah `Send`/`Sync`.
/// Ini juga menunjukkan jenis aliasing yang kuat yang boleh dijangkakan oleh `T`:
/// rujukan penunjuk tidak boleh diubah suai tanpa jalan yang unik untuk memiliki yang unik.
///
/// Sekiranya anda tidak pasti sama ada betul menggunakan `Unique` untuk tujuan anda, pertimbangkan untuk menggunakan `NonNull`, yang mempunyai semantik yang lebih lemah.
///
///
/// Tidak seperti `*mut T`, penunjuk mestilah tidak sia-sia, walaupun penunjuk tidak pernah ditinggalkan.
/// Ini supaya enum dapat menggunakan nilai terlarang ini sebagai diskriminan-`Option<Unique<T>>` mempunyai ukuran yang sama dengan `Unique<T>`.
/// Walau bagaimanapun, penunjuk masih boleh menjuntai jika tidak ditangguhkan.
///
/// Tidak seperti `*mut T`, `Unique<T>` adalah kovarian berbanding `T`.
/// Ini harus selalu betul untuk semua jenis yang memenuhi keperluan aliasing Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: penanda ini tidak mempunyai akibat untuk varians, tetapi perlu
    // agar dropck memahami bahawa secara logiknya kami memiliki `T`.
    //
    // Untuk perincian, lihat:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointer adalah `Send` jika `T` adalah `Send` kerana data yang mereka rujuk tidak ada.
/// Perhatikan bahawa invarian aliasing ini tidak dipaksakan oleh sistem jenis;pengambilan menggunakan `Unique` mesti menegakkannya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointer adalah `Sync` jika `T` adalah `Sync` kerana data yang mereka rujuk tidak ada.
/// Perhatikan bahawa invarian aliasing ini tidak dipaksakan oleh sistem jenis;pengambilan menggunakan `Unique` mesti menegakkannya.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Membuat `Unique` baru yang menggantung, tetapi diselaraskan dengan baik.
    ///
    /// Ini berguna untuk memulakan jenis yang diperuntukkan dengan malas, seperti `Vec::new`.
    ///
    /// Perhatikan bahawa nilai penunjuk berpotensi mewakili penunjuk yang sah ke `T`, yang bermaksud ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang diperuntukkan dengan malas mesti mengesan inisialisasi dengan cara lain.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // KESELAMATAN: mem::align_of() mengembalikan penunjuk yang tidak sah.The
        // syarat untuk memanggil new_unchecked() dipatuhi.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Membuat `Unique` baru.
    ///
    /// # Safety
    ///
    /// `ptr` mesti tidak batal.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `ptr` tidak sah.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Membuat `Unique` baru jika `ptr` tidak kosong.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KESELAMATAN: Penunjuk sudah diperiksa dan tidak kosong.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Memperoleh penunjuk `*mut` yang mendasari.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Merendahkan kandungan.
    ///
    /// Seumur hidup yang dihasilkan terikat pada diri sendiri sehingga ini berperilaku "as if" sebenarnya ini adalah contoh T yang sedang dipinjam.
    /// Sekiranya jangka hayat (unbound) lebih lama, gunakan `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        unsafe { &*self.as_ptr() }
    }

    /// Dereferensikan kandungan secara bergantian.
    ///
    /// Seumur hidup yang dihasilkan terikat pada diri sendiri sehingga ini berperilaku "as if" sebenarnya ini adalah contoh T yang sedang dipinjam.
    /// Sekiranya jangka hayat (unbound) lebih lama, gunakan `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // syarat untuk rujukan yang boleh berubah.
        unsafe { &mut *self.as_ptr() }
    }

    /// Menghantar penunjuk jenis lain.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // KESELAMATAN: Unique::new_unchecked() mencipta unik dan keperluan baru
        // penunjuk yang diberikan agar tidak batal.
        // Oleh kerana kita menjadikan diri kita sebagai penunjuk, itu tidak boleh menjadi kosong.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KESELAMATAN: Rujukan yang tidak dapat diubah tidak boleh berlaku
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}