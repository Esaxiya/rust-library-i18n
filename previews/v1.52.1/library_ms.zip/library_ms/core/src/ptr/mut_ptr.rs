use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Mengembalikan `true` jika penunjuk kosong.
    ///
    /// Perhatikan bahawa jenis yang tidak bersaiz mempunyai banyak kemungkinan penunjuk kosong, kerana hanya penunjuk data mentah yang dipertimbangkan, bukan panjang, vtable, dll.
    /// Oleh itu, dua petunjuk yang tidak dapat dipastikan mungkin tidak sama antara satu sama lain.
    ///
    /// ## Tingkah laku semasa penilaian konst
    ///
    /// Apabila fungsi ini digunakan semasa penilaian const, ia mungkin mengembalikan `false` untuk petunjuk yang ternyata tidak berfungsi pada waktu proses.
    /// Secara khusus, apabila penunjuk ke beberapa memori diimbangi melebihi batas sedemikian rupa sehingga penunjuk yang dihasilkan adalah nol, fungsinya akan tetap mengembalikan `false`.
    ///
    /// Tidak ada cara untuk CTFE mengetahui kedudukan mutlak memori itu, jadi kami tidak dapat mengetahui apakah penunjuk itu batal atau tidak.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Bandingkan melalui pemeran ke penunjuk nipis, jadi penunjuk lemak hanya mempertimbangkan bahagian "data" mereka untuk nol-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Menghantar penunjuk jenis lain.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Menguraikan penunjuk (mungkin lebar) ke dalam komponen alamat dan metadata.
    ///
    /// Penunjuk kemudian boleh dibina semula dengan [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Mengembalikan `None` jika penunjuk nol, atau mengembalikan rujukan bersama kepada nilai yang dibungkus dalam `Some`.Sekiranya nilainya mungkin tidak dimulakan, [`as_uninit_ref`] mesti digunakan sebagai gantinya.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Penunjuk mesti menunjukkan contoh `T` yang diinisialisasi.
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    /// (Bahagian tentang diinisialisasi belum diputuskan sepenuhnya, tetapi sampai sekarang, satu-satunya pendekatan yang selamat adalah memastikan mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versi tidak dicentang
    ///
    /// Sekiranya anda pasti penunjuk tidak boleh kosong dan mencari jenis `as_ref_unchecked` yang mengembalikan `&T` dan bukannya `Option<&T>`, ketahuilah bahawa anda boleh mengurangkan penunjuk secara langsung.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` sah untuk a
        // rujuk jika tidak kosong.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Mengembalikan `None` jika penunjuk nol, atau mengembalikan rujukan bersama kepada nilai yang dibungkus dalam `Some`.
    /// Berbeza dengan [`as_ref`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Mengira ofset dari penunjuk.
    ///
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Sekiranya salah satu syarat berikut dilanggar, hasilnya adalah Tingkah Laku Tidak Ditentukan:
    ///
    /// * Kedua-dua penunjuk permulaan dan hasil mesti sama ada dalam batas atau satu bait melewati akhir objek yang diperuntukkan sama.
    /// Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// * Offset yang dikira,**dalam byte**, tidak dapat melimpah `isize`.
    ///
    /// * Ofset yang berada dalam batas tidak boleh bergantung pada ruang alamat "wrapping around".Iaitu, jumlah ketepatan tak terhingga,**dalam bait** mesti sesuai dengan penggunaan.
    ///
    /// Pengkompil dan pustaka standard pada amnya berusaha memastikan peruntukan tidak pernah mencapai ukuran di mana ofset menjadi perhatian.
    /// Sebagai contoh, `Vec` dan `Box` memastikan mereka tidak pernah memperuntukkan lebih daripada `isize::MAX` bait, jadi `vec.as_ptr().add(vec.len())` selalu selamat.
    ///
    /// Sebilangan besar platform pada dasarnya tidak dapat membina peruntukan sedemikian.
    /// Sebagai contoh, tidak ada platform 64-bit yang diketahui yang dapat melayani permintaan untuk 2 <sup>63</sup> bait kerana keterbatasan jadual halaman atau membelah ruang alamat.
    /// Walau bagaimanapun, beberapa platform 32-bit dan 16-bit berjaya memenuhi permintaan lebih daripada `isize::MAX` bait dengan perkara seperti Sambungan Alamat Fizikal.
    ///
    /// Oleh itu, ingatan yang diperoleh secara langsung dari pengedar atau fail yang dipetakan memori *mungkin* terlalu besar untuk dikendalikan dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_offset`] sebaliknya jika kekangan ini sukar dipuaskan.
    /// Satu-satunya kelebihan kaedah ini ialah ia membolehkan pengoptimuman penyusun yang lebih agresif.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `offset`.
        // Penunjuk yang diperoleh adalah sah untuk penulisan kerana pemanggil harus menjamin bahawa ia menunjuk ke objek yang diperuntukkan sama dengan `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Mengira ofset dari penunjuk menggunakan aritmetik pembungkus.
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu selamat, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Penunjuk yang dihasilkan tetap melekat pada objek yang diperuntukkan yang sama yang ditunjukkan oleh `self`.
    /// Mungkin *tidak* digunakan untuk mengakses objek yang diperuntukkan yang berbeza.Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_offset((y as isize) - (x as isize))`*tidak* menjadikan `z` sama dengan `y` walaupun kita menganggap `T` mempunyai ukuran `1` dan tidak ada limpahan: `z` masih melekat pada objek yang dilampirkan `x`, dan tidak menjadikannya Perilaku Tidak Ditentukan kecuali `x` dan Titik `y` ke objek yang diperuntukkan yang sama.
    ///
    /// Berbanding dengan [`offset`], kaedah ini pada dasarnya menangguhkan syarat tinggal dalam objek yang diperuntukkan yang sama: [`offset`] adalah Tingkah Laku Tidak Ditentukan segera ketika melintasi batas objek;`wrapping_offset` menghasilkan penunjuk tetapi masih membawa kepada Tingkah Laku Tidak Terdefinisi jika penunjuk tidak dirujuk ketika berada di luar batas objek yang dilekatkannya.
    /// [`offset`] dapat dioptimumkan dengan lebih baik dan dengan itu lebih disukai dalam kod sensitif prestasi.
    ///
    /// Pemeriksaan yang ditangguhkan hanya mempertimbangkan nilai penunjuk yang dereferensikan, bukan nilai perantaraan yang digunakan semasa pengiraan hasil akhir.
    /// Contohnya, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` selalu sama dengan `x`.Dengan kata lain, membiarkan objek yang diperuntukkan dan memasukkannya semula kemudian dibenarkan.
    ///
    /// Sekiranya anda perlu melintasi batas objek, hantarkan penunjuk ke bilangan bulat dan lakukan aritmetik di sana.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // Berulang dengan menggunakan penunjuk mentah dalam kenaikan dua elemen
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KESELAMATAN: intrinsik `arith_offset` tidak mempunyai prasyarat untuk dipanggil.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Mengembalikan `None` jika penunjuk kosong, atau mengembalikan rujukan unik untuk nilai yang dibungkus dalam `Some`.Sekiranya nilainya mungkin tidak dimulakan, [`as_uninit_mut`] mesti digunakan sebagai gantinya.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Penunjuk mesti menunjukkan contoh `T` yang diinisialisasi.
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    /// (Bahagian tentang diinisialisasi belum diputuskan sepenuhnya, tetapi sampai sekarang, satu-satunya pendekatan yang selamat adalah memastikan mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ia akan mencetak: "[4, 2, 3]".
    /// ```
    ///
    /// # Versi tidak dicentang
    ///
    /// Sekiranya anda pasti penunjuk tidak boleh kosong dan mencari jenis `as_mut_unchecked` yang mengembalikan `&mut T` dan bukannya `Option<&mut T>`, ketahuilah bahawa anda boleh mengurangkan penunjuk secara langsung.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ia akan mencetak: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` sah untuk
        // rujukan yang boleh berubah jika tidak batal.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Mengembalikan `None` jika penunjuk kosong, atau mengembalikan rujukan unik untuk nilai yang dibungkus dalam `Some`.
    /// Berbeza dengan [`as_mut`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Mengembalikan sama ada dua penunjuk dijamin sama.
    ///
    /// Pada waktu runtime, fungsi ini berkelakuan seperti `self == other`.
    /// Walau bagaimanapun, dalam beberapa konteks (contohnya, penilaian waktu kompilasi), tidak selalu mungkin untuk menentukan persamaan dua titik, jadi fungsi ini secara tidak sengaja dapat mengembalikan `false` untuk petunjuk yang kemudian benar-benar berubah menjadi sama.
    ///
    /// Tetapi apabila mengembalikan `true`, pointer dijamin sama.
    ///
    /// Fungsi ini adalah cermin [`guaranteed_ne`], tetapi bukan kebalikannya.Terdapat perbandingan penunjuk yang kedua fungsi mengembalikan `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Nilai pulangan mungkin berubah bergantung pada versi penyusun dan kod yang tidak selamat mungkin tidak bergantung pada hasil fungsi ini untuk kesegaran.
    /// Dianjurkan untuk hanya menggunakan fungsi ini untuk pengoptimuman prestasi di mana nilai pengembalian `false` palsu oleh fungsi ini tidak mempengaruhi hasilnya, tetapi hanya kinerja.
    /// Kesan daripada menggunakan kaedah ini untuk membuat kod runtime dan compile-time berkelakuan berbeza belum diterokai.
    /// Kaedah ini tidak boleh digunakan untuk memperkenalkan perbezaan tersebut, dan juga tidak boleh distabilkan sebelum kita memiliki pemahaman yang lebih baik mengenai masalah ini.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Mengembalikan sama ada dua penunjuk dijamin tidak sama.
    ///
    /// Pada waktu runtime, fungsi ini berkelakuan seperti `self != other`.
    /// Namun, dalam beberapa konteks (misalnya, penilaian waktu kompilasi), tidak selalu mungkin untuk menentukan ketaksamaan dua titik, jadi fungsi ini dapat mengembalikan `false` secara tidak sengaja untuk petunjuk yang kemudian benar-benar berubah menjadi tidak sama.
    ///
    /// Tetapi apabila mengembalikan `true`, petunjuknya dijamin tidak sama.
    ///
    /// Fungsi ini adalah cermin [`guaranteed_eq`], tetapi bukan kebalikannya.Terdapat perbandingan penunjuk yang kedua fungsi mengembalikan `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Nilai pulangan mungkin berubah bergantung pada versi penyusun dan kod yang tidak selamat mungkin tidak bergantung pada hasil fungsi ini untuk kesegaran.
    /// Dianjurkan untuk hanya menggunakan fungsi ini untuk pengoptimuman prestasi di mana nilai pengembalian `false` palsu oleh fungsi ini tidak mempengaruhi hasilnya, tetapi hanya kinerja.
    /// Kesan daripada menggunakan kaedah ini untuk membuat kod runtime dan compile-time berkelakuan berbeza belum diterokai.
    /// Kaedah ini tidak boleh digunakan untuk memperkenalkan perbezaan tersebut, dan juga tidak boleh distabilkan sebelum kita memiliki pemahaman yang lebih baik mengenai masalah ini.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Mengira jarak antara dua titik.Nilai yang dikembalikan adalah dalam unit T: jarak dalam bait dibahagi dengan `mem::size_of::<T>()`.
    ///
    /// Fungsi ini adalah kebalikan dari [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Sekiranya salah satu syarat berikut dilanggar, hasilnya adalah Tingkah Laku Tidak Ditentukan:
    ///
    /// * Penunjuk permulaan dan penunjuk lain mestilah sama atau satu bait melewati akhir objek yang diperuntukkan sama.
    /// Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// * Kedua-dua penunjuk mesti *berasal dari* penunjuk ke objek yang sama.
    ///   (Lihat di bawah untuk contoh.)
    ///
    /// * Jarak antara penunjuk, dalam bait, mestilah gandaan tepat dari ukuran `T`.
    ///
    /// * Jarak antara penunjuk,**dalam bait**, tidak boleh melimpah `isize`.
    ///
    /// * Jarak yang berada dalam batas tidak boleh bergantung pada ruang alamat "wrapping around".
    ///
    /// Jenis Rust tidak pernah lebih besar daripada `isize::MAX` dan peruntukan Rust tidak pernah membungkus ruang alamat, jadi dua petunjuk dalam nilai dari mana-mana jenis Rust `T` akan selalu memenuhi dua syarat terakhir.
    ///
    /// Perpustakaan standard juga secara amnya memastikan bahawa peruntukan tidak pernah mencapai ukuran di mana ofset menjadi perhatian.
    /// Sebagai contoh, `Vec` dan `Box` memastikan mereka tidak pernah memperuntukkan lebih daripada `isize::MAX` bait, jadi `ptr_into_vec.offset_from(vec.as_ptr())` selalu memenuhi dua syarat terakhir.
    ///
    /// Sebilangan besar platform pada dasarnya tidak dapat membina peruntukan yang begitu besar.
    /// Sebagai contoh, tidak ada platform 64-bit yang diketahui yang dapat melayani permintaan untuk 2 <sup>63</sup> bait kerana keterbatasan jadual halaman atau membelah ruang alamat.
    /// Walau bagaimanapun, beberapa platform 32-bit dan 16-bit berjaya memenuhi permintaan lebih daripada `isize::MAX` bait dengan perkara seperti Sambungan Alamat Fizikal.
    /// Oleh itu, ingatan yang diperoleh secara langsung dari pengedar atau fail yang dipetakan memori *mungkin* terlalu besar untuk dikendalikan dengan fungsi ini.
    /// (Perhatikan bahawa [`offset`] dan [`add`] juga mempunyai batasan yang serupa dan oleh itu tidak dapat digunakan pada peruntukan besar seperti itu.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Fungsi ini panics jika `T` adalah Z00-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Penggunaan* tidak betul:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Jadikan ptr2_other "alias" ptr2, tetapi berasal dari ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Oleh kerana ptr2_other dan ptr2 berasal dari penunjuk ke objek yang berbeza, mengira ofsetnya adalah tingkah laku yang tidak ditentukan, walaupun mereka menunjukkan alamat yang sama!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Tingkah Laku Tidak Ditentukan
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Mengira ofset dari penunjuk (kemudahan untuk `.offset(count as isize)`).
    ///
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Sekiranya salah satu syarat berikut dilanggar, hasilnya adalah Tingkah Laku Tidak Ditentukan:
    ///
    /// * Kedua-dua penunjuk permulaan dan hasil mesti sama ada dalam batas atau satu bait melewati akhir objek yang diperuntukkan sama.
    /// Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// * Offset yang dikira,**dalam byte**, tidak dapat melimpah `isize`.
    ///
    /// * Ofset yang berada dalam batas tidak boleh bergantung pada ruang alamat "wrapping around".Iaitu, jumlah ketepatan tak terhingga mesti masuk dalam `usize`.
    ///
    /// Pengkompil dan pustaka standard pada amnya berusaha memastikan peruntukan tidak pernah mencapai ukuran di mana ofset menjadi perhatian.
    /// Sebagai contoh, `Vec` dan `Box` memastikan mereka tidak pernah memperuntukkan lebih daripada `isize::MAX` bait, jadi `vec.as_ptr().add(vec.len())` selalu selamat.
    ///
    /// Sebilangan besar platform pada dasarnya tidak dapat membina peruntukan sedemikian.
    /// Sebagai contoh, tidak ada platform 64-bit yang diketahui yang dapat melayani permintaan untuk 2 <sup>63</sup> bait kerana keterbatasan jadual halaman atau membelah ruang alamat.
    /// Walau bagaimanapun, beberapa platform 32-bit dan 16-bit berjaya memenuhi permintaan lebih daripada `isize::MAX` bait dengan perkara seperti Sambungan Alamat Fizikal.
    ///
    /// Oleh itu, ingatan yang diperoleh secara langsung dari pengedar atau fail yang dipetakan memori *mungkin* terlalu besar untuk dikendalikan dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_add`] sebaliknya jika kekangan ini sukar dipuaskan.
    /// Satu-satunya kelebihan kaedah ini ialah ia membolehkan pengoptimuman penyusun yang lebih agresif.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Mengira ofset dari penunjuk (kemudahan untuk `.offset ((dikira sebagai isize).wrapping_neg())`)).
    ///
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Sekiranya salah satu syarat berikut dilanggar, hasilnya adalah Tingkah Laku Tidak Ditentukan:
    ///
    /// * Kedua-dua penunjuk permulaan dan hasil mesti sama ada dalam batas atau satu bait melewati akhir objek yang diperuntukkan sama.
    /// Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// * Offset yang dikira tidak boleh melebihi `isize::MAX`**bait**.
    ///
    /// * Offset yang berada dalam batas tidak boleh bergantung pada ruang alamat "wrapping around".Iaitu, jumlah ketepatan tak terhingga harus sesuai dengan penggunaan.
    ///
    /// Pengkompil dan pustaka standard pada amnya berusaha memastikan peruntukan tidak pernah mencapai ukuran di mana ofset menjadi perhatian.
    /// Sebagai contoh, `Vec` dan `Box` memastikan mereka tidak pernah memperuntukkan lebih daripada `isize::MAX` bait, jadi `vec.as_ptr().add(vec.len()).sub(vec.len())` selalu selamat.
    ///
    /// Sebilangan besar platform pada dasarnya tidak dapat membina peruntukan sedemikian.
    /// Sebagai contoh, tidak ada platform 64-bit yang diketahui yang dapat melayani permintaan untuk 2 <sup>63</sup> bait kerana keterbatasan jadual halaman atau membelah ruang alamat.
    /// Walau bagaimanapun, beberapa platform 32-bit dan 16-bit berjaya memenuhi permintaan lebih daripada `isize::MAX` bait dengan perkara seperti Sambungan Alamat Fizikal.
    ///
    /// Oleh itu, ingatan yang diperoleh secara langsung dari pengedar atau fail yang dipetakan memori *mungkin* terlalu besar untuk dikendalikan dengan fungsi ini.
    ///
    /// Pertimbangkan untuk menggunakan [`wrapping_sub`] sebaliknya jika kekangan ini sukar dipuaskan.
    /// Satu-satunya kelebihan kaedah ini ialah ia membolehkan pengoptimuman penyusun yang lebih agresif.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Mengira ofset dari penunjuk menggunakan aritmetik pembungkus.
    /// (kemudahan untuk `.wrapping_offset(count as isize)`)
    ///
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu selamat, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Penunjuk yang dihasilkan tetap melekat pada objek yang diperuntukkan yang sama yang ditunjukkan oleh `self`.
    /// Mungkin *tidak* digunakan untuk mengakses objek yang diperuntukkan yang berbeza.Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_add((y as usize) - (x as usize))`*tidak* menjadikan `z` sama dengan `y` walaupun kita menganggap `T` mempunyai ukuran `1` dan tidak ada limpahan: `z` masih melekat pada objek yang dilampirkan `x`, dan tidak menjadikannya Perilaku Tidak Ditentukan kecuali `x` dan Titik `y` ke objek yang diperuntukkan yang sama.
    ///
    /// Berbanding dengan [`add`], kaedah ini pada dasarnya menangguhkan syarat tinggal dalam objek yang diperuntukkan yang sama: [`add`] adalah Tingkah Laku Tidak Ditentukan segera ketika melintasi batas objek;`wrapping_add` menghasilkan penunjuk tetapi masih membawa kepada Tingkah Laku Tidak Terdefinisi jika penunjuk tidak dirujuk ketika berada di luar batas objek yang dilekatkannya.
    /// [`add`] dapat dioptimumkan dengan lebih baik dan dengan itu lebih disukai dalam kod sensitif prestasi.
    ///
    /// Pemeriksaan yang ditangguhkan hanya mempertimbangkan nilai penunjuk yang dereferensikan, bukan nilai perantaraan yang digunakan semasa pengiraan hasil akhir.
    /// Contohnya, `x.wrapping_add(o).wrapping_sub(o)` selalu sama dengan `x`.Dengan kata lain, membiarkan objek yang diperuntukkan dan memasukkannya semula kemudian dibenarkan.
    ///
    /// Sekiranya anda perlu melintasi batas objek, hantarkan penunjuk ke bilangan bulat dan lakukan aritmetik di sana.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // Berulang dengan menggunakan penunjuk mentah dalam kenaikan dua elemen
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Gelung ini mencetak "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Mengira ofset dari penunjuk menggunakan aritmetik pembungkus.
    /// (kemudahan untuk `.wrapping_offset ((dikira sebagai isize).wrapping_neg())`)
    ///
    /// `count` adalah dalam unit T;contohnya, `count` of 3 mewakili pointer ofset `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Operasi ini sendiri selalu selamat, tetapi menggunakan penunjuk yang dihasilkan tidak.
    ///
    /// Penunjuk yang dihasilkan tetap melekat pada objek yang diperuntukkan yang sama yang ditunjukkan oleh `self`.
    /// Mungkin *tidak* digunakan untuk mengakses objek yang diperuntukkan yang berbeza.Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
    ///
    /// Dengan kata lain, `let z = x.wrapping_sub((x as usize) - (y as usize))`*tidak* menjadikan `z` sama dengan `y` walaupun kita menganggap `T` mempunyai ukuran `1` dan tidak ada limpahan: `z` masih melekat pada objek yang dilampirkan `x`, dan tidak menjadikannya Perilaku Tidak Ditentukan kecuali `x` dan Titik `y` ke objek yang diperuntukkan yang sama.
    ///
    /// Berbanding dengan [`sub`], kaedah ini pada dasarnya melambatkan syarat tinggal dalam objek yang diperuntukkan yang sama: [`sub`] adalah Tingkah Laku Tidak Ditentukan segera ketika melintasi batas objek;`wrapping_sub` menghasilkan penunjuk tetapi masih membawa kepada Tingkah Laku Tidak Terdefinisi jika penunjuk tidak dirujuk ketika berada di luar batas objek yang dilekatkannya.
    /// [`sub`] dapat dioptimumkan dengan lebih baik dan dengan itu lebih disukai dalam kod sensitif prestasi.
    ///
    /// Pemeriksaan yang ditangguhkan hanya mempertimbangkan nilai penunjuk yang dereferensikan, bukan nilai perantaraan yang digunakan semasa pengiraan hasil akhir.
    /// Contohnya, `x.wrapping_add(o).wrapping_sub(o)` selalu sama dengan `x`.Dengan kata lain, membiarkan objek yang diperuntukkan dan memasukkannya semula kemudian dibenarkan.
    ///
    /// Sekiranya anda perlu melintasi batas objek, hantarkan penunjuk ke bilangan bulat dan lakukan aritmetik di sana.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // Berulang dengan menggunakan penunjuk mentah dalam kenaikan dua elemen (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Gelung ini mencetak "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Menetapkan nilai penunjuk ke `ptr`.
    ///
    /// Sekiranya `self` adalah penunjuk (fat) ke jenis yang tidak berukuran, operasi ini hanya akan mempengaruhi bahagian penunjuk, sedangkan untuk penunjuk (thin) ke jenis bersaiz, ini mempunyai kesan yang sama dengan tugas sederhana.
    ///
    /// Penunjuk yang dihasilkan akan mempunyai bukti `val`, iaitu, untuk penunjuk lemak, operasi ini semantik sama dengan membuat penunjuk lemak baru dengan nilai penunjuk data `val` tetapi metadata `self`.
    ///
    ///
    /// # Examples
    ///
    /// Fungsi ini terutamanya berguna untuk membenarkan aritmetik penunjuk berdasarkan bait pada petunjuk yang berpotensi gemuk:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // akan mencetak "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // KESELAMATAN: Sekiranya penunjuk nipis, operasi ini sama
        // kepada tugasan sederhana.
        // Sekiranya penunjuk lemak, dengan pelaksanaan susun atur penunjuk lemak semasa, bidang pertama penunjuk seperti itu selalu penunjuk data, yang juga diberikan.
        //
        unsafe { *thin = val };
        self
    }

    /// Membaca nilai dari `self` tanpa memindahkannya.
    /// Ini menjadikan memori di `self` tidak berubah.
    ///
    /// Lihat [`ptr::read`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk ``.
        unsafe { read(self) }
    }

    /// Melakukan bacaan nilai yang tidak stabil dari `self` tanpa memindahkannya.Ini menjadikan memori di `self` tidak berubah.
    ///
    /// Operasi volatile dimaksudkan untuk bertindak pada memori I/O, dan dijamin tidak akan dipinggirkan atau disusun semula oleh penyusun di seluruh operasi mudah alih yang lain.
    ///
    ///
    /// Lihat [`ptr::read_volatile`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Membaca nilai dari `self` tanpa memindahkannya.
    /// Ini menjadikan memori di `self` tidak berubah.
    ///
    /// Tidak seperti `read`, penunjuk mungkin tidak sejajar.
    ///
    /// Lihat [`ptr::read_unaligned`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Menyalin bait `count * size_of<T>` dari `self` hingga `dest`.
    /// Sumber dan tujuan mungkin bertindih.
    ///
    /// NOTE: ini mempunyai perintah argumen *sama* seperti [`ptr::copy`].
    ///
    /// Lihat [`ptr::copy`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Menyalin bait `count * size_of<T>` dari `self` hingga `dest`.
    /// Sumber dan tujuan mungkin *tidak* bertindih.
    ///
    /// NOTE: ini mempunyai perintah argumen *sama* seperti [`ptr::copy_nonoverlapping`].
    ///
    /// Lihat [`ptr::copy_nonoverlapping`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Menyalin bait `count * size_of<T>` dari `src` hingga `self`.
    /// Sumber dan tujuan mungkin bertindih.
    ///
    /// NOTE: ini mempunyai susunan argumen *bertentangan*[`ptr::copy`].
    ///
    /// Lihat [`ptr::copy`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Menyalin bait `count * size_of<T>` dari `src` hingga `self`.
    /// Sumber dan tujuan mungkin *tidak* bertindih.
    ///
    /// NOTE: ini mempunyai susunan argumen *bertentangan*[`ptr::copy_nonoverlapping`].
    ///
    /// Lihat [`ptr::copy_nonoverlapping`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Melaksanakan pemusnah (jika ada) dari nilai runcing.
    ///
    /// Lihat [`ptr::drop_in_place`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
    ///
    ///
    /// Lihat [`ptr::write`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `write`.
        unsafe { write(self, val) }
    }

    /// Meminta memset pada penunjuk yang ditentukan, menetapkan memori `count * size_of::<T>()` bait bermula dari `self` hingga `val`.
    ///
    ///
    /// Lihat [`ptr::write_bytes`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Melakukan penulisan lokasi memori yang tidak stabil dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
    ///
    /// Operasi volatile dimaksudkan untuk bertindak pada memori I/O, dan dijamin tidak akan dipinggirkan atau disusun semula oleh penyusun di seluruh operasi mudah alih yang lain.
    ///
    ///
    /// Lihat [`ptr::write_volatile`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
    ///
    ///
    /// Tidak seperti `write`, penunjuk mungkin tidak sejajar.
    ///
    /// Lihat [`ptr::write_unaligned`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Menggantikan nilai di `self` dengan `src`, mengembalikan nilai lama, tanpa menjatuhkan sama ada.
    ///
    ///
    /// Lihat [`ptr::replace`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `replace`.
        unsafe { replace(self, src) }
    }

    /// Tukar nilai di dua lokasi yang boleh berubah dengan jenis yang sama, tanpa membinasakan.
    /// Mereka mungkin bertindih, tidak seperti `mem::swap` yang setara.
    ///
    /// Lihat [`ptr::swap`] untuk masalah keselamatan dan contohnya.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `swap`.
        unsafe { swap(self, with) }
    }

    /// Menghitung ofset yang perlu diterapkan pada penunjuk untuk menjadikannya sejajar dengan `align`.
    ///
    /// Sekiranya tidak dapat menyelaraskan penunjuk, pelaksanaannya akan mengembalikan `usize::MAX`.
    /// Dibolehkan untuk pelaksanaan untuk *selalu* mengembalikan `usize::MAX`.
    /// Hanya prestasi algoritma anda yang bergantung pada mendapatkan ofset yang dapat digunakan di sini, bukan kebenarannya.
    ///
    /// Offset dinyatakan dalam jumlah elemen `T`, dan bukan bait.Nilai yang dikembalikan dapat digunakan dengan kaedah `wrapping_add`.
    ///
    /// Tidak ada jaminan sama sekali bahawa mengimbangi penunjuk tidak akan meluap atau melampaui peruntukan yang ditunjukkan oleh penunjuk.
    ///
    /// Terserah kepada pemanggil untuk memastikan bahawa pengimbangan yang dikembalikan adalah betul dalam semua istilah selain penjajaran.
    ///
    /// # Panics
    ///
    /// Fungsi panics jika `align` bukan power-of-two.
    ///
    /// # Examples
    ///
    /// Mengakses `u8` berdekatan sebagai `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // sementara penunjuk dapat diselaraskan melalui `offset`, ia akan menunjukkan di luar peruntukan
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // KESELAMATAN: `align` telah diperiksa untuk menjadi kekuatan 2 di atas
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Mengembalikan panjang kepingan mentah.
    ///
    /// Nilai yang dikembalikan adalah bilangan **elemen**, bukan bilangan bait.
    ///
    /// Fungsi ini selamat, walaupun irisan mentah tidak dapat dilemparkan ke rujukan slice kerana penunjuk tidak ada atau tidak sejajar.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // KESELAMATAN: ini selamat kerana `*const [T]` dan `FatPtr<T>` mempunyai susun atur yang sama.
            // Hanya `std` yang boleh membuat jaminan ini.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Mengembalikan penunjuk mentah ke penyangga slice.
    ///
    /// Ini sama dengan menghantar `self` ke `*mut T`, tetapi lebih selamat untuk jenis.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Mengembalikan penunjuk mentah ke elemen atau subslice, tanpa melakukan pemeriksaan batas.
    ///
    /// Memanggil kaedah ini dengan indeks luar batas atau ketika `self` tidak dapat dihentikan adalah *[tingkah laku tidak ditentukan]* walaupun penunjuk yang dihasilkan tidak digunakan.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // KESELAMATAN: pemanggil memastikan bahawa `self` tidak dapat ditanggalkan dan `index` tidak terhad.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Mengembalikan `None` jika penunjuk nol, atau mengembalikan potongan bersama ke nilai yang dibungkus dalam `Some`.
    /// Berbeza dengan [`as_ref`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mestilah [valid] untuk bacaan untuk `ptr.len() * mem::size_of::<T>()` banyak bait, dan mesti diselaraskan dengan betul.Ini bermaksud:
    ///
    ///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
    ///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.
    ///
    ///     * Penunjuk mesti diselaraskan walaupun untuk kepingan panjang sifar.
    ///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
    ///
    ///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran keseluruhan potongan `ptr.len() * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
    ///   Lihat dokumentasi keselamatan [`pointer::offset`].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Mengembalikan `None` jika penunjuk kosong, atau mengembalikan potongan unik ke nilai yang dibungkus dalam `Some`.
    /// Berbeza dengan [`as_mut`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa *sama ada* pointer adalah NULL *atau* semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mestilah [valid] untuk membaca dan menulis untuk `ptr.len() * mem::size_of::<T>()` banyak bait, dan mesti diselaraskan dengan betul.Ini bermaksud:
    ///
    ///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
    ///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.
    ///
    ///     * Penunjuk mesti diselaraskan walaupun untuk kepingan panjang sifar.
    ///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
    ///
    ///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran keseluruhan potongan `ptr.len() * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
    ///   Lihat dokumentasi keselamatan [`pointer::offset`].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Persamaan untuk petunjuk
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}