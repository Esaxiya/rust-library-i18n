//! Menguruskan memori secara manual melalui penunjuk mentah.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Banyak fungsi dalam modul ini menggunakan petunjuk mentah sebagai hujah dan membacanya atau menulis kepada mereka.Agar selamat, petunjuk ini mestilah *sah*.
//! Adakah penunjuk itu sah bergantung pada operasi yang digunakannya (baca atau tulis), dan sejauh mana memori yang diakses (iaitu, berapa bait read/written).
//! Sebilangan besar fungsi menggunakan `*mut T` dan `* const T` untuk mengakses hanya satu nilai, dalam hal ini dokumentasi menghilangkan ukuran dan secara implisit menganggapnya sebagai bait `size_of::<T>()`.
//!
//! Peraturan tepat untuk kesahan belum ditentukan.Jaminan yang diberikan pada tahap ini sangat minimum:
//!
//! * Penunjuk [null]*tidak* sah, bahkan untuk akses [size zero][zst].
//! * Agar penunjuk menjadi sah, perlu, tetapi tidak selalu mencukupi, agar penunjuk *tidak dapat diturunkan*: julat memori dari ukuran yang diberikan bermula dari penunjuk mesti semua berada dalam batas satu objek yang diperuntukkan.
//!
//! Perhatikan bahawa dalam Rust, setiap pemboleh ubah (stack-allocated) dianggap sebagai objek yang diperuntukkan secara berasingan.
//! * Walaupun untuk operasi [size zero][zst], penunjuk tidak boleh menunjuk ke memori yang dialihkan, iaitu, penyahpindahan menjadikan penunjuk tidak sah walaupun untuk operasi bersaiz sifar.
//! Walau bagaimanapun, menghantar sebarang integer non-zero *literal* ke pointer adalah sah untuk akses bersaiz sifar, walaupun terdapat beberapa memori yang terdapat di alamat tersebut dan akan dialihkan.
//! Ini sesuai dengan menulis alokasi anda sendiri: memperuntukkan objek bersaiz sifar tidaklah sukar.
//! Cara kanonik untuk mendapatkan penunjuk yang sah untuk akses bersaiz sifar adalah [`NonNull::dangling`].
//! * Semua akses yang dilakukan oleh fungsi dalam modul ini *tidak atomik* dalam arti [atomic operations] digunakan untuk menyegerakkan antara utas.
//! Ini bermaksud tingkah laku yang tidak ditentukan untuk melakukan dua akses serentak ke lokasi yang sama dari rangkaian yang berbeza kecuali kedua-dua akses hanya dibaca dari memori.
//! Perhatikan bahawa ini secara eksplisit merangkumi [`read_volatile`] dan [`write_volatile`]: Akses tidak stabil tidak dapat digunakan untuk penyegerakan antara benang.
//! * Hasil menghantar rujukan ke penunjuk berlaku selama objek yang mendasari masih hidup dan tidak ada rujukan (hanya penunjuk mentah) yang digunakan untuk mengakses memori yang sama.
//!
//! Aksioma ini, bersama dengan penggunaan [`offset`] yang berhati-hati untuk aritmetik penunjuk, cukup untuk melaksanakan banyak perkara berguna dalam kod yang tidak selamat.
//! Jaminan yang lebih kuat akhirnya akan diberikan, kerana peraturan [aliasing] sedang ditentukan.
//! Untuk maklumat lebih lanjut, lihat [book] dan juga bahagian dalam rujukan yang dikhaskan untuk [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Penunjuk mentah yang sah seperti yang ditentukan di atas tidak semestinya sejajar dengan betul (di mana penjajaran "proper" ditentukan oleh jenis pointee, iaitu, `*const T` mesti diselaraskan dengan `mem::align_of::<T>()`).
//! Namun, kebanyakan fungsi memerlukan argumen mereka diselaraskan dengan betul, dan secara eksplisit akan menyatakan keperluan ini dalam dokumentasi mereka.
//! Pengecualian yang ketara ialah [`read_unaligned`] dan [`write_unaligned`].
//!
//! Apabila fungsi memerlukan penjajaran yang tepat, ia melakukannya walaupun aksesnya mempunyai ukuran 0, iaitu, walaupun memori sebenarnya tidak disentuh.Pertimbangkan untuk menggunakan [`NonNull::dangling`] dalam kes sedemikian.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Melaksanakan pemusnah (jika ada) dari nilai runcing.
///
/// Ini semantik sama dengan memanggil [`ptr::read`] dan membuang hasilnya, tetapi mempunyai kelebihan berikut:
///
/// * *Wajib* menggunakan `drop_in_place` untuk menjatuhkan jenis yang tidak berukuran seperti objek trait, kerana ia tidak dapat dibaca ke tumpukan dan dijatuhkan secara normal.
///
/// * Adalah lebih baik kepada pengoptimum untuk melakukan ini lebih dari [`ptr::read`] ketika menjatuhkan memori yang diperuntukkan secara manual (contohnya, dalam pelaksanaan `Box`/`Rc`/`Vec`), kerana penyusun tidak perlu membuktikan bahawa pantas untuk menyalin salinan.
///
///
/// * Ini dapat digunakan untuk menjatuhkan data [pinned] ketika `T` bukan `repr(packed)` (data yang disematkan tidak boleh dipindahkan sebelum dijatuhkan).
///
/// Nilai yang tidak selaras tidak dapat dijatuhkan, ia mesti disalin ke lokasi yang diselaraskan terlebih dahulu menggunakan [`ptr::read_unaligned`].Untuk struktur yang dikemas, langkah ini dilakukan secara automatik oleh penyusun.
/// Ini bermaksud medan struktur yang dibungkus tidak diturunkan di tempatnya.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `to_drop` mestilah [valid] untuk membaca dan menulis.
///
/// * `to_drop` mesti diselaraskan dengan betul.
///
/// * Nilai yang ditunjukkan `to_drop` mestilah sah untuk penurunan, yang mungkin bermaksud mesti menyokong invarian tambahan, ini bergantung pada jenis.
///
/// Selain itu, jika `T` bukan [`Copy`], menggunakan nilai runcing setelah memanggil `drop_in_place` boleh menyebabkan tingkah laku tidak ditentukan.Perhatikan bahawa `*to_drop = foo` dikira sebagai penggunaan kerana ia akan menyebabkan nilainya jatuh lagi.
/// [`write()`] boleh digunakan untuk menimpa data tanpa menyebabkannya digugurkan.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Keluarkan item terakhir secara manual dari vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Dapatkan penunjuk mentah ke elemen terakhir dalam `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Pendekkan `v` untuk mengelakkan item terakhir dijatuhkan.
///     // Kami melakukannya terlebih dahulu, untuk mengelakkan masalah sekiranya `drop_in_place` di bawah panics.
///     v.set_len(1);
///     // Tanpa panggilan `drop_in_place`, item terakhir tidak akan jatuh, dan memori yang dikendalikannya akan bocor.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Pastikan item terakhir dijatuhkan.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Perhatikan bahawa penyusun melakukan salinan ini secara automatik ketika menjatuhkan struktur yang dikemas, iaitu, anda biasanya tidak perlu risau tentang masalah tersebut melainkan anda memanggil `drop_in_place` secara manual.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kod di sini tidak menjadi masalah, ini digantikan oleh gam penurunan sebenar oleh penyusun.
    //

    // KESELAMATAN: lihat komen di atas
    unsafe { drop_in_place(to_drop) }
}

/// Membuat penunjuk mentah kosong.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Membuat penunjuk mentah yang tidak dapat diubah.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Implan manual diperlukan untuk mengelakkan `T: Clone` terikat.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Implan manual diperlukan untuk mengelakkan `T: Copy` terikat.
impl<T> Copy for FatPtr<T> {}

/// Membentuk kepingan mentah dari penunjuk dan panjang.
///
/// Argumen `len` adalah bilangan **elemen**, bukan bilangan bait.
///
/// Fungsi ini selamat, tetapi sebenarnya menggunakan nilai kembali tidak selamat.
/// Lihat dokumentasi [`slice::from_raw_parts`] untuk keperluan keselamatan slice.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // buat penunjuk slice semasa memulakan dengan penunjuk ke elemen pertama
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // KESELAMATAN: Mengakses nilai dari kesatuan `Repr` selamat kerana * const [T]
        //
        // dan FatPtr mempunyai susun atur memori yang sama.Hanya std yang boleh membuat jaminan ini.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Melakukan fungsi yang sama seperti [`slice_from_raw_parts`], kecuali potongan yang dapat diubah mentah dikembalikan, berbanding potongan yang tidak berubah mentah.
///
///
/// Lihat dokumentasi [`slice_from_raw_parts`] untuk maklumat lebih lanjut.
///
/// Fungsi ini selamat, tetapi sebenarnya menggunakan nilai kembali tidak selamat.
/// Lihat dokumentasi [`slice::from_raw_parts_mut`] untuk keperluan keselamatan slice.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // berikan nilai pada indeks di slice
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // KESELAMATAN: Mengakses nilai dari kesatuan `Repr` selamat sejak * mut [T]
        // dan FatPtr mempunyai susun atur memori yang sama
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Tukar nilai di dua lokasi yang boleh berubah dengan jenis yang sama, tanpa membinasakan.
///
/// Tetapi untuk dua pengecualian berikut, fungsi ini semantik bersamaan dengan [`mem::swap`]:
///
///
/// * Ia beroperasi pada petunjuk mentah dan bukannya rujukan.
/// Apabila rujukan tersedia, [`mem::swap`] harus diutamakan.
///
/// * Kedua-dua nilai runcing mungkin bertindih.
/// Sekiranya nilainya bertindih, kawasan memori yang bertindih dari `x` akan digunakan.
/// Ini ditunjukkan dalam contoh kedua di bawah.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * Kedua-dua `x` dan `y` mestilah [valid] untuk membaca dan menulis.
///
/// * Kedua-dua `x` dan `y` mesti diselaraskan dengan betul.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah tidak NULL dan diselaraskan dengan betul.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Menukar dua kawasan yang tidak bertindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // ini adalah `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // ini adalah `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Menukar dua kawasan yang bertindih:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // ini adalah `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // ini adalah `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeks `1..3` kepingan bertindih antara `x` dan `y`.
///     // Hasil yang munasabah adalah `[2, 3]`, sehingga indeks `0..3` adalah `[1, 2, 3]` (sepadan dengan `y` sebelum `swap`);atau untuk menjadi `[0, 1]` sehingga indeks `1..4` adalah `[0, 1, 2]` (sepadan dengan `x` sebelum `swap`).
/////
///     // Pelaksanaan ini ditakrifkan untuk membuat pilihan terakhir.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Beri diri kita sedikit ruang awal untuk dikerjakan.
    // Kita tidak perlu bimbang tentang penurunan: `MaybeUninit` tidak melakukan apa-apa ketika dijatuhkan.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Lakukan pertukaran KESELAMATAN: pemanggil mesti menjamin bahawa `x` dan `y` sah untuk menulis dan diselaraskan dengan betul.
    // `tmp` tidak boleh bertindih sama ada `x` atau `y` kerana `tmp` hanya diperuntukkan pada timbunan sebagai objek yang diperuntukkan terpisah.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` dan `y` mungkin bertindih
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Tukar bait `count * size_of::<T>()` antara dua kawasan memori bermula pada `x` dan `y`.
/// Kedua-dua wilayah tersebut mesti *tidak* bertindih.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * Kedua-dua `x` dan `y` mestilah [valid] untuk kedua-dua bacaan dan penulisan `kiraan *
///   saiz: :<T>() `bait.
///
/// * Kedua-dua `x` dan `y` mesti diselaraskan dengan betul.
///
/// * Kawasan memori bermula pada `x` dengan ukuran `kiraan *
///   saiz: :<T>() `byte mesti *tidak* bertindih dengan kawasan memori bermula pada `y` dengan ukuran yang sama.
///
/// Perhatikan bahawa walaupun ukuran yang disalin secara berkesan (`hitung * size_of: :<T>()`) adalah `0`, penunjuk mestilah bukan NULL dan diselaraskan dengan betul.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KESELAMATAN: pemanggil mesti menjamin bahawa `x` dan `y`
    // sah untuk tulisan dan sejajar dengan betul.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Untuk jenis yang lebih kecil daripada pengoptimuman blok di bawah, tukar terus untuk mengelakkan codegen yang tidak menentu.
    //
    if mem::size_of::<T>() < 32 {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `x` dan `y` adalah sah
        // untuk menulis, diselaraskan dengan betul, dan tidak bertindih.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pendekatan di sini adalah dengan menggunakan simd untuk menukar x&y dengan cekap.
    // Pengujian menunjukkan bahawa menukar 32 bait atau 64 bait pada satu masa adalah paling berkesan untuk pemproses Intel Haswell E.
    // LLVM lebih mampu mengoptimumkan jika kita memberikan struktur #[repr(simd)], walaupun kita tidak menggunakan struktur ini secara langsung.
    //
    //
    // FIXME repr(simd) rosak pada emscripten dan redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Gelung melalui x&y, menyalinnya `Block` pada satu masa Pengoptimum harus melepaskan gelung sepenuhnya untuk kebanyakan jenis NB
    // Kami tidak dapat menggunakan loop untuk kerana `range` memanggil `mem::swap` secara berulang
    //
    let mut i = 0;
    while i + block_size <= len {
        // Buat beberapa memori yang tidak diinisialkan sebagai ruang calar Menyatakan `t` di sini mengelakkan menjajarkan timbunan apabila gelung ini tidak digunakan
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KESELAMATAN: Seperti `i < len`, dan sebagai pemanggil mesti menjamin bahawa `x` dan `y` adalah sah
        // untuk `len` bait, `x + i` dan `y + i` mestilah alamat yang sah, yang memenuhi kontrak keselamatan untuk `add`.
        //
        // Juga, pemanggil mesti menjamin bahawa `x` dan `y` berlaku untuk tulisan, diselaraskan dengan betul, dan tidak bertindih, yang memenuhi kontrak keselamatan untuk `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Tukar sekumpulan bait x&y, menggunakan t sebagai penyangga sementara Ini harus dioptimumkan menjadi operasi SIMD yang cekap jika ada
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Tukar bait yang tinggal
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // KESELAMATAN: lihat komen keselamatan sebelumnya.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Pindahkan `src` ke `dst` runcing, mengembalikan nilai `dst` sebelumnya.
///
/// Nilai tidak dijatuhkan.
///
/// Fungsi ini semantik bersamaan dengan [`mem::replace`] kecuali ia berfungsi pada petunjuk mentah dan bukannya rujukan.
/// Apabila rujukan tersedia, [`mem::replace`] harus diutamakan.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `dst` mestilah [valid] untuk membaca dan menulis.
///
/// * `dst` mesti diselaraskan dengan betul.
///
/// * `dst` mesti menunjukkan nilai `T` yang diinisialisasi dengan betul.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` akan mempunyai kesan yang sama tanpa memerlukan blok yang tidak selamat.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // KESELAMATAN: pemanggil mesti menjamin bahawa `dst` adalah sah
    // dilampirkan ke rujukan yang dapat diubah (berlaku untuk penulisan, diselaraskan, diinisialisasi), dan tidak dapat bertindih `src` kerana `dst` mesti menunjukkan objek yang diperuntukkan.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // tidak boleh bertindih
    }
    src
}

/// Membaca nilai dari `src` tanpa memindahkannya.Ini menjadikan memori di `src` tidak berubah.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `src` mesti [valid] untuk bacaan.
///
/// * `src` mesti diselaraskan dengan betul.Gunakan [`read_unaligned`] jika ini tidak berlaku.
///
/// * `src` mesti menunjukkan nilai `T` yang diinisialisasi dengan betul.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Laksanakan [`mem::swap`] secara manual:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Buat salinan sedikit demi sedikit nilai pada `a` di `tmp`.
///         let tmp = ptr::read(a);
///
///         // Keluar pada titik ini (baik dengan mengembalikan secara eksplisit atau dengan memanggil fungsi yang panics) akan menyebabkan nilai dalam `tmp` turun sementara nilai yang sama masih dirujuk oleh `a`.
///         // Ini boleh mencetuskan tingkah laku yang tidak ditentukan jika `T` bukan `Copy`.
/////
/////
///
///         // Buat salinan sedikit demi sedikit nilai pada `b` di `a`.
///         // Ini selamat kerana rujukan yang tidak dapat diubah tidak boleh menjadi alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Seperti di atas, keluar dari sini boleh mencetuskan tingkah laku yang tidak ditentukan kerana nilai yang sama dirujuk oleh `a` dan `b`.
/////
///
///         // Pindahkan `tmp` ke `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` telah dipindahkan (`write` mengambil alih argumen keduanya), jadi tidak ada yang dijatuhkan secara tersirat di sini.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Pemilikan Nilai yang Dikembalikan
///
/// `read` membuat salinan sedikit demi sedikit `T`, tidak kira sama ada `T` adalah [`Copy`].
/// Sekiranya `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai pada `*src` boleh melanggar keselamatan memori.
/// Perhatikan bahawa menetapkan ke `*src` dikira sebagai penggunaan kerana ia akan berusaha menjatuhkan nilai pada `* src`.
///
/// [`write()`] boleh digunakan untuk menimpa data tanpa menyebabkannya digugurkan.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` kini menunjukkan memori asas yang sama dengan `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Menetapkan ke `s2` menyebabkan nilai asalnya jatuh.
///     // Di luar titik ini, `s` tidak boleh digunakan lagi, kerana memori yang mendasari telah dibebaskan.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Menugaskan ke `s` akan menyebabkan nilai lama dijatuhkan lagi, mengakibatkan tingkah laku yang tidak ditentukan.
/////
///     // s= String::from("bar");//RALAT
///
///     // `ptr::write` boleh digunakan untuk menimpa nilai tanpa menjatuhkannya.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KESELAMATAN: pemanggil mesti menjamin bahawa `src` sah untuk dibaca.
    // `src` tidak dapat bertindih `tmp` kerana `tmp` hanya diperuntukkan pada timbunan sebagai objek yang diperuntukkan secara berasingan.
    //
    //
    // Juga, kerana kami baru saja menulis nilai yang sah ke `tmp`, dijamin akan diinisialisasi dengan betul.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Membaca nilai dari `src` tanpa memindahkannya.Ini menjadikan memori di `src` tidak berubah.
///
/// Tidak seperti [`read`], `read_unaligned` berfungsi dengan penunjuk yang tidak selaras.
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `src` mesti [valid] untuk bacaan.
///
/// * `src` mesti menunjukkan nilai `T` yang diinisialisasi dengan betul.
///
/// Seperti [`read`], `read_unaligned` membuat salinan sedikit demi sedikit `T`, tidak kira sama ada `T` adalah [`Copy`].
/// Sekiranya `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai pada `*src` boleh [violate memory safety][read-ownership].
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Pada struktur `packed`
///
/// Buat masa ini mustahil untuk membuat penunjuk mentah ke medan struktur yang tidak selaras.
///
/// Mencuba membuat penunjuk mentah ke medan struktur `unaligned` dengan ungkapan seperti `&packed.unaligned as *const FieldType` membuat rujukan tidak selaras perantaraan sebelum menukarnya menjadi penunjuk mentah.
///
/// Bahawa rujukan ini bersifat sementara dan segera dilancarkan tidak penting kerana penyusun selalu mengharapkan rujukan diselaraskan dengan betul.
/// Akibatnya, penggunaan `&packed.unaligned as *const FieldType` menyebabkan* tingkah laku yang tidak ditentukan langsung dalam program anda.
///
/// Contoh perkara yang tidak boleh dilakukan dan bagaimana ini berkaitan dengan `read_unaligned` adalah:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Di sini kita cuba mengambil alamat bilangan bulat 32-bit yang tidak selaras.
///     let unaligned =
///         // Rujukan sementara yang tidak selaras dibuat di sini yang menghasilkan tingkah laku yang tidak ditentukan tanpa mengira sama ada rujukan itu digunakan atau tidak.
/////
///         &packed.unaligned
///         // Menghantar penunjuk mentah tidak membantu;kesalahan itu sudah berlaku.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Walau bagaimanapun, mengakses medan tidak selaras secara langsung dengan contoh `packed.unaligned` adalah selamat.
///
///
///
///
///
///
// FIXME: Kemas kini dokumen berdasarkan hasil RFC #2582 dan rakan.
/// # Examples
///
/// Baca nilai penggunaan dari penyangga bait:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // KESELAMATAN: pemanggil mesti menjamin bahawa `src` sah untuk dibaca.
    // `src` tidak dapat bertindih `tmp` kerana `tmp` hanya diperuntukkan pada timbunan sebagai objek yang diperuntukkan secara berasingan.
    //
    //
    // Juga, kerana kami baru saja menulis nilai yang sah ke `tmp`, dijamin akan diinisialisasi dengan betul.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
///
/// `write` tidak menjatuhkan kandungan `dst`.
/// Ini selamat, tetapi mungkin membocorkan peruntukan atau sumber daya, jadi berhati-hati agar tidak menimpa objek yang harus dijatuhkan.
///
///
/// Selain itu, ia tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjukkan oleh `dst`.
///
/// Ini sesuai untuk menginisialisasi memori yang tidak diinisialisasi, atau menimpa memori yang sebelumnya berasal dari [`read`].
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `dst` mesti [valid] untuk menulis.
///
/// * `dst` mesti diselaraskan dengan betul.Gunakan [`write_unaligned`] jika ini tidak berlaku.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Laksanakan [`mem::swap`] secara manual:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Buat salinan sedikit demi sedikit nilai pada `a` di `tmp`.
///         let tmp = ptr::read(a);
///
///         // Keluar pada titik ini (baik dengan mengembalikan secara eksplisit atau dengan memanggil fungsi yang panics) akan menyebabkan nilai dalam `tmp` turun sementara nilai yang sama masih dirujuk oleh `a`.
///         // Ini boleh mencetuskan tingkah laku yang tidak ditentukan jika `T` bukan `Copy`.
/////
/////
///
///         // Buat salinan sedikit demi sedikit nilai pada `b` di `a`.
///         // Ini selamat kerana rujukan yang tidak dapat diubah tidak boleh menjadi alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Seperti di atas, keluar dari sini boleh mencetuskan tingkah laku yang tidak ditentukan kerana nilai yang sama dirujuk oleh `a` dan `b`.
/////
///
///         // Pindahkan `tmp` ke `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` telah dipindahkan (`write` mengambil alih argumen keduanya), jadi tidak ada yang dijatuhkan secara tersirat di sini.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Kami memanggil pihak intrinsik secara langsung untuk mengelakkan panggilan fungsi dalam kod yang dihasilkan kerana `intrinsics::copy_nonoverlapping` adalah fungsi pembungkus.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // KESELAMATAN: pemanggil mesti menjamin bahawa `dst` sah untuk menulis.
    // `dst` tidak dapat bertindih `src` kerana pemanggil mempunyai akses yang dapat diubah ke `dst` sementara `src` dimiliki oleh fungsi ini.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Menimpa lokasi memori dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
///
/// Tidak seperti [`write()`], penunjuk mungkin tidak sejajar.
///
/// `write_unaligned` tidak menjatuhkan kandungan `dst`.Ini selamat, tetapi mungkin membocorkan peruntukan atau sumber daya, jadi berhati-hati agar tidak menimpa objek yang harus dijatuhkan.
///
/// Selain itu, ia tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjukkan oleh `dst`.
///
/// Ini sesuai untuk menginisialisasi memori yang belum dimulakan, atau menimpa memori yang sebelumnya telah dibaca dengan [`read_unaligned`].
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `dst` mesti [valid] untuk menulis.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL.
///
/// [valid]: self#safety
///
/// ## Pada struktur `packed`
///
/// Buat masa ini mustahil untuk membuat penunjuk mentah ke medan struktur yang tidak selaras.
///
/// Mencuba membuat penunjuk mentah ke medan struktur `unaligned` dengan ungkapan seperti `&packed.unaligned as *const FieldType` membuat rujukan tidak selaras perantaraan sebelum menukarnya menjadi penunjuk mentah.
///
/// Bahawa rujukan ini bersifat sementara dan segera dilancarkan tidak penting kerana penyusun selalu mengharapkan rujukan diselaraskan dengan betul.
/// Akibatnya, penggunaan `&packed.unaligned as *const FieldType` menyebabkan* tingkah laku yang tidak ditentukan langsung dalam program anda.
///
/// Contoh perkara yang tidak boleh dilakukan dan bagaimana ini berkaitan dengan `write_unaligned` adalah:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Di sini kita cuba mengambil alamat bilangan bulat 32-bit yang tidak selaras.
///     let unaligned =
///         // Rujukan sementara yang tidak selaras dibuat di sini yang menghasilkan tingkah laku yang tidak ditentukan tanpa mengira sama ada rujukan itu digunakan atau tidak.
/////
///         &mut packed.unaligned
///         // Menghantar penunjuk mentah tidak membantu;kesalahan itu sudah berlaku.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Walau bagaimanapun, mengakses medan tidak selaras secara langsung dengan contoh `packed.unaligned` adalah selamat.
///
///
///
///
///
///
///
///
///
// FIXME: Kemas kini dokumen berdasarkan hasil RFC #2582 dan rakan.
/// # Examples
///
/// Tuliskan nilai penggunaan ke penyangga bait:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // KESELAMATAN: pemanggil mesti menjamin bahawa `dst` sah untuk menulis.
    // `dst` tidak dapat bertindih `src` kerana pemanggil mempunyai akses yang dapat diubah ke `dst` sementara `src` dimiliki oleh fungsi ini.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Kami memanggil secara langsung hakiki untuk mengelakkan panggilan fungsi dalam kod yang dihasilkan.
        intrinsics::forget(src);
    }
}

/// Melakukan bacaan nilai yang tidak stabil dari `src` tanpa memindahkannya.Ini menjadikan memori di `src` tidak berubah.
///
/// Operasi volatile dimaksudkan untuk bertindak pada memori I/O, dan dijamin tidak akan dipinggirkan atau disusun semula oleh penyusun di seluruh operasi mudah alih yang lain.
///
/// # Notes
///
/// Rust pada masa ini tidak mempunyai model memori yang ditentukan dengan ketat dan formal, jadi semantik yang tepat mengenai maksud "volatile" di sini boleh berubah dari masa ke masa.
/// Yang dikatakan, semantik hampir selalu hampir sama dengan [C11's definition of volatile][c11].
///
/// Penyusun tidak boleh mengubah susunan relatif atau jumlah operasi memori yang tidak menentu.
/// Walau bagaimanapun, operasi memori yang tidak menentu pada jenis bersaiz sifar (contohnya, jika jenis berukuran sifar diteruskan ke `read_volatile`) adalah tidak ada dan mungkin diabaikan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `src` mesti [valid] untuk bacaan.
///
/// * `src` mesti diselaraskan dengan betul.
///
/// * `src` mesti menunjukkan nilai `T` yang diinisialisasi dengan betul.
///
/// Seperti [`read`], `read_volatile` membuat salinan sedikit demi sedikit `T`, tidak kira sama ada `T` adalah [`Copy`].
/// Sekiranya `T` bukan [`Copy`], menggunakan nilai yang dikembalikan dan nilai pada `*src` boleh [violate memory safety][read-ownership].
/// Walau bagaimanapun, menyimpan jenis bukan [`Salin`] dalam memori tidak stabil hampir pasti tidak betul.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Sama seperti di C, sama ada operasi tidak stabil sama sekali tidak berkaitan dengan soalan yang melibatkan akses serentak dari pelbagai utas.Akses turun naik berperilaku sama seperti akses bukan atom dalam hal itu.
///
/// Khususnya, perlumbaan antara `read_volatile` dan operasi tulis ke lokasi yang sama adalah tingkah laku yang tidak ditentukan.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Tidak panik untuk memastikan impak codegen lebih kecil.
        abort();
    }
    // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Melakukan penulisan lokasi memori yang tidak stabil dengan nilai yang diberikan tanpa membaca atau menjatuhkan nilai lama.
///
/// Operasi volatile dimaksudkan untuk bertindak pada memori I/O, dan dijamin tidak akan dipinggirkan atau disusun semula oleh penyusun di seluruh operasi mudah alih yang lain.
///
/// `write_volatile` tidak menjatuhkan kandungan `dst`.Ini selamat, tetapi mungkin membocorkan peruntukan atau sumber daya, jadi berhati-hati agar tidak menimpa objek yang harus dijatuhkan.
///
/// Selain itu, ia tidak menjatuhkan `src`.Secara semantik, `src` dipindahkan ke lokasi yang ditunjukkan oleh `dst`.
///
/// # Notes
///
/// Rust pada masa ini tidak mempunyai model memori yang ditentukan dengan ketat dan formal, jadi semantik yang tepat mengenai maksud "volatile" di sini boleh berubah dari masa ke masa.
/// Yang dikatakan, semantik hampir selalu hampir sama dengan [C11's definition of volatile][c11].
///
/// Penyusun tidak boleh mengubah susunan relatif atau jumlah operasi memori yang tidak menentu.
/// Walau bagaimanapun, operasi memori yang tidak menentu pada jenis bersaiz sifar (contohnya, jika jenis bersaiz sifar diteruskan ke `write_volatile`) adalah tidak ada dan boleh diabaikan.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `dst` mesti [valid] untuk menulis.
///
/// * `dst` mesti diselaraskan dengan betul.
///
/// Perhatikan bahawa walaupun `T` mempunyai ukuran `0`, penunjuk mestilah bukan NULL dan sejajar dengan betul.
///
/// [valid]: self#safety
///
/// Sama seperti di C, sama ada operasi tidak stabil sama sekali tidak berkaitan dengan soalan yang melibatkan akses serentak dari pelbagai utas.Akses turun naik berperilaku sama seperti akses bukan atom dalam hal itu.
///
/// Khususnya, perlumbaan antara `write_volatile` dan operasi lain (membaca atau menulis) di lokasi yang sama adalah tingkah laku yang tidak ditentukan.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Tidak panik untuk memastikan impak codegen lebih kecil.
        abort();
    }
    // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Sejajarkan penunjuk `p`.
///
/// Hitung offset (dari segi elemen langkah `stride`) yang harus diterapkan pada penunjuk `p` sehingga penunjuk `p` akan sejajar dengan `a`.
///
/// Note: Pelaksanaan ini telah disesuaikan dengan teliti agar tidak panic.Ini adalah UB untuk panic.
/// Satu-satunya perubahan nyata yang boleh dibuat di sini adalah perubahan `INV_TABLE_MOD_16` dan pemalar yang berkaitan.
///
/// Sekiranya kita pernah memutuskan untuk memungkinkan memanggil intrinsik dengan `a` yang bukan kekuatan dua, mungkin lebih bijak untuk hanya menukar kepada pelaksanaan naif daripada berusaha menyesuaikannya untuk mengakomodasi perubahan itu.
///
///
/// Sebarang pertanyaan pergi ke@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Penggunaan langsung intrinsik ini meningkatkan codegen dengan ketara pada tahap opt <=
    // 1, di mana versi kaedah operasi ini tidak sebaris.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Hitung songsang modular darab `x` modulo `m`.
    ///
    /// Pelaksanaan ini disesuaikan untuk `align_offset` dan mempunyai prasyarat berikut:
    ///
    /// * `m` adalah kekuatan dua;
    /// * `x < m`; (jika `x ≥ m`, masukkan `x % m` sebagai gantinya)
    ///
    /// Pelaksanaan fungsi ini tidak boleh panic.Pernah.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Jadual terbalik modular multiplatif modulo 2⁴=16.
        ///
        /// Perhatikan, bahawa jadual ini tidak mengandungi nilai di mana kebalikannya tidak wujud (iaitu, untuk `0⁻¹ mod 16`, `2⁻¹ mod 16`, dll.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo yang dimaksudkan untuk `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // KESELAMATAN: `m` diperlukan sebagai kekuatan dua, oleh itu bukan sifar.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Kami mengulangi "up" menggunakan formula berikut:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // hingga 2²ⁿ ≥ m.Maka kita boleh mengurangkan `m` yang kita inginkan dengan mengambil hasil `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Perhatikan, bahawa kami menggunakan operasi pembungkus di sini dengan sengaja-formula asal menggunakan misalnya, pengurangan `mod n`.
                // Sebaiknya lakukan `mod usize::MAX` sebagai gantinya, kerana kita tetap mengambil hasilnya `mod n` pada akhirnya.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KESELAMATAN: `a` adalah kuasa dua, oleh itu tidak sifar.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kes dapat dikira dengan lebih mudah melalui `-p (mod a)`, tetapi hal itu menghalang kemampuan LLVM untuk memilih arahan seperti `lea`.Sebaliknya kami mengira
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // yang mengedarkan operasi di sekitar penanggung beban, tetapi menipu `and` cukup untuk LLVM dapat menggunakan pelbagai pengoptimuman yang diketahui.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Sudah diselaraskan.Yay!
        return 0;
    } else if stride == 0 {
        // Sekiranya penunjuk tidak sejajar, dan elemennya berukuran sifar, maka tidak ada jumlah elemen yang akan menyelaraskan penunjuk.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // KESELAMATAN: a adalah kekuatan-dua dan bukan sifar.stride==0 kes dikendalikan di atas.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // KESELAMATAN: gcdpow mempunyai batas atas yang paling banyak bilangan bit dalam penggunaan.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // KESELAMATAN: gcd selalu lebih besar atau sama dengan 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // branch ini menyelesaikan persamaan kesesuaian linear berikut:
        //
        // ` p + so = 0 mod a `
        //
        // `p` berikut adalah nilai penunjuk, `s`, langkah `T`, pengimbangan `o` dalam `T`s, dan `a`, penjajaran yang diminta.
        //
        // Dengan `g = gcd(a, s)`, dan keadaan di atas yang menegaskan bahawa `p` juga boleh dibahagi dengan `g`, kita dapat menandakan `a' = a/g`, `s' = s/g`, `p' = p/g`, maka ini menjadi setara dengan:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Istilah pertama ialah "the relative alignment of `p` to `a`" (dibahagi dengan `g`), istilah kedua adalah "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (sekali lagi dibahagi dengan `g`).
        //
        // Pembahagian dengan `g` diperlukan untuk menjadikan terbalik dengan baik jika `a` dan `s` tidak bersamaan.
        //
        // Selanjutnya, hasil yang dihasilkan oleh penyelesaian ini bukanlah "minimal", jadi perlu mengambil hasilnya `o mod lcm(s, a)`.Kita boleh menggantikan `lcm(s, a)` dengan `a'` sahaja.
        //
        //
        //
        //
        //

        // KESELAMATAN: `gcdpow` mempunyai batas atas tidak lebih besar daripada bilangan 0-bit yang tertinggal di `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // KESELAMATAN: `a2` bukan sifar.Mengalihkan `a` dengan `gcdpow` tidak dapat mengalihkan keluar dari bit yang ditetapkan
        // dalam `a` (yang mana satu tepat).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KESELAMATAN: `gcdpow` mempunyai batas atas tidak lebih besar daripada bilangan 0-bit yang tertinggal di `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KESELAMATAN: `gcdpow` mempunyai batas atas tidak lebih besar daripada bilangan 0-bit yang tertinggal di
        // `a`.
        // Tambahan pula, pengurangan tidak dapat meluap, kerana `a2 = a >> gcdpow` akan selalu lebih besar daripada `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // KESELAMATAN: `a2` adalah kekuatan dua, seperti yang terbukti di atas.`s2` sama sekali kurang daripada `a2`
        // kerana `(s % a) >> gcdpow` sama sekali kurang daripada `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Tidak dapat diselaraskan sama sekali.
    usize::MAX
}

/// Membandingkan petunjuk mentah untuk persamaan.
///
/// Ini sama dengan menggunakan pengendali `==`, tetapi kurang generik:
/// hujah-hujah itu mestilah petunjuk mentah `*const T`, bukan apa-apa yang menerapkan `PartialEq`.
///
/// Ini dapat digunakan untuk membandingkan rujukan `&T` (yang memaksakan `*const T` secara tersirat) dengan alamatnya daripada membandingkan nilai yang mereka tunjukkan (yang dilakukan oleh pelaksanaan `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Potongan juga dibandingkan dengan panjangnya (penunjuk lemak):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits juga dibandingkan dengan pelaksanaannya:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Penunjuk mempunyai alamat yang sama.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objek mempunyai alamat yang sama, tetapi `Trait` mempunyai implementasi yang berbeza.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Menukar rujukan ke `*const u8` membandingkan dengan alamat.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash penunjuk mentah.
///
/// Ini dapat digunakan untuk mencantumkan rujukan `&T` (yang bersangkutan dengan `*const T` secara tersirat) dengan alamatnya daripada nilai yang ditunjukkan (itulah yang dilakukan oleh pelaksanaan `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Memberi petunjuk untuk fungsi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemain perantaraan sebagai penggunaan diperlukan untuk AVR
                // supaya ruang alamat penunjuk fungsi sumber dikekalkan dalam penunjuk fungsi akhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pemain perantaraan sebagai penggunaan diperlukan untuk AVR
                // supaya ruang alamat penunjuk fungsi sumber dikekalkan dalam penunjuk fungsi akhir.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Tiada fungsi variadik dengan 0 parameter
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Buat penunjuk mentah `const` ke tempat, tanpa membuat rujukan perantaraan.
///
/// Membuat rujukan dengan `&`/`&mut` hanya dibenarkan jika penunjuk diselaraskan dengan betul dan menunjukkan data yang diinisialisasi.
/// Untuk kes-kes di mana syarat-syarat tersebut tidak berlaku, penunjuk mentah harus digunakan.
/// Walau bagaimanapun, `&expr as *const _` membuat rujukan sebelum menghantarnya ke penunjuk mentah, dan rujukan itu tertakluk kepada peraturan yang sama seperti semua rujukan lain.
///
/// Makro ini dapat membuat penunjuk mentah *tanpa* membuat rujukan terlebih dahulu.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` akan membuat rujukan yang tidak selaras, dan dengan itu menjadi Tingkah Laku Tidak Ditentukan!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Buat penunjuk mentah `mut` ke tempat, tanpa membuat rujukan perantaraan.
///
/// Membuat rujukan dengan `&`/`&mut` hanya dibenarkan jika penunjuk diselaraskan dengan betul dan menunjukkan data yang diinisialisasi.
/// Untuk kes-kes di mana syarat-syarat tersebut tidak berlaku, penunjuk mentah harus digunakan.
/// Walau bagaimanapun, `&mut expr as *mut _` membuat rujukan sebelum menghantarnya ke penunjuk mentah, dan rujukan itu tertakluk kepada peraturan yang sama seperti semua rujukan lain.
///
/// Makro ini dapat membuat penunjuk mentah *tanpa* membuat rujukan terlebih dahulu.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` akan membuat rujukan yang tidak selaras, dan dengan itu menjadi Tingkah Laku Tidak Ditentukan!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` memaksa menyalin medan daripada membuat rujukan.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}