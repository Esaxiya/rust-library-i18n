use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` tetapi tidak sifar dan kovarian.
///
/// Ini sering kali digunakan dengan betul semasa membina struktur data menggunakan penunjuk mentah, tetapi akhirnya lebih berbahaya untuk digunakan kerana sifat tambahannya.Sekiranya anda tidak pasti sama ada anda mesti menggunakan `NonNull<T>`, gunakan `*mut T` sahaja!
///
/// Tidak seperti `*mut T`, penunjuk mestilah tidak sia-sia, walaupun penunjuk tidak pernah ditinggalkan.Ini supaya enum dapat menggunakan nilai terlarang ini sebagai diskriminan-`Option<NonNull<T>>` mempunyai ukuran yang sama dengan `* mut T`.
/// Walau bagaimanapun, penunjuk masih boleh menjuntai jika tidak ditangguhkan.
///
/// Tidak seperti `*mut T`, `NonNull<T>` dipilih untuk menjadi kovarian berbanding `T`.Ini memungkinkan untuk menggunakan `NonNull<T>` ketika membangun jenis kovarian, tetapi memperkenalkan risiko tidak masuk akal jika digunakan pada jenis yang seharusnya tidak benar-benar kovarian.
/// (Pilihan sebaliknya dibuat untuk `*mut T` walaupun secara teknikalnya ketidaksabaran hanya disebabkan oleh memanggil fungsi yang tidak selamat.)
///
/// Kovarians betul untuk kebanyakan pengambilan yang selamat, seperti `Box`, `Rc`, `Arc`, `Vec`, dan `LinkedList`.Ini berlaku kerana mereka menyediakan API awam yang mengikuti peraturan XOR boleh ubah bersama Rust.
///
/// Sekiranya jenis anda tidak dapat menjadi kovarian dengan selamat, anda mesti memastikannya mengandungi beberapa medan tambahan untuk menyediakan invariance.Selalunya bidang ini akan menjadi jenis [`PhantomData`] seperti `PhantomData<Cell<T>>` atau `PhantomData<&'a mut T>`.
///
/// Perhatikan bahawa `NonNull<T>` mempunyai contoh `From` untuk `&T`.Walau bagaimanapun, ini tidak mengubah fakta bahawa bermutasi melalui (penunjuk yang berasal dari a) rujukan bersama adalah tingkah laku yang tidak ditentukan kecuali mutasi berlaku di dalam [`UnsafeCell<T>`].Perkara yang sama berlaku untuk membuat rujukan yang boleh berubah dari rujukan bersama.
///
/// Semasa menggunakan instance `From` ini tanpa `UnsafeCell<T>`, adalah tanggungjawab anda untuk memastikan bahawa `as_mut` tidak pernah dipanggil, dan `as_ptr` tidak pernah digunakan untuk mutasi.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointer bukan `Send` kerana data yang mereka rujuk mungkin diasingkan.
// NB, ini tidak perlu, tetapi harus memberikan mesej ralat yang lebih baik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointer bukan `Sync` kerana data yang mereka rujuk mungkin diasingkan.
// NB, ini tidak perlu, tetapi harus memberikan mesej ralat yang lebih baik.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Membuat `NonNull` baru yang menggantung, tetapi diselaraskan dengan baik.
    ///
    /// Ini berguna untuk memulakan jenis yang diperuntukkan dengan malas, seperti `Vec::new`.
    ///
    /// Perhatikan bahawa nilai penunjuk berpotensi mewakili penunjuk yang sah ke `T`, yang bermaksud ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang diperuntukkan dengan malas mesti mengesan inisialisasi dengan cara lain.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // KESELAMATAN: mem::align_of() mengembalikan penggunaan bukan sifar yang kemudian dilemparkan
        // kepada a * mut T.
        // Oleh itu, `ptr` tidak sia-sia dan syarat untuk memanggil new_unchecked() dipatuhi.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Mengembalikan rujukan yang dikongsi kepada nilai.Berbeza dengan [`as_ref`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Mengembalikan rujukan unik pada nilai.Berbeza dengan [`as_mut`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Membuat `NonNull` baru.
    ///
    /// # Safety
    ///
    /// `ptr` mesti tidak batal.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `ptr` tidak sah.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Membuat `NonNull` baru jika `ptr` tidak kosong.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // KESELAMATAN: Penunjuk sudah diperiksa dan tidak kosong
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Melakukan fungsi yang sama dengan [`std::ptr::from_raw_parts`], kecuali bahawa penunjuk `NonNull` dikembalikan, berbanding penunjuk `*const` mentah.
    ///
    ///
    /// Lihat dokumentasi [`std::ptr::from_raw_parts`] untuk maklumat lebih lanjut.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // KESELAMATAN: Hasil `ptr::from::raw_parts_mut` tidak sia-sia kerana `data_address` adalah.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Menguraikan penunjuk (mungkin lebar) ke dalam komponen alamat dan metadata.
    ///
    /// Penunjuk kemudian boleh dibina semula dengan [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Memperoleh penunjuk `*mut` yang mendasari.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Mengembalikan rujukan bersama ke nilai.Sekiranya nilainya mungkin tidak dimulakan, [`as_uninit_ref`] mesti digunakan sebagai gantinya.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Penunjuk mesti menunjukkan contoh `T` yang diinisialisasi.
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    /// (Bahagian tentang diinisialisasi belum diputuskan sepenuhnya, tetapi sampai sekarang, satu-satunya pendekatan yang selamat adalah memastikan mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // keperluan untuk rujukan.
        unsafe { &*self.as_ptr() }
    }

    /// Mengembalikan rujukan unik untuk nilai.Sekiranya nilainya mungkin tidak dimulakan, [`as_uninit_mut`] mesti digunakan sebagai gantinya.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mesti diselaraskan dengan betul.
    ///
    /// * Ia mestilah "dereferencable" dalam pengertian yang ditentukan dalam [the module documentation].
    ///
    /// * Penunjuk mesti menunjukkan contoh `T` yang diinisialisasi.
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    /// (Bahagian tentang diinisialisasi belum diputuskan sepenuhnya, tetapi sampai sekarang, satu-satunya pendekatan yang selamat adalah memastikan mereka benar-benar diinisialisasi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` memenuhi semua
        // syarat untuk rujukan yang boleh berubah.
        unsafe { &mut *self.as_ptr() }
    }

    /// Menghantar penunjuk jenis lain.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KESELAMATAN: `self` adalah penunjuk `NonNull` yang semestinya tidak kosong
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Membuat potongan mentah yang tidak kosong dari penunjuk nipis dan panjang.
    ///
    /// Argumen `len` adalah bilangan **elemen**, bukan bilangan bait.
    ///
    /// Fungsi ini selamat, tetapi menurunkan nilai kembali tidak selamat.
    /// Lihat dokumentasi [`slice::from_raw_parts`] untuk keperluan keselamatan slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // buat penunjuk slice semasa memulakan dengan penunjuk ke elemen pertama
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Perhatikan bahawa contoh ini menunjukkan penggunaan kaedah ini secara artifisial, tetapi `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KESELAMATAN: `data` adalah penunjuk `NonNull` yang semestinya tidak kosong
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Mengembalikan panjang kepingan mentah yang tidak kosong.
    ///
    /// Nilai yang dikembalikan adalah bilangan **elemen**, bukan bilangan bait.
    ///
    /// Fungsi ini selamat, walaupun irisan mentah yang tidak kosong tidak dapat dihapus dari potongan kerana penunjuk tidak mempunyai alamat yang sah.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Mengembalikan penunjuk yang tidak kosong ke penyangga slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // KESELAMATAN: Kami tahu `self` tidak kosong.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Mengembalikan penunjuk mentah ke penyangga slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Mengembalikan rujukan bersama ke sepotong nilai yang mungkin tidak dimulakan.Berbeza dengan [`as_ref`], ini tidak memerlukan nilainya harus diinisialisasi.
    ///
    /// Untuk rakan sejawat yang boleh diubah, lihat [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mestilah [valid] untuk bacaan untuk `ptr.len() * mem::size_of::<T>()` banyak bait, dan mesti diselaraskan dengan betul.Ini bermaksud:
    ///
    ///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
    ///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.
    ///
    ///     * Penunjuk mesti diselaraskan walaupun untuk kepingan panjang sifar.
    ///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
    ///
    ///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran keseluruhan potongan `ptr.len() * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
    ///   Lihat dokumentasi keselamatan [`pointer::offset`].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, untuk sepanjang hayat ini, memori yang ditunjuk oleh penunjuk tidak boleh dimutasi (kecuali di dalam `UnsafeCell`).
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Mengembalikan rujukan unik kepada potongan nilai yang mungkin tidak dimulakan.Berbeza dengan [`as_mut`], ini tidak memerlukan nilai harus diinisialisasi.
    ///
    /// Untuk rakan kongsi yang sama, lihat [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Semasa memanggil kaedah ini, anda harus memastikan bahawa semua perkara berikut adalah benar:
    ///
    /// * Penunjuk mestilah [valid] untuk membaca dan menulis untuk `ptr.len() * mem::size_of::<T>()` banyak bait, dan mesti diselaraskan dengan betul.Ini bermaksud:
    ///
    ///     * Keseluruhan rentang memori slice ini mesti terdapat dalam satu objek yang diperuntukkan!
    ///       Potongan tidak boleh menjangkau pelbagai objek yang diperuntukkan.
    ///
    ///     * Penunjuk mesti diselaraskan walaupun untuk kepingan panjang sifar.
    ///     Salah satu sebabnya adalah bahawa pengoptimuman susun atur enum mungkin bergantung pada rujukan (termasuk potongan panjang) yang diselaraskan dan tidak kosong untuk membezakannya dari data lain.
    ///
    ///     Anda boleh mendapatkan penunjuk yang dapat digunakan sebagai `data` untuk potongan panjang sifar menggunakan [`NonNull::dangling()`].
    ///
    /// * Ukuran keseluruhan potongan `ptr.len() * mem::size_of::<T>()` tidak boleh lebih besar daripada `isize::MAX`.
    ///   Lihat dokumentasi keselamatan [`pointer::offset`].
    ///
    /// * Anda mesti melaksanakan peraturan pengasingan Rust, kerana `'a` seumur hidup yang dikembalikan dipilih secara sewenang-wenang dan tidak semestinya menggambarkan jangka hayat sebenar data.
    ///   Khususnya, sepanjang hayat ini, ingatan yang ditunjuk oleh penunjuk tidak boleh diakses (dibaca atau ditulis) melalui penunjuk lain.
    ///
    /// Ini berlaku walaupun hasil kaedah ini tidak digunakan!
    ///
    /// Lihat juga [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ini selamat kerana `memory` sah untuk membaca dan menulis untuk `memory.len()` banyak bait.
    /// // Perhatikan bahawa memanggil `memory.as_mut()` tidak dibenarkan di sini kerana kandungannya mungkin tidak dimulakan.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Mengembalikan penunjuk mentah ke elemen atau subslice, tanpa melakukan pemeriksaan batas.
    ///
    /// Memanggil kaedah ini dengan indeks luar batas atau ketika `self` tidak dapat dihentikan adalah *[tingkah laku tidak ditentukan]* walaupun penunjuk yang dihasilkan tidak digunakan.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // KESELAMATAN: pemanggil memastikan bahawa `self` tidak dapat ditanggalkan dan `index` tidak terhad.
        // Akibatnya, penunjuk yang dihasilkan tidak boleh NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // KESELAMATAN: Penunjuk unik tidak boleh sia-sia, jadi syarat untuk
        // new_unchecked() dihormati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // KESELAMATAN: Rujukan yang tidak dapat diubah tidak boleh dibatalkan.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // KESELAMATAN: Rujukan tidak boleh dibatalkan, jadi syarat untuk
        // new_unchecked() dihormati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}