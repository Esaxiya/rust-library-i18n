//! Sokongan Panic untuk libcore
//!
//! Perpustakaan inti tidak dapat menentukan panik, tetapi ia *menyatakan* panik.
//! Ini bermaksud bahawa fungsi di dalam libcore diizinkan untuk panic, tetapi untuk menjadi berguna crate hulu mesti menentukan panik untuk digunakan.
//! Antara muka semasa untuk panik adalah:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Definisi ini memungkinkan untuk panik dengan sebarang mesej umum, tetapi tidak memungkinkan untuk gagal dengan nilai `Box<Any>`.
//! (`PanicInfo` hanya berisi `&(dyn Any + Send)`, yang mana kami mengisi nilai dummy di `PanicInfo: : internal_constructor`.) Sebabnya ialah libcore tidak dibenarkan untuk mengalokasikan.
//!
//!
//! Modul ini mengandungi beberapa fungsi panik lain, tetapi ini hanyalah item lang yang diperlukan untuk penyusun.Semua panics disalurkan melalui fungsi satu ini.
//! Simbol sebenar dinyatakan melalui atribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Pelaksanaan asas makro `panic!` libcore ketika tiada pemformatan digunakan.
#[cold]
// jangan sekali-kali sebaris kecuali panic_immediate_abort untuk mengelakkan kod kembung di laman panggilan sebanyak mungkin
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // diperlukan oleh codegen untuk panic pada overflow dan terminal `Assert` MIR lain
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Gunakan Arguments::new_v1 dan bukannya format_args! ("{}", Expr) untuk berpotensi mengurangkan overhead ukuran.
    // Format_args!makro menggunakan Str's Display trait untuk menulis expr, yang memanggil Formatter::pad, yang mesti menampung pemotongan tali dan padding (walaupun tidak digunakan di sini).
    //
    // Menggunakan Arguments::new_v1 mungkin membolehkan penyusun menghilangkan Formatter::pad dari perduaan output, menjimatkan hingga beberapa kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // diperlukan untuk panics yang dinilai secara konst
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // diperlukan oleh codegen untuk panic pada akses OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Pelaksanaan asas makro `panic!` libcore semasa pemformatan digunakan.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // CATATAN Fungsi ini tidak pernah melintasi sempadan FFI;ia adalah panggilan Rust-to-Rust yang diselesaikan ke fungsi `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // KESELAMATAN: `panic_impl` didefinisikan dalam kod Rust selamat dan dengan itu selamat dipanggil.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Fungsi dalaman untuk makro `assert_eq!` dan `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}