//! Adaptasi Rust algoritma Grisu3 yang dijelaskan dalam "Mencetak Nombor Titik Terapung Dengan Pantas dan Tepat dengan Bilangan" [^ 1].
//! Ia menggunakan kira-kira 1KB jadual yang dikira, dan pada gilirannya, sangat cepat untuk kebanyakan input.
//!
//! [^1]: Florian Loitsch.2010. Mencetak nombor terapung dengan cepat dan
//!   tepat dengan nombor bulat.TANDATANGAN Tidak.45, 6 (Jun 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// lihat komen di `format_shortest_opt` untuk rasionalnya.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Diberi `x > 0`, mengembalikan `(k, 10^k)` sehingga `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Pelaksanaan mod terpendek untuk Grisu.
///
/// Ia mengembalikan `None` apabila akan mengembalikan representasi yang tidak tepat.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // kita memerlukan sekurang-kurangnya tiga bit ketepatan tambahan

    // mulakan dengan nilai normal dengan eksponen bersama
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // cari sebarang `cached = 10^minusk` sehingga `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // kerana `plus` dinormalisasi, ini bermaksud `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // memandangkan pilihan kami `ALPHA` dan `GAMMA`, ini meletakkan `plus * cached` ke `[4, 2^32)`.
    //
    // jelas sekali diinginkan untuk memaksimumkan `GAMMA - ALPHA`, sehingga kita tidak memerlukan banyak kekuatan 10, tetapi ada beberapa pertimbangan:
    //
    //
    // 1. kami mahu mengekalkan `floor(plus * cached)` dalam `u32` kerana ia memerlukan pembahagian yang mahal.
    //    (ini tidak dapat dielakkan, selebihnya diperlukan untuk anggaran ketepatan.)
    // 2.
    // selebihnya `floor(plus * cached)` berulang kali dikalikan dengan 10, dan tidak boleh melimpah.
    //
    // yang pertama memberikan `64 + GAMMA <= 32`, sementara yang kedua memberikan `10 * 2^-ALPHA <= 2^64`;
    // -60 dan -32 adalah julat maksimum dengan kekangan ini, dan V8 juga menggunakannya.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.ini memberikan ralat maksimum 1 ulp (terbukti dari Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-julat minus sebenar
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // di atas `minus`, `v` dan `plus` dihitung *dihitung*(ralat <1 ulp).
    // kerana kita tidak tahu kesalahannya positif atau negatif, kita menggunakan dua jarak yang sama jaraknya dan mempunyai kesalahan maksimum 2 ulps.
    //
    // "unsafe region" adalah selang liberal yang pada awalnya kita hasilkan.
    // "safe region" adalah selang konservatif yang hanya kita terima.
    // kita mulakan dengan repr yang betul di kawasan yang tidak selamat, dan cuba cari repr yang paling dekat dengan `v` yang juga berada di kawasan yang selamat.
    // jika tidak dapat, kita berputus asa.
    //
    let plus1 = plus.f + 1;
    // biarkan plus0 = plus.f, 1;//hanya untuk penjelasan, biarkan minus0 = minus.f + 1;//hanya untuk penjelasan
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // eksponen bersama

    // bahagikan `plus1` menjadi bahagian tidak terpecah dan pecahan.
    // bahagian integral dijamin muat dalam u32, kerana kuasa cache menjamin `plus < 2^32` dan `plus.f` yang dinormalisasi selalu kurang dari `2^64 - 2^4` kerana keperluan ketepatan.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // hitung `10^max_kappa` terbesar tidak lebih daripada `plus1` (dengan demikian `plus1 < 10^(max_kappa+1)`).
    // ini adalah had atas `kappa` di bawah.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: jika `k` adalah bilangan bulat terbesar
    // `0 <= y mod 10^k <= y - x`,              maka `V = floor(y / 10^k) * 10^k` berada dalam `[x, y]` dan salah satu representasi terpendek (dengan bilangan digit signifikan minimum) dalam julat tersebut.
    //
    //
    // cari panjang digit `kappa` antara `(minus1, plus1)` mengikut Teorem 6.2.
    // Teorem 6.2 dapat diadopsi untuk mengecualikan `x` dengan memerlukan `y mod 10^k < y - x` sebagai gantinya.
    // (mis., `x` =32000, `y` =32777; `kappa` =2 kerana `y mod 10 ^ 3=777 <y, x=777`.) algoritma bergantung pada fasa pengesahan kemudian untuk mengecualikan `y`.
    //
    let delta1 = plus1 - minus1;
    // biarkan delta1int=(delta1>> e) sebagai penggunaan;//hanya untuk penjelasan
    let delta1frac = delta1 & ((1 << e) - 1);

    // membuat bahagian tidak terpisahkan, sambil memeriksa ketepatan pada setiap langkah.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // digit belum diberikan
    loop {
        // kita selalu mempunyai sekurang-kurangnya satu digit untuk diberikan, sebagai invarian `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ia mengikuti bahawa `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // bahagikan `remainder` dengan `10^kappa`.kedua-duanya diberi skala oleh `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; kami telah menemui `kappa` yang betul.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa kembali ke eksponen bersama
            return round_and_weed(
                // KESELAMATAN: kami memulakan memori di atas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // putus gelung apabila kita telah memberikan semua digit integral.
        // bilangan digit yang tepat ialah `max_kappa + 1` sebagai `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // memulihkan invarian
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // membuat bahagian pecahan, sambil memeriksa ketepatan pada setiap langkah.
    // kali ini kita bergantung pada pendaraban berulang, kerana pembahagian akan kehilangan ketepatan.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // digit seterusnya mestilah penting kerana kami telah mengujinya sebelum memecahkan invarian, di mana `m = max_kappa + 1` (#digit di bahagian tidak terpisahkan):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // tidak akan meluap, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // bahagikan `remainder` dengan `10^kappa`.
        // kedua-duanya diskala oleh `2^e / 10^kappa`, jadi yang terakhir tersirat di sini.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // pembahagi tersirat
            return round_and_weed(
                // KESELAMATAN: kami memulakan memori di atas.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // memulihkan invarian
        kappa -= 1;
        remainder = r;
    }

    // kami telah menghasilkan semua digit penting `plus1`, tetapi tidak pasti apakah itu digit yang optimum.
    // sebagai contoh, jika `minus1` adalah 3.14153 ... dan `plus1` adalah 3.14158 ..., terdapat 5 perwakilan terpendek yang berbeza dari 3.14154 hingga 3.14158 tetapi kami hanya mempunyai yang paling hebat.
    // kita mesti menurunkan digit terakhir secara berturut-turut dan memeriksa apakah ini adalah repr yang optimum.
    // terdapat paling banyak 9 calon (..1 hingga ..9), jadi ini agak pantas.(Fasa "rounding")
    //
    // fungsi memeriksa apakah repr "optimal" ini benar-benar berada dalam rentang ulp, dan juga, kemungkinan bahawa repr "second-to-optimal" sebenarnya dapat optimum kerana kesalahan pembulatan.
    // dalam kedua-dua kes ini mengembalikan `None`.
    // (Fasa "weeding")
    //
    // semua argumen di sini dikira berdasarkan nilai biasa (tetapi tersirat) `k`, sehingga:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (dan juga, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (dan juga, `threshold > plus1v` dari invarian sebelumnya)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // menghasilkan dua penghampiran `v` (sebenarnya `plus1 - v`) dalam jarak 1.5.
        // perwakilan yang dihasilkan harus menjadi perwakilan yang paling dekat dengan kedua-duanya.
        //
        // di sini `plus1 - v` digunakan kerana pengiraan dilakukan berkenaan dengan `plus1` untuk mengelakkan overflow/underflow (oleh itu nama-nama yang nampaknya bertukar).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // turunkan digit terakhir dan berhenti pada perwakilan terdekat dengan `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // kami bekerjasama dengan digit `w(n)`, yang pada mulanya sama dengan `plus1 - plus1 % 10^kappa`.setelah menjalankan badan gelung `n` kali, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // kami menetapkan `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (dengan itu `bakinya= plus1w(0)`) untuk memudahkan pemeriksaan.
            // ambil perhatian bahawa `plus1w(n)` sentiasa meningkat.
            //
            // kita mempunyai tiga syarat untuk ditamatkan.mana-mana dari mereka akan membuat gelung tidak dapat dilanjutkan, tetapi kita kemudian mempunyai sekurang-kurangnya satu perwakilan yang sah yang paling hampir dengan `v + 1 ulp`.
            // kami akan menunjukkannya sebagai TC1 hingga TC3 untuk jangka masa pendek.
            //
            // TC1: `w(n) <= v + 1 ulp`, iaitu, ini adalah teguran terakhir yang boleh menjadi yang paling dekat.
            // ini bersamaan dengan `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // digabungkan dengan TC2 (yang memeriksa apakah `w(n+1)` is valid), ini menghalang kemungkinan limpahan pada pengiraan `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, iaitu, teguran seterusnya pasti tidak membulat ke `v`.
            // ini bersamaan dengan `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // sebelah kiri boleh melimpah, tetapi kita tahu `threshold > plus1v`, jadi jika TC1 salah, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` dan kita boleh menguji dengan selamat jika `threshold - plus1w(n) < 10^kappa` sebagai gantinya.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, iaitu, repr seterusnya adalah
            // tidak lebih dekat dengan `v + 1 ulp` daripada repr semasa.
            // diberi `z(n) = plus1v_up - plus1w(n)`, ini menjadi `abs(z(n)) <= abs(z(n+1))`.sekali lagi dengan anggapan bahawa TC1 adalah palsu, kita mempunyai `z(n) > 0`.kita mempunyai dua kes yang perlu dipertimbangkan:
            //
            // - apabila `z(n+1) >= 0`: TC3 menjadi `z(n) <= z(n+1)`.
            // kerana `plus1w(n)` semakin meningkat, `z(n)` semestinya akan menurun dan ini jelas salah.
            // - apabila `z(n+1) < 0`:
            //   - TC3a: prasyarat ialah `plus1v_up < plus1w(n) + 10^kappa`.dengan anggapan TC2 adalah salah, `threshold >= plus1w(n) + 10^kappa` sehingga tidak dapat melimpah.
            //   - TC3b: TC3 menjadi `z(n) <= -z(n+1)`, iaitu, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 yang ditolak memberikan `plus1v_up > plus1w(n)`, jadi ia tidak dapat meluap atau mengalir ketika digabungkan dengan TC3a.
            //
            // akibatnya, kita harus berhenti ketika `TC1 || TC2 || (TC3a && TC3b)`.berikut sama dengan yang terbalik, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr terpendek tidak boleh berakhir dengan `0`
                plus1w += ten_kappa;
            }
        }

        // periksa sama ada perwakilan ini juga merupakan perwakilan terdekat dengan `v - 1 ulp`.
        //
        // ini sama dengan syarat penamatan untuk `v + 1 ulp`, dengan semua `plus1v_up` digantikan oleh `plus1v_down` sebagai gantinya.
        // analisis limpahan berlaku.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // sekarang kita mempunyai perwakilan terdekat dengan `v` antara `plus1` dan `minus1`.
        // ini terlalu liberal, jadi kami menolak sebarang `w(n)` bukan antara `plus0` dan `minus0`, iaitu, `plus1 - plus1w(n) <= minus0` atau `plus1 - plus1w(n) >= plus0`.
        // kami menggunakan fakta bahawa `threshold = plus1 - minus1` dan `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Pelaksanaan mod terpendek untuk Grisu dengan Dragon fallback.
///
/// Ini mesti digunakan untuk kebanyakan kes.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KESELAMATAN: Pemeriksa pinjaman tidak cukup pintar untuk membolehkan kita menggunakan `buf`
    // di branch kedua, jadi kami mencederakan seumur hidup di sini.
    // Tetapi kami hanya menggunakan semula `buf` jika `format_shortest_opt` mengembalikan `None` jadi ini tidak mengapa.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Pelaksanaan mod yang tepat dan tetap untuk Grisu.
///
/// Ia mengembalikan `None` apabila akan mengembalikan representasi yang tidak tepat.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // kita memerlukan sekurang-kurangnya tiga bit ketepatan tambahan
    assert!(!buf.is_empty());

    // menormalkan dan skala `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // bahagikan `v` menjadi bahagian tidak terpecah dan pecahan.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // kedua `v` lama dan `v` baru (skala oleh `10^-k`) mempunyai ralat <1 ulp (Theorem 5.1).
    // kerana kita tidak tahu kesalahan itu positif atau negatif, kita menggunakan dua jarak yang sama jaraknya dan mempunyai kesalahan maksimum 2 ulps (sama dengan kes terpendek).
    //
    //
    // tujuannya adalah untuk mencari rangkaian digit yang tepat bulat yang biasa bagi `v - 1 ulp` dan `v + 1 ulp`, supaya kita yakin sepenuhnya.
    // jika ini tidak mungkin, kami tidak tahu yang mana satu output yang betul untuk `v`, jadi kami menyerah dan mundur.
    //
    // `err` didefinisikan sebagai `1 ulp * 2^e` di sini (sama dengan ulp di `vfrac`), dan kami akan menskalakannya setiap kali `v` mendapat skala.
    //
    //
    //
    let mut err = 1;

    // hitung `10^max_kappa` terbesar tidak lebih daripada `v` (dengan demikian `v < 10^(max_kappa+1)`).
    // ini adalah had atas `kappa` di bawah.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jika kita bekerja dengan batasan digit terakhir, kita perlu memendekkan penyangga sebelum rendering sebenar untuk mengelakkan pembulatan berganda.
    //
    // ambil perhatian bahawa kita harus memperbesar penyangga lagi apabila pembulatan berlaku!
    let len = if exp <= limit {
        // Alamak, kita tidak dapat menghasilkan *satu* digit.
        // ini mungkin berlaku apabila, katakanlah, kita mempunyai sesuatu seperti 9.5 dan ia dibundarkan kepada 10.
        //
        // pada prinsipnya kita dapat memanggil `possibly_round` dengan segera dengan penyangga kosong, tetapi penskalaan `max_ten_kappa << e` dengan 10 dapat mengakibatkan limpahan.
        //
        // dengan demikian kita menjadi ceroboh di sini dan memperluas julat kesalahan dengan faktor 10.
        // ini akan meningkatkan kadar negatif palsu, tetapi hanya sangat,*sangat* sedikit;
        // ia hanya dapat dilihat dengan ketara apabila mantissa lebih besar daripada 60 bit.
        //
        // KESELAMATAN: `len=0`, jadi kewajiban menginisialisasi memori ini adalah remeh.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // menjadikan bahagian tidak terpisahkan.
    // kesalahannya pecahan sepenuhnya, jadi kami tidak perlu menyemaknya di bahagian ini.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // digit belum diberikan
    loop {
        // kita selalu mempunyai sekurang-kurangnya satu digit untuk menjadikan invarian:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ia mengikuti bahawa `remainder = vint % 10^(kappa+1)`)
        //
        //

        // bahagikan `remainder` dengan `10^kappa`.kedua-duanya diberi skala oleh `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // adakah penyangga penuh?jalankan hantaran bulat dengan baki.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // KESELAMATAN: kami telah menginisialisasi `len` banyak bait.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // putus gelung apabila kita telah memberikan semua digit integral.
        // bilangan digit yang tepat ialah `max_kappa + 1` sebagai `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // memulihkan invarian
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // membuat bahagian pecahan.
    //
    // pada prinsipnya kita dapat meneruskan angka terakhir yang tersedia dan memeriksa ketepatannya.
    // malangnya kami bekerja dengan bilangan bulat berukuran hingga, jadi kami memerlukan beberapa kriteria untuk mengesan limpahan.
    // V8 menggunakan `remainder > err`, yang menjadi palsu apabila digit signifikan `i` pertama `v - 1 ulp` dan `v` berbeza.
    // namun ini menolak terlalu banyak input yang sah.
    //
    // kerana fasa kemudian mempunyai pengesanan limpahan yang betul, kami menggunakan kriteria yang lebih ketat:
    // kita teruskan sehingga `err` melebihi `10^kappa / 2`, sehingga julat antara `v - 1 ulp` dan `v + 1 ulp` pasti mengandungi dua atau lebih representasi bulat.
    //
    // ini sama dengan dua perbandingan pertama dari `possibly_round`, untuk rujukan.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarian, di mana `m = max_kappa + 1` (#digit di bahagian tidak terpisahkan):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // tidak akan meluap, `2^e * 10 < 2^64`
        err *= 10; // tidak akan meluap, `err * 10 < 2^e * 5 < 2^64`

        // bahagikan `remainder` dengan `10^kappa`.
        // kedua-duanya diskala oleh `2^e / 10^kappa`, jadi yang terakhir tersirat di sini.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // adakah penyangga penuh?jalankan hantaran bulat dengan baki.
        if i == len {
            // KESELAMATAN: kami telah menginisialisasi `len` banyak bait.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // memulihkan invarian
        remainder = r;
    }

    // pengiraan selanjutnya tidak berguna (`possibly_round` pasti gagal), jadi kami menyerah.
    return None;

    // kami telah menghasilkan semua digit `v` yang diminta, yang juga harus sama dengan digit `v - 1 ulp` yang sepadan.
    // sekarang kita periksa sama ada terdapat representasi unik yang dikongsi oleh `v - 1 ulp` dan `v + 1 ulp`;ini sama dengan digit yang dihasilkan, atau versi digit yang dibundarkan.
    //
    // jika julat mengandungi beberapa perwakilan dengan panjang yang sama, kita tidak pasti dan seharusnya mengembalikan `None` sebagai gantinya.
    //
    // semua argumen di sini dikira berdasarkan nilai biasa (tetapi tersirat) `k`, sehingga:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KESELAMATAN: `len` byte `buf` pertama mesti dimulakan.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (untuk rujukan, garis putus-putus menunjukkan nilai tepat untuk kemungkinan perwakilan dalam bilangan digit yang diberikan.)
        //
        //
        // ralat terlalu besar sehingga terdapat sekurang-kurangnya tiga kemungkinan perwakilan antara `v - 1 ulp` dan `v + 1 ulp`.
        // kita tidak dapat menentukan mana yang betul.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // sebenarnya, ulp 1/2 cukup untuk memperkenalkan dua kemungkinan representasi.
        // (ingat bahawa kita memerlukan perwakilan unik untuk `v - 1 ulp` dan `v + 1 ulp`.) ini tidak akan meluap, kerana `ulp < ten_kappa` dari pemeriksaan pertama.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // jika `v + 1 ulp` lebih dekat dengan perwakilan bulat ke bawah (yang sudah ada di `buf`), maka kita dapat kembali dengan selamat.
        // perhatikan bahawa `v - 1 ulp`*boleh* kurang daripada perwakilan semasa, tetapi sebagai `1 ulp < 10^kappa / 2`, syarat ini sudah cukup:
        // jarak antara `v - 1 ulp` dan perwakilan semasa tidak boleh melebihi `10^kappa / 2`.
        //
        // keadaannya sama dengan `remainder + ulp < 10^kappa / 2`.
        // kerana ini boleh melimpah dengan mudah, periksa terlebih dahulu apakah `remainder < 10^kappa / 2`.
        // kami telah mengesahkan bahawa `ulp < 10^kappa / 2`, selagi `10^kappa` tidak meluap, pemeriksaan kedua adalah baik.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // KESELAMATAN: pemanggil kami memulakan memori itu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------selebihnya------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // sebaliknya, jika `v - 1 ulp` lebih dekat dengan perwakilan bulat-bulat, kita harus membundarkan dan kembali.
        // untuk alasan yang sama kita tidak perlu memeriksa `v + 1 ulp`.
        //
        // keadaannya sama dengan `remainder - ulp >= 10^kappa / 2`.
        // sekali lagi kita memeriksa sama ada `remainder > ulp` (perhatikan bahawa ini bukan `remainder >= ulp`, kerana `10^kappa` tidak pernah sifar).
        //
        // perhatikan juga bahawa `remainder - ulp <= 10^kappa`, jadi pemeriksaan kedua tidak berlebihan.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KESELAMATAN: pemanggil kami mesti memulakan memori itu.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // hanya tambahkan digit tambahan apabila kami diminta ketepatan tetap.
                // kita juga perlu memastikan bahawa, jika penyangga asal kosong, digit tambahan hanya dapat ditambahkan apabila `exp == limit` (casing edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KESELAMATAN: kami dan pemanggil kami memulakan ingatan itu.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // jika tidak, kita akan ditakdirkan (iaitu, beberapa nilai antara `v - 1 ulp` dan `v + 1 ulp` membulatkan ke bawah dan yang lain membundarkan) dan menyerah.
        //
        None
    }
}

/// Pelaksanaan mod yang tepat dan tetap untuk Grisu dengan Dragon fallback.
///
/// Ini mesti digunakan untuk kebanyakan kes.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KESELAMATAN: Pemeriksa pinjaman tidak cukup pintar untuk membolehkan kita menggunakan `buf`
    // di branch kedua, jadi kami mencederakan seumur hidup di sini.
    // Tetapi kami hanya menggunakan semula `buf` jika `format_exact_opt` mengembalikan `None` jadi ini tidak mengapa.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}