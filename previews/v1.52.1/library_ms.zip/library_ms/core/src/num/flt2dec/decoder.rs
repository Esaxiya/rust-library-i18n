//! Menyahkod nilai titik terapung ke bahagian individu dan julat ralat.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Nilai terhingga yang tidak didekodkan, seperti:
///
/// - Nilai asalnya sama dengan `mant * 2^exp`.
///
/// - Sebilangan nombor dari `(mant - minus)*2^exp` hingga `(mant + plus)* 2^exp` akan bulat ke nilai asalnya.
/// Julatnya hanya termasuk apabila `inclusive` adalah `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantissa yang bersisik.
    pub mant: u64,
    /// Julat ralat yang lebih rendah.
    pub minus: u64,
    /// Julat ralat atas.
    pub plus: u64,
    /// Eksponen bersama di pangkalan 2.
    pub exp: i16,
    /// Benar apabila julat ralat adalah inklusif.
    ///
    /// Dalam IEEE 754, ini berlaku semasa mantissa yang asli sama rata.
    pub inclusive: bool,
}

/// Nilai tidak ditandatangani.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infiniti, sama ada positif atau negatif.
    Infinite,
    /// Sifar, sama ada positif atau negatif.
    Zero,
    /// Nombor terhingga dengan medan penyahkodan selanjutnya.
    Finite(Decoded),
}

/// Jenis titik terapung yang boleh `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Nilai normal normal minimum.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Mengembalikan tanda (benar apabila negatif) dan nilai `FullDecoded` dari nombor titik terapung yang diberikan.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // jiran: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode selalu menjaga eksponen, sehingga mantissa diperkecil untuk subnormal.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // jiran: (maksmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // di mana maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // jiran: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}