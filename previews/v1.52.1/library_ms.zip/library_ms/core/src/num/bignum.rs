//! Pelaksanaan (bignum) nombor tepat sewenang-wenangnya.
//!
//! Ini dirancang untuk mengelakkan peruntukan timbunan dengan mengorbankan memori timbunan.
//! Jenis bignum yang paling banyak digunakan, `Big32x40`, dihadkan oleh 32 × 40=1,280 bit dan akan mengambil maksimum 160 bait memori timbunan.
//! Ini lebih dari cukup untuk melancarkan semua kemungkinan nilai `f64` terhingga.
//!
//! Pada prinsipnya mungkin ada beberapa jenis bignum untuk input yang berbeza, tetapi kami tidak melakukannya untuk mengelakkan kod kod.
//!
//! Setiap bignum masih dikesan untuk penggunaan sebenarnya, jadi biasanya tidak menjadi masalah.
//!

// Modul ini hanya untuk dec2flt dan flt2dec, dan hanya umum kerana coretests.
// Ia tidak bertujuan untuk sentiasa stabil.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Operasi aritmetik yang diperlukan oleh bignum.
pub trait FullOps: Sized {
    /// Mengembalikan `(carry', v')` sehingga `carry' * 2^W + v' = self + other + carry`, di mana `W` adalah bilangan bit dalam `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Mengembalikan `(carry', v')` sehingga `carry'*2^W + v' = self* other + carry`, di mana `W` adalah bilangan bit dalam `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Mengembalikan `(carry', v')` sehingga `carry'*2^W + v' = self* other + other2 + carry`, di mana `W` adalah bilangan bit dalam `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Mengembalikan `(quo, rem)` sedemikian rupa sehingga `borrow *2^W + self = quo* other + rem` dan `0 <= rem < other`, di mana `W` adalah bilangan bit dalam `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Ini tidak boleh meluap;outputnya antara `0` dan `2 * 2^nbits - 1`.
                    // FIXME: adakah LLVM akan mengoptimumkannya menjadi ADC atau serupa?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ini tidak boleh meluap;
                    // outputnya antara `0` dan `2^nbits * (2^nbits - 1)`.
                    // FIXME: adakah LLVM akan mengoptimumkannya menjadi ADC atau serupa?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Ini tidak boleh meluap;
                    // outputnya antara `0` dan `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Ini tidak boleh meluap;outputnya antara `0` dan `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Lihat RFC #521 untuk mengaktifkannya.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Jadual kuasa 5 yang boleh ditunjukkan dalam digit.Khususnya, nilai {u8, u16, u32} terbesar yang mempunyai kekuatan lima, ditambah dengan eksponen yang sepadan.
/// Digunakan dalam `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Bilangan bulat ketepatan sewenang-wenang yang diperuntukkan (sehingga had tertentu).
        ///
        /// Ini disokong oleh susunan ukuran tetap dari jenis ("digit") yang diberikan.
        /// Walaupun array tidak terlalu besar (biasanya beberapa ratus bait), menyalinnya secara sembarangan dapat mengakibatkan prestasi meningkat.
        ///
        /// Oleh itu ini sengaja bukan `Copy`.
        ///
        /// Semua operasi tersedia untuk bignum panic sekiranya berlaku limpahan.
        /// Pemanggil bertanggungjawab menggunakan jenis bignum yang cukup besar.
        pub struct $name {
            /// Satu ditambah ofset ke "digit" maksimum yang digunakan.
            /// Ini tidak berkurang, jadi perhatikan urutan pengiraan.
            /// `base[size..]` hendaklah sifar.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` mewakili `a + b *2^W + c* 2^(2W) + ...` di mana `W` adalah bilangan bit dalam jenis digit.
            base: [$ty; $n],
        }

        impl $name {
            /// Membuat bignum dari satu digit.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Membuat bignum dari nilai `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Mengembalikan digit dalaman sebagai potongan `[a, b, c, ...]` sehingga nilai numeriknya adalah `a + b *2^W + c* 2^(2W) + ...` di mana `W` adalah bilangan bit dalam jenis digit.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Mengembalikan bit `i`-th di mana bit 0 adalah yang paling tidak signifikan.
            /// Dengan kata lain, sedikit dengan berat `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Mengembalikan `true` jika bignum adalah sifar.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Mengembalikan bilangan bit yang diperlukan untuk mewakili nilai ini.
            /// Perhatikan bahawa sifar dianggap memerlukan 0 bit.
            pub fn bit_length(&self) -> usize {
                // Langkau angka paling signifikan iaitu sifar.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Tidak ada digit bukan sifar, iaitu, angka itu adalah sifar.
                    return 0;
                }
                // Ini dapat dioptimumkan dengan pergeseran leading_zeros() dan bit, tetapi itu mungkin tidak merisaukan.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Menambah `other` untuk dirinya sendiri dan mengembalikan rujukannya yang boleh berubah.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Kurangkan `other` dari dirinya dan mengembalikan rujukannya yang boleh berubah.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Menggandakan dirinya dengan `other` bersaiz digit dan mengembalikan rujukannya yang boleh berubah.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Mengalikan dengan `2^bits` dan mengembalikan rujukannya yang boleh berubah.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // beralih oleh bit `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // beralih oleh bit `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. digit] adalah sifar, tidak perlu beralih
                }

                self.size = sz;
                self
            }

            /// Mengalikan dengan `5^e` dan mengembalikan rujukannya yang boleh berubah.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Terdapat n angka nol di belakang pada 2 ^ n, dan satu-satunya ukuran digit yang relevan adalah kekuatan dua berturut-turut, jadi ini adalah indeks yang sesuai untuk jadual.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Gandakan dengan kuasa satu digit terbesar selama mungkin ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... kemudian selesaikan baki.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Mengalikan dengan nombor yang dijelaskan oleh `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (di mana `W` adalah bilangan bit dalam jenis digit) dan mengembalikan rujukannya yang boleh berubah.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // rutin dalaman.berfungsi paling baik apabila aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Membahagi dirinya dengan `other` bersaiz digit dan mengembalikan rujukan *dan* selebihnya yang boleh berubah.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Bahagikan diri dengan bignum lain, ganti `q` dengan hasil tambah dan `r` dengan selebihnya.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Pembahagian panjang lambat base-2 bodoh diambil dari
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME menggunakan ($ty) asas yang lebih besar untuk pembahagian panjang.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Tetapkan bit `i` q hingga 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Jenis digit untuk `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// yang ini digunakan untuk ujian sahaja.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}