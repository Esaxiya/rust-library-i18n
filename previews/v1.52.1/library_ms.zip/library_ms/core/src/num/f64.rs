//! Pemalar khusus untuk jenis titik terapung berketepatan ganda `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Nombor signifikan secara matematik disediakan dalam sub-modul `consts`.
//!
//! Untuk pemalar yang ditentukan secara langsung dalam modul ini (berbeza dengan yang ditentukan dalam sub-modul `consts`), kod baru harus menggunakan pemalar yang berkaitan yang ditentukan secara langsung pada jenis `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Jejari atau asas perwakilan dalaman `f64`.
/// Gunakan [`f64::RADIX`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // cara yang dimaksudkan
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Bilangan digit penting dalam asas 2.
/// Gunakan [`f64::MANTISSA_DIGITS`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // cara yang dimaksudkan
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Jumlah anggaran digit penting dalam asas 10.
/// Gunakan [`f64::DIGITS`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // cara yang dimaksudkan
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] nilai untuk `f64`.
/// Gunakan [`f64::EPSILON`] sebagai gantinya.
///
/// Ini adalah perbezaan antara `1.0` dan nombor yang dapat diwakilkan seterusnya yang lebih besar.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // cara yang dimaksudkan
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Nilai `f64` terhingga terkecil.
/// Gunakan [`f64::MIN`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Nilai `f64` normal positif terkecil.
/// Gunakan [`f64::MIN_POSITIVE`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Nilai `f64` terhingga terbesar.
/// Gunakan [`f64::MAX`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Satu yang lebih besar daripada kekuatan normal minimum 2 eksponen.
/// Gunakan [`f64::MIN_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Kuasa maksimum 2 eksponen.
/// Gunakan [`f64::MAX_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Kekuatan normal minimum 10 eksponen.
/// Gunakan [`f64::MIN_10_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // cara yang dimaksudkan
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Kuasa maksimum 10 eksponen.
/// Gunakan [`f64::MAX_10_EXP`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // cara yang dimaksudkan
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Bukan Nombor (NaN).
/// Gunakan [`f64::NAN`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // cara yang dimaksudkan
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// Gunakan [`f64::INFINITY`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // cara yang dimaksudkan
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Infiniti negatif (−∞).
/// Gunakan [`f64::NEG_INFINITY`] sebagai gantinya.
///
/// # Examples
///
/// ```rust
/// // cara usang
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // cara yang dimaksudkan
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Pemalar matematik asas.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: gantikan dengan pemalar matematik dari cmath.

    /// Pemalar Archimedes (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Pemalar bulatan penuh (τ)
    ///
    /// Sama dengan 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Nombor Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// Jejari atau asas perwakilan dalaman `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Bilangan digit penting dalam asas 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Jumlah anggaran digit penting dalam asas 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] nilai untuk `f64`.
    ///
    /// Ini adalah perbezaan antara `1.0` dan nombor yang dapat diwakilkan seterusnya yang lebih besar.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Nilai `f64` terhingga terkecil.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Nilai `f64` normal positif terkecil.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Nilai `f64` terhingga terbesar.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Satu yang lebih besar daripada kekuatan normal minimum 2 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Kuasa maksimum 2 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Kekuatan normal minimum 10 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Kuasa maksimum 10 eksponen.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Bukan Nombor (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Infiniti negatif (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Mengembalikan `true` jika nilai ini adalah `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` tidak tersedia secara terbuka di libcore kerana kebimbangan mengenai mudah alih, jadi pelaksanaan ini adalah untuk kegunaan peribadi secara dalaman.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Mengembalikan `true` jika nilai ini adalah infiniti positif atau infiniti negatif, dan `false` sebaliknya.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Mengembalikan `true` jika nombor ini tidak terbatas atau `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Tidak perlu menangani NaN secara berasingan: jika diri sendiri adalah NaN, perbandingannya tidak benar, tepat seperti yang diinginkan.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Mengembalikan `true` jika nombornya adalah [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Nilai antara `0` dan `min` adalah Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Mengembalikan `true` jika nombornya tidak sifar, tidak terhingga, [subnormal] atau `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Nilai antara `0` dan `min` adalah Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Mengembalikan kategori nombor terapung nombor.
    /// Sekiranya hanya satu harta benda yang akan diuji, biasanya lebih pantas menggunakan predikat tertentu sebagai gantinya.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Mengembalikan `true` jika `self` mempunyai tanda positif, termasuk `+0.0`, `NaN dengan bit tanda positif dan tak terhingga positif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Mengembalikan `true` jika `self` mempunyai tanda negatif, termasuk `-0.0`, `NaN dengan bit tanda negatif dan tak terhingga negatif.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Mengambil (inverse) timbal balik nombor, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Menukar radian kepada darjah.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Pembahagian di sini dibulatkan dengan betul berkenaan dengan nilai sebenar 180/π.
        // (Ini berbeza dengan f32, di mana pemalar mesti digunakan untuk memastikan hasil yang bulat dengan betul.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Menukar darjah kepada radian.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Mengembalikan maksimum dua nombor.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Sekiranya salah satu argumen adalah NaN, maka hujah yang lain dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Mengembalikan minimum dua nombor.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Sekiranya salah satu argumen adalah NaN, maka hujah yang lain dikembalikan.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Membundarkan ke arah sifar dan menukar ke jenis bilangan bulat primitif, dengan andaian bahawa nilainya terbatas dan sesuai dengan jenis itu.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Nilai mesti:
    ///
    /// * Jangan jadi `NaN`
    /// * Tidak menjadi tidak terbatas
    /// * Wakili dalam jenis pulangan `Int`, setelah memotong bahagian pecahannya
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transutasi mentah ke `u64`.
    ///
    /// Ini sama dengan `transmute::<f64, u64>(self)` pada semua platform.
    ///
    /// Lihat `from_bits` untuk beberapa perbincangan mengenai kemungkinan operasi ini (hampir tidak ada masalah).
    ///
    /// Perhatikan bahawa fungsi ini berbeza dengan pemutus `as`, yang berusaha mengekalkan nilai *numerik*, dan bukan nilai bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() tidak membuang!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // KESELAMATAN: `u64` adalah jenis data lama biasa sehingga kita selalu dapat memancarkannya
        unsafe { mem::transmute(self) }
    }

    /// Transutasi mentah dari `u64`.
    ///
    /// Ini sama dengan `transmute::<u64, f64>(v)` pada semua platform.
    /// Ternyata ini sangat mudah alih, kerana dua sebab:
    ///
    /// * Floats dan Ints mempunyai endian yang sama pada semua platform yang disokong.
    /// * IEEE-754 dengan tepat menentukan susun atur bit apungan.
    ///
    /// Namun ada satu peringatan: sebelum versi IEEE-754 2008, bagaimana mentafsirkan bit isyarat NaN sebenarnya tidak dinyatakan.
    /// Sebilangan besar platform (terutamanya x86 dan ARM) memilih tafsiran yang akhirnya diseragamkan pada tahun 2008, tetapi beberapa tidak (terutamanya MIPS).
    /// Hasilnya, semua NaN isyarat pada MIPS adalah NaN yang tenang pada x86, dan sebaliknya.
    ///
    /// Daripada berusaha mengekalkan platform lintas isyarat, pelaksanaan ini lebih baik untuk mengekalkan bit tepat.
    /// Ini bermaksud bahawa setiap muatan yang dikodkan dalam NaN akan dipertahankan walaupun hasil kaedah ini dihantar melalui rangkaian dari mesin x86 ke MIPS.
    ///
    ///
    /// Sekiranya hasil kaedah ini hanya dimanipulasi oleh seni bina yang sama yang menghasilkannya, maka tidak ada masalah mudah dibawa.
    ///
    /// Sekiranya inputnya bukan NaN, maka tidak ada masalah mudah dibawa.
    ///
    /// Sekiranya anda tidak peduli dengan isyarat-isyarat (kemungkinan besar), maka tidak ada masalah mudah alih.
    ///
    /// Perhatikan bahawa fungsi ini berbeza dengan pemutus `as`, yang berusaha mengekalkan nilai *numerik*, dan bukan nilai bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // KESELAMATAN: `u64` adalah jenis data lama biasa sehingga kita selalu dapat mengubahnya
        // Ternyata masalah keselamatan dengan sNaN meletup!Hore!
        unsafe { mem::transmute(v) }
    }

    /// Kembalikan perwakilan memori nombor terapung ini sebagai tatasusunan bait dalam susunan byte (network) besar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Kembalikan perwakilan memori nombor terapung ini sebagai tatasusunan bait dalam susunan bait kecil-endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Kembalikan perwakilan memori nombor terapung ini sebagai susunan bait dalam susunan bait asli.
    ///
    /// Oleh kerana kebiasaan asli platform sasaran digunakan, kod mudah alih harus menggunakan [`to_be_bytes`] atau [`to_le_bytes`], jika sesuai, sebagai gantinya.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Kembalikan perwakilan memori nombor terapung ini sebagai susunan bait dalam susunan bait asli.
    ///
    ///
    /// [`to_ne_bytes`] semestinya lebih disukai berbanding ini bila mungkin.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // KESELAMATAN: `f64` adalah jenis data lama biasa sehingga kita selalu dapat memancarkannya
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Buat nilai titik terapung dari perwakilannya sebagai susunan bait di endian besar.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Buat nilai titik terapung dari perwakilannya sebagai susunan bait di endian kecil.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Buat nilai titik terapung dari perwakilannya sebagai susunan bait dalam endian asli.
    ///
    /// Oleh kerana kebiasaan asli platform sasaran digunakan, kod mudah alih mungkin ingin menggunakan [`from_be_bytes`] atau [`from_le_bytes`], yang sesuai sebagai gantinya.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Mengembalikan susunan antara nilai diri dan nilai lain.
    /// Tidak seperti perbandingan separa standard antara nombor titik terapung, perbandingan ini selalu menghasilkan pesanan sesuai dengan predikat totalOrder seperti yang ditentukan dalam standard titik terapung IEEE 754 (revisi 2008).
    /// Nilai disusun mengikut urutan berikut:
    /// - NaN senyap negatif
    /// - NaN isyarat negatif
    /// - Infiniti negatif
    /// - Nombor negatif
    /// - Nombor subnormal negatif
    /// - Sifar negatif
    /// - Sifar positif
    /// - Nombor subnormal positif
    /// - Nombor positif
    /// - Infiniti positif
    /// - Pemberian isyarat positif NaN
    /// - NaN pendiam positif
    ///
    /// Perhatikan bahawa fungsi ini tidak selalu sesuai dengan pelaksanaan [`PartialOrd`] dan [`PartialEq`] `f64`.Secara khusus, mereka menganggap sifar negatif dan positif sama, sementara `total_cmp` tidak.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Sekiranya negatif, balikkan semua bit kecuali tanda untuk mencapai susun atur yang sama dengan bilangan bulat pelengkap dua
        //
        // Mengapa ini berfungsi?Terapung IEEE 754 terdiri daripada tiga bidang:
        // Tanda bit, eksponen dan mantissa.Kumpulan medan eksponen dan mantissa secara keseluruhan mempunyai sifat bahawa urutan bitwisenya sama dengan magnitud berangka di mana besarannya ditentukan.
        // Besarnya biasanya tidak ditentukan pada nilai NaN, tetapi IEEE 754 totalOrder mendefinisikan nilai NaN juga untuk mengikuti urutan bitwise.Ini membawa kepada pesanan yang dijelaskan dalam komen dokumen.
        // Walau bagaimanapun, perwakilan magnitud adalah sama untuk nombor negatif dan positif-hanya bit tanda yang berbeza.
        // Untuk membandingkan apungan dengan mudah sebagai bilangan bulat yang ditandatangani, kita perlu membalikkan bit eksponen dan mantissa sekiranya terdapat nombor negatif.
        // Kami menukar nombor dengan berkesan ke bentuk "two's complement".
        //
        // Untuk melakukan pembalikan, kami membina topeng dan XOR terhadapnya.
        // Kami mengira topeng "all-ones except for the sign bit" tanpa cacat dari nilai bertanda negatif: tanda peralihan kanan-memanjangkan bilangan bulat, jadi kami "fill" topeng dengan bit tanda, dan kemudian menukar ke tidak ditandatangani untuk menolak satu bit sifar lagi.
        //
        // Pada nilai positif, topeng adalah semua nol, jadi itu bukan op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Hadkan nilai pada selang waktu tertentu melainkan ia adalah NaN.
    ///
    /// Mengembalikan `max` jika `self` lebih besar daripada `max`, dan `min` jika `self` kurang dari `min`.
    /// Jika tidak, ini mengembalikan `self`.
    ///
    /// Perhatikan bahawa fungsi ini mengembalikan NaN jika nilai awalnya juga NaN.
    ///
    /// # Panics
    ///
    /// Panics jika `min > max`, `min` adalah NaN, atau `max` adalah NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}