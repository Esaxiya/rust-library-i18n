//! Pemalar untuk jenis bilangan bulat bersaiz penunjuk.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Kod baru harus menggunakan pemalar yang berkaitan terus pada jenis primitif.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }