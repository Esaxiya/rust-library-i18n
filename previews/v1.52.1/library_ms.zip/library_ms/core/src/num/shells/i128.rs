//! Pemalar untuk jenis bilangan bulat yang ditandatangani 128-bit.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Kod baru harus menggunakan pemalar yang berkaitan terus pada jenis primitif.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }