//! Mengesahkan dan menguraikan rentetan perpuluhan bentuk:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Dengan kata lain, sintaks titik terapung standard, dengan dua pengecualian: Tanpa tanda, dan tanpa pengendalian "inf" dan "NaN".Ini dikendalikan oleh fungsi pemandu (super::dec2flt).
//!
//! Walaupun mengenali input yang sah agak mudah, modul ini juga harus menolak variasi tidak sah yang tidak terhitung jumlahnya, tidak pernah panic, dan melakukan banyak pemeriksaan yang bergantung pada modul lain agar tidak panic (atau meluap) pada gilirannya.
//!
//! Untuk memburukkan lagi keadaan, semua itu berlaku dalam satu masukan melalui input.
//! Jadi, berhati-hatilah semasa mengubahsuai apa-apa, dan periksa semula dengan modul lain.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Bahagian yang menarik dari tali perpuluhan.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Eksponen perpuluhan, dijamin mempunyai kurang daripada 18 digit perpuluhan.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Memeriksa apakah rentetan input adalah nombor titik terapung yang sah dan jika ya, cari bahagian integral, bahagian pecahan, dan eksponen di dalamnya.
/// Tidak mengendalikan tanda.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Tiada digit sebelum 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Kami memerlukan sekurang-kurangnya satu digit sebelum atau selepas titik.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Trailing sampah selepas bahagian pecahan
            }
        }
        _ => Invalid, // Junk trailing setelah rentetan digit pertama
    }
}

/// Mengeluarkan digit perpuluhan hingga aksara bukan digit pertama.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Pengekstrakan eksponen dan pemeriksaan ralat.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Menjejak sampah selepas eksponen
    }
    if number.is_empty() {
        return Invalid; // Eksponen kosong
    }
    // Pada ketika ini, kita pasti mempunyai rentetan digit yang sah.Mungkin terlalu lama untuk dimasukkan ke dalam `i64`, tetapi jika begitu besar, inputnya pasti sifar atau tak terhingga.
    // Oleh kerana setiap sifar dalam digit perpuluhan hanya menyesuaikan eksponen dengan +/-1, pada exp=10 ^ 18 input harus menjadi 17 exabyte (!) nol untuk mendapatkan jarak jauh hingga menjadi terbatas.
    //
    // Ini bukan kes penggunaan yang perlu kita atasi.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}