//! Sedikit mempermainkan IEEE 754 terapung positif.Nombor negatif tidak dan tidak perlu dikendalikan.
//! Nombor terapung normal mempunyai perwakilan kanonik seperti (frac, exp) sehingga nilainya adalah 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) di mana N adalah bilangan bit.
//!
//! Subnormal sedikit berbeza dan pelik, tetapi prinsip yang sama berlaku.
//!
//! Di sini, bagaimanapun, kami mewakili mereka sebagai (sig, k) dengan f positif, sehingga nilainya adalah f *
//! 2 <sup>e</sup> .Selain membuat "hidden bit" eksplisit, ini mengubah eksponen oleh apa yang disebut pergeseran mantissa.
//!
//! Dengan kata lain, biasanya apungan ditulis sebagai (1) tetapi di sini ia ditulis sebagai (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Kami memanggil (1) sebagai **perwakilan pecahan** dan (2) sebagai **perwakilan tidak terpadu**.
//!
//! Banyak fungsi dalam modul ini hanya menangani nombor normal.Rutin dec2flt secara konservatif mengambil jalan perlahan yang betul secara universal (Algoritma M) untuk bilangan yang sangat kecil dan sangat besar.
//! Algoritma itu hanya memerlukan next_float() yang menangani subnormal dan sifar.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Pembantu trait untuk mengelakkan penduaan pada dasarnya semua kod penukaran untuk `f32` dan `f64`.
///
/// Lihat komen dokumen modul induk mengapa ini diperlukan.
///
/// Sekiranya **tidak pernah** dilaksanakan untuk jenis lain atau digunakan di luar modul dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Jenis yang digunakan oleh `to_bits` dan `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Melakukan transmutasi mentah ke integer.
    fn to_bits(self) -> Self::Bits;

    /// Melakukan transmutasi mentah dari integer.
    fn from_bits(v: Self::Bits) -> Self;

    /// Mengembalikan kategori yang menjadi nombor ini.
    fn classify(self) -> FpCategory;

    /// Mengembalikan mantissa, eksponen dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Menyahkod pelampung.
    fn unpack(self) -> Unpacked;

    /// Cast dari bilangan bulat kecil yang dapat ditunjukkan dengan tepat.
    /// Panic jika bilangan bulat tidak dapat ditunjukkan, kod lain dalam modul ini memastikan tidak akan membiarkan perkara itu berlaku.
    fn from_int(x: u64) -> Self;

    /// Mendapat nilai 10 <sup>e</sup> dari jadual yang telah dikira sebelumnya.
    /// Panics untuk `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Apa namanya.
    /// Lebih mudah untuk membuat kod keras daripada menyulap intrinsik dan berharap LLVM sentiasa melipatnya.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konservatif terikat pada digit perpuluhan input yang tidak dapat menghasilkan limpahan atau sifar atau
    /// subormal.Mungkin eksponen perpuluhan dari nilai normal maksimum, maka namanya.
    const MAX_NORMAL_DIGITS: usize;

    /// Apabila digit perpuluhan yang paling signifikan mempunyai nilai tempat lebih besar daripada ini, angka itu pasti dibundarkan hingga tak terhingga.
    ///
    const INF_CUTOFF: i64;

    /// Apabila digit perpuluhan yang paling signifikan mempunyai nilai tempat kurang dari ini, angka itu pasti dibundarkan ke sifar.
    ///
    const ZERO_CUTOFF: i64;

    /// Bilangan bit dalam eksponen.
    const EXP_BITS: u8;

    /// Bilangan bit dalam makna,*termasuk* bit tersembunyi.
    const SIG_BITS: u8;

    /// Bilangan bit dalam makna,*tidak termasuk* bit tersembunyi.
    const EXPLICIT_SIG_BITS: u8;

    /// Eksponen undang-undang maksimum dalam perwakilan pecahan.
    const MAX_EXP: i16;

    /// Eksponen undang-undang minimum dalam perwakilan pecahan, tidak termasuk subnormal.
    const MIN_EXP: i16;

    /// `MAX_EXP` untuk perwakilan integral, iaitu, dengan pergeseran yang berlaku.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` dikodkan (iaitu, dengan bias ofset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` untuk perwakilan integral, iaitu, dengan pergeseran yang berlaku.
    const MIN_EXP_INT: i16;

    /// Maksud normalisasi maksimum dalam perwakilan integral.
    const MAX_SIG: u64;

    /// Makna normalisasi minimum dalam perwakilan integral.
    const MIN_SIG: u64;
}

// Sebilangan besar penyelesaian untuk #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Mengembalikan mantissa, eksponen dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias eksponen + pergeseran mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe tidak pasti sama ada `as` membundarkan dengan betul di semua platform.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Mengembalikan mantissa, eksponen dan tanda sebagai bilangan bulat.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias eksponen + pergeseran mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe tidak pasti sama ada `as` membundarkan dengan betul di semua platform.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Menukar `Fp` ke jenis mesin apungan terdekat.
/// Tidak menangani keputusan yang tidak normal.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f adalah 64 bit, jadi xe mempunyai peralihan mantissa 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Bundarkan nilai 64-bit ke bit T::SIG_BITS dengan separuh hingga genap.
/// Tidak menangani limpahan eksponen.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Selaraskan pergeseran mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Sebalik `RawFloat::unpack()` untuk nombor yang dinormalisasi.
/// Panics jika signifikan atau eksponen tidak sah untuk nombor yang dinormalisasi.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Keluarkan bit yang tersembunyi
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Laraskan eksponen untuk bias eksponen dan pergeseran mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Tinggalkan bit tanda pada 0 ("+"), nombor kami semua positif
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Bentukkan subnormal.Mantissa 0 dibenarkan dan membina sifar.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Eksponen yang dikodkan adalah 0, bit tanda adalah 0, jadi kita hanya perlu mentafsirkan semula bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Kira bignum dengan Fp.Putaran dalam 0.5 ULP dengan separuh hingga genap.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Kami memotong semua bit sebelum indeks `start`, iaitu, kita secara efektif beralih ke kanan dengan jumlah `start`, jadi ini juga eksponen yang kita perlukan.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Bulat (half-to-even) bergantung pada bit terpotong.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Mencari nombor titik terapung terbesar lebih kecil daripada argumen.
/// Tidak menangani aliran bawah subnormal, sifar, atau eksponen.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Cari nombor titik terapung terkecil yang lebih besar daripada argumen.
// Operasi ini tepu, iaitu, next_float(inf) ==inf.
// Tidak seperti kebanyakan kod dalam modul ini, fungsi ini menangani sifar, subnormal, dan infiniti.
// Namun, seperti semua kod lain di sini, ia tidak berkaitan dengan nombor NaN dan nombor negatif.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Ini nampaknya terlalu bagus untuk menjadi kenyataan, tetapi ia berjaya.
        // 0.0 dikodkan sebagai kata semua-sifar.Subnormal adalah 0x000m ... m dengan m adalah mantissa.
        // Khususnya, subnormal terkecil adalah 0x0 ... 01 dan yang terbesar ialah 0x000F ... F.
        // Nombor normal terkecil ialah 0x0010 ... 0, jadi casing sudut ini juga berfungsi.
        // Sekiranya kenaikan melampaui mantissa, nilai tambah akan menaikkan eksponen seperti yang kita mahukan, dan bit mantissa menjadi sifar.
        // Kerana konvensyen bit tersembunyi, ini juga yang kita mahukan!
        // Akhirnya, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}