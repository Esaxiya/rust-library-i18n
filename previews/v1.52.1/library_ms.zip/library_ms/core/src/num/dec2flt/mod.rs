//! Menukarkan rentetan perpuluhan menjadi nombor titik terapung binari IEEE 754.
//!
//! # Pernyataan masalah
//!
//! Kami diberi rentetan perpuluhan seperti `12.34e56`.
//! Rentetan ini terdiri daripada bahagian (`12`) integral, pecahan (`34`), dan bahagian (`56`) eksponen.Semua bahagian adalah pilihan dan ditafsirkan sebagai sifar apabila hilang.
//!
//! Kami mencari nombor titik terapung IEEE 754 yang paling hampir dengan nilai tepat bagi tali perpuluhan.
//! Telah diketahui bahawa banyak rentetan perpuluhan tidak mempunyai perwakilan penamat di pangkalan dua, jadi kita membundarkan ke unit 0.5 di tempat terakhir (dengan kata lain, juga mungkin).
//! Ikatan, nilai perpuluhan tepat di tengah-tengah antara dua pelampung berturut-turut, diselesaikan dengan strategi setengah hingga genap, juga dikenali sebagai pembundaran banker.
//!
//! Tidak perlu dikatakan, ini agak sukar, baik dari segi kerumitan pelaksanaan dan dari segi kitaran CPU yang diambil.
//!
//! # Implementation
//!
//! Pertama, kita mengabaikan tanda.Atau lebih tepatnya, kami menghapusnya pada awal proses penukaran dan menerapkannya semula pada akhir.
//! Ini betul dalam semua kes edge kerana pelampung IEEE adalah simetri sekitar sifar, meniadakan satu hanya membalik bit pertama.
//!
//! Kemudian kami membuang titik perpuluhan dengan menyesuaikan eksponen: Secara konseptual, `12.34e56` berubah menjadi `1234e54`, yang kami gambarkan dengan bilangan bulat positif `f = 1234` dan bilangan bulat `e = 54`.
//! Perwakilan `(f, e)` digunakan oleh hampir semua kod melewati peringkat penghuraian.
//!
//! Kami kemudian mencuba rangkaian panjang kes khas yang lebih umum dan mahal secara progresif menggunakan bilangan bulat berukuran mesin dan nombor titik terapung berukuran tetap kecil (`f32`/`f64` pertama, kemudian jenis dengan makna 64 bit, `Fp`).
//!
//! Apabila semua ini gagal, kami menggigit peluru dan menggunakan algoritma sederhana tetapi sangat perlahan yang melibatkan pengkomputeran `f * 10^e` sepenuhnya dan melakukan pencarian berulang untuk penghampiran terbaik.
//!
//! Terutama, modul ini dan anak-anaknya melaksanakan algoritma yang dijelaskan dalam:
//! "How to Read Floating Point Numbers Accurately" oleh William D.
//! Clinger, boleh didapati dalam talian: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Di samping itu, terdapat banyak fungsi pembantu yang digunakan di dalam kertas tetapi tidak terdapat di Rust (atau sekurang-kurangnya inti).
//! Versi kami juga rumit oleh keperluan untuk menangani limpahan dan aliran bawah dan keinginan untuk menangani nombor yang tidak normal.
//! Bellerophon dan Algorithm R menghadapi masalah overflow, subnormal, dan underflow.
//! Kami secara konservatif beralih ke Algoritma M (dengan pengubahsuaian yang dijelaskan dalam bahagian 8 kertas) sebelum input masuk ke kawasan kritikal.
//!
//! Aspek lain yang memerlukan perhatian adalah `` RawFloat '' trait di mana hampir semua fungsi diparamatisasi.Seseorang mungkin menganggap bahawa sudah cukup untuk menguraikan ke `f64` dan memberikan hasilnya ke `f32`.
//! Sayangnya ini bukan dunia yang kita jalani, dan ini tidak ada kaitan dengan penggunaan asas dua atau pembundaran setengah hingga genap.
//!
//! Pertimbangkan misalnya dua jenis `d2` dan `d4` yang mewakili jenis perpuluhan dengan dua digit perpuluhan dan empat digit perpuluhan masing-masing dan ambil "0.01499" sebagai input.Mari gunakan pembundaran separuh atas.
//! Pergi secara langsung ke dua digit perpuluhan memberikan `0.01`, tetapi jika kita membulatkan ke empat digit terlebih dahulu, kita mendapat `0.0150`, yang kemudian dibulatkan hingga `0.02`.
//! Prinsip yang sama berlaku untuk operasi lain juga, jika anda mahukan ketepatan 0.5 ULP, anda perlu melakukan *semuanya* dengan tepat dan bulat *tepat sekali, pada akhir*, dengan mempertimbangkan semua potongan terpotong sekaligus.
//!
//! FIXME: Walaupun beberapa pendua kod diperlukan, mungkin bahagian kod dapat digeser sehingga kurang kod yang diduplikasi.
//! Sebilangan besar algoritma tidak bergantung pada jenis float ke output, atau hanya memerlukan akses ke beberapa pemalar, yang dapat diteruskan sebagai parameter.
//!
//! # Other
//!
//! Penukaran hendaklah *tidak pernah* panic.
//! Terdapat pernyataan dan panics eksplisit dalam kod tersebut, tetapi tidak boleh dicetuskan dan hanya berfungsi sebagai pemeriksaan kewarasan dalaman.Sebarang panics harus dianggap sebagai pepijat.
//!
//! Terdapat ujian unit tetapi sangat tidak mencukupi untuk memastikan kebenaran, mereka hanya merangkumi sebilangan kecil kemungkinan kesalahan.
//! Ujian yang jauh lebih luas terdapat di direktori `src/etc/test-float-parse` sebagai skrip Python.
//!
//! Catatan mengenai limpahan bilangan bulat: Banyak bahagian fail ini melakukan aritmetik dengan eksponen perpuluhan `e`.
//! Terutamanya, kita mengalihkan titik perpuluhan sekitar: Sebelum digit perpuluhan pertama, selepas digit perpuluhan terakhir, dan seterusnya.Ini boleh melimpah jika dilakukan secara sembarangan.
//! Kami bergantung pada submodul penguraian untuk hanya membagikan eksponen yang cukup kecil, di mana "sufficient" bermaksud "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Eksponen yang lebih besar diterima, tetapi kami tidak melakukan aritmetik dengan mereka, mereka segera berubah menjadi {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Kedua-dua ini mempunyai ujian sendiri.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Menukar rentetan di pangkalan 10 ke apungan.
            /// Menerima eksponen perpuluhan pilihan.
            ///
            /// Fungsi ini menerima tali seperti
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', atau setaraf, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', atau, bersamaan, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Ruang kosong terkemuka dan ketinggalan menunjukkan ralat.
            ///
            /// # Grammar
            ///
            /// Semua rentetan yang mematuhi tatabahasa [EBNF] berikut akan menghasilkan [`Ok`] yang dikembalikan:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Pepijat yang dikenali
            ///
            /// Dalam beberapa keadaan, beberapa rentetan yang seharusnya membuat pengapungan yang sah sebaliknya mengembalikan ralat.
            /// Lihat [issue #31407] untuk maklumat lanjut.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Rentetan
            ///
            /// # Nilai pulangan
            ///
            /// `Err(ParseFloatError)` jika rentetan tidak mewakili nombor yang sah.
            /// Jika tidak, `Ok(n)` di mana `n` adalah nombor titik terapung yang diwakili oleh `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Kesalahan yang dapat dikembalikan semasa menguraikan apungan.
///
/// Kesalahan ini digunakan sebagai jenis ralat untuk pelaksanaan [`FromStr`] untuk [`f32`] dan [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Membahagi rentetan perpuluhan menjadi tanda dan selebihnya, tanpa memeriksa atau mengesahkan sisanya.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Sekiranya tali tidak sah, kami tidak akan pernah menggunakan tanda, jadi kami tidak perlu mengesahkannya di sini.
        _ => (Sign::Positive, s),
    }
}

/// Menukar rentetan perpuluhan menjadi nombor titik terapung.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Kuda kerja utama untuk penukaran desimal-ke-apungan: Susun semua proses pra-proses dan cari tahu algoritma mana yang harus melakukan penukaran sebenar.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift keluar titik perpuluhan.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 terhad kepada 1280 bit, yang diterjemahkan menjadi sekitar 385 digit perpuluhan.
    // Sekiranya melebihi ini, kita akan mengalami kerosakan, jadi kita membuat kesilapan sebelum terlalu dekat (dalam jarak 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Sekarang eksponen pasti sesuai dengan 16 bit, yang digunakan di seluruh algoritma utama.
    let e = e as i16;
    // FIXME Batasan ini agak konservatif.
    // Analisis yang lebih teliti mengenai mod kegagalan Bellerophon memungkinkan untuk menggunakannya dalam lebih banyak kes untuk mempercepat.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Seperti yang ditulis, ini mengoptimumkan dengan teruk (lihat #27130, walaupun merujuk kepada versi lama kod).
// `inline(always)` adalah penyelesaian untuk itu.
// Hanya ada dua laman web panggilan dan keseluruhannya tidak menjadikan saiz kod menjadi lebih teruk.

/// Angkat sifar jika boleh, walaupun ini memerlukan perubahan eksponen
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Memangkas angka nol ini tidak akan mengubah apa-apa tetapi boleh membolehkan jalan pantas (<15 digit).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Permudahkan nombor bentuk 0.0 ... x dan x ... 0.0, sesuaikan eksponen dengan sewajarnya.
    // Ini mungkin tidak selalu menjadi kemenangan (mungkin mendorong beberapa nombor keluar dari jalan cepat), tetapi ini memudahkan bahagian lain dengan ketara (terutamanya, menghampiri besarnya nilai).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Mengembalikan batas atas cepat-kotor pada ukuran (log10) dari nilai terbesar yang akan dikira oleh Algoritma R dan Algoritma M semasa mengerjakan perpuluhan yang diberikan.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Kami tidak perlu terlalu bimbang tentang limpahan di sini berkat trivial_cases() dan penghurai, yang menyaring input yang paling ekstrem bagi kami.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Dalam kes e>=0, kedua-dua algoritma mengira kira-kira `f * 10^e`.
        // Algoritma R meneruskan pengiraan rumit dengan ini tetapi kita dapat mengabaikannya untuk bahagian atas kerana ia juga mengurangkan pecahan sebelumnya, jadi kita mempunyai banyak penyangga di sana.
        //
        f_len + (e as u64)
    } else {
        // Sekiranya e <0, Algoritma R melakukan perkara yang hampir sama, tetapi Algoritma M berbeza:
        // Ia berusaha mencari nombor positif k sehingga `f << k / 10^e` adalah makna dalam jarak.
        // Ini akan menghasilkan kira-kira `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Satu input yang mencetuskan ini adalah 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Mengesan limpahan dan aliran masuk yang jelas tanpa melihat angka perpuluhan.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Terdapat sifar tetapi mereka dilucutkan oleh simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Ini adalah anggaran ceil(log10(the real value)) yang kasar.
    // Kami tidak perlu terlalu risau tentang limpahan di sini kerana panjang inputnya kecil (sekurang-kurangnya dibandingkan dengan 2 ^ 64) dan penghurai sudah menangani eksponen yang nilai mutlaknya lebih besar daripada 10 ^ 18 (yang masih pendek 10 ^ 19 daripada 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}