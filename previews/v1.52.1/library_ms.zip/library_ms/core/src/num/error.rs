//! Jenis ralat untuk penukaran menjadi jenis kamiran.

use crate::convert::Infallible;
use crate::fmt;

/// Jenis ralat dikembalikan apabila penukaran jenis kamiran yang diperiksa gagal.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Padankan daripada memaksa untuk memastikan bahawa kod seperti `From<Infallible> for TryFromIntError` di atas akan terus berfungsi apabila `Infallible` menjadi alias kepada `!`.
        //
        //
        match never {}
    }
}

/// Kesalahan yang dapat dikembalikan semasa menguraikan bilangan bulat.
///
/// Kesalahan ini digunakan sebagai jenis ralat untuk fungsi `from_str_radix()` pada jenis bilangan bulat primitif, seperti [`i8::from_str_radix`].
///
/// # Sebab berpotensi
///
/// Antara sebab lain, `ParseIntError` dapat dilemparkan kerana ruang kosong di depan atau di belakang tali, misalnya, apabila ia diperoleh dari input standard.
///
/// Menggunakan kaedah [`str::trim()`] memastikan bahawa tidak ada ruang kosong yang tersisa sebelum menghuraikan.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Jumlah untuk menyimpan pelbagai jenis kesalahan yang boleh menyebabkan penguraian integer gagal.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Nilai yang dihuraikan kosong.
    ///
    /// Antara sebab lain, varian ini akan dibina semasa menguraikan tali kosong.
    Empty,
    /// Mengandungi digit yang tidak betul dalam konteksnya.
    ///
    /// Antara sebab lain, varian ini akan dibina semasa menguraikan rentetan yang mengandungi char bukan ASCII.
    ///
    /// Varian ini juga dibina apabila `+` atau `-` salah letak dalam rentetan sama ada sendiri atau di tengah nombor.
    ///
    ///
    InvalidDigit,
    /// Integer terlalu besar untuk disimpan dalam jenis bilangan bulat sasaran.
    PosOverflow,
    /// Integer terlalu kecil untuk disimpan dalam jenis bilangan bulat sasaran.
    NegOverflow,
    /// Nilai adalah Sifar
    ///
    /// Varian ini akan dikeluarkan ketika rentetan parsing memiliki nilai sifar, yang tidak sah untuk jenis bukan sifar.
    ///
    Zero,
}

impl ParseIntError {
    /// Menghasilkan sebab terperinci menguraikan kegagalan bilangan bulat.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}