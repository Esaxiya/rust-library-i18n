//! Pengendali yang berlebihan.
//!
//! Melaksanakan traits ini membolehkan anda membebani operator tertentu.
//!
//! Sebilangan traits ini diimport oleh prelude, jadi ia boleh didapati di setiap program Rust.Hanya operator yang disokong oleh traits yang boleh berlebihan.
//! Sebagai contoh, pengendali penambahan (`+`) boleh dibebani secara berlebihan melalui [`Add`] trait, tetapi oleh kerana pengendali penugasan (`=`) tidak mempunyai sokongan trait, tidak ada cara untuk memuatkan semantiknya secara berlebihan.
//! Selain itu, modul ini tidak menyediakan mekanisme untuk mewujudkan pengendali baru.
//! Sekiranya diperlukan pengecualian tanpa kelebihan atau pengendali tersuai, anda harus melihat makro atau pemalam penyusun untuk memperluas sintaks Rust.
//!
//! Pelaksanaan pengendali traits semestinya tidak mengejutkan dalam konteks masing-masing, dengan mengingat makna biasa dan [operator precedence].
//! Sebagai contoh, semasa melaksanakan [`Mul`], operasi harus mempunyai beberapa persamaan dengan pendaraban (dan berkongsi sifat yang diharapkan seperti kaitan).
//!
//! Perhatikan bahawa pengendali litar pintas `&&` dan `||`, iaitu, mereka hanya menilai operasi kedua mereka jika menyumbang kepada hasilnya.Oleh kerana tingkah laku ini tidak dapat dilaksanakan oleh traits, `&&` dan `||` tidak disokong sebagai pengendali yang terlalu banyak.
//!
//! Sebilangan besar pengendali menggunakan operasi mereka dengan nilai.Dalam konteks bukan generik yang melibatkan jenis terbina dalam, ini biasanya tidak menjadi masalah.
//! Walau bagaimanapun, menggunakan operator ini dalam kod generik, memerlukan perhatian sekiranya nilai harus digunakan semula berbanding dengan membiarkan operator menggunakannya.Salah satu pilihan adalah dengan sesekali menggunakan [`clone`].
//! Pilihan lain adalah bergantung pada jenis yang terlibat menyediakan pelaksanaan operator tambahan untuk rujukan.
//! Sebagai contoh, untuk jenis `T` yang ditentukan pengguna yang seharusnya menyokong penambahan, mungkin idea yang baik ialah kedua-dua `T` dan `&T` melaksanakan traits [`Add<T>`][`Add`] dan [`Add<&T>`][`Add`] supaya kod generik dapat ditulis tanpa pengklonan yang tidak perlu.
//!
//!
//! # Examples
//!
//! Contoh ini mencipta struktur `Point` yang menerapkan [`Add`] dan [`Sub`], dan kemudian menunjukkan penambahan dan pengurangan dua `Titik`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Lihat dokumentasi untuk setiap trait untuk contoh pelaksanaannya.
//!
//! [`Fn`], [`FnMut`], dan [`FnOnce`] traits dilaksanakan oleh jenis yang boleh dipanggil seperti fungsi.Perhatikan bahawa [`Fn`] mengambil `&self`, [`FnMut`] mengambil `&mut self` dan [`FnOnce`] mengambil `self`.
//! Ini sesuai dengan tiga jenis metode yang dapat digunakan pada suatu contoh: panggilan demi referensi, panggilan-oleh-mutable-rujukan, dan panggilan demi nilai.
//! Penggunaan traits yang paling biasa ini adalah bertindak sebagai batas ke fungsi peringkat lebih tinggi yang menggunakan fungsi atau penutupan sebagai argumen.
//!
//! Mengambil [`Fn`] sebagai parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Mengambil [`FnMut`] sebagai parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Mengambil [`FnOnce`] sebagai parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` menggunakan pemboleh ubah yang ditangkap, jadi ia tidak dapat dijalankan lebih dari satu kali
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Mencuba untuk menggunakan `func()` sekali lagi akan menimbulkan ralat `use of moved value` untuk `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` tidak boleh lagi dipanggil pada ketika ini
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;