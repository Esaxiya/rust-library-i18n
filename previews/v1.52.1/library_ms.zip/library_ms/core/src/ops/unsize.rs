use crate::marker::Unsize;

/// Trait yang menunjukkan bahawa ini adalah penunjuk atau pembungkus untuk satu, di mana penukaran saiz dapat dilakukan pada pointee.
///
/// Lihat [DST coercion RFC][dst-coerce] dan [the nomicon entry on coercion][nomicon-coerce] untuk maklumat lebih lanjut.
///
/// Untuk jenis penunjuk terbina dalam, penunjuk ke `T` akan memaksa penunjuk ke `U` jika `T: Unsize<U>` dengan menukar dari penunjuk nipis ke penunjuk gemuk.
///
/// Untuk jenis tersuai, paksaan di sini berfungsi dengan memaksakan `Foo<T>` hingga `Foo<U>` dengan syarat terdapat `CoerceUnsized<Foo<U>> for Foo<T>` yang wujud.
/// Implan semacam itu hanya boleh ditulis jika `Foo<T>` hanya mempunyai satu bidang non-phantomdata yang melibatkan `T`.
/// Sekiranya jenis medan itu adalah `Bar<T>`, pelaksanaan `CoerceUnsized<Bar<U>> for Bar<T>` mesti ada.
/// Paksaan akan berfungsi dengan memaksakan medan `Bar<T>` ke `Bar<U>` dan mengisi medan selebihnya dari `Foo<T>` untuk membuat `Foo<U>`.
/// Ini akan berkesan ke medan penunjuk dan memaksanya.
///
/// Secara amnya, untuk penunjuk pintar anda akan melaksanakan `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, dengan `?Sized` pilihan yang terikat pada `T` itu sendiri.
/// Untuk jenis pembungkus yang menyematkan secara langsung `T` seperti `Cell<T>` dan `RefCell<T>`, anda boleh melaksanakan `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` secara langsung.
///
/// Ini akan membiarkan paksaan jenis seperti `Cell<Box<T>>` berfungsi.
///
/// [`Unsize`][unsize] digunakan untuk menandakan jenis yang boleh dipaksakan ke DST jika berada di belakang petunjuk.Ia dilaksanakan secara automatik oleh penyusun.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ini digunakan untuk keselamatan objek, untuk memeriksa apakah jenis penerima metode dapat dikirimkan.
///
/// Contoh pelaksanaan trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}