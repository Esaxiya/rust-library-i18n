/// trait untuk menyesuaikan tingkah laku pengendali `?`.
///
/// Jenis yang menerapkan `Try` adalah kaedah yang mempunyai cara kanonik untuk melihatnya dari segi dikotomi success/failure.
/// trait ini membolehkan kedua-duanya mengekstrak nilai kejayaan atau kegagalan dari contoh yang ada dan membuat contoh baru dari nilai kejayaan atau kegagalan.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Jenis nilai ini apabila dilihat berjaya.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Jenis nilai ini apabila dilihat gagal.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Menggunakan pengendali "?".Pengembalian `Ok(t)` bermaksud bahawa pelaksanaan harus diteruskan seperti biasa, dan hasil `?` adalah nilai `t`.
    /// Pengembalian `Err(e)` bermaksud bahawa pelaksanaan harus branch ke `catch` paling dalam, atau kembali dari fungsi.
    ///
    /// Sekiranya hasil `Err(e)` dikembalikan, nilai `e` akan menjadi "wrapped" dalam jenis pengembalian skop penutup (yang mesti menerapkan `Try`).
    ///
    /// Secara khusus, nilai `X::from_error(From::from(e))` dikembalikan, di mana `X` adalah jenis kembali fungsi lampiran.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Bungkus nilai ralat untuk membina hasil gabungan.
    /// Contohnya, `Result::Err(x)` dan `Result::from_error(x)` adalah setara.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Balut nilai OK untuk membina hasil gabungan.
    /// Contohnya, `Result::Ok(x)` dan `Result::from_ok(x)` adalah setara.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}