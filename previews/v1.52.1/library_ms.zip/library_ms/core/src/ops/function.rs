/// Versi pengendali panggilan yang mengambil penerima yang tidak berubah.
///
/// Contoh `Fn` boleh dipanggil berulang kali tanpa keadaan mutasi.
///
/// *trait (`Fn`) ini tidak boleh dikelirukan dengan [function pointers] (`fn`).*
///
/// `Fn` dilaksanakan secara automatik dengan penutupan yang hanya mengambil rujukan yang tidak berubah pada pemboleh ubah yang ditangkap atau tidak menangkap apa-apa, begitu juga (safe) [function pointers] (dengan beberapa peringatan, lihat dokumentasi mereka untuk lebih jelasnya).
///
/// Selain itu, untuk sebarang jenis `F` yang menggunakan `Fn`, `&F` juga menggunakan `Fn`.
///
/// Oleh kerana kedua [`FnMut`] dan [`FnOnce`] adalah supertra `Fn`, setiap `Fn` dapat digunakan sebagai parameter di mana [`FnMut`] atau [`FnOnce`] diharapkan.
///
/// Gunakan `Fn` sebagai terikat ketika anda ingin menerima parameter jenis fungsi dan perlu memanggilnya berulang kali dan tanpa keadaan mutasi (misalnya, ketika memanggilnya secara serentak).
/// Sekiranya anda tidak memerlukan syarat yang ketat, gunakan [`FnMut`] atau [`FnOnce`] sebagai had.
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk mendapatkan lebih banyak maklumat mengenai topik ini.
///
/// Juga diperhatikan ialah sintaks khas untuk `Fn` traits (mis
/// `Fn(usize, bool) -> guna`).Mereka yang berminat dengan perincian teknikal ini boleh merujuk kepada [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Memanggil penutupan
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Menggunakan parameter `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex boleh bergantung pada `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Menjalankan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versi pengendali panggilan yang mengambil penerima yang boleh berubah.
///
/// Contoh `FnMut` boleh dipanggil berulang kali dan boleh berubah keadaan.
///
/// `FnMut` diimplementasikan secara automatik oleh penutupan yang mengambil rujukan yang berubah-ubah ke pemboleh ubah yang ditangkap, serta semua jenis yang menerapkan [`Fn`], misalnya, (safe) [function pointers] (kerana `FnMut` adalah supertrait dari [`Fn`]).
/// Selain itu, untuk sebarang jenis `F` yang menggunakan `FnMut`, `&mut F` juga menggunakan `FnMut`.
///
/// Oleh kerana [`FnOnce`] adalah supertrait `FnMut`, setiap contoh `FnMut` dapat digunakan di mana [`FnOnce`] diharapkan, dan kerana [`Fn`] adalah subtrait `FnMut`, setiap contoh [`Fn`] dapat digunakan di mana `FnMut` diharapkan.
///
/// Gunakan `FnMut` sebagai terikat ketika anda ingin menerima parameter jenis fungsi dan perlu memanggilnya berulang kali, sambil membiarkannya berubah keadaan.
/// Sekiranya anda tidak mahu parameter bermutasi keadaan, gunakan [`Fn`] sebagai terikat;jika anda tidak perlu memanggilnya berulang kali, gunakan [`FnOnce`].
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk mendapatkan lebih banyak maklumat mengenai topik ini.
///
/// Juga diperhatikan ialah sintaks khas untuk `Fn` traits (mis
/// `Fn(usize, bool) -> guna`).Mereka yang berminat dengan perincian teknikal ini boleh merujuk kepada [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Memanggil penutupan yang boleh ditangkap
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Menggunakan parameter `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex boleh bergantung pada `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Menjalankan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versi operator panggilan yang mengambil penerima nilai demi nilai.
///
/// Contoh `FnOnce` boleh dipanggil, tetapi mungkin tidak dapat dipanggil berulang kali.Oleh kerana itu, jika satu-satunya perkara yang diketahui mengenai jenisnya ialah ia menggunakan `FnOnce`, ia hanya boleh dipanggil sekali.
///
/// `FnOnce` dilaksanakan secara automatik oleh penutupan yang mungkin menggunakan variabel yang ditangkap, serta semua jenis yang menerapkan [`FnMut`], misalnya, (safe) [function pointers] (kerana `FnOnce` adalah supertrait dari [`FnMut`]).
///
///
/// Oleh kerana [`Fn`] dan [`FnMut`] adalah subtraits `FnOnce`, mana-mana contoh [`Fn`] atau [`FnMut`] dapat digunakan di mana `FnOnce` diharapkan.
///
/// Gunakan `FnOnce` sebagai terikat ketika anda ingin menerima parameter jenis seperti fungsi dan hanya perlu memanggilnya sekali.
/// Sekiranya anda perlu memanggil parameter berulang kali, gunakan [`FnMut`] sebagai terikat;jika anda juga memerlukannya untuk tidak mengubah keadaan, gunakan [`Fn`].
///
/// Lihat [chapter on closures in *The Rust Programming Language*][book] untuk mendapatkan lebih banyak maklumat mengenai topik ini.
///
/// Juga diperhatikan ialah sintaks khas untuk `Fn` traits (mis
/// `Fn(usize, bool) -> guna`).Mereka yang berminat dengan perincian teknikal ini boleh merujuk kepada [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Menggunakan parameter `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` menggunakan pemboleh ubah yang ditangkap, jadi ia tidak dapat dijalankan lebih dari satu kali.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Mencuba untuk menggunakan `func()` sekali lagi akan menimbulkan ralat `use of moved value` untuk `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` tidak boleh lagi dipanggil pada ketika ini
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // supaya regex boleh bergantung pada `&str: !FnMut` itu
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Jenis yang dikembalikan setelah operator panggilan digunakan.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Menjalankan operasi panggilan.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}