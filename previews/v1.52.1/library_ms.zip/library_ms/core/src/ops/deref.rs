/// Digunakan untuk operasi dereferensi yang tidak berubah, seperti `*v`.
///
/// Selain digunakan untuk operasi penghapusan referensi eksplisit dengan operator (unary) `*` dalam konteks yang tidak berubah, `Deref` juga digunakan secara tidak langsung oleh penyusun dalam banyak keadaan.
/// Mekanisme ini dipanggil ['`Deref` coercion'][more].
/// Dalam konteks yang boleh berubah, [`DerefMut`] digunakan.
///
/// Menerapkan `Deref` untuk penunjuk pintar memudahkan mengakses data di belakangnya, sebab itulah mereka menerapkan `Deref`.
/// Sebaliknya, peraturan mengenai `Deref` dan [`DerefMut`] dirancang khusus untuk mengakomodasi penunjuk pintar.
/// Oleh kerana itu,**`Deref` hanya harus dilaksanakan untuk penunjuk pintar** untuk mengelakkan kekeliruan.
///
/// Atas sebab yang serupa,**trait ini tidak boleh gagal**.Kegagalan semasa penghapusan referensi boleh menjadi sangat membingungkan ketika `Deref` dipanggil secara tidak langsung.
///
/// # Lebih banyak mengenai paksaan `Deref`
///
/// Sekiranya `T` menerapkan `Deref<Target = U>`, dan `x` adalah nilai jenis `T`, maka:
///
/// * Dalam konteks yang tidak berubah, `*x` (di mana `T` bukan rujukan atau penunjuk mentah) bersamaan dengan `* Deref::deref(&x)`.
/// * Nilai jenis `&T` dipaksakan ke nilai jenis `&U`
/// * `T` secara implisit menerapkan semua kaedah (immutable) dari jenis `U`.
///
/// Untuk maklumat lebih lanjut, lawati [the chapter in *The Rust Programming Language*][book] serta bahagian rujukan pada [the dereference operator][ref-deref-op], [method resolution] dan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Str dengan medan tunggal yang boleh diakses dengan membatalkan struktur.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Jenis yang terhasil setelah dereferensi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Merendahkan nilai.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Digunakan untuk operasi dereferensi yang dapat diubah, seperti di `*v = 1;`.
///
/// Selain digunakan untuk operasi penghapusan referensi eksplisit dengan operator (unary) `*` dalam konteks yang dapat berubah, `DerefMut` juga digunakan secara tidak langsung oleh penyusun dalam banyak keadaan.
/// Mekanisme ini dipanggil ['`Deref` coercion'][more].
/// Dalam konteks yang tidak berubah, [`Deref`] digunakan.
///
/// Menerapkan `DerefMut` untuk penunjuk pintar menjadikan mutasi data di belakangnya lebih mudah, sebab itulah mereka menerapkan `DerefMut`.
/// Sebaliknya, peraturan mengenai [`Deref`] dan `DerefMut` dirancang khusus untuk mengakomodasi penunjuk pintar.
/// Oleh kerana itu,**`DerefMut` hanya harus dilaksanakan untuk penunjuk pintar** untuk mengelakkan kekeliruan.
///
/// Atas sebab yang serupa,**trait ini tidak boleh gagal**.Kegagalan semasa penghapusan referensi boleh menjadi sangat membingungkan ketika `DerefMut` dipanggil secara tidak langsung.
///
/// # Lebih banyak mengenai paksaan `Deref`
///
/// Sekiranya `T` menerapkan `DerefMut<Target = U>`, dan `x` adalah nilai jenis `T`, maka:
///
/// * Dalam konteks yang boleh berubah, `*x` (di mana `T` bukan rujukan atau penunjuk mentah) bersamaan dengan `* DerefMut::deref_mut(&mut x)`.
/// * Nilai jenis `&mut T` dipaksakan ke nilai jenis `&mut U`
/// * `T` secara implisit menerapkan semua kaedah (mutable) dari jenis `U`.
///
/// Untuk maklumat lebih lanjut, lawati [the chapter in *The Rust Programming Language*][book] serta bahagian rujukan pada [the dereference operator][ref-deref-op], [method resolution] dan [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Str dengan medan tunggal yang boleh diubah suai dengan membatalkan struktur.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Dereferensikan nilai secara bergantian.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Menunjukkan bahawa struktur dapat digunakan sebagai penerima kaedah, tanpa ciri `arbitrary_self_types`.
///
/// Ini dilaksanakan oleh jenis penunjuk stdlib seperti `Box<T>`, `Rc<T>`, `&T`, dan `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}