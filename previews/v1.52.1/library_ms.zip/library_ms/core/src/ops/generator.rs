use crate::marker::Unpin;
use crate::pin::Pin;

/// Hasil penyambungan semula penjana.
///
/// Enum ini dikembalikan dari kaedah `Generator::resume` dan menunjukkan kemungkinan nilai pulangan penjana.
/// Pada masa ini, ini sesuai dengan titik penggantungan (`Yielded`) atau titik penamatan (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Penjana digantung dengan nilai.
    ///
    /// Keadaan ini menunjukkan bahawa generator telah digantung, dan biasanya sesuai dengan pernyataan `yield`.
    /// Nilai yang diberikan dalam varian ini sesuai dengan ungkapan yang diteruskan ke `yield` dan membolehkan penjana memberikan nilai setiap kali mereka menghasilkan.
    ///
    ///
    Yielded(Y),

    /// Penjana dilengkapkan dengan nilai pulangan.
    ///
    /// Keadaan ini menunjukkan bahawa penjana telah selesai dilaksanakan dengan nilai yang diberikan.
    /// Setelah penjana mengembalikan `Complete` dianggap sebagai kesalahan pengaturcara untuk memanggil `resume` lagi.
    ///
    Complete(R),
}

/// trait dilaksanakan oleh jenis penjana terbina dalam.
///
/// Penjana, yang juga biasa disebut sebagai coroutine, kini merupakan ciri bahasa eksperimental di Rust.
/// Generator [RFC 2033] yang ditambahkan pada masa ini bertujuan terutamanya untuk menyediakan blok bangunan untuk sintaks async/await tetapi kemungkinan akan juga memberikan definisi ergonomik untuk iterator dan primitif lain.
///
///
/// Sintaks dan semantik untuk penjana tidak stabil dan memerlukan RFC lebih lanjut untuk penstabilan.Namun, pada masa ini, sintaks seperti penutupan:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Lebih banyak dokumentasi penjana boleh didapati di buku yang tidak stabil.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Jenis nilai yang dihasilkan penjana ini.
    ///
    /// Jenis yang berkaitan ini sesuai dengan ungkapan `yield` dan nilai-nilai yang dibenarkan dikembalikan setiap kali penjana menghasilkan.
    ///
    /// Sebagai contoh, iterator-as-a-generator mungkin mempunyai jenis ini sebagai `T`, jenisnya berulang.
    ///
    type Yield;

    /// Jenis nilai yang dijana oleh penjana ini.
    ///
    /// Ini sesuai dengan jenis yang dikembalikan dari generator sama ada dengan pernyataan `return` atau secara implisit sebagai ungkapan terakhir literal generator.
    /// Sebagai contoh futures akan menggunakan ini sebagai `Result<T, E>` kerana ia mewakili future yang telah siap.
    ///
    ///
    type Return;

    /// Menyambung semula pelaksanaan penjana ini.
    ///
    /// Fungsi ini akan menyambung semula pelaksanaan generator atau memulakan pelaksanaannya jika belum.
    /// Panggilan ini akan kembali ke titik penggantungan terakhir penjana, meneruskan pelaksanaan dari `yield` terbaru.
    /// Penjana akan terus dijalankan sehingga menghasilkan atau mengembalikan, dan pada masa ini fungsi ini akan kembali.
    ///
    /// # Nilai pulangan
    ///
    /// Enum `GeneratorState` yang dikembalikan dari fungsi ini menunjukkan keadaan penjana semasa kembali.
    /// Sekiranya varian `Yielded` dikembalikan maka generator telah mencapai titik penggantungan dan nilai telah dikeluarkan.
    /// Penjana dalam keadaan ini tersedia untuk disambung semula di kemudian hari.
    ///
    /// Sekiranya `Complete` dikembalikan maka penjana telah selesai sepenuhnya dengan nilai yang diberikan.Tidak sah untuk generator disambung semula.
    ///
    /// # Panics
    ///
    /// Fungsi ini mungkin panic jika dipanggil setelah varian `Complete` telah dikembalikan sebelumnya.
    /// Walaupun literal penjana dalam bahasa dijamin panic akan disambung semula selepas `Complete`, ini tidak dijamin untuk semua pelaksanaan `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}