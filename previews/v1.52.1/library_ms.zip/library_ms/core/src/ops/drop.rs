/// Kod tersuai dalam pemusnah.
///
/// Apabila nilai tidak lagi diperlukan, Rust akan menjalankan "destructor" pada nilai tersebut.
/// Cara paling umum bahawa nilai tidak lagi diperlukan adalah ketika ia berada di luar ruang lingkup.Pemusnah mungkin masih berjalan dalam keadaan lain, tetapi kita akan memberi tumpuan kepada skop contoh di sini.
/// Untuk mengetahui beberapa kes lain, sila lihat bahagian [the reference] mengenai pemusnah.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Pemusnah ini terdiri daripada dua komponen:
/// - Panggilan ke `Drop::drop` untuk nilai itu, jika `Drop` trait khas ini dilaksanakan untuk jenisnya.
/// - "drop glue" yang dihasilkan secara automatik yang secara berulang memanggil pemusnah semua bidang nilai ini.
///
/// Oleh kerana Rust secara automatik memanggil pemusnah semua medan terkandung, anda tidak perlu melaksanakan `Drop` dalam kebanyakan kes.
/// Tetapi ada beberapa kes di mana ia berguna, misalnya untuk jenis yang mengurus sumber secara langsung.
/// Sumber itu mungkin memori, mungkin deskriptor fail, mungkin soket rangkaian.
/// Setelah nilai jenis itu tidak lagi digunakan, ia harus "clean up" sumbernya dengan membebaskan memori atau menutup fail atau soket.
/// Ini adalah tugas pemusnah, dan oleh itu tugas `Drop::drop`.
///
/// ## Examples
///
/// Untuk melihat pemusnah dalam tindakan, mari kita lihat program berikut:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust akan memanggil `Drop::drop` terlebih dahulu untuk `_x` dan kemudian untuk kedua-dua `_x.one` dan `_x.two`, yang bermaksud bahawa menjalankan ini akan mencetak
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Walaupun kita membuang pelaksanaan `Drop` untuk `HasTwoDrop`, pemusnah bidangnya masih dipanggil.
/// Ini akan mengakibatkan
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Anda tidak boleh menghubungi `Drop::drop` sendiri
///
/// Kerana `Drop::drop` digunakan untuk membersihkan nilai, mungkin berbahaya untuk menggunakan nilai ini setelah metode tersebut dipanggil.
/// Oleh kerana `Drop::drop` tidak mengambil alih inputnya, Rust mencegah penyalahgunaan dengan tidak membenarkan anda menghubungi `Drop::drop` secara langsung.
///
/// Dengan kata lain, jika anda cuba memanggil `Drop::drop` secara jelas dalam contoh di atas, anda akan mendapat ralat penyusun.
///
/// Sekiranya anda ingin secara jelas memanggil pemusnah nilai, [`mem::drop`] boleh digunakan sebagai gantinya.
///
/// [`mem::drop`]: drop
///
/// ## Urutan drop
///
/// Manakah antara kedua `HasDrop` kami yang pertama jatuh?Untuk struktur, susunannya sama seperti yang dinyatakan: `one` pertama, kemudian `two`.
/// Sekiranya anda ingin mencuba sendiri, anda boleh mengubah `HasDrop` di atas untuk mengandungi beberapa data, seperti bilangan bulat, dan kemudian menggunakannya di `println!` di dalam `Drop`.
/// Tingkah laku ini dijamin oleh bahasa.
///
/// Tidak seperti struktur, pemboleh ubah tempatan dijatuhkan dalam urutan terbalik:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Ini akan dicetak
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Sila lihat [the reference] untuk peraturan lengkap.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` dan `Drop` adalah eksklusif
///
/// Anda tidak dapat menerapkan kedua [`Copy`] dan `Drop` pada jenis yang sama.Jenis yang `Copy` digandakan secara implisit oleh penyusun, menjadikannya sangat sukar untuk diramalkan kapan, dan seberapa sering pemusnah akan dijalankan.
///
/// Oleh itu, jenis ini tidak boleh mempunyai pemusnah.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Melaksanakan pemusnah untuk jenis ini.
    ///
    /// Kaedah ini dipanggil secara tidak langsung ketika nilainya keluar dari ruang lingkup, dan tidak dapat disebut secara eksplisit (ini adalah ralat penyusun [E0040]).
    /// Walau bagaimanapun, fungsi [`mem::drop`] di prelude dapat digunakan untuk memanggil pelaksanaan `Drop` argumen.
    ///
    /// Apabila kaedah ini dipanggil, `self` belum disahpindah.
    /// Itu hanya berlaku setelah kaedah selesai.
    /// Sekiranya ini tidak berlaku, `self` akan menjadi rujukan yang menggantung.
    ///
    /// # Panics
    ///
    /// Memandangkan [`panic!`] akan memanggil `drop` ketika ia berhenti, [`panic!`] mana pun dalam pelaksanaan `drop` kemungkinan akan dibatalkan.
    ///
    /// Perhatikan bahawa walaupun panics ini, nilainya dianggap jatuh;
    /// anda tidak boleh menyebabkan `drop` dipanggil lagi.
    /// Ini biasanya dikendalikan secara automatik oleh pengkompil, tetapi ketika menggunakan kod yang tidak selamat, kadang-kadang boleh terjadi secara tidak sengaja, terutama ketika menggunakan [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}