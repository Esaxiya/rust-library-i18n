use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Walaupun fungsi ini digunakan di satu tempat dan pelaksanaannya dapat diselaraskan, percubaan sebelumnya untuk melakukannya menjadikan rustc lebih lambat:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Susun atur sekumpulan memori.
///
/// Contoh `Layout` menerangkan susun atur memori tertentu.
/// Anda membina `Layout` sebagai input untuk diberikan kepada alokasi.
///
/// Semua susun atur mempunyai ukuran yang berkaitan dan penjajaran kekuatan-dua.
///
/// (Perhatikan bahawa susun atur *tidak* diharuskan memiliki ukuran bukan nol, walaupun `GlobalAlloc` mengharuskan semua permintaan memori berukuran tidak sifar.
/// Pemanggil mesti memastikan bahawa syarat seperti ini dipenuhi, menggunakan peruntukan khusus dengan keperluan yang lebih longgar, atau menggunakan antara muka `Allocator` yang lebih lembut.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ukuran blok memori yang diminta, diukur dalam bait.
    size_: usize,

    // penjajaran blok memori yang diminta, diukur dalam bait.
    // kami memastikan bahawa ini selalu menjadi kekuatan dua, kerana API seperti `posix_memalign` memerlukannya dan merupakan kekangan yang wajar untuk dikenakan pada pembangun Layout.
    //
    //
    // (Namun, kami tidak memerlukan `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Membina `Layout` dari `size` dan `align` tertentu, atau mengembalikan `LayoutError` jika mana-mana syarat berikut tidak dipenuhi:
    ///
    /// * `align` tidak boleh sifar,
    ///
    /// * `align` mesti kekuatan dua,
    ///
    /// * `size`, apabila dibundarkan ke gandaan `align` terdekat, tidak boleh melimpah (iaitu, nilai bulat mestilah kurang daripada atau sama dengan `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (kekuatan-dua menyiratkan sejajar!=0.)

        // Saiz bulat adalah:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Kami tahu dari atas bahawa sejajar!=0.
        // Sekiranya penambahan (sejajar, 1) tidak meluap, maka pembundaran akan baik-baik saja.
        //
        // Sebaliknya,&-masking dengan! (Align, 1) akan mengurangkan hanya bit pesanan rendah.
        // Oleh itu, jika limpahan berlaku dengan jumlah, maka&-mask tidak dapat mengurangkan cukup untuk mengurungkan limpahan itu.
        //
        //
        // Di atas menunjukkan bahawa memeriksa limpahan penjumlahan adalah perlu dan mencukupi.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // KESELAMATAN: syarat untuk `from_size_align_unchecked` adalah
        // diperiksa di atas.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Membuat susun atur, melewati semua pemeriksaan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tidak mengesahkan prasyarat dari [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // KESELAMATAN: pemanggil mesti memastikan bahawa `align` lebih besar daripada sifar.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Ukuran minimum dalam bait untuk blok memori susun atur ini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Penjajaran byte minimum untuk blok memori susun atur ini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Membina `Layout` yang sesuai untuk memegang nilai jenis `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // KESELAMATAN: penjajaran dijamin oleh Rust menjadi kekuatan dua dan
        // combo size + align dijamin sesuai di ruang alamat kami.
        // Hasilnya gunakan konstruktor yang tidak dicentang di sini untuk mengelakkan memasukkan kod yang panics jika tidak dioptimumkan dengan cukup baik.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Menghasilkan susun atur yang menggambarkan rekod yang dapat digunakan untuk memperuntukkan struktur sokongan untuk `T` (yang boleh menjadi trait atau jenis lain yang tidak berukuran seperti potongan).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KESELAMATAN: lihat rasional dalam `new` mengapa ini menggunakan varian tidak selamat
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Menghasilkan susun atur yang menggambarkan rekod yang dapat digunakan untuk memperuntukkan struktur sokongan untuk `T` (yang boleh menjadi trait atau jenis lain yang tidak berukuran seperti potongan).
    ///
    /// # Safety
    ///
    /// Fungsi ini selamat dipanggil jika keadaan berikut berlaku:
    ///
    /// - Sekiranya `T` adalah `Sized`, fungsi ini selalu selamat dipanggil.
    /// - Sekiranya ekor `T` yang tidak bersaiz adalah:
    ///     - [slice], maka panjang ekor irisan mestilah bilangan bulat yang terpadu, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
    ///     - [trait object], maka bahagian vtable dari penunjuk mesti menunjukkan vtable yang sah untuk jenis `T` yang diperolehi oleh penggabungan yang tidak bersaiz, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
    ///
    ///     - (unstable) [extern type], maka fungsi ini selalu selamat dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, kerana susun atur jenis luaran tidak diketahui.
    ///     Ini adalah kelakuan yang sama dengan [`Layout::for_value`] yang merujuk pada ekor jenis luaran.
    ///     - jika tidak, secara konservatif tidak dibenarkan memanggil fungsi ini.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KESELAMATAN: kami menyampaikan prasyarat fungsi ini kepada pemanggil
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KESELAMATAN: lihat rasional dalam `new` mengapa ini menggunakan varian tidak selamat
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Membuat `NonNull` yang menggantung, tetapi sejajar dengan Tata Letak ini.
    ///
    /// Perhatikan bahawa nilai penunjuk berpotensi mewakili penunjuk yang sah, yang bermaksud ini tidak boleh digunakan sebagai nilai sentinel "not yet initialized".
    /// Jenis yang diperuntukkan dengan malas mesti mengesan inisialisasi dengan cara lain.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // KESELAMATAN: penjajaran dijamin tidak sifar
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Membuat susun atur yang menerangkan rekod yang dapat menyimpan nilai susun atur yang sama dengan `self`, tetapi juga sejajar dengan penjajaran `align` (diukur dalam bait).
    ///
    ///
    /// Sekiranya `self` sudah memenuhi penjajaran yang ditentukan, maka kembalikan `self`.
    ///
    /// Perhatikan bahawa kaedah ini tidak menambahkan padding pada ukuran keseluruhan, tidak kira sama ada susun atur yang dikembalikan mempunyai penjajaran yang berbeza.
    /// Dengan kata lain, jika `K` mempunyai ukuran 16, `K.align_to(32)` akan *masih* mempunyai ukuran 16.
    ///
    /// Mengembalikan ralat jika gabungan `self.size()` dan `align` yang diberikan melanggar syarat yang disenaraikan dalam [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Mengembalikan jumlah padding yang mesti kita masukkan selepas `self` untuk memastikan bahawa alamat berikut akan memenuhi `align` (diukur dalam bait).
    ///
    /// contohnya, jika `self.size()` adalah 9, maka `self.padding_needed_for(4)` mengembalikan 3, kerana itu adalah jumlah minimum byte padding yang diperlukan untuk mendapatkan alamat selaras 4 (dengan anggapan bahawa blok memori yang sesuai bermula pada alamat selaras 4).
    ///
    ///
    /// Nilai kembali fungsi ini tidak mempunyai makna jika `align` bukan power-of-two.
    ///
    /// Perhatikan bahawa utiliti nilai yang dikembalikan memerlukan `align` kurang dari atau sama dengan penjajaran alamat permulaan untuk keseluruhan blok memori yang diperuntukkan.Salah satu cara untuk memenuhi kekangan ini adalah dengan memastikan `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Nilai bulat ialah:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // dan kemudian kami mengembalikan perbezaan padding: `len_rounded_up - len`.
        //
        // Kami menggunakan aritmetik modular sepanjang:
        //
        // 1. align dijamin> 0, jadi align, 1 selalu berlaku.
        //
        // 2.
        // `len + align - 1` boleh melimpah paling banyak `align - 1`, jadi&-mask dengan `!(align - 1)` akan memastikan bahawa sekiranya berlaku limpahan, `len_rounded_up` sendiri akan menjadi 0.
        //
        //    Oleh itu, padding yang dikembalikan, apabila ditambahkan ke `len`, menghasilkan 0, yang secara sepele memenuhi penjajaran `align`.
        //
        // (Sudah tentu, percubaan untuk mengalokasikan blok memori yang ukuran dan paddingnya melimpah dengan cara di atas semestinya menyebabkan alokasi menghasilkan kesalahan.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Membuat susun atur dengan membundarkan ukuran susun atur ini menjadi gandaan susun atur.
    ///
    ///
    /// Ini sama dengan menambahkan hasil `padding_needed_for` pada ukuran susun atur semasa.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ini tidak boleh meluap.Memetik dari Tata Letak invarian:
        // > `size`, apabila dibundarkan ke gandaan `align` terdekat,
        // > tidak boleh melimpah (iaitu, nilai bulat mestilah kurang daripada
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Membuat susun atur yang menerangkan rekod untuk contoh `n` `self`, dengan jumlah padding yang sesuai antara masing-masing untuk memastikan bahawa setiap contoh diberi ukuran dan penjajaran yang diminta.
    /// Apabila berjaya, mengembalikan `(k, offs)` di mana `k` adalah susun atur array dan `offs` adalah jarak antara permulaan setiap elemen dalam array.
    ///
    /// Pada limpahan aritmetik, mengembalikan `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ini tidak boleh meluap.Memetik dari Tata Letak invarian:
        // > `size`, apabila dibundarkan ke gandaan `align` terdekat,
        // > tidak boleh melimpah (iaitu, nilai bulat mestilah kurang daripada
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // KESELAMATAN: self.align sudah diketahui sah dan telah diperuntukkan jumlah_size
        // sudah empuk.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Membuat susun atur yang menerangkan rekod untuk `self` diikuti oleh `next`, termasuk semua padding yang diperlukan untuk memastikan bahawa `next` akan diselaraskan dengan betul, tetapi *tidak ada padding trailing*.
    ///
    /// Agar sesuai dengan susun atur perwakilan C `repr(C)`, anda harus menghubungi `pad_to_align` setelah memperluas susun atur dengan semua bidang.
    /// (Tidak ada cara untuk menyamai susun atur perwakilan Rust `repr(Rust)`, as it is unspecified.) lalai
    ///
    /// Perhatikan bahawa penjajaran susun atur yang dihasilkan akan menjadi maksimum dari `self` dan `next`, untuk memastikan penyelarasan kedua-dua bahagian.
    ///
    /// Mengembalikan `Ok((k, offset))`, di mana `k` adalah susun atur rakaman gabungan dan `offset` adalah lokasi relatif, dalam bait, permulaan `next` yang tertanam dalam rekod gabungan (dengan anggapan bahawa rekod itu sendiri bermula pada ofset 0).
    ///
    ///
    /// Pada limpahan aritmetik, mengembalikan `LayoutError`.
    ///
    /// # Examples
    ///
    /// Untuk mengira susun atur struktur `#[repr(C)]` dan offset medan dari susun atur bidangnya:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ingatlah untuk menyelesaikan dengan `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // menguji bahawa ia berfungsi
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Membuat susun atur yang menerangkan rekod untuk contoh `n` `self`, tanpa padding antara setiap instance.
    ///
    /// Perhatikan bahawa, tidak seperti `repeat`, `repeat_packed` tidak menjamin bahawa kejadian `self` berulang akan diselaraskan dengan betul, walaupun contoh `self` tertentu dijajarkan dengan betul.
    /// Dengan kata lain, jika susun atur yang dikembalikan oleh `repeat_packed` digunakan untuk memperuntukkan array, tidak dijamin semua elemen dalam array akan diselaraskan dengan betul.
    ///
    /// Pada limpahan aritmetik, mengembalikan `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Membuat susun atur yang menggambarkan rekod untuk `self` diikuti oleh `next` tanpa tambahan padding antara keduanya.
    /// Oleh kerana tiada padding dimasukkan, penjajaran `next` tidak relevan, dan tidak digabungkan sama sekali * ke dalam susun atur yang dihasilkan.
    ///
    ///
    /// Pada limpahan aritmetik, mengembalikan `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Membuat susun atur yang menerangkan rekod `[T; n]`.
    ///
    /// Pada limpahan aritmetik, mengembalikan `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parameter yang diberikan kepada `Layout::from_size_align` atau beberapa konstruktor `Layout` lain tidak memenuhi kekangan yang didokumentasikan.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (kami memerlukan ini untuk implan ralat trait hilir)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}