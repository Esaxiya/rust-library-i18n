//! API peruntukan memori

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Kesalahan `AllocError` menunjukkan kegagalan peruntukan yang mungkin disebabkan oleh kehabisan sumber atau sesuatu yang salah ketika menggabungkan argumen input yang diberikan dengan pengagihan ini.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (kami memerlukan ini untuk implan ralat trait hilir)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Pelaksanaan `Allocator` dapat memperuntukkan, mengembangkan, mengecil, dan menyahbekal blok data sewenang-wenang yang dijelaskan melalui [`Layout`][].
///
/// `Allocator` dirancang untuk dilaksanakan pada ZST, rujukan, atau pointer pintar kerana mempunyai alokasi seperti `MyAlloc([u8; N])` tidak dapat dipindahkan, tanpa mengemas kini penunjuk ke memori yang diperuntukkan.
///
/// Tidak seperti [`GlobalAlloc`][], peruntukan bersaiz sifar dibenarkan di `Allocator`.
/// Sekiranya peruntukan yang mendasari tidak menyokong ini (seperti jemalloc) atau mengembalikan penunjuk kosong (seperti `libc::malloc`), ini mesti ditangkap oleh pelaksanaannya.
///
/// ### Memori yang diperuntukkan sekarang
///
/// Beberapa kaedah memerlukan blok memori *diperuntukkan* sekarang melalui alokasi.Ini bermaksud:
///
/// * alamat permulaan untuk blok memori itu sebelumnya dikembalikan oleh [`allocate`], [`grow`], atau [`shrink`], dan
///
/// * blok memori kemudiannya tidak dialokasikan, di mana blok sama ada dialihkan langsung secara langsung dengan diteruskan ke [`deallocate`] atau diubah dengan diteruskan ke [`grow`] atau [`shrink`] yang mengembalikan `Ok`.
///
/// Sekiranya `grow` atau `shrink` telah mengembalikan `Err`, penunjuk lulus tetap sah.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Pemasangan memori
///
/// Beberapa kaedah memerlukan bahawa susun atur *sesuai* blok memori.
/// Apa yang dimaksudkan untuk susun atur ke "fit" berarti blok memori (atau setara, untuk blok memori ke "fit" susun atur) adalah bahawa syarat berikut mesti berlaku:
///
/// * Blok mesti diperuntukkan dengan penjajaran yang sama dengan [`layout.align()`], dan
///
/// * [`layout.size()`] yang disediakan mesti berada dalam lingkungan `min ..= max`, di mana:
///   - `min` adalah ukuran susun atur yang paling baru digunakan untuk memperuntukkan blok, dan
///   - `max` adalah ukuran sebenar terkini yang dikembalikan dari [`allocate`], [`grow`], atau [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blok memori yang dikembalikan dari alokasi mesti menunjukkan memori yang sah dan mengekalkan kesahihannya sehingga kejadian dan semua klonnya dijatuhkan,
///
/// * mengklon atau menggerakkan pengagihan tidak boleh membatalkan blok memori yang dikembalikan dari pengagihan ini.Pengagihan klon mesti berkelakuan seperti pembahagi yang sama, dan
///
/// * sebarang penunjuk ke blok memori yang [*currently allocated*] boleh disalurkan ke kaedah alokasi lain.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Percubaan untuk memperuntukkan sekumpulan memori.
    ///
    /// Setelah berjaya, mengembalikan [`NonNull<[u8]>`][NonNull] yang memenuhi jaminan ukuran dan penjajaran `layout`.
    ///
    /// Blok yang dikembalikan mungkin mempunyai ukuran yang lebih besar daripada yang ditentukan oleh `layout.size()`, dan mungkin atau tidak kandungannya dimulakan.
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` menunjukkan bahawa sama ada memori habis atau `layout` tidak memenuhi had ukuran atau penjajaran alokasi.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan `Err` pada kehabisan memori daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Berkelakuan seperti `allocate`, tetapi juga memastikan bahawa ingatan yang dikembalikan adalah awal yang sifar.
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` menunjukkan bahawa sama ada memori habis atau `layout` tidak memenuhi had ukuran atau penjajaran alokasi.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan `Err` pada kehabisan memori daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // KESELAMATAN: `alloc` mengembalikan blok memori yang sah
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Menurunkan memori yang dirujuk oleh `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` mesti menandakan sekatan memori [*currently allocated*] melalui pembahagi ini, dan
    /// * `layout` mesti [*fit*] sekatan memori itu.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Percubaan untuk meluaskan blok memori.
    ///
    /// Mengembalikan [`NonNull<[u8]>`][NonNull] baru yang mengandungi penunjuk dan ukuran sebenar memori yang diperuntukkan.Penunjuk sesuai untuk menyimpan data yang dijelaskan oleh `new_layout`.
    /// Untuk mencapai tujuan ini, pengagihan dapat memperluas peruntukan yang dirujuk oleh `ptr` agar sesuai dengan susun atur baru.
    ///
    /// Sekiranya ini mengembalikan `Ok`, maka pemilikan blok memori yang dirujuk oleh `ptr` telah dipindahkan ke alokasi ini.
    /// Memori itu mungkin atau mungkin telah dibebaskan, dan harus dianggap tidak dapat digunakan kecuali jika ia dipindahkan kembali ke pemanggil lagi melalui nilai kembali kaedah ini.
    ///
    /// Sekiranya kaedah ini mengembalikan `Err`, maka pemilikan blok memori belum dipindahkan ke alokasi ini, dan kandungan blok memori tidak berubah.
    ///
    /// # Safety
    ///
    /// * `ptr` mesti menunjukkan sekumpulan memori [*currently allocated*] melalui pengagihan ini.
    /// * `old_layout` mesti [*fit*] blok memori itu (Hujah `new_layout` tidak sesuai.)
    /// * `new_layout.size()` mestilah lebih besar daripada atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika susun atur baru tidak memenuhi batasan ukuran dan penjajaran alokasi, atau jika pertumbuhan gagal.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan `Err` pada kehabisan memori daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KESELAMATAN: kerana `new_layout.size()` mestilah lebih besar daripada atau sama dengan
        // `old_layout.size()`, kedua-dua peruntukan memori lama dan baru adalah sah untuk membaca dan menulis untuk `old_layout.size()` bait.
        // Juga, kerana peruntukan lama belum dialokasikan, ia tidak boleh bertindih `new_ptr`.
        // Oleh itu, panggilan ke `copy_nonoverlapping` adalah selamat.
        // Kontrak keselamatan untuk `dealloc` mesti dipegang oleh pemanggil.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Berkelakuan seperti `grow`, tetapi juga memastikan bahawa kandungan baru ditetapkan ke sifar sebelum dikembalikan.
    ///
    /// Blok memori akan mengandungi kandungan berikut setelah panggilan berjaya ke
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` terpelihara dari peruntukan asal.
    ///   * Bytes `old_layout.size()..old_size` sama ada akan dipelihara atau dipusatkan, bergantung pada pelaksanaan peruntukan.
    ///   `old_size` merujuk pada ukuran blok memori sebelum panggilan `grow_zeroed`, yang mungkin lebih besar daripada ukuran yang awalnya diminta ketika dialokasikan.
    ///   * Bytes `old_size..new_size` adalah sifar.`new_size` merujuk kepada ukuran blok memori yang dikembalikan oleh panggilan `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` mesti menunjukkan sekumpulan memori [*currently allocated*] melalui pengagihan ini.
    /// * `old_layout` mesti [*fit*] blok memori itu (Hujah `new_layout` tidak sesuai.)
    /// * `new_layout.size()` mestilah lebih besar daripada atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika susun atur baru tidak memenuhi batasan ukuran dan penjajaran alokasi, atau jika pertumbuhan gagal.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan `Err` pada kehabisan memori daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // KESELAMATAN: kerana `new_layout.size()` mestilah lebih besar daripada atau sama dengan
        // `old_layout.size()`, kedua-dua peruntukan memori lama dan baru adalah sah untuk membaca dan menulis untuk `old_layout.size()` bait.
        // Juga, kerana peruntukan lama belum dialokasikan, ia tidak boleh bertindih `new_ptr`.
        // Oleh itu, panggilan ke `copy_nonoverlapping` adalah selamat.
        // Kontrak keselamatan untuk `dealloc` mesti dipegang oleh pemanggil.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Percubaan untuk mengecilkan blok memori.
    ///
    /// Mengembalikan [`NonNull<[u8]>`][NonNull] baru yang mengandungi penunjuk dan ukuran sebenar memori yang diperuntukkan.Penunjuk sesuai untuk menyimpan data yang dijelaskan oleh `new_layout`.
    /// Untuk mencapainya, pengagihan mungkin mengecilkan peruntukan yang dirujuk oleh `ptr` agar sesuai dengan susun atur baru.
    ///
    /// Sekiranya ini mengembalikan `Ok`, maka pemilikan blok memori yang dirujuk oleh `ptr` telah dipindahkan ke alokasi ini.
    /// Memori itu mungkin atau mungkin telah dibebaskan, dan harus dianggap tidak dapat digunakan kecuali jika ia dipindahkan kembali ke pemanggil lagi melalui nilai kembali kaedah ini.
    ///
    /// Sekiranya kaedah ini mengembalikan `Err`, maka pemilikan blok memori belum dipindahkan ke alokasi ini, dan kandungan blok memori tidak berubah.
    ///
    /// # Safety
    ///
    /// * `ptr` mesti menunjukkan sekumpulan memori [*currently allocated*] melalui pengagihan ini.
    /// * `old_layout` mesti [*fit*] blok memori itu (Hujah `new_layout` tidak sesuai.)
    /// * `new_layout.size()` mestilah lebih kecil daripada atau sama dengan `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Mengembalikan `Err` jika susun atur baru tidak memenuhi kekangan ukuran dan penjajaran alokasi, atau jika penyusutan gagal.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan `Err` pada kehabisan memori daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // KESELAMATAN: kerana `new_layout.size()` mesti lebih rendah daripada atau sama dengan
        // `old_layout.size()`, kedua-dua peruntukan memori lama dan baru adalah sah untuk membaca dan menulis untuk `new_layout.size()` bait.
        // Juga, kerana peruntukan lama belum dialokasikan, ia tidak boleh bertindih `new_ptr`.
        // Oleh itu, panggilan ke `copy_nonoverlapping` adalah selamat.
        // Kontrak keselamatan untuk `dealloc` mesti dipegang oleh pemanggil.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Membuat penyesuai "by reference" untuk contoh `Allocator` ini.
    ///
    /// Penyesuai yang dikembalikan juga menggunakan `Allocator` dan hanya akan meminjamnya.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // KESELAMATAN: kontrak keselamatan mesti dipegang oleh pemanggil
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keselamatan mesti dipegang oleh pemanggil
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keselamatan mesti dipegang oleh pemanggil
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // KESELAMATAN: kontrak keselamatan mesti dipegang oleh pemanggil
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}