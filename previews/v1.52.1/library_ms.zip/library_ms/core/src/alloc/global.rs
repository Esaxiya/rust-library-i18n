use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Peruntukan memori yang boleh didaftarkan sebagai lalai perpustakaan standard melalui atribut `#[global_allocator]`.
///
/// Beberapa kaedah memerlukan blok memori *diperuntukkan* sekarang melalui alokasi.Ini bermaksud:
///
/// * alamat permulaan untuk blok memori itu sebelumnya dikembalikan oleh panggilan sebelumnya ke kaedah peruntukan seperti `alloc`, dan
///
/// * blok memori kemudiannya tidak dialokasikan, di mana blok dialihkan sama ada dengan disalurkan ke kaedah penyahpisahan seperti `dealloc` atau dengan diteruskan ke kaedah pengagihan semula yang mengembalikan penunjuk bukan nol.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait adalah `unsafe` trait kerana beberapa sebab, dan pelaksana mesti memastikan bahawa mereka mematuhi kontrak ini:
///
/// * Ini adalah tingkah laku yang tidak ditentukan jika peruntukan global berehat.Sekatan ini mungkin dicabut di future, tetapi pada masa ini panic dari mana-mana fungsi ini boleh menyebabkan memori tidak selamat.
///
/// * `Layout` pertanyaan dan pengiraan secara umum mestilah betul.Pemanggil trait ini dibenarkan untuk bergantung pada kontrak yang ditentukan pada setiap kaedah, dan pelaksana harus memastikan kontrak tersebut tetap berlaku.
///
/// * Anda mungkin tidak bergantung pada peruntukan yang sebenarnya berlaku, walaupun terdapat peruntukan timbunan eksplisit di sumbernya.
/// Pengoptimum dapat mengesan peruntukan yang tidak digunakan yang dapat dihapuskan sepenuhnya atau berpindah ke timbunan dan dengan itu tidak pernah meminta pengagihan.
/// Pengoptimum mungkin menganggap bahawa peruntukan tidak sempurna, jadi kod yang dulu gagal kerana kegagalan pengagihan sekarang boleh tiba-tiba berfungsi kerana pengoptimum bekerja untuk keperluan peruntukan.
/// Lebih konkrit, contoh kod berikut tidak berasas, tidak kira sama ada peruntukan khusus anda membenarkan pengiraan berapa banyak peruntukan yang berlaku.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Perhatikan bahawa pengoptimuman yang disebutkan di atas bukan satu-satunya pengoptimuman yang dapat diterapkan.Anda mungkin tidak bergantung pada peruntukan timbunan yang berlaku sekiranya ia dapat dikeluarkan tanpa mengubah tingkah laku program.
///   Sama ada peruntukan berlaku atau tidak bukan sebahagian daripada tingkah laku program, bahkan jika dapat dikesan melalui alokasi yang melacak peruntukan dengan mencetak atau mempunyai kesan sampingan.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alokasikan memori seperti yang dijelaskan oleh `layout` yang diberikan.
    ///
    /// Mengembalikan penunjuk ke memori yang baru diperuntukkan, atau nol untuk menunjukkan kegagalan peruntukan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tingkah laku yang tidak ditentukan boleh berlaku sekiranya pemanggil tidak memastikan bahawa `layout` mempunyai ukuran bukan sifar.
    ///
    /// (Subtra peluasan mungkin memberikan batasan yang lebih spesifik mengenai tingkah laku, misalnya, menjamin alamat pengirim atau penunjuk nol sebagai tindak balas terhadap permintaan peruntukan ukuran sifar.)
    ///
    /// Blok memori yang diperuntukkan mungkin atau mungkin tidak diinisialisasi.
    ///
    /// # Errors
    ///
    /// Mengembalikan penunjuk nol menunjukkan bahawa memori sama ada habis atau `layout` tidak memenuhi had ukuran atau penjajaran alokasi ini.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan kehabisan ingatan daripada membatalkan, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Nyah alihkan blok memori pada penunjuk `ptr` yang diberikan dengan `layout` yang diberikan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tingkah laku tidak ditentukan boleh berlaku sekiranya pemanggil tidak memastikan semua perkara berikut:
    ///
    ///
    /// * `ptr` mesti menunjukkan sekumpulan memori yang diperuntukkan sekarang melalui pengagihan ini,
    ///
    /// * `layout` mestilah susun atur yang sama yang digunakan untuk memperuntukkan sekatan memori tersebut.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Berkelakuan seperti `alloc`, tetapi juga memastikan bahawa kandungannya ditetapkan ke sifar sebelum dikembalikan.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana alasan yang sama seperti `alloc`.
    /// Namun blok memori yang diperuntukkan dijamin akan diinisialisasi.
    ///
    /// # Errors
    ///
    /// Mengembalikan penunjuk nol menunjukkan bahawa memori sama ada habis atau `layout` tidak memenuhi batasan ukuran atau penjajaran, seperti di `alloc`.
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat peruntukan digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // KESELAMATAN: kontrak keselamatan untuk `alloc` mesti dipegang oleh pemanggil.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KESELAMATAN: sebagai peruntukan berjaya, wilayah dari `ptr`
            // saiz `size` dijamin sah untuk penulisan.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Kecilkan atau kembangkan sekumpulan memori ke `new_size` yang diberikan.
    /// Blok tersebut dijelaskan oleh penunjuk `ptr` dan `layout` yang diberikan.
    ///
    /// Sekiranya ini mengembalikan penunjuk yang tidak kosong, maka pemilikan blok memori yang dirujuk oleh `ptr` telah dipindahkan ke alokasi ini.
    /// Memori itu mungkin atau mungkin telah dialihkan, dan harus dianggap tidak dapat digunakan (kecuali tentu saja ia dipindahkan kembali ke pemanggil lagi melalui nilai kembali kaedah ini).
    /// Blok memori baru diperuntukkan dengan `layout`, tetapi dengan `size` dikemas kini ke `new_size`.
    /// Susun atur baru ini harus digunakan ketika menyahpindah blok memori baru dengan `dealloc`.
    /// Julat `0..min(layout.size(), new_size) `blok memori baru dijamin mempunyai nilai yang sama dengan blok asal.
    ///
    /// Sekiranya kaedah ini mengembalikan nol, maka pemilikan blok memori belum dipindahkan ke alokasi ini, dan kandungan blok memori tidak berubah.
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat kerana tingkah laku tidak ditentukan boleh berlaku sekiranya pemanggil tidak memastikan semua perkara berikut:
    ///
    /// * `ptr` mesti diperuntukkan sekarang melalui peruntukan ini,
    ///
    /// * `layout` mestilah susun atur yang sama yang digunakan untuk memperuntukkan blok memori itu,
    ///
    /// * `new_size` mesti lebih besar daripada sifar.
    ///
    /// * `new_size`, apabila dibundarkan ke gandaan `layout.align()` terdekat, tidak boleh melimpah (iaitu, nilai bulat mestilah kurang dari `usize::MAX`).
    ///
    /// (Subtra peluasan mungkin memberikan batasan yang lebih spesifik mengenai tingkah laku, misalnya, menjamin alamat pengirim atau penunjuk nol sebagai tindak balas terhadap permintaan peruntukan ukuran sifar.)
    ///
    /// # Errors
    ///
    /// Mengembalikan nol jika susun atur baru tidak memenuhi batasan ukuran dan penjajaran alokasi, atau jika peruntukan semula gagal.
    ///
    /// Pelaksanaan digalakkan untuk mengembalikan kehabisan ingatan daripada panik atau batal, tetapi ini bukan syarat yang ketat.
    /// (Khususnya:*sah* untuk menerapkan trait ini di atas perpustakaan peruntukan asli yang mendasari kehabisan memori.)
    ///
    /// Pelanggan yang ingin membatalkan pengiraan sebagai tindak balas terhadap ralat pengalihan semula digalakkan untuk memanggil fungsi [`handle_alloc_error`], dan bukan secara langsung memanggil `panic!` atau yang serupa.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // KESELAMATAN: pemanggil mesti memastikan bahawa `new_size` tidak melimpah.
        // `layout.align()` berasal dari `Layout` dan dengan itu dijamin sah.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // KESELAMATAN: pemanggil mesti memastikan bahawa `new_layout` lebih besar daripada sifar.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // KESELAMATAN: blok yang diperuntukkan sebelumnya tidak dapat bertindih dengan blok yang baru diperuntukkan.
            // Kontrak keselamatan untuk `dealloc` mesti dipegang oleh pemanggil.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}