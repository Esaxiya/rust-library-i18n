//! Traits untuk penukaran antara jenis.
//!
//! traits dalam modul ini menyediakan cara untuk menukar dari satu jenis ke jenis yang lain.
//! Setiap trait mempunyai tujuan yang berbeza:
//!
//! - Laksanakan [`AsRef`] trait untuk penukaran rujukan-ke-rujukan yang murah
//! - Terapkan [`AsMut`] trait untuk penukaran berubah-ubah yang boleh berubah
//! - Terapkan [`From`] trait untuk memakan penukaran nilai ke nilai
//! - Terapkan [`Into`] trait untuk menghabiskan penukaran nilai ke nilai ke jenis di luar crate semasa
//! - [`TryFrom`] dan [`TryInto`] traits berkelakuan seperti [`From`] dan [`Into`], tetapi harus dilaksanakan apabila penukaran boleh gagal.
//!
//! traits dalam modul ini sering digunakan sebagai trait bounds untuk fungsi generik sehingga argumen pelbagai jenis disokong.Lihat dokumentasi setiap trait untuk contoh.
//!
//! Sebagai pengarang perpustakaan, anda harus selalu memilih untuk melaksanakan [`From<T>`][`From`] atau [`TryFrom<T>`][`TryFrom`] daripada [`Into<U>`][`Into`] atau [`TryInto<U>`][`TryInto`], kerana [`From`] dan [`TryFrom`] memberikan fleksibiliti yang lebih besar dan menawarkan pelaksanaan [`Into`] atau [`TryInto`] yang setara secara percuma, berkat pelaksanaan selimut di perpustakaan standard.
//! Semasa menargetkan versi sebelum Rust 1.41, mungkin perlu menerapkan [`Into`] atau [`TryInto`] secara langsung ketika menukar ke jenis di luar crate semasa.
//!
//! # Pelaksanaan Generik
//!
//! - [`AsRef`] dan [`AsMut`] auto-dereference jika jenis dalaman adalah rujukan
//! - [`From`]`<U>untuk T` menyiratkan [`Into`]`</u><T><U>untuk U`</u>
//! - [`TryFrom`]`<U>untuk T` menyiratkan [`TryInto`]`</u><T><U>untuk U`</u>
//! - [`From`] dan [`Into`] adalah refleksif, yang bermaksud bahawa semua jenis boleh `into` sendiri dan `from` sendiri
//!
//! Lihat setiap trait untuk contoh penggunaan.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Fungsi identiti.
///
/// Dua perkara penting untuk diperhatikan mengenai fungsi ini:
///
/// - Ia tidak selalu setara dengan penutupan seperti `|x| x`, kerana penutupan boleh memaksa `x` menjadi jenis yang lain.
///
/// - Ia memindahkan input `x` yang diteruskan ke fungsi.
///
/// Walaupun kelihatan aneh untuk mempunyai fungsi yang hanya mengembalikan input, ada beberapa kegunaan yang menarik.
///
///
/// # Examples
///
/// Menggunakan `identity` untuk melakukan apa-apa dalam urutan fungsi lain yang menarik:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Mari kita berpura-pura bahawa menambahkan satu adalah fungsi yang menarik.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Menggunakan `identity` sebagai casing asas "do nothing" dalam keadaan bersyarat:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Lakukan lebih banyak perkara menarik ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Menggunakan `identity` untuk mengekalkan varian `Some` dari iterator `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Digunakan untuk melakukan penukaran rujukan-ke-rujukan yang murah.
///
/// trait ini serupa dengan [`AsMut`] yang digunakan untuk menukar antara rujukan yang boleh berubah.
/// Sekiranya anda perlu melakukan penukaran yang mahal, lebih baik menerapkan [`From`] dengan jenis `&T` atau menulis fungsi khusus.
///
/// `AsRef` mempunyai tanda tangan yang sama dengan [`Borrow`], tetapi [`Borrow`] berbeza dalam beberapa aspek:
///
/// - Tidak seperti `AsRef`, [`Borrow`] memiliki selimut implan untuk `T` mana pun, dan dapat digunakan untuk menerima rujukan atau nilai.
/// - [`Borrow`] juga menghendaki [`Hash`], [`Eq`] dan [`Ord`] untuk nilai yang dipinjam setara dengan nilai yang dimiliki.
/// Atas sebab ini, jika anda ingin meminjam hanya satu bidang struktur, anda boleh melaksanakan `AsRef`, tetapi tidak [`Borrow`].
///
/// **Note: trait ini tidak boleh gagal **.Sekiranya penukaran gagal, gunakan kaedah khusus yang mengembalikan [`Option<T>`] atau [`Result<T, E>`].
///
/// # Pelaksanaan Generik
///
/// - `AsRef` dereferens automatik jika jenis dalaman adalah rujukan atau rujukan yang boleh berubah (contohnya: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Dengan menggunakan trait bounds kita dapat menerima argumen dari pelbagai jenis selagi ia dapat ditukar kepada jenis yang ditentukan `T`.
///
/// Contohnya: Dengan membuat fungsi generik yang memerlukan `AsRef<str>`, kami menyatakan bahawa kami ingin menerima semua rujukan yang boleh ditukar menjadi [`&str`] sebagai argumen.
/// Oleh kerana kedua-dua [`String`] dan [`&str`] melaksanakan `AsRef<str>`, kami dapat menerima keduanya sebagai argumen input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Melakukan penukaran.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Digunakan untuk melakukan penukaran rujukan yang berubah-ubah-menjadi-berubah.
///
/// trait ini serupa dengan [`AsRef`] tetapi digunakan untuk menukar antara rujukan yang boleh berubah.
/// Sekiranya anda perlu melakukan penukaran yang mahal, lebih baik menerapkan [`From`] dengan jenis `&mut T` atau menulis fungsi khusus.
///
/// **Note: trait ini tidak boleh gagal **.Sekiranya penukaran gagal, gunakan kaedah khusus yang mengembalikan [`Option<T>`] atau [`Result<T, E>`].
///
/// # Pelaksanaan Generik
///
/// - `AsMut` dereferens automatik jika jenis dalaman adalah rujukan yang boleh berubah (contohnya: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Dengan menggunakan `AsMut` sebagai trait bound untuk fungsi generik, kita dapat menerima semua rujukan yang dapat diubah yang dapat ditukar menjadi jenis `&mut T`.
/// Kerana [`Box<T>`] menerapkan `AsMut<T>`, kita dapat menulis fungsi `add_one` yang mengambil semua argumen yang dapat ditukar menjadi `&mut u64`.
/// Kerana [`Box<T>`] menerapkan `AsMut<T>`, `add_one` juga menerima argumen jenis `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Melakukan penukaran.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Penukaran nilai ke nilai yang menggunakan nilai input.Kebalikan dari [`From`].
///
/// Seseorang harus mengelakkan pelaksanaan [`Into`] dan melaksanakan [`From`] sebagai gantinya.
/// Menerapkan [`From`] secara automatik memberikan satu pelaksanaan [`Into`] berkat pelaksanaan selimut di perpustakaan standard.
///
/// Lebih suka menggunakan [`Into`] berbanding [`From`] ketika menentukan trait bounds pada fungsi generik untuk memastikan bahawa jenis yang hanya melaksanakan [`Into`] dapat digunakan juga.
///
/// **Note: trait ini tidak boleh gagal **.Sekiranya penukaran gagal, gunakan [`TryInto`].
///
/// # Pelaksanaan Generik
///
/// - [`Dari`]`<T>untuk U` menunjukkan `Into<U> for T`
/// - [`Into`] bersifat refleksif, yang bermaksud bahawa `Into<T> for T` dilaksanakan
///
/// # Melaksanakan [`Into`] untuk penukaran ke jenis luaran dalam versi lama Rust
///
/// Sebelum Rust 1.41, jika jenis tujuan bukan sebahagian daripada crate semasa, maka anda tidak dapat melaksanakan [`From`] secara langsung.
/// Contohnya, ambil kod ini:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ini akan gagal disusun dalam versi bahasa yang lebih lama kerana peraturan yatim piatu Rust sedikit lebih ketat.
/// Untuk memotongnya, anda boleh melaksanakan [`Into`] secara langsung:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Penting untuk memahami bahawa [`Into`] tidak menyediakan pelaksanaan [`From`] (seperti yang dilakukan [`From`] dengan [`Into`]).
/// Oleh itu, anda harus selalu berusaha melaksanakan [`From`] dan kemudian kembali ke [`Into`] jika [`From`] tidak dapat dilaksanakan.
///
/// # Examples
///
/// [`String`] mengimplementasikan [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Untuk menyatakan bahawa kami ingin fungsi generik mengambil semua argumen yang dapat ditukar ke jenis `T` yang ditentukan, kami dapat menggunakan trait bound dari [`Into`]`<T>".
///
/// Contohnya: Fungsi `is_hello` mengambil semua argumen yang dapat diubah menjadi [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Melakukan penukaran.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Digunakan untuk melakukan penukaran nilai ke nilai sambil memakan nilai input.Ini adalah kebalikan [`Into`].
///
/// Seseorang harus lebih suka melaksanakan `From` berbanding [`Into`] kerana melaksanakan `From` secara automatik memberikan pelaksanaan [`Into`] berkat pelaksanaan menyeluruh di perpustakaan standard.
///
///
/// Hanya melaksanakan [`Into`] ketika menargetkan versi sebelum Rust 1.41 dan menukar ke jenis di luar crate semasa.
/// `From` tidak dapat melakukan jenis penukaran ini dalam versi terdahulu kerana peraturan yatim piatu Rust.
/// Lihat [`Into`] untuk maklumat lebih lanjut.
///
/// Lebih suka menggunakan [`Into`] daripada menggunakan `From` semasa menentukan trait bounds pada fungsi generik.
/// Dengan cara ini, jenis yang secara langsung melaksanakan [`Into`] dapat digunakan sebagai argumen juga.
///
/// `From` juga sangat berguna ketika melakukan pengendalian ralat.Semasa membina fungsi yang mampu gagal, jenis pengembalian umumnya akan berbentuk `Result<T, E>`.
/// `From` trait mempermudahkan pengendalian ralat dengan membenarkan fungsi mengembalikan satu jenis ralat yang merangkumi pelbagai jenis ralat.Lihat bahagian "Examples" dan [the book][book] untuk maklumat lebih lanjut.
///
/// **Note: trait ini tidak boleh gagal **.Sekiranya penukaran gagal, gunakan [`TryFrom`].
///
/// # Pelaksanaan Generik
///
/// - `From<T> for U` membayangkan [`Into`]`<U>untuk T`</u>
/// - `From` bersifat refleksif, yang bermaksud bahawa `From<T> for T` dilaksanakan
///
/// # Examples
///
/// [`String`] menggunakan `From<&str>`:
///
/// Penukaran eksplisit dari `&str` ke String dilakukan seperti berikut:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Semasa melakukan pengendalian ralat, sering kali berguna untuk menerapkan `From` untuk jenis ralat anda sendiri.
/// Dengan menukar jenis ralat yang mendasari ke jenis ralat tersuai kita sendiri yang merangkumi jenis ralat yang mendasari, kita dapat mengembalikan satu jenis ralat tanpa kehilangan maklumat mengenai penyebabnya.
/// Pengendali '?' secara automatik menukar jenis ralat yang mendasari ke jenis ralat tersuai kami dengan memanggil `Into<CliError>::into` yang disediakan secara automatik ketika melaksanakan `From`.
/// Pengkompil kemudian menyimpulkan pelaksanaan `Into` mana yang harus digunakan.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Melakukan penukaran.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Percubaan penukaran yang memakan `self`, yang mungkin mahal atau mungkin tidak mahal.
///
/// Penulis perpustakaan biasanya tidak secara langsung melaksanakan trait ini, tetapi lebih suka melaksanakan [`TryFrom`] trait, yang menawarkan fleksibiliti yang lebih besar dan menyediakan pelaksanaan `TryInto` yang setara secara percuma, berkat pelaksanaan selimut di perpustakaan standard.
/// Untuk maklumat lebih lanjut mengenai ini, lihat dokumentasi untuk [`Into`].
///
/// # Melaksanakan `TryInto`
///
/// Ini mengalami sekatan dan alasan yang sama dengan melaksanakan [`Into`], lihat di sana untuk perincian.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Jenis dikembalikan sekiranya berlaku kesilapan penukaran.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Melakukan penukaran.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Penukaran jenis mudah dan selamat yang mungkin gagal dengan cara terkawal dalam beberapa keadaan.Ini adalah kebalikan [`TryInto`].
///
/// Ini berguna semasa anda melakukan penukaran jenis yang mungkin berjaya tetapi mungkin juga memerlukan pengendalian khas.
/// Sebagai contoh, tidak ada cara untuk menukar [`i64`] menjadi [`i32`] menggunakan [`From`] trait, kerana [`i64`] mungkin berisi nilai yang tidak dapat ditunjukkan oleh [`i32`] dan oleh itu penukaran akan kehilangan data.
///
/// Ini mungkin ditangani dengan memangkas [`i64`] ke [`i32`] (pada dasarnya memberikan nilai modulo `` i64 '' [`i32::MAX`]) atau dengan hanya mengembalikan [`i32::MAX`], atau dengan kaedah lain.
/// [`From`] trait ditujukan untuk penukaran yang sempurna, jadi `TryFrom` trait memberitahu pengaturcara bila penukaran jenis boleh menjadi buruk dan memungkinkan mereka memutuskan bagaimana mengatasinya.
///
/// # Pelaksanaan Generik
///
/// - `TryFrom<T> for U` menyiratkan [`TryInto`]`<U>untuk T`</u>
/// - [`try_from`] bersifat refleksif, yang bermaksud bahawa `TryFrom<T> for T` dilaksanakan dan tidak boleh gagal-jenis `Error` yang berkaitan untuk memanggil `T::try_from()` pada nilai jenis `T` adalah [`Infallible`].
/// Apabila jenis [`!`] distabilkan [`Infallible`] dan [`!`] akan bersamaan.
///
/// `TryFrom<T>` boleh dilaksanakan seperti berikut:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Seperti yang dijelaskan, [`i32`] menerapkan `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Diam-diam memotong `big_number`, memerlukan pengesanan dan pengendalian pemotongan setelah fakta.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Mengembalikan ralat kerana `big_number` terlalu besar untuk dimasukkan ke dalam `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Mengembalikan `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Jenis dikembalikan sekiranya berlaku kesilapan penukaran.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Melakukan penukaran.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLIKASI UMUM
////////////////////////////////////////////////////////////////////////////////

// Semasa mengangkat&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Sebagai mengangkat lebih dari &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ganti implan di atas untuk&/&mut dengan yang lebih umum berikut:
// // Semasa mengangkat Deref
// tersirat <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>untuk D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut mengangkat lebih dari &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ganti implan di atas untuk &mut dengan yang berikut lebih umum:
// // AsMut mengangkat DerefMut
// tersirat <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>untuk D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Dari yang tersirat Ke
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Dari (dan dengan demikian Into) adalah refleksif
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota kestabilan:** Implikasinya belum ada, tetapi kami "reserving space" untuk menambahkannya di future.
/// Lihat [rust-lang/rust#64715][#64715] untuk maklumat lanjut.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): sebaliknya lakukan pembaikan berprinsip.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom bermaksud TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Penukaran yang tidak betul adalah semantik sama dengan penukaran yang tidak betul dengan jenis ralat yang tidak berpenghuni.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLIKASI KONKRIT
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// JENIS KESALAHAN TIDAK ADA
////////////////////////////////////////////////////////////////////////////////

/// Jenis kesalahan untuk kesilapan yang tidak pernah boleh berlaku.
///
/// Oleh kerana enum ini tidak mempunyai varian, nilai jenis ini tidak akan pernah wujud.
/// Ini berguna untuk API generik yang menggunakan [`Result`] dan memformat jenis ralat, untuk menunjukkan bahawa hasilnya selalu [`Ok`].
///
/// Sebagai contoh, [`TryFrom`] trait (penukaran yang mengembalikan [`Result`]) mempunyai implementasi selimut untuk semua jenis di mana pelaksanaan [`Into`] terbalik wujud.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Keserasian Future
///
/// Enum ini mempunyai peranan yang sama dengan [the `!`“never”type][never], yang tidak stabil dalam versi Rust ini.
/// Apabila `!` distabilkan, kami merancang untuk menjadikan `Infallible` sebagai alias jenisnya:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... dan akhirnya menghentikan `Infallible`.
///
/// Namun ada satu kes di mana sintaks `!` dapat digunakan sebelum `!` distabilkan sebagai jenis penuh: dalam posisi jenis pengembalian fungsi.
/// Secara khusus, kemungkinan pelaksanaan untuk dua jenis penunjuk fungsi yang berbeza:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Dengan `Infallible` menjadi enum, kod ini sah.
/// Namun apabila `Infallible` menjadi alias untuk never type, kedua `impl` akan mula bertindih dan oleh itu akan dilarang oleh peraturan koherensi trait bahasa.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}