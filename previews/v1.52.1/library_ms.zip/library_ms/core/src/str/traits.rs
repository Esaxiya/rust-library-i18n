//! Pelaksanaan Trait untuk `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Melaksanakan susunan tali.
///
/// Rentetan disusun [lexicographically](Ord#lexicographical-comparison) mengikut nilai baitnya.
/// Ini memerintahkan titik kod Unicode berdasarkan kedudukannya dalam carta kod.
/// Ini tidak semestinya sama dengan pesanan "alphabetical", yang berbeza mengikut bahasa dan tempat.
/// Menyusun rentetan mengikut piawaian yang diterima secara budaya memerlukan data khusus tempat yang berada di luar ruang lingkup jenis `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Melaksanakan operasi perbandingan pada rentetan.
///
/// Rentetan dibandingkan [lexicographically](Ord#lexicographical-comparison) dengan nilai baitnya.
/// Ini membandingkan titik kod Unicode berdasarkan kedudukannya dalam carta kod.
/// Ini tidak semestinya sama dengan pesanan "alphabetical", yang berbeza mengikut bahasa dan tempat.
/// Membandingkan rentetan mengikut piawaian yang diterima budaya memerlukan data khusus tempat yang berada di luar ruang lingkup jenis `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[..]` atau `&mut self[..]`.
///
/// Mengembalikan sepotong keseluruhan rentetan, iaitu mengembalikan `&self` atau `&mut self`.Sama dengan `&diri [0..
/// len] `atau`&mut diri [0..
/// len]`.
/// Tidak seperti operasi pengindeksan lain, ini tidak akan pernah dapat panic.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih disokong oleh pelaksanaan langsung `Index` dan `IndexMut`.
///
/// Sama dengan `&self[0 .. len]` atau `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[begin .. end]` atau `&mut self[begin .. end]`.
///
/// Mengembalikan kepingan rentetan yang diberikan dari julat bait [`begin`, `end`).
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih disokong oleh pelaksanaan langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `begin` atau `end` tidak menunjukkan permulaan byte watak (seperti yang ditentukan oleh `is_char_boundary`), jika `begin > end`, atau jika `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ini akan panic:
/// // bait 2 terletak dalam `ö`:
/// // &s [2 ..3];
///
/// // byte 8 terletak dalam `老`&s [1..
/// // 8];
///
/// // byte 100 berada di luar rentetan [3..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` dan `end` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            // Kami juga memeriksa had char, jadi ini sah UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` dan `end` berada di sempadan char.
            // Kami tahu penunjuk itu unik kerana kami memperolehnya dari `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KESELAMATAN: pemanggil menjamin bahawa `self` berada di had `slice`
        // yang memenuhi semua syarat untuk `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KESELAMATAN: lihat komen untuk `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary memeriksa bahawa indeks berada di [0, .len()] tidak dapat menggunakan kembali `get` seperti di atas, kerana masalah NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` dan `end` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[.. end]` atau `&mut self[.. end]`.
///
/// Mengembalikan potongan rentetan yang diberikan dari julat bait [`0`, `end`).
/// Sama dengan `&self[0 .. end]` atau `&mut self[0 .. end]`.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih disokong oleh pelaksanaan langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `end` tidak menunjukkan permulaan byte watak (seperti yang ditentukan oleh `is_char_boundary`), atau jika `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `end` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `end` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `end` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[begin ..]` atau `&mut self[begin ..]`.
///
/// Mengembalikan kepingan rentetan yang diberikan dari julat bait [`begin`, `len`).Sama dengan `&diri [bermula ..
/// len] `atau`&mut diri [bermula ..
/// len]`.
///
/// Operasi ini adalah *O*(1).
///
/// Sebelum 1.20.0, operasi pengindeksan ini masih disokong oleh pelaksanaan langsung `Index` dan `IndexMut`.
///
/// # Panics
///
/// Panics jika `begin` tidak menunjukkan permulaan byte watak (seperti yang ditentukan oleh `is_char_boundary`), atau jika `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KESELAMATAN: pemanggil menjamin bahawa `self` berada di had `slice`
        // yang memenuhi semua syarat untuk `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // KESELAMATAN: sama dengan `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // KESELAMATAN: baru sahaja memeriksa bahawa `start` berada di sempadan char,
            // dan kami memberikan rujukan yang selamat, jadi nilai pengembalian juga akan menjadi satu.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[begin ..= end]` atau `&mut self[begin ..= end]`.
///
/// Mengembalikan sepotong rentetan yang diberikan dari julat bait [`begin`, `end`].Sama dengan `&self [begin .. end + 1]` atau `&mut self[begin .. end + 1]`, kecuali jika `end` mempunyai nilai maksimum untuk `usize`.
///
/// Operasi ini adalah *O*(1).
///
/// # Panics
///
/// Panics jika `begin` tidak menunjukkan offset byte permulaan watak (seperti yang ditentukan oleh `is_char_boundary`), jika `end` tidak menunjukkan offset byte aksara (`end + 1` sama ada byte permulaan byte atau sama dengan `len`), jika `begin > end`, atau jika `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Melaksanakan pemotongan substring dengan sintaks `&self[..= end]` atau `&mut self[..= end]`.
///
/// Mengembalikan potongan rentetan yang diberikan dari julat bait [0, `end`].
/// Sama dengan `&self [0 .. end + 1]`, kecuali jika `end` mempunyai nilai maksimum untuk `usize`.
///
/// Operasi ini adalah *O*(1).
///
/// # Panics
///
/// Panics jika `end` tidak menunjuk ke offset byte aksara watak (`end + 1` adalah sama ada byte permulaan seperti yang ditentukan oleh `is_char_boundary`, atau sama dengan `len`), atau jika `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KESELAMATAN: pemanggil mesti mematuhi kontrak keselamatan untuk `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Huraikan nilai dari rentetan
///
/// Kaedah [`from_str`] `FromStr` sering digunakan secara tersirat, melalui kaedah [`parse`] [`str`].
/// Lihat dokumentasi [`parse`] untuk contoh.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` tidak mempunyai parameter seumur hidup, dan oleh itu anda hanya boleh menguraikan jenis yang tidak mengandungi parameter seumur hidup itu sendiri.
///
/// Dengan kata lain, anda boleh menguraikan `i32` dengan `FromStr`, tetapi bukan `&i32`.
/// Anda boleh menguraikan struktur yang mengandungi `i32`, tetapi bukan yang mengandungi `&i32`.
///
/// # Examples
///
/// Pelaksanaan asas `FromStr` pada jenis `Point` contoh:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Kesalahan yang berkaitan yang dapat dikembalikan daripada penghuraian.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Menghuraikan rentetan `s` untuk mengembalikan nilai jenis ini.
    ///
    /// Sekiranya penghuraian berjaya, kembalikan nilai di dalam [`Ok`], jika tidak apabila rentetan tidak diformat, kembalikan ralat khusus untuk [`Err`] di dalam.
    /// Jenis ralat adalah khusus untuk pelaksanaan trait.
    ///
    /// # Examples
    ///
    /// Penggunaan asas dengan [`i32`], jenis yang menerapkan `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Huraikan `bool` dari rentetan.
    ///
    /// Memberi `Result<bool, ParseBoolError>`, kerana `s` mungkin atau tidak sebenarnya dapat dihuraikan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Perhatikan, dalam banyak kes, kaedah `.parse()` pada `str` lebih tepat.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}