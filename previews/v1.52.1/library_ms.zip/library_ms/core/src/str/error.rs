//! Mentakrifkan jenis ralat utf8.

use crate::fmt;

/// Kesalahan yang boleh berlaku semasa cuba menafsirkan urutan [`u8`] sebagai rentetan.
///
/// Oleh itu, keluarga fungsi dan kaedah `from_utf8` untuk kedua-dua [`String`] dan [`&str`] menggunakan ralat ini, misalnya.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Kaedah jenis ralat ini dapat digunakan untuk membuat fungsi yang serupa dengan `String::from_utf8_lossy` tanpa memperuntukkan memori timbunan:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Mengembalikan indeks dalam rentetan yang diberikan sehingga UTF-8 yang sah disahkan.
    ///
    /// Ini adalah indeks maksimum sehingga `from_utf8(&input[..index])` akan mengembalikan `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::str;
    ///
    /// // sebilangan bait tidak sah, dalam vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 mengembalikan Ralat Utf8
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // bait kedua tidak sah di sini
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Memberi lebih banyak maklumat mengenai kegagalan:
    ///
    /// * `None`: akhir input dicapai tanpa diduga.
    ///   `self.valid_up_to()` adalah 1 hingga 3 bait dari akhir input.
    ///   Sekiranya aliran byte (seperti fail atau soket rangkaian) didekodekan secara bertahap, ini mungkin `char` yang sah yang urutan bait UTF-8 nya merangkumi beberapa bahagian.
    ///
    ///
    /// * `Some(len)`: bait yang tidak dijangka ditemui.
    ///   Panjang yang diberikan adalah urutan bait tidak sah yang bermula pada indeks yang diberikan oleh `valid_up_to()`.
    ///   Penyahkodan harus disambung semula selepas urutan itu (setelah memasukkan [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) sekiranya berlaku penyahkodan yang hilang.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Ralat dikembalikan semasa menguraikan `bool` menggunakan [`from_str`] gagal
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}