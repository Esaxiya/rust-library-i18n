//! Cara untuk membuat `str` dari potongan byte.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Menukar sepotong bait ke irisan rentetan.
///
/// Potongan tali ([`&str`]) terbuat dari byte ([`u8`]), dan potongan byte ([`&[u8]`][byteslice]) terbuat dari bait, jadi fungsi ini bertukar antara keduanya.
/// Tidak semua irisan bait adalah potongan rentetan yang sah, namun: [`&str`] memerlukannya adalah UTF-8 yang sah.
/// `from_utf8()` memeriksa untuk memastikan bahawa bait itu sah UTF-8, dan kemudian melakukan penukaran.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Sekiranya anda yakin bahawa potongan byte itu sah UTF-8, dan anda tidak mahu menanggung overhead dari pemeriksaan kesahan, terdapat versi fungsi ini yang tidak selamat, [`from_utf8_unchecked`], yang mempunyai tingkah laku yang sama tetapi melewatkan pemeriksaan.
///
///
/// Sekiranya anda memerlukan `String` dan bukannya `&str`, pertimbangkan [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Kerana anda boleh mengagendakan `[u8; N]`, dan anda boleh mengambil [`&[u8]`][byteslice], fungsi ini adalah salah satu cara untuk mempunyai rentetan yang diperuntukkan.Terdapat contoh ini di bahagian contoh di bawah.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Mengembalikan `Err` jika slice bukan UTF-8 dengan keterangan mengapa slice yang disediakan bukan UTF-8.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::str;
///
/// // sebilangan bait, dalam vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Kami tahu bait ini sah, jadi gunakan `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bait yang tidak betul:
///
/// ```
/// use std::str;
///
/// // sebilangan bait tidak sah, dalam vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Lihat dokumen untuk [`Utf8Error`] untuk maklumat lebih lanjut mengenai jenis kesalahan yang dapat dikembalikan.
///
/// "stack allocated string":
///
/// ```
/// use std::str;
///
/// // sebilangan bait, dalam susunan yang diperuntukkan
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Kami tahu bait ini sah, jadi gunakan `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // KESELAMATAN: Hanya menjalankan pengesahan.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Menukarkan potongan byte yang boleh berubah menjadi irisan rentetan yang boleh berubah.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" sebagai vector yang boleh berubah
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Seperti yang kita tahu bait ini sah, kita boleh menggunakan `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bait yang tidak betul:
///
/// ```
/// use std::str;
///
/// // Sebilangan bait tidak sah dalam vector yang boleh berubah
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Lihat dokumen untuk [`Utf8Error`] untuk maklumat lebih lanjut mengenai jenis kesalahan yang dapat dikembalikan.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // KESELAMATAN: Hanya menjalankan pengesahan.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Menukar sepotong bait ke irisan rentetan tanpa memeriksa bahawa rentetan mengandungi UTF-8 yang sah.
///
/// Lihat versi selamat, [`from_utf8`], untuk maklumat lebih lanjut.
///
/// # Safety
///
/// Fungsi ini tidak selamat kerana tidak memastikan bait yang diteruskan kepadanya adalah UTF-8 yang sah.
/// Sekiranya kekangan ini dilanggar, hasil tingkah laku tidak ditentukan, kerana Rust selebihnya menganggap bahawa [`&str`] adalah UTF-8 yang sah.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::str;
///
/// // sebilangan bait, dalam vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KESELAMATAN: pemanggil mesti menjamin bahawa byte `v` sah UTF-8.
    // Juga bergantung pada `&str` dan `&[u8]` yang mempunyai susun atur yang sama.
    unsafe { mem::transmute(v) }
}

/// Menukar sepotong bait ke irisan rentetan tanpa memeriksa bahawa rentetan mengandungi UTF-8 yang sah;versi boleh ubah.
///
///
/// Lihat versi tidak berubah, [`from_utf8_unchecked()`] untuk maklumat lebih lanjut.
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // KESELAMATAN: pemanggil mesti menjamin bahawa byte `v`
    // sah UTF-8, oleh itu pemeran ke `*mut str` selamat.
    // Juga, penghindaran penunjuk adalah selamat kerana penunjuk itu berasal dari rujukan yang dijamin sah untuk penulisan.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}