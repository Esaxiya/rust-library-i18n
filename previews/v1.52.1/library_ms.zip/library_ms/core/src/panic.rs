//! Sokongan Panic di perpustakaan standard.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Struktur yang memberikan maklumat mengenai panic.
///
/// `PanicInfo` struktur diteruskan ke set panic hook oleh fungsi [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Mengembalikan muatan yang berkaitan dengan panic.
    ///
    /// Ini biasanya, tetapi tidak selalu, menjadi `&'static str` atau [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Sekiranya makro `panic!` dari `core` crate (bukan dari `std`) digunakan dengan rentetan pemformatan dan beberapa argumen tambahan, kembalikan mesej yang siap digunakan misalnya dengan [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Mengembalikan maklumat mengenai lokasi asal panic, jika ada.
    ///
    /// Kaedah ini pada masa ini akan selalu mengembalikan [`Some`], tetapi ini mungkin berubah dalam versi future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Sekiranya ini diubah menjadi kadangkala tidak ada,
        // atasi kes itu di std::panicking::default_hook dan std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: kita tidak boleh menggunakan downcast_ref: :<String>() di sini
        // kerana String tidak tersedia dalam libcore!
        // Muatan adalah Rentetan ketika `std::panic!` dipanggil dengan banyak argumen, tetapi dalam hal itu mesejnya juga tersedia.
        //

        self.location.fmt(formatter)
    }
}

/// Struktur yang mengandungi maklumat mengenai lokasi panic.
///
/// Struktur ini dicipta oleh [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Perbandingan untuk kesamaan dan susunan dibuat dalam keutamaan fail, baris, dan lajur.
/// Fail dibandingkan sebagai rentetan, bukan `Path`, yang mungkin tidak dijangka.
/// Lihat dokumentasi [`Lokasi: : file`] untuk perbincangan lebih lanjut.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Mengembalikan lokasi sumber pemanggil fungsi ini.
    /// Sekiranya pemanggil fungsi itu diberi penjelasan, lokasi panggilannya akan dikembalikan, dan seterusnya menaikkan timbunan ke panggilan pertama dalam badan fungsi yang tidak dilacak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Mengembalikan [`Location`] di mana ia dipanggil.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Mengembalikan [`Location`] dari dalam definisi fungsi ini.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // menjalankan fungsi yang tidak dilacak yang sama di lokasi yang berbeza memberikan kita hasil yang sama
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // menjalankan fungsi yang dijejaki di lokasi yang berbeza menghasilkan nilai yang berbeza
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Mengembalikan nama fail sumber dari mana panic berasal.
    ///
    /// # `&str`, bukan `&Path`
    ///
    /// Nama yang dikembalikan merujuk kepada jalan sumber pada sistem penyusunan, tetapi tidak sah untuk mewakili ini secara langsung sebagai `&Path`.
    /// Kod yang disusun mungkin berjalan pada sistem yang berbeza dengan pelaksanaan `Path` yang berbeza daripada sistem yang menyediakan isinya dan perpustakaan ini pada masa ini tidak mempunyai jenis "host path" yang berbeza.
    ///
    /// Tingkah laku yang paling mengejutkan berlaku apabila fail "the same" dapat dicapai melalui beberapa jalur dalam sistem modul (biasanya menggunakan atribut `#[path = "..."]` atau serupa), yang dapat menyebabkan apa yang nampaknya kod yang sama untuk mengembalikan nilai yang berbeza dari fungsi ini.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Nilai ini tidak sesuai untuk diteruskan ke `Path::new` atau pembina yang serupa apabila platform hos dan platform sasaran berbeza.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Mengembalikan nombor garis dari mana panic berasal.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Mengembalikan lajur dari mana panic berasal.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait dalaman yang digunakan oleh libstd untuk menyampaikan data dari libstd ke `panic_unwind` dan masa runtuh panic yang lain.
/// Tidak dimaksudkan untuk stabil dalam waktu dekat, jangan gunakan.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Mendapatkan sepenuhnya isi kandungannya.
    /// Jenis pengembalian sebenarnya adalah `Box<dyn Any + Send>`, tetapi kita tidak dapat menggunakan `Box` dalam libcore.
    ///
    /// Setelah kaedah ini dipanggil, hanya beberapa nilai lalai dummy yang tersisa di `self`.
    /// Memanggil kaedah ini dua kali, atau memanggil `get` setelah memanggil kaedah ini, adalah satu kesalahan.
    ///
    /// Argumen dipinjam kerana panic runtime (`__rust_start_panic`) hanya mendapat `dyn BoxMeUp` yang dipinjam.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Hanya pinjam isinya.
    fn get(&mut self) -> &(dyn Any + Send);
}