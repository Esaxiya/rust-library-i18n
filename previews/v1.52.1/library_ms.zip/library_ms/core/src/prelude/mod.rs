//! Libcore prelude
//!
//! Modul ini ditujukan untuk pengguna libcore yang tidak mempunyai pautan ke libstd juga.
//! Modul ini diimport secara lalai apabila `#![no_std]` digunakan dengan cara yang sama seperti prelude perpustakaan standard.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Versi 2015 teras prelude.
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versi 2018 teras prelude.
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versi 2021 teras prelude.
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Tambah lebih banyak perkara.
}