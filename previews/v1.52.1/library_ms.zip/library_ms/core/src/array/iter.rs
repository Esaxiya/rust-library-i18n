//! Mentakrifkan iterator milik `IntoIter` untuk tatasusunan.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Pengulang [array] nilai.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ini adalah tatasusunan yang kami ulangi.
    ///
    /// Elemen dengan indeks `i` di mana `alive.start <= i < alive.end` belum dihasilkan dan merupakan entri array yang sah.
    /// Elemen dengan indeks `i < alive.start` atau `i >= alive.end` telah dihasilkan dan tidak boleh diakses lagi!Unsur-unsur mati itu mungkin berada dalam keadaan yang belum dimulakan sepenuhnya!
    ///
    ///
    /// Oleh itu, invarian adalah:
    /// - `data[alive]` masih hidup (iaitu mengandungi unsur yang sah)
    /// - `data[..alive.start]` dan `data[alive.end..]` sudah mati (iaitu elemen sudah dibaca dan tidak boleh disentuh lagi!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Unsur-unsur dalam `data` yang belum dihasilkan.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Membuat iterator baru berbanding `array` yang diberikan.
    ///
    /// *Catatan*: kaedah ini mungkin tidak digunakan lagi di future, setelah [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Jenis `value` adalah `i32` di sini, bukannya `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // KESELAMATAN: Pemancar di sini sebenarnya selamat.Dokumen `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` dijamin mempunyai ukuran dan keselarasan yang sama
        // > sebagai `T`.
        //
        // Dokumen tersebut bahkan menunjukkan transmut dari array `MaybeUninit<T>` ke array `T`.
        //
        //
        // Dengan itu, inisialisasi ini dapat memuaskan invarian.

        // FIXME(LukasKalbertodt): sebenarnya menggunakan `mem::transmute` di sini, setelah ia berfungsi dengan generik const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Sehingga itu, kita dapat menggunakan `mem::transmute_copy` untuk membuat salinan bitwise sebagai jenis yang lain, kemudian lupakan `array` agar tidak dijatuhkan.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Mengembalikan potongan yang tidak berubah dari semua elemen yang belum dihasilkan.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // KESELAMATAN: Kami tahu bahawa semua elemen dalam `alive` diinisialisasi dengan betul.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Mengembalikan potongan yang dapat diubah dari semua elemen yang belum dihasilkan.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // KESELAMATAN: Kami tahu bahawa semua elemen dalam `alive` diinisialisasi dengan betul.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Dapatkan indeks seterusnya dari hadapan.
        //
        // Menambah `alive.start` dengan 1 mengekalkan invarian mengenai `alive`.
        // Namun, kerana perubahan ini, untuk waktu yang singkat, zon hidup bukan lagi `data[alive]`, tetapi `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Baca elemen dari tatasusunan.
            // KESELAMATAN: `idx` adalah indeks ke bekas wilayah "alive" di
            // susunan.Membaca elemen ini bermaksud bahawa `data[idx]` dianggap sudah mati sekarang (iaitu jangan sentuh).
            // Oleh kerana `idx` adalah permulaan zon hidup, zon hidup kini `data[alive]` lagi, memulihkan semua invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Dapatkan indeks seterusnya dari belakang.
        //
        // Penurunan `alive.end` dengan 1 mengekalkan invarian berkenaan `alive`.
        // Namun, kerana perubahan ini, untuk waktu yang singkat, zon hidup bukan lagi `data[alive]`, tetapi `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Baca elemen dari tatasusunan.
            // KESELAMATAN: `idx` adalah indeks ke bekas wilayah "alive" di
            // susunan.Membaca elemen ini bermaksud bahawa `data[idx]` dianggap sudah mati sekarang (iaitu jangan sentuh).
            // Oleh kerana `idx` adalah akhir zon hidup, zon hidup kini `data[alive]` lagi, memulihkan semua invarian.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // KESELAMATAN: Ini selamat: `as_mut_slice` mengembalikan tepat sub-slice
        // unsur-unsur yang belum dipindahkan dan yang masih belum dijelaskan.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Tidak akan mengalir keluar kerana `hidup.start <=invarian
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator memang melaporkan panjang yang betul.
// Bilangan elemen "alive" (yang masih akan dihasilkan) adalah panjang julat `alive`.
// Julat ini dikurangkan panjang sama ada `next` atau `next_back`.
// Ini selalu dikurangkan oleh 1 dalam kaedah tersebut, tetapi hanya jika `Some(_)` dikembalikan.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Perhatikan, kita tidak semestinya sesuai dengan jarak hidup yang sama, jadi kita hanya dapat mengklon ke ofset 0 tanpa mengira di mana `self` berada.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klon semua unsur hidup.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Tulis klon ke dalam array baru, kemudian kemas kini julatnya yang masih hidup.
            // Sekiranya pengklonan panics, kami akan menjatuhkan item sebelumnya dengan betul.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Cetak hanya elemen yang belum dihasilkan: kita tidak dapat mengakses elemen yang dihasilkan lagi.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}