#![stable(feature = "core_hint", since = "1.27.0")]

//! Petunjuk untuk penyusun yang mempengaruhi bagaimana kod harus dikeluarkan atau dioptimumkan.
//! Petunjuk mungkin adalah masa penyusunan atau masa berjalan.

use crate::intrinsics;

/// Memaklumkan kepada penyusun bahawa titik dalam kod ini tidak dapat dicapai, memungkinkan pengoptimuman lebih lanjut.
///
/// # Safety
///
/// Mencapai fungsi ini sepenuhnya *tingkah laku tidak ditentukan*(UB).Khususnya, penyusun menganggap bahawa semua UB tidak boleh berlaku, dan oleh itu akan menghilangkan semua cawangan yang mencapai panggilan ke `unreachable_unchecked()`.
///
/// Seperti semua keadaan UB, jika anggapan ini ternyata salah, iaitu panggilan `unreachable_unchecked()` sebenarnya dapat dicapai di antara semua kemungkinan aliran kawalan, penyusun akan menerapkan strategi pengoptimuman yang salah, dan kadang kala malah kod yang nampaknya tidak berkaitan dengan rasuah, menyebabkan sukar-untuk menyelesaikan masalah.
///
///
/// Gunakan fungsi ini hanya apabila anda dapat membuktikan bahawa kod tidak akan memanggilnya.
/// Jika tidak, pertimbangkan untuk menggunakan makro [`unreachable!`], yang tidak membenarkan pengoptimuman tetapi akan panic ketika dijalankan.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` selalu positif (bukan sifar), oleh itu `checked_div` tidak akan pernah mengembalikan `None`.
/////
///     // Oleh itu, branch yang lain tidak dapat dicapai.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // KESELAMATAN: kontrak keselamatan untuk `intrinsics::unreachable` mesti
    // ditegakkan oleh pemanggil.
    unsafe { intrinsics::unreachable() }
}

/// Memancarkan arahan mesin untuk memberi isyarat kepada pemproses bahawa ia sedang berjalan dalam putaran putaran yang sibuk ("spin lock").
///
/// Setelah menerima isyarat putaran gelung, pemproses dapat mengoptimumkan tingkah lakunya dengan, misalnya, menjimatkan kuasa atau menukar benang hyper.
///
/// Fungsi ini berbeza dengan [`thread::yield_now`] yang langsung menghasilkan penjadual sistem, sedangkan `spin_loop` tidak berinteraksi dengan sistem operasi.
///
/// Kes penggunaan biasa untuk `spin_loop` adalah menerapkan putaran optimis terikat dalam gelung CAS dalam primitif penyegerakan.
/// Untuk mengelakkan masalah seperti penyongsangan keutamaan, sangat digalakkan agar putaran putaran dihentikan setelah lelaran yang terhad dan syscall penyekat yang sesuai dibuat.
///
///
/// **Catatan**: Pada platform yang tidak menyokong penerimaan petunjuk putaran gelung, fungsi ini sama sekali tidak melakukan apa-apa.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Nilai atom bersama yang akan digunakan benang untuk diselaraskan
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Dalam utas latar belakang akhirnya kita akan menetapkan nilai
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Lakukan kerja, kemudian buat nilainya
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Kembali ke utas semasa kami, kami menunggu nilainya ditetapkan
/// while !live.load(Ordering::Acquire) {
///     // Gelung putaran adalah petunjuk kepada CPU yang sedang kita tunggu, tetapi mungkin tidak terlalu lama
/////
///     hint::spin_loop();
/// }
///
/// // Nilai kini ditetapkan
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // KESELAMATAN: attr `cfg` memastikan bahawa kami hanya melaksanakan ini pada sasaran x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // KESELAMATAN: attr `cfg` memastikan bahawa kami hanya melaksanakan ini pada sasaran x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // KESELAMATAN: attr `cfg` memastikan bahawa kami hanya melaksanakan ini pada sasaran aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // KESELAMATAN: `cfg` attr memastikan bahawa kita hanya melaksanakan ini pada sasaran lengan
            // dengan sokongan untuk ciri v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Fungsi identiti yang *__ mengisyaratkan __* kepada penyusun untuk bersikap pesimis tentang apa yang boleh dilakukan oleh `black_box`.
///
/// Tidak seperti [`std::convert::identity`], penyusun Rust digalakkan untuk menganggap bahawa `black_box` dapat menggunakan `dummy` dengan cara yang sah yang mungkin dibenarkan oleh kod Rust tanpa memperkenalkan tingkah laku yang tidak ditentukan dalam kod panggilan.
///
/// Properti ini menjadikan `black_box` berguna untuk menulis kod di mana pengoptimuman tertentu tidak diinginkan, seperti tanda aras.
///
/// Walau bagaimanapun, perhatikan bahawa `black_box` hanya (dan hanya dapat) disediakan berdasarkan "best-effort".Sejauh mana ia dapat menyekat pengoptimuman mungkin berbeza-beza bergantung pada platform dan backend kod-gen yang digunakan.
/// Program tidak boleh bergantung pada `black_box` untuk *kebenaran* dengan cara apa pun.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Kita perlu "use" argumen dengan cara tertentu LLVM tidak dapat melakukan introspeksi, dan pada sasaran yang menyokongnya, kita biasanya dapat memanfaatkan pemasangan sebaris untuk melakukan ini.
    // Tafsiran LLVM mengenai pemasangan sebaris adalah bahawa ia adalah kotak hitam.
    // Ini bukan pelaksanaan terbaik kerana mungkin lebih banyak mengoptimumkan daripada yang kita mahukan, tetapi sejauh ini cukup baik.
    //
    //

    #[cfg(not(miri))] // Ini hanya petunjuk, jadi tidak mengapa untuk melangkau di Miri.
    // KESELAMATAN: pemasangan sebaris adalah op-op.
    unsafe {
        // FIXME: Tidak dapat menggunakan `asm!` kerana tidak menyokong MIPS dan seni bina lain.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}