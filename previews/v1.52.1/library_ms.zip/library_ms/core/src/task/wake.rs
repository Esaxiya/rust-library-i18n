#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` membolehkan pelaksana pelaksana tugas membuat [`Waker`] yang menyediakan tingkah laku bangun yang disesuaikan.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Ia terdiri daripada penunjuk data dan [virtual function pointer table (vtable)][vtable] yang menyesuaikan tingkah laku `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Penunjuk data, yang dapat digunakan untuk menyimpan data sewenang-wenang seperti yang diperlukan oleh pelaksana.
    /// Ini boleh menjadi contoh
    /// penunjuk pemadam jenis ke `Arc` yang dikaitkan dengan tugas.
    /// Nilai medan ini diteruskan ke semua fungsi yang merupakan sebahagian daripada vtable sebagai parameter pertama.
    ///
    data: *const (),
    /// Jadual penunjuk fungsi maya yang menyesuaikan tingkah laku pembuat ini.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Membuat `RawWaker` baru dari penunjuk `data` dan `vtable` yang disediakan.
    ///
    /// Penunjuk `data` boleh digunakan untuk menyimpan data sewenang-wenangnya seperti yang dikehendaki oleh pelaksana.Ini boleh menjadi contoh
    /// penunjuk pemadam jenis ke `Arc` yang dikaitkan dengan tugas.
    /// Nilai penunjuk ini akan diteruskan ke semua fungsi yang merupakan sebahagian daripada `vtable` sebagai parameter pertama.
    ///
    /// `vtable` menyesuaikan tingkah laku `Waker` yang dibuat dari `RawWaker`.
    /// Untuk setiap operasi pada `Waker`, fungsi yang berkaitan dalam `vtable` dari `RawWaker` yang mendasari akan dipanggil.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Jadual penunjuk fungsi maya (vtable) yang menentukan tingkah laku [`RawWaker`].
///
/// Penunjuk yang diteruskan ke semua fungsi di dalam vtable adalah penunjuk `data` dari objek [`RawWaker`] yang melampirkan.
///
/// Fungsi di dalam struktur ini hanya dimaksudkan untuk dipanggil pada penunjuk `data` dari objek [`RawWaker`] yang dibina dengan betul dari dalam pelaksanaan [`RawWaker`].
/// Memanggil salah satu fungsi terkandung menggunakan penunjuk `data` lain akan menyebabkan tingkah laku yang tidak ditentukan.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Fungsi ini akan dipanggil ketika [`RawWaker`] diklon, misalnya ketika [`Waker`] di mana [`RawWaker`] disimpan akan diklon.
    ///
    /// Pelaksanaan fungsi ini mesti menyimpan semua sumber yang diperlukan untuk contoh tambahan [`RawWaker`] dan tugas yang berkaitan ini.
    /// Memanggil `wake` pada [`RawWaker`] yang terhasil seharusnya menghasilkan tugas yang sama yang pasti akan dibangunkan oleh [`RawWaker`] yang asli.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Fungsi ini akan dipanggil semasa `wake` dipanggil pada [`Waker`].
    /// Ia mesti membangunkan tugas yang berkaitan dengan [`RawWaker`] ini.
    ///
    /// Pelaksanaan fungsi ini mesti memastikan untuk melepaskan sumber yang berkaitan dengan contoh [`RawWaker`] dan tugas yang berkaitan ini.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Fungsi ini akan dipanggil semasa `wake_by_ref` dipanggil pada [`Waker`].
    /// Ia mesti membangunkan tugas yang berkaitan dengan [`RawWaker`] ini.
    ///
    /// Fungsi ini serupa dengan `wake`, tetapi tidak boleh menggunakan penunjuk data yang disediakan.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Fungsi ini dipanggil apabila [`RawWaker`] jatuh.
    ///
    /// Pelaksanaan fungsi ini mesti memastikan untuk melepaskan sumber yang berkaitan dengan contoh [`RawWaker`] dan tugas yang berkaitan ini.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Membuat `RawWakerVTable` baru dari fungsi `clone`, `wake`, `wake_by_ref`, dan `drop` yang disediakan.
    ///
    /// # `clone`
    ///
    /// Fungsi ini akan dipanggil ketika [`RawWaker`] diklon, misalnya ketika [`Waker`] di mana [`RawWaker`] disimpan akan diklon.
    ///
    /// Pelaksanaan fungsi ini mesti menyimpan semua sumber yang diperlukan untuk contoh tambahan [`RawWaker`] dan tugas yang berkaitan ini.
    /// Memanggil `wake` pada [`RawWaker`] yang terhasil seharusnya menghasilkan tugas yang sama yang pasti akan dibangunkan oleh [`RawWaker`] yang asli.
    ///
    /// # `wake`
    ///
    /// Fungsi ini akan dipanggil semasa `wake` dipanggil pada [`Waker`].
    /// Ia mesti membangunkan tugas yang berkaitan dengan [`RawWaker`] ini.
    ///
    /// Pelaksanaan fungsi ini mesti memastikan untuk melepaskan sumber yang berkaitan dengan contoh [`RawWaker`] dan tugas yang berkaitan ini.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Fungsi ini akan dipanggil semasa `wake_by_ref` dipanggil pada [`Waker`].
    /// Ia mesti membangunkan tugas yang berkaitan dengan [`RawWaker`] ini.
    ///
    /// Fungsi ini serupa dengan `wake`, tetapi tidak boleh menggunakan penunjuk data yang disediakan.
    ///
    /// # `drop`
    ///
    /// Fungsi ini dipanggil apabila [`RawWaker`] jatuh.
    ///
    /// Pelaksanaan fungsi ini mesti memastikan untuk melepaskan sumber yang berkaitan dengan contoh [`RawWaker`] dan tugas yang berkaitan ini.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` tugas tak segerak.
///
/// Pada masa ini, `Context` hanya berfungsi untuk memberikan akses ke `&Waker` yang dapat digunakan untuk mengaktifkan tugas semasa.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Pastikan kita future-bukti terhadap perubahan varians dengan memaksa jangka hayat tidak berubah (jangka hayat kedudukan argumen bertentangan sementara jangka hayat kedudukan kembali adalah kovarian).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Buat `Context` baru dari `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Mengembalikan rujukan ke `Waker` untuk tugas semasa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` adalah pegangan untuk membangunkan tugas dengan memberitahu pelaksana bahawa ia sudah siap untuk dijalankan.
///
/// Pemegang ini merangkum instance [`RawWaker`], yang menentukan tingkah laku bangun khusus pelaksana.
///
///
/// Mengimplementasikan [`Clone`], [`Send`], dan [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Bangunkan tugas yang berkaitan dengan `Waker` ini.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Panggilan bangun sebenarnya diberikan melalui panggilan fungsi maya ke pelaksanaan yang ditentukan oleh pelaksana.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Jangan panggil `drop`-pembuat wak akan dimakan oleh `wake`.
        crate::mem::forget(self);

        // KESELAMATAN: Ini selamat kerana `Waker::from_raw` adalah satu-satunya cara
        // untuk memulakan `wake` dan `data` yang memerlukan pengguna untuk mengakui bahawa kontrak `RawWaker` ditegakkan.
        //
        unsafe { (wake)(data) };
    }

    /// Bangunkan tugas yang berkaitan dengan `Waker` ini tanpa memakan `Waker`.
    ///
    /// Ini serupa dengan `wake`, tetapi mungkin sedikit kurang efisien sekiranya `Waker` yang dimiliki tersedia.
    /// Kaedah ini harus lebih disukai daripada memanggil `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Panggilan bangun sebenarnya diberikan melalui panggilan fungsi maya ke pelaksanaan yang ditentukan oleh pelaksana.
        //

        // KESELAMATAN: lihat `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Mengembalikan `true` jika `Waker` ini dan `Waker` lain telah membangunkan tugas yang sama.
    ///
    /// Fungsi ini berfungsi berdasarkan usaha terbaik, dan mungkin kembali salah walaupun `Waker` akan membangunkan tugas yang sama.
    /// Tetapi, jika fungsi ini mengembalikan `true`, dijamin bahawa `Waker`s akan membangkitkan tugas yang sama.
    ///
    /// Fungsi ini digunakan terutamanya untuk tujuan pengoptimuman.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Membuat `Waker` baru dari [`RawWaker`].
    ///
    /// Tingkah laku `Waker` yang dikembalikan tidak ditentukan sekiranya kontrak yang ditentukan dalam dokumentasi [`RawWaker`] dan [`RawWakerVTable`] tidak ditegakkan.
    ///
    /// Oleh itu kaedah ini tidak selamat.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // KESELAMATAN: Ini selamat kerana `Waker::from_raw` adalah satu-satunya cara
            // untuk memulakan `clone` dan `data` yang memerlukan pengguna untuk mengakui bahawa kontrak [`RawWaker`] ditegakkan.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // KESELAMATAN: Ini selamat kerana `Waker::from_raw` adalah satu-satunya cara
        // untuk memulakan `drop` dan `data` yang memerlukan pengguna untuk mengakui bahawa kontrak `RawWaker` ditegakkan.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}