//! Iterasi tak segerak yang boleh disusun.
//!
//! Sekiranya futures adalah nilai tak segerak, maka aliran adalah lelaran tak segerak.
//! Sekiranya anda mempunyai beberapa jenis koleksi tidak segerak, dan perlu melakukan operasi pada elemen koleksi tersebut, anda akan mengalami 'streams' dengan cepat.
//! Aliran banyak digunakan dalam kod Rust asinkron idiomatik, jadi perlu dikenali dengannya.
//!
//! Sebelum menerangkan lebih lanjut, mari kita bincangkan bagaimana modul ini disusun:
//!
//! # Organization
//!
//! Modul ini sebahagian besarnya disusun mengikut jenis:
//!
//! * [Traits] adalah bahagian inti: traits ini menentukan jenis aliran yang ada dan apa yang boleh anda lakukan dengannya.Kaedah traits ini bernilai menghabiskan masa belajar tambahan.
//! * Fungsi menyediakan beberapa cara yang berguna untuk membuat beberapa aliran asas.
//! * Struktur selalunya merupakan jenis pengembalian dari pelbagai kaedah pada modul traits ini.Anda biasanya ingin melihat kaedah yang menghasilkan `struct`, bukannya `struct` itu sendiri.
//! Untuk keterangan lebih lanjut mengenai sebabnya, lihat '[Implementing Stream](#Implementing-stream)'.
//!
//! [Traits]: #traits
//!
//! Itu sahaja!Mari menggali aliran.
//!
//! # Stream
//!
//! Hati dan jiwa modul ini adalah [`Stream`] trait.Inti [`Stream`] kelihatan seperti ini:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Tidak seperti `Iterator`, `Stream` membuat perbezaan antara kaedah [`poll_next`] yang digunakan ketika menerapkan `Stream`, dan metode (to-be-implemented) `next` yang digunakan ketika menggunakan aliran.
//!
//! Pengguna `Stream` hanya perlu mempertimbangkan `next`, yang apabila dipanggil, mengembalikan future yang menghasilkan `Option<Stream::Item>`.
//!
//! future yang dikembalikan oleh `next` akan menghasilkan `Some(Item)` selagi ada elemen, dan setelah semuanya habis, akan menghasilkan `None` untuk menunjukkan bahawa lelaran selesai.
//! Sekiranya kita menunggu sesuatu yang tidak segerak untuk diselesaikan, future akan menunggu sehingga aliran siap menghasilkan semula.
//!
//! Aliran individu boleh memilih untuk meneruskan lelaran, dan dengan itu memanggil `next` sekali lagi mungkin atau mungkin tidak akhirnya menghasilkan `Some(Item)` lagi pada suatu ketika.
//!
//! Definisi penuh [Stream]] merangkumi sebilangan kaedah lain juga, tetapi kaedah tersebut merupakan kaedah lalai, dibina di atas [`poll_next`], dan oleh itu anda mendapatkannya secara percuma.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Melaksanakan Aliran
//!
//! Membuat aliran anda sendiri melibatkan dua langkah: membuat `struct` untuk menahan keadaan aliran, dan kemudian melaksanakan [`Stream`] untuk `struct` itu.
//!
//! Mari buat aliran bernama `Counter` yang berkisar dari `1` hingga `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Pertama, struktur:
//!
//! /// Aliran yang terdiri dari satu hingga lima
//! struct Counter {
//!     count: usize,
//! }
//!
//! // kami mahu kiraan kami bermula dari satu, jadi mari tambah kaedah new() untuk membantu.
//! // Ini tidak semestinya diperlukan, tetapi senang.
//! // Perhatikan bahawa kita memulakan `count` pada sifar, kita akan melihat mengapa dalam pelaksanaan `poll_next()`'s di bawah.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Kemudian, kami melaksanakan `Stream` untuk `Counter` kami:
//!
//! impl Stream for Counter {
//!     // kita akan mengira dengan penggunaan
//!     type Item = usize;
//!
//!     // poll_next() adalah satu-satunya kaedah yang diperlukan
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Tingkatkan jumlah kami.Inilah sebabnya mengapa kami bermula pada sifar.
//!         self.count += 1;
//!
//!         // Periksa untuk mengetahui sama ada kita sudah selesai mengira atau tidak.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Aliran *malas*.Ini bermakna bahawa hanya membuat aliran tidak banyak _do_.Tidak ada yang benar-benar berlaku sehingga anda menghubungi `next`.
//! Ini kadang-kadang menjadi sumber kekeliruan ketika membuat aliran hanya untuk kesan sampingannya.
//! Penyusun akan memberi amaran kepada kami mengenai tingkah laku seperti ini:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;