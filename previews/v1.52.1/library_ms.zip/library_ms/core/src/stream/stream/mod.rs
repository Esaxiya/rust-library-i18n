use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Antara muka untuk menangani iterator tak segerak.
///
/// Ini adalah aliran utama trait.
/// Untuk lebih lanjut mengenai konsep aliran secara umum, sila lihat [module-level documentation].
/// Khususnya, anda mungkin ingin mengetahui cara [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Jenis item yang dihasilkan oleh aliran.
    type Item;

    /// Cuba tarik nilai seterusnya dari aliran ini, daftarkan tugas semasa untuk bangun jika nilainya belum tersedia, dan kembalikan `None` jika aliran habis.
    ///
    /// # Nilai pulangan
    ///
    /// Terdapat beberapa kemungkinan nilai kembali, masing-masing menunjukkan keadaan aliran yang berbeza:
    ///
    /// - `Poll::Pending` bermaksud bahawa nilai seterusnya aliran ini belum siap.Pelaksanaan akan memastikan bahawa tugas semasa akan diberitahu ketika nilai berikutnya mungkin sudah siap.
    ///
    /// - `Poll::Ready(Some(val))` bermaksud bahawa aliran berjaya menghasilkan nilai, `val`, dan dapat menghasilkan nilai lebih lanjut pada panggilan `poll_next` berikutnya.
    ///
    /// - `Poll::Ready(None)` bermaksud bahawa aliran telah ditamatkan, dan `poll_next` tidak boleh dipanggil lagi.
    ///
    /// # Panics
    ///
    /// Setelah aliran selesai (dikembalikan `Ready(None)` from `poll_next`), memanggil kaedah `poll_next` sekali lagi mungkin panic, menyekat selamanya, atau menyebabkan masalah lain; `Stream` trait tidak memerlukan syarat mengenai kesan panggilan tersebut.
    ///
    /// Walau bagaimanapun, kerana kaedah `poll_next` tidak ditandai `unsafe`, peraturan biasa Rust berlaku: panggilan tidak boleh menyebabkan tingkah laku yang tidak ditentukan (kerosakan memori, penggunaan fungsi `unsafe` yang salah, atau sejenisnya), tanpa mengira keadaan aliran.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Mengembalikan batas pada baki aliran yang tinggal.
    ///
    /// Secara khusus, `size_hint()` mengembalikan tuple di mana elemen pertama adalah batas bawah, dan elemen kedua adalah batas atas.
    ///
    /// Separuh kedua tuple yang dikembalikan adalah [`Option`]`<`[`usize`] `>`.
    /// [`None`] di sini bermaksud bahawa sama ada tidak ada batas atas yang diketahui, atau batas atas lebih besar daripada [`usize`].
    ///
    /// # Catatan pelaksanaan
    ///
    /// Tidak dipaksakan bahawa pelaksanaan aliran menghasilkan jumlah elemen yang dinyatakan.Aliran kereta boleh menghasilkan kurang dari batas bawah atau lebih tinggi daripada bahagian atas elemen.
    ///
    /// `size_hint()` terutamanya bertujuan untuk digunakan untuk pengoptimuman seperti menempah ruang untuk elemen aliran, tetapi tidak boleh dipercayai untuk menghilangkan pemeriksaan had dalam kod yang tidak selamat.
    /// Pelaksanaan `size_hint()` yang salah tidak boleh menyebabkan pelanggaran keselamatan memori.
    ///
    /// Yang mengatakan, pelaksanaan harus memberikan perkiraan yang tepat, kerana jika tidak, itu akan melanggar protokol trait.
    ///
    /// Pelaksanaan lalai mengembalikan `(0,` [None`]`)` yang betul untuk aliran apa pun.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}