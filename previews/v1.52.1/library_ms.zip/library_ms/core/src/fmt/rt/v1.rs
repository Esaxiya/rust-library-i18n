//! Ini adalah modul dalaman yang digunakan oleh ifmt!masa berjalan.Struktur ini dipancarkan ke array statik untuk mengompilasi rentetan format lebih awal.
//!
//! Definisi ini serupa dengan setara `ct` mereka, tetapi berbeza kerana definisi ini dapat diperuntukkan secara statik dan sedikit dioptimumkan untuk waktu proses
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Kemungkinan penjajaran yang dapat diminta sebagai bagian dari arahan pemformatan.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Petunjuk bahawa kandungan harus diselaraskan ke kiri.
    Left,
    /// Petunjuk bahawa kandungan harus sejajar dengan betul.
    Right,
    /// Petunjuk bahawa kandungan harus sejajar tengah.
    Center,
    /// Tidak ada penjajaran yang diminta.
    Unknown,
}

/// Digunakan oleh penentu [width](https://doc.rust-lang.org/std/fmt/#width) dan [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Ditentukan dengan nombor literal, menyimpan nilai
    Is(usize),
    /// Ditentukan menggunakan sintaks `$` dan `*`, menyimpan indeks menjadi `args`
    Param(usize),
    /// Tidak dinyatakan
    Implied,
}