//! `Clone` trait untuk jenis yang tidak boleh 'disalin secara tersirat'.
//!
//! Di Rust, beberapa jenis mudah adalah "implicitly copyable" dan apabila anda menetapkannya atau memberikannya sebagai argumen, penerima akan mendapat salinan, meninggalkan nilai asalnya.
//! Jenis ini tidak memerlukan peruntukan untuk menyalin dan tidak mempunyai penyelesai (iaitu, mereka tidak mengandungi kotak yang dimiliki atau melaksanakan [`Drop`]), jadi penyusun menganggapnya murah dan selamat untuk disalin.
//!
//! Untuk jenis lain, salinan mesti dibuat secara eksplisit, dengan konvensyen yang menerapkan [`Clone`] trait dan memanggil kaedah [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Contoh penggunaan asas:
//!
//! ```
//! let s = String::new(); // Jenis tali mengimplementasikan Klon
//! let copy = s.clone(); // supaya kita dapat mengklonnya
//! ```
//!
//! Untuk melaksanakan Clone trait dengan mudah, anda juga boleh menggunakan `#[derive(Clone)]`.Contoh:
//!
//! ```
//! #[derive(Clone)] // kita menambah Clone trait ke Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // dan sekarang kita boleh mengklonnya!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait biasa untuk keupayaan untuk mendua objek secara eksplisit.
///
/// Perbezaan dari [`Copy`] kerana [`Copy`] itu tersirat dan sangat murah, sementara `Clone` selalu eksplisit dan mungkin atau mungkin tidak mahal.
/// Untuk menegakkan ciri-ciri ini, Rust tidak membenarkan anda melaksanakan semula [`Copy`], tetapi anda boleh menerapkan semula `Clone` dan menjalankan kod sewenang-wenangnya.
///
/// Oleh kerana `Clone` lebih umum daripada [`Copy`], anda juga boleh menjadikan [`Copy`] menjadi `Clone` secara automatik.
///
/// ## Derivable
///
/// trait ini boleh digunakan dengan `#[derive]` jika semua medan adalah `Clone`.Pelaksanaan `derive`d [`Clone`] memanggil [`clone`] di setiap bidang.
///
/// [`clone`]: Clone::clone
///
/// Untuk struktur generik, `#[derive]` menerapkan `Clone` secara bersyarat dengan menambahkan `Clone` terikat pada parameter generik.
///
/// ```
/// // `derive` melaksanakan Klon untuk Membaca<T>apabila T adalah Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Bagaimana saya boleh melaksanakan `Clone`?
///
/// Jenis yang [`Copy`] harus mempunyai pelaksanaan `Clone` sepele.Lebih formal:
/// jika `T: Copy`, `x: T`, dan `y: &T`, maka `let x = y.clone();` bersamaan dengan `let x = *y;`.
/// Pelaksanaan manual harus berhati-hati untuk menegakkan invarian ini;namun, kod yang tidak selamat tidak boleh bergantung padanya untuk memastikan keselamatan memori.
///
/// Contohnya ialah struktur generik yang memegang penunjuk fungsi.Dalam hal ini, pelaksanaan `Clone` tidak dapat `derive`d, tetapi dapat dilaksanakan sebagai:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Pelaksana tambahan
///
/// Selain [implementors listed below][impls], jenis berikut juga menerapkan `Clone`:
///
/// * Jenis item fungsi (iaitu, jenis yang ditentukan untuk setiap fungsi)
/// * Jenis penunjuk fungsi (contohnya, `fn() -> i32`)
/// * Jenis susunan, untuk semua ukuran, jika jenis item juga menggunakan `Clone` (mis., `[i32; 123456]`)
/// * Jenis tambahan, jika setiap komponen juga menerapkan `Clone` (mis., `()`, `(i32, bool)`)
/// * Jenis penutupan, jika tidak menangkap nilai dari persekitaran atau jika semua nilai yang ditangkap itu menerapkan `Clone` sendiri.
///   Perhatikan bahawa pemboleh ubah yang ditangkap dengan rujukan bersama selalu menerapkan `Clone` (walaupun rujukan tidak), sementara pemboleh ubah yang ditangkap oleh rujukan yang berubah-ubah tidak pernah melaksanakan `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Mengembalikan salinan nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str melaksanakan Klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Melakukan tugasan salinan dari `source`.
    ///
    /// `a.clone_from(&b)` sama dengan fungsi `a = b.clone()`, tetapi boleh diganti untuk menggunakan semula sumber `a` untuk mengelakkan peruntukan yang tidak perlu.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Terbitkan makro yang menghasilkan implan trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): struktur ini hanya digunakan oleh#[derive] untuk menegaskan bahawa setiap komponen jenis menggunakan Clone atau Copy.
//
//
// Struktur ini tidak boleh muncul dalam kod pengguna.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Pelaksanaan `Clone` untuk jenis primitif.
///
/// Pelaksanaan yang tidak dapat dijelaskan dalam Rust dilaksanakan di `traits::SelectionContext::copy_clone_conditions()` di `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Rujukan bersama dapat diklon, tetapi rujukan yang dapat diubah *tidak dapat*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Rujukan bersama dapat diklon, tetapi rujukan yang dapat diubah *tidak dapat*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}