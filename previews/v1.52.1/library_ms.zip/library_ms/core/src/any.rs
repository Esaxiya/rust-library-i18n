//! Modul ini mengimplementasikan `Any` trait, yang membolehkan menaip dinamik dari mana-mana jenis `'static` melalui pantulan runtime.
//!
//! `Any` itu sendiri dapat digunakan untuk mendapatkan `TypeId`, dan mempunyai lebih banyak fitur ketika digunakan sebagai objek trait.
//! Sebagai `&dyn Any` (objek trait yang dipinjam), ia mempunyai kaedah `is` dan `downcast_ref`, untuk menguji apakah nilai yang terkandung dari jenis tertentu, dan untuk mendapatkan referensi ke nilai dalaman sebagai jenis.
//! Sebagai `&mut dyn Any`, ada juga kaedah `downcast_mut`, untuk mendapatkan rujukan yang dapat berubah pada nilai dalaman.
//! `Box<dyn Any>` menambah kaedah `downcast`, yang cuba menukar ke `Box<T>`.
//! Lihat dokumentasi [`Box`] untuk maklumat lengkap.
//!
//! Perhatikan bahawa `&dyn Any` terhad untuk menguji sama ada nilai dari jenis konkrit yang ditentukan, dan tidak dapat digunakan untuk menguji sama ada jenis mengimplementasikan trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Petunjuk pintar dan `dyn Any`
//!
//! Satu tingkah laku yang perlu diingat semasa menggunakan `Any` sebagai objek trait, terutama dengan jenis seperti `Box<dyn Any>` atau `Arc<dyn Any>`, adalah dengan hanya memanggil `.type_id()` pada nilai akan menghasilkan `TypeId` dari *kontainer*, bukan objek trait yang mendasari.
//!
//! Ini dapat dielakkan dengan menukar penunjuk pintar menjadi `&dyn Any`, yang akan mengembalikan `TypeId` objek.
//! Sebagai contoh:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Anda lebih cenderung menginginkan ini:
//! let actual_id = (&*boxed).type_id();
//! // ... daripada ini:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Pertimbangkan situasi di mana kita ingin log keluar nilai yang diteruskan ke fungsi.
//! Kami tahu nilai yang sedang kami jalankan mengimplementasikan Debug, tetapi kami tidak mengetahui jenis konkritnya.Kami ingin memberikan perlakuan khas untuk jenis tertentu: dalam hal ini mencetak panjang nilai String sebelum nilainya.
//! Kami tidak mengetahui jenis konkrit dari nilai kami pada waktu penyusunan, jadi kami perlu menggunakan refleksi waktu proses.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Fungsi logger untuk semua jenis yang melaksanakan Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Cuba ubah nilai kita menjadi `String`.
//!     // Sekiranya berjaya, kami ingin mengeluarkan panjang String dan juga nilainya.
//!     // Sekiranya tidak, ia adalah jenis yang berbeza: hanya mencetaknya tanpa hiasan.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Fungsi ini ingin log keluar parameternya sebelum melakukan kerja dengannya.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... buat kerja lain
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Mana-mana trait
///////////////////////////////////////////////////////////////////////////////

/// trait untuk meniru penaipan dinamik.
///
/// Sebilangan besar jenis menggunakan `Any`.Walau bagaimanapun, sebarang jenis yang mengandungi rujukan bukan `` statik 'tidak.
/// Lihat [module-level documentation][mod] untuk maklumat lebih lanjut.
///
/// [mod]: crate::any
// trait ini tidak selamat, walaupun kami bergantung pada spesifik fungsi `type_id` impl-satunya dalam kod yang tidak selamat (contohnya, `downcast`).Biasanya, itu akan menjadi masalah, tetapi kerana satu-satunya implan `Any` adalah implementasi selimut, tidak ada kod lain yang dapat menerapkan `Any`.
//
// Kami boleh membuat trait ini tidak selamat-ia tidak akan menyebabkan kerosakan, kerana kami mengawal semua pelaksanaan-tetapi kami memilih untuk tidak melakukannya kerana kedua-duanya tidak begitu diperlukan dan boleh membingungkan pengguna mengenai perbezaan kaedah traits dan kaedah tidak selamat (iaitu, `type_id` masih selamat untuk dihubungi, tetapi kami mungkin ingin menunjukkan seperti itu dalam dokumentasi).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Mendapat `TypeId` `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Kaedah peluasan untuk sebarang objek trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Pastikan bahawa hasilnya, menggabungkan benang dapat dicetak dan dengan itu digunakan dengan `unwrap`.
// Mungkin akhirnya tidak lagi diperlukan jika pengiriman berfungsi dengan peningkatan.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Mengembalikan `true` jika jenis kotak sama dengan `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Dapatkan `TypeId` dari jenis fungsi ini.
        let t = TypeId::of::<T>();

        // Dapatkan `TypeId` dari jenis dalam objek trait (`self`).
        let concrete = self.type_id();

        // Bandingkan kedua-dua `TypeId` pada persamaan.
        t == concrete
    }

    /// Mengembalikan sebilangan rujukan ke nilai kotak jika jenis `T`, atau `None` jika tidak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // KESELAMATAN: periksa sama ada kita menunjukkan jenis yang betul, dan kita boleh bergantung
            // yang memeriksa keselamatan memori kerana kami telah melaksanakan Mana-mana untuk semua jenis;tidak ada implikasi lain yang boleh wujud kerana mereka akan bertentangan dengan implan kita.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Mengembalikan beberapa rujukan yang dapat diubah ke nilai kotak jika jenis `T`, atau `None` jika tidak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // KESELAMATAN: periksa sama ada kita menunjukkan jenis yang betul, dan kita boleh bergantung
            // yang memeriksa keselamatan memori kerana kami telah melaksanakan Mana-mana untuk semua jenis;tidak ada implikasi lain yang boleh wujud kerana mereka akan bertentangan dengan implan kita.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Teruskan ke kaedah yang ditentukan pada jenis `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID dan kaedahnya
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` mewakili pengecam unik global untuk jenis.
///
/// Setiap `TypeId` adalah objek legap yang tidak membenarkan pemeriksaan apa yang ada di dalamnya tetapi membenarkan operasi asas seperti pengklonan, perbandingan, percetakan, dan paparan.
///
///
/// `TypeId` saat ini hanya tersedia untuk jenis yang sesuai dengan `'static`, tetapi batasan ini dapat dihapus di future.
///
/// Walaupun `TypeId` menerapkan `Hash`, `PartialOrd`, dan `Ord`, perlu diperhatikan bahawa hash dan susunannya akan berbeza antara pelepasan Rust.
/// Hati-hati dengan mempercayai mereka di dalam kod anda!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Mengembalikan `TypeId` dari jenis fungsi generik ini.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Mengembalikan nama jenis sebagai irisan rentetan.
///
/// # Note
///
/// Ini bertujuan untuk penggunaan diagnostik.
/// Isi dan format tali yang dikembalikan tidak dinyatakan, selain menjadi penerangan jenis terbaik.
/// Contohnya, antara rentetan yang mungkin dikembalikan oleh `type_name::<Option<String>>()` adalah `"Option<String>"` dan `"std::option::Option<std::string::String>"`.
///
///
/// Rentetan yang dikembalikan tidak boleh dianggap sebagai pengenal jenis yang unik kerana pelbagai jenis dapat dipetakan ke nama jenis yang sama.
/// Begitu juga, tidak ada jaminan bahawa semua bahagian jenis akan muncul dalam rentetan yang dikembalikan: sebagai contoh, penentu jangka hayat saat ini tidak disertakan.
/// Di samping itu, output boleh berubah antara versi penyusun.
///
/// Pelaksanaan semasa menggunakan infrastruktur yang sama dengan diagnostik penyusun dan debuginfo, tetapi ini tidak dijamin.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Mengembalikan nama jenis nilai runcing ke irisan rentetan.
/// Ini sama dengan `type_name::<T>()`, tetapi boleh digunakan di mana jenis pemboleh ubah tidak mudah didapati.
///
/// # Note
///
/// Ini bertujuan untuk penggunaan diagnostik.Isi dan format rentetan yang tepat tidak dinyatakan, selain menjadi penerangan jenis usaha terbaik.
/// Sebagai contoh, `type_name_of_val::<Option<String>>(None)` boleh mengembalikan `"Option<String>"` atau `"std::option::Option<std::string::String>"`, tetapi tidak `"foobar"`.
///
/// Di samping itu, output boleh berubah antara versi penyusun.
///
/// Fungsi ini tidak menyelesaikan objek trait, yang bermaksud bahawa `type_name_of_val(&7u32 as &dyn Debug)` mungkin mengembalikan `"dyn Debug"`, tetapi tidak `"u32"`.
///
/// Nama jenis tidak boleh dianggap sebagai pengenal unik jenis;
/// pelbagai jenis mungkin mempunyai nama jenis yang sama.
///
/// Pelaksanaan semasa menggunakan infrastruktur yang sama dengan diagnostik penyusun dan debuginfo, tetapi ini tidak dijamin.
///
/// # Examples
///
/// Mencetak bilangan bulat dan pengapung lalai.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}