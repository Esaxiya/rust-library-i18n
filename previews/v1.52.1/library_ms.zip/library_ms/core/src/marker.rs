//! Primitif traits dan jenis yang mewakili sifat asas jenis.
//!
//! Jenis Rust dapat dikelaskan dalam pelbagai cara yang berguna mengikut sifat intrinsiknya.
//! Klasifikasi ini dinyatakan sebagai traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Jenis yang boleh dipindahkan melintasi batas utas.
///
/// trait ini dilaksanakan secara automatik apabila penyusun menentukan ia sesuai.
///
/// Contoh jenis bukan `Kirim 'adalah penunjuk pengira rujukan [`rc::Rc`][`Rc`].
/// Sekiranya dua utas cuba mengklon [`Rc`] yang menunjukkan nilai yang dikira rujukan yang sama, mereka mungkin cuba mengemas kini kiraan rujukan pada masa yang sama, iaitu [undefined behavior][ub] kerana [`Rc`] tidak menggunakan operasi atom.
///
/// Sepupunya [`sync::Arc`][arc] memang menggunakan operasi atom (berlaku overhead) dan dengan itu `Send`.
///
/// Lihat [the Nomicon](../../nomicon/send-and-sync.html) untuk maklumat lebih lanjut.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Jenis dengan ukuran tetap yang diketahui pada masa penyusunan.
///
/// Semua parameter jenis mempunyai had tersirat `Sized`.Sintaks khas `?Sized` boleh digunakan untuk menghilangkan had ini jika tidak sesuai.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struktur FooUse(Foo<[i32]>);//ralat: Saiz tidak dilaksanakan untuk [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Satu pengecualian adalah jenis `Self` tersirat dari trait.
/// trait tidak mempunyai ikatan `Sized` tersirat kerana ini tidak sesuai dengan objek [trait] di mana, menurut definisi, trait perlu bekerjasama dengan semua pelaksana yang mungkin, dan dengan demikian boleh menjadi ukuran apa pun.
///
///
/// Walaupun Rust akan membiarkan anda mengikat `Sized` ke trait, anda tidak akan dapat menggunakannya untuk membentuk objek trait kemudian:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // biarkan y: &dyn Bar= &Impl;//ralat: trait `Bar` tidak dapat dijadikan objek
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // sebagai Default, misalnya, yang memerlukan `[T]: !Default` dapat dinilai
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Jenis yang boleh berukuran "unsized" hingga jenis bersaiz dinamik.
///
/// Sebagai contoh, jenis array berukuran `[i8; 2]` menerapkan `Unsize<[i8]>` dan `Unsize<dyn fmt::Debug>`.
///
/// Semua pelaksanaan `Unsize` disediakan secara automatik oleh penyusun.
///
/// `Unsize` dilaksanakan untuk:
///
/// - `[T; N]` ialah `Unsize<[T]>`
/// - `T` ialah `Unsize<dyn Trait>` apabila `T: Trait`
/// - `Foo<..., T, ...>` ialah `Unsize<Foo<..., U, ...>>` jika:
///   - `T: Unsize<U>`
///   - Foo adalah struktur
///   - Hanya bidang terakhir `Foo` yang mempunyai jenis yang melibatkan `T`
///   - `T` bukan sebahagian daripada jenis bidang lain
///   - `Bar<T>: Unsize<Bar<U>>`, jika medan terakhir `Foo` mempunyai jenis `Bar<T>`
///
/// `Unsize` digunakan bersama dengan [`ops::CoerceUnsized`] untuk membolehkan bekas "user-defined" seperti [`Rc`] mengandungi jenis bersaiz dinamik.
/// Lihat [DST coercion RFC][RFC982] dan [the nomicon entry on coercion][nomicon-coerce] untuk maklumat lebih lanjut.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait yang diperlukan untuk pemalar yang digunakan dalam pertandingan corak.
///
/// Apa-apa jenis yang berasal `PartialEq` secara automatik menerapkan trait ini,*tanpa mengira* sama ada parameter jenisnya menerapkan `Eq`.
///
/// Sekiranya item `const` mengandungi beberapa jenis yang tidak melaksanakan trait ini, maka jenis itu sama ada (1.) tidak melaksanakan `PartialEq` (yang bermaksud pemalar tidak akan memberikan kaedah perbandingan itu, yang mana penjanaan kod dianggap tersedia), atau (2.) yang diimplementasikan *sendiri* versi `PartialEq` (yang kami anggap tidak sesuai dengan perbandingan struktur-kesamaan).
///
///
/// Dalam salah satu daripada kedua-dua senario di atas, kami menolak penggunaan pemalar sedemikian dalam pemadanan corak.
///
/// Lihat juga [structural match RFC][RFC1445], dan [issue 63438] yang mendorong bermigrasi dari reka bentuk berdasarkan atribut ke trait ini.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait yang diperlukan untuk pemalar yang digunakan dalam pertandingan corak.
///
/// Apa-apa jenis yang berasal `Eq` secara automatik menerapkan trait ini,*tanpa mengira* sama ada parameter jenisnya menerapkan `Eq`.
///
/// Ini adalah hack untuk mengatasi batasan dalam sistem jenis kami.
///
/// # Background
///
/// Kami ingin menghendaki bahawa jenis kon yang digunakan dalam padanan corak mempunyai atribut `#[derive(PartialEq, Eq)]`.
///
/// Di dunia yang lebih ideal, kita dapat memeriksa syarat itu dengan hanya memeriksa bahawa jenis yang diberikan menerapkan `StructuralPartialEq` trait *dan*`Eq` trait.
/// Walau bagaimanapun, anda boleh mempunyai ADT yang *melakukan*`derive(PartialEq, Eq)`, dan menjadi kes yang kami mahu penyusunnya terima, namun jenis pemalarnya gagal melaksanakan `Eq`.
///
/// Yaitu, kes seperti ini:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Masalah dalam kod di atas adalah `Wrap<fn(&())>` tidak menerapkan `PartialEq`, atau `Eq`, kerana `untuk <'a> fn(&'a _)` does not implement those traits.)
///
/// Oleh itu, kita tidak boleh bergantung pada pemeriksaan naif untuk `StructuralPartialEq` dan hanya `Eq`.
///
/// Sebagai langkah mengatasi masalah ini, kami menggunakan dua traits berasingan yang disuntikkan oleh masing-masing dari dua turunan (`#[derive(PartialEq)]` dan `#[derive(Eq)]`) dan memastikan bahawa kedua-duanya hadir sebagai sebahagian daripada pemeriksaan perlawanan struktur.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Jenis yang nilainya dapat diduplikasi hanya dengan menyalin bit.
///
/// Secara lalai, pengikatan pemboleh ubah mempunyai 'semantik bergerak.'Dalam kata lain:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` telah berpindah ke `y`, sehingga tidak dapat digunakan
///
/// // println! ("{: ?}", x);//ralat: penggunaan nilai yang dipindahkan
/// ```
///
/// Walau bagaimanapun, jika jenis menggunakan `Copy`, ia mempunyai 'copy semantik':
///
/// ```
/// // Kami dapat memperoleh pelaksanaan `Copy`.
/// // `Clone` juga diperlukan, kerana ia adalah supertrait `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` adalah salinan `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Penting untuk diperhatikan bahawa dalam kedua-dua contoh ini, satu-satunya perbezaan adalah sama ada anda dibenarkan mengakses `x` selepas tugas tersebut.
/// Di bawah penutup, salinan dan pemindahan dapat mengakibatkan bit disalin dalam memori, walaupun kadangkala dioptimumkan.
///
/// ## Bagaimana saya boleh melaksanakan `Copy`?
///
/// Terdapat dua cara untuk melaksanakan `Copy` pada jenis anda.Yang paling mudah adalah menggunakan `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Anda juga boleh melaksanakan `Copy` dan `Clone` secara manual:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Terdapat perbezaan kecil antara keduanya: strategi `derive` juga akan menempatkan `Copy` terikat pada parameter jenis, yang tidak selalu diinginkan.
///
/// ## Apakah perbezaan antara `Copy` dan `Clone`?
///
/// Salinan berlaku secara tersirat, sebagai contoh sebagai tugas `y = x`.Kelakuan `Copy` tidak berlebihan;ia adalah salinan bit-bijaksana yang ringkas.
///
/// Pengklonan adalah tindakan eksplisit, `x.clone()`.Pelaksanaan [`Clone`] dapat memberikan tingkah laku khusus jenis yang diperlukan untuk menduplikasi nilai dengan selamat.
/// Sebagai contoh, pelaksanaan [`Clone`] untuk [`String`] perlu menyalin penunjuk rentetan ke arah timbunan.
/// Salinan bitcoin sederhana nilai [`String`] hanya akan menyalin penunjuk, yang membawa dua kali ganda percuma.
/// Atas sebab ini, [`String`] adalah [`Clone`] tetapi bukan `Copy`.
///
/// [`Clone`] adalah supertrait `Copy`, jadi semua yang `Copy` juga mesti melaksanakan [`Clone`].
/// Sekiranya jenisnya adalah `Copy` maka pelaksanaan [`Clone`] hanya perlu mengembalikan `*self` (lihat contoh di atas).
///
/// ## Bilakah jenis saya boleh menjadi `Copy`?
///
/// Jenis boleh melaksanakan `Copy` jika semua komponennya melaksanakan `Copy`.Contohnya, struktur ini boleh menjadi `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktur boleh menjadi `Copy`, dan [`i32`] adalah `Copy`, oleh itu `Point` layak menjadi `Copy`.
/// Sebaliknya, pertimbangkan
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktur `PointList` tidak dapat menerapkan `Copy`, kerana [`Vec<T>`] bukan `Copy`.Sekiranya kami berusaha mendapatkan pelaksanaan `Copy`, kami akan mendapat ralat:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Rujukan bersama (`&T`) juga `Copy`, jadi jenisnya boleh menjadi `Copy`, bahkan jika ia mengandungi rujukan bersama jenis `T` yang *bukan*`Copy`.
/// Pertimbangkan struktur berikut, yang dapat menerapkan `Copy`, kerana hanya menyimpan *rujukan bersama* untuk jenis `PointList` bukan `` Salin '' kami dari atas:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Bilakah *tidak* jenis saya boleh menjadi `Copy`?
///
/// Beberapa jenis tidak dapat disalin dengan selamat.Sebagai contoh, menyalin `&mut T` akan membuat rujukan yang dapat diubah alias.
/// Menyalin [`String`] akan menggandakan tanggungjawab untuk menguruskan penyangga [`String`], yang menghasilkan percuma dua kali ganda.
///
/// Menyamaratakan kes terakhir, jenis apa pun yang melaksanakan [`Drop`] tidak boleh `Copy`, kerana ia menguruskan beberapa sumber selain bait [`size_of::<T>`] sendiri.
///
/// Sekiranya anda cuba menerapkan `Copy` pada struktur atau enum yang mengandungi data bukan `` Salin ', anda akan mendapat ralat [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Bilakah *harus* jenis saya `Copy`?
///
/// Secara amnya, jika _can_ jenis anda melaksanakan `Copy`, semestinya.
/// Perlu diingat, bahawa melaksanakan `Copy` adalah sebahagian daripada API awam jenis anda.
/// Sekiranya jenisnya mungkin menjadi bukan `` Salin '' di future, mungkin bijaksana untuk menghilangkan pelaksanaan `Copy` sekarang, untuk mengelakkan perubahan API yang pecah.
///
/// ## Pelaksana tambahan
///
/// Selain [implementors listed below][impls], jenis berikut juga menerapkan `Copy`:
///
/// * Jenis item fungsi (iaitu, jenis yang ditentukan untuk setiap fungsi)
/// * Jenis penunjuk fungsi (contohnya, `fn() -> i32`)
/// * Jenis susunan, untuk semua ukuran, jika jenis item juga menggunakan `Copy` (mis., `[i32; 123456]`)
/// * Jenis tambahan, jika setiap komponen juga menerapkan `Copy` (mis., `()`, `(i32, bool)`)
/// * Jenis penutupan, jika tidak menangkap nilai dari persekitaran atau jika semua nilai yang ditangkap itu menerapkan `Copy` sendiri.
///   Perhatikan bahawa pemboleh ubah yang ditangkap dengan rujukan bersama selalu menerapkan `Copy` (walaupun rujukan tidak), sementara pemboleh ubah yang ditangkap oleh rujukan yang berubah-ubah tidak pernah melaksanakan `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ini membolehkan menyalin jenis yang tidak melaksanakan `Copy` kerana had seumur hidup yang tidak memuaskan (menyalin `A<'_>` ketika hanya `A<'static>: Copy` dan `A<'_>: Clone`).
// Kami mempunyai atribut ini di sini buat masa ini hanya kerana terdapat beberapa pengkhususan yang ada pada `Copy` yang sudah ada di perpustakaan standard, dan tidak ada cara untuk selamatkan tingkah laku ini sekarang.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Terbitkan makro yang menghasilkan implan trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Jenis yang selamat untuk berkongsi rujukan antara utas.
///
/// trait ini dilaksanakan secara automatik apabila penyusun menentukan ia sesuai.
///
/// Definisi yang tepat adalah: jenis `T` adalah [`Sync`] jika dan hanya jika `&T` adalah [`Send`].
/// Dengan kata lain, jika tidak ada kemungkinan [undefined behavior][ub] (termasuk perlumbaan data) ketika melewati rujukan `&T` antara utas.
///
/// Seperti yang dijangkakan, jenis primitif seperti [`u8`] dan [`f64`] semuanya [`Sync`], dan begitu juga jenis agregat sederhana yang mengandunginya, seperti tupel, struktur dan enum.
/// Lebih banyak contoh jenis [`Sync`] asas termasuk jenis "immutable" seperti `&T`, dan yang mempunyai kebolehubahan yang diwarisi sederhana, seperti [`Box<T>`][box], [`Vec<T>`][vec] dan kebanyakan jenis koleksi lain.
///
/// (Parameter generik harus [`Sync`] agar bekasnya menjadi [`Sync`].)
///
/// Konsekuensi definisi yang agak mengejutkan ialah `&mut T` adalah `Sync` (jika `T` adalah `Sync`) walaupun sepertinya mungkin memberikan mutasi yang tidak diselaraskan.
/// Caranya adalah bahawa rujukan yang dapat diubah di sebalik rujukan bersama (iaitu, `& &mut T`) menjadi hanya baca, seolah-olah itu adalah `& &T`.
/// Oleh itu, tidak ada risiko perlumbaan data.
///
/// Jenis yang bukan `Sync` adalah jenis yang mempunyai "interior mutability" dalam bentuk yang tidak selamat dari benang, seperti [`Cell`][cell] dan [`RefCell`][refcell].
/// Jenis ini memungkinkan untuk mutasi kandungannya walaupun melalui rujukan bersama yang tidak berubah.
/// Contohnya kaedah `set` pada [`Cell<T>`][cell] mengambil `&self`, jadi ia hanya memerlukan [`&Cell<T>`][cell] rujukan bersama.
/// Kaedah ini tidak melakukan penyegerakan, oleh itu [`Cell`][cell] tidak boleh menjadi `Sync`.
///
/// Contoh lain dari jenis bukan-Sync` adalah penunjuk pengira rujukan [`Rc`][rc].
/// Dengan adanya rujukan [`&Rc<T>`][rc], anda dapat mengklon [`Rc<T>`][rc] baru, mengubah kiraan rujukan dengan cara bukan atom.
///
/// Untuk kes apabila seseorang memerlukan kebolehubahan dalaman yang selamat dari benang, Rust menyediakan [atomic data types], serta penguncian eksplisit melalui [`sync::Mutex`][mutex] dan [`sync::RwLock`][rwlock].
/// Jenis ini memastikan bahawa mutasi tidak dapat menyebabkan perlumbaan data, oleh itu jenisnya adalah `Sync`.
/// Begitu juga, [`sync::Arc`][arc] menyediakan analog selamat dari utas [`Rc`][rc].
///
/// Sebarang jenis dengan kebolehubahan dalaman juga mesti menggunakan pembungkus [`cell::UnsafeCell`][unsafecell] di sekitar value(s) yang dapat dimutasi melalui rujukan bersama.
/// Gagal melakukan ini adalah [undefined behavior][ub].
/// Contohnya, [`transmute`][transmute]-ing dari `&T` ke `&mut T` tidak sah.
///
/// Lihat [the Nomicon][nomicon-send-and-sync] untuk maklumat lebih lanjut mengenai `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): sekali menyokong untuk menambah nota di `rustc_on_unimplemented` dalam versi beta, dan telah diperluas untuk memeriksa apakah penutupan berada di mana saja dalam rantai keperluan, lanjutkan dengan (#48534) seperti itu:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Jenis bersaiz sifar digunakan untuk menandakan barang yang "act like" mereka miliki `T`.
///
/// Menambah medan `PhantomData<T>` ke jenis anda memberitahu penyusun bahawa jenis anda bertindak seolah-olah menyimpan nilai jenis `T`, walaupun sebenarnya tidak.
/// Maklumat ini digunakan semasa mengira sifat keselamatan tertentu.
///
/// Untuk penjelasan yang lebih mendalam mengenai cara menggunakan `PhantomData<T>`, sila lihat [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Nota mengerikan 👻👻👻
///
/// Walaupun kedua-duanya mempunyai nama yang menakutkan, `PhantomData` dan 'jenis hantu' berkaitan, tetapi tidak serupa.Parameter jenis hantu hanyalah parameter jenis yang tidak pernah digunakan.
/// Di Rust, ini sering menyebabkan pengkompil mengeluh, dan jalan keluarnya adalah dengan menambahkan penggunaan "dummy" dengan cara `PhantomData`.
///
/// # Examples
///
/// ## Parameter jangka hayat yang tidak digunakan
///
/// Mungkin kes penggunaan yang paling biasa untuk `PhantomData` adalah struktur yang mempunyai parameter seumur hidup yang tidak digunakan, biasanya sebagai sebahagian daripada beberapa kod yang tidak selamat.
/// Sebagai contoh, berikut adalah struktur `Slice` yang mempunyai dua penunjuk jenis `*const T`, mungkin menunjuk ke array di suatu tempat:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tujuannya adalah bahawa data yang mendasari hanya berlaku untuk `'a` seumur hidup, jadi `Slice` tidak boleh melebihi `'a`.
/// Namun, maksud ini tidak dinyatakan dalam kod, kerana tidak ada penggunaan `'a` seumur hidup dan oleh itu tidak jelas data apa yang digunakannya.
/// Kita boleh membetulkannya dengan memberitahu penyusun untuk bertindak *seolah-olah* struktur `Slice` mengandungi rujukan `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ini juga memerlukan penjelasan `T: 'a`, yang menunjukkan bahawa sebarang rujukan di `T` berlaku sepanjang `'a` seumur hidup.
///
/// Semasa memulakan `Slice` anda hanya memberikan nilai `PhantomData` untuk bidang `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parameter jenis yang tidak digunakan
///
/// Kadang kala anda mempunyai parameter jenis yang tidak digunakan yang menunjukkan jenis data yang merupakan struktur "tied", walaupun data tersebut sebenarnya tidak terdapat dalam struktur itu sendiri.
/// Berikut adalah contoh di mana ini timbul dengan [FFI].
/// Antara muka asing menggunakan pemegang jenis `*mut ()` untuk merujuk kepada nilai Rust dari pelbagai jenis.
/// Kami mengesan jenis Rust menggunakan parameter jenis hantu pada struktur `ExternalResource` yang membungkus pemegang.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Pemilikan dan drop check
///
/// Menambah medan jenis `PhantomData<T>` menunjukkan bahawa jenis anda memiliki data jenis `T`.Ini seterusnya menunjukkan bahawa apabila jenis anda dijatuhkan, ia mungkin menjatuhkan satu atau lebih contoh jenis `T`.
/// Ini berkaitan dengan analisis [drop check] penyusun Rust.
///
/// Sekiranya struktur anda sebenarnya tidak *memiliki* data jenis `T`, lebih baik menggunakan jenis rujukan, seperti `PhantomData<&'a T>` (ideally) atau `PhantomData<*const T>` (jika tidak berlaku seumur hidup), agar tidak menunjukkan kepemilikan.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-internal trait digunakan untuk menunjukkan jenis diskriminasi enum.
///
/// trait ini dilaksanakan secara automatik untuk setiap jenis dan tidak memberikan jaminan kepada [`mem::Discriminant`].
/// Adalah **tingkah laku yang tidak ditentukan** untuk bertukar antara `DiscriminantKind::Discriminant` dan `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Jenis diskriminan, yang mesti memenuhi trait bounds yang diperlukan oleh `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internal trait digunakan untuk menentukan sama ada jenis mengandungi `UnsafeCell` secara dalaman, tetapi tidak melalui arahan.
///
/// Ini mempengaruhi, misalnya, sama ada `static` jenis itu diletakkan dalam memori statik hanya baca atau memori statik yang boleh ditulis.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Jenis yang boleh dipindahkan dengan selamat setelah disematkan.
///
/// Rust sendiri tidak mempunyai tanggapan mengenai jenis yang tidak bergerak, dan menganggap pergerakan (misalnya, melalui penugasan atau [`mem::replace`]) sentiasa selamat.
///
/// Jenis [`Pin`][Pin] digunakan sebagai gantinya untuk mencegah pergerakan melalui sistem jenis.Penunjuk `P<T>` yang dibalut dengan pembungkus [`Pin<P<T>>`][Pin] tidak dapat dikeluarkan.
/// Lihat dokumentasi [`pin` module] untuk maklumat lebih lanjut mengenai penyematan.
///
/// Menerapkan `Unpin` trait untuk `T` akan membuang sekatan penentuan jenis, yang kemudian membolehkan memindahkan `T` keluar dari [`Pin<P<T>>`][Pin] dengan fungsi seperti [`mem::replace`].
///
///
/// `Unpin` tidak mempunyai kesan sama sekali untuk data yang tidak disematkan.
/// Khususnya, [`mem::replace`] dengan senang hati memindahkan data `!Unpin` (ia berfungsi untuk `&mut T` mana pun, bukan hanya ketika `T: Unpin`).
/// Namun, anda tidak dapat menggunakan [`mem::replace`] pada data yang dibungkus dalam [`Pin<P<T>>`][Pin] kerana anda tidak dapat mendapatkan `&mut T` yang anda perlukan untuk itu, dan *itulah* yang menjadikan sistem ini berfungsi.
///
/// Oleh itu, ini hanya boleh dilakukan pada jenis yang melaksanakan `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Kami memerlukan rujukan yang boleh diubah untuk memanggil `mem::replace`.
/// // Kita boleh mendapatkan rujukan seperti itu dengan (implicitly) memanggil `Pin::deref_mut`, tetapi itu hanya mungkin kerana `String` menerapkan `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait ini dilaksanakan secara automatik untuk hampir semua jenis.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Jenis penanda yang tidak melaksanakan `Unpin`.
///
/// Sekiranya jenis mengandungi `PhantomPinned`, ia tidak akan melaksanakan `Unpin` secara lalai.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Pelaksanaan `Copy` untuk jenis primitif.
///
/// Pelaksanaan yang tidak dapat dijelaskan dalam Rust dilaksanakan di `traits::SelectionContext::copy_clone_conditions()` di `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Rujukan bersama dapat disalin, tetapi rujukan yang tidak dapat diubah *tidak dapat*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}