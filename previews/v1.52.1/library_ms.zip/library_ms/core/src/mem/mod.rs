//! Fungsi asas untuk menangani memori.
//!
//! Modul ini mengandungi fungsi untuk menanyakan ukuran dan penjajaran jenis, memulai dan memanipulasi memori.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Mengambil hak milik dan "forgets" mengenai nilai **tanpa menjalankan pemusnahnya**.
///
/// Segala sumber yang dikendalikan oleh nilai, seperti memori timbunan atau pemegang fail, akan kekal selama-lamanya dalam keadaan tidak dapat dicapai.Namun, ia tidak menjamin bahawa petunjuk ke memori ini akan tetap berlaku.
///
/// * Sekiranya anda ingin membocorkan memori, lihat [`Box::leak`].
/// * Sekiranya anda ingin mendapatkan penunjuk mentah ke memori, lihat [`Box::into_raw`].
/// * Sekiranya anda ingin membuang nilai dengan betul, menjalankan pemusnahnya, lihat [`mem::drop`].
///
/// # Safety
///
/// `forget` tidak ditandakan sebagai `unsafe`, kerana jaminan keselamatan Rust tidak termasuk jaminan bahawa pemusnah akan selalu berjalan.
/// Sebagai contoh, program dapat membuat kitaran rujukan menggunakan [`Rc`][rc], atau memanggil [`process::exit`][exit] untuk keluar tanpa menjalankan pemusnah.
/// Oleh itu, membenarkan `mem::forget` dari kod selamat tidak secara asasnya mengubah jaminan keselamatan Rust.
///
/// Yang mengatakan, kebocoran sumber seperti memori atau objek I/O biasanya tidak diingini.
/// Keperluannya terdapat dalam beberapa kes penggunaan khusus untuk FFI atau kod yang tidak selamat, tetapi walaupun begitu, [`ManuallyDrop`] biasanya disukai.
///
/// Kerana melupakan suatu nilai dibenarkan, setiap kod `unsafe` yang anda tulis mesti membenarkan kemungkinan ini.Anda tidak dapat mengembalikan nilai dan mengharapkan pemanggil semestinya menjalankan pemusnah nilai.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Penggunaan selamat kanonik `mem::forget` adalah untuk mengelakkan pemusnah nilai yang dilaksanakan oleh `Drop` trait.Sebagai contoh, ini akan membocorkan `File`, iaitu
/// menuntut semula ruang yang diambil oleh pemboleh ubah tetapi tidak pernah menutup sumber sistem yang mendasari:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ini berguna apabila pemilikan sumber yang mendasari sebelumnya dipindahkan ke kod di luar Rust, misalnya dengan menghantar deskriptor fail mentah ke kod C.
///
/// # Hubungan dengan `ManuallyDrop`
///
/// Walaupun `mem::forget` juga dapat digunakan untuk memindahkan *memori* pemilikan, melakukannya adalah ralat.
/// [`ManuallyDrop`] harus digunakan sebagai gantinya.Pertimbangkan, misalnya, kod ini:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Bina `String` menggunakan kandungan `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // bocor `v` kerana ingatannya kini diuruskan oleh `s`
/// mem::forget(v);  // KESALAHAN, v tidak sah dan tidak boleh diteruskan ke fungsi
/// assert_eq!(s, "Az");
/// // `s` secara implisit dijatuhkan dan ingatannya dialihkan.
/// ```
///
/// Terdapat dua masalah dengan contoh di atas:
///
/// * Sekiranya lebih banyak kod ditambahkan antara pembinaan `String` dan pemanggilan `mem::forget()`, panic di dalamnya akan menyebabkan dua kali ganda bebas kerana memori yang sama dikendalikan oleh `v` dan `s`.
/// * Setelah memanggil `v.as_mut_ptr()` dan menghantar pemilikan data ke `s`, nilai `v` tidak sah.
/// Walaupun nilai hanya dipindahkan ke `mem::forget` (yang tidak akan memeriksanya), beberapa jenis mempunyai syarat ketat terhadap nilai yang menjadikannya tidak sah ketika menggantung atau tidak lagi dimiliki.
/// Menggunakan nilai yang tidak betul dengan cara apa pun, termasuk menyerahkannya atau mengembalikannya dari fungsi, merupakan tingkah laku yang tidak ditentukan dan boleh melanggar andaian yang dibuat oleh penyusun.
///
/// Beralih ke `ManuallyDrop` mengelakkan kedua-dua masalah:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Sebelum kita membongkar `v` ke bahagian mentahnya, pastikan ia tidak jatuh!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Sekarang bongkar `v`.Operasi ini tidak boleh panic, jadi tidak ada kebocoran.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Akhirnya, bina `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` secara implisit dijatuhkan dan ingatannya dialihkan.
/// ```
///
/// `ManuallyDrop` dengan kuat mencegah bebas dua kali ganda kerana kami mematikan pemusnah `v` sebelum melakukan perkara lain.
/// `mem::forget()` tidak membenarkan ini kerana ia menghabiskan hujahnya, memaksa kami memanggilnya hanya setelah mengeluarkan apa sahaja yang kami perlukan dari `v`.
/// Walaupun panic diperkenalkan antara pembinaan `ManuallyDrop` dan membina tali (yang tidak dapat terjadi dalam kod seperti yang ditunjukkan), ia akan mengakibatkan kebocoran dan tidak bebas ganda.
/// Dengan kata lain, `ManuallyDrop` salah pada sisi bocor dan bukannya salah pada sisi (double-) jatuh.
///
/// Juga, `ManuallyDrop` menghalangi kita untuk tidak harus "touch" `v` setelah memindahkan hak milik ke `s`-langkah terakhir berinteraksi dengan `v` untuk membuangnya tanpa menjalankan pemusnahnya dapat dielakkan sepenuhnya.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Seperti [`forget`], tetapi juga menerima nilai yang tidak berukuran.
///
/// Fungsi ini hanyalah shim yang ingin dikeluarkan apabila ciri `unsized_locals` stabil.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Mengembalikan ukuran jenis dalam bait.
///
/// Lebih khusus lagi, ini adalah pengimbangan dalam bait antara elemen berturut-turut dalam array dengan jenis item tersebut termasuk pelapisan penjajaran.
///
/// Oleh itu, untuk sebarang jenis `T` dan panjang `n`, `[T; n]` mempunyai ukuran `n * size_of::<T>()`.
///
/// Secara umum, ukuran jenis tidak stabil di seluruh kompilasi, tetapi jenis tertentu seperti primitif.
///
/// Jadual berikut memberikan ukuran untuk primitif.
///
/// Jenis |saiz: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Tambahan pula, `usize` dan `isize` mempunyai ukuran yang sama.
///
/// Jenis `*const T`, `&T`, `Box<T>`, `Option<&T>`, dan `Option<Box<T>>` semuanya mempunyai ukuran yang sama.
/// Sekiranya `T` Berukuran, semua jenis itu mempunyai ukuran yang sama dengan `usize`.
///
/// Kebolehubahan penunjuk tidak mengubah ukurannya.Oleh itu, `&T` dan `&mut T` mempunyai ukuran yang sama.
/// Begitu juga untuk `*const T` dan `* mut T`.
///
/// # Saiz barang `#[repr(C)]`
///
/// Perwakilan `C` untuk item mempunyai susun atur yang ditentukan.
/// Dengan susun atur ini, ukuran item juga stabil selagi semua bidang mempunyai ukuran yang stabil.
///
/// ## Saiz Struktur
///
/// Untuk `structs`, ukuran ditentukan oleh algoritma berikut.
///
/// Untuk setiap bidang dalam struktur yang diperintahkan dengan perintah deklarasi:
///
/// 1. Tambah ukuran bidang.
/// 2. Bundarkan ukuran semasa ke gandaan terdekat [alignment] medan seterusnya.
///
/// Akhirnya, bulatkan ukuran struktur ke gandaan [alignment] terdekat.
/// Penjajaran struktur biasanya merupakan penjajaran terbesar dari semua bidangnya;ini boleh diubah dengan penggunaan `repr(align(N))`.
///
/// Tidak seperti `C`, struktur bersaiz sifar tidak dibundarkan hingga satu bait berukuran.
///
/// ## Saiz Bilangan
///
/// Jumlah yang tidak membawa data selain diskriminan mempunyai ukuran yang sama dengan C enum pada platform yang mereka kumpulkan.
///
/// ## Saiz Kesatuan
///
/// Ukuran kesatuan adalah ukuran bidang terbesarnya.
///
/// Tidak seperti `C`, kesatuan bersaiz sifar tidak dibundarkan dengan ukuran satu bait.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Beberapa primitif
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Beberapa tatasusunan
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Persamaan ukuran penunjuk
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Menggunakan `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Ukuran medan pertama adalah 1, jadi tambahkan 1 pada ukuran.Saiz adalah 1.
/// // Penjajaran medan kedua adalah 2, jadi tambahkan 1 pada ukuran untuk padding.Saiz adalah 2.
/// // Ukuran medan kedua adalah 2, jadi tambahkan 2 pada ukuran.Saiznya 4.
/// // Penjajaran medan ketiga adalah 1, jadi tambahkan 0 pada ukuran untuk padding.Saiznya 4.
/// // Ukuran medan ketiga adalah 1, jadi tambahkan 1 pada ukuran.Saiznya 5.
/// // Akhirnya, penjajaran struktur adalah 2 (kerana penjajaran terbesar di antara bidangnya adalah 2), jadi tambahkan 1 pada ukuran untuk padding.
/// // Saiznya 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs mengikut peraturan yang sama.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Perhatikan bahawa menyusun semula medan dapat menurunkan ukuran.
/// // Kita boleh membuang kedua-dua bait padding dengan meletakkan `third` sebelum `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Ukuran Union adalah ukuran bidang terbesar.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Mengembalikan ukuran nilai runcing ke dalam bait.
///
/// Ini biasanya sama dengan `size_of::<T>()`.
/// Namun, apabila `T` * tidak memiliki ukuran yang diketahui secara statistik, misalnya, potongan [`[T]`][slice] atau [trait object], maka `size_of_val` dapat digunakan untuk mendapatkan ukuran yang diketahui secara dinamis.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KESELAMATAN: `val` adalah rujukan, jadi ini adalah penunjuk mentah yang sah
    unsafe { intrinsics::size_of_val(val) }
}

/// Mengembalikan ukuran nilai runcing ke dalam bait.
///
/// Ini biasanya sama dengan `size_of::<T>()`.Namun, apabila `T` * tidak memiliki ukuran yang diketahui secara statistik, misalnya, potongan [`[T]`][slice] atau [trait object], maka `size_of_val_raw` dapat digunakan untuk mendapatkan ukuran yang diketahui secara dinamis.
///
/// # Safety
///
/// Fungsi ini selamat dipanggil jika keadaan berikut berlaku:
///
/// - Sekiranya `T` adalah `Sized`, fungsi ini selalu selamat dipanggil.
/// - Sekiranya ekor `T` yang tidak bersaiz adalah:
///     - [slice], maka panjang ekor irisan mestilah bilangan bulat yang diinisialisasi, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
///     - [trait object], maka bahagian vtable dari penunjuk mesti menunjukkan vtable yang sah yang diperolehi dengan paksaan tidak berukuran, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
///
///     - (unstable) [extern type], maka fungsi ini selalu selamat dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, kerana susun atur jenis luaran tidak diketahui.
///     Ini adalah kelakuan yang sama dengan [`size_of_val`] yang merujuk pada jenis dengan ekor jenis luaran.
///     - jika tidak, secara konservatif tidak dibenarkan memanggil fungsi ini.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KESELAMATAN: pemanggil mesti memberikan penunjuk mentah yang sah
    unsafe { intrinsics::size_of_val(val) }
}

/// Mengembalikan penjajaran minimum yang diperlukan [ABI].
///
/// Setiap rujukan pada nilai jenis `T` mestilah gandaan nombor ini.
///
/// Ini adalah penjajaran yang digunakan untuk bidang struktur.Ia mungkin lebih kecil daripada penjajaran yang disukai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mengembalikan penjajaran minimum [ABI] yang diperlukan untuk jenis nilai yang ditunjukkan oleh `val`.
///
/// Setiap rujukan pada nilai jenis `T` mestilah gandaan nombor ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KESELAMATAN: val adalah rujukan, jadi ini adalah penunjuk mentah yang sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan penjajaran minimum yang diperlukan [ABI].
///
/// Setiap rujukan pada nilai jenis `T` mestilah gandaan nombor ini.
///
/// Ini adalah penjajaran yang digunakan untuk bidang struktur.Ia mungkin lebih kecil daripada penjajaran yang disukai.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Mengembalikan penjajaran minimum [ABI] yang diperlukan untuk jenis nilai yang ditunjukkan oleh `val`.
///
/// Setiap rujukan pada nilai jenis `T` mestilah gandaan nombor ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KESELAMATAN: val adalah rujukan, jadi ini adalah penunjuk mentah yang sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan penjajaran minimum [ABI] yang diperlukan untuk jenis nilai yang ditunjukkan oleh `val`.
///
/// Setiap rujukan pada nilai jenis `T` mestilah gandaan nombor ini.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Fungsi ini selamat dipanggil jika keadaan berikut berlaku:
///
/// - Sekiranya `T` adalah `Sized`, fungsi ini selalu selamat dipanggil.
/// - Sekiranya ekor `T` yang tidak bersaiz adalah:
///     - [slice], maka panjang ekor irisan mestilah bilangan bulat yang diinisialisasi, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
///     - [trait object], maka bahagian vtable dari penunjuk mesti menunjukkan vtable yang sah yang diperolehi dengan paksaan tidak berukuran, dan ukuran *keseluruhan nilai*(panjang ekor dinamik + awalan bersaiz statik) mesti sesuai dengan `isize`.
///
///     - (unstable) [extern type], maka fungsi ini selalu selamat dipanggil, tetapi mungkin panic atau sebaliknya mengembalikan nilai yang salah, kerana susun atur jenis luaran tidak diketahui.
///     Ini adalah kelakuan yang sama dengan [`align_of_val`] yang merujuk pada jenis dengan ekor jenis luaran.
///     - jika tidak, secara konservatif tidak dibenarkan memanggil fungsi ini.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KESELAMATAN: pemanggil mesti memberikan penunjuk mentah yang sah
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Mengembalikan `true` jika nilai jatuh dari jenis `T` penting.
///
/// Ini hanyalah petunjuk pengoptimuman, dan dapat dilaksanakan secara konservatif:
/// ia mungkin mengembalikan `true` untuk jenis yang sebenarnya tidak perlu dijatuhkan.
/// Oleh itu, selalu mengembalikan `true` adalah pelaksanaan fungsi ini yang sah.Tetapi jika fungsi ini benar-benar mengembalikan `false`, maka anda pasti menjatuhkan `T` tidak mempunyai kesan sampingan.
///
/// Pelaksanaan tahap rendah seperti koleksi, yang perlu menjatuhkan data mereka secara manual, harus menggunakan fungsi ini untuk mengelakkan usaha membuang semua kandungannya secara tidak perlu ketika mereka dimusnahkan.
///
/// Ini mungkin tidak membuat perbezaan dalam pembebasan pelepasan (di mana gelung yang tidak mempunyai kesan sampingan mudah dikesan dan dihilangkan), tetapi sering kali menjadi kemenangan besar untuk pembuatan debug.
///
/// Perhatikan bahawa [`drop_in_place`] sudah melakukan pemeriksaan ini, jadi jika beban kerja anda dapat dikurangkan menjadi sebilangan kecil panggilan [`drop_in_place`], penggunaan ini tidak perlu.
/// Terutama perhatikan bahawa anda dapat [`drop_in_place`] sepotong, dan itu akan melakukan semakan satu keperluan_drop untuk semua nilai.
///
/// Jenis seperti Vec oleh itu hanya `drop_in_place(&mut self[..])` tanpa menggunakan `needs_drop` secara eksplisit.
/// Jenis seperti [`HashMap`], sebaliknya, harus menjatuhkan nilai satu demi satu dan harus menggunakan API ini.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Berikut adalah contoh bagaimana koleksi boleh menggunakan `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // jatuhkan data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Mengembalikan nilai jenis `T` yang diwakili oleh pola byte semua-sifar.
///
/// Ini bermaksud, sebagai contoh, bait padding dalam `(u8, u16)` tidak semestinya sifar.
///
/// Tidak ada jaminan bahawa pola byte semua-sifar mewakili nilai sah dari beberapa jenis `T`.
/// Sebagai contoh, pola byte semua-sifar bukan nilai yang sah untuk jenis rujukan (`&T`, `&mut T`) dan penunjuk fungsi.
/// Menggunakan `zeroed` pada jenis seperti itu menyebabkan [undefined behavior][ub] segera kerana [the Rust compiler assumes][inv] yang selalu ada nilai yang sah dalam pemboleh ubah yang dianggapnya diinisialisasi.
///
///
/// Ini mempunyai kesan yang sama dengan [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Ia berguna untuk FFI kadang-kadang, tetapi umumnya harus dielakkan.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Penggunaan fungsi ini dengan betul: memulakan bilangan bulat dengan sifar.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Salah* penggunaan fungsi ini: memulakan rujukan dengan sifar.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Tingkah laku yang tidak ditentukan!
/// let _y: fn() = unsafe { mem::zeroed() }; // Dan lagi!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KESELAMATAN: pemanggil mesti menjamin bahawa nilai semua-sifar adalah sah untuk `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Memintas memori permulaan-normal Rust memeriksa dengan berpura-pura menghasilkan nilai jenis `T`, tanpa melakukan apa-apa.
///
/// **Fungsi ini tidak digunakan lagi.** Gunakan [`MaybeUninit<T>`] sebagai gantinya.
///
/// Sebab penghentian adalah kerana fungsi pada dasarnya tidak dapat digunakan dengan betul: ia mempunyai kesan yang sama dengan [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Seperti yang dijelaskan oleh [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] yang diinisialisasi dengan betul.
/// Akibatnya, memanggil misalnya
/// `mem::uninitialized::<bool>()` menyebabkan tingkah laku langsung yang tidak ditentukan kerana mengembalikan `bool` yang tidak semestinya sama ada `true` atau `false`.
/// Lebih buruk lagi, memori yang benar-benar tidak dimulakan seperti apa yang dikembalikan di sini adalah istimewa kerana penyusun tahu bahawa ia tidak mempunyai nilai tetap.
/// Ini menjadikan tingkah laku yang tidak ditentukan untuk memiliki data yang tidak diinisialisasi dalam pemboleh ubah walaupun pemboleh ubah tersebut mempunyai jenis bilangan bulat.
/// (Perhatikan bahawa peraturan tentang bilangan bulat yang belum diinisialisasi belum diselesaikan, tetapi sampai ada, disarankan untuk menghindarinya.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KESELAMATAN: pemanggil mesti menjamin bahawa nilai unitialized adalah sah untuk `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Tukar nilai di dua lokasi yang boleh berubah, tanpa menyusun satu sama lain.
///
/// * Sekiranya anda ingin menukar dengan nilai lalai atau palsu, lihat [`take`].
/// * Sekiranya anda ingin menukar dengan nilai lulus, mengembalikan nilai lama, lihat [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KESELAMATAN: penunjuk mentah telah dibuat dari rujukan boleh ubah yang selamat yang memenuhi semua
    // kekangan pada `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Menggantikan `dest` dengan nilai lalai `T`, mengembalikan nilai `dest` sebelumnya.
///
/// * Sekiranya anda ingin mengganti nilai dua pemboleh ubah, lihat [`swap`].
/// * Sekiranya anda ingin mengganti dengan nilai lulus dan bukan nilai lalai, lihat [`replace`].
///
/// # Examples
///
/// Contoh mudah:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` membolehkan mengambil hak milik bidang struktur dengan menggantinya dengan nilai "empty".
/// Tanpa `take` anda boleh menghadapi masalah seperti ini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Perhatikan bahawa `T` tidak semestinya menerapkan [`Clone`], jadi ia bahkan tidak dapat mengklon dan menetapkan semula `self.buf`.
/// Tetapi `take` dapat digunakan untuk memisahkan nilai asal `self.buf` dari `self`, memungkinkan untuk dikembalikan:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Pindahkan `src` ke `dest` yang dirujuk, mengembalikan nilai `dest` sebelumnya.
///
/// Nilai tidak dijatuhkan.
///
/// * Sekiranya anda ingin mengganti nilai dua pemboleh ubah, lihat [`swap`].
/// * Sekiranya anda ingin mengganti dengan nilai lalai, lihat [`take`].
///
/// # Examples
///
/// Contoh mudah:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` membenarkan penggunaan medan struktur dengan menggantinya dengan nilai yang lain.
/// Tanpa `replace` anda boleh menghadapi masalah seperti ini:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Perhatikan bahawa `T` tidak semestinya menerapkan [`Clone`], jadi kami bahkan tidak dapat mengklon `self.buf[i]` untuk mengelakkan bergerak.
/// Tetapi `replace` dapat digunakan untuk memisahkan nilai asal pada indeks itu dari `self`, memungkinkan untuk dikembalikan:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // KESELAMATAN: Kami membaca dari `dest` tetapi secara langsung menulis `src` ke dalamnya selepas itu,
    // supaya nilai lama tidak digandakan.
    // Tidak ada yang dijatuhkan dan tidak ada yang boleh panic di sini.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Melupuskan nilai.
///
/// Ini berlaku dengan memanggil pelaksanaan argumen [`Drop`][drop].
///
/// Ini tidak berkesan untuk jenis yang menerapkan `Copy`, misalnya
/// integers.
/// Nilai tersebut disalin dan _then_ dipindahkan ke fungsi, sehingga nilainya berterusan setelah fungsi ini memanggil.
///
///
/// Fungsi ini bukan sihir;ia secara literal ditakrifkan sebagai
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Oleh kerana `_x` dipindahkan ke fungsi, ia secara automatik dijatuhkan sebelum fungsi kembali.
///
/// [drop]: Drop
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // menjatuhkan vector secara eksplisit
/// ```
///
/// Oleh kerana [`RefCell`] menerapkan peraturan peminjaman pada waktu runtime, `drop` dapat melepaskan pinjaman [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // melepaskan pinjaman yang boleh berubah pada slot ini
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integer dan jenis lain yang melaksanakan [`Copy`] tidak dipengaruhi oleh `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // salinan `x` dipindahkan dan dijatuhkan
/// drop(y); // salinan `y` dipindahkan dan dijatuhkan
///
/// println!("x: {}, y: {}", x, y.0); // masih ada
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Mentafsirkan `src` sebagai jenis `&U`, dan kemudian membaca `src` tanpa memindahkan nilai yang terkandung.
///
/// Fungsi ini tidak akan menganggap pointer `src` sah untuk [`size_of::<U>`][size_of] byte dengan menghantar `&T` ke `&U` dan kemudian membaca `&U` (kecuali bahawa ini dilakukan dengan cara yang betul walaupun `&U` membuat syarat penjajaran yang lebih ketat daripada `&T`).
/// Ia juga tidak akan membuat salinan nilai yang terkandung dan bukannya keluar dari `src`.
///
/// Ini bukan kesalahan waktu kompilasi jika `T` dan `U` mempunyai ukuran yang berbeza, tetapi sangat digalakkan untuk hanya menggunakan fungsi ini di mana `T` dan `U` memiliki ukuran yang sama.Fungsi ini mencetuskan [undefined behavior][ub] jika `U` lebih besar daripada `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Salin data dari 'foo_array' dan perlakukan sebagai 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Ubah suai data yang disalin
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Kandungan 'foo_array' seharusnya tidak berubah
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Sekiranya U mempunyai syarat penjajaran yang lebih tinggi, src mungkin tidak sesuai.
    if align_of::<U>() > align_of::<T>() {
        // KESELAMATAN: `src` adalah rujukan yang dijamin sah untuk dibaca.
        // Pemanggil mesti menjamin bahawa transmutasi sebenarnya selamat.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // KESELAMATAN: `src` adalah rujukan yang dijamin sah untuk dibaca.
        // Kami baru sahaja memeriksa bahawa `src as *const U` sejajar dengan betul.
        // Pemanggil mesti menjamin bahawa transmutasi sebenarnya selamat.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Jenis buram mewakili pembeza enum.
///
/// Lihat fungsi [`discriminant`] dalam modul ini untuk maklumat lebih lanjut.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Pelaksanaan trait ini tidak dapat diturunkan kerana kami tidak mahu ada batasan pada T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Mengembalikan nilai yang mengenal pasti varian enum dalam `v` secara unik.
///
/// Sekiranya `T` bukan enum, memanggil fungsi ini tidak akan menghasilkan tingkah laku yang tidak ditentukan, tetapi nilai pengembalian tidak ditentukan.
///
///
/// # Stability
///
/// Diskriminasi varian enum boleh berubah sekiranya definisi enum berubah.
/// Diskriminasi dari beberapa varian tidak akan berubah antara kompilasi dengan penyusun yang sama.
///
/// # Examples
///
/// Ini dapat digunakan untuk membandingkan jumlah yang membawa data, sambil mengabaikan data sebenarnya:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Mengembalikan bilangan varian dalam jenis enum `T`.
///
/// Sekiranya `T` bukan enum, memanggil fungsi ini tidak akan menghasilkan tingkah laku yang tidak ditentukan, tetapi nilai pengembalian tidak ditentukan.
/// Sama, jika `T` adalah enum dengan lebih banyak varian daripada `usize::MAX` maka nilai pengembaliannya tidak ditentukan.
/// Varian yang tidak berpenghuni akan dikira.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}