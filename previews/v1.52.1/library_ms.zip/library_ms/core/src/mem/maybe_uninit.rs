use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Jenis pembungkus untuk membina contoh `T` yang tidak dimulakan.
///
/// # Permulaan invarian
///
/// Penyusun, secara amnya, menganggap bahawa pemboleh ubah diinisialisasi dengan betul mengikut kehendak jenis pemboleh ubah.Sebagai contoh, pemboleh ubah jenis rujukan mesti diselaraskan dan bukan NULL.
/// Ini adalah invarian yang mesti *selalu* ditegakkan, walaupun dalam kod yang tidak selamat.
/// Akibatnya, pemboleh ubah jenis rujukan yang menginisialisasi sifar menyebabkan [undefined behavior][ub] seketika, tidak kira sama ada rujukan itu biasa digunakan untuk mengakses memori
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // tingkah laku yang tidak ditentukan!⚠️
/// // Kod setaraf dengan `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // tingkah laku yang tidak ditentukan!⚠️
/// ```
///
/// Ini dieksploitasi oleh penyusun untuk pelbagai pengoptimuman, seperti pemeriksaan masa berjalan dan pengoptimuman susun atur `enum`.
///
/// Begitu juga, memori yang belum sepenuhnya dimulakan mungkin mempunyai kandungan, sementara `bool` mestilah selalu `true` atau `false`.Oleh itu, membuat `bool` yang tidak dimulakan adalah tingkah laku yang tidak ditentukan:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // tingkah laku yang tidak ditentukan!⚠️
/// // Kod setaraf dengan `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // tingkah laku yang tidak ditentukan!⚠️
/// ```
///
/// Lebih-lebih lagi, memori yang tidak dimulakan adalah istimewa kerana ia tidak mempunyai nilai tetap ("fixed" bererti "it won't change without being written to").Membaca bait yang tidak dimulakan sama berulang kali dapat memberikan hasil yang berbeza.
/// Ini menjadikan tingkah laku tidak ditentukan untuk memiliki data yang tidak diinisialisasi dalam pemboleh ubah walaupun pemboleh ubah tersebut mempunyai jenis bilangan bulat, yang sebaliknya dapat memegang corak bit *tetap*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // tingkah laku yang tidak ditentukan!⚠️
/// // Kod setaraf dengan `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // tingkah laku yang tidak ditentukan!⚠️
/// ```
/// (Perhatikan bahawa peraturan tentang bilangan bulat yang belum diinisialisasi belum diselesaikan, tetapi sampai ada, disarankan untuk menghindarinya.)
///
/// Selain itu, ingat bahawa kebanyakan jenis mempunyai invarian tambahan selain hanya dianggap diinisialisasi pada tahap jenis.
/// Sebagai contoh, [`Vec<T>`] yang diinisialisasi `1 'dianggap diinisialisasi (di bawah pelaksanaan semasa; ini bukan merupakan jaminan yang stabil) kerana satu-satunya syarat yang diketahui oleh penyusun adalah bahawa penunjuk data mestilah tidak kosong.
/// Membuat `Vec<T>` seperti itu tidak menyebabkan perilaku *langsung* tidak ditentukan, tetapi akan menyebabkan tingkah laku yang tidak ditentukan dengan kebanyakan operasi yang selamat (termasuk menjatuhkannya).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` berfungsi untuk membolehkan kod yang tidak selamat untuk menangani data yang tidak dimulakan.
/// Ini adalah isyarat kepada penyusun yang menunjukkan bahawa data di sini mungkin *tidak* dimulakan:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Buat rujukan yang belum dimulakan secara jelas.
/// // Penyusun tahu bahawa data di dalam `MaybeUninit<T>` mungkin tidak sah, dan oleh itu ini bukan UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Tetapkan pada nilai yang sah.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ekstrak data yang diinisialisasi-ini hanya dibenarkan *setelah* memulakan `x` dengan betul!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Penyusun kemudian tahu untuk tidak membuat andaian atau pengoptimuman yang salah pada kod ini.
///
/// Anda boleh menganggap `MaybeUninit<T>` sedikit seperti `Option<T>` tetapi tanpa penjejakan waktu larian dan tanpa pemeriksaan keselamatan.
///
/// ## out-pointers
///
/// Anda dapat menggunakan `MaybeUninit<T>` untuk menerapkan "out-pointers": alih-alih mengembalikan data dari fungsi, berikan penunjuk ke memori (uninitialized) untuk memasukkan hasilnya.
/// Ini berguna apabila pemanggil perlu mengawal bagaimana memori hasil disimpan disimpan dan anda ingin mengelakkan pergerakan yang tidak perlu.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` tidak menjatuhkan kandungan lama, yang penting.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Sekarang kita tahu `v` diinisialisasi!Ini juga memastikan vector dijatuhkan dengan betul.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Memulakan elemen-demi-elemen array
///
/// `MaybeUninit<T>` boleh digunakan untuk menginisialisasi elemen array demi elemen yang besar:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Buat susunan `MaybeUninit` yang belum dimulakan.
///     // `assume_init` selamat kerana jenis yang kami katakan telah diinisialisasi di sini adalah sekumpulan `MaybeUninit`s, yang tidak memerlukan inisialisasi.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Menjatuhkan `MaybeUninit` tidak ada apa-apa.
///     // Oleh itu, menggunakan penugasan penunjuk mentah dan bukannya `ptr::write` tidak menyebabkan nilai lama yang tidak dimulakan akan jatuh.
/////
///     // Juga jika terdapat panic semasa gelung ini, kita mengalami kebocoran memori, tetapi tidak ada masalah keselamatan memori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Semuanya dimulakan.
///     // Hantarkan susunan ke jenis yang dimulakan.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Anda juga boleh bekerja dengan array yang diinisialisasi secara separa, yang terdapat di datastruktur peringkat rendah.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Buat susunan `MaybeUninit` yang belum dimulakan.
/// // `assume_init` selamat kerana jenis yang kami katakan telah diinisialisasi di sini adalah sekumpulan `MaybeUninit`s, yang tidak memerlukan inisialisasi.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Hitung bilangan elemen yang telah kita tetapkan.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Untuk setiap item dalam array, turunkan jika kami memperuntukkannya.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Memulakan struktur medan demi bidang
///
/// Anda boleh menggunakan `MaybeUninit<T>`, dan makro [`std::ptr::addr_of_mut`], untuk memulakan bidang struktur mengikut bidang:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Memulakan medan `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Memulakan medan `list` Sekiranya terdapat panic di sini, maka `String` di medan `name` bocor.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Semua medan diinisialisasi, jadi kami memanggil `assume_init` untuk mendapatkan Foo yang diinisialisasi.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` dijamin mempunyai ukuran, penjajaran, dan ABI yang sama dengan `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Namun ingat bahawa jenis *yang mengandungi* a `MaybeUninit<T>` tidak semestinya susun atur yang sama;Rust secara amnya tidak menjamin bahawa medan `Foo<T>` mempunyai susunan yang sama dengan `Foo<U>` walaupun `T` dan `U` mempunyai ukuran dan penjajaran yang sama.
///
/// Tambahan lagi kerana nilai bit mana-mana sah untuk `MaybeUninit<T>`, penyusun tidak dapat menerapkan pengoptimuman non-zero/niche-filling, berpotensi menghasilkan ukuran yang lebih besar:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Sekiranya `T` selamat dari FFI, begitu juga `MaybeUninit<T>`.
///
/// Walaupun `MaybeUninit` adalah `#[repr(transparent)]` (menunjukkan ia menjamin ukuran, penjajaran, dan ABI yang sama dengan `T`), ini *tidak* mengubah mana-mana peringatan sebelumnya.
/// `Option<T>` dan `Option<MaybeUninit<T>>` mungkin masih mempunyai ukuran yang berbeza, dan jenis yang mengandungi medan jenis `T` mungkin ditata (dan berukuran) secara berbeza daripada jika bidang itu `MaybeUninit<T>`.
/// `MaybeUninit` adalah jenis kesatuan, dan `#[repr(transparent)]` pada kesatuan tidak stabil (lihat [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Seiring berjalannya waktu, jaminan tepat `#[repr(transparent)]` pada kesatuan dapat berkembang, dan `MaybeUninit` mungkin atau mungkin tidak tetap `#[repr(transparent)]`.
/// Oleh itu, `MaybeUninit<T>` akan *selalu* menjamin bahawa ia mempunyai ukuran, penjajaran, dan ABI yang sama dengan `T`;hanya dengan cara `MaybeUninit` melaksanakan jaminan dapat berkembang.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Item Lang supaya kita dapat membungkus jenis lain di dalamnya.Ini berguna untuk penjana.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Tidak memanggil `T::clone()`, kami tidak dapat mengetahui apakah kami cukup awal untuk itu.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Membuat `MaybeUninit<T>` baru yang dimulakan dengan nilai yang diberikan.
    /// Adalah selamat untuk memanggil [`assume_init`] pada nilai pengembalian fungsi ini.
    ///
    /// Perhatikan bahawa menjatuhkan `MaybeUninit<T>` tidak akan memanggil kod penurunan `T '.
    /// Adalah tanggungjawab anda untuk memastikan `T` dijatuhkan sekiranya ia diinisialisasi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Membuat `MaybeUninit<T>` baru dalam keadaan tidak dimulakan.
    ///
    /// Perhatikan bahawa menjatuhkan `MaybeUninit<T>` tidak akan memanggil kod penurunan `T '.
    /// Adalah tanggungjawab anda untuk memastikan `T` dijatuhkan sekiranya ia diinisialisasi.
    ///
    /// Lihat [type-level documentation][MaybeUninit] untuk beberapa contoh.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Buat susunan item `MaybeUninit<T>` baru, dalam keadaan tidak dimulakan.
    ///
    /// Note: dalam versi future Rust kaedah ini mungkin tidak diperlukan apabila sintaks literal array membenarkan [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Contoh di bawah boleh menggunakan `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Mengembalikan sekeping data (mungkin lebih kecil) yang sebenarnya telah dibaca
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KESELAMATAN: `[MaybeUninit<_>; LEN]` yang belum dimulakan adalah sah.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Membuat `MaybeUninit<T>` baru dalam keadaan yang tidak dimulakan, dengan memori diisi dengan bait `0`.Itu bergantung pada `T` sama ada yang sudah membuat permulaan yang tepat.
    ///
    /// Contohnya, `MaybeUninit<usize>::zeroed()` diinisialisasi, tetapi `MaybeUninit<&'static i32>::zeroed()` bukan kerana rujukan tidak boleh kosong.
    ///
    /// Perhatikan bahawa menjatuhkan `MaybeUninit<T>` tidak akan memanggil kod penurunan `T '.
    /// Adalah tanggungjawab anda untuk memastikan `T` dijatuhkan sekiranya ia diinisialisasi.
    ///
    /// # Example
    ///
    /// Penggunaan fungsi ini dengan betul: memulakan struktur dengan sifar, di mana semua medan struktur dapat menahan corak bit 0 sebagai nilai yang sah.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Salah* penggunaan fungsi ini: memanggil `x.zeroed().assume_init()` apabila `0` bukan corak bit yang sah untuk jenis:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Di dalam pasangan, kami membuat `NotZero` yang tidak mempunyai diskriminasi yang sah.
    /// // Ini adalah tingkah laku yang tidak ditentukan.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KESELAMATAN: `u.as_mut_ptr()` menunjukkan memori yang diperuntukkan.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Menetapkan nilai `MaybeUninit<T>`.
    /// Ini menimpa nilai sebelumnya tanpa menjatuhkannya, jadi berhati-hatilah untuk tidak menggunakannya dua kali melainkan jika anda mahu melangkau pemusnah.
    ///
    /// Untuk keselesaan anda, ini juga mengembalikan rujukan yang boleh diubah kepada kandungan `self` (kini selamat dimulakan).
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // KESELAMATAN: Kami baru memulakan nilai ini.
        unsafe { self.assume_init_mut() }
    }

    /// Mendapat pointer ke nilai yang terkandung.
    /// Membaca dari penunjuk ini atau mengubahnya menjadi rujukan adalah tingkah laku yang tidak ditentukan kecuali `MaybeUninit<T>` dimulakan.
    /// Menulis ke memori yang ditunjukkan oleh penunjuk (non-transitively) ini adalah tingkah laku yang tidak ditentukan (kecuali di dalam `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Buat rujukan ke `MaybeUninit<T>`.Ini tidak mengapa kerana kami memulakannya.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Salah* penggunaan kaedah ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Kami telah membuat rujukan ke vector yang belum dimulakan!Ini adalah tingkah laku yang tidak ditentukan.⚠️
    /// ```
    ///
    /// (Perhatikan bahwa aturan mengenai rujukan ke data yang belum diinisialisasi belum diselesaikan, tetapi sampai ada, disarankan untuk menghindarinya.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` dan `ManuallyDrop` kedua-duanya adalah `repr(transparent)` sehingga kami dapat menghantar penunjuk.
        self as *const _ as *const T
    }

    /// Mendapat penunjuk yang boleh berubah ke nilai yang terkandung.
    /// Membaca dari penunjuk ini atau mengubahnya menjadi rujukan adalah tingkah laku yang tidak ditentukan kecuali `MaybeUninit<T>` dimulakan.
    ///
    /// # Examples
    ///
    /// Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Buat rujukan ke `MaybeUninit<Vec<u32>>`.
    /// // Ini tidak mengapa kerana kami memulakannya.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Salah* penggunaan kaedah ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Kami telah membuat rujukan ke vector yang belum dimulakan!Ini adalah tingkah laku yang tidak ditentukan.⚠️
    /// ```
    ///
    /// (Perhatikan bahwa aturan mengenai rujukan ke data yang belum diinisialisasi belum diselesaikan, tetapi sampai ada, disarankan untuk menghindarinya.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` dan `ManuallyDrop` kedua-duanya adalah `repr(transparent)` sehingga kami dapat menghantar penunjuk.
        self as *mut _ as *mut T
    }

    /// Mengekstrak nilai dari bekas `MaybeUninit<T>`.Ini adalah cara yang baik untuk memastikan bahawa data akan dijatuhkan, kerana `T` yang dihasilkan tunduk pada pengendalian penurunan yang biasa.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa `MaybeUninit<T>` benar-benar dalam keadaan yang diinisialisasi.Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan langsung.
    /// [type-level documentation][inv] mengandungi lebih banyak maklumat mengenai invarian inisialisasi ini.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Selain itu, ingat bahawa kebanyakan jenis mempunyai invarian tambahan selain hanya dianggap diinisialisasi pada tahap jenis.
    /// Sebagai contoh, [`Vec<T>`] yang diinisialisasi `1 'dianggap diinisialisasi (di bawah pelaksanaan semasa; ini bukan merupakan jaminan yang stabil) kerana satu-satunya syarat yang diketahui oleh penyusun adalah bahawa penunjuk data mestilah tidak kosong.
    ///
    /// Membuat `Vec<T>` seperti itu tidak menyebabkan perilaku *langsung* tidak ditentukan, tetapi akan menyebabkan tingkah laku yang tidak ditentukan dengan kebanyakan operasi yang selamat (termasuk menjatuhkannya).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Salah* penggunaan kaedah ini:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` belum dimulakan, jadi baris terakhir ini menyebabkan tingkah laku yang tidak ditentukan.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` diinisialisasi.
        // Ini juga bermaksud bahawa `self` mestilah varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Membaca nilai dari bekas `MaybeUninit<T>`.`T` yang dihasilkan tertakluk pada pengendalian penurunan biasa.
    ///
    /// Seboleh-bolehnya, lebih baik menggunakan [`assume_init`] sebagai gantinya, yang menghalang penduaan kandungan `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa `MaybeUninit<T>` benar-benar dalam keadaan yang diinisialisasi.Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan.
    /// [type-level documentation][inv] mengandungi lebih banyak maklumat mengenai invarian inisialisasi ini.
    ///
    /// Lebih-lebih lagi, ini meninggalkan salinan data yang sama di `MaybeUninit<T>`.
    /// Semasa menggunakan beberapa salinan data (dengan memanggil `assume_init_read` berkali-kali, atau pertama kali memanggil `assume_init_read` dan kemudian [`assume_init`]), adalah tanggungjawab anda untuk memastikan bahawa data tersebut semestinya diduplikasi.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` adalah `Copy`, jadi kami mungkin membaca berulang kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Penduaan nilai `None` tidak apa-apa, jadi kita boleh membaca berkali-kali.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Salah* penggunaan kaedah ini:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Kami kini membuat dua salinan vector yang sama, yang membawa kepada ⚠️ percuma dua kali apabila kedua-duanya digugurkan!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` diinisialisasi.
        // Membaca dari `self.as_ptr()` adalah selamat kerana `self` harus diinisialisasi.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Turunkan nilai yang terkandung di tempat.
    ///
    /// Sekiranya anda memiliki hak milik `MaybeUninit`, anda boleh menggunakan [`assume_init`] sebagai gantinya.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa `MaybeUninit<T>` benar-benar dalam keadaan yang diinisialisasi.Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan.
    ///
    /// Di samping itu, semua invarian tambahan dari jenis `T` mesti dipuaskan, kerana pelaksanaan `Drop` `T` (atau anggotanya) mungkin bergantung pada ini.
    /// Sebagai contoh, [`Vec<T>`] yang diinisialisasi `1 'dianggap diinisialisasi (di bawah pelaksanaan semasa; ini bukan merupakan jaminan yang stabil) kerana satu-satunya syarat yang diketahui oleh penyusun adalah bahawa penunjuk data mestilah tidak kosong.
    ///
    /// Menjatuhkan `Vec<T>` seperti itu akan menyebabkan tingkah laku yang tidak ditentukan.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` diinisialisasi dan
        // memenuhi semua invarian `T`.
        // Menjatuhkan nilai di tempat adalah selamat sekiranya demikian.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Mendapat rujukan bersama untuk nilai yang terkandung.
    ///
    /// Ini dapat berguna ketika kita ingin mengakses `MaybeUninit` yang telah diinisialisasi tetapi tidak memiliki kepemilikan `MaybeUninit` (mencegah penggunaan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Memanggilnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan: terserah kepada pemanggil untuk menjamin bahawa `MaybeUninit<T>` benar-benar berada dalam keadaan yang diinisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ### Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Memulakan `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Setelah `MaybeUninit<_>` kami diketahui diinisialisasi, tidak ada salahnya membuat rujukan bersama dengannya:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // KESELAMATAN: `x` telah diinisialisasi.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Penggunaan* kaedah ini tidak betul:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Kami telah membuat rujukan ke vector yang belum dimulakan!Ini adalah tingkah laku yang tidak ditentukan.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Memulakan `MaybeUninit` menggunakan `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Rujukan ke `Cell<bool>` yang belum dimulakan: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` diinisialisasi.
        // Ini juga bermaksud bahawa `self` mestilah varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Mendapat rujukan (unique) yang berubah-ubah ke nilai yang terkandung.
    ///
    /// Ini dapat berguna ketika kita ingin mengakses `MaybeUninit` yang telah diinisialisasi tetapi tidak memiliki kepemilikan `MaybeUninit` (mencegah penggunaan `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Memanggilnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan: terserah kepada pemanggil untuk menjamin bahawa `MaybeUninit<T>` benar-benar berada dalam keadaan yang diinisialisasi.
    /// Sebagai contoh, `.assume_init_mut()` tidak dapat digunakan untuk menginisialisasi `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Penggunaan kaedah ini dengan betul:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Memulakan *semua* bait penyangga input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Memulakan `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Sekarang kita tahu bahawa `buf` telah diinisialisasi, jadi kita dapat `.assume_init()`.
    /// // Walau bagaimanapun, menggunakan `.assume_init()` boleh mencetuskan `memcpy` dari 2048 bait.
    /// // Untuk menegaskan penyangga kami telah diinisialisasi tanpa menyalinnya, kami menaik taraf `&mut MaybeUninit<[u8; 2048]>` ke `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // KESELAMATAN: `buf` telah diinisialisasi.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Sekarang kita boleh menggunakan `buf` sebagai potongan biasa:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Penggunaan* kaedah ini tidak betul:
    ///
    /// Anda tidak boleh menggunakan `.assume_init_mut()` untuk memulakan nilai:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Kami telah membuat rujukan (mutable) ke `bool` yang belum dimulakan!
    ///     // Ini adalah tingkah laku yang tidak ditentukan.⚠️
    /// }
    /// ```
    ///
    /// Contohnya, anda tidak boleh [`Read`] menjadi penyangga yang tidak diinisialisasi:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) merujuk kepada memori yang tidak dimulakan!
    ///                             // Ini adalah tingkah laku yang tidak ditentukan.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Anda juga tidak boleh menggunakan akses lapangan langsung untuk melakukan inisialisasi bertahap bidang demi bidang:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) merujuk kepada memori yang tidak dimulakan!
    ///                  // Ini adalah tingkah laku yang tidak ditentukan.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) merujuk kepada memori yang tidak dimulakan!
    ///                  // Ini adalah tingkah laku yang tidak ditentukan.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Kami pada masa ini bergantung pada perkara di atas yang tidak betul, iaitu, kami mempunyai rujukan ke data yang tidak diinisialisasi (misalnya, di `libcore/fmt/float.rs`)
    // Kita harus membuat keputusan akhir mengenai peraturan sebelum penstabilan.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // KESELAMATAN: pemanggil mesti menjamin bahawa `self` diinisialisasi.
        // Ini juga bermaksud bahawa `self` mestilah varian `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Mengekstrak nilai dari pelbagai bekas `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa semua elemen array berada dalam keadaan yang diinisialisasi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // KESELAMATAN: Sekarang selamat kerana kami memulakan semua elemen
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Pemanggil menjamin bahawa semua elemen array diinisialisasi
        // * `MaybeUninit<T>` dan T dijamin mempunyai susun atur yang sama
        // * MungkinUnint tidak jatuh, jadi tidak ada pembebasan dua kali Oleh itu, penukarannya selamat
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Dengan andaian semua elemen diinisialisasi, dapatkan potongannya.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa elemen `MaybeUninit<T>` benar-benar berada dalam keadaan awal.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan.
    ///
    /// Lihat [`assume_init_ref`] untuk maklumat lebih terperinci dan contoh.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // KESELAMATAN: membuang slice ke `*const [T]` adalah selamat kerana pemanggil menjaminnya
        // `slice` diinisialisasi, dan `MaybeUninit` dijamin mempunyai susun atur yang sama dengan `T`.
        // Penunjuk yang diperoleh adalah sah kerana merujuk kepada memori yang dimiliki oleh `slice` yang merupakan rujukan dan dengan demikian dijamin sah untuk dibaca.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Dengan andaian semua elemen diinisialisasi, dapatkan potongan yang dapat diubah.
    ///
    /// # Safety
    ///
    /// Terserah kepada pemanggil untuk menjamin bahawa elemen `MaybeUninit<T>` benar-benar berada dalam keadaan awal.
    ///
    /// Menyebutnya ketika kandungan belum diinisialisasi sepenuhnya menyebabkan tingkah laku tidak ditentukan.
    ///
    /// Lihat [`assume_init_mut`] untuk maklumat lebih terperinci dan contoh.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KESELAMATAN: serupa dengan nota keselamatan untuk `slice_get_ref`, tetapi kami mempunyai
        // rujukan boleh ubah yang juga dijamin sah untuk penulisan.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Mendapat penunjuk ke elemen pertama tatasusunan.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Mendapatkan penunjuk yang boleh diubah ke elemen pertama bagi larik.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Menyalin unsur-unsur dari `src` ke `this`, mengembalikan rujukan yang dapat diubah ke kandungan `this` yang kini tidak dimodelkan.
    ///
    /// Sekiranya `T` tidak melaksanakan `Copy`, gunakan [`write_slice_cloned`]
    ///
    /// Ini serupa dengan [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika kedua kepingan mempunyai panjang yang berbeza.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KESELAMATAN: kami baru saja menyalin semua elemen len ke dalam kapasiti ganti
    /// // elemen src.len() vec yang pertama sudah sah sekarang.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // KESELAMATAN: &[T] dan&[MungkinUninit<T>] mempunyai susun atur yang sama
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KESELAMATAN: Elemen yang sah baru saja disalin ke `this` sehingga ia diinitalisasi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klon elemen dari `src` ke `this`, mengembalikan rujukan yang dapat diubah ke kandungan `this` yang kini tidak dimodelkan.
    /// Mana-mana unsur yang sudah tidak dianalisis tidak akan dijatuhkan
    ///
    /// Sekiranya `T` menerapkan `Copy`, gunakan [`write_slice`]
    ///
    /// Ini serupa dengan [`slice::clone_from_slice`] tetapi tidak menjatuhkan elemen yang ada.
    ///
    /// # Panics
    ///
    /// Fungsi ini akan panic jika kedua potongan mempunyai panjang yang berbeza, atau jika pelaksanaan `Clone` panics.
    ///
    /// Sekiranya terdapat panic, elemen yang sudah diklon akan dijatuhkan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // KESELAMATAN: kami baru saja mengklon semua elemen len ke dalam kapasiti ganti
    /// // elemen src.len() vec yang pertama sudah sah sekarang.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // tidak seperti copy_from_slice ini tidak memanggil clone_from_slice pada slice ini kerana `MaybeUninit<T: Clone>` tidak melaksanakan Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KESELAMATAN: potongan mentah ini hanya akan mengandungi objek yang diinisialisasi
                // sebab itu, ia dibenarkan menjatuhkannya.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Kita perlu memotongnya secara jelas
        // untuk memeriksa batas, dan pengoptimum akan menghasilkan memcpy untuk kes mudah (contohnya T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // pengawal diperlukan b/c panic mungkin berlaku semasa klon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KESELAMATAN: Elemen yang sah baru sahaja ditulis ke dalam `this` sehingga ia diinitalisasi
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}