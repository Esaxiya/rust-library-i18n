use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Pembungkus untuk menghalang penyusun daripada memanggil pemusnah `T` secara automatik.
/// Pembungkus ini berharga 0.
///
/// `ManuallyDrop<T>` tertakluk kepada pengoptimuman susun atur yang sama dengan `T`.
/// Akibatnya, ia *tidak memberi kesan* terhadap andaian yang dibuat oleh penyusun mengenai kandungannya.
/// Sebagai contoh, memulakan `ManuallyDrop<&mut T>` dengan [`mem::zeroed`] adalah tingkah laku yang tidak ditentukan.
/// Sekiranya anda perlu menangani data yang tidak diinisialisasi, gunakan [`MaybeUninit<T>`] sebagai gantinya.
///
/// Perhatikan bahawa mengakses nilai di dalam `ManuallyDrop<T>` adalah selamat.
/// Ini bermaksud bahawa `ManuallyDrop<T>` yang kandungannya dijatuhkan tidak boleh didedahkan melalui API keselamatan awam.
/// Sejajar dengan itu, `ManuallyDrop::drop` tidak selamat.
///
/// # `ManuallyDrop` dan urutan turun.
///
/// Rust mempunyai nilai [drop order] yang jelas.
/// Untuk memastikan bahawa bidang atau penduduk tempatan dijatuhkan dalam urutan tertentu, susun semula deklarasi sedemikian rupa sehingga urutan penurunan tersirat adalah yang betul.
///
/// Adalah mungkin untuk menggunakan `ManuallyDrop` untuk mengawal urutan penurunan, tetapi ini memerlukan kod yang tidak selamat dan sukar untuk dilakukan dengan betul sekiranya tidak berfungsi.
///
///
/// Sebagai contoh, jika anda ingin memastikan bahawa medan tertentu dijatuhkan setelah yang lain, jadikan bidang terakhir struktur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` akan dijatuhkan selepas `children`.
///     // Rust menjamin bahawa medan dijatuhkan mengikut urutan perisytiharan.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Balut nilai untuk dijatuhkan secara manual.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Anda masih boleh beroperasi dengan selamat pada nilai
    /// assert_eq!(*x, "Hello");
    /// // Tetapi `Drop` tidak akan dijalankan di sini
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Mengekstrak nilai dari bekas `ManuallyDrop`.
    ///
    /// Ini membolehkan nilai dijatuhkan lagi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Ini menjatuhkan `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Mengeluarkan nilai dari bekas `ManuallyDrop<T>`.
    ///
    /// Kaedah ini bertujuan terutamanya untuk memindahkan nilai secara menurun.
    /// Daripada menggunakan [`ManuallyDrop::drop`] untuk menjatuhkan nilai secara manual, anda boleh menggunakan kaedah ini untuk mengambil nilai dan menggunakannya sesuka hati.
    ///
    /// Seboleh-bolehnya, lebih baik menggunakan [`into_inner`][`ManuallyDrop::into_inner`] sebagai gantinya, yang menghalang penduaan kandungan `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi ini secara semantik memindahkan nilai yang terkandung tanpa mencegah penggunaan selanjutnya, membiarkan keadaan wadah ini tidak berubah.
    /// Adalah menjadi tanggungjawab anda untuk memastikan bahawa `ManuallyDrop` ini tidak digunakan lagi.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // KESELAMATAN: kita membaca dari rujukan, yang dijamin
        // sah untuk bacaan.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Menurunkan nilai yang terkandung secara manual.Ini sama dengan memanggil [`ptr::drop_in_place`] dengan penunjuk ke nilai yang terkandung.
    /// Oleh itu, kecuali jika nilai yang terkandung adalah struktur yang dikemas, pemusnah akan dipanggil di tempat tanpa memindahkan nilai, dan dengan demikian dapat digunakan untuk menjatuhkan data [pinned] dengan selamat.
    ///
    /// Sekiranya anda memiliki hak milik, anda boleh menggunakan [`ManuallyDrop::into_inner`] sebagai gantinya.
    ///
    /// # Safety
    ///
    /// Fungsi ini menjalankan pemusnah nilai terkandung.
    /// Selain daripada perubahan yang dibuat oleh pemusnah itu sendiri, memori tidak akan berubah, dan sejauh mana penyusun masih memegang corak bit yang sah untuk jenis `T`.
    ///
    ///
    /// Walau bagaimanapun, nilai "zombie" ini tidak boleh terkena kod selamat, dan fungsi ini tidak boleh disebut lebih dari sekali.
    /// Untuk menggunakan nilai setelah dijatuhkan, atau menjatuhkan nilai berkali-kali, boleh menyebabkan Perilaku Tidak Ditentukan (bergantung pada apa yang dilakukan `drop`).
    /// Ini biasanya dicegah oleh sistem jenis, tetapi pengguna `ManuallyDrop` mesti menjamin jaminan tersebut tanpa bantuan penyusun.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KESELAMATAN: kami menjatuhkan nilai yang ditunjukkan oleh rujukan yang boleh berubah
        // yang dijamin sah untuk penulisan.
        // Terserah kepada pemanggil untuk memastikan `slot` tidak dijatuhkan lagi.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}