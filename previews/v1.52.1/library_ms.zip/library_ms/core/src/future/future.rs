#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future mewakili pengiraan tak segerak.
///
/// future adalah nilai yang mungkin belum selesai pengkomputeran.
/// "asynchronous value" jenis ini memungkinkan utas untuk terus melakukan kerja berguna sementara menunggu nilainya tersedia.
///
///
/// # Kaedah `poll`
///
/// Kaedah teras future, `poll`,*mencuba* untuk menyelesaikan future menjadi nilai akhir.
/// Kaedah ini tidak menyekat sekiranya nilainya tidak siap.
/// Sebaliknya, tugas semasa dijadualkan akan terbangun apabila mungkin untuk membuat kemajuan lebih jauh dengan `poll`ing lagi.
/// `context` yang diteruskan ke kaedah `poll` dapat memberikan [`Waker`], yang merupakan pegangan untuk membangunkan tugas semasa.
///
/// Semasa menggunakan future, secara amnya anda tidak akan memanggil `poll` secara langsung, melainkan nilai `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Jenis nilai yang dihasilkan setelah selesai.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Cuba menyelesaikan future ke nilai akhir, mendaftarkan tugas semasa untuk bangun sekiranya nilainya belum tersedia.
    ///
    /// # Nilai pulangan
    ///
    /// Fungsi ini mengembalikan:
    ///
    /// - [`Poll::Pending`] sekiranya future belum siap
    /// - [`Poll::Ready(val)`] dengan hasil `val` future ini jika berjaya diselesaikan.
    ///
    /// Setelah future selesai, pelanggan tidak boleh `poll` lagi.
    ///
    /// Apabila future belum siap, `poll` mengembalikan `Poll::Pending` dan menyimpan klon [`Waker`] yang disalin dari [`Context`] semasa.
    /// [`Waker`] ini kemudian terbangun setelah future dapat membuat kemajuan.
    /// Sebagai contoh, future yang menunggu soket menjadi mudah dibaca akan memanggil `.clone()` pada [`Waker`] dan menyimpannya.
    /// Apabila isyarat tiba di tempat lain yang menunjukkan bahawa soket boleh dibaca, [`Waker::wake`] dipanggil dan tugas soket future terjaga.
    /// Setelah tugas terbangun, ia harus mencuba `poll` future sekali lagi, yang mungkin atau tidak menghasilkan nilai akhir.
    ///
    /// Perhatikan bahawa pada beberapa panggilan ke `poll`, hanya [`Waker`] dari [`Context`] yang dilalui ke panggilan terbaru yang dijadwalkan untuk menerima bangun.
    ///
    /// # Ciri-ciri jangka masa
    ///
    /// Futures sahaja adalah *lengai*;mereka mesti *secara aktif*`poll`ed untuk membuat kemajuan, yang bermaksud bahawa setiap kali tugas saat ini terbangun, ia harus secara aktif 'kembali' menunggu futures yang masih mempunyai minat.
    ///
    /// Fungsi `poll` tidak dipanggil berulang kali dalam gelung ketat-sebaliknya, ia hanya boleh dipanggil apabila future menunjukkan bahawa ia sudah siap untuk mencapai kemajuan (dengan memanggil `wake()`).
    /// Sekiranya anda biasa dengan sysall `poll(2)` atau `select(2)` di Unix, perlu diperhatikan bahawa futures biasanya *tidak* mengalami masalah "all wakeups must poll all events" yang sama;mereka lebih menyerupai `epoll(4)`.
    ///
    /// Pelaksanaan `poll` harus berusaha untuk kembali dengan cepat, dan tidak boleh menyekat.Kembali dengan cepat menghalang penyumbatan benang atau gelung acara yang tidak perlu.
    /// Sekiranya diketahui lebih awal bahawa panggilan ke `poll` mungkin akan berlangsung lama, kerja tersebut harus dimuat ke kumpulan utas (atau yang serupa) untuk memastikan bahawa `poll` dapat kembali dengan cepat.
    ///
    /// # Panics
    ///
    /// Setelah future selesai (mengembalikan `Ready` dari `poll`), memanggil kaedah `poll` sekali lagi mungkin panic, menyekat selamanya, atau menyebabkan masalah lain;`Future` trait tidak memerlukan syarat mengenai kesan panggilan tersebut.
    /// Walau bagaimanapun, kerana kaedah `poll` tidak ditandai `unsafe`, peraturan biasa Rust berlaku: panggilan tidak boleh menyebabkan tingkah laku yang tidak ditentukan (kerosakan memori, penggunaan fungsi `unsafe` yang salah, atau sejenisnya), tanpa mengira keadaan future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}