use crate::future::Future;

/// Penukaran menjadi `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Keluaran yang akan dihasilkan oleh future setelah selesai.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// future jenis apa yang kita ubah menjadi?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Membuat future dari nilai.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}