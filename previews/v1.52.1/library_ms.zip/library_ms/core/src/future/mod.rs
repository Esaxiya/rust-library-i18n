#![stable(feature = "futures_api", since = "1.36.0")]

//! Nilai tak segerak.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Jenis ini diperlukan kerana:
///
/// a) Penjana tidak dapat melaksanakan `for<'a, 'b> Generator<&'a mut Context<'b>>`, jadi kita perlu melewati penunjuk mentah (lihat <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Penunjuk mentah dan `NonNull` bukan `Send` atau `Sync`, jadi itu akan menjadikan setiap future non-Send/Sync juga, dan kami tidak menginginkannya.
///
/// Ia juga mempermudah penurunan HIR `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Balut penjana dalam future.
///
/// Fungsi ini mengembalikan `GenFuture` di bawahnya, tetapi menyembunyikannya di `impl Trait` untuk memberikan mesej ralat yang lebih baik (`impl Future` dan bukannya `GenFuture<[closure.....]>`).
///
// Ini adalah `const` untuk mengelakkan ralat tambahan setelah kita pulih dari `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Kami bergantung pada hakikat bahawa async/await futures tidak bergerak untuk membuat peminjaman rujukan diri dalam penjana yang mendasari.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // KESELAMATAN: Selamat kerana kami !Unpin + !Drop, dan ini hanyalah unjuran lapangan.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Sambung semula penjana, ubah `&mut Context` menjadi penunjuk mentah `NonNull`.
            // Penurunan `.await` dengan selamat akan meletakkannya kembali ke `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // KESELAMATAN: pemanggil mesti menjamin bahawa `cx.0` adalah penunjuk yang sah
    // yang memenuhi semua syarat untuk rujukan yang boleh berubah.
    unsafe { &mut *cx.0.as_ptr().cast() }
}