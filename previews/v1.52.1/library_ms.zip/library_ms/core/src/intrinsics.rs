//! Intrinsik penyusun.
//!
//! Definisi yang sesuai terdapat dalam `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Pelaksanaan const yang sesuai terdapat dalam `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Intrinsik Const
//!
//! Note: sebarang perubahan pada keteguhan intrinsik harus dibincangkan dengan pasukan bahasa.
//! Ini termasuk perubahan dalam kestabilan keteguhan.
//!
//! Untuk membuat intrinsik dapat digunakan pada waktu kompilasi, seseorang perlu menyalin pelaksanaan dari <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ke `compiler/rustc_mir/src/interpret/intrinsics.rs` dan menambahkan `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ke intrinsik.
//!
//!
//! Sekiranya intrinsik seharusnya digunakan dari `const fn` dengan atribut `rustc_const_stable`, atribut intrinsik juga harus `rustc_const_stable`.
//! Perubahan seperti itu tidak boleh dilakukan tanpa konsultasi T-lang, kerana fitur ini menggunakan bahasa yang tidak dapat ditiru dalam kod pengguna tanpa dukungan penyusun.
//!
//! # Volatiles
//!
//! Intrinsik yang tidak menentu menyediakan operasi yang dimaksudkan untuk bertindak pada memori I/O, yang dijamin tidak akan disusun semula oleh penyusun di seluruh intrinsik lain yang mudah berubah.Lihat dokumentasi LLVM di [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Intrinsik atom memberikan operasi atom biasa pada kata mesin, dengan pelbagai susunan memori yang mungkin.Mereka mematuhi semantik yang sama dengan C++ 11.Lihat dokumentasi LLVM di [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Penyegaran pantas mengenai pesanan memori:
//!
//! * Memperoleh, penghalang untuk memperoleh kunci.Pembacaan dan penulisan seterusnya berlaku selepas penghalang.
//! * Lepaskan, penghalang untuk melepaskan kunci.Terdahulu membaca dan menulis berlaku sebelum penghalang.
//! * Operasi yang berurutan, berturutan secara konsisten dijamin akan berlaku dengan teratur.Ini adalah mod standard untuk bekerja dengan jenis atom dan setaraf dengan Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Import ini digunakan untuk memudahkan pautan intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // KESELAMATAN: lihat `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, intrinsik ini mengambil petunjuk yang mentah kerana mereka mengubah memori alias, yang tidak sah untuk `&` atau `&mut`.
    //

    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan melewati [`Ordering::SeqCst`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan melewati [`Ordering::Acquire`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::Release`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan melewati [`Ordering::Relaxed`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::Acquire`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange` dengan meneruskan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan melewati [`Ordering::SeqCst`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan melewati [`Ordering::Acquire`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::Release`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan melewati [`Ordering::Relaxed`] sebagai parameter `success` dan `failure`.
    ///
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::SeqCst`] sebagai `success` dan [`Ordering::Acquire`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::Acquire`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Menyimpan nilai jika nilai semasa sama dengan nilai `old`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `compare_exchange_weak` dengan meneruskan [`Ordering::AcqRel`] sebagai `success` dan [`Ordering::Relaxed`] sebagai parameter `failure`.
    /// Sebagai contoh, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Memuatkan nilai penunjuk semasa.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `load` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Memuatkan nilai penunjuk semasa.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `load` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Memuatkan nilai penunjuk semasa.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `load` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `store` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `store` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Menyimpan nilai di lokasi memori yang ditentukan.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `store` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `swap` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `swap` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `swap` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `swap` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menyimpan nilai di lokasi memori yang ditentukan, mengembalikan nilai lama.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `swap` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Menambah nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_add` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambah nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_add` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambah nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_add` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambah nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_add` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Menambah nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_add` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kurangkan dari nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_sub` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangkan dari nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_sub` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangkan dari nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_sub` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangkan dari nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_sub` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kurangkan dari nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_sub` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sedikit demi sedikit dan dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_and` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit dan dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_and` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit dan dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_and` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit dan dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_and` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit dan dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_and` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`AtomicBool`] melalui kaedah `fetch_nand` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`AtomicBool`] melalui kaedah `fetch_nand` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`AtomicBool`] melalui kaedah `fetch_nand` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`AtomicBool`] melalui kaedah `fetch_nand` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`AtomicBool`] melalui kaedah `fetch_nand` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sedikit demi sedikit atau dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_or` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit atau dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_or` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit atau dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_or` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit atau dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_or` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sedikit demi sedikit atau dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_or` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_xor` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_xor` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_xor` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_xor` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor dengan nilai semasa, mengembalikan nilai sebelumnya.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis [`atomic`] melalui kaedah `fetch_xor` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_max` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_max` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_min` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_min` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada jenis bilangan bulat yang ditandatangani [`atomic`] melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_min` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] yang tidak ditandatangani melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_min` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_min` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] yang tidak ditandatangani melalui kaedah `fetch_max` dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Release`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_max` dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum dengan nilai semasa menggunakan perbandingan yang tidak ditandatangani.
    ///
    /// Versi stabil dari intrinsik ini terdapat pada jenis bilangan bulat [`atomic`] tanpa tanda melalui kaedah `fetch_max` dengan memasukkan [`Ordering::Relaxed`] sebagai `order`.
    /// Sebagai contoh, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Intrinsik `prefetch` adalah petunjuk kepada penjana kod untuk memasukkan arahan prefetch jika disokong;jika tidak, ia adalah op-op.
    /// Prefetches tidak mempengaruhi tingkah laku program tetapi boleh mengubah ciri prestasinya.
    ///
    /// Argumen `locality` mesti berupa bilangan bulat tetap dan merupakan penentu lokaliti temporal mulai dari (0), tanpa lokaliti, hingga (3), penyimpanan lokal yang sangat cache.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk kepada penjana kod untuk memasukkan arahan prefetch jika disokong;jika tidak, ia adalah op-op.
    /// Prefetches tidak mempengaruhi tingkah laku program tetapi boleh mengubah ciri prestasinya.
    ///
    /// Argumen `locality` mesti berupa bilangan bulat tetap dan merupakan penentu lokaliti temporal mulai dari (0), tanpa lokaliti, hingga (3), penyimpanan lokal yang sangat cache.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk kepada penjana kod untuk memasukkan arahan prefetch jika disokong;jika tidak, ia adalah op-op.
    /// Prefetches tidak mempengaruhi tingkah laku program tetapi boleh mengubah ciri prestasinya.
    ///
    /// Argumen `locality` mesti berupa bilangan bulat tetap dan merupakan penentu lokaliti temporal mulai dari (0), tanpa lokaliti, hingga (3), penyimpanan lokal yang sangat cache.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Intrinsik `prefetch` adalah petunjuk kepada penjana kod untuk memasukkan arahan prefetch jika disokong;jika tidak, ia adalah op-op.
    /// Prefetches tidak mempengaruhi tingkah laku program tetapi boleh mengubah ciri prestasinya.
    ///
    /// Argumen `locality` mesti berupa bilangan bulat tetap dan merupakan penentu lokaliti temporal mulai dari (0), tanpa lokaliti, hingga (3), penyimpanan lokal yang sangat cache.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::fence`] dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::fence`] dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::fence`] dengan memasukkan [`Ordering::Release`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Pagar atom.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::fence`] dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Penghalang memori hanya penyusun.
    ///
    /// Akses memori tidak akan disusun semula melintasi halangan ini oleh penyusun, tetapi tidak ada arahan yang akan dikeluarkan untuknya.
    /// Ini sesuai untuk operasi pada utas yang sama yang mungkin telah ditentukan sebelumnya, seperti ketika berinteraksi dengan pengendali isyarat.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::compiler_fence`] dengan memasukkan [`Ordering::SeqCst`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Penghalang memori hanya penyusun.
    ///
    /// Akses memori tidak akan disusun semula melintasi halangan ini oleh penyusun, tetapi tidak ada arahan yang akan dikeluarkan untuknya.
    /// Ini sesuai untuk operasi pada utas yang sama yang mungkin telah ditentukan sebelumnya, seperti ketika berinteraksi dengan pengendali isyarat.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::compiler_fence`] dengan memasukkan [`Ordering::Acquire`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Penghalang memori hanya penyusun.
    ///
    /// Akses memori tidak akan disusun semula melintasi halangan ini oleh penyusun, tetapi tidak ada arahan yang akan dikeluarkan untuknya.
    /// Ini sesuai untuk operasi pada utas yang sama yang mungkin telah ditentukan sebelumnya, seperti ketika berinteraksi dengan pengendali isyarat.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::compiler_fence`] dengan memasukkan [`Ordering::Release`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Penghalang memori hanya penyusun.
    ///
    /// Akses memori tidak akan disusun semula melintasi halangan ini oleh penyusun, tetapi tidak ada arahan yang akan dikeluarkan untuknya.
    /// Ini sesuai untuk operasi pada utas yang sama yang mungkin telah ditentukan sebelumnya, seperti ketika berinteraksi dengan pengendali isyarat.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati di [`atomic::compiler_fence`] dengan memasukkan [`Ordering::AcqRel`] sebagai `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Intrinsik sihir yang memperoleh maknanya dari atribut yang melekat pada fungsi.
    ///
    /// Sebagai contoh, aliran data menggunakan ini untuk menyuntikkan penegasan statik sehingga `rustc_peek(potentially_uninitialized)` benar-benar memeriksa semula bahawa aliran data memang mengira bahawa aliran data tidak dimulakan pada saat itu dalam aliran kawalan.
    ///
    ///
    /// Intrinsik ini tidak boleh digunakan di luar penyusun.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Membatalkan pelaksanaan proses.
    ///
    /// Versi operasi yang lebih mesra pengguna dan stabil adalah [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Memaklumkan kepada pengoptimum bahawa titik dalam kod ini tidak dapat dicapai, memungkinkan pengoptimuman lebih lanjut.
    ///
    /// NB, ini sangat berbeza dengan makro `unreachable!()`: Tidak seperti makro, yang panics ketika dijalankan, adalah *tingkah laku yang tidak ditentukan* untuk mencapai kod yang ditandai dengan fungsi ini.
    ///
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Memaklumkan kepada pengoptimum bahawa keadaan selalu berlaku.
    /// Sekiranya keadaan itu salah, tingkah laku itu tidak ditentukan.
    ///
    /// Tidak ada kod yang dihasilkan untuk intrinsik ini, tetapi pengoptimum akan berusaha mengekalkannya (dan keadaannya) di antara hantaran, yang boleh mengganggu pengoptimuman kod sekitarnya dan mengurangkan prestasi.
    /// Ia tidak boleh digunakan jika invarian dapat ditemukan oleh pengoptimum sendiri, atau jika tidak memungkinkan pengoptimuman yang signifikan.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Petunjuk kepada penyusun bahawa keadaan branch kemungkinan benar.
    /// Mengembalikan nilai yang diberikan kepadanya.
    ///
    /// Sebarang penggunaan selain daripada penyataan `if` mungkin tidak akan memberi kesan.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Petunjuk kepada penyusun bahawa keadaan branch kemungkinan salah.
    /// Mengembalikan nilai yang diberikan kepadanya.
    ///
    /// Sebarang penggunaan selain daripada penyataan `if` mungkin tidak akan memberi kesan.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Melakukan perangkap breakpoint, untuk diperiksa oleh penyahpepijat.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn breakpoint();

    /// Ukuran jenis dalam bait.
    ///
    /// Lebih khusus lagi, ini adalah pengimbangan dalam bait antara item berturut-turut dari jenis yang sama, termasuk pelapisan penjajaran.
    ///
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Penjajaran minimum jenis.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Penjajaran jenis yang disukai.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Ukuran nilai yang dirujuk dalam bait.
    ///
    /// Versi stabil dari intrinsik ini ialah [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Penjajaran yang diperlukan dari nilai yang dirujuk.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Mendapat irisan rentetan statik yang mengandungi nama jenis.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Mendapat pengecam yang unik secara global dengan jenis yang ditentukan.
    /// Fungsi ini akan mengembalikan nilai yang sama untuk jenis tanpa mengira crate mana yang digunakan.
    ///
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Penjaga untuk fungsi yang tidak selamat yang tidak dapat dilaksanakan sekiranya `T` tidak berpenghuni:
    /// Ini secara statistik sama ada panic, atau tidak melakukan apa-apa.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Penjaga untuk fungsi yang tidak selamat yang tidak pernah dapat dilaksanakan jika `T` tidak membenarkan inisialisasi awal: Ini secara statik sama ada panic, atau tidak melakukan apa-apa.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn assert_zero_valid<T>();

    /// Penjaga untuk fungsi tidak selamat yang tidak pernah dapat dilaksanakan jika `T` mempunyai corak bit yang tidak sah: Ini secara statik sama ada panic, atau tidak melakukan apa-apa.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn assert_uninit_valid<T>();

    /// Mendapat rujukan ke `Location` statik yang menunjukkan di mana ia dipanggil.
    ///
    /// Pertimbangkan untuk menggunakan [`core::panic::Location::caller`](crate::panic::Location::caller) sebagai gantinya.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Memindahkan nilai di luar ruang lingkup tanpa menjalankan gam pelekat.
    ///
    /// Ini wujud hanya untuk [`mem::forget_unsized`];`forget` biasa menggunakan `ManuallyDrop` sebagai gantinya.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Mentafsirkan bit nilai satu jenis sebagai jenis lain.
    ///
    /// Kedua-dua jenis mesti mempunyai ukuran yang sama.
    /// Baik yang asli, dan juga hasilnya, mungkin [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` secara semantik bersamaan dengan pergerakan sedikit demi sedikit dari satu jenis ke jenis yang lain.Ia menyalin bit dari nilai sumber ke nilai tujuan, kemudian melupakan asalnya.
    /// Ia sama dengan C01 X01 di bawah tudung, sama seperti `transmute_copy`.
    ///
    /// Oleh kerana `transmute` adalah operasi nilai demi nilai, penjajaran *nilai yang ditransmisikan sendiri* tidak menjadi perhatian.
    /// Seperti fungsi lain, penyusun sudah memastikan kedua `T` dan `U` diselaraskan dengan betul.
    /// Walau bagaimanapun, ketika mentransmisikan nilai-nilai yang *menunjuk ke tempat lain*(seperti penunjuk, rujukan, kotak ...), pemanggil harus memastikan penjajaran yang tepat dari nilai yang ditunjuk ke.
    ///
    /// `transmute` **sangat** tidak selamat.Terdapat sebilangan besar cara untuk menyebabkan [undefined behavior][ub] dengan fungsi ini.`transmute` harus menjadi pilihan terakhir mutlak.
    ///
    /// [nomicon](../../nomicon/transmutes.html) mempunyai dokumentasi tambahan.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Terdapat beberapa perkara yang sangat berguna untuk `transmute`.
    ///
    /// Mengubah penunjuk menjadi penunjuk fungsi.Ini *tidak* mudah dibawa ke mesin di mana penunjuk fungsi dan penunjuk data mempunyai ukuran yang berbeza.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Memanjangkan jangka hayat, atau memendekkan jangka hayat yang tidak berubah.Ini adalah Rust yang maju, sangat tidak selamat!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Jangan putus asa: banyak penggunaan `transmute` dapat dicapai dengan cara lain.
    /// Berikut adalah aplikasi biasa `transmute` yang boleh diganti dengan konstruk yang lebih selamat.
    ///
    /// Menukar bytes(`&[u8]`) mentah menjadi `u32`, `f64`, dan lain-lain:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // gunakan `u32::from_ne_bytes` sebagai gantinya
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // atau gunakan `u32::from_le_bytes` atau `u32::from_be_bytes` untuk menentukan endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Mengubah penunjuk menjadi `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sebagai gantinya, gunakan pelakon `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Mengubah `*mut T` menjadi `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sebagai gantinya, gunakan pembayaran semula
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Mengubah `&mut T` menjadi `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sekarang, masukkan `as` dan reborrowing, perhatikan bahawa rantai `as` `as` tidak transitif
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Mengubah `&str` menjadi `&[u8]`:
    ///
    /// ```
    /// // ini bukan kaedah yang baik untuk melakukan ini.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Anda boleh menggunakan `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Atau, hanya gunakan rentetan byte, jika anda mempunyai kawalan ke atas rentetan literal
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Mengubah `Vec<&T>` menjadi `Vec<Option<&T>>`.
    ///
    /// Untuk mentransmisikan jenis isi dalam bekas, anda mesti memastikan tidak melanggar invarian kontena.
    /// Untuk `Vec`, ini bermaksud kedua-dua ukuran *dan penjajaran* dari jenis dalaman mesti sepadan.
    /// Bekas lain mungkin bergantung pada ukuran jenis, penjajaran, atau bahkan `TypeId`, dalam hal transmisi tidak mungkin dilakukan sama sekali tanpa melanggar invarian kontainer.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klon vector kerana kami akan menggunakannya semula kemudian
    /// let v_clone = v_orig.clone();
    ///
    /// // Menggunakan transmute: ini bergantung pada susun atur data `Vec` yang tidak ditentukan, yang merupakan idea yang tidak baik dan boleh menyebabkan Perilaku Tidak Ditentukan.
    /////
    /// // Walau bagaimanapun, ia bukan salinan.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ini adalah cara yang disarankan dan selamat.
    /// // Ia menyalin keseluruhan vector, ke dalam array baru.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ini adalah cara tanpa salinan yang betul, tidak selamat dari "transmuting" dan `Vec`, tanpa bergantung pada susun atur data.
    /// // Daripada memanggil `transmute` secara harfiah, kami melakukan penunjuk pointer, tetapi dari segi menukar jenis dalaman (`&i32`) yang asli ke (`Option<&i32>`) yang baru, ini mempunyai semua peringatan yang sama.
    /////
    /// // Selain maklumat yang diberikan di atas, lihat juga dokumentasi [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Kemas kini ini apabila vec_into_raw_parts distabilkan.
    ///     // Pastikan vector yang asal tidak dijatuhkan.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Melaksanakan `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Terdapat pelbagai cara untuk melakukan ini, dan terdapat banyak masalah dengan cara (transmute) berikut.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pertama: transmute tidak selamat digunakan;semua yang diperiksa adalah bahawa T dan
    ///         // U mempunyai saiz yang sama.
    ///         // Kedua, di sini, anda mempunyai dua rujukan yang boleh berubah yang menunjukkan memori yang sama.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ini menghilangkan masalah keselamatan jenis;`&mut *` hanya akan* memberi anda `&mut T` dari `&mut T` atau `*mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // namun, anda masih mempunyai dua rujukan yang boleh berubah yang menunjukkan memori yang sama.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Inilah cara perpustakaan standard melakukannya.
    /// // Ini adalah kaedah terbaik, jika anda perlu melakukan perkara seperti ini
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ini sekarang mempunyai tiga rujukan yang berubah-ubah yang menunjuk pada memori yang sama.`slice`, rvalue ret.0, dan rvalue ret.1.
    ///         // `slice` tidak pernah digunakan selepas `let ptr = ...`, dan oleh itu seseorang boleh menganggapnya sebagai "dead", dan oleh itu, anda hanya mempunyai dua kepingan yang boleh berubah.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Walaupun ini menjadikan const intrinsik stabil, kami mempunyai beberapa kod tersuai dalam const fn
    // pemeriksaan yang menghalang penggunaannya dalam `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Mengembalikan `true` jika jenis sebenar yang diberikan sebagai `T` memerlukan drop gam;mengembalikan `false` jika jenis sebenar yang disediakan untuk `T` menerapkan `Copy`.
    ///
    ///
    /// Sekiranya jenis sebenarnya tidak memerlukan pelekat atau menggunakan `Copy`, maka nilai kembali fungsi ini tidak ditentukan.
    ///
    /// Versi stabil dari intrinsik ini ialah [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Mengira ofset dari penunjuk.
    ///
    /// Ini dilaksanakan sebagai intrinsik untuk mengelakkan penukaran menjadi dan dari bilangan bulat, kerana penukaran akan membuang maklumat yang menjengkelkan.
    ///
    /// # Safety
    ///
    /// Kedua-dua penunjuk permulaan dan hasil mesti sama ada dalam batas atau satu bait melewati akhir objek yang diperuntukkan.
    /// Sekiranya penunjuk berada di luar batas atau aritmetik limpahan berlaku maka penggunaan nilai kembali yang lebih jauh akan menghasilkan tingkah laku yang tidak ditentukan.
    ///
    ///
    /// Versi stabil dari intrinsik ini ialah [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Mengira ofset dari penunjuk, berpotensi membungkus.
    ///
    /// Ini dilaksanakan sebagai intrinsik untuk mengelakkan penukaran menjadi dan dari bilangan bulat, kerana penukaran menghalang pengoptimuman tertentu.
    ///
    /// # Safety
    ///
    /// Tidak seperti intrinsik `offset`, intrinsik ini tidak menyekat penunjuk yang dihasilkan untuk menunjuk ke atau satu bait melewati akhir objek yang diperuntukkan, dan membungkus dengan aritmetik pelengkap dua.
    /// Nilai yang dihasilkan tidak semestinya sah untuk digunakan untuk benar-benar mengakses memori.
    ///
    /// Versi stabil dari intrinsik ini ialah [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Sama dengan intrinsik `llvm.memcpy.p0i8.0i8.*` yang sesuai, dengan ukuran `count`*`size_of::<T>()` dan penjajaran
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter mudah berubah ditetapkan ke `true`, sehingga tidak akan dioptimumkan kecuali ukurannya sama dengan sifar.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sama dengan intrinsik `llvm.memmove.p0i8.0i8.*` yang sesuai, dengan ukuran `count* size_of::<T>()` dan penjajaran
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter mudah berubah ditetapkan ke `true`, sehingga tidak akan dioptimumkan kecuali ukurannya sama dengan sifar.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Sama dengan intrinsik `llvm.memset.p0i8.*` yang sesuai, dengan ukuran `count* size_of::<T>()` dan penjajaran `min_align_of::<T>()`.
    ///
    ///
    /// Parameter mudah berubah ditetapkan ke `true`, sehingga tidak akan dioptimumkan kecuali ukurannya sama dengan sifar.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Melakukan beban yang tidak menentu dari penunjuk `src`.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Melakukan simpanan turun naik ke penunjuk `dst`.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Melakukan beban yang tidak menentu dari penunjuk `src` Penunjuk tidak diperlukan untuk diselaraskan.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Melakukan simpanan turun naik ke penunjuk `dst`.
    /// Penunjuk tidak diperlukan untuk diselaraskan.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Mengembalikan punca kuasa dua `f32`
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Mengembalikan punca kuasa dua `f64`
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Meningkatkan `f32` menjadi kuasa integer.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Meningkatkan `f64` menjadi kuasa integer.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Mengembalikan sinus `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Mengembalikan sinus `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Mengembalikan kosinus `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Mengembalikan kosinus `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Meningkatkan kuasa `f32` ke `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Meningkatkan kuasa `f64` ke `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Mengembalikan eksponen `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Mengembalikan eksponen `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Mengembalikan 2 dinaikkan ke kekuatan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Mengembalikan 2 dinaikkan ke kekuatan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Mengembalikan logaritma semula jadi `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Mengembalikan logaritma semula jadi `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Mengembalikan logaritma asas 10 `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Mengembalikan logaritma asas 10 `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Mengembalikan logaritma asas 2 `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Mengembalikan logaritma asas 2 `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Mengembalikan `a * b + c` untuk nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Mengembalikan `a * b + c` untuk nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Mengembalikan nilai mutlak `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Mengembalikan nilai mutlak `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Mengembalikan minimum dua nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Mengembalikan minimum dua nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Mengembalikan maksimum dua nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Mengembalikan maksimum dua nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Menyalin tanda dari `y` ke `x` untuk nilai `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Menyalin tanda dari `y` ke `x` untuk nilai `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Mengembalikan bilangan bulat terbesar kurang daripada atau sama dengan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terbesar kurang daripada atau sama dengan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terkecil yang lebih besar daripada atau sama dengan `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terkecil yang lebih besar daripada atau sama dengan `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Mengembalikan bahagian integer `f32`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Mengembalikan bahagian integer `f64`.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.
    /// Boleh menimbulkan pengecualian titik apungan yang tidak tepat jika argumennya bukan bilangan bulat.
    pub fn rintf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.
    /// Boleh menimbulkan pengecualian titik apungan yang tidak tepat jika argumennya bukan bilangan bulat.
    pub fn rintf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Mengembalikan bilangan bulat terdekat ke `f32`.Membulatkan kes separuh jalan dari sifar.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Mengembalikan bilangan bulat terdekat ke `f64`.Membulatkan kes separuh jalan dari sifar.
    ///
    /// Versi stabil dari intrinsik ini adalah
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Penambahan apungan yang membolehkan pengoptimuman berdasarkan peraturan algebra.
    /// Mungkin menganggap input adalah terhad.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Pengurangan apungan yang membolehkan pengoptimuman berdasarkan peraturan algebra.
    /// Mungkin menganggap input adalah terhad.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Pendaraban apungan yang membolehkan pengoptimuman berdasarkan peraturan algebra.
    /// Mungkin menganggap input adalah terhad.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Bahagian apungan yang membolehkan pengoptimuman berdasarkan peraturan algebra.
    /// Mungkin menganggap input adalah terhad.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Sisa float yang membolehkan pengoptimuman berdasarkan peraturan algebra.
    /// Mungkin menganggap input adalah terhad.
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Tukar dengan LLVM's fptoui/fptosi, yang mungkin mengembalikan undef untuk nilai di luar jangkauan
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Ditstabilkan sebagai [`f32::to_int_unchecked`] dan [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Mengembalikan bilangan bit yang ditetapkan dalam jenis integer `T`
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `count_ones`.
    /// Sebagai contoh,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Mengembalikan bilangan bit unset utama (zeroes) dalam bilangan bulat `T`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `leading_zeros`.
    /// Sebagai contoh,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` dengan nilai `0` akan mengembalikan lebar bit `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Seperti `ctlz`, tetapi sangat tidak selamat kerana mengembalikan `undef` apabila diberi `x` dengan nilai `0`.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Mengembalikan bilangan bit unset yang tertinggal (zeroes) dalam bilangan bulat `T`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `trailing_zeros`.
    /// Sebagai contoh,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` dengan nilai `0` akan mengembalikan lebar bit `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Seperti `cttz`, tetapi sangat tidak selamat kerana mengembalikan `undef` apabila diberi `x` dengan nilai `0`.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Membalikkan bait dalam bilangan bulat `T`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `swap_bytes`.
    /// Sebagai contoh,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Membalikkan bit dalam jenis integer `T`.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `reverse_bits`.
    /// Sebagai contoh,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Melakukan penambahan bilangan bulat yang diperiksa.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `overflowing_add`.
    /// Sebagai contoh,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan pengurangan integer yang diperiksa
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `overflowing_sub`.
    /// Sebagai contoh,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan pendaraban bilangan bulat yang diperiksa
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `overflowing_mul`.
    /// Sebagai contoh,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Melakukan pembahagian tepat, menghasilkan tingkah laku yang tidak ditentukan di mana `x % y != 0` atau `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Melakukan pembahagian yang tidak diperiksa, menghasilkan tingkah laku yang tidak ditentukan di mana `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Pembungkus selamat untuk intrinsik ini boleh didapati pada primer integer melalui kaedah `checked_div`.
    /// Sebagai contoh,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Mengembalikan baki bahagian yang tidak diperiksa, menghasilkan tingkah laku yang tidak ditentukan ketika `y == 0` atau `x == T::MIN && y == -1`
    ///
    ///
    /// Pembungkus selamat untuk intrinsik ini boleh didapati pada primer integer melalui kaedah `checked_rem`.
    /// Sebagai contoh,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Melakukan pergeseran kiri yang tidak diperiksa, menghasilkan tingkah laku yang tidak ditentukan ketika `y < 0` atau `y >= N`, di mana N adalah lebar T dalam bit.
    ///
    ///
    /// Pembungkus selamat untuk intrinsik ini boleh didapati pada primer integer melalui kaedah `checked_shl`.
    /// Sebagai contoh,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Melakukan pergeseran kanan yang tidak dicentang, menghasilkan tingkah laku yang tidak ditentukan ketika `y < 0` atau `y >= N`, di mana N adalah lebar T dalam bit.
    ///
    ///
    /// Pembungkus selamat untuk intrinsik ini boleh didapati pada primer integer melalui kaedah `checked_shr`.
    /// Sebagai contoh,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil penambahan yang tidak dicentang, menghasilkan tingkah laku yang tidak ditentukan ketika `x + y > T::MAX` atau `x + y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil pengurangan yang tidak dicentang, menghasilkan tingkah laku yang tidak ditentukan ketika `x - y > T::MAX` atau `x - y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan hasil pendaraban yang tidak diperiksa, menghasilkan tingkah laku yang tidak ditentukan ketika `x *y > T::MAX` atau `x* y < T::MIN`.
    ///
    ///
    /// Intrinsik ini tidak mempunyai rakan yang stabil.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Melakukan putaran ke kiri.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `rotate_left`.
    /// Sebagai contoh,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Melakukan putaran ke kanan.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `rotate_right`.
    /// Sebagai contoh,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Mengembalikan (a + b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `wrapping_add`.
    /// Sebagai contoh,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Mengembalikan (a, b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `wrapping_sub`.
    /// Sebagai contoh,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Mengembalikan (a * b) mod 2 <sup>N</sup>, di mana N adalah lebar T dalam bit.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `wrapping_mul`.
    /// Sebagai contoh,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Mengira `a + b`, tepu pada batas angka.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `saturating_add`.
    /// Sebagai contoh,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Mengira `a - b`, tepu pada batas angka.
    ///
    /// Versi stabil dari intrinsik ini boleh didapati pada primer integer melalui kaedah `saturating_sub`.
    /// Sebagai contoh,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Mengembalikan nilai diskriminan untuk varian dalam 'v';
    /// jika `T` tidak mempunyai diskriminasi, mengembalikan `0`.
    ///
    /// Versi stabil dari intrinsik ini ialah [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Mengembalikan bilangan varian jenis pelakon `T` ke `usize`;
    /// jika `T` tidak mempunyai varian, mengembalikan `0`.Varian yang tidak berpenghuni akan dikira.
    ///
    /// Versi intrinsik ini yang mesti ditstabilkan adalah [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konstruksi "try catch" Rust yang memanggil fungsi penunjuk `try_fn` dengan penunjuk data `data`.
    ///
    /// Argumen ketiga adalah fungsi yang disebut jika panic berlaku.
    /// Fungsi ini membawa penunjuk data dan penunjuk ke objek pengecualian khusus sasaran yang ditangkap.
    ///
    /// Untuk maklumat lebih lanjut, lihat sumber penyusun serta pelaksanaan tangkapan std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Memancarkan kedai `!nontemporal` mengikut LLVM (lihat dokumen mereka).
    /// Mungkin tidak akan menjadi stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Lihat dokumentasi `<*const T>::offset_from` untuk perincian.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Lihat dokumentasi `<*const T>::guaranteed_eq` untuk perincian.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Lihat dokumentasi `<*const T>::guaranteed_ne` untuk perincian.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Peruntukkan pada masa penyusunan.Tidak boleh dipanggil pada waktu runtime.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Beberapa fungsi didefinisikan di sini kerana secara tidak sengaja tersedia dalam modul ini di kandang.
// Lihat <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` juga termasuk dalam kategori ini, tetapi tidak dapat dibungkus karena pemeriksaan bahawa `T` dan `U` memiliki ukuran yang sama.)
//

/// Memeriksa sama ada `ptr` diselaraskan dengan betul berkenaan dengan `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Menyalin bait `count *size_of::<T>()` dari `src` hingga `dst`.Sumber dan tujuan mesti* tidak * bertindih.
///
/// Untuk kawasan memori yang mungkin bertindih, gunakan [`copy`] sebagai gantinya.
///
/// `copy_nonoverlapping` semantik setara dengan C0000 C, tetapi dengan pesanan argumen ditukar.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `src` mestilah [valid] untuk bacaan `count * size_of::<T>()` bait.
///
/// * `dst` mestilah [valid] untuk penulisan byte `count * size_of::<T>()`.
///
/// * Kedua-dua `src` dan `dst` mesti diselaraskan dengan betul.
///
/// * Kawasan memori bermula pada `src` dengan ukuran `kiraan *
///   saiz: :<T>() `byte mesti *tidak* bertindih dengan kawasan memori bermula pada `dst` dengan ukuran yang sama.
///
/// Seperti [`read`], `copy_nonoverlapping` membuat salinan sedikit demi sedikit `T`, tidak kira sama ada `T` adalah [`Copy`].
/// Sekiranya `T` bukan [`Copy`], gunakan *keduanya* nilai di rantau yang bermula pada `*src` dan rantau yang dimulai pada `* dst` dapat [violate memory safety][read-ownership].
///
///
/// Perhatikan bahawa walaupun ukuran yang disalin secara berkesan (`hitung * size_of: :<T>()`) adalah `0`, penunjuk mestilah bukan NULL dan diselaraskan dengan betul.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Laksanakan [`Vec::append`] secara manual:
///
/// ```
/// use std::ptr;
///
/// /// Memindahkan semua elemen `src` ke `dst`, membiarkan `src` kosong.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Pastikan `dst` mempunyai kapasiti yang cukup untuk menampung semua `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Panggilan untuk mengimbangi selalu selamat kerana `Vec` tidak akan memperuntukkan lebih daripada `isize::MAX` bait.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Potong `src` tanpa menjatuhkan kandungannya.
///         // Kami melakukan ini terlebih dahulu, untuk mengelakkan masalah sekiranya berlaku lebih jauh dari panics.
///         src.set_len(0);
///
///         // Kedua-dua wilayah tersebut tidak boleh bertindih kerana rujukan yang boleh berubah tidak alias, dan dua vektor yang berbeza tidak dapat memiliki memori yang sama.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Beritahu `dst` bahawa ia sekarang mengandungi kandungan `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Lakukan pemeriksaan ini hanya pada waktu berjalan
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Tidak panik untuk memastikan impak codegen lebih kecil.
        abort();
    }*/

    // KESELAMATAN: kontrak keselamatan untuk `copy_nonoverlapping` mestilah
    // ditegakkan oleh pemanggil.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Menyalin bait `count * size_of::<T>()` dari `src` hingga `dst`.Sumber dan tujuan mungkin bertindih.
///
/// Sekiranya sumber dan tujuan *tidak* tumpang tindih, [`copy_nonoverlapping`] boleh digunakan sebagai gantinya.
///
/// `copy` semantik setara dengan C0000 C, tetapi dengan pesanan argumen ditukar.
/// Penyalinan berlaku seolah-olah bait disalin dari `src` ke array sementara dan kemudian disalin dari array ke `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `src` mestilah [valid] untuk bacaan `count * size_of::<T>()` bait.
///
/// * `dst` mestilah [valid] untuk penulisan byte `count * size_of::<T>()`.
///
/// * Kedua-dua `src` dan `dst` mesti diselaraskan dengan betul.
///
/// Seperti [`read`], `copy` membuat salinan sedikit demi sedikit `T`, tidak kira sama ada `T` adalah [`Copy`].
/// Sekiranya `T` bukan [`Copy`], menggunakan kedua-dua nilai di rantau yang bermula pada `*src` dan rantau yang dimulai pada `* dst` dapat [violate memory safety][read-ownership].
///
///
/// Perhatikan bahawa walaupun ukuran yang disalin secara berkesan (`hitung * size_of: :<T>()`) adalah `0`, penunjuk mestilah bukan NULL dan diselaraskan dengan betul.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Buat Rust vector dengan berkesan dari penyangga yang tidak selamat:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` mesti diselaraskan dengan betul untuk jenisnya dan bukan sifar.
/// /// * `ptr` mesti sah untuk pembacaan unsur bersambung `elts` jenis `T`.
/// /// * Unsur-unsur tersebut tidak boleh digunakan setelah memanggil fungsi ini kecuali `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KESELAMATAN: Prasyarat kami memastikan sumbernya sejajar dan sah,
///     // dan `Vec::with_capacity` memastikan bahawa kita mempunyai ruang yang boleh digunakan untuk menulisnya.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // KESELAMATAN: Kami membuatnya dengan kapasiti sebegini lebih awal,
///     // dan `copy` sebelumnya telah memulakan elemen-elemen ini.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Lakukan pemeriksaan ini hanya pada waktu berjalan
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Tidak panik untuk memastikan impak codegen lebih kecil.
        abort();
    }*/

    // KESELAMATAN: kontrak keselamatan untuk `copy` mesti dipegang oleh pemanggil.
    unsafe { copy(src, dst, count) }
}

/// Menetapkan memori byte `count * size_of::<T>()` bermula dari `dst` hingga `val`.
///
/// `write_bytes` serupa dengan C's [`memset`], tetapi menetapkan byte `count * size_of::<T>()` ke `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Tingkah laku tidak ditentukan sekiranya salah satu syarat berikut dilanggar:
///
/// * `dst` mestilah [valid] untuk penulisan byte `count * size_of::<T>()`.
///
/// * `dst` mesti diselaraskan dengan betul.
///
/// Selain itu, pemanggil mesti memastikan bahawa menulis byte `count * size_of::<T>()` ke kawasan memori yang diberikan menghasilkan nilai `T` yang sah.
/// Menggunakan kawasan memori yang ditaip sebagai `T` yang mengandungi nilai `T` yang tidak sah adalah tingkah laku yang tidak ditentukan.
///
/// Perhatikan bahawa walaupun ukuran yang disalin secara berkesan (`hitung * size_of: :<T>()`) adalah `0`, penunjuk mestilah bukan NULL dan diselaraskan dengan betul.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Penggunaan asas:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Membuat nilai yang tidak betul:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Membocorkan nilai yang dipegang sebelumnya dengan menimpa `Box<T>` dengan penunjuk kosong.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Pada ketika ini, menggunakan atau menjatuhkan `v` menghasilkan tingkah laku yang tidak ditentukan.
/// // drop(v); // ERROR
///
/// // Bahkan membocorkan `v` "uses", dan oleh itu adalah perilaku yang tidak ditentukan.
/// // mem::forget(v); // ERROR
///
/// // Sebenarnya, `v` tidak sah mengikut invariant susun atur jenis asas, jadi *sebarang* operasi yang menyentuhnya adalah tingkah laku yang tidak ditentukan.
/////
/// // biarkan v2 =v;//RALAT
///
/// unsafe {
///     // Biarkan kita meletakkan nilai yang sah
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Sekarang kotak itu baik-baik saja
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // KESELAMATAN: kontrak keselamatan untuk `write_bytes` mesti dipegang oleh pemanggil.
    unsafe { write_bytes(dst, val, count) }
}