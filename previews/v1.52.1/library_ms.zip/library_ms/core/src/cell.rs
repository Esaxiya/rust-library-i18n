//! Bekas boleh ubah yang boleh dikongsi.
//!
//! Keselamatan memori Rust berdasarkan peraturan ini: Memandangkan objek `T`, hanya mungkin memiliki salah satu daripada yang berikut:
//!
//! - Mempunyai beberapa rujukan (`&T`) yang tidak berubah pada objek (juga dikenali sebagai **aliasing**).
//! - Mempunyai satu rujukan yang dapat diubah (`&mut T`) ke objek (juga dikenali sebagai **mutability**).
//!
//! Ini dikuatkuasakan oleh penyusun Rust.Walau bagaimanapun, terdapat situasi di mana peraturan ini tidak cukup fleksibel.Kadang-kadang diperlukan untuk mempunyai banyak rujukan ke suatu objek namun dapat mengubahnya.
//!
//! Wadah yang dapat diubah suai ada untuk membolehkan kebolehubahan secara terkawal, walaupun terdapat aliasing.Kedua-dua [`Cell<T>`] dan [`RefCell<T>`] membenarkan melakukan ini dengan satu utas.
//! Walau bagaimanapun, `Cell<T>` dan `RefCell<T>` tidak selamat pada benang (mereka tidak melaksanakan [`Sync`]).
//! Sekiranya anda perlu melakukan aliasing dan mutasi antara beberapa utas, mungkin menggunakan jenis [`Mutex<T>`], [`RwLock<T>`] atau [`atomic`].
//!
//! Nilai jenis `Cell<T>` dan `RefCell<T>` boleh dimutasi melalui rujukan bersama (iaitu
//! jenis `&T` biasa), sedangkan kebanyakan jenis Rust hanya boleh dimutasi melalui rujukan unik (`&mut T`).
//! Kami mengatakan bahawa `Cell<T>` dan `RefCell<T>` memberikan 'kebolehubahan dalaman', berbeza dengan jenis Rust khas yang menunjukkan 'kebolehubahan yang diwarisi'.
//!
//! Jenis sel terdapat dalam dua perisa: `Cell<T>` dan `RefCell<T>`.`Cell<T>` menerapkan kebolehubahan dalaman dengan menggerakkan nilai masuk dan keluar dari `Cell<T>`.
//! Untuk menggunakan rujukan dan bukannya nilai, seseorang mesti menggunakan jenis `RefCell<T>`, memperoleh kunci tulis sebelum bermutasi.`Cell<T>` menyediakan kaedah untuk mendapatkan dan mengubah nilai dalaman semasa:
//!
//!  - Untuk jenis yang menerapkan [`Copy`], kaedah [`get`](Cell::get) mengambil nilai dalaman semasa.
//!  - Untuk jenis yang menerapkan [`Default`], kaedah [`take`](Cell::take) menggantikan nilai dalaman semasa dengan [`Default::default()`] dan mengembalikan nilai yang diganti.
//!  - Untuk semua jenis, kaedah [`replace`](Cell::replace) menggantikan nilai dalaman semasa dan mengembalikan nilai yang diganti dan kaedah [`into_inner`](Cell::into_inner) menggunakan `Cell<T>` dan mengembalikan nilai dalaman.
//!  Selain itu, kaedah [`set`](Cell::set) menggantikan nilai dalaman, menjatuhkan nilai yang diganti.
//!
//! `RefCell<T>` menggunakan jangka hayat Rust untuk melaksanakan 'peminjaman dinamik', suatu proses di mana seseorang dapat menuntut akses sementara, eksklusif, yang dapat berubah ke nilai dalaman.
//! Meminjam untuk `RefCell<T>"s dilacak 'pada waktu runtime', tidak seperti jenis rujukan asli Rust yang sepenuhnya dijejaki secara statik, pada waktu kompilasi.
//! Oleh kerana peminjam `RefCell<T>` bersifat dinamik, adalah mungkin untuk mencuba meminjam nilai yang sudah dipinjam bersama;apabila ini berlaku ia menghasilkan benang panic.
//!
//! # Bila hendak memilih kebolehubahan dalaman
//!
//! Kebolehubahan yang diwariskan yang lebih biasa, di mana seseorang mesti mempunyai akses unik untuk mengubah nilai, adalah salah satu elemen bahasa utama yang membolehkan Rust memberi alasan yang kuat mengenai pemisahan penunjuk, secara statik mencegah pepijat kerosakan.
//! Oleh kerana itu, kebolehubahan yang diwarisi lebih disukai, dan kebolehubahan dalaman adalah pilihan terakhir.
//! Oleh kerana jenis sel membolehkan mutasi di mana ia tidak diizinkan, ada kalanya kebolehubahan dalaman mungkin sesuai, atau bahkan *mesti* digunakan, misalnya
//!
//! * Memperkenalkan kebolehubahan 'inside' sesuatu yang tidak berubah
//! * Perincian pelaksanaan kaedah yang tidak berubah secara logik.
//! * Mengamalkan pelaksanaan [`Clone`].
//!
//! ## Memperkenalkan kebolehubahan 'inside' sesuatu yang tidak berubah
//!
//! Banyak jenis penunjuk pintar yang dikongsi, termasuk [`Rc<T>`] dan [`Arc<T>`], menyediakan bekas yang dapat diklon dan dikongsi antara pelbagai pihak.
//! Kerana nilai yang terkandung mungkin diasingkan berganda, nilainya hanya dapat dipinjam dengan `&`, bukan `&mut`.
//! Tanpa sel, mustahil untuk mengubah data di dalam penunjuk pintar ini sama sekali.
//!
//! Sangat biasa jika meletakkan `RefCell<T>` di dalam jenis penunjuk yang dikongsi untuk memperkenalkan kebolehubahan:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Buat blok baru untuk menghadkan ruang lingkup pinjaman dinamik
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Perhatikan bahawa jika kita tidak membiarkan pinjaman cache sebelumnya jatuh dari ruang lingkup maka pinjaman berikutnya akan menyebabkan benang dinamis panic.
//!     //
//!     // Ini adalah bahaya utama penggunaan `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Perhatikan bahawa contoh ini menggunakan `Rc<T>` dan bukan `Arc<T>`.`RefCell<T>s adalah untuk senario single-thread.Pertimbangkan untuk menggunakan [`RwLock<T>`] atau [`Mutex<T>`] jika anda memerlukan kebolehubahan bersama dalam situasi berbilang utas.
//!
//! ## Perincian pelaksanaan kaedah yang tidak berubah secara logik
//!
//! Kadang-kadang mungkin diinginkan untuk tidak mendedahkan dalam API bahawa terdapat mutasi yang berlaku "under the hood".
//! Ini mungkin kerana secara logiknya operasi tidak berubah, tetapi misalnya, caching memaksa pelaksanaan untuk melakukan mutasi;atau kerana anda mesti menggunakan mutasi untuk melaksanakan kaedah trait yang pada awalnya ditentukan untuk mengambil `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Pengiraan yang mahal berlaku di sini
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mengamalkan pelaksanaan `Clone`
//!
//! Ini hanyalah kes khas, tetapi biasa, yang sebelumnya: menyembunyikan kebolehubahan untuk operasi yang nampaknya tidak berubah.
//! Kaedah [`clone`](Clone::clone) diharapkan tidak mengubah nilai sumber, dan dinyatakan mengambil `&self`, bukan `&mut self`.
//! Oleh itu, sebarang mutasi yang berlaku dalam kaedah `clone` mesti menggunakan jenis sel.
//! Sebagai contoh, [`Rc<T>`] mengekalkan bilangan rujukannya dalam `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Lokasi memori yang boleh berubah.
///
/// # Examples
///
/// Dalam contoh ini, anda dapat melihat bahawa `Cell<T>` membolehkan mutasi di dalam struktur yang tidak berubah.
/// Dengan kata lain, ia membolehkan "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // RALAT: `my_struct` tidak boleh berubah
/// // my_struct.regular_field =nilai_baru;
///
/// // KERJA: walaupun `my_struct` tidak berubah, `special_field` adalah `Cell`,
/// // yang selalu dapat bermutasi
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Membuat `Cell<T>`, dengan nilai `Default` untuk T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Membuat `Cell` baru yang mengandungi nilai yang diberikan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Menetapkan nilai yang terkandung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Menukar nilai dua Sel.
    /// Perbezaan dengan `std::mem::swap` adalah bahawa fungsi ini tidak memerlukan rujukan `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // KESELAMATAN: Ini boleh berisiko jika dipanggil dari utas yang berasingan, tetapi `Cell`
        // adalah `!Sync` jadi ini tidak akan berlaku.
        // Ini juga tidak akan membatalkan petunjuk kerana `Cell` memastikan tidak ada perkara lain yang akan menunjuk ke salah satu dari `Cell`s ini.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Menggantikan nilai terkandung dengan `val`, dan mengembalikan nilai terkandung lama.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // KESELAMATAN: Ini boleh menyebabkan perlumbaan data jika dipanggil dari utas yang terpisah,
        // tetapi `Cell` adalah `!Sync` jadi ini tidak akan berlaku.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Membongkar nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Mengembalikan salinan nilai yang terkandung.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // KESELAMATAN: Ini boleh menyebabkan perlumbaan data jika dipanggil dari utas yang terpisah,
        // tetapi `Cell` adalah `!Sync` jadi ini tidak akan berlaku.
        unsafe { *self.value.get() }
    }

    /// Mengemas kini nilai terkandung menggunakan fungsi dan mengembalikan nilai baru.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Mengembalikan penunjuk mentah ke data asas dalam sel ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Mengembalikan rujukan yang berubah-ubah ke data yang mendasari.
    ///
    /// Panggilan ini meminjam `Cell` secara bergantian (pada waktu kompilasi) yang menjamin bahawa kita mempunyai satu-satunya rujukan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Mengembalikan `&Cell<T>` dari `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // KESELAMATAN: `&mut` memastikan akses unik.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Mengambil nilai sel, meninggalkan `Default::default()` di tempatnya.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Mengembalikan `&[Cell<T>]` dari `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // KESELAMATAN: `Cell<T>` mempunyai susun atur memori yang sama dengan `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Lokasi memori yang boleh diubah dengan peraturan peminjaman yang diperiksa secara dinamik
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Ralat dikembalikan oleh [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Ralat dikembalikan oleh [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Nilai positif mewakili bilangan `Ref` aktif.Nilai negatif mewakili bilangan `RefMut` aktif.
// Pelbagai `RefMut`s hanya dapat aktif pada satu masa jika merujuk kepada komponen `RefCell` yang berbeza dan tidak bertindih (contohnya, rentang potongan yang berbeza).
//
// `Ref` dan `RefMut` adalah dua perkataan yang berukuran, dan kemungkinan tidak akan ada cukup `Ref`s atau`RefMut` untuk melimpah separuh daripada julat `usize`.
// Oleh itu, `BorrowFlag` mungkin tidak akan meluap atau meluap.
// Namun, ini bukan jaminan, kerana program patologi dapat berulang kali dibuat dan kemudian mem::forget `Ref`s atau`RefMut`s.
// Oleh itu, semua kod mesti secara eksplisit memeriksa limpahan dan aliran bawah untuk mengelakkan tidak selamat, atau sekurang-kurangnya berkelakuan dengan betul sekiranya berlaku limpahan atau aliran bawah (misalnya, lihat BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Membuat `RefCell` baru yang mengandungi `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Menggunakan `RefCell`, mengembalikan nilai yang dibungkus.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Oleh kerana fungsi ini mengambil nilai `self` (`RefCell`), penyusun secara statistik mengesahkan bahawa ia tidak dipinjam pada masa ini.
        //
        self.value.into_inner()
    }

    /// Menggantikan nilai yang dibungkus dengan yang baru, mengembalikan nilai lama, tanpa membinasakan salah satu.
    ///
    ///
    /// Fungsi ini sepadan dengan [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam pada masa ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Menggantikan nilai yang dibungkus dengan yang baru yang dikira dari `f`, mengembalikan nilai lama, tanpa mendefinisikan salah satu.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam pada masa ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Tukar nilai pembungkus `self` dengan nilai pembungkus `other`, tanpa membinasakan salah satu.
    ///
    ///
    /// Fungsi ini sepadan dengan [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Meminjam nilai bungkus secara tidak selanjarnya.
    ///
    /// Pinjaman berlangsung sehingga `Ref` yang dikembalikan keluar dari skop.
    /// Banyak peminjaman tidak berubah boleh dikeluarkan pada masa yang sama.
    ///
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam secara mutlak.
    /// Untuk varian yang tidak panik, gunakan [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Contoh panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Meminjam nilai yang telah dibungkus secara tidak berubah, mengembalikan ralat jika nilainya dipinjam secara mutlak.
    ///
    ///
    /// Pinjaman berlangsung sehingga `Ref` yang dikembalikan keluar dari skop.
    /// Banyak peminjaman tidak berubah boleh dikeluarkan pada masa yang sama.
    ///
    /// Ini adalah varian [`borrow`](#method.borrow) yang tidak panik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // KESELAMATAN: `BorrowRef` memastikan bahawa hanya ada akses yang tidak berubah
            // kepada nilai semasa dipinjam.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Meminjam nilai berbungkus secara bergantian.
    ///
    /// Pinjaman berlangsung sehingga `RefMut` yang dikembalikan atau semua `RefMut`s yang keluar dari skop keluar.
    ///
    /// Nilainya tidak boleh dipinjam semasa pinjaman ini aktif.
    ///
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam pada masa ini.
    /// Untuk varian yang tidak panik, gunakan [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Contoh panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Meminjam dengan baik nilai yang dibungkus, mengembalikan ralat jika nilainya dipinjam.
    ///
    ///
    /// Pinjaman berlangsung sehingga `RefMut` yang dikembalikan atau semua `RefMut`s yang keluar dari skop keluar.
    /// Nilainya tidak boleh dipinjam semasa pinjaman ini aktif.
    ///
    /// Ini adalah varian [`borrow_mut`](#method.borrow_mut) yang tidak panik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // KESELAMATAN: `BorrowRef` menjamin akses unik.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Mengembalikan penunjuk mentah ke data asas dalam sel ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Mengembalikan rujukan yang berubah-ubah ke data yang mendasari.
    ///
    /// Panggilan ini meminjam `RefCell` secara bergantian (pada waktu kompilasi) sehingga tidak perlu pemeriksaan dinamik.
    ///
    /// Namun berhati-hati: kaedah ini mengharapkan `self` tidak dapat berubah, yang biasanya tidak berlaku ketika menggunakan `RefCell`.
    ///
    /// Lihat kaedah [`borrow_mut`] sebaliknya jika `self` tidak boleh berubah.
    ///
    /// Juga, perlu diketahui bahawa kaedah ini hanya untuk keadaan khas dan biasanya tidak seperti yang anda mahukan.
    /// Sekiranya terdapat keraguan, gunakan [`borrow_mut`] sebagai gantinya.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Batalkan kesan pengawal yang bocor terhadap keadaan pinjaman `RefCell`.
    ///
    /// Panggilan ini serupa dengan [`get_mut`] tetapi lebih khusus.
    /// Ia meminjam `RefCell` secara mutlak untuk memastikan tidak ada peminjam dan kemudian menetapkan semula keadaan pengesanan peminjaman bersama.
    /// Ini relevan jika beberapa peminjam `Ref` atau `RefMut` telah dibocorkan.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Meminjam nilai yang telah dibungkus secara tidak berubah, mengembalikan ralat jika nilainya dipinjam secara mutlak.
    ///
    /// # Safety
    ///
    /// Tidak seperti `RefCell::borrow`, kaedah ini tidak selamat kerana tidak mengembalikan `Ref`, sehingga membiarkan bendera pinjaman tidak tersentuh.
    /// Meminjam `RefCell` secara diam-diam sementara rujukan yang dikembalikan oleh kaedah ini masih hidup adalah tingkah laku yang tidak ditentukan.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // KESELAMATAN: Kami memeriksa bahawa tidak ada yang aktif menulis sekarang, tetapi memang betul
            // tanggungjawab pemanggil untuk memastikan bahawa tiada siapa yang menulis sehingga rujukan yang dikembalikan tidak lagi digunakan.
            // Juga, `self.value.get()` merujuk kepada nilai yang dimiliki oleh `self` dan dengan itu dijamin sah untuk jangka hayat `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Mengambil nilai yang dibungkus, meninggalkan `Default::default()` di tempatnya.
    ///
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam pada masa ini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilainya dipinjam secara mutlak.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Membuat `RefCell<T>`, dengan nilai `Default` untuk T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics jika nilai pada salah satu `RefCell` sedang dipinjam.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Penambahan pinjaman boleh menghasilkan nilai tidak membaca (<=0) dalam kes berikut:
            // 1. Itu adalah <0, iaitu ada pinjaman peminjaman, jadi kami tidak boleh membiarkan pinjaman baca kerana peraturan pengasingan rujukan Rust
            // 2.
            // Ia adalah isize::MAX (jumlah maksimum membaca pinjaman) dan ia meluap menjadi isize::MIN (jumlah maksimum penulisan peminjam) jadi kami tidak boleh membenarkan pinjaman baca tambahan kerana isize tidak dapat mewakili begitu banyak pinjaman yang dibaca (ini hanya boleh berlaku jika anda mem::forget lebih daripada jumlah tetap `Ref`s, yang bukan amalan yang baik)
            //
            //
            //
            //
            None
        } else {
            // Penambahan pinjaman boleh menghasilkan nilai bacaan (> 0) dalam kes berikut:
            // 1. Ia adalah=0, iaitu tidak dipinjam, dan kami mengambil pinjaman baca pertama
            // 2. Ia adalah> 0 dan <isize::MAX, iaitu
            // terdapat pinjaman yang dibaca, dan ukurannya cukup besar untuk menunjukkan mempunyai pinjaman baca lagi
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Oleh kerana Ref ini wujud, kita tahu bendera pinjaman adalah pinjaman membaca.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Cegah kaunter pinjam daripada meluap menjadi pinjaman penulisan.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Membungkus rujukan yang dipinjam ke nilai dalam kotak `RefCell`.
/// Jenis pembungkus untuk nilai yang dipinjam dari `RefCell<T>`.
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Menyalin `Ref`.
    ///
    /// `RefCell` sudah dipinjam tanpa henti, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `Ref::clone(...)`.
    /// Pelaksanaan `Clone` atau kaedah akan mengganggu penggunaan `r.borrow().clone()` secara meluas untuk mengklon kandungan `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Membuat `Ref` baru untuk komponen data yang dipinjam.
    ///
    /// `RefCell` sudah dipinjam tanpa henti, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `Ref::map(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Membuat `Ref` baru untuk komponen pilihan dari data yang dipinjam.
    /// Pelindung asal dikembalikan sebagai `Err(..)` jika penutupan mengembalikan `None`.
    ///
    /// `RefCell` sudah dipinjam tanpa henti, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `Ref::filter_map(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Membahagi `Ref` menjadi beberapa `Ref`s untuk komponen yang berbeza dari data yang dipinjam.
    ///
    /// `RefCell` sudah dipinjam tanpa henti, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `Ref::map_split(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Tukar menjadi rujukan ke data yang mendasari.
    ///
    /// `RefCell` yang mendasarinya tidak boleh dipinjam lagi dan akan selalu dipinjam tanpa henti.
    ///
    /// Bukan idea yang baik untuk membocorkan lebih banyak daripada sebilangan rujukan yang tetap.
    /// `RefCell` boleh dipinjam lagi jika hanya terdapat sedikit kebocoran yang berlaku secara keseluruhan.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `Ref::leak(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Dengan melupakan Ref ini, kami memastikan bahawa kaunter pinjaman di RefCell tidak dapat kembali ke UNUSED dalam jangka masa `'b` seumur hidup.
        // Menetapkan semula keadaan penjejakan rujukan memerlukan rujukan unik untuk RefCell yang dipinjam.
        // Tiada rujukan yang dapat diubah lebih lanjut dapat dibuat dari sel asal.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Membuat `RefMut` baru untuk komponen data yang dipinjam, misalnya, varian enum.
    ///
    /// `RefCell` sudah dipinjam, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `RefMut::map(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): betulkan cek pinjaman
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Membuat `RefMut` baru untuk komponen pilihan dari data yang dipinjam.
    /// Pelindung asal dikembalikan sebagai `Err(..)` jika penutupan mengembalikan `None`.
    ///
    /// `RefCell` sudah dipinjam, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `RefMut::filter_map(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): betulkan cek pinjaman
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // KESELAMATAN: fungsi memegang rujukan eksklusif selama ini
        // panggilannya melalui `orig`, dan penunjuk hanya tidak dirujuk di dalam fungsi panggilan tidak membenarkan rujukan eksklusif melarikan diri.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // KESELAMATAN: sama seperti di atas.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Membahagi `RefMut` menjadi beberapa `RefMut`s untuk komponen yang berbeza dari data yang dipinjam.
    ///
    /// `RefCell` yang mendasari akan tetap dipinjam sehingga kedua-duanya mengembalikan `RefMut`s di luar ruang lingkup.
    ///
    /// `RefCell` sudah dipinjam, jadi ini tidak akan gagal.
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `RefMut::map_split(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Tukarkan menjadi rujukan yang boleh berubah ke data yang mendasari.
    ///
    /// `RefCell` yang mendasari tidak dapat dipinjam lagi dan akan selalu kelihatan sudah dipinjam secara bergantian, menjadikan rujukan yang dikembalikan hanya menjadi bahagian dalaman.
    ///
    ///
    /// Ini adalah fungsi yang berkaitan yang perlu digunakan sebagai `RefMut::leak(...)`.
    /// Kaedah akan mengganggu kaedah dengan nama yang sama pada kandungan `RefCell` yang digunakan melalui `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Dengan melupakan BorrowRefMut ini, kami memastikan bahawa kaunter pinjaman di RefCell tidak dapat kembali ke TIDAK DIGUNAKAN dalam masa `'b` seumur hidup.
        // Menetapkan semula keadaan penjejakan rujukan memerlukan rujukan unik untuk RefCell yang dipinjam.
        // Tidak ada rujukan lebih lanjut yang dapat dibuat dari sel asal dalam jangka hayat itu, menjadikan pinjaman semasa satu-satunya rujukan untuk jangka hayat yang tinggal.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Tidak seperti BorrowRefMut::clone, yang baru dipanggil untuk membuat yang awal
        // rujukan yang boleh diubah, dan pada masa ini mesti ada rujukan yang tidak ada
        // Oleh itu, sementara klon menambah jumlah berubah, di sini kita secara eksplisit hanya membenarkan pergi dari TIDAK DIGUNAKAN ke TIDAK DIGUNAKAN,
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klon `BorrowRefMut`.
    //
    // Ini hanya berlaku jika setiap `BorrowRefMut` digunakan untuk melacak rujukan yang dapat diubah ke julat objek asal yang tidak saling tumpang tindih.
    //
    // Ini tidak ada dalam implan Clone sehingga kod tidak menyebutnya secara tersirat.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Elakkan kaunter pinjaman daripada aliran masuk.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Jenis pembungkus untuk nilai yang dipinjam dari `RefCell<T>`.
///
/// Lihat [module-level documentation](self) untuk lebih banyak lagi.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Primitif teras untuk kebolehubahan dalaman di Rust.
///
/// Sekiranya anda mempunyai rujukan `&T`, maka biasanya dalam Rust pengkompil melakukan pengoptimuman berdasarkan pengetahuan bahawa `&T` menunjukkan data yang tidak berubah.Memutuskan data tersebut, misalnya melalui alias atau dengan mentransmisikan `&T` ke `&mut T`, dianggap sebagai tingkah laku yang tidak ditentukan.
/// `UnsafeCell<T>` memilih keluar dari jaminan kebolehubahan untuk `&T`: rujukan bersama `&UnsafeCell<T>` mungkin menunjukkan data yang dimutasi.Ini dipanggil "interior mutability".
///
/// Semua jenis lain yang memungkinkan kebolehubahan dalaman, seperti `Cell<T>` dan `RefCell<T>`, menggunakan `UnsafeCell` secara dalaman untuk membungkus data mereka.
///
/// Perhatikan bahawa hanya jaminan kebolehubahan untuk rujukan bersama yang dipengaruhi oleh `UnsafeCell`.Jaminan keunikan untuk rujukan yang berubah-ubah tidak terjejas.Tidak ada cara sah untuk mendapatkan aliasing `&mut`, bahkan tidak dengan `UnsafeCell<T>`.
///
/// API `UnsafeCell` sendiri secara teknikalnya sangat mudah: [`.get()`] memberi anda penunjuk mentah `*mut T` kepada kandungannya.Terserah _you_ sebagai pereka abstraksi untuk menggunakan penunjuk mentah itu dengan betul.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Peraturan pengasingan Rust yang tepat agak berubah-ubah, tetapi perkara utama tidak dipersoalkan:
///
/// - Sekiranya anda membuat rujukan selamat dengan `'a` seumur hidup (sama ada rujukan `&T` atau `&mut T`) yang boleh diakses dengan kod selamat (contohnya, kerana anda mengembalikannya), maka anda tidak boleh mengakses data dengan cara yang bertentangan dengan rujukan tersebut untuk selebihnya daripada `'a`
/// Sebagai contoh, ini bermaksud bahawa jika anda mengambil `*mut T` dari `UnsafeCell<T>` dan membuangnya ke `&T`, maka data dalam `T` mesti tetap tidak berubah (modulo mana-mana data `UnsafeCell` yang terdapat dalam `T`, tentu saja) sehingga jangka hayat rujukan itu tamat.
/// Begitu juga, jika anda membuat rujukan `&mut T` yang dilepaskan ke kod selamat, maka anda tidak boleh mengakses data dalam `UnsafeCell` sehingga rujukan tersebut tamat.
///
/// - Setiap masa, anda mesti mengelakkan perlumbaan data.Sekiranya pelbagai utas mempunyai akses ke `UnsafeCell` yang sama, maka penulisan apa pun mesti berlaku tepat sebelum hubungan dengan semua akses lain (atau menggunakan atom).
///
/// Untuk membantu reka bentuk yang betul, senario berikut dinyatakan secara eksplisit sah untuk kod single-thread:
///
/// 1. Rujukan `&T` dapat dilepaskan ke kod selamat dan di sana ia dapat wujud bersama dengan rujukan `&T` lain, tetapi tidak dengan `&mut T`
///
/// 2. Rujukan `&mut T` boleh dilepaskan ke kod selamat dengan syarat `&mut T` atau `&T` lain tidak wujud bersama dengannya.`&mut T` mestilah unik.
///
/// Perhatikan bahawa semasa mengubah isi kandungan `&UnsafeCell<T>` (walaupun rujukan `&UnsafeCell<T>` yang lain alias sel) adalah baik (dengan syarat anda menerapkan invarian di atas dengan cara lain), masih merupakan tingkah laku yang tidak ditentukan untuk mempunyai beberapa alias `&mut UnsafeCell<T>`.
/// Iaitu, `UnsafeCell` adalah pembungkus yang dirancang untuk mempunyai interaksi khas dengan _shared_ accesses (_i.e._, melalui rujukan `&UnsafeCell<_>`);tidak ada keajaiban sama sekali ketika berurusan dengan _exclusive_ accesses (_e.g._, melalui `&mut UnsafeCell<_>`): sel atau nilai yang dibungkus tidak boleh dilepaskan selama pinjaman `&mut` itu.
///
/// Ini dipamerkan oleh aksesori [`.get_mut()`], yang merupakan _safe_ getter yang menghasilkan `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Berikut adalah contoh yang menunjukkan cara mengubah isi `UnsafeCell<_>` dengan baik walaupun terdapat banyak rujukan yang mengasingkan sel:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Dapatkan rujukan berbilang/dikongsi untuk `x` yang sama.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // KESELAMATAN: dalam skop ini tidak ada rujukan lain untuk kandungan `x`,
///     // jadi milik kita unik.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- pinjam-+
///     *p1_exclusive += 27; // |
/// } // <---------- tidak boleh melampaui tahap ini -------------------+
///
/// unsafe {
///     // KESELAMATAN: dalam ruang lingkup ini tidak ada yang mengharapkan untuk memiliki akses eksklusif ke kandungan `x ',
///     // jadi kita boleh mempunyai pelbagai akses bersama secara serentak.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Contoh berikut menunjukkan fakta bahawa akses eksklusif ke `UnsafeCell<T>` menyiratkan akses eksklusif ke `T` nya:
///
/// ```rust
/// #![forbid(unsafe_code)] // dengan akses eksklusif,
///                         // `UnsafeCell` adalah pembungkus no-op yang telus, jadi tidak perlu `unsafe` di sini.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Dapatkan rujukan unik yang disemak masa kompilasi untuk `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Dengan rujukan eksklusif, kami dapat mengubah kandungan secara percuma.
/// *p_unique.get_mut() = 0;
/// // Atau, bersamaan:
/// x = UnsafeCell::new(0);
///
/// // Apabila kita memiliki nilainya, kita dapat mengekstrak kandungannya secara percuma.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Membina contoh `UnsafeCell` baru yang akan merangkumi nilai yang ditentukan.
    ///
    ///
    /// Semua akses ke nilai dalaman melalui kaedah adalah `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Membongkar nilai.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Mendapat penunjuk yang boleh berubah ke nilai yang dibungkus.
    ///
    /// Ini boleh digunakan untuk penunjuk apa sahaja.
    /// Pastikan aksesnya unik (tidak ada rujukan aktif, dapat diubah atau tidak) ketika menghantar ke `&mut T`, dan pastikan bahawa tidak ada mutasi atau alias yang dapat diubah semasa menghantar ke `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Kami hanya boleh menghantar penunjuk dari `UnsafeCell<T>` ke `T` kerana #[repr(transparent)].
        // Ini mengeksploitasi status istimewa libstd, tidak ada jaminan untuk kod pengguna bahawa ini akan berfungsi dalam versi penyusun future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Mengembalikan rujukan yang berubah-ubah ke data yang mendasari.
    ///
    /// Panggilan ini meminjam `UnsafeCell` secara bergantian (pada waktu kompilasi) yang menjamin bahawa kami mempunyai satu-satunya rujukan.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Mendapat penunjuk yang boleh berubah ke nilai yang dibungkus.
    /// Perbezaan [`get`] adalah bahawa fungsi ini menerima penunjuk mentah, yang berguna untuk mengelakkan penciptaan rujukan sementara.
    ///
    /// Hasilnya boleh diberikan kepada penunjuk apa sahaja.
    /// Pastikan aksesnya unik (tidak ada rujukan aktif, dapat diubah atau tidak) ketika menghantar ke `&mut T`, dan pastikan bahawa tidak ada mutasi atau alias yang dapat diubah semasa menghantar ke `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Inisialisasi `UnsafeCell` secara beransur-ansur memerlukan `raw_get`, kerana memanggil `get` memerlukan membuat rujukan ke data yang belum dimulakan:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Kami hanya boleh menghantar penunjuk dari `UnsafeCell<T>` ke `T` kerana #[repr(transparent)].
        // Ini mengeksploitasi status istimewa libstd, tidak ada jaminan untuk kod pengguna bahawa ini akan berfungsi dalam versi penyusun future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Membuat `UnsafeCell`, dengan nilai `Default` untuk T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}