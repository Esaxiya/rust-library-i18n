//! Modul untuk bekerja dengan data yang dipinjam.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait untuk meminjam data.
///
/// Dalam Rust, adalah perkara biasa untuk memberikan gambaran jenis yang berbeza untuk kes penggunaan yang berbeza.
/// Sebagai contoh, lokasi penyimpanan dan pengurusan untuk nilai dapat dipilih secara khusus sesuai untuk penggunaan tertentu melalui jenis penunjuk seperti [`Box<T>`] atau [`Rc<T>`].
/// Di luar pembungkus generik ini yang dapat digunakan dengan jenis apa pun, beberapa jenis menyediakan aspek pilihan yang memberikan fungsi yang berpotensi mahal.
/// Contoh untuk jenis seperti itu adalah [`String`] yang menambahkan kemampuan untuk memanjangkan tali ke [`str`] asas.
/// Ini memerlukan menyimpan maklumat tambahan yang tidak perlu untuk rentetan yang mudah berubah.
///
/// Jenis-jenis ini memberikan akses ke data yang mendasari melalui rujukan ke jenis data tersebut.Mereka dikatakan 'dipinjam sebagai' jenis itu.
/// Sebagai contoh, [`Box<T>`] boleh dipinjam sebagai `T` sementara [`String`] boleh dipinjam sebagai `str`.
///
/// Jenis menyatakan bahawa mereka boleh dipinjam sebagai beberapa jenis `T` dengan menerapkan `Borrow<T>`, memberikan rujukan pada `T` dalam kaedah [`borrow`] trait.Jenis bebas dipinjam kerana beberapa jenis.
/// Sekiranya ia ingin meminjam secara mutlak sebagai jenis-yang membolehkan data yang mendasarinya diubah, ia juga dapat menerapkan [`BorrowMut<T>`].
///
/// Selanjutnya, ketika memberikan implementasi untuk traits tambahan, perlu dipertimbangkan apakah mereka harus berperilaku sama dengan jenis yang mendasari sebagai akibat bertindak sebagai representasi dari jenis yang mendasari.
/// Kod generik biasanya menggunakan `Borrow<T>` apabila bergantung pada tingkah laku yang serupa dari pelaksanaan trait tambahan ini.
/// traits ini kemungkinan akan muncul sebagai trait bounds tambahan.
///
/// Khususnya `Eq`, `Ord` dan `Hash` mestilah setara dengan nilai yang dipinjam dan dimiliki: `x.borrow() == y.borrow()` harus memberikan hasil yang sama dengan `x == y`.
///
/// Sekiranya kod generik hanya perlu berfungsi untuk semua jenis yang dapat memberikan rujukan kepada jenis `T` yang berkaitan, selalunya lebih baik menggunakan [`AsRef<T>`] kerana lebih banyak jenis dapat menerapkannya dengan selamat.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Sebagai pengumpulan data, [`HashMap<K, V>`] memiliki kunci dan nilai.Sekiranya data sebenar kunci dibungkus dalam jenis pengelolaan semacam itu, bagaimanapun, masih boleh mencari nilai menggunakan rujukan ke data kunci.
/// Sebagai contoh, jika kuncinya adalah rentetan, maka kemungkinan disimpan dengan peta hash sebagai [`String`], sementara mungkin mencari dengan menggunakan [`&str`][`str`].
/// Oleh itu, `insert` perlu beroperasi pada `String` sementara `get` perlu dapat menggunakan `&str`.
///
/// Sedikit dipermudahkan, bahagian `HashMap<K, V>` yang berkaitan kelihatan seperti ini:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // bidang ditinggalkan
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Keseluruhan peta hash adalah generik berbanding jenis kunci `K`.Kerana kunci ini disimpan dengan peta hash, jenis ini harus memiliki data kunci.
/// Semasa memasukkan pasangan nilai-kunci, peta diberi `K` seperti itu dan perlu mencari baldi hash yang betul dan periksa apakah kuncinya sudah ada berdasarkan `K` itu.Oleh itu, ia memerlukan `K: Hash + Eq`.
///
/// Ketika mencari nilai dalam peta, bagaimanapun, harus memberikan rujukan ke `K` sebagai kunci untuk mencari memerlukan selalu membuat nilai yang dimiliki.
/// Untuk kekunci rentetan, ini bermaksud nilai `String` perlu dibuat hanya untuk mencari kes di mana hanya `str` yang tersedia.
///
/// Sebaliknya, kaedah `get` bersifat generik berbanding jenis data utama yang disebut, yang disebut `Q` dalam kaedah tandatangan di atas.Ia menyatakan bahawa `K` meminjam sebagai `Q` dengan mengharuskan `K: Borrow<Q>` itu.
/// Dengan tambahan memerlukan `Q: Hash + Eq`, ini menandakan syarat bahawa `K` dan `Q` memiliki implementasi `Hash` dan `Eq` traits yang menghasilkan hasil yang sama.
///
/// Pelaksanaan `get` bergantung pada pelaksanaan `Hash` yang serupa dengan menentukan hash bucket kunci dengan memanggil `Hash::hash` pada nilai `Q` walaupun ia memasukkan kunci berdasarkan nilai hash yang dikira dari nilai `K`.
///
///
/// Akibatnya, peta hash rosak jika `K` membungkus nilai `Q` menghasilkan hash yang berbeza daripada `Q`.Sebagai contoh, bayangkan anda mempunyai jenis yang membungkus rentetan tetapi membandingkan huruf ASCII dengan mengabaikan huruf kecilnya:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kerana dua nilai yang sama perlu menghasilkan nilai hash yang sama, pelaksanaan `Hash` juga perlu mengabaikan kes ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Bolehkah `CaseInsensitiveString` melaksanakan `Borrow<str>`?Ia pasti dapat memberikan rujukan pada potongan tali melalui tali yang dimiliki.
/// Tetapi kerana pelaksanaannya `Hash` berbeza, ia berperilaku berbeza dari `str` dan oleh itu tidak semestinya tidak melaksanakan `Borrow<str>`.
/// Sekiranya ingin membenarkan orang lain mengakses `str` yang mendasarinya, ia dapat melakukannya melalui `AsRef<str>` yang tidak memenuhi syarat tambahan.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Meminjam dengan tidak betul dari nilai yang dimiliki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait untuk saling meminjam data.
///
/// Sebagai pendamping kepada [`Borrow<T>`], trait ini membolehkan jenis meminjam sebagai jenis yang mendasari dengan memberikan rujukan yang boleh berubah.
/// Lihat [`Borrow<T>`] untuk maklumat lebih lanjut mengenai pinjaman sebagai jenis lain.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Meminjam secara bersama dari nilai yang dimiliki.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}