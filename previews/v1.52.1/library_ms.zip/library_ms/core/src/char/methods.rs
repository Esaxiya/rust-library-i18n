//! implan char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Titik kod sah tertinggi yang boleh dimiliki `char`.
    ///
    /// `char` adalah [Unicode Scalar Value], yang bermaksud bahawa ia adalah [Code Point], tetapi hanya yang berada dalam julat tertentu.
    /// `MAX` adalah titik kod paling tinggi yang sah iaitu [Unicode Scalar Value] yang sah.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () digunakan dalam Unicode untuk mewakili kesalahan penyahkodan.
    ///
    /// Ia boleh berlaku, sebagai contoh, ketika memberikan bytes UTF-8 yang tidak betul kepada [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Versi [Unicode](http://www.unicode.org/) yang digunakan oleh bahagian Unicode kaedah `char` dan `str`.
    ///
    /// Versi baru Unicode dikeluarkan secara berkala dan seterusnya semua kaedah di perpustakaan standard bergantung pada Unicode dikemas kini.
    /// Oleh itu tingkah laku beberapa kaedah `char` dan `str` dan nilai pemalar ini berubah dari semasa ke semasa.
    /// Ini *tidak* dianggap sebagai perubahan yang mematikan.
    ///
    /// Skema penomboran versi dijelaskan dalam [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Membuat iterator pada titik kod yang dikodkan UTF-16 di `iter`, mengembalikan pengganti yang tidak berpasangan sebagai `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Decoder lossy boleh didapati dengan mengganti hasil `Err` dengan watak pengganti:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Menukar `u32` ke `char`.
    ///
    /// Perhatikan bahawa semua `char`s sah [`u32`] s, dan boleh dihantar ke satu dengan
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Namun, kebalikannya tidak benar: tidak semua [u32`s yang sah adalah`char`s.
    /// `from_u32()` akan mengembalikan `None` jika input bukan nilai yang sah untuk `char`.
    ///
    /// Untuk versi fungsi ini yang tidak selamat yang mengabaikan pemeriksaan ini, lihat [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Mengembalikan `None` apabila input bukan `char` yang sah:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Menukar `u32` ke `char`, mengabaikan kesahan.
    ///
    /// Perhatikan bahawa semua `char`s sah [`u32`] s, dan boleh dihantar ke satu dengan
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Namun, kebalikannya tidak benar: tidak semua [u32`s yang sah adalah`char`s.
    /// `from_u32_unchecked()` akan mengabaikan perkara ini, dan membabi buta ke `char`, mungkin membuat yang tidak sah.
    ///
    ///
    /// # Safety
    ///
    /// Fungsi ini tidak selamat, kerana mungkin membina nilai `char` yang tidak sah.
    ///
    /// Untuk versi fungsi ini yang selamat, lihat fungsi [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // KESELAMATAN: kontrak keselamatan mesti dipegang oleh pemanggil.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Menukar digit dalam jejari yang diberi menjadi `char`.
    ///
    /// 'radix' di sini kadang-kadang disebut juga 'base'.
    /// Radix dua menunjukkan nombor binari, jari-jari sepuluh, perpuluhan, dan jari-jari enam belas, heksadesimal, untuk memberikan beberapa nilai sepunya.
    ///
    /// Radis sewenang-wenangnya disokong.
    ///
    /// `from_digit()` akan mengembalikan `None` jika inputnya bukan digit dalam radix yang diberikan.
    ///
    /// # Panics
    ///
    /// Panics jika diberi radix lebih besar daripada 36.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Perpuluhan 11 adalah satu digit dalam asas 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Mengembalikan `None` apabila input bukan digit:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Melewati jejari besar, menyebabkan panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Memeriksa apakah `char` adalah digit dalam radix yang diberikan.
    ///
    /// 'radix' di sini kadang-kadang disebut juga 'base'.
    /// Radix dua menunjukkan nombor binari, jari-jari sepuluh, perpuluhan, dan jari-jari enam belas, heksadesimal, untuk memberikan beberapa nilai sepunya.
    ///
    /// Radis sewenang-wenangnya disokong.
    ///
    /// Berbanding dengan [`is_numeric()`], fungsi ini hanya mengenali watak `0-9`, `a-z` dan `A-Z`.
    ///
    /// 'Digit' didefinisikan sebagai watak-watak berikut:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Untuk pemahaman 'digit' yang lebih komprehensif, lihat [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics jika diberi radix lebih besar daripada 36.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Melewati jejari besar, menyebabkan panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Menukar `char` menjadi digit dalam radix yang diberikan.
    ///
    /// 'radix' di sini kadang-kadang disebut juga 'base'.
    /// Radix dua menunjukkan nombor binari, jari-jari sepuluh, perpuluhan, dan jari-jari enam belas, heksadesimal, untuk memberikan beberapa nilai sepunya.
    ///
    /// Radis sewenang-wenangnya disokong.
    ///
    /// 'Digit' didefinisikan sebagai watak-watak berikut:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Mengembalikan `None` jika `char` tidak merujuk kepada digit dalam radix yang diberikan.
    ///
    /// # Panics
    ///
    /// Panics jika diberi radix lebih besar daripada 36.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Lulus keputusan bukan digit akan gagal:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Melewati jejari besar, menyebabkan panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kod dibahagi-bahagikan di sini untuk meningkatkan kelajuan pelaksanaan bagi kes di mana `radix` tetap dan 10 atau lebih kecil
        //
        let val = if likely(radix <= 10) {
            // Sekiranya bukan digit, nombor yang lebih besar daripada radix akan dibuat.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Mengembalikan iterator yang menghasilkan pelarian Unicode heksadesimal watak sebagai `char`s.
    ///
    /// Ini akan melarikan watak dengan sintaks Rust bentuk `\u{NNNNNN}` di mana `NNNNNN` adalah perwakilan heksadesimal.
    ///
    ///
    /// # Examples
    ///
    /// Sebagai iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Menggunakan `println!` secara langsung:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Kedua-duanya setara dengan:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Menggunakan `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // atau-ing 1 memastikan bahawa untuk c==0 kod mengira satu digit harus dicetak dan (yang sama) mengelakkan (31, 32) aliran masuk
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indeks bagi digit hex yang paling ketara
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Versi lanjutan `escape_debug` yang secara opsional membenarkan pelepasan titik kod Extended Grapheme.
    /// Ini membolehkan kita memformat watak seperti tanda jarak jauh dengan lebih baik ketika mereka berada di awal rentetan.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Mengembalikan iterator yang menghasilkan kod pelarian literal watak sebagai `char`s.
    ///
    /// Ini akan melarikan diri daripada watak-watak yang serupa dengan pelaksanaan `Debug` `str` atau `char`.
    ///
    ///
    /// # Examples
    ///
    /// Sebagai iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Menggunakan `println!` secara langsung:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Kedua-duanya setara dengan:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Menggunakan `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Mengembalikan iterator yang menghasilkan kod pelarian literal watak sebagai `char`s.
    ///
    /// Lalai dipilih dengan bias untuk menghasilkan literal yang sah dalam pelbagai bahasa, termasuk C++ 11 dan bahasa keluarga C yang serupa.
    /// Peraturan yang tepat adalah:
    ///
    /// * Tab dilarikan sebagai `\t`.
    /// * Pengembalian kereta dilarikan sebagai `\r`.
    /// * Umpan baris dilarikan sebagai `\n`.
    /// * Petikan tunggal dilarikan sebagai `\'`.
    /// * Petikan berganda dilarikan sebagai `\"`.
    /// * Backslash dilarikan sebagai `\\`.
    /// * Mana-mana watak dalam julat 'ASCII yang boleh dicetak' `0x20` .. Termasuk `0x7e` tidak boleh dilarikan.
    /// * Semua watak lain diberi pelarian Unicode heksadesimal;lihat [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Sebagai iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Menggunakan `println!` secara langsung:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Kedua-duanya setara dengan:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Menggunakan `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Mengembalikan bilangan byte yang diperlukan oleh `char` ini jika dikodkan dalam UTF-8.
    ///
    /// Jumlah bait itu selalu antara 1 dan 4, termasuk.
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Jenis `&str` menjamin bahawa kandungannya adalah UTF-8, dan jadi kami dapat membandingkan panjangnya jika setiap titik kod ditunjukkan sebagai `char` vs di `&str` itu sendiri:
    ///
    ///
    /// ```
    /// // sebagai watak
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // kedua-duanya boleh dinyatakan sebagai tiga bait
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // sebagai &str, kedua-duanya dikodkan dalam UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // kita dapat melihat bahawa mereka mengambil total enam bait ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... sama seperti &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Mengembalikan bilangan unit kod 16-bit yang `char` perlukan jika dikodkan dalam UTF-16.
    ///
    ///
    /// Lihat dokumentasi untuk [`len_utf8()`] untuk penjelasan lebih lanjut mengenai konsep ini.
    /// Fungsi ini adalah cermin, tetapi untuk UTF-16 dan bukannya UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Mengekodkan watak ini sebagai UTF-8 ke dalam buffer byte yang disediakan, dan kemudian mengembalikan subslice buffer yang mengandungi watak yang dikodkan.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika penyangga tidak cukup besar.
    /// Penyangga panjang empat cukup besar untuk mengekod `char` mana pun.
    ///
    /// # Examples
    ///
    /// Dalam kedua-dua contoh ini, 'ß' memerlukan dua bait untuk dikodkan.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Penyangga yang terlalu kecil:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // KESELAMATAN: `char` bukan pengganti, jadi ini sah UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Mengekodkan watak ini sebagai UTF-16 ke dalam buffer `u16` yang disediakan, dan kemudian mengembalikan subslice buffer yang mengandungi watak yang dikodkan.
    ///
    ///
    /// # Panics
    ///
    /// Panics jika penyangga tidak cukup besar.
    /// Penyangga panjang 2 cukup besar untuk mengekod `char` mana pun.
    ///
    /// # Examples
    ///
    /// Dalam kedua-dua contoh ini, '𝕊' memerlukan dua `u16 untuk dikodkan.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Penyangga yang terlalu kecil:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Mengembalikan `true` jika `char` ini mempunyai harta `Alphabetic`.
    ///
    /// `Alphabetic` dijelaskan dalam Bab 4 (Sifat Karakter) [Unicode Standard] dan dinyatakan dalam [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // cinta adalah banyak perkara, tetapi tidak mengikut abjad
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Mengembalikan `true` jika `char` ini mempunyai harta `Lowercase`.
    ///
    /// `Lowercase` dijelaskan dalam Bab 4 (Sifat Karakter) [Unicode Standard] dan dinyatakan dalam [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Pelbagai skrip dan tanda baca bahasa Cina tidak sesuai, dan demikian:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Mengembalikan `true` jika `char` ini mempunyai harta `Uppercase`.
    ///
    /// `Uppercase` dijelaskan dalam Bab 4 (Sifat Karakter) [Unicode Standard] dan dinyatakan dalam [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Pelbagai skrip dan tanda baca bahasa Cina tidak sesuai, dan demikian:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Mengembalikan `true` jika `char` ini mempunyai harta `White_Space`.
    ///
    /// `White_Space` dinyatakan dalam [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ruang yang tidak pecah
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Mengembalikan `true` jika `char` ini memenuhi [`is_alphabetic()`] atau [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Mengembalikan `true` jika `char` ini mempunyai kategori umum untuk kod kawalan.
    ///
    /// Kod kawalan (titik kod dengan kategori umum `Cc`) dijelaskan dalam Bab 4 (Sifat Karakter) [Unicode Standard] dan ditentukan dalam [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Mengembalikan `true` jika `char` ini mempunyai harta `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` dijelaskan dalam [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] dan dinyatakan dalam [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Mengembalikan `true` jika `char` ini mempunyai salah satu kategori umum untuk nombor.
    ///
    /// Kategori umum untuk nombor (`Nd` untuk digit perpuluhan, `Nl` untuk aksara angka seperti huruf, dan `No` untuk aksara angka lain) ditentukan dalam [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Penggunaan asas:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Mengembalikan iterator yang menghasilkan pemetaan huruf kecil `char` ini sebagai satu atau lebih
    /// `char`s.
    ///
    /// Sekiranya `char` ini tidak mempunyai pemetaan huruf kecil, iterator menghasilkan `char` yang sama.
    ///
    /// Sekiranya `char` ini memiliki pemetaan huruf kecil satu-ke-satu yang diberikan oleh [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator menghasilkan `char` tersebut.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Sekiranya `char` ini memerlukan pertimbangan khas (misalnya beberapa `char`s) iterator menghasilkan`char` (s) yang diberikan oleh [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasi ini melakukan pemetaan tanpa syarat tanpa menyesuaikan.Maksudnya, penukaran itu bebas dari konteks dan bahasa.
    ///
    /// Dalam [Unicode Standard], Bab 4 (Character Properties) membincangkan pemetaan kes secara umum dan Bab 3 (Conformance) membincangkan algoritma lalai untuk penukaran kes.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Sebagai iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Menggunakan `println!` secara langsung:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Kedua-duanya setara dengan:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Menggunakan `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Kadang-kadang hasilnya lebih daripada satu watak:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Watak yang tidak mempunyai huruf besar dan huruf kecil berubah menjadi diri mereka sendiri.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Mengembalikan iterator yang menghasilkan pemetaan huruf besar `char` ini sebagai satu atau lebih
    /// `char`s.
    ///
    /// Sekiranya `char` ini tidak mempunyai pemetaan huruf besar, iterator menghasilkan `char` yang sama.
    ///
    /// Sekiranya `char` ini mempunyai pemetaan huruf besar satu-ke-satu yang diberikan oleh [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator menghasilkan `char` tersebut.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Sekiranya `char` ini memerlukan pertimbangan khas (misalnya beberapa `char`s) iterator menghasilkan`char` (s) yang diberikan oleh [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Operasi ini melakukan pemetaan tanpa syarat tanpa menyesuaikan.Maksudnya, penukaran itu bebas dari konteks dan bahasa.
    ///
    /// Dalam [Unicode Standard], Bab 4 (Character Properties) membincangkan pemetaan kes secara umum dan Bab 3 (Conformance) membincangkan algoritma lalai untuk penukaran kes.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Sebagai iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Menggunakan `println!` secara langsung:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Kedua-duanya setara dengan:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Menggunakan `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Kadang-kadang hasilnya lebih daripada satu watak:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Watak yang tidak mempunyai huruf besar dan huruf kecil berubah menjadi diri mereka sendiri.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Catatan mengenai tempat
    ///
    /// Dalam bahasa Turki, 'i' yang setara dalam bahasa Latin mempunyai lima bentuk dan bukan dua:
    ///
    /// * 'Dotless': Saya/ı, kadangkala ditulis ï
    /// * 'Dotted': İ/i
    ///
    /// Perhatikan bahawa huruf kecil 'i' bertitik sama dengan bahasa Latin.Oleh itu:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Nilai `upper_i` di sini bergantung pada bahasa teks: jika kita berada di `en-US`, seharusnya `"I"`, tetapi jika kita berada di `tr_TR`, ia harus `"İ"`.
    /// `to_uppercase()` tidak mengambil kira perkara ini, dan demikian:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// merangkumi pelbagai bahasa.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Memeriksa apakah nilainya berada dalam julat ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Membuat salinan nilai dalam huruf besar ASCII yang setara.
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk huruf besar nilai di tempat, gunakan [`make_ascii_uppercase()`].
    ///
    /// Untuk huruf besar ASCII selain watak bukan ASCII, gunakan [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Membuat salinan nilai yang setara dengan huruf kecil ASCII.
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengecilkan nilai di tempat, gunakan [`make_ascii_lowercase()`].
    ///
    /// Untuk huruf kecil ASCII selain watak bukan ASCII, gunakan [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Memeriksa bahawa dua nilai adalah padanan peka huruf ASCII.
    ///
    /// Setaraf dengan `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Menukar jenis ini kepada huruf besar ASCII yang setara di tempatnya.
    ///
    /// Huruf ASCII 'a' hingga 'z' dipetakan ke 'A' hingga 'Z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf besar baru tanpa mengubah nilai yang ada, gunakan [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Menukar jenis ini kepada huruf kecil ASCII yang setara di tempat.
    ///
    /// Huruf ASCII 'A' hingga 'Z' dipetakan ke 'a' hingga 'z', tetapi huruf bukan ASCII tidak berubah.
    ///
    /// Untuk mengembalikan nilai huruf kecil yang baru tanpa mengubah nilai yang ada, gunakan [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Memeriksa sama ada nilainya adalah watak abjad ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', atau
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Memeriksa apakah nilainya adalah huruf besar ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Memeriksa sama ada nilainya adalah huruf kecil ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Memeriksa sama ada nilainya adalah watak alfanumerik ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', atau
    /// - U + 0061 'a' ..=U + 007A 'z', atau
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Memeriksa apakah nilainya adalah digit perpuluhan ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Memeriksa apakah nilainya adalah digit heksadesimal ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', atau
    /// - U + 0041 'A' ..=U + 0046 'F', atau
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Memeriksa jika nilainya adalah watak tanda baca ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, atau
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, atau
    /// - U + 005B ..=U + 0060 "[\] ^ _` ``, atau
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Memeriksa apakah nilainya adalah watak grafik ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Memeriksa sama ada nilainya adalah watak ruang kosong ASCII:
    /// U + 0020 RUANG, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, atau U + 000D CARRIAGE RETURN.
    ///
    /// Rust menggunakan XWX WhatWG Infra Standard.Terdapat beberapa definisi lain dalam penggunaan yang luas.
    /// Sebagai contoh, [the POSIX locale][pct] termasuk U + 000B VERTICAL TAB serta semua watak di atas, tetapi - dari spesifikasi yang sama- [peraturan lalai untuk "field splitting" di Bourne shell][bfs] menganggap *hanya* SPACE, HORIZONTAL TAB, dan MAKANAN LINE sebagai ruang kosong.
    ///
    ///
    /// Sekiranya anda menulis program yang akan memproses format fail yang ada, periksa apakah definisi format ruang kosong sebelum menggunakan fungsi ini.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Memeriksa sama ada nilainya adalah watak kawalan ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, atau U + 007F HAPUS.
    /// Perhatikan bahawa kebanyakan watak ruang kosong ASCII adalah watak kawalan, tetapi SPACE tidak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Mengekodkan nilai u32 mentah sebagai UTF-8 ke dalam buffer byte yang disediakan, dan kemudian mengembalikan subslice buffer yang mengandungi watak yang dikodkan.
///
///
/// Tidak seperti `char::encode_utf8`, kaedah ini juga menangani titik titik dalam julat pengganti.
/// (Membuat `char` dalam rentang pengganti adalah UB.) Hasilnya adalah sah [generalized UTF-8] tetapi tidak sah UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics jika penyangga tidak cukup besar.
/// Penyangga panjang empat cukup besar untuk mengekod `char` mana pun.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Mengekodkan nilai u32 mentah sebagai UTF-16 ke dalam buffer `u16` yang disediakan, dan kemudian mengembalikan subslice buffer yang mengandungi watak yang dikodkan.
///
///
/// Tidak seperti `char::encode_utf16`, kaedah ini juga menangani titik titik dalam julat pengganti.
/// (Membuat `char` dalam julat pengganti adalah UB.)
///
/// # Panics
///
/// Panics jika penyangga tidak cukup besar.
/// Penyangga panjang 2 cukup besar untuk mengekod `char` mana pun.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // KESELAMATAN: setiap lengan memeriksa sama ada terdapat cukup bit untuk ditulis
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP jatuh melalui
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Pesawat tambahan menjadi pengganti.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}