#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Dikembangkan ke `$crate::panic::panic_2015` atau `$crate::panic::panic_2021` bergantung pada edisi pemanggil.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Menegaskan bahawa dua ungkapan sama antara satu sama lain (menggunakan [`PartialEq`]).
///
/// Pada panic, makro ini akan mencetak nilai ungkapan dengan perwakilan debug mereka.
///
///
/// Seperti [`assert!`], makro ini mempunyai bentuk kedua, di mana mesej panic khusus dapat diberikan.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Rebore di bawah adalah disengajakan.
                    // Tanpa mereka, slot timbunan untuk pinjaman dimulakan bahkan sebelum nilai dibandingkan, menyebabkan penurunan ketara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Rebore di bawah adalah disengajakan.
                    // Tanpa mereka, slot timbunan untuk pinjaman dimulakan bahkan sebelum nilai dibandingkan, menyebabkan penurunan ketara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Menegaskan bahawa dua ungkapan tidak sama antara satu sama lain (menggunakan [`PartialEq`]).
///
/// Pada panic, makro ini akan mencetak nilai ungkapan dengan perwakilan debug mereka.
///
///
/// Seperti [`assert!`], makro ini mempunyai bentuk kedua, di mana mesej panic khusus dapat diberikan.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Rebore di bawah adalah disengajakan.
                    // Tanpa mereka, slot timbunan untuk pinjaman dimulakan bahkan sebelum nilai dibandingkan, menyebabkan penurunan ketara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Rebore di bawah adalah disengajakan.
                    // Tanpa mereka, slot timbunan untuk pinjaman dimulakan bahkan sebelum nilai dibandingkan, menyebabkan penurunan ketara.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Menegaskan bahawa ungkapan boolean adalah `true` pada waktu runtime.
///
/// Ini akan memanggil makro [`panic!`] jika ungkapan yang diberikan tidak dapat dinilai ke `true` pada waktu runtime.
///
/// Seperti [`assert!`], makro ini juga mempunyai versi kedua, di mana mesej panic tersuai dapat diberikan.
///
/// # Uses
///
/// Tidak seperti [`assert!`], pernyataan `debug_assert!` hanya diaktifkan dalam binaan yang tidak dioptimumkan secara lalai.
/// Binaan yang dioptimumkan tidak akan melaksanakan pernyataan `debug_assert!` melainkan `-C debug-assertions` diserahkan ke penyusun.
/// Ini menjadikan `debug_assert!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam rilis tetapi mungkin berguna semasa pembangunan.
/// Hasil pengembangan `debug_assert!` selalu diperiksa jenisnya.
///
/// Penegasan yang tidak diperiksa membolehkan program dalam keadaan tidak konsisten terus berjalan, yang mungkin mempunyai akibat yang tidak dijangka tetapi tidak memperkenalkan ketidakamanan selagi ini hanya berlaku dalam kod selamat.
///
/// Walau bagaimanapun, kos penegasan prestasi tidak dapat diukur secara umum.
/// Mengganti [`assert!`] dengan `debug_assert!` hanya digalakkan setelah membuat profil yang mendalam, dan yang lebih penting, hanya dalam kod yang selamat!
///
/// # Examples
///
/// ```
/// // mesej panic untuk penegasan ini adalah nilai tegas bagi ungkapan yang diberikan.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // fungsi yang sangat sederhana
/// debug_assert!(some_expensive_computation());
///
/// // tegaskan dengan mesej tersuai
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Menegaskan bahawa dua ungkapan sama antara satu sama lain.
///
/// Pada panic, makro ini akan mencetak nilai ungkapan dengan perwakilan debug mereka.
///
/// Tidak seperti [`assert_eq!`], pernyataan `debug_assert_eq!` hanya diaktifkan dalam binaan yang tidak dioptimumkan secara lalai.
/// Binaan yang dioptimumkan tidak akan melaksanakan pernyataan `debug_assert_eq!` melainkan `-C debug-assertions` diserahkan ke penyusun.
/// Ini menjadikan `debug_assert_eq!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam rilis tetapi mungkin berguna semasa pembangunan.
///
/// Hasil pengembangan `debug_assert_eq!` selalu diperiksa jenisnya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Menegaskan bahawa dua ungkapan tidak sama antara satu sama lain.
///
/// Pada panic, makro ini akan mencetak nilai ungkapan dengan perwakilan debug mereka.
///
/// Tidak seperti [`assert_ne!`], pernyataan `debug_assert_ne!` hanya diaktifkan dalam binaan yang tidak dioptimumkan secara lalai.
/// Binaan yang dioptimumkan tidak akan melaksanakan pernyataan `debug_assert_ne!` melainkan `-C debug-assertions` diserahkan ke penyusun.
/// Ini menjadikan `debug_assert_ne!` berguna untuk pemeriksaan yang terlalu mahal untuk hadir dalam rilis tetapi mungkin berguna semasa pembangunan.
///
/// Hasil pengembangan `debug_assert_ne!` selalu diperiksa jenisnya.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Mengembalikan sama ada ungkapan yang diberikan sesuai dengan mana-mana corak yang diberikan.
///
/// Seperti dalam ekspresi `match`, corak boleh diikuti oleh `if` dan ekspresi penjaga yang mempunyai akses ke nama yang terikat dengan corak.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Membatalkan hasil atau menyebarkan kesilapannya.
///
/// Operator `?` ditambahkan untuk menggantikan `try!` dan harus digunakan sebagai gantinya.
/// Tambahan pula, `try` adalah kata terpelihara di Rust 2018, jadi jika anda mesti menggunakannya, anda perlu menggunakan [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` sepadan dengan [`Result`] yang diberikan.Sekiranya varian `Ok`, ekspresi mempunyai nilai nilai terbungkus.
///
/// Sekiranya terdapat varian `Err`, ia akan mendapatkan kesalahan dalaman.`try!` kemudian melakukan penukaran menggunakan `From`.
/// Ini memberikan penukaran automatik antara kesalahan khusus dan yang lebih umum.
/// Kesalahan yang dihasilkan kemudian dikembalikan dengan segera.
///
/// Kerana pengembalian awal, `try!` hanya dapat digunakan dalam fungsi yang mengembalikan [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Kaedah pilihan Kesalahan mengembalikan cepat
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Kaedah sebelumnya Kesalahan mengembalikan cepat
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ini bersamaan dengan:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Menulis data yang diformat menjadi penyangga.
///
/// Makro ini menerima 'writer', rentetan format, dan senarai argumen.
/// Hujah akan diformat mengikut rentetan format yang ditentukan dan hasilnya akan disampaikan kepada penulis.
/// Penulis mungkin mempunyai nilai apa pun dengan kaedah `write_fmt`;secara amnya ini datang dari pelaksanaan [`fmt::Write`] atau [`io::Write`] trait.
/// Makro mengembalikan apa sahaja kaedah `write_fmt` yang dikembalikan;biasanya [`fmt::Result`], atau [`io::Result`].
///
/// Lihat [`std::fmt`] untuk maklumat lebih lanjut mengenai sintaks rentetan format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modul boleh mengimport kedua `std::fmt::Write` dan `std::io::Write` dan memanggil `write!` pada objek yang melaksanakannya, kerana objek biasanya tidak melaksanakan kedua-duanya.
///
/// Walau bagaimanapun, modul mesti mengimport traits yang berkelayakan agar nama mereka tidak bertentangan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // menggunakan fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // menggunakan io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Makro ini boleh digunakan dalam penyediaan `no_std` juga.
/// Dalam penyediaan `no_std`, anda bertanggungjawab untuk perincian pelaksanaan komponen.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Tulis data yang diformat ke dalam penyangga, dengan baris baru yang dilampirkan.
///
/// Di semua platform, barisan baru adalah watak LINE FEED (`\n`/`U+000A`) sahaja (tidak ada CARRIAGE RETURN (`\r`/`U+000D`) tambahan.
///
/// Untuk maklumat lebih lanjut, lihat [`write!`].Untuk maklumat mengenai sintaks rentetan format, lihat [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modul boleh mengimport kedua `std::fmt::Write` dan `std::io::Write` dan memanggil `write!` pada objek yang melaksanakannya, kerana objek biasanya tidak melaksanakan kedua-duanya.
/// Walau bagaimanapun, modul mesti mengimport traits yang berkelayakan agar nama mereka tidak bertentangan:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // menggunakan fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // menggunakan io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Menunjukkan kod yang tidak dapat dicapai.
///
/// Ini berguna bila-bila masa penyusun tidak dapat menentukan bahawa beberapa kod tidak dapat dicapai.Sebagai contoh:
///
/// * Padankan lengan dengan keadaan pengawal.
/// * Gelung yang ditamatkan secara dinamik.
/// * Iterator yang menamatkan secara dinamik.
///
/// Sekiranya penentuan bahawa kod yang tidak dapat dicapai terbukti tidak betul, program ini akan segera berakhir dengan [`panic!`].
///
/// Rakan makro yang tidak selamat ini adalah fungsi [`unreachable_unchecked`], yang akan menyebabkan tingkah laku tidak ditentukan sekiranya kod tersebut tercapai.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ini akan sentiasa [`panic!`].
///
/// # Examples
///
/// Padankan lengan:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // menyusun ralat jika dikomen
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // salah satu pelaksanaan x/3 paling miskin
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Menunjukkan kod yang tidak dilaksanakan dengan panik dengan mesej "not implemented".
///
/// Ini membolehkan kod anda memeriksa-ketik, yang berguna jika anda membuat prototaip atau melaksanakan trait yang memerlukan beberapa kaedah yang anda tidak merancang untuk menggunakan semua.
///
/// Perbezaan antara `unimplemented!` dan [`todo!`] adalah bahawa sementara `todo!` menyampaikan maksud untuk melaksanakan fungsi tersebut kemudian dan mesejnya adalah "not yet implemented", `unimplemented!` tidak membuat tuntutan seperti itu.
/// Mesejnya adalah "not implemented".
/// Juga beberapa IDE akan menandakan `todo!` S.
///
/// # Panics
///
/// Ini akan selalu [`panic!`] kerana `unimplemented!` hanyalah singkatan untuk `panic!` dengan mesej tertentu yang tetap.
///
/// Seperti `panic!`, makro ini mempunyai bentuk kedua untuk memaparkan nilai tersuai.
///
/// # Examples
///
/// Katakan kita mempunyai trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Kami mahu menerapkan `Foo` untuk 'MyStruct', tetapi untuk beberapa sebab, hanya masuk akal untuk melaksanakan fungsi `bar()`.
/// `baz()` dan `qux()` masih perlu ditentukan dalam pelaksanaan `Foo` kami, tetapi kami dapat menggunakan `unimplemented!` dalam definisi mereka untuk membolehkan kod kami menyusun.
///
/// Kami masih mahu program kami berhenti berjalan sekiranya kaedah yang tidak dilaksanakan tercapai.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Tidak masuk akal untuk `baz` `MyStruct`, jadi kami sama sekali tidak mempunyai logik.
/////
///         // Ini akan memaparkan "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Kami mempunyai beberapa logik di sini, Kami dapat menambahkan mesej untuk tidak dilaksanakan!untuk menunjukkan peninggalan kami.
///         // Ini akan memaparkan: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Menunjukkan kod yang belum selesai.
///
/// Ini berguna jika anda membuat prototaip dan hanya ingin memeriksa jenis kod anda.
///
/// Perbezaan antara [`unimplemented!`] dan `todo!` adalah bahawa sementara `todo!` menyampaikan maksud untuk melaksanakan fungsi tersebut kemudian dan mesejnya adalah "not yet implemented", `unimplemented!` tidak membuat tuntutan seperti itu.
/// Mesejnya adalah "not implemented".
/// Juga beberapa IDE akan menandakan `todo!` S.
///
/// # Panics
///
/// Ini akan sentiasa [`panic!`].
///
/// # Examples
///
/// Berikut adalah contoh beberapa kod dalam proses.Kami mempunyai trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Kami mahu menerapkan `Foo` pada salah satu jenis kami, tetapi kami juga mahu mengusahakan `bar()` terlebih dahulu.Agar kod kita dapat dikompilasi, kita perlu menerapkan `baz()`, sehingga kita dapat menggunakan `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // pelaksanaan berjalan di sini
///     }
///
///     fn baz(&self) {
///         // jangan bimbang untuk melaksanakan baz() buat masa ini
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // kita bahkan tidak menggunakan baz(), jadi ini baik-baik saja.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definisi makro terbina dalam.
///
/// Sebilangan besar sifat makro (kestabilan, keterlihatan, dll.) Diambil dari kod sumber di sini, kecuali fungsi pengembangan yang mengubah input makro menjadi output, fungsi tersebut disediakan oleh penyusun.
///
///
pub(crate) mod builtin {

    /// Menyebabkan penyusunan gagal dengan mesej ralat yang diberikan ketika ditemui.
    ///
    /// Makro ini harus digunakan apabila crate menggunakan strategi penyusunan bersyarat untuk memberikan mesej ralat yang lebih baik untuk keadaan yang salah.
    ///
    /// Ini adalah bentuk tahap penyusun [`panic!`], tetapi memancarkan ralat semasa *penyusunan* dan bukan pada *runtime*.
    ///
    /// # Examples
    ///
    /// Dua contoh tersebut ialah persekitaran makro dan `#[cfg]`.
    ///
    /// Pancarkan ralat penyusun yang lebih baik jika makro diluluskan nilai yang tidak sah.
    /// Tanpa branch terakhir, pengkompil tetap akan mengeluarkan ralat, tetapi mesej ralat tidak akan menyebut dua nilai yang sah.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Pancarkan ralat penyusun jika salah satu daripada sebilangan ciri tidak tersedia.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Membina parameter untuk makro pemformatan rentetan yang lain.
    ///
    /// Makro ini berfungsi dengan mengambil literal string pemformatan yang mengandungi `{}` untuk setiap argumen tambahan yang dilalui.
    /// `format_args!` menyediakan parameter tambahan untuk memastikan output dapat ditafsirkan sebagai rentetan dan mensonalisasikan argumen menjadi satu jenis.
    /// Apa-apa nilai yang menerapkan [`Display`] trait dapat diteruskan ke `format_args!`, begitu juga pelaksanaan [`Debug`] yang diteruskan ke `{:?}` dalam rentetan pemformatan.
    ///
    ///
    /// Makro ini menghasilkan nilai jenis [`fmt::Arguments`].Nilai ini dapat diteruskan ke makro dalam [`std::fmt`] untuk melakukan pengalihan berguna.
    /// Semua makro pemformatan lain ([`format!`], [`write!`], [`println!`], dll) diproksi melalui yang satu ini.
    /// `format_args!`, tidak seperti makro yang dihasilkan, mengelakkan peruntukan timbunan.
    ///
    /// Anda boleh menggunakan nilai [`fmt::Arguments`] yang dikembalikan oleh `format_args!` dalam konteks `Debug` dan `Display` seperti yang dilihat di bawah.
    /// Contohnya juga menunjukkan bahawa format `Debug` dan `Display` mempunyai perkara yang sama: rentetan format yang diinterpolasi di `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Untuk maklumat lebih lanjut, lihat dokumentasi di [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama seperti `format_args`, tetapi menambah barisan baru pada akhirnya.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Memeriksa pemboleh ubah persekitaran pada masa kompilasi.
    ///
    /// Makro ini akan berkembang menjadi nilai pemboleh ubah persekitaran yang dinamakan pada waktu kompilasi, menghasilkan ungkapan jenis `&'static str`.
    ///
    ///
    /// Sekiranya pemboleh ubah persekitaran tidak ditentukan, maka kesalahan kompilasi akan dikeluarkan.
    /// Untuk tidak mengeluarkan ralat kompilasi, gunakan makro [`option_env!`] sebagai gantinya.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Anda dapat menyesuaikan pesan ralat dengan meneruskan rentetan sebagai parameter kedua:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Sekiranya pemboleh ubah persekitaran `documentation` tidak ditentukan, anda akan mendapat ralat berikut:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Secara pilihan memeriksa pemboleh ubah persekitaran pada waktu kompilasi.
    ///
    /// Sekiranya pemboleh ubah persekitaran bernama hadir pada waktu kompilasi, ini akan berkembang menjadi ungkapan jenis `Option<&'static str>` yang nilainya adalah `Some` dari nilai pemboleh ubah persekitaran.
    /// Sekiranya pemboleh ubah persekitaran tidak ada, maka ini akan berkembang menjadi `None`.
    /// Lihat [`Option<T>`][Option] untuk maklumat lebih lanjut mengenai jenis ini.
    ///
    /// Kesalahan masa kompilasi tidak pernah dipancarkan ketika menggunakan makro ini tanpa mengira sama ada pemboleh ubah persekitaran ada atau tidak.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gabungkan pengenal menjadi satu pengecam.
    ///
    /// Makro ini menggunakan sebilangan besar pengecam yang dipisahkan koma, dan menggabungkan semuanya menjadi satu, menghasilkan ungkapan yang merupakan pengecam baru.
    /// Perhatikan bahawa kebersihan menjadikan makro ini tidak dapat menangkap pemboleh ubah tempatan.
    /// Juga, sebagai peraturan umum, makro hanya dibenarkan dalam kedudukan item, pernyataan atau ekspresi.
    /// Itu bermaksud semasa anda menggunakan makro ini untuk merujuk kepada pemboleh ubah, fungsi atau modul yang ada dan lain-lain, anda tidak dapat menentukan yang baru dengannya.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (baru, seronok, nama) { }//tidak boleh digunakan dengan cara ini!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Gabungkan literal menjadi irisan rentetan statik.
    ///
    /// Makro ini mengambil sebilangan literal yang dipisahkan koma, menghasilkan ungkapan jenis `&'static str` yang mewakili semua literal yang digabungkan dari kiri ke kanan.
    ///
    ///
    /// Literal titik integer dan terapung dikelompokkan untuk digabungkan.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Memperluas ke nombor baris yang digunakan.
    ///
    /// Dengan [`column!`] dan [`file!`], makro ini memberikan maklumat penyahpepijatan untuk pembangun mengenai lokasi dalam sumbernya.
    ///
    /// Ekspresi yang diperluas mempunyai jenis `u32` dan berdasarkan 1, jadi baris pertama dalam setiap fail dinilai menjadi 1, yang kedua hingga 2, dll.
    /// Ini sesuai dengan mesej ralat oleh penyusun biasa atau penyunting popular.
    /// Garis yang dikembalikan adalah *tidak semestinya* garis pemanggilan `line!` itu sendiri, melainkan pemanggilan makro pertama yang mengarah ke pemanggilan makro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Memperluas ke nombor lajur yang digunakan.
    ///
    /// Dengan [`line!`] dan [`file!`], makro ini memberikan maklumat penyahpepijatan untuk pembangun mengenai lokasi dalam sumbernya.
    ///
    /// Ungkapan yang diperluas mempunyai jenis `u32` dan berdasarkan 1, jadi lajur pertama di setiap baris dinilai menjadi 1, yang kedua hingga 2, dll.
    /// Ini sesuai dengan mesej ralat oleh penyusun biasa atau penyunting popular.
    /// Lajur yang dikembalikan adalah *tidak semestinya* garis pemanggilan `column!` itu sendiri, melainkan pemanggilan makro pertama yang mengarah ke pemanggilan makro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Memperluas ke nama fail di mana ia dipanggil.
    ///
    /// Dengan [`line!`] dan [`column!`], makro ini memberikan maklumat penyahpepijatan untuk pembangun mengenai lokasi dalam sumbernya.
    ///
    /// Ekspresi yang diperluas mempunyai jenis `&'static str`, dan fail yang dikembalikan bukan pemanggilan makro `file!` itu sendiri, melainkan permintaan makro pertama yang mengarah pada pemanggilan makro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Mengetatkan hujahnya.
    ///
    /// Makro ini akan menghasilkan ungkapan jenis `&'static str` yang merupakan penegasan semua tokens yang diteruskan ke makro.
    /// Tidak ada sekatan yang diletakkan pada sintaks pemanggilan makro itu sendiri.
    ///
    /// Perhatikan bahawa hasil input tokens yang diperluas boleh berubah pada future.Anda harus berhati-hati jika bergantung pada output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Termasuk fail yang dikodkan UTF-8 sebagai rentetan.
    ///
    /// Fail terletak relatif dengan fail semasa (sama dengan bagaimana modul dijumpai).
    /// Laluan yang disediakan ditafsirkan dengan cara khusus platform pada waktu kompilasi.
    /// Oleh itu, sebagai contoh, permintaan dengan jalan Windows yang mengandungi garis miring balik `\` tidak akan dikompilasi dengan betul pada Unix.
    ///
    ///
    /// Makro ini akan menghasilkan ungkapan jenis `&'static str` yang merupakan kandungan fail.
    ///
    /// # Examples
    ///
    /// Andaikan terdapat dua fail dalam direktori yang sama dengan kandungan berikut:
    ///
    /// Fail 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Menyusun 'main.rs' dan menjalankan binari yang dihasilkan akan mencetak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Termasuk fail sebagai rujukan kepada array bait.
    ///
    /// Fail terletak relatif dengan fail semasa (sama dengan bagaimana modul dijumpai).
    /// Laluan yang disediakan ditafsirkan dengan cara khusus platform pada waktu kompilasi.
    /// Oleh itu, sebagai contoh, permintaan dengan jalan Windows yang mengandungi garis miring balik `\` tidak akan dikompilasi dengan betul pada Unix.
    ///
    ///
    /// Makro ini akan menghasilkan ungkapan jenis `&'static [u8; N]` yang merupakan kandungan fail.
    ///
    /// # Examples
    ///
    /// Andaikan terdapat dua fail dalam direktori yang sama dengan kandungan berikut:
    ///
    /// Fail 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Menyusun 'main.rs' dan menjalankan binari yang dihasilkan akan mencetak "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Memperluas ke rentetan yang mewakili jalur modul semasa.
    ///
    /// Laluan modul semasa boleh dianggap sebagai hierarki modul yang menuju ke crate root.
    /// Komponen pertama jalan yang dikembalikan adalah nama crate yang sedang disusun.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Menilai gabungan boolean flag konfigurasi pada waktu kompilasi.
    ///
    /// Sebagai tambahan kepada atribut `#[cfg]`, makro ini disediakan untuk membolehkan penilaian ekspresi boolean terhadap bendera konfigurasi.
    /// Ini sering membawa kepada kod yang kurang digandakan.
    ///
    /// Sintaks yang diberikan untuk makro ini adalah sintaks yang sama dengan atribut [`cfg`].
    ///
    /// `cfg!`, tidak seperti `#[cfg]`, tidak membuang sebarang kod dan hanya menilai benar atau salah.
    /// Sebagai contoh, semua blok dalam ungkapan if/else perlu sah apabila `cfg!` digunakan untuk keadaan tersebut, tanpa mengira apa yang sedang dinilai oleh `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Menghuraikan fail sebagai ungkapan atau item mengikut konteks.
    ///
    /// Fail terletak relatif dengan fail semasa (sama dengan bagaimana modul dijumpai).Laluan yang disediakan ditafsirkan dengan cara khusus platform pada waktu kompilasi.
    /// Oleh itu, sebagai contoh, permintaan dengan jalan Windows yang mengandungi garis miring balik `\` tidak akan dikompilasi dengan betul pada Unix.
    ///
    /// Menggunakan makro ini sering merupakan idea yang tidak baik, kerana jika fail diuraikan sebagai ekspresi, file tersebut akan diletakkan dalam kod di sekitarnya secara tidak higienis.
    /// Ini dapat mengakibatkan pemboleh ubah atau fungsi berbeda dari apa yang diharapkan file jika ada pemboleh ubah atau fungsi yang memiliki nama yang sama dalam file saat ini.
    ///
    ///
    /// # Examples
    ///
    /// Andaikan terdapat dua fail dalam direktori yang sama dengan kandungan berikut:
    ///
    /// Fail 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fail 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Menyusun 'main.rs' dan menjalankan binari yang dihasilkan akan mencetak "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Menegaskan bahawa ungkapan boolean adalah `true` pada waktu runtime.
    ///
    /// Ini akan memanggil makro [`panic!`] jika ungkapan yang diberikan tidak dapat dinilai ke `true` pada waktu runtime.
    ///
    /// # Uses
    ///
    /// Tegasan selalu diperiksa dalam pembuatan debug dan rilis, dan tidak dapat dilumpuhkan.
    /// Lihat [`debug_assert!`] untuk pernyataan yang tidak diaktifkan dalam binaan keluaran secara lalai.
    ///
    /// Kod yang tidak selamat mungkin bergantung pada `assert!` untuk menguatkuasakan invarian jangka masa yang, jika dilanggar dapat menyebabkan tidak selamat.
    ///
    /// Kes penggunaan `assert!` yang lain termasuk menguji dan menguatkuasakan invarian jangka masa dalam kod selamat (yang pelanggarannya tidak dapat menyebabkan ketidakamanan).
    ///
    ///
    /// # Mesej Tersuai
    ///
    /// Makro ini mempunyai bentuk kedua, di mana mesej panic khusus dapat diberikan dengan atau tanpa argumen untuk pemformatan.
    /// Lihat [`std::fmt`] untuk sintaks untuk borang ini.
    /// Ungkapan yang digunakan sebagai argumen format hanya akan dinilai jika penegasan gagal.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // mesej panic untuk penegasan ini adalah nilai tegas bagi ungkapan yang diberikan.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // fungsi yang sangat sederhana
    ///
    /// assert!(some_computation());
    ///
    /// // tegaskan dengan mesej tersuai
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Pemasangan sebaris.
    ///
    /// Baca [unstable book] untuk penggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Pemasangan sebaris gaya LLVM.
    ///
    /// Baca [unstable book] untuk penggunaan.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Pemasangan sebaris peringkat modul.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Cetakan diteruskan tokens ke output standard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mengaktifkan atau mematikan fungsi penelusuran yang digunakan untuk menyahpepijat makro lain.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro atribut yang digunakan untuk menerapkan makro turunan.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut diterapkan pada fungsi untuk mengubahnya menjadi ujian unit.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut diterapkan pada fungsi untuk mengubahnya menjadi ujian penanda aras.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Perincian pelaksanaan makro `#[test]` dan `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atribut diterapkan pada statik untuk mendaftarkannya sebagai peruntukan global.
    ///
    /// Lihat juga [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Menyimpan item yang digunakan jika laluan yang dilalui dapat diakses, dan menghapusnya sebaliknya.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Memperluas semua atribut `#[cfg]` dan `#[cfg_attr]` dalam fragmen kod yang digunakan.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Perincian pelaksanaan yang tidak stabil dari penyusun `rustc`, jangan gunakan.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Perincian pelaksanaan yang tidak stabil dari penyusun `rustc`, jangan gunakan.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}