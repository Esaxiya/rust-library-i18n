Panics utas semasa.

Ini membolehkan program dihentikan serta-merta dan memberi maklum balas kepada pemanggil program.
`panic!` harus digunakan semasa program mencapai keadaan yang tidak dapat dipulihkan.

Makro ini adalah kaedah yang tepat untuk menegaskan syarat dalam contoh kod dan ujian.
`panic!` berkait rapat dengan kaedah `unwrap` kedua-dua enum [`Option`][ounwrap] dan [`Result`][runwrap].
Kedua-dua pelaksanaan memanggil `panic!` ketika mereka disetel ke varian [`None`] atau [`Err`].

Semasa menggunakan `panic!()`, anda dapat menentukan muatan rentetan, yang dibina menggunakan sintaks [`format!`].
Muatan itu digunakan semasa menyuntik panic ke dalam benang Rust yang memanggil, menyebabkan utas ke panic sepenuhnya.

Tingkah laku `std` hook lalai, iaitu
kod yang berjalan terus setelah panic dipanggil, adalah untuk mencetak muatan mesej ke `stderr` bersama dengan maklumat file/line/column panggilan `panic!()`.

Anda boleh mengatasi panic hook menggunakan [`std::panic::set_hook()`].
Di dalam hook, panic boleh diakses sebagai `&dyn Any + Send`, yang mengandungi `&str` atau `String` untuk panggilan `panic!()` biasa.
Untuk panic dengan nilai jenis lain, [`panic_any`] boleh digunakan.

[`Result`] enum selalunya merupakan penyelesaian yang lebih baik untuk memulihkan kesilapan daripada menggunakan makro `panic!`.
Makro ini harus digunakan untuk mengelakkan meneruskan penggunaan nilai yang salah, seperti dari sumber luaran.
Maklumat terperinci mengenai pengendalian ralat terdapat di [book].

Lihat juga makro [`compile_error!`], untuk meningkatkan kesilapan semasa penyusunan.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Pelaksanaan semasa

Sekiranya utas utama panics ia akan menghentikan semua utas anda dan mengakhiri program anda dengan kod `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





