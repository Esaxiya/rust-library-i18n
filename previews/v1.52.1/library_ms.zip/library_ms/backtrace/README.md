# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Perpustakaan untuk memperoleh jejak belakang pada waktu berjalan untuk Rust.
Perpustakaan ini bertujuan untuk meningkatkan sokongan perpustakaan standard dengan menyediakan antara muka yang dapat diprogramkan untuk digunakan, tetapi juga menyokong dengan mudah mencetak jejak belakang seperti panics libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Untuk menangkap jejak belakang dan menangguhkannya sehingga kemudian, anda boleh menggunakan jenis `Backtrace` tingkat atas.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Namun, jika anda mahukan lebih banyak akses mentah ke fungsi penjejakan sebenar, anda boleh menggunakan fungsi `trace` dan `resolve` secara langsung.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Selesaikan penunjuk arahan ini ke nama simbol
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // terus ke bingkai seterusnya
    });
}
```

# License

Projek ini dilesenkan di bawah salah satu daripada

 * Lesen Apache, Versi 2.0, ([LICENSE-APACHE](LICENSE-APACHE) atau http://www.apache.org/licenses/LICENSE-2.0)
 * Lesen MIT ([LICENSE-MIT](LICENSE-MIT) atau http://opensource.org/licenses/MIT)

mengikut pilihan anda.

### Contribution

Kecuali anda menyatakan secara jelas, sebarang sumbangan yang sengaja diserahkan untuk dimasukkan ke dalam backtrace-rs oleh anda, seperti yang ditentukan dalam lesen Apache-2.0, akan dilesenkan dua kali ganda seperti di atas, tanpa terma atau syarat tambahan.







