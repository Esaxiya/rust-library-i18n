#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Pembentuk untuk jejak belakang.
///
/// Jenis ini boleh digunakan untuk mencetak jejak belakang tanpa mengira dari mana asal jalan belakang.
/// Sekiranya anda mempunyai jenis `Backtrace` maka pelaksanaan `Debug` sudah menggunakan format percetakan ini.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Gaya percetakan yang boleh kita cetak
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Mencetak jejak belakang yang lebih pendek yang idealnya hanya mengandungi maklumat yang relevan
    Short,
    /// Mencetak jejak belakang yang mengandungi semua maklumat yang mungkin
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Buat `BacktraceFmt` baru yang akan menulis output ke `fmt` yang disediakan.
    ///
    /// Argumen `format` akan mengawal gaya jejak belakang dicetak, dan argumen `print_path` akan digunakan untuk mencetak contoh nama fail `BytesOrWideString`.
    /// Jenis ini sendiri tidak melakukan pencetakan nama fail, tetapi panggilan balik ini diperlukan untuk melakukannya.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Mencetak mukadimah untuk jejak belakang yang akan dicetak.
    ///
    /// Ini diperlukan di beberapa platform agar jejak belakang dilambangkan sepenuhnya kemudian, dan jika tidak, ini hanya merupakan kaedah pertama yang anda panggil setelah membuat `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Menambah bingkai ke output jejak belakang.
    ///
    /// Komitmen ini mengembalikan contoh RAII `BacktraceFrameFmt` yang dapat digunakan untuk benar-benar mencetak bingkai, dan pada pemusnahan, ia akan meningkatkan penghitung bingkai.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Melengkapkan output jejak belakang.
    ///
    /// Ini bukan op-op tetapi ditambah untuk keserasian future dengan format backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Tidak ada op-termasuk hook ini untuk membenarkan penambahan future.
        Ok(())
    }
}

/// Pembentuk hanya untuk satu bingkai jejak belakang.
///
/// Jenis ini dibuat oleh fungsi `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Mencetak `BacktraceFrame` dengan pemformat bingkai ini.
    ///
    /// Ini akan mencetak semua contoh `BacktraceSymbol` dalam `BacktraceFrame` secara berulang.
    ///
    /// # Ciri-ciri yang diperlukan
    ///
    /// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Mencetak `BacktraceSymbol` dalam `BacktraceFrame`.
    ///
    /// # Ciri-ciri yang diperlukan
    ///
    /// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ini tidak bagus kerana kita tidak akhirnya mencetak apa-apa
            // dengan nama fail bukan utf8.
            // Untungnya hampir semuanya utf8 jadi ini tidak boleh terlalu buruk.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Mencetak `Frame` dan `Symbol` yang dijejaki mentah, biasanya dari dalam panggilan balik mentah crate ini.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Menambah bingkai mentah pada output jejak belakang.
    ///
    /// Kaedah ini, tidak seperti yang sebelumnya, mengambil argumen mentah sekiranya mereka berasal dari lokasi yang berbeza.
    /// Perhatikan bahawa ini mungkin dipanggil berkali-kali untuk satu bingkai.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Menambah bingkai mentah ke output jejak belakang, termasuk maklumat lajur.
    ///
    /// Kaedah ini, seperti sebelumnya, mengambil argumen mentah sekiranya mereka berasal dari lokasi yang berbeza.
    /// Perhatikan bahawa ini mungkin dipanggil berkali-kali untuk satu bingkai.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia tidak dapat melambangkan dalam proses sehingga mempunyai format khas yang dapat digunakan untuk melambangkan kemudian.
        // Cetak itu dan bukannya mencetak alamat dalam format kita sendiri di sini.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Tidak perlu mencetak bingkai "null", pada dasarnya ia bermaksud bahawa jalan belakang sistem agak bersemangat untuk mengesan kembali jauh.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Untuk mengurangkan ukuran TCB di Sgx enclave, kami tidak mahu melaksanakan fungsi resolusi simbol.
        // Sebaliknya, kita dapat mencetak offset alamat di sini, yang kemudian dapat dipetakan untuk memperbaiki fungsi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Cetak indeks bingkai serta petunjuk petunjuk bingkai.
        // Sekiranya kita melampaui simbol pertama bingkai ini walaupun kita hanya mencetak ruang kosong yang sesuai.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Seterusnya tuliskan nama simbol, gunakan format alternatif untuk maklumat lebih lanjut jika kita mengikuti jalan belakang sepenuhnya.
        // Di sini kita juga mengendalikan simbol yang tidak mempunyai nama,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Dan terakhir, cetak nombor filename/line jika ada.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line dicetak pada garisan di bawah nama simbol, jadi cetak beberapa ruang kosong yang sesuai untuk membariskan diri kita sendiri.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegasikan ke panggilan balik dalaman kami untuk mencetak nama fail dan kemudian mencetak nombor baris.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Tambahkan nombor lajur, jika ada.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Kami hanya mementingkan simbol pertama bingkai
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}