//! Sokongan untuk simbolik menggunakan `gimli` crate pada crates.io
//!
//! Ini adalah pelaksanaan simbolik lalai untuk Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'Kehidupan statik adalah kebohongan untuk mengatasi kekurangan sokongan untuk struktur rujukan diri.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Tukar ke 'jangka hayat statik kerana simbol hanya boleh meminjam `map` dan `stash` dan kami menyimpannya di bawah.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Untuk memuatkan perpustakaan asli di Windows, lihat beberapa perbincangan mengenai rust-lang/rust#71060 untuk pelbagai strategi di sini.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Perpustakaan MinGW pada masa ini tidak menyokong ASLR (rust-lang/rust#16514), tetapi DLL masih boleh dipindahkan di ruang alamat.
            // Nampaknya alamat dalam maklumat debug semuanya seolah-olah perpustakaan ini dimuat pada "image base"-nya, yang merupakan bidang dalam tajuk fail COFF-nya.
            // Oleh kerana inilah yang tampaknya disenaraikan oleh debuginfo, kami menguraikan jadual simbol dan alamat kedai seolah-olah perpustakaan dimuat di "image base" juga.
            //
            // Perpustakaan mungkin tidak dimuat pada "image base", bagaimanapun.
            // (mungkin ada yang lain dimuat di sana?) Di sinilah bidang `bias` dimainkan, dan kita perlu mengetahui nilai `bias` di sini.Malangnya walaupun tidak jelas bagaimana memperolehnya dari modul yang dimuatkan.
            // Apa yang kita ada, bagaimanapun, adalah alamat beban sebenar (`modBaseAddr`).
            //
            // Sebagai langkah penyingkiran buat masa ini, kami memetakan fail, baca maklumat tajuk fail, kemudian lepaskan mmap.Ini sia-sia kerana kita mungkin akan membuka semula mmap kemudian, tetapi ini mesti berfungsi dengan baik buat masa ini.
            //
            // Sebaik sahaja kita mempunyai `image_base` (lokasi muatan yang diinginkan) dan `base_addr` (lokasi muatan sebenar) kita dapat mengisi `bias` (perbezaan antara yang sebenarnya dan yang diinginkan) dan kemudian alamat yang dinyatakan dari setiap segmen adalah `image_base` kerana itulah yang dikatakan oleh fail.
            //
            //
            // Buat masa ini nampaknya tidak seperti ELF/MachO yang dapat kita lakukan dengan satu segmen per perpustakaan, menggunakan `modBaseSize` sebagai ukuran keseluruhan.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS menggunakan format fail Mach-O dan menggunakan API khusus DYLD untuk memuatkan senarai perpustakaan asli yang merupakan sebahagian daripada aplikasi.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Ambil nama perpustakaan ini yang sesuai dengan jalan di mana memuatkannya juga.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Muatkan header gambar perpustakaan ini dan delegasikan ke `object` untuk menguraikan semua arahan muat sehingga kita dapat mengetahui semua segmen yang terlibat di sini.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Ulangi segmen dan daftarkan kawasan yang diketahui untuk segmen yang kami dapati.
            // Selain itu, catat maklumat mengenai segmen teks untuk diproses kemudian, lihat komen di bawah.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Tentukan "slide" untuk perpustakaan ini yang akhirnya menjadi bias yang kita gunakan untuk mengetahui di mana objek memori dimuat.
            // Ini sedikit pengiraan yang pelik dan merupakan hasil daripada mencuba beberapa perkara di alam liar dan melihat apa yang melekat.
            //
            // Idea umum adalah bahawa `bias` plus `stated_virtual_memory_address` segmen akan berada di tempat di ruang alamat sebenar segmen itu berada.
            // Perkara lain yang kita percayai ialah alamat sebenar tolak `bias` adalah indeks untuk dicari dalam jadual simbol dan debuginfo.
            //
            // Ternyata, untuk perpustakaan yang dimuatkan sistem, pengiraan ini tidak betul.Bagi pelaksana asli, bagaimanapun, ia kelihatan betul.
            // Mengangkat beberapa logik dari sumber LLDB, ia mempunyai beberapa casing khas untuk bahagian `__TEXT` pertama yang dimuat dari offset fail 0 dengan ukuran bukan nol.
            // Walau apa pun sebabnya, ini menunjukkan bahawa jadual simbol hanya berkaitan dengan slaid vmaddr untuk perpustakaan.
            // Sekiranya *tidak* hadir, maka jadual simbol adalah relatif dengan slaid vmaddr ditambah dengan alamat yang dinyatakan segmen.
            //
            // Untuk menangani keadaan ini jika kita *tidak* menemui bahagian teks pada offset fail sifar maka kita akan meningkatkan bias dengan alamat yang dinyatakan bahagian teks pertama dan menurunkan semua alamat yang dinyatakan dengan jumlah itu juga.
            //
            // Dengan demikian jadual simbol selalu muncul berbanding dengan jumlah bias perpustakaan.
            // Ini nampaknya mempunyai hasil yang tepat untuk melambangkan melalui jadual simbol.
            //
            // Sejujurnya saya tidak pasti sama ada ini betul atau jika ada perkara lain yang harus menunjukkan cara melakukan ini.
            // Buat masa ini walaupun ini nampaknya berfungsi dengan baik (?) dan kita semestinya dapat mengubahnya dari masa ke masa jika perlu.
            //
            // Untuk maklumat lanjut, lihat #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix lain (mis
        // Linux) platform menggunakan ELF sebagai format fail objek dan biasanya menerapkan API yang disebut `dl_iterate_phdr` untuk memuatkan perpustakaan asli.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` harus menjadi petunjuk yang sah.
        // `vec` harus menjadi penunjuk yang sah ke `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 secara semula jadi tidak menyokong maklumat debug, tetapi sistem build akan meletakkan maklumat debug pada jalur `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Semua yang lain mesti menggunakan ELF, tetapi tidak tahu bagaimana memuatkan perpustakaan asli.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Semua perpustakaan kongsi yang diketahui telah dimuatkan.
    libraries: Vec<Library>,

    /// Memetakan cache di mana kita menyimpan maklumat kerdil yang dihuraikan.
    ///
    /// Senarai ini mempunyai kapasiti tetap untuk keseluruhan masa penggunaannya yang tidak pernah meningkat.
    /// Elemen `usize` setiap pasangan adalah indeks ke `libraries` di atas di mana `usize::max_value()` mewakili yang dapat dilaksanakan sekarang.
    ///
    /// `Mapping` adalah maklumat kerdil yang dihuraikan.
    ///
    /// Perhatikan bahawa ini pada dasarnya adalah cache LRU dan kami akan mengalihkan perkara di sini semasa kami melambangkan alamat.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmen perpustakaan ini dimuat ke dalam memori, dan di mana ia dimuat.
    segments: Vec<LibrarySegment>,
    /// "bias" perpustakaan ini, biasanya di mana ia dimuat ke dalam memori.
    /// Nilai ini ditambahkan ke alamat setiap segmen yang dinyatakan untuk mendapatkan alamat memori maya sebenar yang dimuatkan dalam segmen tersebut.
    /// Selain itu bias ini dikurangkan dari alamat memori maya sebenar ke indeks ke debuginfo dan jadual simbol.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Alamat yang dinyatakan dari segmen ini dalam fail objek.
    /// Ini sebenarnya bukan di mana segmen dimuat, melainkan alamat ini ditambah `bias` perpustakaan yang mengandungi adalah tempat untuk mencarinya.
    ///
    stated_virtual_memory_address: usize,
    /// Ukuran segmen ini dalam ingatan.
    len: usize,
}

// tidak selamat kerana ini perlu disegerakkan secara luaran
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // tidak selamat kerana ini perlu disegerakkan secara luaran
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Cache LRU yang sangat kecil dan sangat sederhana untuk pemetaan maklumat debug.
        //
        // Kadar hit harus sangat tinggi, kerana tumpukan biasa tidak melintasi banyak perpustakaan bersama.
        //
        // Struktur `addr2line::Context` cukup mahal untuk dibuat.
        // Kosnya dijangka akan dilunaskan oleh pertanyaan `locate` berikutnya, yang memanfaatkan struktur yang dibina semasa membina `addr2line: : Context`s untuk mendapatkan peningkatan yang baik.
        //
        // Sekiranya kita tidak mempunyai cache ini, pelunasan itu tidak akan pernah berlaku, dan melambangkan jejak belakang adalah ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Pertama, uji apakah `lib` ini mempunyai segmen yang mengandungi `addr` (menangani penempatan semula).Sekiranya cek ini berlalu maka kita boleh teruskan di bawah dan menerjemahkan alamatnya.
                //
                // Perhatikan bahawa kami menggunakan `wrapping_add` di sini untuk mengelakkan pemeriksaan limpahan.Telah dilihat di alam liar bahawa pengiraan bias SVMA + melimpah.
                // Nampaknya agak ganjil yang akan berlaku tetapi tidak banyak yang dapat kita lakukan mengenainya selain mungkin hanya mengabaikan segmen-segmen itu kerana kemungkinan mereka akan menuju ke angkasa.
                //
                // Ini pada asalnya muncul di rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Sekarang kita tahu `lib` mengandungi `addr`, kita dapat mengimbangi dengan bias untuk mencari alamat memori virutal yang dinyatakan.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invarian: setelah syarat ini selesai tanpa kembali awal
        // dari ralat, entri cache untuk laluan ini berada di indeks 0.

        if let Some(idx) = idx {
            // Apabila pemetaan sudah ada di cache, pindahkan ke depan.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Apabila pemetaan tidak ada di cache, buat pemetaan baru, masukkan ke depan cache, dan keluarkan entri cache tertua jika perlu.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // jangan bocor seumur hidup `'static`, pastikan ia dilupuskan untuk diri kita sendiri
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Panjangkan jangka hayat `sym` hingga `'static` kerana sayangnya kami diharuskan ke sini, tetapi ia selalu menjadi rujukan sehingga tidak ada rujukan terhadapnya yang harus dilakukan di luar kerangka ini pula.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Akhirnya, dapatkan pemetaan cache atau buat pemetaan baru untuk fail ini, dan nilaikan maklumat DWARF untuk mencari file/line/name untuk alamat ini.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Kami dapat mencari maklumat bingkai untuk simbol ini, dan bingkai "addr2line" secara dalaman mempunyai semua butiran yang menarik.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Tidak dapat mencari maklumat debug, tetapi kami dapati di jadual simbol peri yang dapat dilaksanakan.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}