//! Strategi simbolik menggunakan kod penghuraian DWARF di libbacktrace.
//!
//! Perpustakaan libbacktrace C, biasanya diedarkan dengan gcc, menyokong bukan sahaja menghasilkan jejak belakang (yang sebenarnya tidak kita gunakan) tetapi juga melambangkan jejak belakang dan menangani maklumat debug kerdil mengenai perkara seperti bingkai bergaris dan yang lainnya.
//!
//!
//! Ini agak rumit kerana terdapat banyak masalah di sini, tetapi idea asasnya adalah:
//!
//! * Mula-mula kami memanggil `backtrace_syminfo`.Ini mendapat maklumat simbol dari jadual simbol dinamik jika kita boleh.
//! * Seterusnya kami memanggil `backtrace_pcinfo`.Ini akan menguraikan jadual debuginfo jika tersedia dan membolehkan kami memulihkan maklumat mengenai bingkai sebaris, nama fail, nombor baris, dll.
//!
//! Terdapat banyak tipu muslihat untuk memasukkan jadual kerdil ke jalan balik, tetapi mudah-mudahan itu bukan akhir dunia dan cukup jelas ketika membaca di bawah.
//!
//! Ini adalah strategi simbolik lalai untuk platform bukan MSVC dan bukan OSX.Dalam libstd walaupun ini adalah strategi lalai untuk OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Sekiranya boleh, pilih nama `function` yang berasal dari debuginfo dan biasanya lebih tepat untuk bingkai sebaris misalnya.
                // Sekiranya itu tidak hadir, kembali ke nama jadual simbol yang dinyatakan dalam `symname`.
                //
                // Perhatikan bahawa kadangkala `function` terasa agak kurang tepat, misalnya disenaraikan sebagai `try<i32,closure>` isntead of `std::panicking::try::do_call`.
                //
                // Tidak begitu jelas mengapa, tetapi secara keseluruhan nama `function` nampaknya lebih tepat.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // buat apa-apa buat masa ini
}

/// Jenis penunjuk `data` diteruskan ke `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Setelah panggilan balik ini dipanggil dari `backtrace_syminfo` ketika kita mula menyelesaikannya, kita akan menghubungi `backtrace_pcinfo` lebih jauh.
    // Fungsi `backtrace_pcinfo` akan merujuk maklumat debug dan berusaha untuk melakukan perkara-perkara seperti memulihkan maklumat file/line dan juga bingkai bergaris.
    // Perhatikan bahawa `backtrace_pcinfo` boleh gagal atau tidak banyak berlaku jika tidak ada maklumat debug, jadi jika itu berlaku, kami pasti memanggil panggilan balik dengan sekurang-kurangnya satu simbol dari `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Jenis penunjuk `data` diteruskan ke `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace menyokong mewujudkan keadaan, tetapi tidak menyokong memusnahkan keadaan.
// Saya secara peribadi menganggap ini bermaksud bahawa sebuah negara dimaksudkan untuk diciptakan dan kemudian hidup selama-lamanya.
//
// Saya ingin mendaftarkan pengendali at_exit() yang membersihkan keadaan ini, tetapi libbacktrace tidak menyediakan cara untuk melakukannya.
//
// Dengan kekangan ini, fungsi ini mempunyai keadaan cache statik yang dikira pada kali pertama diminta.
//
// Ingat bahawa melacak semua berlaku secara bersiri (satu kunci global).
//
// Perhatikan bahawa kurangnya penyegerakan di sini disebabkan oleh syarat bahawa `resolve` diselaraskan secara luaran.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Jangan gunakan keupayaan libstrace threadsafe kerana kami selalu memanggilnya dengan cara yang segerak.
        //
        0,
        error_cb,
        ptr::null_mut(), // tiada data tambahan
    );

    return STATE;

    // Perhatikan bahawa untuk libbacktrace beroperasi sama sekali ia perlu mencari maklumat debug DWARF untuk yang dapat dijalankan sekarang.Ia biasanya dilakukan melalui beberapa mekanisme termasuk, tetapi tidak terhad kepada:
    //
    // * /proc/self/exe pada platform yang disokong
    // * Nama fail diserahkan secara jelas ketika membuat keadaan
    //
    // Perpustakaan libbacktrace adalah sebilangan besar kod C.Ini secara semula jadi bermaksud ia mempunyai kerentanan keselamatan memori, terutama ketika menangani debuginfo yang salah bentuk.
    // Libstd mengalami banyak perkara ini secara sejarah.
    //
    // Sekiranya /proc/self/exe digunakan, kita biasanya dapat mengabaikannya kerana kita menganggap bahawa libbacktrace adalah "mostly correct" dan sebaliknya tidak melakukan perkara yang pelik dengan maklumat debug kerdil "attempted to be correct".
    //
    //
    // Namun, jika kami memasukkan nama fail, mungkin di beberapa platform (seperti BSD) di mana pelaku jahat boleh menyebabkan fail sewenang-wenangnya diletakkan di lokasi tersebut.
    // Ini bermaksud bahawa jika kita memberitahu libbacktrace tentang nama fail, ia mungkin menggunakan fail sewenang-wenang, mungkin menyebabkan segfaults.
    // Sekiranya kita tidak memberitahu apa-apa libbacktrace maka ia tidak akan melakukan apa-apa di platform yang tidak menyokong jalan seperti /proc/self/exe!
    //
    // Mengingat semua yang kami usahakan sekuat mungkin untuk *tidak* memasukkan nama fail, tetapi kami mesti berada di platform yang sama sekali tidak menyokong /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Perhatikan bahawa idealnya kita menggunakan `std::env::current_exe`, tetapi kita tidak memerlukan `std` di sini.
            //
            // Gunakan `_NSGetExecutablePath` untuk memuat jalan yang dapat dilaksanakan sekarang ke kawasan statik (yang jika terlalu kecil hanya menyerah).
            //
            //
            // Perhatikan bahawa kami sangat mempercayai libbacktrace di sini untuk tidak mati pada eksekusi yang korup, tetapi ia pasti ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows mempunyai mod membuka fail di mana setelah dibuka ia tidak dapat dihapus.
            // Secara umum itulah yang kami mahukan di sini kerana kami ingin memastikan bahawa pelaksanaan kami tidak berubah dari bawah kami setelah kami menyerahkannya ke libbacktrace, semoga dapat mengurangkan kemampuan untuk menyebarkan data sewenang-wenang ke jejak libback (yang mungkin tidak dapat diatasi).
            //
            //
            // Memandangkan kita melakukan sedikit tarian di sini untuk berusaha mendapatkan semacam kunci pada gambar kita sendiri:
            //
            // * Dapatkan menangani proses semasa, muatkan nama failnya.
            // * Buka fail ke nama fail itu dengan bendera yang betul.
            // * Muat semula nama fail proses semasa, pastikan ia sama
            //
            // Sekiranya itu semua berlaku, kita secara teori telah membuka fail proses kita dan kita dijamin ia tidak akan berubah.FWIW banyak perkara ini disalin dari libstd secara sejarah, jadi ini adalah tafsiran terbaik saya mengenai apa yang berlaku.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ini tinggal dalam memori statik sehingga kita dapat mengembalikannya ..
                static mut BUF: [i8; N] = [0; N];
                // ... dan ini tinggal di timbunan sejak sementara
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // dengan sengaja membocorkan `handle` di sini kerana dengan membuka itu harus menyimpan kunci kami pada nama fail ini.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Kami ingin mengembalikan potongan yang tidak diakhiri, jadi jika semuanya diisi dan sama dengan jumlah panjangnya maka setamakan dengan kegagalan.
                //
                //
                // Jika tidak apabila berjaya, pastikan nul byte dimasukkan ke dalam slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // kesilapan jalan belakang kini disapu di bawah permaidani
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Panggil `backtrace_syminfo` API yang (dari membaca kod) harus memanggil `syminfo_cb` tepat sekali (atau mungkin gagal dengan ralat).
    // Kami kemudian menangani lebih banyak perkara dalam `syminfo_cb`.
    //
    // Perhatikan bahawa kami melakukan ini kerana `syminfo` akan melihat jadual simbol, mencari nama simbol walaupun tidak ada maklumat debug dalam binari.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}