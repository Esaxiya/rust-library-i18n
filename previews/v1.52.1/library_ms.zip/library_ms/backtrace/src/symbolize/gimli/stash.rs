// hanya digunakan pada Linux sekarang, jadi benarkan kod mati di tempat lain
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Peruntukan arena sederhana untuk penyangga bait.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Memperuntukkan penyangga dari ukuran yang ditentukan dan mengembalikan rujukan yang boleh berubah kepadanya.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // KESELAMATAN: ini adalah satu-satunya fungsi yang pernah membina perubahan
        // merujuk kepada `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // KESELAMATAN: kami tidak pernah mengeluarkan unsur dari `self.buffers`, jadi rujukan
        // ke data di dalam mana-mana penyangga akan hidup selagi `self` berlaku.
        &mut buffers[i]
    }
}