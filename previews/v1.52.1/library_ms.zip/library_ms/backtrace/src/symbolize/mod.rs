use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Selesaikan alamat ke simbol, berikan simbol ke penutupan yang ditentukan.
///
/// Fungsi ini akan mencari alamat yang diberikan di kawasan seperti jadual simbol tempatan, jadual simbol dinamik, atau info debug DWARF (bergantung pada implementasi yang diaktifkan) untuk mencari simbol yang akan dihasilkan.
///
///
/// Penutupan mungkin tidak disebut jika resolusi tidak dapat dilakukan, dan juga dapat disebut lebih dari sekali dalam kasus fungsi sebaris.
///
/// Simbol yang dihasilkan mewakili pelaksanaan pada `addr` yang ditentukan, mengembalikan pasangan file/line untuk alamat tersebut (jika ada).
///
/// Perhatikan bahawa jika anda mempunyai `Frame` maka disarankan untuk menggunakan fungsi `resolve_frame` dan bukan yang ini.
///
/// # Ciri-ciri yang diperlukan
///
/// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic berganda untuk membatalkan prosesnya.
/// Beberapa platform menggunakan perpustakaan C yang secara dalaman menggunakan panggilan balik yang tidak dapat dilepaskan, jadi panik dari `cb` dapat memicu proses membatalkan.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // hanya melihat pada bingkai atas
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Selesaikan bingkai penangkapan sebelumnya ke simbol, pasangkan simbol ke penutupan yang ditentukan.
///
/// Functin ini menjalankan fungsi yang sama dengan `resolve` kecuali ia memerlukan `Frame` sebagai argumen dan bukannya alamat.
/// Ini membolehkan beberapa implementasi platform backtracing memberikan maklumat simbol atau maklumat yang lebih tepat mengenai bingkai sebaris misalnya.
///
/// Sebaiknya gunakan ini jika anda boleh.
///
/// # Ciri-ciri yang diperlukan
///
/// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic berganda untuk membatalkan prosesnya.
/// Beberapa platform menggunakan perpustakaan C yang secara dalaman menggunakan panggilan balik yang tidak dapat dilepaskan, jadi panik dari `cb` dapat memicu proses membatalkan.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // hanya melihat pada bingkai atas
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Nilai IP dari bingkai tumpukan biasanya (always?) arahan *selepas* panggilan itulah jejak timbunan sebenar.
// Melambangkan ini menyebabkan nombor filename/line menjadi satu di hadapan dan mungkin menjadi kosong jika ia hampir ke akhir fungsi.
//
// Ini pada dasarnya selalu berlaku di semua platform, jadi kami selalu mengurangkan satu dari ip yang diselesaikan untuk menyelesaikannya ke arahan panggilan sebelumnya dan bukannya arahan yang dikembalikan.
//
//
// Sebaiknya kita tidak melakukan ini.
// Sebaik-baiknya kami menghendaki pemanggil API `resolve` di sini untuk melakukan -1 dan akaun secara manual bahawa mereka mahukan maklumat lokasi untuk arahan *sebelumnya*, bukan yang terkini.
// Sebaik-baiknya kita juga akan mendedahkan tentang `Frame` sekiranya kita benar-benar alamat arahan seterusnya atau yang terkini.
//
// Buat masa ini walaupun ini adalah masalah yang cukup menarik, jadi kami hanya secara dalaman mengurangkan satu.
// Pengguna harus terus berusaha dan mendapat hasil yang cukup baik, jadi kita harus cukup baik.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Sama seperti `resolve`, hanya tidak selamat kerana tidak diselaraskan.
///
/// Fungsi ini tidak mempunyai penjamin penyegerakan tetapi tersedia apabila ciri `std` crate ini tidak disusun.
/// Lihat fungsi `resolve` untuk lebih banyak dokumentasi dan contoh.
///
/// # Panics
///
/// Lihat maklumat mengenai `resolve` untuk peringatan tentang panik `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Sama seperti `resolve_frame`, hanya tidak selamat kerana tidak diselaraskan.
///
/// Fungsi ini tidak mempunyai penjamin penyegerakan tetapi tersedia apabila ciri `std` crate ini tidak disusun.
/// Lihat fungsi `resolve_frame` untuk lebih banyak dokumentasi dan contoh.
///
/// # Panics
///
/// Lihat maklumat mengenai `resolve_frame` untuk peringatan tentang panik `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait yang mewakili resolusi simbol dalam fail.
///
/// trait ini dihasilkan sebagai objek trait pada penutupan yang diberikan kepada fungsi `backtrace::resolve`, dan ia hampir dihantar kerana tidak diketahui pelaksanaan mana di belakangnya.
///
///
/// Simbol dapat memberikan maklumat kontekstual mengenai fungsi, misalnya nama, nama file, nombor baris, alamat tepat, dll.
/// Namun, tidak semua maklumat selalu tersedia dalam simbol, jadi semua kaedah mengembalikan `Option`.
///
///
pub struct Symbol {
    // TODO: ikatan seumur hidup ini perlu ditahan akhirnya hingga `Symbol`,
    // tetapi pada masa ini perubahan yang mendadak.
    // Buat masa ini, ini selamat kerana `Symbol` hanya diberikan melalui rujukan dan tidak dapat diklon.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Mengembalikan nama fungsi ini.
    ///
    /// Struktur yang dikembalikan boleh digunakan untuk bertanya pelbagai sifat mengenai nama simbol:
    ///
    ///
    /// * Pelaksanaan `Display` akan mencetak simbol demangled.
    /// * Nilai `str` mentah simbol dapat diakses (jika itu sah utf-8).
    /// * Byte mentah untuk nama simbol dapat diakses.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Mengembalikan alamat permulaan fungsi ini.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Mengembalikan nama fail mentah sebagai kepingan.
    /// Ini amat berguna untuk persekitaran `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Mengembalikan nombor lajur di mana simbol ini sedang dijalankan.
    ///
    /// Hanya gimli pada masa ini yang memberikan nilai di sini dan walaupun hanya jika `filename` mengembalikan `Some`, dan oleh itu, ia kemudiannya dikenakan peringatan yang serupa.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Mengembalikan nombor garis di mana simbol ini sedang dijalankan.
    ///
    /// Nilai pulangan ini biasanya `Some` jika `filename` mengembalikan `Some`, dan akibatnya tertakluk pada peringatan yang serupa.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Mengembalikan nama fail di mana fungsi ini ditentukan.
    ///
    /// Ini hanya tersedia semasa libbacktrace atau gimli digunakan (mis
    /// unix platform lain) dan apabila binari disusun dengan debuginfo.
    /// Sekiranya kedua-dua syarat ini tidak terpenuhi maka kemungkinan ini akan mengembalikan `None`.
    ///
    /// # Ciri-ciri yang diperlukan
    ///
    /// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mungkin simbol C++ yang dihuraikan, jika menguraikan simbol yang tidak berfungsi sebagai Rust gagal.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Pastikan ini tetap bersaiz sifar, supaya ciri `cpp_demangle` tidak mempunyai kos ketika dilumpuhkan.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Pembalut di sekitar nama simbol untuk memberikan aksesori ergonomik ke nama yang dibongkar, bait mentah, tali mentah, dll.
///
// Benarkan kod mati apabila ciri `cpp_demangle` tidak diaktifkan.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Membuat nama simbol baru dari bait asas mentah.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Mengembalikan nama simbol (mangled) mentah sebagai `str` jika simbol itu sah utf-8.
    ///
    /// Gunakan pelaksanaan `Display` jika anda mahukan versi yang dibongkar.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Mengembalikan nama simbol mentah sebagai senarai bait
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ini mungkin untuk dicetak jika simbol yang di-demang tidak benar-benar berlaku, jadi atasi kesalahan di sini dengan baik dengan tidak menyebarkannya ke luar.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Percubaan untuk mendapatkan semula memori cache yang digunakan untuk melambangkan alamat.
///
/// Kaedah ini akan berusaha melepaskan struktur data global yang sebaliknya telah di-cache secara global atau dalam urutan yang biasanya mewakili maklumat DWARF yang dihuraikan atau yang serupa.
///
///
/// # Caveats
///
/// Walaupun fungsi ini selalu tersedia, ia sebenarnya tidak melakukan apa-apa pada kebanyakan pelaksanaan.
/// Perpustakaan seperti dbghelp atau libbacktrace tidak menyediakan kemudahan untuk menyahpindah keadaan dan menguruskan memori yang diperuntukkan.
/// Buat masa ini ciri `gimli-symbolize` crate ini adalah satu-satunya ciri di mana fungsi ini mempunyai kesan.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}