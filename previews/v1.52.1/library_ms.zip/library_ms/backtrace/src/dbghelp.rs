//! Modul untuk membantu menguruskan dbghelp binding pada Windows
//!
//! Jejak belakang pada Windows (sekurang-kurangnya untuk MSVC) sebahagian besarnya digerakkan melalui `dbghelp.dll` dan pelbagai fungsi yang terdapat di dalamnya.
//! Fungsi-fungsi ini dimuat *secara dinamik* daripada menghubungkan ke `dbghelp.dll` secara statik.
//! Ini sekarang dilakukan oleh perpustakaan standard (dan secara teori diperlukan di sana), tetapi merupakan usaha untuk membantu mengurangkan kebergantungan dll statik perpustakaan kerana jejak belakang biasanya cukup pilihan.
//!
//! Oleh itu, `dbghelp.dll` hampir selalu berjaya dimuat pada Windows.
//!
//! Perhatikan bahawa kerana kita memuat semua sokongan ini secara dinamik, kita sebenarnya tidak dapat menggunakan definisi mentah di `winapi`, tetapi kita perlu menentukan sendiri jenis penunjuk fungsi dan menggunakannya.
//! Kami tidak benar-benar ingin berada dalam perniagaan menggandakan winapi, jadi kami mempunyai ciri Cargo `verify-winapi` yang menegaskan bahawa semua pengikatan sesuai dengan yang ada di winapi dan ciri ini diaktifkan pada CI.
//!
//! Akhirnya, anda akan perhatikan di sini bahawa dll untuk `dbghelp.dll` tidak pernah dimuat turun, dan pada masa ini disengajakan.
//! Pemikirannya adalah bahawa kita dapat menyimpannya secara global dan menggunakannya antara panggilan ke API, mengelakkan loads/unloads yang mahal.
//! Sekiranya ini menjadi masalah bagi pengesan kebocoran atau sesuatu seperti itu, kita boleh menyeberangi jambatan ketika sampai di sana.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Selesaikan `SymGetOptions` dan `SymSetOptions` tidak hadir di winapi itu sendiri.
// Jika tidak, ini hanya digunakan apabila kita memeriksa jenis jenis winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Belum ditentukan dalam winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ini ditentukan dalam winapi, tetapi tidak betul (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Belum ditentukan dalam winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Makro ini digunakan untuk menentukan struktur `Dbghelp` yang secara dalaman mengandungi semua petunjuk fungsi yang mungkin kita muatkan.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL yang dimuat untuk `dbghelp.dll`
            dll: HMODULE,

            // Setiap penunjuk fungsi untuk setiap fungsi yang mungkin kita gunakan
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Pada mulanya kami belum memuatkan DLL
            dll: 0 as *mut _,
            // Permulaan semua fungsi ditetapkan ke sifar untuk mengatakan bahawa mereka perlu dimuat secara dinamik.
            //
            $($name: 0,)*
        };

        // Kemudahan typedef untuk setiap jenis fungsi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Percubaan untuk membuka `dbghelp.dll`.
            /// Mengembalikan kejayaan jika berjaya atau ralat jika `LoadLibraryW` gagal.
            ///
            /// Panics jika perpustakaan sudah dimuat.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Fungsi untuk setiap kaedah yang ingin kita gunakan.
            // Apabila dipanggil, ia akan membaca penunjuk fungsi cache atau memuatkannya dan mengembalikan nilai yang dimuat.
            // Banyak ditegaskan untuk berjaya.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Kemudahan proksi untuk menggunakan kunci pembersihan untuk merujuk fungsi dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Permulaan semua sokongan yang diperlukan untuk mengakses fungsi `dbghelp` API dari crate ini.
///
///
/// Perhatikan bahawa fungsi ini **selamat**, secara dalaman mempunyai penyegerakan tersendiri.
/// Juga perhatikan bahawa selamat memanggil fungsi ini berulang kali secara berulang.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Perkara pertama yang perlu kita lakukan ialah menyegerakkan fungsi ini.Ini boleh dipanggil secara serentak dari utas lain atau secara berulang dalam satu utas.
        // Perhatikan bahawa ia lebih sukar daripada itu kerana apa yang kita gunakan di sini, `dbghelp`,*juga* perlu diselaraskan dengan semua pemanggil lain ke `dbghelp` dalam proses ini.
        //
        // Biasanya tidak ada banyak panggilan ke `dbghelp` dalam proses yang sama dan kita mungkin boleh menganggap bahawa satu-satunya yang mengaksesnya.
        // Terdapat, bagaimanapun, satu pengguna utama yang perlu kita bimbangkan adalah ironinya diri kita, tetapi di perpustakaan standard.
        // Perpustakaan standard Rust bergantung pada crate ini untuk sokongan jejak belakang, dan crate ini juga wujud di crates.io.
        // Ini bermaksud bahawa jika perpustakaan standard mencetak jejak belakang panic, ia mungkin berlumba dengan crate ini yang berasal dari crates.io, menyebabkan segfaults.
        //
        // Untuk membantu menyelesaikan masalah penyegerakan ini, kami menggunakan trik khusus Windows di sini (bagaimanapun, ini adalah sekatan khusus Windows mengenai penyegerakan).
        // Kami membuat *sesi-local* bernama mutex untuk melindungi panggilan ini.
        // Tujuannya di sini adalah bahawa pustaka standard dan crate ini tidak perlu berkongsi API tahap Rust untuk disegerakkan di sini tetapi sebaliknya dapat berfungsi di belakang tabir untuk memastikan mereka saling menyelaraskan antara satu sama lain.
        //
        // Dengan cara itu apabila fungsi ini dipanggil melalui pustaka standard atau melalui crates.io, kita dapat memastikan bahawa mutex yang sama sedang diperoleh.
        //
        // Jadi semua itu adalah untuk mengatakan bahawa perkara pertama yang kita lakukan di sini adalah kita secara automatik membuat `HANDLE` yang dinamakan mutex pada Windows.
        // Kami sedikit menyegerakkan dengan utas lain yang berkongsi fungsi ini secara khusus dan memastikan bahawa hanya satu pemegang dibuat setiap kejadian fungsi ini.
        // Perhatikan bahawa pemegang tidak akan pernah ditutup setelah ia disimpan di global.
        //
        // Setelah benar-benar membuka kunci, kita hanya memperolehnya, dan pegangan `Init` yang kita berikan akan bertanggungjawab untuk menjatuhkannya akhirnya.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Sekarang kita semua disegerakkan dengan selamat, mari kita mula memproses semuanya.
        // Pertama kita perlu memastikan bahawa `dbghelp.dll` sebenarnya dimuat dalam proses ini.
        // Kami melakukan ini secara dinamik untuk mengelakkan kebergantungan statik.
        // Ini secara historis dilakukan untuk mengatasi masalah penghubung yang pelik dan bertujuan menjadikan binari sedikit lebih mudah alih kerana ini sebahagian besarnya hanyalah utiliti penyahpepijatan.
        //
        //
        // Setelah kita membuka `dbghelp.dll`, kita perlu memanggil beberapa fungsi inisialisasi di dalamnya, dan itu lebih terperinci di bawah.
        // Kami hanya melakukan ini sekali, jadi kami mempunyai boolean global yang menunjukkan sama ada kami sudah selesai atau belum.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Pastikan bendera `SYMOPT_DEFERRED_LOADS` ditetapkan, kerana menurut dokumen MSVC sendiri mengenai ini: "This is the fastest, most efficient way to use the symbol handler.", jadi mari kita lakukan itu!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Sebenarnya memulakan simbol dengan MSVC.Perhatikan bahawa ini boleh gagal, tetapi kita mengabaikannya.
        // Tidak ada banyak karya seni sebelumnya, tetapi LLVM secara dalaman nampaknya mengabaikan nilai pengembalian di sini dan salah satu perpustakaan pembersih di LLVM mencetak amaran menakutkan jika ini gagal tetapi pada dasarnya mengabaikannya dalam jangka masa panjang.
        //
        //
        // Satu kes yang sering berlaku untuk Rust ialah perpustakaan standard dan crate di crates.io ini sama-sama mahu bersaing untuk `SymInitializeW`.
        // Perpustakaan standard secara historis ingin menginisialisasi dan membersihkannya sepanjang masa, tetapi sekarang kerana ia menggunakan crate ini, ia bermaksud seseorang akan melakukan inisialisasi terlebih dahulu dan yang lain akan mengambil inisialisasi tersebut.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}