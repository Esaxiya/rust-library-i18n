use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr mengambil panggilan balik yang akan menerima penunjuk dl_phdr_info untuk setiap DSO yang telah dihubungkan ke dalam proses.
    // dl_iterate_phdr juga memastikan bahawa penghubung dinamik terkunci dari awal hingga akhir lelaran.
    // Sekiranya panggilan balik mengembalikan nilai bukan sifar maka lelaran ditamatkan lebih awal.
    // 'data' akan disampaikan sebagai argumen ketiga untuk panggilan balik pada setiap panggilan.
    // 'size' memberikan ukuran dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Kita perlu menguraikan ID binaan dan beberapa data tajuk program asas yang bermaksud bahawa kita juga memerlukan sedikit barang dari spesifikasi ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Sekarang kita harus meniru, sedikit demi sedikit, struktur jenis dl_phdr_info yang digunakan oleh penghubung dinamik fuchsia semasa.
// Chromium juga mempunyai sempadan ABI ini dan juga crashpad.
// Akhirnya kami ingin memindahkan kes-kes ini untuk menggunakan pencarian elf tetapi kami perlu memberikannya dalam SDK dan itu belum dilakukan.
//
// Oleh itu, kami (dan mereka) buntu harus menggunakan kaedah ini yang menyebabkan gandingan erat dengan libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Kami tidak mempunyai cara untuk mengetahui sama ada e_phoff dan e_phnum sah.
    // libc harus memastikan ini untuk kita namun selamat untuk membentuk potongan di sini.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr melambangkan header program ELF 64-bit dalam kesempurnaan seni bina sasaran.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr mewakili tajuk program ELF yang sah dan isinya.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Kami tidak mempunyai cara untuk memeriksa sama ada p_addr atau p_memsz sah.
    // Perpustakaan Fuchsia menguraikan nota terlebih dahulu tetapi oleh kerana berada di sini tajuk ini mesti sah.
    //
    // NoteIter tidak memerlukan data yang mendasari berlaku tetapi ia memerlukan batasan untuk menjadi sah.
    // Kami percaya bahawa libc telah memastikan bahawa ini adalah perkara yang sama bagi kami di sini.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Jenis nota untuk ID binaan.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr mewakili tajuk nota ELF pada tahap akhir sasaran.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Catatan mewakili nota ELF (tajuk + isi).
// Nama itu dibiarkan sebagai potongan u8 kerana tidak selalu dihentikan nol dan rust menjadikannya cukup mudah untuk memeriksa sama ada bait sesuai.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter membolehkan anda melakukan lelaran pada segmen nota dengan selamat.
// Ia akan berakhir sebaik sahaja berlaku ralat atau tidak ada lagi nota.
// Sekiranya anda mengulangi data tidak sah, ia akan berfungsi seolah-olah tidak ada nota yang dijumpai.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Ini adalah fungsi yang tetap bahawa penunjuk dan ukuran yang diberikan menunjukkan julat bait yang sah yang semuanya dapat dibaca.
    // Kandungan bait ini boleh jadi apa-apa tetapi julatnya mesti sah agar selamat.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to aligning 'x' to''-byte alignment andaian 'to' adalah kekuatan 2.
// Ini mengikuti corak standard dalam kod penghuraian ELF C/C ++ di mana (x + hingga, 1)&-to digunakan.
// Rust tidak membiarkan anda menafikan penggunaan jadi saya gunakan
// Penukaran 2-pelengkap untuk mencipta semula.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 menggunakan bilangan bait dari slice (jika ada) dan juga memastikan bahawa potongan akhir diselaraskan dengan betul.
// Sekiranya bilangan bait yang diminta terlalu besar atau slice tidak dapat diselaraskan selepas itu kerana bait yang masih ada tidak mencukupi, Tiada akan dikembalikan dan slice tidak diubah.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Fungsi ini tidak mempunyai invarian yang nyata yang harus dijaga oleh pemanggil selain mungkin bahawa 'bytes' harus diselaraskan untuk prestasi (dan pada beberapa ketepatan seni bina).
// Nilai-nilai dalam medan Elf_Nhdr mungkin tidak masuk akal tetapi fungsi ini tidak memastikan perkara itu.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Ini selamat selagi ada cukup ruang dan kami baru mengesahkan bahawa dalam pernyataan if di atas maka ini tidak seharusnya tidak selamat.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Perhatikan bahawa sice_of: :<Elf_Nhdr>() sentiasa diselaraskan 4-bait.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Periksa sama ada kita sudah sampai ke penghujungnya.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Kami menghantar satu nhdr tetapi kami dengan teliti mempertimbangkan struktur yang dihasilkan.
        // Kami tidak mempercayai namesz atau descsz dan kami tidak membuat keputusan yang tidak selamat berdasarkan jenisnya.
        //
        // Jadi walaupun kita mengeluarkan sampah yang lengkap, kita tetap harus selamat.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Menunjukkan bahawa segmen boleh dilaksanakan.
const PERM_X: u32 = 0b00000001;
/// Menunjukkan bahawa segmen boleh ditulis.
const PERM_W: u32 = 0b00000010;
/// Menunjukkan bahawa segmen dapat dibaca.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Merupakan segmen ELF pada waktu runtime.
struct Segment {
    /// Memberi alamat maya runtime kandungan segmen ini.
    addr: usize,
    /// Memberi ukuran memori kandungan segmen ini.
    size: usize,
    /// Memberi alamat maya modul segmen ini dengan fail ELF.
    mod_rel_addr: usize,
    /// Memberi kebenaran yang terdapat dalam fail ELF.
    /// Kebenaran ini tidak semestinya izin yang ada pada waktu runtime.
    flags: Perm,
}

/// Biarkan satu berulang di Segmen dari DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Merupakan DSF ELF (Objek Berkongsi Dinamik).
/// Jenis ini merujuk data yang disimpan dalam DSO sebenar dan bukannya membuat salinannya sendiri.
struct Dso<'a> {
    /// Penghubung dinamik selalu memberi kita nama, walaupun namanya kosong.
    /// Dalam kes utama yang boleh dilaksanakan, nama ini akan kosong.
    /// Dalam kes objek yang dikongsi, itu adalah nama anak lelaki (lihat DT_SONAME).
    name: &'a str,
    /// Pada Fuchsia hampir semua binari mempunyai ID binaan tetapi ini bukan syarat yang ketat.
    /// Tidak ada cara untuk memadankan maklumat DSO dengan fail ELF sebenar selepas itu jika tidak ada build_id jadi kami menghendaki setiap DSO memilikinya di sini.
    ///
    /// DSO tanpa build_id tidak diambil kira.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Mengembalikan iterator pada Segmen dalam DSO ini.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Kesalahan ini menyandikan masalah yang timbul semasa menguraikan maklumat mengenai setiap DSO.
///
enum Error {
    /// NameError bermaksud bahawa berlaku ralat semasa menukar rentetan gaya C menjadi rentetan rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError bermaksud bahawa kami tidak menemui ID binaan.
    /// Ini mungkin berlaku kerana DSO tidak mempunyai ID binaan atau kerana segmen yang mengandungi ID binaan salah.
    ///
    BuildIDError,
}

/// Panggilan 'dso' atau 'error' untuk setiap DSO yang dihubungkan ke proses oleh penghubung dinamik.
///
///
/// # Arguments
///
/// * `visitor` - Pencetak Dso yang akan mempunyai salah satu kaedah makan yang disebut foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr memastikan bahawa info.name akan menunjuk ke lokasi yang sah.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Fungsi ini mencetak markup simbolis Fuchsia untuk semua maklumat yang terdapat dalam DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}