use core::ffi::c_void;
use core::fmt;

/// Memeriksa timbunan panggilan semasa, melewati semua bingkai aktif ke penutup yang disediakan untuk mengira jejak timbunan.
///
/// Fungsi ini adalah tenaga kerja perpustakaan ini dalam mengira jejak timbunan untuk program.Penutupan yang diberikan `cb` dihasilkan sebagai contoh `Frame` yang mewakili maklumat mengenai bingkai panggilan itu pada timbunan.
/// Penutupan menghasilkan bingkai dengan cara top-down (fungsi yang paling baru disebut fungsi pertama).
///
/// Nilai kembali penutupan adalah petunjuk sama ada jejak belakang harus diteruskan.Nilai pulangan `false` akan menghentikan jejak belakang dan kembali dengan segera.
///
/// Setelah `Frame` diperoleh, anda mungkin ingin memanggil `backtrace::resolve` untuk menukar `ip` (petunjuk petunjuk) atau alamat simbol ke `Symbol` yang mana nama dan/atau nama fail/nombor baris dapat dipelajari.
///
///
/// Perhatikan bahawa ini adalah fungsi tahap rendah dan jika anda ingin, misalnya, menangkap jejak belakang untuk diperiksa kemudian, maka jenis `Backtrace` mungkin lebih sesuai.
///
/// # Ciri-ciri yang diperlukan
///
/// Fungsi ini memerlukan ciri `std` dari `backtrace` crate diaktifkan, dan ciri `std` diaktifkan secara lalai.
///
/// # Panics
///
/// Fungsi ini berusaha untuk tidak pernah panic, tetapi jika `cb` menyediakan panics maka beberapa platform akan memaksa panic berganda untuk membatalkan prosesnya.
/// Beberapa platform menggunakan perpustakaan C yang secara dalaman menggunakan panggilan balik yang tidak dapat dilepaskan, jadi panik dari `cb` dapat memicu proses membatalkan.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // teruskan jejak belakang
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Sama seperti `trace`, hanya tidak selamat kerana tidak diselaraskan.
///
/// Fungsi ini tidak mempunyai penjamin penyegerakan tetapi tersedia apabila ciri `std` crate ini tidak disusun.
/// Lihat fungsi `trace` untuk lebih banyak dokumentasi dan contoh.
///
/// # Panics
///
/// Lihat maklumat mengenai `trace` untuk peringatan tentang panik `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait mewakili satu bingkai jejak belakang, menghasilkan fungsi `trace` crate ini.
///
/// Penutupan fungsi pelacakan akan dihasilkan bingkai, dan bingkai hampir dikirim karena pelaksanaan yang mendasari tidak selalu diketahui hingga waktu berjalan.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Mengembalikan penunjuk arahan semasa bingkai ini.
    ///
    /// Ini biasanya adalah arahan seterusnya untuk dilaksanakan dalam bingkai, tetapi tidak semua pelaksanaan menyenaraikannya dengan ketepatan 100% (tetapi umumnya cukup dekat).
    ///
    ///
    /// Sebaiknya berikan nilai ini ke `backtrace::resolve` untuk mengubahnya menjadi nama simbol.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Mengembalikan penunjuk timbunan semasa bingkai ini.
    ///
    /// Sekiranya backend tidak dapat memulihkan penunjuk tumpukan untuk bingkai ini, penunjuk nol dikembalikan.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Mengembalikan alamat simbol permulaan bingkai fungsi ini.
    ///
    /// Ini akan cuba memundurkan penunjuk arahan yang dikembalikan oleh `ip` ke permulaan fungsi, mengembalikan nilai itu.
    ///
    /// Dalam beberapa kes, bagaimanapun, backend hanya akan mengembalikan `ip` dari fungsi ini.
    ///
    /// Nilai yang dikembalikan kadangkala dapat digunakan jika `backtrace::resolve` gagal pada `ip` yang diberikan di atas.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Mengembalikan alamat asas modul tempat bingkai berada.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Ini perlu didahulukan, untuk memastikan bahawa Miri mengutamakan platform host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // hanya digunakan dalam simbol dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}