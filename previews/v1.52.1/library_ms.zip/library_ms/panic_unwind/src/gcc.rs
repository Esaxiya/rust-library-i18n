//! Pelaksanaan panics disokong oleh libgcc/libunwind (dalam beberapa bentuk).
//!
//! Untuk latar belakang pengendalian pengecualian dan penumpukan susun sila lihat "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) dan dokumen yang dipautkan daripadanya.
//! Ini juga bacaan yang baik:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Ringkasan ringkas
//!
//! Pengendalian pengecualian berlaku dalam dua fasa: fasa pencarian dan fasa pembersihan.
//!
//! Dalam kedua-dua fasa tersebut, pengawal berjalan bingkai susun dari atas ke bawah menggunakan maklumat dari kerangka susun melepas modul proses semasa ("module" di sini merujuk kepada modul OS, iaitu perpustakaan yang dapat dilaksanakan atau dinamik).
//!
//!
//! Untuk setiap bingkai timbunan, ia memanggil "personality routine" yang berkaitan, yang alamatnya juga disimpan di bahagian maklumat bersantai.
//!
//! Dalam fasa pencarian, tugas rutin keperibadian adalah memeriksa objek pengecualian yang dilemparkan, dan memutuskan apakah benda itu harus ditangkap pada bingkai tumpukan itu.Setelah kerangka pengendali dikenal pasti, fasa pembersihan bermula.
//!
//! Dalam fasa pembersihan, penyingkiran menggunakan kembali setiap rutin keperibadian.
//! Kali ini memutuskan kod pembersihan (jika ada) mana yang perlu dijalankan untuk bingkai timbunan semasa.Sekiranya demikian, kawalan dipindahkan ke branch khas dalam badan fungsi, "landing pad", yang memanggil pemusnah, membebaskan memori, dll.
//! Di hujung landas pendaratan, kawalan dipindahkan kembali ke penyambung semula dan menyambung semula.
//!
//! Setelah tumpukan dilepaskan ke tahap kerangka pengendali, berhenti berhenti dan rutin keperibadian terakhir memindahkan kawalan ke blok tangkapan.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Pengecam kelas pengecualian Rust.
// Ini digunakan oleh rutin keperibadian untuk menentukan sama ada pengecualian itu dilancarkan oleh masa kerja mereka sendiri.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-vendor, bahasa
    0x4d4f5a_00_52555354
}

// ID pendaftaran diangkat dari LLVM's TargetLowering::getExceptionPointerRegister() dan TargetLowering::getExceptionSelectorRegister() untuk setiap seni bina, kemudian dipetakan ke nombor pendaftaran DWARF melalui jadual definisi daftar (biasanya<arch>RegisterInfo.td, cari "DwarfRegNum").
//
// Lihat juga http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Kod berikut berdasarkan rutin keperibadian C dan C++ GCC.Untuk rujukan, lihat:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rutin keperibadian EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS menggunakan rutin lalai kerana menggunakan SjLj bersantai.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Jejak belakang di ARM akan memanggil keperibadian sebagai rutin dengan keadaan==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Dalam kes tersebut, kami ingin terus melepaskan timbunan, jika tidak, semua jejak belakang kami akan berakhir pada __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Pencerob DWARF menganggap bahawa_Unwind_Context menyimpan perkara seperti fungsi dan penunjuk LSDA, namun ARM EHABI meletakkannya ke dalam objek pengecualian.
            // Untuk mengekalkan tanda tangan fungsi seperti _Unwind_GetLanguageSpecificData(), yang hanya mengambil penunjuk konteks, rutin keperibadian GCC menyimpan penunjuk ke pengecualian_benda dalam konteks, menggunakan lokasi yang disediakan untuk ARM "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Pendekatan yang lebih berprinsip adalah untuk memberikan definisi lengkap mengenai_Unwind_Context ARM dalam ikatan libunwind kami dan mengambil data yang diperlukan dari sana secara langsung, dengan melewati fungsi keserasian DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI memerlukan rutin keperibadian untuk mengemas kini nilai SP dalam cache penghalang objek pengecualian.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Pada ARM EHABI, rutin keperibadian bertanggung jawab untuk benar-benar melepaskan bingkai tumpukan tunggal sebelum kembali (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // ditakrifkan dalam libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Rutin keperibadian lalai, yang digunakan secara langsung pada kebanyakan sasaran dan secara tidak langsung pada Windows x86_64 melalui SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Pada sasaran x86_64 MinGW, mekanisme melepaskan adalah SEH namun data pengendali bersantai (aka LSDA) menggunakan pengekodan yang serasi dengan GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Rutin keperibadian untuk kebanyakan sasaran kami.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Alamat pengembalian menunjukkan 1 bait setelah arahan panggilan, yang boleh berada dalam julat IP seterusnya dalam jadual julat LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Bingkai pendaftaran maklumat bersantai
//
// Gambar setiap modul mengandungi bahagian maklumat bersantai bingkai (biasanya ".eh_frame").Apabila modul dimasukkan ke dalam proses loaded/unloaded, pelepas mesti diberitahu mengenai lokasi bahagian ini dalam ingatan.Kaedah mencapainya berbeza mengikut platform.
// Pada beberapa (contohnya, Linux), penyekat dapat menemui bahagian maklumat bersantai dengan sendirinya (dengan menghitung secara dinamis modul yang dimuatkan saat ini melalui dl_iterate_phdr() API and finding their ".eh_frame" sections); Yang lain, seperti Windows, memerlukan modul untuk secara aktif mendaftarkan bahagian maklumat bersantai mereka melalui API pemutus.
//
//
// Modul ini mendefinisikan dua simbol yang dirujuk dan dipanggil dari rsbegin.rs untuk mendaftarkan maklumat kami dengan masa berjalan GCC.
// Pelaksanaan timbal balik timbunan (untuk sekarang) ditangguhkan ke libgcc_eh, namun Rust crates menggunakan titik masuk khusus Rust ini untuk mengelakkan pertembungan berpotensi dengan mana-mana masa berjalan GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}