//! Pelaksanaan panics melalui pembongkaran timbunan
//!
//! crate ini adalah implementasi panics di Rust menggunakan "most native" tumpukan mekanisme pelepas platform yang sedang disusun.
//! Ini pada dasarnya dikategorikan kepada tiga baldi pada masa ini:
//!
//! 1. Sasaran MSVC menggunakan SEH dalam fail `seh.rs`.
//! 2. Emscripten menggunakan pengecualian C++ dalam fail `emcc.rs`.
//! 3. Semua sasaran lain menggunakan libunwind/libgcc dalam fail `gcc.rs`.
//!
//! Lebih banyak dokumentasi mengenai setiap pelaksanaan boleh didapati di modul masing-masing.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` tidak digunakan dengan Miri, jadi diamkan amaran.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Objek permulaan runtime Rust bergantung pada simbol-simbol ini, jadi jadikan ia umum.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Sasaran yang tidak menyokong penolakan.
        // - arch=wasm32
        // - os=tiada (sasaran "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Gunakan masa berjalan Miri.
        // Kita masih perlu memuat runtime normal di atas, kerana rustc mengharapkan item lang dari sana dapat ditentukan.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Gunakan masa berjalan sebenar.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler dalam libstd dipanggil apabila objek panic dijatuhkan di luar `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Penangan dalam libstd dipanggil ketika pengecualian asing ditangkap.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Titik masuk untuk meningkatkan pengecualian, hanya perwakilan untuk pelaksanaan platform khusus.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}