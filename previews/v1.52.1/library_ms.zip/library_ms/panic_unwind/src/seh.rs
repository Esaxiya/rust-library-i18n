//! Windows SEH
//!
//! Pada Windows (saat ini hanya di MSVC), mekanisme pengendalian pengecualian lalai adalah Structured Exception Handling (SEH).
//! Ini agak berbeza daripada pengendalian pengecualian berasaskan Dwarf (misalnya, apa yang digunakan platform unix lain) dari segi penyusun dalaman, jadi LLVM diharuskan memiliki banyak sokongan tambahan untuk SEH.
//!
//! Ringkasnya, apa yang berlaku di sini adalah:
//!
//! 1. Fungsi `panic` memanggil fungsi Windows standard `_CxxThrowException` untuk membuang pengecualian seperti C++ , yang mencetuskan proses bersantai.
//! 2.
//! Semua pad pendaratan yang dihasilkan oleh pengkompil menggunakan fungsi keperibadian `__CxxFrameHandler3`, fungsi dalam CRT, dan kod pelepas di Windows akan menggunakan fungsi keperibadian ini untuk melaksanakan semua kod pembersihan pada timbunan.
//!
//! 3. Semua panggilan yang dihasilkan penyusun ke `invoke` mempunyai landasan yang ditetapkan sebagai arahan `cleanuppad` LLVM, yang menunjukkan permulaan rutin pembersihan.
//! Keperibadian (dalam langkah 2, yang ditentukan dalam CRT) bertanggungjawab untuk menjalankan rutin pembersihan.
//! 4. Akhirnya kod "catch" dalam `try` intrinsik (dihasilkan oleh pengkompil) dilaksanakan dan menunjukkan bahawa kawalan harus kembali ke Rust.
//! Ini dilakukan melalui arahan `catchswitch` plus `catchpad` dalam istilah IR LLVM, akhirnya mengembalikan kawalan normal ke program dengan arahan `catchret`.
//!
//! Beberapa perbezaan khusus dari pengendalian pengecualian berasaskan gcc adalah:
//!
//! * Rust tidak mempunyai fungsi keperibadian tersuai, sebaliknya *selalu*`__CxxFrameHandler3`.Selain itu, tidak ada penapisan tambahan yang dilakukan, jadi kami akhirnya menangkap pengecualian C++ yang kelihatan seperti yang kami lemparkan.
//! Perhatikan bahawa membuang pengecualian ke Rust adalah tingkah laku yang tidak ditentukan, jadi ini semestinya baik.
//! * Kami mempunyai beberapa data untuk dihantar melintasi batas yang tidak putus, khususnya `Box<dyn Any + Send>`.Seperti pengecualian Dwarf, dua petunjuk ini disimpan sebagai muatan dalam pengecualian itu sendiri.
//! Di MSVC, bagaimanapun, tidak perlu peruntukan timbunan tambahan kerana timbunan panggilan disimpan sementara fungsi penapis sedang dijalankan.
//! Ini bermaksud bahawa penunjuk dihantar terus ke `_CxxThrowException` yang kemudian dipulihkan dalam fungsi penapis untuk ditulis ke bingkai timbunan `try` intrinsik.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Ini mesti menjadi Pilihan kerana kita dapat mengecualikan pengecualian dengan merujuk dan pemusnahnya dijalankan oleh waktu operasi C++ .
    // Apabila kita mengeluarkan Kotak dari pengecualian, kita harus membiarkan pengecualian dalam keadaan yang sah agar pemusnahnya dapat berjalan tanpa menjatuhkan Kotak dua kali.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Pertama, sebilangan besar definisi jenis.Terdapat beberapa keunikan khusus platform di sini, dan banyak yang disalin secara terang-terangan dari LLVM.Tujuan semua ini adalah untuk melaksanakan fungsi `panic` di bawah melalui panggilan ke `_CxxThrowException`.
//
// Fungsi ini mengambil dua hujah.Yang pertama adalah penunjuk kepada data yang kami sampaikan, yang dalam hal ini adalah objek trait kami.Cukup senang dijumpai!Walau bagaimanapun, yang seterusnya adalah lebih rumit.
// Ini adalah petunjuk kepada struktur `_ThrowInfo`, dan secara amnya hanya bertujuan untuk menggambarkan pengecualian yang dilemparkan.
//
// Pada masa ini definisi [1] jenis ini sedikit berbulu, dan keanehan utama (dan perbezaan dari artikel dalam talian) adalah bahawa pada 32-bit pointer adalah pointer tetapi pada 64-bit pointer dinyatakan sebagai offset 32-bit dari Simbol `__ImageBase`.
//
// Makro `ptr_t` dan `ptr!` dalam modul di bawah digunakan untuk menyatakan ini.
//
// Definisi jenis labirin juga mengikuti apa yang dikeluarkan oleh LLVM untuk operasi seperti ini.Contohnya, jika anda menyusun kod C++ ini di MSVC dan mengeluarkan IR LLVM:
//
//      #include <stdint.h>
//
//      struktur karat_panik {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      batal foo() { rust_panic a = {0, 1};
//          melempar a;}
//
// Itulah hakikatnya yang cuba kita tiru.Sebilangan besar nilai tetap di bawah ini hanya disalin dari LLVM,
//
// Walau apa pun, struktur ini semuanya dibina dengan cara yang serupa, dan ini agak verbose bagi kita.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Perhatikan bahawa kita sengaja mengabaikan peraturan mangling nama di sini: kita tidak mahu C++ tidak dapat menangkap Rust panics dengan hanya menyatakan `struct rust_panic`.
//
//
// Semasa mengubah suai, pastikan rentetan nama jenis sama dengan yang digunakan dalam `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Bait `\x01` yang terkemuka di sini sebenarnya adalah isyarat ajaib untuk LLVM untuk *tidak* menerapkan sebarang gangguan lain seperti awalan dengan watak `_`.
    //
    //
    // Simbol ini adalah vtable yang digunakan oleh `std::type_info` C++ .
    // Objek jenis `std::type_info`, deskriptor jenis, mempunyai penunjuk ke jadual ini.
    // Jenis deskriptor dirujuk oleh struktur C++ EH yang ditakrifkan di atas dan yang kami bina di bawah.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Deskriptor jenis ini hanya digunakan semasa membuang pengecualian.
// Bahagian tangkapan dikendalikan oleh cubaan intrinsik, yang menghasilkan TypeDescriptor sendiri.
//
// Ini baik-baik saja kerana masa berjalan MSVC menggunakan perbandingan rentetan pada nama jenis untuk memadankan TypeDescriptors dan bukannya persamaan penunjuk.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor digunakan sekiranya kod C++ memutuskan untuk menangkap pengecualian dan menjatuhkannya tanpa menyebarkannya.
// Bahagian tangkapan intrinsik cubaan akan menetapkan kata pertama objek pengecualian menjadi 0 sehingga dilewati oleh pemusnah.
//
// Perhatikan bahawa x86 Windows menggunakan konvensyen panggilan "thiscall" untuk fungsi anggota C++ dan bukannya konvensyen panggilan "C" lalai.
//
// Fungsi pengecualian_copy agak istimewa di sini: ia dipanggil oleh runtime MSVC di bawah blok try/catch dan panic yang kami hasilkan di sini akan digunakan sebagai hasil salinan pengecualian.
//
// Ini digunakan oleh runtime C++ untuk menyokong pengecualian menangkap dengan std::exception_ptr, yang tidak dapat kami sokong kerana Box<dyn Any>tidak boleh diklon.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException dilaksanakan sepenuhnya pada bingkai tumpukan ini, jadi tidak perlu memindahkan `data` ke timbunan.
    // Kami hanya meneruskan penunjuk timbunan ke fungsi ini.
    //
    // ManuallyDrop diperlukan di sini kerana kami tidak mahu Pengecualian dijatuhkan ketika berehat.
    // Sebaliknya ia akan dijatuhkan dengan pengecualian_cleanup yang dipanggil oleh runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Ini ... mungkin kelihatan mengejutkan, dan dibenarkan.Pada MSVC 32-bit, penunjuk antara struktur ini hanyalah petunjuk.
    // Pada MSVC 64-bit, bagaimanapun, penunjuk antara struktur agak dinyatakan sebagai ofset 32-bit dari `__ImageBase`.
    //
    // Oleh itu, pada MSVC 32-bit kita dapat menyatakan semua petunjuk ini dalam `statik di atas.
    // Pada MSVC 64-bit, kita mesti menyatakan pengurangan penunjuk dalam statik, yang Rust tidak membenarkan pada masa ini, jadi kita sebenarnya tidak dapat melakukannya.
    //
    // Perkara terbaik seterusnya, adalah dengan mengisi struktur ini pada waktu runtime (panik sudah menjadi "slow path" pula).
    // Jadi di sini kita menafsirkan semula semua medan penunjuk ini sebagai bilangan bulat 32-bit dan kemudian menyimpan nilai yang relevan ke dalamnya (secara atom, kerana panics serentak mungkin berlaku).
    //
    // Secara teknikal, runtime mungkin akan melakukan pembacaan non-atom bidang ini, tetapi secara teori mereka tidak pernah membaca nilai *salah* sehingga tidak boleh terlalu buruk ...
    //
    // Walau apa pun, kita pada dasarnya perlu melakukan sesuatu seperti ini sehingga kita dapat menyatakan lebih banyak operasi dalam statik (dan kita mungkin tidak akan dapat).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Muatan NULL di sini bermaksud kita sampai di sini dari tangkapan (...) __rust_try.
    // Ini berlaku apabila pengecualian asing bukan Rust ditangkap.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Ini diperlukan oleh penyusun untuk wujud (contohnya, itu adalah item lang), tetapi sebenarnya tidak pernah dipanggil oleh penyusun kerana __C_specific_handler atau_except_handler3 adalah fungsi keperibadian yang selalu digunakan.
//
// Oleh itu ini hanyalah rintangan yang membatalkan.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}