# Menyumbang kepada stdarch

`stdarch` crate lebih bersedia menerima sumbangan!Mula-mula anda mungkin ingin memeriksa repositori dan memastikan bahawa ujian lulus untuk anda:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Di mana `<your-target-arch>` adalah sasaran tiga kali lipat seperti yang digunakan oleh `rustup`, misalnya `x86_x64-unknown-linux-gnu` (tanpa `nightly-` sebelumnya atau serupa).
Ingat juga bahawa repositori ini memerlukan saluran Rust setiap malam!
Ujian di atas sebenarnya memerlukan rust malam untuk menjadi lalai pada sistem anda, untuk menetapkan yang menggunakan `rustup default nightly` (dan `rustup default stable` untuk mengembalikan).

Sekiranya salah satu langkah di atas tidak berfungsi, [please let us know][new]!

Selanjutnya anda dapat [find an issue][issues] untuk membantu, kami telah memilih beberapa dengan tag [`help wanted`][help] dan [`impl-period`][impl] yang dapat menggunakan bantuan. 
Anda mungkin paling berminat dengan [#40][vendor], menerapkan semua intrinsik vendor di x86.Isu itu mempunyai beberapa petunjuk yang baik mengenai di mana hendak bermula!

Sekiranya anda mempunyai soalan umum, sila gunakan [join us on gitter][gitter] dan bertanya-tanya!Jangan ragu untuk membuat ping sama ada@BurntSushi atau@alexcrichton dengan soalan.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Cara menulis contoh untuk intrinsik stdarch

Terdapat beberapa ciri yang mesti diaktifkan agar intrinsik yang diberikan dapat berfungsi dengan baik dan contohnya hanya boleh dijalankan oleh `cargo test --doc` apabila fitur tersebut disokong oleh CPU.

Akibatnya, `fn main` lalai yang dihasilkan oleh `rustdoc` tidak akan berfungsi (dalam kebanyakan kes).
Pertimbangkan untuk menggunakan yang berikut sebagai panduan untuk memastikan contoh anda berfungsi seperti yang diharapkan.

```rust
/// # // Kami memerlukan cfg_target_feature untuk memastikan contohnya hanya
/// # // dijalankan oleh `cargo test --doc` apabila CPU menyokong ciri tersebut
/// # #![feature(cfg_target_feature)]
/// # // Kami memerlukan target_feature agar intrinsik berfungsi
/// # #![feature(target_feature)]
/// #
/// # // rustdoc secara lalai menggunakan `extern crate stdarch`, tetapi kami memerlukannya
/// # // `#[macro_use]`
/// # # [macro_use] stdarch crate luaran;
/// #
/// # // Fungsi utama yang sebenarnya
/// # fn main() {
/// #     // Jalankan ini hanya jika `<target feature>` disokong
/// #     jika cfg_feature_enabled! ("<target feature>"){
/// #         // Buat fungsi `worker` yang hanya akan dijalankan jika ciri sasaran
/// #         // disokong dan memastikan bahawa `target_feature` diaktifkan untuk pekerja anda
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         tidak selamat fn worker() {
/// // Tuliskan contoh anda di sini.Fitur intrinsik khusus akan berfungsi di sini!Menjadi liar!
///
/// #         }
///
/// #         { worker(); } tidak selamat
/// #     }
/// # }
```

Sekiranya beberapa sintaks di atas tidak kelihatan biasa, bahagian [Documentation as tests] dari [Rust Book] menerangkan sintaks `rustdoc` dengan cukup baik.
Seperti biasa, jangan ragu untuk [join us on gitter][gitter] dan tanyakan kepada kami jika anda mengalami masalah, dan terima kasih kerana membantu meningkatkan dokumentasi `stdarch`!

# Arahan Ujian Alternatif

Umumnya disarankan agar anda menggunakan `ci/run.sh` untuk menjalankan ujian.
Walau bagaimanapun, ini mungkin tidak berfungsi untuk anda, contohnya jika anda menggunakan Windows.

Dalam kes ini, anda boleh kembali menjalankan `cargo +nightly test` dan `cargo +nightly test --release -p core_arch` untuk menguji penjanaan kod.
Perhatikan bahawa ini memerlukan rantai alat setiap malam untuk dipasang dan agar `rustc` mengetahui mengenai sasaran tiga kali ganda dan CPUnya.
Khususnya anda perlu menetapkan pemboleh ubah persekitaran `TARGET` seperti yang anda lakukan untuk `ci/run.sh`.
Di samping itu anda perlu menetapkan `RUSTCFLAGS` (memerlukan `C`) untuk menunjukkan ciri sasaran, mis `RUSTCFLAGS="-C -target-features=+avx2"`.
Anda juga boleh menetapkan `-C -target-cpu=native` jika "just" berkembang berbanding CPU semasa anda.

Berhati-hatilah bahawa apabila anda menggunakan arahan alternatif ini, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], mis
ujian penjanaan arahan mungkin gagal kerana pembongkar menamakannya secara berbeza, mis
ia mungkin menghasilkan arahan `vaesenc` dan bukannya `aesenc` walaupun mereka berkelakuan sama.
Petunjuk ini juga menjalankan ujian yang lebih sedikit daripada yang biasanya dilakukan, jadi jangan terkejut apabila anda akhirnya meminta-minta beberapa kesalahan mungkin muncul untuk ujian yang tidak tercakup di sini.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






