use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Digunakan untuk memberitahu anotasi `#[assert_instr]` kami bahawa semua intrinsik simd tersedia untuk menguji codegen mereka, kerana ada yang tertutup di belakang `-Ctarget-feature=+unimplemented-simd128` tambahan yang tidak mempunyai setara dengan `#[target_feature]` sekarang.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}