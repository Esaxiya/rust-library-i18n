`core::arch` - Intrinsik khusus seni bina perpustakaan teras Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` menerapkan intrinsik yang bergantung pada seni bina (contohnya SIMD).

# Usage 

`core::arch` tersedia sebagai sebahagian daripada `libcore` dan ia dieksport semula oleh `libstd`.Lebih suka menggunakannya melalui `core::arch` atau `std::arch` daripada melalui crate ini.
Ciri tidak stabil sering terdapat pada Rust setiap malam melalui `feature(stdsimd)`.

Menggunakan `core::arch` melalui crate ini memerlukan Rust setiap malam, dan ia boleh (dan tidak) sering pecah.Satu-satunya kes di mana anda harus mempertimbangkan untuk menggunakannya melalui crate ini adalah:

* jika anda perlu menyusun semula `core::arch` sendiri, misalnya, dengan ciri-ciri sasaran tertentu yang tidak diaktifkan untuk `libcore`/`libstd`.
Note: jika anda perlu menyusunnya semula untuk sasaran yang tidak standard, sila gunakan `xargo` dan susun semula `libcore`/`libstd` yang sesuai daripada menggunakan crate ini.
  
* menggunakan beberapa ciri yang mungkin tidak tersedia walaupun di belakang ciri Rust yang tidak stabil.Kami berusaha memastikannya minimum.
Sekiranya anda perlu menggunakan beberapa ciri ini, buka masalah agar kami dapat memaparkannya di Rust setiap malam dan anda boleh menggunakannya dari sana.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` diedarkan terutamanya di bawah syarat-syarat kedua-dua lesen MIT dan Lesen Apache (Versi 2.0), dengan bahagian-bahagian yang dilindungi oleh pelbagai lesen seperti BSD.

Lihat LICENSE-APACHE, dan LICENSE-MIT untuk maklumat lanjut.

# Contribution

Kecuali anda menyatakan secara jelas, sebarang sumbangan yang sengaja diserahkan untuk dimasukkan ke dalam `core_arch` oleh anda, seperti yang ditentukan dalam lesen Apache-2.0, akan dilesenkan dua kali ganda seperti di atas, tanpa syarat atau syarat tambahan.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












