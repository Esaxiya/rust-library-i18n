//! Ukuqaliswa kwe-panics nge-stack unwinding
//!
//! Le crate ukuqaliswa kwe-panics ku-Rust kusetshenziswa i-"most native" isitaki sokuqaqa indlela yesikhulumi lesi esihlanganiselwa sona.
//! Lokhu kuhlukaniswa ngamabhakede amathathu njengamanje:
//!
//! 1. Izinhloso ze-MSVC zisebenzisa i-SEH kufayela le-`seh.rs`.
//! 2. U-Emscripten usebenzisa okuhlukile kwe-C++ kufayela le-`emcc.rs`.
//! 3. Zonke ezinye izinhloso zisebenzisa i-libunwind/libgcc kufayela le-`gcc.rs`.
//!
//! Imibhalo eminingi mayelana nokuqaliswa ngakunye ingatholakala kwimodyuli efanele.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` ayisetshenziswanga noMiri, ngakho-ke thulisa izexwayiso.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Izinto zokuqalisa zesikhathi sokusebenza se-Rust zincike kulezi zimpawu, ngakho-ke zenze zibe sesidlangalaleni.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Okuqondiwe okungasekeli ukuqaqa.
        // - arch=wasm32
        // - os=none ("bare metal" okuhlosiwe)
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Sebenzisa isikhathi sokusebenza sikaMiri.
        // Sisadinga futhi ukulayisha isikhathi esivamile sokusebenza ngenhla, njengoba i-rustc ilindele ukuthi izinto ezithile ze-lang ezivela lapho zichazwe.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Sebenzisa isikhathi sokusebenza sangempela.
        use real_imp as imp;
    }
}

extern "C" {
    /// Isiphathi ku-libstd esibizwa lapho into ye-panic iphonswa ngaphandle kwe-`catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Isiphathi ku-libstd sabizwa lapho kubanjwa okuhlukile kwangaphandle.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Iphoyinti lokungena lokukhulisa okuhlukile, izithunywa nje ekusetshenzisweni okuqondene nepulatifomu.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}