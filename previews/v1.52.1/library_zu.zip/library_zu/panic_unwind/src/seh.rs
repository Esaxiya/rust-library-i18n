//! Windows SEH
//!
//! Ku-Windows (okwamanje kuphela ku-MSVC), indlela yokuphatha ngokungafani okuzenzakalelayo yi-Structured Exception Handling (SEH).
//! Lokhu kuhluke kakhulu ekuphatheni okwehlukile okwe-Dwarf (isb., Yini amanye amapulatifomu e-unix ayisebenzisayo) maqondana nabahlanganisi be-compiler, ngakho-ke i-LLVM iyadingeka ukuthola ukusekelwa okuhle kwe-SEH.
//!
//! Kafushane nje, okwenzekayo lapha yilokhu:
//!
//! 1. Umsebenzi we-`panic` ubiza umsebenzi ojwayelekile we-Windows `_CxxThrowException` ukuphonsa okuhlukile kwe-C++ , okubangela inqubo yokuqaqa.
//! 2.
//! Onke amaphedi wokufika akhiqizwe ngumhlanganisi asebenzisa umsebenzi wobuntu `__CxxFrameHandler3`, umsebenzi ku-CRT, futhi ikhodi yokuphumula ku-Windows izosebenzisa lo msebenzi wobuntu ukwenza yonke ikhodi yokuhlanza esitaki.
//!
//! 3. Zonke izingcingo ezenziwe ngumhlanganisi eziya ku-`invoke` zinendawo yokubeka esethelwe njengomyalo we-`cleanuppad` LLVM, ekhombisa ukuqala kwendlela yokuhlanza.
//! Ubuntu (esinyathelweni 2, esichazwe ku-CRT) bungumsebenzi wokusebenzisa izindlela zokuhlanza.
//! 4. Ekugcineni ikhodi ye "catch" ku-`try` intrinsic (eyenziwe ngumhlanganisi) iyenziwa futhi ikhombisa ukuthi ukulawula kufanele kubuyele ku-Rust.
//! Lokhu kwenziwa nge-`catchswitch` kanye nomyalo we-`catchpad` ngamagama we-LLVM IR, ekugcineni kubuyisa ukulawula okujwayelekile kuhlelo ngomyalo we-`catchret`.
//!
//! Ukungezwani okuthile okuvela ekuphatheni okwehlukile kwe-gcc yile:
//!
//! * I-Rust ayinakho umsebenzi wobuntu ngokwezifiso, kunalokho *ihlala njalo* i-`__CxxFrameHandler3`.Ngokwengeziwe, akukho ukuhlunga okwengeziwe okwenziwayo, ngakho-ke sigcina ngokubamba noma ikuphi okuhlukile kwe-C++ okwenzeka kufane nohlobo esiluphonsa.
//! Qaphela ukuthi ukuphonsa okuhlukile ku-Rust kungukuziphatha okungachazeki noma kunjalo, ngakho-ke lokhu kufanele kube kuhle.
//! * Sinedatha ethile esizoyidlulisa ngaphesheya komngcele ongashayi eceleni, ikakhulukazi i `Box<dyn Any + Send>`.Njengokuhlukile kwe-Dwarf lezi zikhombisi ezimbili zigcinwa njengomthwalo okhokhelwayo ngaphandle kukodwa.
//! Ku-MSVC, noma kunjalo, asikho isidingo sokwabiwa kwenqwaba eyengeziwe ngoba isitaki sezingcingo sigcinwa ngenkathi kwenziwa imisebenzi yokuhlunga.
//! Lokhu kusho ukuthi izikhombisi zidluliselwa ngqo ku `_CxxThrowException` eziphinde zitholakale ekusebenzeni kwesihlungi ezizobhalwa kuzimele zesitaki se-`try` intrinsic.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Lokhu kudinga ukuthi kube inketho ngoba sibamba okuhlukile ngesethenjwa futhi umbhubhisi wayo wenziwa isikhathi sokusebenza se-C++ .
    // Lapho sikhipha iBhokisi ngaphandle, sidinga ukushiya okuhlukile kusimo esivumelekile ukuthi umbhubhisi wawo asebenze ngaphandle kokuphonsa ibhokisi kabili.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Okokuqala, inqwaba yezincazelo zohlobo.Kunokungajwayelekile okuqondene nepulatifomu lapha, futhi okuningi okukopishwe ngokusobala kusuka ku-LLVM.Inhloso yakho konke lokhu ukusebenzisa umsebenzi we-`panic` ongezansi ngocingo oluya ku-`_CxxThrowException`.
//
// Lo msebenzi uthatha izimpikiswano ezimbili.Esokuqala yisikhombisi sedatha esidlula kuyo, kulokhu into yethu eyi-trait.Kulula ukuthola!Okulandelayo, noma kunjalo, kuyinkimbinkimbi ngokwengeziwe.
// Lesi yisikhombi esakhiweni se-`_ThrowInfo`, futhi imvamisa nje kuhloselwe ukuchaza nje okuhlukile okuphonswayo.
//
// Njengamanje incazelo yalolu hlobo i [1] inoboya obuncane, futhi isimanga esikhulu (nokwehluka kwendatshana eku-inthanethi) ukuthi kuma-32-bit izikhombisi ziyizikhombisi kepha kuma-64-bit izikhombisi zikhonjiswa njengama-32-bit offsets avela Uphawu lwe-`__ImageBase`.
//
// I-`ptr_t` ne-`ptr!` macro kumamojula angezansi zisetshenziselwa ukuveza lokhu.
//
// I-maze yezincazelo zohlobo nayo ilandela eduze lokho okukhishwa yi-LLVM yalolu hlobo lokusebenza.Isibonelo, uma uhlanganisa le khodi ye-C++ ku-MSVC bese ukhipha i-LLVM IR:
//
//      #include <stdint.h>
//
//      isakhiwo se-rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          i-uint64_t x[2];};
//
//      I-foo() { rust_panic a = {0, 1} engenalutho;
//          phonsa a;}
//
// Lokho yilokho esizama ukulingisa.Amanani amaningi ajwayelekile ngezansi akopishwe kusuka ku-LLVM,
//
// Kunoma ikuphi, zonke lezi zakhiwo zakhiwe ngendlela efanayo, futhi ziyisenzo nje ngathi.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Yazi ukuthi ngamabomu siyishaya indiva imithetho yama-mangling lapha: asifuni ukuthi i-C++ ikwazi ukubamba i-Rust panics ngokumane imemezele i-`struct rust_panic`.
//
//
// Lapho uguqula, qiniseka ukuthi intambo yegama lohlobo ifana ncamashi naleyo esetshenziswe ku-`compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // I-byte ehamba phambili ye-`\x01` lapha empeleni iyisiginali yemilingo ku-LLVM ukuze *ingasebenzisi* noma yikuphi okunye ukubambeka njengokuqamba kuqala ngohlamvu lwe-`_`.
    //
    //
    // Lolu phawu yi-vtable esetshenziswa yi-C++ 's `std::type_info`.
    // Izinto zohlobo `std::type_info`, izincazelo zohlobo, zinezikhombi kuleli thebula.
    // Izincazelo zohlobo zikhonjiswe yizinhlaka ze-C++ EH ezichazwe ngenhla nokuthi sizakha ngezansi.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Lesi sichazi sohlobo sisetshenziswa kuphela lapho kuphonsa okuhlukile.
// Ingxenye yokubamba isingathwa yi-try intrinsic, ekhiqiza iTypeDescriptor yayo uqobo.
//
// Lokhu kulungile ngoba isikhathi sokusebenza se-MSVC sisebenzisa ukuqhathanisa kwentambo egameni lohlobo ukufanisa iTypeDescriptors kunokulingana kwesikhombi.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Umbhubhisi usetshenzisiwe uma ikhodi ye-C++ ithatha isinqumo sokuthwebula okuhlukile bese uyilahla ngaphandle kokuyisabalalisa.
// Ingxenye yokubamba ye-try intrinsic izosetha igama lokuqala lento ehlukile ibe ngu-0 ukuze yeqiwe ngumbhubhisi.
//
// Qaphela ukuthi i x86 Windows isebenzisa umhlangano wokushaya we "thiscall" wemisebenzi yamalungu e-C++ esikhundleni somhlangano wokushaya we-"C" ozenzakalelayo.
//
// Umsebenzi we-exception_copy ukhetheke kancane lapha: ubizwa yisikhathi sokusebenza se-MSVC ngaphansi kwe-try/catch block kanye ne-panic esiyikhiqiza lapha izosetshenziswa njengomphumela wekhophi elihlukile.
//
// Lokhu kusetshenziswa isikhathi sokusebenza se-C++ ukusekela ukuthwebula okuhlukile nge-std::exception_ptr, esingakwazi ukuyisekela ngoba i-Box<dyn Any>ayinakuhlanganiswa.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException isebenza ngokuphelele kuloluhlaka lwesitaki, ngakho-ke asikho isidingo sokudlulisela i `data` enqwabeni.
    // Simane sidlulise isikhombi sesitaki kulo msebenzi.
    //
    // I-ManuallyDrop iyadingeka lapha ngoba asifuni ukuthi i-Exception ilahlwe lapho ivulwa.
    // Esikhundleni salokho izokwehliswa yi-exception_cleanup edonswa yisikhathi sokusebenza se-C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Lokhu ... kungabonakala kumangaza, futhi kufanele.Ku-32-bit MSVC izikhombisi eziphakathi kwalesi sakhiwo zimane nje, izikhombisi.
    // Ku-64-bit MSVC, noma kunjalo, izikhombisi eziphakathi kwezakhiwo zichazwa njengama-32-bit offsets kusuka ku `__ImageBase`.
    //
    // Ngenxa yalokho, kuma-32-bit MSVC singamemezela zonke lezi zikhombisi ku-`static`s ngenhla.
    // Ku-64-bit MSVC, kuzofanele siveze ukukhipha izikhombisi ku-statics, i-Rust engakuvumeli njengamanje, ngakho-ke ngeke sikwazi ukukwenza lokho.
    //
    // Into elandelayo ehamba phambili, lapho-ke ukugcwalisa lezi zakhiwo ngesikhathi sokuqalisa (ukwethuka sekuvele kuyi-"slow path" noma kunjalo).
    // Ngakho-ke lapha sichaza kabusha zonke lezi zinkambu zesikhombi njengezinombolo ezingama-32-bit bese sigcina inani elifanele kulo (i-atomically, njengoba i-panics efanayo kungenzeka ingenzeka).
    //
    // Ngokobuchwepheshe isikhathi sokusebenza cishe sizokwenza ukufundwa okungeyona eye-athomu kwalezi zinkambu, kepha ngombono abakaze bafunde inani *elingalungile* ngakho-ke akufanele libe libi kakhulu ...
    //
    // Kunoma ikuphi, ngokuyisisekelo sidinga ukwenza into enjengale size sikwazi ukuveza imisebenzi eminingi kuma-statics (futhi kungenzeka singakwazi).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Ukulayishwa kwe-NULL lapha kusho ukuthi sifike lapha kusuka ekubanjweni kwe (...) kwe __rust_try.
    // Lokhu kwenzeka lapho kubanjwa okuhlukile okungeyona i-Rust yangaphandle.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Lokhu kudingwa ngumhlanganisi ukuthi abekhona (isb., Kuyinto ye-lang), kepha akukaze kubizwe umhlanganisi ngoba __C_specific_handler noma_except_handler3 umsebenzi wobuntu ohlale usetshenziswa.
//
// Ngakho-ke lokhu kuyisiqu nje esikhipha isisu.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}