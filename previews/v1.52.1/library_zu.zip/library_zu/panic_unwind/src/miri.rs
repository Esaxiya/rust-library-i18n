//! Ukususa umoya ku-panics kaMiri.
use alloc::boxed::Box;
use core::any::Any;

// Uhlobo lokukhokhelwa okusatshalaliswa yinjini kaMiri ngokungasiphumulele.
// Kufanele ibe ngosikhombi.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Umsebenzi wangaphandle onikezwe yi-Miri ukuqala ukuqaqa.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Inkokhelo esiyidlulisela ku-`miri_start_panic` kuzoba impikiswano esiyithola ku-`cleanup` ngezansi.
    // Ngakho-ke simane siyibhalishe kanye, ukuze sithole okuthile okulingana nesikhombi.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Buyisela i-`Box` engaphansi.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}