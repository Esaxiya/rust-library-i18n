//! Imodyuli yokusiza ekuphatheni ukubopha kwe-dbghelp ku-Windows
//!
//! Ama-backtraces ku-Windows (okungenani ama-MSVC) anikwa amandla kakhulu nge-`dbghelp.dll` nemisebenzi ehlukahlukene equkethe.
//! Le misebenzi njengamanje ilayishwe *ngamandla* kunokuxhumanisa ne `dbghelp.dll` ngokwezibalo.
//! Lokhu njengamanje kwenziwa umtapo wezincwadi ojwayelekile (futhi kumcabango kuyadingeka lapho), kepha ngumzamo wokusiza ukunciphisa ukuncika kwe-static dll yomtapo wezincwadi ngoba ama-backtraces ngokuvamile ayakhethwa kahle.
//!
//! Lokho kushiwo, i-`dbghelp.dll` cishe ilayisha ngempumelelo ngempumelelo ku-Windows.
//!
//! Qaphela nokho ukuthi njengoba silayisha konke lokhu kusekela ngamandla asikwazi empeleni ukusebenzisa izincazelo ezingavuthiwe ku-`winapi`, kepha kunalokho sidinga ukuzichaza ngokwethu izinhlobo zesikhombi somsebenzi futhi sikusebenzise lokho.
//! Asifuni ngempela ukuba semabhizinisini okuphinda i-winapi, ngakho-ke sinezici ze-Cargo `verify-winapi` eziqinisekisa ukuthi konke ukubopha kufana nalokho okuku-winapi futhi lesi sici sinikwe amandla ku-CI.
//!
//! Ekugcineni, uzokwazi lapha ukuthi i-dll ye-`dbghelp.dll` ayikalayishwa, futhi lokho kuhloswe ngakho njengamanje.
//! Ukucabanga ukuthi singayigcina emhlabeni jikelele futhi siyisebenzise phakathi kwezingcingo eziya ku-API, sigweme i loads/unloads ebizayo.
//! Uma lokhu kuyinkinga kubatholi abavuzayo noma into efana naleyo singawela ibhuloho lapho sifika lapho.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Sebenza cishe nge `SymGetOptions` ne `SymSetOptions` ungekho ku-winapi uqobo.
// Ngaphandle kwalokho lokhu kusetshenziswa kuphela lapho sihlola izinhlobo ezimbili ngokumelene ne-winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Akuchaziwe ku-winapi okwamanje
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Lokhu kuchazwe ku-winapi, kepha akulungile (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Akuchaziwe ku-winapi okwamanje
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Le macro isetshenziselwa ukuchaza isakhiwo se `Dbghelp` esiqukethe ngaphakathi zonke izikhombisi zomsebenzi esingazilayisha.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// I-DLL elayishiwe ye-`dbghelp.dll`
            dll: HMODULE,

            // Isikhombi ngasinye somsebenzi ngamunye esingawusebenzisa
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Ekuqaleni besingakayilayishi i-DLL
            dll: 0 as *mut _,
            // Qala yonke imisebenzi isethwe ku-zero ukusho ukuthi idinga ukulayishwa ngamandla.
            //
            $($name: 0,)*
        };

        // I-typedef elula yohlobo ngalunye lomsebenzi.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Imizamo yokuvula i `dbghelp.dll`.
            /// Ibuyisa impumelelo uma isebenza noma iphutha uma i-`LoadLibraryW` yehluleka.
            ///
            /// I-Panics uma umtapo wezincwadi usuvele ulayishiwe.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Umsebenzi wendlela ngayinye esingathanda ukuyisebenzisa.
            // Lapho ibizwa ukuthi izofunda isikhombisi somsebenzi esifakwe kunqolobane noma iyilayishe bese ibuyisa inani elilayishiwe.
            // Imithwalo igomela ukuthi iphumelele.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // I-proxy elula yokusebenzisa ukukhiya kokuhlanza ekubhekiseni imisebenzi ye-dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Qalisa lonke usizo oludingekayo ukufinyelela imisebenzi ye-`dbghelp` API kusuka kule crate.
///
///
/// Qaphela ukuthi lo msebenzi **uphephile**, ngaphakathi unokuvumelanisa kwawo.
/// Futhi qaphela ukuthi kuphephile ukubiza lo msebenzi kaninginingi ngokuphindayo.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Into yokuqala okudingeka siyenze ukuvumelanisa lo msebenzi.Lokhu kungabizwa ngasikhathi sinye kusuka kweminye imicu noma okuphindwayo ngaphakathi kwentambo eyodwa.
        // Qaphela ukuthi kunzima kunalokho ngoba lokho esikusebenzisa lapha, i-`dbghelp`,*nayo* idinga ukuvumelaniswa nabo bonke abanye abafonayo ku-`dbghelp` kule nqubo.
        //
        // Imvamisa azikho kangako izingcingo eziningi eziya ku-`dbghelp` ngaphakathi kwenqubo efanayo futhi singacabanga ngokuphepha ukuthi yithi kuphela esiyifinyelela.
        // Kukhona, noma kunjalo, omunye umsebenzisi oyinhloko okufanele sikhathazeke ngokuthi ngubani uqobo lwethu, kepha kulabhulali ejwayelekile.
        // Umtapo wezincwadi ojwayelekile we-Rust uncike kule crate yokuxhaswa okwenziwa ngemuva, futhi le crate nayo ikhona ku crates.io.
        // Lokhu kusho ukuthi uma umtapo wezincwadi ojwayelekile uphrinta i-backtrace ye-panic ingahle ibaleke nale crate evela ku-crates.io, idale ukwehlukana.
        //
        // Ukusiza ukuxazulula le nkinga yokuvumelanisa sisebenzisa iqhinga elithile leWindows lapha (ngemuva kwakho konke, umkhawulo oqondene neWindows ngokuvumelanisa).
        // Sakha *iseshini-yendawo* ebizwa nge-mutex ukuvikela le kholi.
        // Inhloso lapha ukuthi umtapo wezincwadi ojwayelekile nale crate akudingeki babelane ngama-API ezingeni le-Rust ukuvumelanisa lapha kepha esikhundleni salokho bangasebenza ngemuva kwezigcawu ukuze baqiniseke ukuthi bayavumelana.
        //
        // Ngaleyo ndlela lapho lo msebenzi ubizwa ngomtapo wezincwadi ojwayelekile noma nge-crates.io singaqiniseka ukuthi i-mutex efanayo iyatholakala.
        //
        // Ngakho-ke konke lokho ukusho ukuthi into yokuqala esiyenzayo lapha ukuthi ngokwethu sakhe i-`HANDLE` eyi-mutex eqanjwe igama ku-Windows.
        // Sivumelanisa kancane neminye imicu yokwabelana ngalo msebenzi ngokukhethekile futhi siqinisekise ukuthi isibambo esisodwa kuphela esakhiwe ngokwesibonelo salo msebenzi.
        // Qaphela ukuthi isibambo asikaze sivalwe uma sesigcinwe emhlabeni jikelele.
        //
        // Ngemuva kokuthi sesiphumile esikhiyeni simane nje siyithole, futhi isibambo sethu se `Init` esisinikezayo sizoba nesibopho sokusiyeka ekugcineni.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Kulungile, phew!Manje njengoba sonke sivumelanisiwe ngokuphepha, ake siqale ukucubungula konke.
        // Okokuqala kufanele siqinisekise ukuthi i `dbghelp.dll` ilayishwe empeleni kule nqubo.
        // Lokhu sikwenza ngamandla ukuze sigweme ukuncika kwe-static.
        // Lokhu ngokomlando kwenzelwe ukusebenzela izingqinamba ezixakile futhi kuhloswe ngazo ukwenza ama-binaries atholakale kalula ngoba lokhu kumane nje kuyinsiza yokulungisa amaphutha.
        //
        //
        // Lapho sesivule i-`dbghelp.dll` sidinga ukubiza eminye imisebenzi yokuqalisa kuyo, futhi lokho kuchazwe kabanzi ngezansi.
        // Senza lokhu kanye kuphela, noma kunjalo, ngakho-ke sine-boolean yomhlaba wonke ekhombisa ukuthi sesiqedile okwamanje noma cha.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Qiniseka ukuthi ifulegi le-`SYMOPT_DEFERRED_LOADS` lisethiwe, ngoba ngokwamadokhumenti e-MSVC uqobo ngalokhu: "This is the fastest, most efficient way to use the symbol handler.", ngakho-ke masikwenze lokho!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Empeleni qalisa izimpawu nge-MSVC.Qaphela ukuthi lokhu kungahluleka, kepha asikunaki.
        // Ayikho ithoni yobuciko bangaphambilini yalokhu ngasikhathi sinye, kepha i-LLVM ngaphakathi ibonakala inganaki inani lokubuyisa lapha futhi omunye wemitapo yolwazi ye-sanitizer e-LLVM iphrinta isexwayiso esesabekayo uma lokhu kwehluleka kepha kungakunaki ngokuhamba kwesikhathi.
        //
        //
        // Icala elilodwa lokhu okuvela kakhulu ku-Rust ukuthi umtapo wezincwadi ojwayelekile nale crate ku-crates.io bobabili bafuna ukuncintisana ne-`SymInitializeW`.
        // Umtapo wezincwadi ojwayelekile ngokomlando ubufuna ukuqala bese uhlanza isikhathi esiningi, kepha manje njengoba usebenzisa le crate kusho ukuthi othile uzofika ekuqaliseni kuqala bese omunye ezothatha lokho kuqalwa.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}