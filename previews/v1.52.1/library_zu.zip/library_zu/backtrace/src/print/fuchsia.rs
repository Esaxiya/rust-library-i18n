use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // i-dl_iterate_phdr ithatha ukubuyela emuva okuzothola i-dl_phdr_info pointer kuyo yonke i-DSO exhunywe kunqubo.
    // I-dl_iterate_phdr futhi iqinisekisa ukuthi isixhumanisi esinamandla sikhiyiwe kusukela ekuqaleni kuze kube sekupheleni kwe-iteration.
    // Uma ukuphinda ushayele ucingo kubuyisa inani elingezona zero i-iteration inqanyulwa ngaphambi kwesikhathi.
    // 'data' izodluliselwa njengengxabano yesithathu ekubuyiselweni emuva kukholi ngayinye.
    // 'size' inika usayizi we-dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Sidinga ukuhlwaya i-ID yokwakha kanye nedatha ethile eyisisekelo yohlelo okusho ukuthi sidinga nezinto ezithile ezivela ku-ELF spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Manje kufanele siphindaphinde, kancane kancane, ukwakheka kohlobo lwe-dl_phdr_info olusetshenziswa isixhumanisi samanje se-fuchsia.
// I-Chromium nayo inayo lo mngcele we-ABI kanye ne-crashpad.
// Ekugcineni singathanda ukuhambisa lawa macala ukuthi asebenzise ukusesha kwe-elf kepha sizodinga ukukunikeza lokho ku-SDK futhi lokho akukenziwa.
//
// Ngakho-ke thina (nabo) sinamathele ekusebenziseni le ndlela eyenza ukuhlangana okuqinile ne-fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Asinayo indlela yokwazi ukuhlola ukuthi i-e_phoff ne-e_phnum zivumelekile yini.
    // i-libc kufanele isiqinisekise lokhu kithina ngakho-ke kuphephile ukwakha ucezu lapha.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// I-Elf_Phdr imele unhlokweni wohlelo lwe-EL-64-bit ku-endianness yezakhiwo eziqondiwe.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// I-Phdr imele unhlokweni ovumelekile we-ELF nokuqukethwe kwayo.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Asinayo indlela yokubheka ukuthi i-p_addr noma i-p_memsz zivumelekile yini.
    // I-libc kaFuchsia ibeka amanothi kuqala kepha ngenxa yokuthi ulapha lezi zihloko kufanele zisebenze.
    //
    // I-NoteIter ayidingi ukuthi idatha eyisisekelo isebenze kepha idinga ukuthi imingcele isebenze.
    // Siyethemba ukuthi i-libc iqinisekise ukuthi lokhu kunjalo kithina lapha.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Uhlobo lwenothi lwama-ID wokwakha.
const NT_GNU_BUILD_ID: u32 = 3;

// I-Elf_Nhdr imele unhlokweni wenothi we-ELF ebunyameni belitshe.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Inothi limelela inothi le-ELF (okuqukethwe unhlokweni +).
// Igama lishiywa njengocezu lwe-u8 ngoba ayihlali inqanyuliwe futhi i-rust yenza kube lula ngokwanele ukubheka ukuthi ama-byte ayafana yini.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// I-NoteIter ikuvumela ukuthi uphephe ngokuphepha ngaphezulu kwengxenye yenothi.
// Iyanqamuka ngokushesha lapho iphutha livela noma kungasekho manothi.
// Uma ulinganisa idatha engavumelekile izosebenza sengathi awekho amanothi atholakele.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Kuyi-invariant yomsebenzi ukuthi i-pointer nosayizi onikeziwe ukhomba uhla oluvumelekile lwama-byte angafundwa wonke.
    // Okuqukethwe yilawa mabhayithi kungaba yinoma yini kodwa ububanzi kumele bubevumelekile ukuze lokhu kuphephe.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// qondanisa_ukuqondanisa i-'x' ne-to'-byte ukuqondanisa kucatshangwa ukuthi i-'to' ingamandla ka-2.
// Lokhu kulandela iphethini ejwayelekile kukhodi yokuhlukanisa i-C/C ++ ELF lapho kusetshenziswa khona (x + to, 1)&-to.
// I-Rust ayikuvumeli ukuthi usebenzise usize ngakho ngisebenzisa
// 2's-complement conversion ukuze uphinde ukwenze lokho.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// i-take_bytes_align4 idla ama-num byte kusuka kucezu (uma likhona) futhi ngokungeziwe iqinisekisa ukuthi ucezu lokugcina luqondaniswe kahle.
// Uma ngabe inani lamabhayithi aceliwe likhulu kakhulu noma ucezu lungakwazi ukwabiwa kabusha ngemuva kwalokho ngenxa yokuthi alanele ngokwanele ama-byte asele akhona, Akukho okubuyiswayo nesilayidi asiguqulwanga.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Lo msebenzi awunazingenisi zangempela oshayayo kufanele aziphakamise ngaphandle kokuthi mhlawumbe i-'bytes' kufanele iqondaniswe nokusebenza (futhi kokunye ukwakheka kwezakhiwo).
// Amanani ezinkambu ze-Elf_Nhdr angahle abe ngumbhedo kepha lo msebenzi awuqinisekisi into enjalo.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Lokhu kuphephile inqobo nje uma kunesikhala esanele futhi sikuqinisekisile nje ukuthi esitatimendeni se-if ngenhla ngakho lokhu akufanele kungaphephi.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Qaphela ukuthi i-sice_of: :<Elf_Nhdr>() ihlala i-4-byte iqondisiwe.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Bheka ukuthi sesifikile yini ekugcineni.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Sikhipha i-nhdr kepha sibheka ngokucophelela ukwakheka okuvelayo.
        // Asithembi i-namesz noma i-descsz futhi asenzi izinqumo ezingaphephile ngokuya ngohlobo.
        //
        // Ngakho-ke noma ngabe sithola udoti ophelele kufanele ngabe siphephile.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Kubonisa ukuthi ingxenye iyasebenza.
const PERM_X: u32 = 0b00000001;
/// Ikhombisa ukuthi isegmenti iyabhalwa.
const PERM_W: u32 = 0b00000010;
/// Kubonisa ukuthi ingxenye ifundeka.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Imelela ingxenye ye-ELF ngesikhathi sokusebenza.
struct Segment {
    /// Inika ikheli elibonakalayo lesikhathi sokusebenza lokuqukethwe kwale ngxenye.
    addr: usize,
    /// Inika usayizi wememori wokuqukethwe kwale ngxenye.
    size: usize,
    /// Inika ikheli elibonakalayo lemodyuli lale ngxenye ngefayela le-ELF.
    mod_rel_addr: usize,
    /// Inika izimvume ezitholakala kufayela le-ELF.
    /// Lezi zimvume akuzona ngempela izimvume ezikhona ngesikhathi sokusebenza kodwa.
    flags: Perm,
}

/// Lets eyodwa iterate over Segment from a DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Imelela i-ELF DSO (Into Eyabiwe Eyabelwe).
/// Lolu hlobo lukhomba idatha egcinwe ku-DSO yangempela kunokwenza ikhophi yayo.
struct Dso<'a> {
    /// Isixhumanisi esinamandla sisinikeza igama noma ngabe igama alinalutho.
    /// Endabeni yokufeza okukhulu leli gama ngeke libe nalutho.
    /// Endabeni yento eyabiwe kuzoba i-soname (bona i-DT_SONAME).
    name: &'a str,
    /// KwiFuchsia cishe wonke ama-binaries anama-ID wokwakha kepha lesi akusona isidingo esiqinile.
    /// Ayikho indlela yokufanisa imininingwane ye-DSO nefayela langempela le-ELF ngemuva kwalokho uma ingekho i-build_id ngakho-ke sidinga ukuthi yonke i-DSO ibe nayo lapha.
    ///
    /// Ama-DSO angenayo i-build_id ayinakwa.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Ibuyisa i-iterator ngaphezulu kwamaSegment kule DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Lawa maphutha afaka izingqinamba ezivela ngenkathi kuhlaziywa imininingwane nge-DSO ngayinye.
///
enum Error {
    /// IgamaError lisho ukuthi kwenzeke iphutha ngenkathi kuguqulwa umucu wesitayela se-C waba yintambo ye rust.
    ///
    NameError(core::str::Utf8Error),
    /// I-Buildiderror isho ukuthi asitholanga i-ID yokwakha.
    /// Lokhu kungenzeka ukuthi kungenxa yokuthi i-DSO ibingenayo i-ID yokwakha noma ngoba ingxenye equkethe i-ID yokwakha ibingalungile.
    ///
    BuildIDError,
}

/// Izingcingo kungaba yi-'dso' noma i-'error' nge-DSO ngayinye exhunywe kunqubo ngesixhumanisi esinamandla.
///
///
/// # Arguments
///
/// * `visitor` - I-DsoPrinter ezoba nenye yezindlela zokudla ezibizwa nge-foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // i-dl_iterate_phdr iqinisekisa ukuthi i-info.name izokhomba endaweni evumelekile.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Lo msebenzi uprinta umaki wokufanekisa we-Fuchsia lonke ulwazi oluqukethwe ku-DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}