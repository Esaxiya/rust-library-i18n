#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Ifomathi yezindlela zangemuva.
///
/// Lolu hlobo lungasetshenziselwa ukuphrinta i-backtrace kungakhathalekile ukuthi i-backtrace uqobo luvelaphi.
/// Uma unohlobo lwe-`Backtrace` ukusetshenziswa kwayo kwe-`Debug` sekuvele kuyayisebenzisa le fomethi yokuphrinta.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Izitayela zokuphrinta esingaziphrinta
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Iphrinta i-backtrace ye-terser equkethe kuphela imininingwane efanelekile
    Short,
    /// Iphrinta ithrekhi yangemuva equkethe lonke ulwazi olungaba khona
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Dala i `BacktraceFmt` entsha ezobhala umphumela ku-`fmt` enikeziwe.
    ///
    /// Impikiswano ye-`format` izolawula isitayela lapho i-backtrace iphrintwa khona, futhi impikiswano ye-`print_path` izosetshenziselwa ukuphrinta izimo ze-`BytesOrWideString` zamagama wamafayela.
    /// Lolu hlobo ngokwalo alwenzi noma yikuphi ukuphrinta kwamagama wamafayela, kepha lokhu kubuyiselwa emuva kuyadingeka ukwenza njalo.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Iphrinta isendlalelo sengemuva eliseduze elizophrintwa.
    ///
    /// Lokhu kuyadingeka kwamanye amapulatifomu ama-backtraces ukuthi afanekiselwe ngokugcwele ngokuhamba kwesikhathi, ngaphandle kwalokho lokhu kufanele kube yindlela yokuqala oyishayayo ngemuva kokwenza i-`BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Yengeza ifreyimu kokukhiphayo kwangemuva.
    ///
    /// Lokhu kuzibophezela kubuyisa isibonelo se-RAII se-`BacktraceFrameFmt` esingasetshenziselwa ukuphrinta empeleni ifreyimu, futhi ekubhujisweni kuzokwengeza isibali sefreyimu.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Iqedela okukhipha emuva.
    ///
    /// Lokhu okwamanje akuna-op kepha kungezwa ukuhambisana kwe-future namafomethi we-backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Njengamanje i-no-op-- kufaka phakathi le hook ukuvumela okungeziwe kwe-future.
        Ok(())
    }
}

/// Ifomathi yohlaka olulodwa lwethrafikhi yangemuva.
///
/// Lolu hlobo lwenziwa ngomsebenzi we-`BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Iphrinta i-`BacktraceFrame` ngale fomathi yozimele.
    ///
    /// Lokhu kuzophrinta okuphindwayo zonke izimo ze-`BacktraceSymbol` ngaphakathi kwe `BacktraceFrame`.
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Iphrinta i-`BacktraceSymbol` ngaphakathi kwe-`BacktraceFrame`.
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: lokhu akukuhle ukuthi asigcini ukuphrinta noma yini
            // ngamagama wefayela okungewona awu-utf8.
            // Ngokujabulisayo cishe yonke into iyi-utf8 ngakho-ke lokhu akufanele kube kubi kakhulu.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Iphrinta i-`Frame` elandelwe okuluhlaza kanye ne-`Symbol`, imvamisa kusuka ngaphakathi kokuphindwayo okungafakwanga kwale crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ingeza ifreyimu eluhlaza kokukhipha emuva kwethrekhi.
    ///
    /// Le ndlela, ngokungafani neyangaphambilini, ithatha izimpikiswano ezingavuthiwe uma kungenzeka ukuthi zivela ezindaweni ezahlukahlukene.
    /// Qaphela ukuthi lokhu kungabizwa kaningi kuhlaka olulodwa.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Ingeza ifreyimu eluhlaza kokukhishwa kwangemuva, kufaka phakathi ulwazi lwekholomu.
    ///
    /// Le ndlela, njengaphambilini, ithatha izimpikiswano ezingavuthiwe uma kungenzeka ukuthi zivela ezindaweni ezahlukahlukene.
    /// Qaphela ukuthi lokhu kungabizwa kaningi kuhlaka olulodwa.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // I-Fuchsia ayikwazi ukufanekisela ngaphakathi kwenqubo ngakho-ke inefomethi ekhethekile engasetshenziselwa ukufanekisela ngokuhamba kwesikhathi.
        // Phrinta lokho esikhundleni sokuphrinta amakheli ngefomethi yethu lapha.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Akunasidingo sokuphrinta ozimele be-"null", empeleni kusho nje ukuthi ukubuyela emuva kwesistimu bekukulangazelela ukulandela emuva kude kakhulu.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Ukwehlisa usayizi we-TCB endaweni ebekiwe kaSgx, asifuni ukusebenzisa ukusebenza kokuxazululwa kwezimpawu.
        // Esikhundleni salokho, singaphrinta okungasetshenziswanga kwekheli lapha, elingafakwa kumephu kamuva ukulungisa umsebenzi.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Phrinta inkomba yefreyimu kanye nesikhombisi sokuzikhethela sohlaka.
        // Uma singaphezu kophawu lokuqala lwalesi sakhiwo yize simane siphrinta indawo emhlophe efanelekile.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Okulandelayo bhala igama lophawu, usebenzisa ukufomatha okunye ukuthola eminye imininingwane uma siyi-backtrace ephelele.
        // Lapha siphatha nezimpawu ezingenagama,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Futhi ekugcineni, phrinta inombolo ye-filename/line uma ikhona.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ziphrintiwe emigqeni ngaphansi kwegama lophawu, ngakho-ke phrinta indawo emhlophe efanelekile ukuhlunga ukuziqondanisa kwesokudla nathi.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Thumela ekubizweni kwethu kwangaphakathi ukuphrinta igama lefayela bese uprinta inombolo yolayini.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Faka inombolo yekholomu, uma ikhona.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Sinakekela kuphela uphawu lokuqala lohlaka
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}