use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Ukumelelwa kwe-backtrace ephethwe futhi equkethwe nguwe.
///
/// Lesi sakhiwo singasetshenziswa ukuthatha i-backtrace ezindaweni ezahlukahlukene kuhlelo futhi kamuva isetshenziselwe ukuhlola ukuthi i-backtrace yayiyini ngaleso sikhathi.
///
///
/// `Backtrace` isekela ukuphrinta okuhle kwama-backtraces ngokusebenzisa ukuqaliswa kwe-`Debug`.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Amafreyimu lapha afakwe kuhlu kusuka phezulu kuye phansi kwesitaki
    frames: Vec<BacktraceFrame>,
    // Inkomba esikholelwa ukuthi iyisiqalo sangempela sangemuva, sishiya ozimele abanjengo-`Backtrace::new` no-`backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Uhlobo oluthathiwe lozimele ngemuva.
///
/// Lolu hlobo lubuyiselwa njengohlu oluvela ku-`Backtrace::frames` futhi lumele ifreyimu eyodwa yesitaki ku-backtrace ebanjiwe.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Uhlobo oluthathiwe lophawu ngemuva.
///
/// Lolu hlobo lubuyiselwa njengohlu oluvela ku-`BacktraceFrame::symbols` futhi lumele imethadatha yesimbuli ku-backtrace.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Ibamba i-backtrace ezindaweni zokubiza zalo msebenzi, ibuyisa isethulo esiphethwe.
    ///
    /// Lo msebenzi ulusizo ukumela i-backtrace njengento ku-Rust.Leli nani elibuyisiwe lingathunyelwa kuyo yonke imicu bese liphrintwa kwenye indawo, futhi inhloso yaleli nani ukuba uqobo luqukethwe ngokuphelele.
    ///
    /// Qaphela ukuthi kwamanye amapulatifomu ukuthola i-backtrace ephelele nokuyixazulula kungabiza kakhulu.
    /// Uma izindleko ziziningi kakhulu kuhlelo lwakho lokusebenza kunconywa ukuthi esikhundleni salokho usebenzise i-`Backtrace::new_unresolved()` evikela isinyathelo sokuxazulula izimpawu (esivame ukuthatha isikhathi eside kakhulu) futhi sivumele ukuhlehlisa lokho kusuku olulandelayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ufuna ukwenza isiqiniseko sokuthi kunohlaka lapha oluzosuswa
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Ifana ne-`new` ngaphandle kokuthi lokhu akuxazululi noma yiziphi izimpawu, lokhu kumane kuthathe i-backtrace njengohlu lwamakheli.
    ///
    /// Ngokuhamba kwesikhathi umsebenzi we `resolve` ungabizwa ukuxazulula lezi zimpawu zangemuva zibe ngamagama afundekayo.
    /// Lo msebenzi ukhona ngoba inqubo yokulungisa kwesinye isikhathi ingathatha isikhathi esiningi kanti noma yikuphi ukubuyela emuva okukodwa kungahle kungaphrinteki kuphela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // awekho amagama ezimpawu
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // amagama ezimpawu manje akhona
    /// ```
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    ///
    #[inline(never)] // ufuna ukwenza isiqiniseko sokuthi kunohlaka lapha oluzosuswa
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Ibuyisa ozimele kusukela lapho kuthwalwa khona la ngemuva.
    ///
    /// Ukufakwa kokuqala kwalesi slice kungenzeka kube umsebenzi `Backtrace::new`, futhi ifreyimu yokugcina kungenzeka ukuthi iyinto ethile mayelana nokuthi le ntambo noma umsebenzi oyinhloko uqale kanjani.
    ///
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Uma ngabe lo muva wangemuva wenziwa kusuka ku-`new_unresolved` khona-ke lo msebenzi uzoxazulula wonke amakheli asemuva emuva kumagama abo angokomfanekiso.
    ///
    ///
    /// Uma ngabe lokhu kubuyela emuva kuxazululwe ngaphambilini noma kwenziwa nge-`new`, lo msebenzi awenzi lutho.
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Kuyafana ne `Frame::ip`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Kuyafana ne `Frame::symbol_address`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Kuyafana ne `Frame::module_base_address`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Ibuyisa uhlu lwezimpawu oluhambisana nalo luhlaka.
    ///
    /// Imvamisa kunophawu olulodwa kuphela kuhlaka ngalunye, kepha kwesinye isikhathi uma inani lemisebenzi lifakwe kuhlaka olulodwa kuzobuyiselwa izimpawu eziningi.
    /// Uphawu lokuqala olufakwe kuhlu yi-"innermost function", kanti uphawu lokugcina lungaphandle kakhulu (oshaye ucingo lokugcina).
    ///
    /// Qaphela ukuthi uma ngabe lolu luhlaka luqhamuka emuva emuva okungasonjululwanga lokho kuzobuyisa uhlu olungenalutho.
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Kuyafana ne `Symbol::name`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Kuyafana ne `Symbol::addr`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Kuyafana ne `Symbol::filename`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Kuyafana ne `Symbol::lineno`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Kuyafana ne `Symbol::colno`
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Lapho siphrinta izindlela sizama ukuhlubula i-cwd uma ikhona, ngaphandle kwalokho simane siphrinte indlela njengoba injalo.
        // Qaphela ukuthi nathi sikwenza lokhu kuphela ngefomethi emfushane, ngoba uma igcwele kungenzeka ukuthi sifuna ukuphrinta konke.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}