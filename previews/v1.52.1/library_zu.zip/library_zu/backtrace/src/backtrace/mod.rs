use core::ffi::c_void;
use core::fmt;

/// Ihlola isitaki sezingcingo samanje, idlulisa wonke amafreyimu asebenzayo ekuvaleni okunikeziwe ukubala umkhondo wesitaki.
///
/// Lo msebenzi uwukusebenza kahle kwalomtapo wolwazi ekubaleni umkhondo wesitaki sohlelo.Ukuvalwa okunikeziwe i-`cb` kuvezwe izimo ze-`Frame` ezimele imininingwane mayelana nalelo luhlaka lwezingcingo esitaki.
/// Ukuvalwa kuvezwe ozimele ngendlela ephezulu (phansi esanda kubizwa ngokuthi imisebenzi kuqala).
///
/// Inani lokubuyisa lokuvalwa liyinkomba yokuthi ukubuyela emuva kufanele kuqhubeke.Inani lokubuyisa le-`false` lizonqamula umugqa ongemuva bese libuya ngokushesha.
///
/// Lapho nje i-`Frame` isitholakele uzofuna ukubiza i-`backtrace::resolve` ukuguqula i-`ip` (i-pointer pointer) noma ikheli lesimbuli libe yi-`Symbol` lapho igama kanye/noma igama lefayela/inombolo yomugqa ingafundwa.
///
///
/// Qaphela ukuthi lokhu kungumsebenzi osezingeni eliphansi uma ufuna, ngokwesibonelo, ukuthwebula ithrekhi yangemuva ezohlolwa ngokuhamba kwesikhathi, uhlobo lwe `Backtrace` lungahle lufaneleke.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
/// # Panics
///
/// Lo msebenzi ulwela ukungalokothi ube yi-panic, kepha uma i-`cb` inikeze i-panics amanye amapulatifomu azophoqa i-panic ephindwe kabili ukukhipha inqubo.
/// Amanye amapulatifomu asebenzisa umtapo wezincwadi we-C osebenzisa ngaphakathi izingcingo ezingavuleki ngaphakathi, ngakho-ke ukwethuka okuvela ku `cb` kungadala inqubo yokukhipha isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // qhubeka nokuhlehlela emuva
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Ifana ne-`trace`, kuphela engaphephile njengoba ingavumelanisiwe.
///
/// Lo msebenzi awunawo ama-guarantee wokuvumelanisa kepha uyatholakala lapho isici se-`std` sale crate singahlanganiswa.
/// Bona umsebenzi we `trace` ukuthola eminye imibhalo nezibonelo.
///
/// # Panics
///
/// Bona imininingwane ku-`trace` yama-caveats nge-`cb` panicking.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// I-trait emele ifreyimu eyodwa ye-backtrace, inikezwe umsebenzi we-`trace` wale crate.
///
/// Ukuvalwa komsebenzi wokulandela umkhondo kuzonikezwa ozimele, futhi ifreyimu icishe ithunyelwe njengoba ukuqaliswa okuyisisekelo kungaziwa njalo kuze kube isikhathi sokuqalisa.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Ibuyisa isikhombisi semiyalo samanje salesi sakhiwo.
    ///
    /// Lokhu imvamisa kuyimiyalo elandelayo yokwenza kwifreyimu, kepha hhayi konke ukuqalisa ukukufaka lokhu ngokunemba okungu-100% (kepha ngokuvamile kusondele kakhulu).
    ///
    ///
    /// Kunconywa ukudlulisa leli nani liye ku-`backtrace::resolve` ukuliguqula libe igama lophawu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Ibuyisa isikhombisi sesitaki samanje sale freyimu.
    ///
    /// Esimweni lapho i-backend ingakwazi ukuthola i-pointer yesitaki yalesi sakhiwo, i-pointer null iyabuyiselwa.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Ibuyisa ikheli lophawu lokuqala lohlaka lomsebenzi.
    ///
    /// Lokhu kuzozama ukubuyisela emuva isikhombisi semiyalo esibuyiswe ngu-`ip` ekuqaleni komsebenzi, sibuyise lelo nani.
    ///
    /// Kwezinye izimo, noma kunjalo, ukubuyela emuva kuzovele kubuyise i-`ip` kusuka kulo msebenzi.
    ///
    /// Inani elibuyisiwe kwesinye isikhathi lingasetshenziswa uma i-`backtrace::resolve` yehlulekile ku-`ip` enikezwe ngenhla.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Ibuyisa ikheli lesisekelo le-module okuluhlaka lwayo.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Lokhu kudinga ukuza kuqala, ukuqinisekisa ukuthi uMiri ubekwa phambili kunendawo yesikhulumi
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // isetshenziswe kuphela ekufanekiseni kwe-dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}