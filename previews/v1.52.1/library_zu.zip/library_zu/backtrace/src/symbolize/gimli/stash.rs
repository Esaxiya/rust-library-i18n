// isetshenziswe kuphela ku-Linux njengamanje, ngakho-ke vumela ikhodi efile kwenye indawo
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Isabeluli senkundla esilula sama-byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Kwabela i-buffer yosayizi ocacisiwe bese kubuyisa ireferensi engaguquguquka kuyo.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // UKUPHEPHA: lo ukuphela komsebenzi owake wakha okuguqukayo
        // ireferensi ye `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // UKUPHEPHA: asilokothi sisuse izinto ku-`self.buffers`, ngakho-ke ireferensi
        // kudatha engaphakathi kwanoma iyiphi i-buffer izophila inqobo nje uma i-`self` iphila.
        &mut buffers[i]
    }
}