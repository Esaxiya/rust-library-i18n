//! Ukusekelwa kokufanekiselwa kusetshenziswa i-`gimli` crate ku-crates.io
//!
//! Lokhu ukuqaliswa kokufanekisela okuzenzakalelayo kwe-Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // Isikhathi sempilo esimile kungamanga ukuqamba ngokuntuleka kokusekelwa kokuzimela okuzimele.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Guqulela esikhathini sokuphila esimile ngoba izimpawu kufanele ziboleke kuphela i-`map` ne-`stash` futhi sizigcina ngezansi.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Ngokulayisha imitapo yolwazi yemvelo ku Windows, bona ingxoxo ethile ku rust-lang/rust#71060 ngamasu ahlukahlukene lapha.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Imitapo yolwazi ye-MinGW njengamanje ayisekeli i-ASLR (rust-lang/rust#16514), kepha ama-DLL asengathunyelwa kwenye indawo esikhaleni.
            // Kubukeka sengathi amakheli emininingwana yokulungisa iphutha konke kufana nokuthi lo mtapo wolwazi ulayishwe ku-"image base" yawo, okuyinkambu esezihlokweni zefayela le-COFF.
            // Njengoba lokhu kungukuthi i-debuginfo ibonakala ifaka kuhlu sidlulisa itafula lezimpawu namakheli wesitolo njengokungathi umtapo wezincwadi ulayishwe ku-"image base" futhi.
            //
            // Umtapo wezincwadi kungenzeka ungalayishwa ku "image base", noma kunjalo.
            // (mhlawumbe kukhona okunye okungalayishwa lapho?) Yilapho inkambu ye `bias` iqala khona ukusebenza, futhi sidinga ukuthola inani le `bias` lapha.Ngeshwa yize kungacaci ukuthi ungakuthola kanjani lokhu kusuka kwimodyuli elayishiwe.
            // Esinakho, noma kunjalo, ikheli langempela lomthwalo i-(`modBaseAddr`).
            //
            // Njengokuphuma kancane okwamanje sifaka imephu kufayela, sifunde imininingwane yeheda yefayela, bese ulahla imephu.Lokhu kumoshile ngoba mhlawumbe sizovula kabusha imephu kamuva, kepha lokhu kufanele kusebenze kahle ngokwanele okwamanje.
            //
            // Lapho sesinayo i-`image_base` (indawo yokulayisha oyifunayo) kanye ne-`base_addr` (indawo yangempela yokulayisha) singagcwalisa i-`bias` (umehluko phakathi kwangempela nokufunwayo) bese ikheli elibekiwe lesigaba ngasinye yi-`image_base` ngoba yilokho okushiwo yifayela.
            //
            //
            // Okwamanje kubonakala sengathi ngokungafani ne-ELF/MachO singenza ingxenye eyodwa kulabhulali ngayinye, sisebenzisa i-`modBaseSize` njengosayizi wonke.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS isebenzisa ifomethi yefayela leMach-O futhi isebenzisa ama-API aqondene ne-DYLD ukulayisha uhlu lwemitapo yolwazi eyingxenye yohlelo lokusebenza.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Landa igama lalabhulali elihambelana nendlela yokuthi ungalilayisha kuphi.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Layisha unhlokweni wesithombe wale labhulali bese unikezela ku-`object` ukudlulisa yonke imiyalo yokulayisha ukuze sikwazi ukuthola zonke izingxenye ezibandakanyekile lapha.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Hlukanisa izingxenye bese ubhalisa izifunda ezaziwayo zamasegmenti esiwatholayo.
            // Ngokwengeziwe qopha izingxenye zemibhalo yombhalo wolwazi ukuze uzocubungulwa kamuva, bona amazwana ngezansi.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Nquma i "slide" yalomtapo wezincwadi ogcina ungukuchema esikusebenzisayo ukuthola ukuthi kulayishwa kuphi kwimemori.
            // Lokhu kancane ukubalwa okuxakile nokho futhi kungumphumela wokuzama izinto ezimbalwa endle ubone ukuthi yini okunamathela.
            //
            // Umqondo ojwayelekile ngukuthi i `bias` kanye nesigaba sika `stated_virtual_memory_address` sizoba lapho kusendaweni yekheli langempela ingxenye ehlala kuyo.
            // Enye into esithembele kuyo kepha ukuthi ikheli langempela lisusa i `bias` yinkomba yokubheka etafuleni lezimpawu naku-debuginfo.
            //
            // Kuyavela nokho ukuthi kwimitapo yolwazi elayishwe uhlelo lezi zibalo azilungile.Okwenziwa ngokwendabuko, noma kunjalo, kubonakala kulungile.
            // Ukuphakamisa umqondo othile emthonjeni we-LLDB kunokukodwa okukhethekile kwesigaba sokuqala se-`__TEXT` esilayishwe kusuka ku-offset 0 yefayela ngosayizi we-nonzero.
            // Nganoma yisiphi isizathu lapho lokhu kukhona kubonakala sengathi kusho ukuthi ithebula lezimpawu lihlobene nesilayidi se-vmaddr somtapo wezincwadi.
            // Uma *ingekho* itafula lezimpawu lihlobene nesilayidi se-vmaddr kanye nekheli lesigaba esishiwo.
            //
            // Ukusingatha lesi simo uma *singatholi* isigaba sombhalo kufayela elisuselwe ku-zero bese sikhuphula ukwenzelela ngekheli elishiwo lezigaba zombhalo bese sinciphisa nawo wonke amakheli ashiwo ngaleyo mali.
            //
            // Ngaleyo ndlela itafula lezimpawu lihlala livela ngokuhlobene nenani lokukhetha lomtapo wolwazi.
            // Lokhu kubonakala kunemiphumela efanele yokufanekisa ngethebula lezimpawu.
            //
            // Ngokwethembeka angiqiniseki ngokuphelele ukuthi lokhu kulungile noma uma kukhona okunye okufanele kukhombise ukuthi ungakwenza kanjani lokhu.
            // Okwamanje yize lokhu kubonakala kusebenza kahle ngokwanele i-(?) futhi kufanele ngaso sonke isikhathi sikwazi ukukuthinta lokhu ngokuhamba kwesikhathi uma kunesidingo.
            //
            // Ngeminye imininingwane bheka i #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Enye i Unix (isb
        // I-Linux) amapulatifomu asebenzisa i-ELF njengefomethi yefayela lezinto futhi isebenzisa i-API ebizwa nge-`dl_iterate_phdr` ukulayisha imitapo yolwazi yendabuko.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` kufanele kube izikhombisi ezivumelekile.
        // `vec` kufanele kube yisikhombi esivumelekile ku-`std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ayisekeli ngokwendabuko imininingwane yokulungisa iphutha, kepha uhlelo lokwakha luzobeka imininingwane yokulungisa iphutha endleleni `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Konke okunye kufanele kusebenzise i-ELF, kepha akwazi ukuthi alayishe kanjani imitapo yolwazi yendabuko.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Yonke imitapo yolwazi eyabiwayo eyaziwayo elayishiwe.
    libraries: Vec<Library>,

    /// Isilondolozi samamephu lapho sigcina khona imininingwane yemifino ehlukanisiwe.
    ///
    /// Lolu hlu lunamandla amisiwe esikhathi salo lonke sokuphila olungakhuphuki.
    /// Isici se-`usize` sepheya ngalinye liyinkomba ku-`libraries` ngaphezulu lapho i-`usize::max_value()` imele ukwenziwa okwenzekayo njengamanje.
    ///
    /// I-`Mapping` yimininingwane ehambisanayo ehlukanisiwe.
    ///
    /// Qaphela ukuthi lokhu empeleni kuyinqolobane ye-LRU futhi sizobe sigudluza izinto lapha njengoba sifanekisela amakheli.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Izingxenye zalo mtapo wolwazi zilayishwe kwimemori, nokuthi zilayishwa kuphi.
    segments: Vec<LibrarySegment>,
    /// I "bias" yalomtapo wezincwadi, imvamisa lapho ilayishwa khona kwimemori.
    /// Leli xabiso lengezwa kukheli ngalinye lesigaba esishiwo ukuthola ikheli langempela lememori ingxenye elayishwe kulo.
    /// Ngokwengeziwe lokhu kubandlululwa kukhishiwe kumakheli wangempela wememori kuya kunkomba ku-debuginfo kanye netafula lezimpawu.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Ikheli elishiwo lalesi sigaba kufayela lezinto.
    /// Lokhu akulona lapho ingxenye ilayishwa khona, kepha kunalokho leli kheli kanye ne-`bias` yelabhulali equkethe lapho ungayithola khona.
    ///
    stated_virtual_memory_address: usize,
    /// Usayizi wengxenye ye-ths kwimemori.
    len: usize,
}

// akuphephile ngoba lokhu kuyadingeka ukuthi kuvumelaniswe ngaphandle
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // akuphephile ngoba lokhu kuyadingeka ukuthi kuvumelaniswe ngaphandle
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Isilondolozi esincane kakhulu, esilula kakhulu se-LRU semephu yokulungiswa kwemininingwane.
        //
        // Izinga lokushaya kufanele libe phezulu kakhulu, ngoba isitaki esijwayelekile asiweli phakathi kwemitapo yolwazi eminingi eyabiwe.
        //
        // Izakhiwo ze `addr2line::Context` zibiza kakhulu ukuzakha.
        // Izindleko zayo kulindeleke ukuthi zincishiswe yimibuzo elandelayo ye-`locate`, esebenzisa izakhiwo ezakhiwe lapho kwakhiwa i-`addr2line: : Context`s ukuthola ama-speedups amahle.
        //
        // Ukube besingenayo le nqolobane, lokho kuncishiswa kwemali bekungeke kwenzeke, futhi ukufanekisela okwasemuva kungaba yi-ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Okokuqala, hlola ukuthi ngabe le `lib` inesigaba esithile esiqukethe i-`addr` (esingatha ukufuduswa).Uma leli sheke lidlula lapho singaqhubeka ngezansi futhi empeleni sihumushe ikheli.
                //
                // Qaphela ukuthi sisebenzisa i-`wrapping_add` lapha ukugwema ukuhlolwa okuchichimayo.Kubonakele endle ukuthi ukubalwa kwe-SVMA + bias kuchichima.
                // Kubukeka kuyinto exakile engeke yenzeke kepha ayikho imali enkulu esingayenza ngayo ngaphandle kokuthi ungazinaki lezo zingxenye ngoba kungenzeka zikhomba emkhathini.
                //
                // Lokhu kwavela ngo-rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Manje njengoba sesazi ukuthi i-`lib` iqukethe i-`addr`, sesingahlehla ngokuchema nokuthola ikheli le-virutal memory elishiwoyo.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Okuhlukile: ngemuva kwalesi simiso kuqeda ngaphandle kokubuyisa kusenesikhathi
        // kusuka ephutheni, ukufakwa kwesilondolozi sale ndlela kuku-index 0.

        if let Some(idx) = idx {
            // Lapho ukwenza imephu sekuvele kunqolobane, kuhambise ngaphambili.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Lapho ukwenza imephu kungekho kunqolobane, yakha imephu entsha, kufake ngaphambili kwesilondolozi, bese uxosha okufakwe kunqolobane endala kakhulu uma kunesidingo.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ungavuzi impilo ye `'static`, qiniseka ukuthi ikhethelwe thina uqobo
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Nweba isikhathi sempilo ye `sym` siye ku `'static` ngoba ngeshwa siyadingeka lapha, kepha kuphuma njalo njengesethenjwa ngakho-ke akukho okubhekiswa kukho okufanele kuqhutshekwe ngale kwaloluhlaka noma kunjalo.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Ekugcineni, thola imephu efakwe kunqolobane noma udale imephu entsha yaleli fayela, bese uhlola imininingwane ye-DWARF ukuthola i-file/line/name yaleli kheli.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Sikwazile ukuthola imininingwane yohlaka lwalesi simboli, futhi ifreyimu ka-`addr2line` ngaphakathi inemininingwane ye-nitty gritty.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Ayikwazanga ukuthola imininingwane yokulungisa iphutha, kepha siyitholile kuthebula lezimpawu ze-elf esebenzayo.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}