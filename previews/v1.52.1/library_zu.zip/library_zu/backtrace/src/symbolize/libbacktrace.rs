//! Isu lokufanekisa lisebenzisa ikhodi yokuhlaziya ye-DWARF ku-libbacktrace.
//!
//! Umtapo wezincwadi we-libbacktrace C, ovame ukusatshalaliswa nge-gcc, awusekeli nje kuphela ukudala i-backtrace (esingayisebenzisi empeleni) kepha futhi kufanekisela ukubuyela emuva nokuphatha imininingwane yokulungisa iphutha emifushane ngezinto ezinjengezinhlaka ezibekiwe kanye nokuthi yini.
//!
//!
//! Lokhu kuyinkimbinkimbi ngenxa yezinkinga eziningi ezahlukahlukene lapha, kepha umqondo oyisisekelo ngukuthi:
//!
//! * Okokuqala sibiza i `backtrace_syminfo`.Lokhu kuthola imininingwane yezimpawu kusuka etafuleni lezimpawu ezinamandla uma sikwazi.
//! * Ngokulandelayo sibiza i-`backtrace_pcinfo`.Lokhu kuzohlwaya amatafula e-debuginfo uma etholakala futhi kusivumele ukuthi siphinde sithole imininingwane emayelana nozimele abaphakathi kolayini, amagama wamafayela, izinombolo zomugqa, njll.
//!
//! Kunokukhohlisa okuningi ngokufaka amatafula amancane ku-libbacktrace, kepha ngethemba ukuthi akusona isiphelo somhlaba futhi kucace ngokwanele lapho ufunda ngezansi.
//!
//! Leli isu lokufanekisa lokuzenzakalelayo lamapulatifomu angewona ama-MSVC nama-non-OSX.Ku-libstd yize leli kuyisu elizenzakalelayo le-OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Uma kunokwenzeka khetha igama le-`function` elivela ku-debuginfo futhi ngokujwayelekile linganemba kakhudlwana kozimele abaphakathi kolayini ngokwesibonelo.
                // Uma lokho kungekho yize ubuyela emuva egameni lethebula lezimpawu elichazwe ku-`symname`.
                //
                // Qaphela ukuthi kwesinye isikhathi i-`function` ingazizwa inembe ngandlela thile, ngokwesibonelo ukufakwa kuhlu njenge-`try<i32,closure>` isntead ye `std::panicking::try::do_call`.
                //
                // Akucaci kahle ukuthi kungani, kepha lilonke igama le `function` libonakala linembe kakhudlwana.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ungenzi lutho okwamanje
}

/// Uhlobo lwesikhombi se `data` lidluliselwe ku-`syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Lapho le callback icelwe kusuka ku-`backtrace_syminfo` lapho siqala ukuxazulula siqhubeka ngokushayela i-`backtrace_pcinfo`.
    // Umsebenzi we-`backtrace_pcinfo` uzobheka imininingwane yokulungisa iphutha futhi ucabangele ukwenza izinto njengokuthola imininingwane ye-file/line kanye nohlaka olubekiwe.
    // Qaphela yize i-`backtrace_pcinfo` ingahluleka noma ingenzi okuningi uma ingekho imininingwane yokulungisa iphutha, ngakho-ke uma lokho kwenzeka sinesiqiniseko sokubiza ukubuyela emuva okungenani ngophawu olulodwa oluvela ku-`syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Uhlobo lwesikhombi se `data` lidluliselwe ku-`pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// I-libbacktrace API isekela ukudala isimo, kepha ayisekeli ukubhubhisa izwe.
// Ngokwami ngithatha lokhu kusho ukuthi isimo senzelwe ukwakhiwa bese siphila ingunaphakade.
//
// Ngingathanda ukubhalisa i-at_exit() handler ehlanza lesi simo, kepha i-libbacktrace ayinikeli ndlela yokwenza lokho.
//
// Ngalezi zingqinamba, lo msebenzi unesimo esifakwe kunqolobane esibalwa okokuqala lapho kucelwa lokhu.
//
// Khumbula ukuthi ukubuyisela emuva konke kwenzeka ngokulandelana (ukukhiya okukodwa komhlaba).
//
// Qaphela ukuntuleka kokuvumelanisa lapha kungenxa yesidingo sokuthi i `resolve` ivumelaniswe ngaphandle.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Musa ukusebenzisa amandla we-threadsafe we-libbacktrace ngoba sihlala sikubiza ngendlela evumelanisiwe.
        //
        0,
        error_cb,
        ptr::null_mut(), // ayikho idatha eyengeziwe
    );

    return STATE;

    // Qaphela ukuthi ukuze i-libbacktrace isebenze konke idinga ukuthola imininingwane yokulungisa iphutha le-DWARF ye-executable yamanje.Kwenza lokho ngezindlela eziningi kufaka phakathi, kepha kungakhawulelwe ku:
    //
    // * /proc/self/exe kuzingxenyekazi ezisekelwayo
    // * Igama lefayela lidluliswe ngokucacile lapho kwakhiwa isimo
    //
    // Umtapo wezincwadi we-libbacktrace uyi-wad enkulu yekhodi ye-C.Lokhu ngokwemvelo kusho ukuthi kunokukhubazeka kokuphepha kwememori, ikakhulukazi lapho usingatha i-debuginfo engalungile.
    // ILibstd ihlangabezane nokuningi kwalokhu ngokomlando.
    //
    // Uma i-/proc/self/exe isetshenziswa lapho-ke singakwazi ukukuziba lokhu njengoba sicabanga ukuthi i-libbacktrace iyi-"mostly correct" futhi kungenjalo ayenzi izinto ezixakile ngolwazi lwe-"attempted to be correct" dwarf debug.
    //
    //
    // Uma sidlula ngegama lefayela, noma kunjalo, khona-ke kuyenzeka kwamanye amapulatifomu (njengama-BSD) lapho umlingisi ononya angadala ukuthi kufakwe ifayili lokuphikisana kuleyo ndawo.
    // Lokhu kusho ukuthi uma sitshela i-libbacktrace mayelana negama lefayela kungenzeka ukuthi lisebenzisa ifayela lokuphikisana, okungenzeka lidale ukwehluka.
    // Uma singatsheli lutho ngokubuyisa emuva noma ngabe ngeke lwenze lutho kuzingxenyekazi ezingasekeli izindlela ezifana ne /proc/self/exe!
    //
    // Njengoba kunikezwe konke esizama ngakho konke okusemandleni ukuze * singadluli igama lefayela, kepha kufanele kumapulatifomu angayisekeli nhlobo i-/proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Qaphela ukuthi kuhle sisebenzise i-`std::env::current_exe`, kepha asikwazi ukufuna i-`std` lapha.
            //
            // Sebenzisa i-`_NSGetExecutablePath` ukulayisha indlela yamanje engaphunyelelwa endaweni ye-static (okuthi uma incane kakhulu yeka).
            //
            //
            // Qaphela ukuthi sethembela kakhulu ekubuyiseleni emuva lapha ukuthi singafi kokusebenzisekayo okonakele, kepha nakanjani kunjalo ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows inendlela yokuvula amafayela lapho ngemuva kokuthi ivuliwe ingeke isuswe.
            // Ngokuvamile yilokho esikufunayo lapha ngoba sifuna ukuqinisekisa ukuthi okwenzekayo akusishintshi kusuka ngaphansi kwethu ngemuva kokuthi sikunikeze ku-libbacktrace, ngethemba lokunciphisa ikhono lokudlulisa idatha engqubuzanayo ku-libbacktrace (engahle iphathwe kabi).
            //
            //
            // Njengoba kunikezwe ukuthi senza umdanso omncane lapha ukuzama ukuthola uhlobo lokhiye esithombeni sethu:
            //
            // * Thola isibambo kunqubo yamanje, layisha igama lefayela layo.
            // * Vula ifayela kulelo gama lefayela ngamafulegi alungile.
            // * Phinda ulayishe igama lefayela lenqubo yamanje, uqiniseke ukuthi liyafana
            //
            // Uma konke lokho kudlula ngokwemibono kuvulwe ifayela lethu lenqubo futhi siqinisekisiwe ukuthi ngeke kuguquke.I-FWIW inqwaba yalokhu ikopishwe kusuka ku-libstd ngokomlando, ngakho-ke lokhu ukutolika kwami okuhle ngokwakwenzeka.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Lokhu kuhlala kwimemori emile ukuze sikwazi ukuyibuyisa ..
                static mut BUF: [i8; N] = [0; N];
                // ... futhi lokhu kuhlala esitaki ngoba kungokwesikhashana
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ukuvuza ngamabomu i-`handle` lapha ngoba ukukuvula lokho kufanele kulondoloze ukukhiya kwethu kuleli gama lefayela.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Sifuna ukubuyisa isilayidi esinqanyuliwe, ngakho-ke uma konke kugcwalisiwe futhi kulingana nobude obuphelele bese ulinganisa nalokho ukwehluleka.
                //
                //
                // Ngaphandle kwalokho lapho ubuyisa impumelelo qiniseka ukuthi i-nul byte ifakiwe kusilayidi.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // amaphutha we-backtrace njengamanje ashanyelwe ngaphansi kombhoxo
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Shayela i-`backtrace_syminfo` API okufanele (ngokufunda ikhodi) ifonele i-`syminfo_cb` kanye (noma yehluleke ngephutha mhlawumbe).
    // Ngemuva kwalokho siphatha okuningi ngaphakathi kwe `syminfo_cb`.
    //
    // Qaphela ukuthi lokhu sikwenza ngoba i `syminfo` izobheka itafula lezimpawu, ithole amagama ezimpawu ngisho noma kungekho lwazi lokususa iphutha kunambambili.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}