use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Sombulula ikheli kusimbuli, udlulise uphawu ekuvalweni okucacisiwe.
///
/// Lo msebenzi uzobheka ikheli elinikeziwe ezindaweni ezifana netafula lezimpawu lendawo, itafula lezimpawu ezinamandla, noma imininingwane yokulungisa iphutha ye-DWARF (kuya ngokuqaliswa okwenziwe kwasebenza) ukuthola izimpawu ezizonikezwa.
///
///
/// Ukuvalwa kungenzeka kungabizwa uma isinqumo singakwazanga ukwenziwa, futhi kungabizwa ngaphezu kwesisodwa esimweni semisebenzi efakwe ngaphakathi.
///
/// Izimpawu ezinikeziwe zimelela ukwenziwa ku-`addr` ebekiwe, kubuyiselwa ama-file/line ngababili alelo kheli (uma likhona).
///
/// Qaphela ukuthi uma une-`Frame` kuyanconywa ukuthi usebenzise umsebenzi we-`resolve_frame` esikhundleni salokhu.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
/// # Panics
///
/// Lo msebenzi ulwela ukungalokothi ube yi-panic, kepha uma i-`cb` inikeze i-panics amanye amapulatifomu azophoqa i-panic ephindwe kabili ukukhipha inqubo.
/// Amanye amapulatifomu asebenzisa umtapo wezincwadi we-C osebenzisa ngaphakathi izingcingo ezingavuleki ngaphakathi, ngakho-ke ukwethuka okuvela ku `cb` kungadala inqubo yokukhipha isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // bheka kuphela ifreyimu ephezulu
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Sombulula uhlaka lwangaphambili lokuthwebula lube wuphawu, udlulise uphawu ekuvalweni okucacisiwe.
///
/// Le functin yenza umsebenzi ofanayo ne-`resolve` ngaphandle kokuthi ithatha i-`Frame` njengengxabano esikhundleni sekheli.
/// Lokhu kungavumela ukusetshenziswa kwepulatifomu yokubuyiselwa emuva kunikeze imininingwane ethe xaxa yezimpawu noma imininingwane emayelana nozimele abaphakathi kolayini ngokwesibonelo.
///
/// Kunconywa ukuthi usebenzise lokhu uma ukwazi.
///
/// # Izici ezidingekayo
///
/// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
///
/// # Panics
///
/// Lo msebenzi ulwela ukungalokothi ube yi-panic, kepha uma i-`cb` inikeze i-panics amanye amapulatifomu azophoqa i-panic ephindwe kabili ukukhipha inqubo.
/// Amanye amapulatifomu asebenzisa umtapo wezincwadi we-C osebenzisa ngaphakathi izingcingo ezingavuleki ngaphakathi, ngakho-ke ukwethuka okuvela ku `cb` kungadala inqubo yokukhipha isisu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // bheka kuphela ifreyimu ephezulu
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Amanani we-IP avela kuzimele zesitaki imvamisa i-(always?) imiyalo *ngemuva* kwekholi okuwumbhalo wesitaki uqobo.
// Ukufanekisela lokhu kubangela ukuthi inombolo ye-filename/line ibe yinye phambili futhi mhlawumbe ibe yize uma isiseduze nokuphela komsebenzi.
//
// Lokhu kubukeka kunjalo ngaso sonke isikhathi kuwo wonke amapulatifomu, ngakho-ke sihlala sikhipha eyodwa ku-ip exazululiwe ukuyixazulula kumyalo wangaphambili wezingcingo esikhundleni somyalo obuyiselwa kuwo.
//
//
// Ngokufanele besingeke sikwenze lokhu.
// Ngokufanelekile sizodinga abafonayo bama-`resolve` APIs lapha ukuze benze i--1 ngesandla ne-akhawunti ukuthi bafuna imininingwane yendawo ngomyalo *wangaphambilini*, hhayi owamanje.
// Ngokufanelekile futhi sizodalula ku-`Frame` uma siyikheli langempela lomyalo olandelayo noma owamanje.
//
// Okwamanje yize lokhu kuyinkinga enhle ye-niche ngakho-ke nje ngaphakathi sisusa njalo eyodwa.
// Abathengi kufanele baqhubeke nokusebenza futhi bathole imiphumela emihle kakhulu, ngakho-ke kufanele silunge ngokwanele.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Ifana ne-`resolve`, kuphela engaphephile njengoba ingavumelanisiwe.
///
/// Lo msebenzi awunawo ama-guarantee wokuvumelanisa kepha uyatholakala lapho isici se-`std` sale crate singahlanganiswa.
/// Bona umsebenzi we `resolve` ukuthola eminye imibhalo nezibonelo.
///
/// # Panics
///
/// Bona imininingwane ku-`resolve` yama-caveats nge-`cb` panicking.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Ifana ne-`resolve_frame`, kuphela engaphephile njengoba ingavumelanisiwe.
///
/// Lo msebenzi awunawo ama-guarantee wokuvumelanisa kepha uyatholakala lapho isici se-`std` sale crate singahlanganiswa.
/// Bona umsebenzi we `resolve_frame` ukuthola eminye imibhalo nezibonelo.
///
/// # Panics
///
/// Bona imininingwane ku-`resolve_frame` yama-caveats nge-`cb` panicking.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// I-trait emele ukulungiswa kophawu kufayela.
///
/// Le trait ikhishwa njengento ye trait ekuvalweni okunikezwe umsebenzi we `backtrace::resolve`, futhi ithunyelwa cishe njengoba kungaziwa ukuthi ikuphi ukuqaliswa okusemuva kwayo.
///
///
/// Uphawu lunganikeza imininingwane yokuqukethwe ngomsebenzi, isibonelo igama, igama lefayela, inombolo yomugqa, ikheli eliqondile, njll.
/// Akuyona yonke imininingwane ehlala itholakala ngophawu, noma kunjalo, ngakho-ke zonke izindlela zibuyisa i-`Option`.
///
///
pub struct Symbol {
    // TODO: lesi sibopho sempilo yonke sidinga ukuphikelela ekugcineni sibe yi-`Symbol`,
    // kepha okwamanje ushintsho olukhulu.
    // Okwamanje lokhu kuphephile ngoba i `Symbol` inikezwa kuphela ngesethenjwa futhi ayikwazi ukwakhiwa.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Ibuyisa igama lalo msebenzi.
    ///
    /// Isakhiwo esibuyisiwe singasetshenziswa ukubuza izakhiwo ezahlukahlukene mayelana negama lophawu:
    ///
    ///
    /// * Ukusetshenziswa kwe `Display` kuzophrinta uphawu oludonswe phansi.
    /// * Inani elingavuthiwe le-`str` lophawu lungafinyelelwa (uma livumelekile i-utf-8).
    /// * Ama-byte aluhlaza wegama lesimboli angafinyelelwa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Ibuyisa ikheli lokuqala lalo msebenzi.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Ibuyisa igama lefayela eliluhlaza njengocezu.
    /// Lokhu kusebenza ikakhulukazi ezindaweni ze-`no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Ibuyisa inombolo yekholomu yalapho lolu phawu lusebenza khona njengamanje.
    ///
    /// Kuphela i-gimli okwamanje enikeza inani lapha futhi lapho kuphela uma i-`filename` ibuyisa i-`Some`, ngakho-ke ngenxa yalokho ingaphansi kwemigede efanayo.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Ibuyisa inombolo yomugqa lapho lolu phawu lusebenza khona manje.
    ///
    /// Leli nani elibuyiswayo ngokuvamile liyi-`Some` uma i-`filename` ibuyisa i-`Some`, futhi ngenxa yalokho ikhonjelwe emihumeni efanayo.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Ibuyisa igama lefayela lapho lo msebenzi uchazwe khona.
    ///
    /// Lokhu okwamanje kutholakala kuphela lapho kusetshenziswa i-libbacktrace noma i-gimli (isb
    /// unix amapulatifomu amanye) futhi lapho kuhlanganiswa kanambambili nge-debuginfo.
    /// Uma kungekho neyodwa yalezi zimo ehlangatshezwayo lokhu kungenzeka kubuyise i-`None`.
    ///
    /// # Izici ezidingekayo
    ///
    /// Lo msebenzi udinga isici se-`std` se-`backtrace` crate ukuthi sinikwe amandla, futhi isici se-`std` sinikwe amandla ngokuzenzakalela.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mhlawumbe uphawu oluhlukanisiwe lwe-C++ , uma ukuhlukanisa uphawu olumakiwe njenge-Rust kwehlulekile.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Qiniseka ukuthi ugcina lesi sikhulu esingu-zero, ukuze isici se-`cpp_demangle` singabi nezindleko lapho sikhutshaziwe.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Isisongeli esizungeze igama lesimbuli ukuhlinzeka izifinyezo ze-ergonomic egameni elidiliziwe, ama-byte aluhlaza, intambo eluhlaza, njll.
///
// Vumela ikhodi efile lapho isici se-`cpp_demangle` sinikwe amandla.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Idala igama lophawu olusha kusuka kumabhayithi angaphansi aluhlaza.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Ibuyisa igama lophawu le-(mangled) eluhlaza njenge-`str` uma uphawu luyi-utf-8 evumelekile.
    ///
    /// Sebenzisa ukuqaliswa kwe `Display` uma ufuna inguqulo edonswe phansi.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Ibuyisa igama lophawu oluhlaza njengohlu lwama-byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Lokhu kungaphrinta uma uphawu oludonswe phansi aluvumelekile empeleni, ngakho-ke phatha iphutha lapha ngomusa ngokungalisabalalisi ngaphandle.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Umzamo wokufuna leyo nkumbulo efakwe kunqolobane esetshenziselwa ukufanekisela amakheli.
///
/// Le ndlela izozama ukukhipha noma yiziphi izakhiwo zedatha zomhlaba wonke ezifakwe kunqolobane emhlabeni jikelele noma ngentambo emele imininingwane ehlukanisiwe ye-DWARF noma efanayo.
///
///
/// # Caveats
///
/// Ngenkathi lo msebenzi uhlala utholakala awenzi lutho ekusetshenzisweni okuningi.
/// Imitapo yolwazi efana ne-dbghelp noma i-libbacktrace ayinikezeli ngezinsizakusebenza zokuhambisa izwe nokuphatha imemori eyabiwe.
/// Okwamanje isici se `gimli-symbolize` sale crate ukuphela kwento lapho lo msebenzi unomphumela.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}