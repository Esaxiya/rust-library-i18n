# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Umtapo wolwazi wokuthola imuva langemuva ngesikhathi sokusebenza se-Rust.
Lo mtapo wolwazi uhlose ukukhulisa ukwesekwa kwelabhulali ejwayelekile ngokunikeza isikhombimsebenzisi sokusebenza, kepha futhi isekela ukumane ukuphrinta kalula i-backtrace yamanje efana ne-libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ukumane uthwebule i-backtrace nokuhlehlisa ukubhekana nayo kuze kube yisikhathi esizayo, ungasebenzisa uhlobo lwe-`Backtrace` esezingeni eliphezulu.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Uma, noma kunjalo, ungathanda ukufinyelela okuluhlaza okwengeziwe ekusebenzeni kwangempela kokulandela, ungasebenzisa imisebenzi ye `trace` ne `resolve` ngqo.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Xazulula lesi sikhombi semiyalo egameni lesimbuli
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // qhubeka uye kufreyimu elandelayo
    });
}
```

# License

Le phrojekthi inikwe ilayisense ngaphansi kwanoma iyiphi

 * Ilayisense ye-Apache, i-Version 2.0, i-([LICENSE-APACHE](LICENSE-APACHE) noma i-http://www.apache.org/licenses/LICENSE-2.0)
 * Ilayisense ye-MIT ([LICENSE-MIT](LICENSE-MIT) noma i-http://opensource.org/licenses/MIT)

ngokuthanda kwakho.

### Contribution

Ngaphandle kokuthi usho ngokuhlukile, noma imuphi umnikelo ohanjiswe ngenhloso ukuze ufakwe ku-backtrace-rs nguwe, njengoba kuchaziwe kwilayisense le-Apache-2.0, uzoba nelayisense elikabili njengalokhu ngenhla, ngaphandle kweminye imibandela noma imibandela.







