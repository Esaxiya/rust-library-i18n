use backtrace::Backtrace;

// Igama lemodyuli enezinhlamvu ezingama-50
mod _234567890_234567890_234567890_234567890_234567890 {
    // Igama lezinhlaka ezingama-50
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Amagama omsebenzi omude kumele ancishiselwe izinhlamvu (MAX_SYM_NAME, 1).
// Sebenzisa lolu vivinyo kuphela lwe-msvc, ngoba i-gnu iphrinta i-"<no info>" yawo wonke amafreyimu.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // Ukuphindaphindwa okungu-10 kwegama le-struct, igama lomsebenzi elifaneleke ngokuphelele yi-atleast 10 *(50 + 50)* 2=izinhlamvu ezingama-2000 ubude.
    //
    // Mude impela ngoba futhi ifaka phakathi i `::`, `<>` negama lemodyuli yamanje
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}