use backtrace::Backtrace;

// Lokhu kuhlolwa kusebenza kuphela kuzingxenyekazi ezinomsebenzi we-`symbol_address` osebenzayo wozimele obika ikheli lokuqala lophawu.
// Ngenxa yalokhu inikwe amandla kuphela kuzingxenyekazi ezimbalwa.
//
const ENABLED: bool = cfg!(all(
    // Windows ayikaze ihlolwe ngempela, futhi i-OSX ayisekeli ukuthola ifreyimu evaliwe, ngakho-ke khubaza lokhu
    //
    target_os = "linux",
    // Ku-ARM ukuthola umsebenzi ovalekile kumane nje kubuyisa i-ip uqobo.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}