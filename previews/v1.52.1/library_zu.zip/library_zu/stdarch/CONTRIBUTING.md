# Ukunikela ku-stdarch

I `stdarch` crate izimisele kakhulu ukwamukela iminikelo!Okokuqala uzofuna ukubheka okugciniwe futhi uqiniseke ukuthi izivivinyo ziyakudlulela:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Lapho i-`<your-target-arch>` iyithagethi ephindwe kathathu njengoba isetshenziswe yi-`rustup`, isb. `x86_x64-unknown-linux-gnu` (ngaphandle kwe-`nightly-` eyedlule noma efanayo).
Futhi khumbula ukuthi leli khosombe lidinga isiteshi sasebusuku se Rust!
Lezi zivivinyo ezingenhla empeleni zidinga ukuthi i-rust yasebusuku ibe yinto ezenzakalelayo kusistimu yakho, ukusetha lokho kusebenzisa i-`rustup default nightly` (ne-`rustup default stable` ukubuyisa).

Uma ngabe yiziphi kulezi zinyathelo ezingenhla zingasebenzi, [please let us know][new]!

Ngokulandelayo ungasiza i-[find an issue][issues] ukusiza, sikhethe ezimbalwa ngamathegi we-[`help wanted`][help] ne-[`impl-period`][impl] angasebenzisa ikakhulukazi usizo oluthile. 
Ungaba nentshisekelo enkulu ku-[#40][vendor], usebenzisa konke okungaphakathi kwabathengisi ku-x86.Leyo nkinga inezinkomba ezinhle mayelana nokuthi ungaqala kuphi!

Uma unemibuzo ejwayelekile zizwe ukhululekile kwi [join us on gitter][gitter] futhi ubuze nxazonke!Zizwe ukhululekile ukubuza noma i-@BurntSushi noma i-@alexcrichton ngemibuzo.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Ungazibhala kanjani izibonelo ze-stdarch intrinsics

Kunezici ezimbalwa okufanele zinikwe amandla ukuze okungaphakathi okunikeziwe kusebenze kahle futhi isibonelo kufanele siqhutshwe kuphela yi-`cargo test --doc` lapho isici sisekelwa yi-CPU.

Njengomphumela, i-`fn main` ezenzakalelayo ekhiqizwa yi-`rustdoc` ngeke isebenze (ezimweni eziningi).
Cabanga ukusebenzisa okulandelayo njengesiqondisi ukuqinisekisa ukuthi isibonelo sakho sisebenza njengoba kulindelwe.

```rust
/// # // Sidinga isici se-cfg_target_ukuqinisekisa ukuthi isibonelo kuphela
/// # // run by `cargo test --doc` lapho i-CPU isekela isici
/// # #![feature(cfg_target_feature)]
/// # // Sidinga i-target_feature ukuze okungaphakathi kusebenze
/// # #![feature(target_feature)]
/// #
/// # // i-rustdoc ngokuzenzakalela isebenzisa i-`extern crate stdarch`, kepha sidinga i-
/// # // `#[macro_use]`
/// # # [macro_use] ngaphandle kwe-crate stdarch;
/// #
/// # // Umsebenzi omkhulu wangempela
/// # fn main() {
/// #     // Qalisa lokhu kuphela uma i-`<target feature>` isekelwa
/// #     uma i-cfg_feature_inikwe amandla! ("<target feature>"){
/// #         // Dala umsebenzi we-`worker` ozoqhutshwa kuphela uma isici sethagethi
/// #         // kuyasekelwa futhi kuqinisekiswe ukuthi i-`target_feature` inikwe amandla isisebenzi sakho
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         okungaphephile fn worker() {
/// // Bhala isibonelo sakho lapha.Faka ama-intrinsics athile azosebenza lapha!Iya endle!
///
/// #         }
///
/// #         okungaphephile i { worker(); }
/// #     }
/// # }
```

Uma enye ye-syntax engenhla ingabonakali ijwayelekile, isigaba se-[Documentation as tests] se-[Rust Book] sichaza kahle i-syntax ye-`rustdoc`.
Njengenjwayelo, khululeka ku-[join us on gitter][gitter] bese usibuza ukuthi ngabe ushaya noma yiziphi izingqinamba, futhi siyabonga ngokusiza ukuthuthukisa imibhalo ye-`stdarch`!

# Imiyalo Yokuhlola Ehlukile

Ngokuvamile kunconywa ukuthi usebenzise i-`ci/run.sh` ukwenza izivivinyo.
Kodwa-ke lokhu kungenzeka kungakusebenzeli, isb. Uma uku-Windows.

Uma kunjalo ungabuyela ekusebenziseni i-`cargo +nightly test` ne-`cargo +nightly test --release -p core_arch` yokuhlola ukwenziwa kwekhodi.
Qaphela ukuthi lokhu kudinga ukuthi kufakwe i-toolchain yasebusuku futhi i-`rustc` yazi ngethagethi yakho ephindwe kathathu ne-CPU yayo.
Ikakhulu udinga ukusetha ukuguquguquka kwemvelo kwe-`TARGET` njengoba ubungathanda i-`ci/run.sh`.
Ngokungeziwe udinga ukusetha i-`RUSTCFLAGS` (dinga i-`C`) ukukhombisa izici eziqondiwe, isb `RUSTCFLAGS="-C -target-features=+avx2"`.
Ungasetha futhi i-`-C -target-cpu=native` uma uyi-"just" ithuthukisa i-CPU yakho yamanje.

Xwayiswa ukuthi uma usebenzisa le miyalo ehlukile, i-[things may go less smoothly than they would with `ci/run.sh`][ci-run-good], isb
izivivinyo zokukhiqiza ukufundisa zingahluleka ngoba i-disassembler iqambe ngokuhlukile, isb
ingahle ikhiqize i-`vaesenc` esikhundleni semiyalo ye-`aesenc` yize beziphatha ngokufanayo.
Futhi le miyalo yenza izivivinyo ezingaphansi kunalokho obekuvame ukwenziwa, ngakho-ke ungamangali ukuthi lapho ekugcineni udonsela isicelo amanye amaphutha angavela ekuhlolweni okungamboziwe lapha.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






