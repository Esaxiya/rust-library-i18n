`core::arch` - I-intrinsics ekhethekile yomtapo wolwazi we-Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Imodyuli ye `core::arch` isebenzisa okokusebenza okuncike ekwakhiweni kwezakhiwo (isb. SIMD).

# Usage 

`core::arch` iyatholakala njengengxenye ye-`libcore` futhi ithunyelwa kabusha yi-`libstd`.Uncamela ukuyisebenzisa nge-`core::arch` noma i-`std::arch` kunale crate.
Izici ezingazinzile zivame ukutholakala ku-Rust yasebusuku nge `feature(stdsimd)`.

Sebenzisa i-`core::arch` ngale crate kudinga i-Rust yasebusuku, futhi (futhi iyakwazi) ukuphuka kaningi.Okuwukuphela kwamacala lapho kufanele ucabangele ukuyisebenzisa nge-crate yile:

* uma udinga ukuzihlanganisa kabusha i-`core::arch` ngokwakho, isb., ngezici ezithile eziqondiwe ezinikwe amandla ezinganikwanga amandla i-`libcore`/`libstd`.
Note: uma udinga ukuyihlanganisa kabusha ngenhloso engajwayelekile, sicela ukhethe ukusebenzisa i-`xargo` bese uhlanganisa kabusha i-`libcore`/`libstd` njengokufanelekile esikhundleni sokusebenzisa le crate.
  
* usebenzisa ezinye izici ezingase zingatholakali ngisho nangemva kwezici ezingazinzile ze-Rust.Sizama ukugcina lokhu kube okuncane.
Uma udinga ukusebenzisa ezinye zalezi zici, sicela uvule inkinga ukuze siziveze ku-Rust yasebusuku futhi ukwazi ukuzisebenzisa ukusuka lapho.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` isatshalaliswa ngokuyinhloko ngaphansi kwemigomo yelayisense ye-MIT kanye ne Apache License (Version 2.0), nezingxenye ezithile zimbozwe ngamalayisense ahlukahlukene afana ne-BSD.

Bona i-LICENSE-APACHE, ne-LICENSE-MIT ukuthola imininingwane.

# Contribution

Ngaphandle kokuthi usho ngokuhlukile, noma imuphi umnikelo ohanjiswe ngenhloso ukuze ufakwe ku `core_arch` nguwe, njengoba kuchaziwe kwilayisense ye Apache-2.0, uzoba nelayisense elikabili njengalokhu okungenhla, ngaphandle kweminye imibandela noma imibandela.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












