use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Sisebenzise ukutshela izichasiselo zethu ze-`#[assert_instr]` ukuthi zonke izinto ze-simd ziyatholakala ukuhlola i-codegen yazo, ngoba ezinye ziboshwe ngemuva kwe-`-Ctarget-feature=+unimplemented-simd128` eyengeziwe engenakho okulingana ku-`#[target_feature]` njengamanje.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}