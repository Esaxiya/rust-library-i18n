#![feature(no_core)]
#![no_core]

// Bona i rustc-std-workspace-core yokuthi kungani le crate idingeka.

// Qamba kabusha i-crate ukugwema ukungqubuzana nemodyuli eyabiwe ku-liballoc.
extern crate alloc as foo;

pub use foo::*;