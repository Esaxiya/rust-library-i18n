use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Kukhipha okwesikhashana okunye, okulingana okungaguquki kobubanzi obufanayo.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ithola onqenqemeni beqabunga abahlukile abahlukanisa ububanzi obucacisiwe esihlahleni.
    /// Ibuyisa noma yiziphi izibambo ezihlukile esihlahleni esisodwa noma izinketho ezingenalutho.
    ///
    /// # Safety
    ///
    /// Ngaphandle kokuthi i-`BorrowType` iyi-`Immut`, ungasebenzisi izibambo eziphindiwe ukuvakashela i-KV efanayo kabili.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ilingana ne `(root1.first_leaf_edge(), root2.last_leaf_edge())` kepha isebenza kahle kakhulu.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Uthola amaphethelo amaqabunga ahlukanisa ibanga elithile esihlahleni.
    ///
    /// Umphumela uba nencazelo kuphela uma isihlahla siyalwe ngokhiye, njengesihlahla esiku-`BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // UKUPHEPHA: uhlobo lwethu lokuboleka aluguquki.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Uthola amaphethelo amaqabunga aqeda umuthi wonke.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Ihlukanisa ireferensi eyingqayizivele emaphethelweni amaqabunga ahlukanisa ububanzi obucacisiwe.
    /// Imiphumela iyizinkomba ezingezona ezehlukile ezivumela ukuguqulwa kwe (some), okumele kusetshenziswe ngokucophelela.
    ///
    /// Umphumela uba nencazelo kuphela uma isihlahla siyalwe ngokhiye, njengesihlahla esiku-`BTreeMap`.
    ///
    ///
    /// # Safety
    /// Ungasebenzisi izibambo eziphindiwe ukuvakashela i-KV efanayo kabili.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ihlukanisa ireferensi eyingqayizivele emaphethelweni amaqabunga ehlukanisa ububanzi obugcwele besihlahla.
    /// Imiphumela iyizinkomba ezingezona ezehlukile ezivumela ukuguqulwa (kwamanani kuphela), ngakho-ke kufanele isetshenziswe ngokunakekela.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Siphinda impande yeNodeRef lapha-asisoze savakashela i-KV efanayo kabili, futhi asisoze sagcina sinereferensi yamanani agqagqene.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ihlukanisa ireferensi eyingqayizivele emaphethelweni amaqabunga ehlukanisa ububanzi obugcwele besihlahla.
    /// Imiphumela iyizinkomba ezingezona ezehlukile ezivumela ukuguqulwa okunamandla kokulimaza, ngakho-ke kufanele isetshenziswe ngokucophelela okukhulu.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Siphinda impande yeNodeRef lapha-asisoze sayifinyelela ngendlela eyeqa izinkomba ezitholwe empandeni.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Njengoba kunikezwe isibambo seqabunga i-edge, ibuyisa i-[`Result::Ok`] ngesibambo ku-KV engomakhelwane ngakwesokunene, esiku-node efanayo yeqabunga noma ku-node yokhokho.
    ///
    /// Uma iqabunga i-edge kungokugcina esihlahleni, ibuyisa i-[`Result::Err`] nge-node yezimpande.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Njengoba kunikezwe isibambo seqabunga i-edge, ibuyisa i-[`Result::Ok`] ngesibambo ku-KV engomakhelwane ohlangothini lwesobunxele, okuyi-node efanayo yeqabunga noma ku-node yokhokho.
    ///
    /// Uma iqabunga i-edge kungowokuqala esihlahleni, ibuyisa i-[`Result::Err`] nge-node yezimpande.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Njengoba kunikezwe isibambo sangaphakathi se-edge, ibuyisa i-[`Result::Ok`] ngesibambo ku-KV engomakhelwane ngakwesokunene, okukuyo engeyokuqala yangaphakathi efanayo noma kunodi yokhokho.
    ///
    /// Uma i-edge yangaphakathi ingeyokugcina esihlahleni, ibuyisa i-[`Result::Err`] nge-node yezimpande.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Njengoba kunikezwe isibambo seqabunga i-edge esihlahleni esifayo, ibuyisa iqabunga elilandelayo i-edge ngakwesokunene, nepheya lenani lokhiye phakathi, okukulo lendawo yeqabunga elifanayo, ku-node yokhokho, noma engekho.
    ///
    ///
    /// Le ndlela ibuye ihambise noma iyiphi i-node(s) efinyelela ekugcineni kwayo.
    /// Lokhu kusho ukuthi uma kungasekho okubili kwenani lokhiye, sonke isihlahla esisele sizobe sesihanjisiwe futhi akukho okusele okuzobuya.
    ///
    /// # Safety
    /// I-edge enikeziwe akumele ngabe ibuyiselwe phambilini uzakwethu u-`deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Njengoba kunikezwe isibambo seqabunga i-edge esihlahleni esifayo, ibuyisa iqabunga elilandelayo i-edge ohlangothini lwesobunxele, nepheya lenani lokhiye phakathi, okukulo lendawo yeqabunga elifanayo, ku-node yokhokho, noma engekho.
    ///
    ///
    /// Le ndlela ibuye ihambise noma iyiphi i-node(s) efinyelela ekugcineni kwayo.
    /// Lokhu kusho ukuthi uma kungasekho okubili kwenani lokhiye, sonke isihlahla esisele sizobe sesihanjisiwe futhi akukho okusele okuzobuya.
    ///
    /// # Safety
    /// I-edge enikeziwe akumele ngabe ibuyiselwe phambilini uzakwethu u-`deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Isusa inqwaba yama-node kusuka eqabeni kuye ezimpandeni.
    /// Le ukuphela kwendlela yokuhambisa okusele kwesihlahla ngemuva kokuthi i `deallocating_next` ne `deallocating_next_back` zibambe izinhlangothi zombili zesihlahla, futhi bashaya i edge efanayo.
    /// Njengoba kuhloselwe ukubizwa kuphela lapho konke okhiye namanani abuyisiwe, akukho kuhlanzwa okwenziwa kunoma ikuphi okhiye noma amanani.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isibambo seqabunga i-edge siye kukhasi elilandelayo i-edge bese ibuyisa izinkomba kukhiye nenani eliphakathi nendawo.
    ///
    ///
    /// # Safety
    /// Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Ihambisa isibambo seqabunga i-edge kukhasi langaphambilini le-edge bese ibuyisa izinkomba kukhiye nenani eliphakathi nendawo.
    ///
    ///
    /// # Safety
    /// Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isibambo seqabunga i-edge siye kukhasi elilandelayo i-edge bese ibuyisa izinkomba kukhiye nenani eliphakathi nendawo.
    ///
    ///
    /// # Safety
    /// Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Ukwenza lokhu kokugcina kuyashesha, ngokuya ngamabhentshimakhi.
        kv.into_kv_valmut()
    }

    /// Ihambisa isibambo seqabunga i-edge siye eqabeni langaphambilini futhi sibuyisele izinkomba kukhiye nenani eliphakathi.
    ///
    ///
    /// # Safety
    /// Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Ukwenza lokhu kokugcina kuyashesha, ngokuya ngamabhentshimakhi.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Ihambisa isibambo seqabunga i-edge siye eqabeni elilandelayo i-edge bese ibuyisa ukhiye nenani phakathi, kuhanjiswa noma iyiphi i-node esele ngemuva ngenkathi ishiya i-edge ehambelanayo endaweni yayo yomzali ilenga.
    ///
    /// # Safety
    /// - Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    /// - Leyo KV yayingabuyiswanga phambilini nguzakwabo u `next_back_unchecked` kunoma iyiphi ikhophi yezibambo ezazisetshenziswa ukunqamula isihlahla.
    ///
    /// Ukuphela kwendlela ephephile yokuqhubeka nesibambo esibuyekeziwe ukukuqhathanisa, ukusilahla, ukushayela le ndlela futhi ngokuya ngezimo zokuphepha kwayo, noma ukushayela umlingani u `next_back_unchecked` ngokuya ngezimo zokuphepha kwayo.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Ihambisa isibambo seqabunga i-edge siye eqabeni langaphambilini le-edge bese ibuyisa ukhiye nenani phakathi, kuhanjiswa noma iyiphi i-node esele ngemuva ngenkathi ishiya i-edge ehambelanayo endaweni yayo yomzali ilenga.
    ///
    /// # Safety
    /// - Kufanele kube nenye i-KV ekuqondisweni okuhanjiwe.
    /// - Lelo qabunga i-edge belingabuyiswanga phambilini nguzakwabo u-`next_unchecked` kunoma iyiphi ikhophi yezibambo ezisetshenziselwa ukunqamula isihlahla.
    ///
    /// Ukuphela kwendlela ephephile yokuqhubeka nesibambo esibuyekeziwe ukukuqhathanisa, ukusilahla, ukushayela le ndlela futhi ngokuya ngezimo zokuphepha kwayo, noma ukushayela umlingani u `next_unchecked` ngokuya ngezimo zokuphepha kwayo.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ibuyisa iqabunga elingakwesokunxele i-edge ngaphakathi noma ngaphansi kwe-node, ngamanye amagama, i-edge oyidinga kuqala lapho uzulazulela phambili (noma ekugcineni lapho uzulazulela emuva).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Ibuyisa iqabunga elingakwesokudla i-edge ngaphakathi noma ngaphansi kwe-node, ngamanye amagama, i-edge oyidingayo ekugcineni lapho uzulazulela phambili (noma okokuqala lapho ubuyela emuva).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ivakashela ama-node amaqabunga nama-KV angaphakathi ngokulandelana kokhiye abakhuphukayo, futhi ibuye ivakashele ama-node wangaphakathi wonke ngokujula kokuqala, okusho ukuthi ama-node angaphakathi andulela ama-KV abo kanye nezindawo zezingane zabo.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Ibala inani lama-elementi esihlahleni (esingaphansi).
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Ibuyisa iqabunga i-edge eliseduze kakhulu ne-KV lokuzulazula phambili.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Ibuyisa iqabunga i-edge eduzane ne-KV yokuzula emuva.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}