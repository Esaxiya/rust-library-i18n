use core::marker::PhantomData;
use core::ptr::NonNull;

/// Amamodeli ukukhokhiswa kwesithenjwa esithile esiyingqayizivele, lapho wazi ukuthi ukukhishwa kwemali nayo yonke inzalo yayo (okungukuthi, zonke izikhombisi nezinkomba ezithathwe kuyo) ngeke kusasetshenziswa kwesinye isikhathi, ngemuva kwalokho ufuna ukusebenzisa ireferensi eyingqayizivele yoqobo futhi .
///
///
/// Isihloli sokuboleka ngokuvamile siphatha lokhu kugcinwa kokubolekwa kwakho, kepha okunye ukugeleza kokulawula okufeza lokhu kugcinwa kuyinkimbinkimbi kakhulu ukuba umhlanganisi alandele.
/// I-`DormantMutRef` ikuvumela ukuthi uhlole ukuboleka wena, ngenkathi uveza imvelo yayo ehlanganisiwe, futhi ifaka ikhodi yesikhombi eluhlaza edingekayo ukwenza lokhu ngaphandle kokuziphatha okungachazwanga.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Thwebula imali ehlukile ebolekwayo, bese uyiboleka ngokushesha.
    /// Kumhlanganisi, isikhathi sokuphila kwesethenjwa esisha siyefana nesikhathi sokuphila kwesethenjwa sokuqala, kepha wena promise ukusisebenzisa isikhathi esifushane.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // UKUPHEPHA: sibamba ukuboleka kuyo yonke i-a nge-`_marker`, futhi siyadalula
        // le nkomba kuphela, ngakho-ke ihlukile.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Buyela ekubolekeni okuhlukile okuthathwe ekuqaleni.
    ///
    /// # Safety
    ///
    /// Ukubolekwa kwemali kufanele ngabe kuphelile, okusho ukuthi, ireferensi ebuyiswe yi-`new` nazo zonke izikhombisi nezethenjwa ezisuselwe kuyo, akumele zisetshenziswe futhi.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // UKUPHEPHA: izimo zethu zokuphepha zisho ukuthi lesi sithenjwa siphinde sehlukile.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;