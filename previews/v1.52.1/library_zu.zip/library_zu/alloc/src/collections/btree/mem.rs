use core::intrinsics;
use core::mem;
use core::ptr;

/// Lokhu kufaka esikhundleni senani elingemuva kwesethenjwa esiyingqayizivele se-`v` ngokubiza umsebenzi ofanele.
///
///
/// Uma i-panic ivela ekuvalweni kwe-`change`, yonke inqubo izokhishwa.
#[allow(dead_code)] // gcina njengomfanekiso nokusetshenziswa kwe-future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Lokhu kufaka esikhundleni senani elingemuva kwesethenjwa esiyingqayizivele se-`v` ngokubiza umsebenzi ofanele, bese kubuyisa umphumela otholwe endleleni.
///
///
/// Uma i-panic ivela ekuvalweni kwe-`change`, yonke inqubo izokhishwa.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}