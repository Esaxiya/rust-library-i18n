// Lo ngumzamo wokuqalisa okulandela umbono
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Njengoba i-Rust ingenazo izinhlobo ezincike ekuphindaphindeni kwe-polymorphic, senza ngokungaqiniseki okuningi.
//

// Inhloso enkulu yalesi sigaba ukugwema ubunzima ngokuphatha isihlahla njengesithako esijwayelekile (uma senziwe ngendlela exakile) nokugwema ukubhekana nabahlaseli be-B-Tree abaningi.
//
// Kanjalo, le mojule ayinandaba ukuthi okufakiwe kuhlungwe yini, yiziphi izindawo ezingagcwaliswa ngokuphelele, noma nokuthi kusho ukuthini underfull.Kodwa-ke, sithembele kubahlaseli abambalwa:
//
// - Izihlahla kufanele zibe ne-depth/height efanayo.Lokhu kusho ukuthi yonke indlela eya eqabungeni kusuka kunodi enikeziwe inebude obufanayo ncamashi.
// - I-node yobude i-`n` inezikhiye ze-`n`, amanani we-`n`, nemiphetho ye-`n + 1`.
//   Lokhu kusho ukuthi noma ngabe i-node engenalutho ine-edge okungenani eyodwa.
//   Nge-node yamaqabunga, i-"having an edge" isho kuphela ukuthi singakhomba isikhundla ku-node, ngoba imiphetho yamaqabunga ayinalutho futhi ayidingi ukumelwa kwedatha.
// Ku-node yangaphakathi, i-edge yomibili ikhomba isikhundla futhi iqukethe isikhombisi ku-node yengane.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ukumelwa okuyisisekelo kwama-node amaqabunga kanye nengxenye yokumelwa kwama-node angaphakathi.
struct LeafNode<K, V> {
    /// Sifuna ukwenza i-covariant ku-`K` naku-`V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Inkomba yale node kuhlu lwe-node yomzali ye-`edges`.
    /// `*node.parent.edges[node.parent_idx]` kufanele kube into efanayo ne `node`.
    /// Lokhu kuqinisekiswe kuphela ukuthi kuzoqaliswa lapho i-`parent` ingasebenzi.
    parent_idx: MaybeUninit<u16>,

    /// Inombolo yokhiye namanani agcinwa yile node.
    len: u16,

    /// Ukuhlelwa okugcina idatha yangempela ye-node.
    /// Kuphela izakhi zokuqala ze-`len` zamalungu afanayo eziqalisiwe futhi zivumelekile.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Iqala i-`LeafNode` entsha endaweni.
    unsafe fn init(this: *mut Self) {
        // Njengenqubomgomo ejwayelekile, sishiya izinkambu zingaqaliwe uma kungenzeka, ngoba lokhu kufanele kusheshe kancane futhi kube lula ukulandela umkhondo eValgrind.
        //
        unsafe {
            // i-parent_idx, okhiye, nama-vals konke kungu-MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Idala ibhokisi elisha le-`LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ukumelwa okuyisisekelo kwama-node angaphakathi.Njengakuma-LeafNode`s, lokhu kufanele kufihlwe ngemuva kwe-`BoxedNode`s ukuvikela ukulahla okhiye namanani angaqaliwe.
/// Noma isiphi isikhombisi se-`InternalNode` singasakazwa ngqo kusikhombi engxenyeni engaphansi ye-`LeafNode` ye-node, ivumela ikhodi ukuthi isebenze kumakhasi naphakathi kwangaphakathi ngokujwayelekile ngaphandle kokuthi ibheke nokuthi yisiphi isikhombisi esikhomba kuso.
///
/// Le mpahla inikwe amandla ngokusetshenziswa kwe `repr(C)`.
///
#[repr(C)]
// gdb_providers.py isebenzisa leli gama lohlobo ukuzihlola.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Izinkomba ezinganeni zaleli node.
    /// `len + 1` kwalokhu kuthathwa njengokuqalisiwe futhi kusebenza, ngaphandle kokuthi ngasekupheleni, ngenkathi isihlahla siphethwe ngohlobo lokuboleka i `Dying`, ezinye zalezi zikhombisi zilenga.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Idala ibhokisi elisha le-`InternalNode`.
    ///
    /// # Safety
    /// Okungaguquguquki kwama-node wangaphakathi ukuthi okungenani ane-edge eyodwa eqalisiwe futhi esebenzayo.
    /// Lo msebenzi awusethi i-edge enjalo.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Sidinga ukuqala idatha kuphela;imiphetho yi-MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Isikhombi esiphethwe, esingeyona into engeyodwa esetshenziselwa i-node.Lokhu kungaba yisikhombi esiphethwe ku-`LeafNode<K, V>` noma isikhombi esingesika-`InternalNode<K, V>`.
///
/// Kodwa-ke, i-`BoxedNode` ayiqukethe imininingwane yokuthi yiziphi izinhlobo ezimbili zama-node equkethe, futhi, ngokwengxenye ngenxa yalokhu kushoda kolwazi, akuyona uhlobo oluhlukile futhi ayinayo imbhuqi.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// I-node yempande yesihlahla esinomnikazi.
///
/// Qaphela ukuthi lokhu akunaye umchithi, futhi kufanele kuhlanzwe ngesandla.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Ibuyisa umuthi omusha ophethwe, unezimpande zawo ezingeyokuqala ezingenalutho.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` akumele kube uziro.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Ngokusobala uboleka i-node yezimpande ephethwe.
    /// Ngokungafani ne-`reborrow_mut`, lokhu kuphephile ngoba inani lokubuyisa alinakusetshenziswa ukubhubhisa impande, futhi akunakubakhona ezinye izinkomba zesihlahla.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kancane kancane uboleka i-node yezimpande ephethwe.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ukuguqulwa okungaguquki kusithenjwa esivumela ukuwela futhi kunikeze izindlela ezilimazayo nokunye okunye.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Ingeza i-node entsha yangaphakathi ene-edge eyodwa ekhomba endaweni eyedlule yezimpande, yenza leyo node entsha i-node yezimpande, bese uyibuyisela.
    /// Lokhu kukhulisa ukuphakama ngo-1 futhi kuphambene ne `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ngaphandle kokuthi sikhohlwe nje ukuthi singaphakathi manje:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Isusa i-node yangaphakathi yezimpande, isebenzisa ingane yayo yokuqala njenge-node yezimpande entsha.
    /// Njengoba kuhloselwe ukubizwa kuphela lapho i-node yezimpande inengane eyodwa kuphela, akukho ukuhlanzwa okwenziwa kunoma ikuphi okhiye, amanani nezinye izingane.
    ///
    /// Lokhu kwehlisa ukuphakama ngo-1 futhi kuphambene ne `push_internal_level`.
    ///
    /// Kudinga ukufinyelela okukhethekile entweni engu-`Root` kepha hhayi ku-node yezimpande;
    /// ngeke ivimbele ezinye izibambo noma izinkomba endaweni yempande.
    ///
    /// I-Panics uma kungekho ileveli yangaphakathi, okungukuthi, uma i-node yezimpande iyiqabunga.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // UKUPHEPHA: sigomela ukuthi singaphakathi.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // UKUPHEPHA: siboleke i-`self` kuphela futhi uhlobo lwayo lokuboleka lukhethekile.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // UKUPHEPHA: i-edge yokuqala ihlala iqaliswa.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. I-`NodeRef` ihlala i-covariant ku-`K` naku-`V`, noma ngabe i `BorrowType` iyi-`Mut`.
// Lokhu akulungile ngokomthetho, kepha ngeke kuholele ekuphepheni ngenxa yokusetshenziswa kwangaphakathi kwe `NodeRef` ngoba sihlala sijwayelekile ngaphezu kwe `K` ne `V`.
//
// Kodwa-ke, noma nini lapho uhlobo lomphakathi lusonga i-`NodeRef`, qiniseka ukuthi inokuhluka okulungile.
//
/// Isethenjwa se-node.
///
/// Lolu hlobo lunamapharamitha amaningi alawula ukuthi lisebenza kanjani:
/// - `BorrowType`: Uhlobo lwe-dummy oluchaza uhlobo lokubolekwa noluthwala impilo yonke.
///    - Uma lokhu kuyi-`Immut<'a>`, i `NodeRef` isebenza cishe njenge `&'a Node`.
///    - Lapho lokhu kuyi-`ValMut<'a>`, i `NodeRef` isebenza ngokufana ne `&'a Node` maqondana nezinkinobho nokwakheka kwesihlahla, kepha futhi ivumela izinkomba eziningi eziguqukayo zamanani kuwo wonke umuthi ukuze zihlalisane.
///    - Uma lokhu kuyi-`Mut<'a>`, i-`NodeRef` isebenza cishe njenge-`&'a mut Node`, noma izindlela zokufaka zivumela isikhombisi esiguquguqukayo kunani lokuhlangana.
///    - Uma lokhu kuyi-`Owned`, i `NodeRef` isebenza ngokufana ne `Box<Node>`, kepha ayinayo incithakalo, futhi kufanele ihlanzwe ngesandla.
///    - Lapho lokhu kuyi-`Dying`, i `NodeRef` isasebenza cishe njenge `Box<Node>`, kepha inezindlela zokucekela phansi isihlahla kancane, futhi izindlela ezijwayelekile, ngenkathi zingamakiwe njengezingaphephile ukubiza, zingacela i-UB uma ibizwe ngokungalungile.
///
///   Njengoba noma iyiphi i-`NodeRef` ivumela ukuzulazula esihlahleni, i-`BorrowType` isebenza ngempumelelo kuso sonke isihlahla, hhayi kwi-node uqobo.
/// - `K` kanye ne-`V`: Lezi yizinhlobo zokhiye namanani agcinwe kuma-node.
/// - `Type`: Lokhu kungaba yi-`Leaf`, `Internal`, noma i-`LeafOrInternal`.
/// Uma lokhu kuyi-`Leaf`, i-`NodeRef` ikhomba endaweni engemuva kweqabunga, lapho lokhu kuyi-`Internal` i-`NodeRef` ikhomba kunodi yangaphakathi, futhi lapho lokhu kuyi-`LeafOrInternal` i-`NodeRef` kungenzeka ikhombe kunoma yiluphi uhlobo lwe-node.
///   `Type` ibizwa ngegama elithi `NodeType` lapho isetshenziswa ngaphandle kwe `NodeRef`.
///
/// Kokubili i-`BorrowType` ne-`NodeType` zikhawulela ukuthi yiziphi izindlela esizisebenzisayo, ukuxhaphaza ukuphepha kohlobo lwe-static.Kunemikhawulo endleleni esingasebenzisa ngayo leyo mikhawulo:
/// - Ngepharamitha yohlobo ngalunye, singachaza kuphela indlela ethile ngokwenziwa noma ngohlobo oluthile oluthile.
/// Isibonelo, asikwazi ukuchaza indlela efana ne-`into_kv` ngokujwayelekile kuyo yonke i-`BorrowType`, noma kanye kuzo zonke izinhlobo ezithwala impilo yonke, ngoba sifuna ukuthi ibuyise izinkomba ze-`&'a`.
///   Ngakho-ke, silichaza kuphela ngohlobo olunamandla amancane i `Immut<'a>`.
/// - Asikwazi ukuthola ukuphoqelelwa okusobala kusuka ku-`Mut<'a>` kuye ku-`Immut<'a>`.
///   Ngakho-ke, kufanele sishayele ngokusobala i-`reborrow` ku-`NodeRef` enamandla amakhulu ukuze sifinyelele indlela efana ne-`into_kv`.
///
/// Zonke izindlela ezikuma `NodeRef` ezibuyisa uhlobo oluthile lwesethenjwa, kungaba:
/// - Thatha i-`self` ngenani, bese ubuyisa isikhathi sempilo esiphethwe yi-`BorrowType`.
///   Kwesinye isikhathi, ukucela indlela enjalo, sidinga ukubiza i-`reborrow_mut`.
/// - Thatha i-`self` ngesethenjwa, bese u-(implicitly) ubuyise isikhathi sokuphila saleso sithenjwa, esikhundleni sempilo ephethwe yi-`BorrowType`.
/// Ngaleyo ndlela, isihloli sokuboleka siqinisekisa ukuthi i-`NodeRef` ihlala ibolekwe inqobo nje uma ireferensi ebuyisiwe isetshenziswa.
///   Izindlela ezisekela ukufaka okugoba lo mthetho ngokubuyisa isikhombisi esiluhlaza, okungukuthi, ireferensi ngaphandle kwempilo yonke.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Inani lamazinga i-node nezinga lamaqabunga ahlukene ngalo, ukuguquguquka kwe-node okungachazwa ngokuphelele yi-`Type`, nokuthi i-node uqobo ayigcini.
    /// Sidinga kuphela ukugcina ukuphakama kwe-node yezimpande, futhi sithola ukuphakama kwawo wonke amanye ama-node kuwo.
    /// Kumele kube uziro uma i-`Type` ingu-`Leaf` futhi engeyona iqanda uma i-`Type` ingu-`Internal`.
    ///
    ///
    height: usize,
    /// Isikhombi seqabunga noma i-node yangaphakathi.
    /// Incazelo ye `InternalNode` iqinisekisa ukuthi isikhombisi sisebenza nganoma iyiphi indlela.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Khipha ireferensi ye-node ebigcwele njenge-`NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Iveza idatha ye-node yangaphakathi.
    ///
    /// Ibuyisa i-ptr eluhlaza ukugwema ukwenza ezinye izinkomba zale node zingasebenzi.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // UKUPHEPHA: uhlobo lwe-static node ngu-`Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Uboleka ukufinyelela okukhethekile kwimininingwane ye-node yangaphakathi.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Thola ubude be-node.Le yinombolo yokhiye noma amanani.
    /// Inombolo yamaphethelo ngu-`len() + 1`.
    /// Qaphela ukuthi, yize uphephile, ukubiza lo msebenzi kungaba nomphumela oseceleni wokungasebenzi kahle kwezinkomba eziguqukayo ezenziwe yikhodi engaphephile.
    ///
    pub fn len(&self) -> usize {
        // Ngokweqile, sifinyelela kuphela inkambu ye `len` lapha.
        // Uma i-BorrowType iyi-marker::ValMut, kungahle kube nezinkomba eziguqukayo ezingaguquguquki zamanani okungafanele siwanikeze amandla.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Ibuyisa inani lamazinga ahlukaniswe yimo namaqabunga.
    /// Ukuphakama kwe-Zero kusho ukuthi i-node iqabunga uqobo.
    /// Uma ucabanga ngezihlahla ezinezimpande ngaphezulu, inombolo ithi kuphakama indawo lapho kuvela khona.
    /// Uma ucabanga ngezihlahla ezinamaqabunga ngaphezulu, inombolo ithi isihlahla siphakeme kangakanani ngaphezu kwe-node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Ithatha okwesikhashana enye, ireferensi engaphenduki kunodi efanayo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Iveza ingxenye yamaqabunga yanoma yiliphi iqabunga noma i-node yangaphakathi.
    ///
    /// Ibuyisa i-ptr eluhlaza ukugwema ukwenza ezinye izinkomba zale node zingasebenzi.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // I-node kufanele isebenze okungenani engxenyeni yeLeafNode.
        // Lesi akusona isethenjwa sohlobo lweNodeRef ngoba asazi noma kufanele sihluke noma sabiwe.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ithola umzali wenodi yamanje.
    /// Ibuyisa i-`Ok(handle)` uma ngabe i-node yamanje inomzali, lapho i-`handle` ikhomba ku-edge yomzali ekhomba kunodi yamanje.
    ///
    /// Ibuyisa i-`Err(self)` uma ngabe i-node yamanje ingenamzali, ibuyisa i-`NodeRef` yoqobo.
    ///
    /// Igama lendlela licabanga ukuthi unezithombe zezihlahla ezine-node yezimpande ngaphezulu.
    ///
    /// `edge.descend().ascend().unwrap()` futhi i `node.ascend().unwrap().descend()` kufanele, ekuphumeleleni, ingenzi lutho.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Sidinga ukusebenzisa izikhombisi ezingavuthiwe kuma-node ngoba, uma i-BorrowType iyi-marker::ValMut, kungahle kube nezikhombo eziguqukayo eziguqukayo kumanani okungafanele siwenzile angasebenzi.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Qaphela ukuthi i-`self` kumele ingabi nokukhululeka.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Qaphela ukuthi i-`self` kumele ingabi nokukhululeka.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Iveza ingxenye yamaqabunga yanoma yiliphi iqabunga noma i-node yangaphakathi esihlahleni esingaguquguquki.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // UKUPHEPHA: akunakubakhona izinkomba eziguqukayo kulesi sihlahla esibolekwe njenge-`Immut`.
        unsafe { &*ptr }
    }

    /// Uboleka ukubuka kuzinkinobho ezigcinwe ku-node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ngokufana ne-`ascend`, ithola ireferensi kunodi yomzali ye-node, kepha futhi ihambisa i-node yamanje kunqubo.
    /// Lokhu akuphephile ngoba i-node yamanje isazotholakala yize ihanjisiwe.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kufakazelwa ngokungaphephile kumhlanganisi imininingwane emile yokuthi le node iyi-`Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kufakazelwa ngokungaphephile kumhlanganisi imininingwane emile yokuthi le node iyi-`Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Ithatha okwesikhashana enye inkomba, engaguquguquki yenodi efanayo.Qaphela, ngoba le ndlela iyingozi kakhulu, kabili ngoba kungenzeka ingabonakali ngokushesha iyingozi.
    ///
    /// Ngoba izikhombisi eziguqukayo zingazulazula noma kuphi eduze kwesihlahla, isikhombisi esibuyisiwe singasetshenziswa kalula ukwenza i-pointer yangempela ilenga, iphume emingceleni, noma ingavumelekile ngaphansi kwemithetho yokubolekwa embondelene.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) cabanga ukungeza enye futhi ipharamitha yohlobo ku-`NodeRef` evimbela ukusetshenziswa kwezindlela zokuzulazula kuzikhombi ezibolekwe kabusha, ukuvimbela lokhu kungavikeleki.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Uboleka ukufinyelela okukhethekile engxenyeni yeqabunga yanoma yiliphi iqabunga noma i-node yangaphakathi.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // UKUPHEPHA: sinokufinyelela okukhethekile kuyo yonke i-node.
        unsafe { &mut *ptr }
    }

    /// Inikeza ukufinyelela okukhethekile engxenyeni yeqabunga yanoma yiliphi iqabunga noma i-node yangaphakathi.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // UKUPHEPHA: sinokufinyelela okukhethekile kuyo yonke i-node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Uboleka ukufinyelela okukhethekile entweni yendawo yokugcina eyisihluthulelo.
    ///
    /// # Safety
    /// `index` isemikhawulweni 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // UKUPHEPHA: umuntu ofonayo ngeke akwazi ukuzishayela ezinye izindlela kuye
        // kuze kushiywe inkomba yesilayidi sokhiye, njengoba sinokufinyelela okuyingqayizivele ngesikhathi sempilo yokubolekwa.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Uboleka ukufinyelela okukhethekile entweni noma kocezu lwendawo yokugcina inani le-node.
    ///
    /// # Safety
    /// `index` isemikhawulweni 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // UKUPHEPHA: umuntu ofonayo ngeke akwazi ukuzishayela ezinye izindlela kuye
        // kuze kukhishwe ireferensi yocezu lwenani, njengoba sinokufinyelela okuyingqayizivele ngesikhathi sempilo yokubolekwa.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Uboleka ukufinyelela okukhethekile entweni noma kocezu lwendawo yokugcina indawo engeyokuqukethwe kwe-edge.
    ///
    /// # Safety
    /// `index` ikumingcele we-0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // UKUPHEPHA: umuntu ofonayo ngeke akwazi ukuzishayela ezinye izindlela kuye
        // kuze kube yilapho kususwa isethenjwa sesilayidi se-edge, njengoba sinokufinyelela okuyingqayizivele ngesikhathi sempilo yokubolekwa.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - I-node inezakhi ezingaphezu kwe-`idx` eziqaliwe.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Sakha kuphela ireferensi entweni eyodwa esinentshisekelo kuyo, ukugwema ukuhlobana nezethenjwa ezivelele zezinye izinto, ikakhulukazi, lezo ezibuyiselwe kofonayo kuma-iterations angaphambilini.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kumele siphoqelele izikhombisi-ndlela ezingafakwanga usayizi ngenxa yenkinga ye-Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Uboleka ukufinyelela okukhethekile kubude be-node.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Isetha isixhumanisi se-node kumzali wayo u-edge, ngaphandle kokwenza ezinye izinkomba ze-node zingasebenzi.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Isula isixhumanisi sezimpande kumzali wayo u edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ingeza inani lenani lokhiye ekugcineni kwe-node.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Yonke into ebuyiswe yi-`range` iyinkomba evumelekile ye-edge ye-node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ingeza ipheya yenani lokhiye, ne-edge ukuya kwesokudla kwalelo pair, ekugcineni kwe-node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Ihlola ukuthi ngabe i-node iyi-node ye-`Internal` noma i-node ye-`Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Isethenjwa sepheya yenani lokhiye elithile noma i-edge ngaphakathi kwenodi.
/// Ipharamitha ye-`Node` kufanele ibe yi-`NodeRef`, kuyilapho i-`Type` ingaba yi-`KV` (okukhombisa isibambo kubhangqa lenani lokhiye) noma i-`Edge` (okukhombisa isibambo ku-edge).
///
/// Qaphela ukuthi ngisho ama-`Leaf` node angaba nezibambo ze-`Edge`.
/// Esikhundleni sokumelela isikhombisi endaweni yezingane, lezi zimelela izikhala lapho izikhombisi zezingane zingahamba khona phakathi kwamabili wenani lokhiye.
/// Isibonelo, ku-node enobude obungu-2, kuzoba nezindawo ezi-3 ezikhona ze-edge, eyodwa ngakwesobunxele se-node, eyodwa phakathi kwamabili amabili, nenye engakwesokudla kwe-node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Asidingi ukwenziwa okuphelele kwe-`#[derive(Clone)]`, ngoba ukuphela kwesikhathi i-`Node` ezobe ingu-Clone`able kulapho kuyisithenjwa esingaguquki ngakho-ke i-`Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Ibuyisa i-node equkethe i-edge noma i-value-value pair leli phuzu lesibambo.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Ibuyisa ukuma kwalesi sibambo kunodi.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Kwakha isibambo esisha kubhangqa lenani lokhiye ku-`node`.
    /// Akuphephile ngoba umuntu ofonayo kufanele aqinisekise ukuthi i-`idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kungaba ukusetshenziswa komphakathi kwePartialEq, kepha kusetshenziswe kuphela kule mojule.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Ikhipha esinye isibambo esingaguquki okwesikhashana endaweni efanayo.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Asikwazi ukusebenzisa i-Handle::new_kv noma i-Handle::new_edge ngoba asilwazi uhlobo lwethu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Iqinisekisa ngokungaphephile kumhlanganisi imininingwane emile yokuthi indawo yokubamba i-`Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Ikhipha okwesikhashana esinye isibambo, esiguquguqukayo endaweni efanayo.
    /// Qaphela, ngoba le ndlela iyingozi kakhulu, kabili ngoba kungenzeka ingabonakali ngokushesha iyingozi.
    ///
    ///
    /// Ngemininingwane, bheka i `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Asikwazi ukusebenzisa i-Handle::new_kv noma i-Handle::new_edge ngoba asilwazi uhlobo lwethu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Idala isibambo esisha ku-edge ku-`node`.
    /// Akuphephile ngoba umuntu ofonayo kufanele aqinisekise ukuthi i-`idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Njengoba kunikezwe inkomba ye-edge lapho sifuna ukufaka khona ku-node egcwaliswe ngomthamo, ihlanganisa inkomba ye-KV enengqondo yephoyinti lokuhlukanisa nokuthi kufanele kufakwe kuphi.
///
/// Umgomo wephoyinti lokwehlukanisa ukhiye nenani lalo kugcine ku-node yomzali;
/// okhiye, amanani namaphethelo kwesobunxele sephoyinti lokuhlukaniswa baba yingane yangakwesobunxele;
/// okhiye, amanani nemiphetho engakwesokudla kwephoyinti lokuhlukanisa baba ingane efanele.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Ukukhishwa kwe-Rust i-#74834 izama ukuchaza le mithetho ehambisanayo.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ifaka ipheya lenani lokhiye omusha phakathi kwamapheya wenani lokhiye ngakwesokudla nangakwesobunxele sale edge.
    /// Le ndlela icabanga ukuthi kunesikhala esanele endaweni engezansi ukuthi i-pair entsha ilingane.
    ///
    /// Isikhombi esibuyiselwe sikhomba kunani elifakiwe.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ifaka ipheya lenani lokhiye omusha phakathi kwamapheya wenani lokhiye ngakwesokudla nangakwesobunxele sale edge.
    /// Le ndlela ihlukanisa indawo uma ingekho indawo eyanele.
    ///
    /// Isikhombi esibuyiselwe sikhomba kunani elifakiwe.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ilungisa isikhombisi somzali nenkomba kunodi yengane le edge exhuma kuyo.
    /// Lokhu kuyasiza lapho uku-oda kwemiphetho kushintshiwe,
    fn correct_parent_link(self) {
        // Dala i-backpointer ngaphandle kokuvumela ezinye izinkomba ku-node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ifaka ipheya lenani lokhiye omusha ne-edge ezizoya kwesokudla kwalelobhangqa elisha phakathi kwale edge nombhangqwana wenani lokhiye ngakwesokunene sale edge.
    /// Le ndlela icabanga ukuthi kunesikhala esanele endaweni engezansi ukuthi i-pair entsha ilingane.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ifaka ipheya lenani lokhiye omusha ne-edge ezizoya kwesokudla kwalelobhangqa elisha phakathi kwale edge nombhangqwana wenani lokhiye ngakwesokunene sale edge.
    /// Le ndlela ihlukanisa indawo uma ingekho indawo eyanele.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ifaka ipheya lenani lokhiye omusha phakathi kwamapheya wenani lokhiye ngakwesokudla nangakwesobunxele sale edge.
    /// Le ndlela ihlukanisa i-node uma ingekho indawo eyanele, futhi izama ukufaka ingxenye ehlukanisiwe endaweni ye-parent ephindaphindwayo, kuze kufinyelelwe empandeni.
    ///
    ///
    /// Uma imiphumela ebuyisiwe kuyi-`Fit`, indawo yokubamba yayo ingaba yile node ye edge noma idlozi.
    /// Uma umphumela obuyisiwe uyi-`Split`, inkambu ye-`left` izoba yindawo engeyokuqala yezimpande.
    /// Isikhombi esibuyiselwe sikhomba kunani elifakiwe.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Ithola indawo ekhonjwe yile edge.
    ///
    /// Igama lendlela licabanga ukuthi unezithombe zezihlahla ezine-node yezimpande ngaphezulu.
    ///
    /// `edge.descend().ascend().unwrap()` futhi i `node.ascend().unwrap().descend()` kufanele, ekuphumeleleni, ingenzi lutho.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Sidinga ukusebenzisa izikhombisi ezingavuthiwe kuma-node ngoba, uma i-BorrowType iyi-marker::ValMut, kungahle kube nezikhombo eziguqukayo eziguqukayo kumanani okungafanele siwenzile angasebenzi.
        // Akukho ukukhathazeka ngokufinyelela inkambu yokuphakama ngoba lelo nani likopishiwe.
        // Qaphela ukuthi, lapho isikhombisi se-node sesingasetshenziswanga, sifinyelela emaphethelweni afanayo nesethenjwa (ukukhishwa kwe-Rust #73987) bese senza noma yiziphi ezinye izinkomba eziya ngaphakathi noma ngaphakathi kwamalungu afanayo, uma kukhona okukhona.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Asikwazi ukubiza izindlela zokhiye ezihlukile nezenani, ngoba ukubiza eyesibili kwenza ireferensi ebuyiswe eyokuqala kungasebenzi.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Shintsha ukhiye nenani isibambo se-KV esibhekisele kulo.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Isiza ukuqaliswa kwe-`split` nge-`NodeType` ethile, ngokunakekela idatha yamaqabunga.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Ihlukanisa indawo engezansi ibe izingxenye ezintathu:
    ///
    /// - I-node ishunquliwe ukuthi iqukathe kuphela amapheya wenani lokhiye ngakwesokunxele kwalesi sibambo.
    /// - Ukhiye nenani elikhonjwe kulesi sibambo likhishiwe.
    /// - Onke amabhangqa enani lokhiye ongakwesokudla kwalesi sibambo afakwa kunodi esanda kwabiwa.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Isusa inani lenani lokhiye elikhonjwe kulesi sibambo bese liyalibuyisa, kanye ne-edge iwele lenani lokhiye eliwele kulo.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Ihlukanisa indawo engezansi ibe izingxenye ezintathu:
    ///
    /// - I-node incishisiwe ukuthi iqukathe kuphela imiphetho namanani wamanani okhiye ngakwesokunxele kwalesi sibambo.
    /// - Ukhiye nenani elikhonjwe kulesi sibambo likhishiwe.
    /// - Yonke imiphetho namabili wenani lokhiye ngakwesokunene salesi sibambo afakwa kunodi esanda kwabiwa.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Imelela iseshini yokuhlola nokwenza umsebenzi wokulinganisa ezungeze i-pair yenani langaphakathi lokhiye.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ikhetha umongo wokulinganisela ofaka phakathi i-node njengengane, ngaleyo ndlela phakathi kwe-KV ngokushesha ngakwesobunxele noma kwesokudla ku-node yomzali.
    /// Ibuyisa i `Err` uma kungekho mzali.
    /// Panics uma umzali engenalutho.
    ///
    /// Kuncamela ohlangothini lwesobunxele, ukuze lusebenze kahle uma ngabe i-node enikeziwe ngandlela thile igcwele, okusho ukuthi lapha kuphela ukuthi inezinto ezimbalwa kunengane yakubo yangakwesobunxele nangaphezu kwengane yakubo yangakwesokudla, uma ikhona.
    /// Kuleso simo, ukuhlangana nengane yakini yangakwesobunxele kuyashesha, ngoba sidinga kuphela ukuhambisa izinto ze-node's N, esikhundleni sokuzihambisa kwesokudla futhi sihambise ngaphezu kwezakhi ze-N ngaphambili.
    /// Ukweba enganeni yangakwesobunxele nakho kushesha ngokwejwayelekile, ngoba sidinga kuphela ukuhambisa izinto ze-node's N ziye kwesokudla, esikhundleni sokuhambisa okungenani u-N wezinto zakubo ngakwesobunxele.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Ibuyisa ukuthi ukuhlangana kungenzeka yini, okungukuthi, ngabe kunendawo eyanele kunodi yokuhlanganisa i-KV emaphakathi nazo zombili izingqimba zezingane eziseduze.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Yenza ukuhlangana bese ivumela ukuvalwa kunqume ukuthi kubuyiswa ini.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // UKUPHEPHA: ukuphakama kwezindawo ezihlanganisiwe kungaphansi kokuphakama
                // kwe-node yale edge, ngaleyo ndlela ingaphezulu kuka-zero, ngakho-ke ingaphakathi.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ihlanganisa ipheya yenani lokhiye lomzali futhi womabili ama-node wezingane aseduze ne-node yengane yesobunxele bese ibuyisa i-node yomzali enciphile.
    ///
    ///
    /// I-Panics ngaphandle kokuthi si-`.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ihlanganisa ipheya yenani lokhiye lomzali futhi womabili ama-node wezingane aseduze ne-node yengane yangakwesokunxele bese ibuyisa leyo node yengane.
    ///
    ///
    /// I-Panics ngaphandle kokuthi si-`.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ihlanganisa ipheya yenani lokhiye lomzali futhi womabili ama-node wezingane aseduze ne-node yengane yesobunxele bese ibuyisa isibambo se-edge kuleyo node yengane lapho ingane elandelelwe i-edge iphele khona,
    ///
    ///
    /// I-Panics ngaphandle kokuthi si-`.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Isusa ipheya yenani lokhiye kusuka enganeni yangakwesobunxele bese ikubeka kwisitoreji senani lokhiye lomzali, ngenkathi icindezela ipheya lenani lokhiye lomzali elidala enganeni elungile.
    ///
    /// Ibuyisa isibambo ku-edge enganeni elungile ehambisana nokuthi i edge yoqobo ecaciswe yi-`track_right_edge_idx` yagcina kuphi.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Isusa ipheya yenani lokhiye kusuka enganeni engakwesokudla bese ikubeka kwisitoreji senani lokhiye lomzali, ngenkathi icindezela ipheya lenani lokhiye lomzali elidala enganeni yangakwesobunxele.
    ///
    /// Ibuyisa isibambo ku-edge enganeni yangakwesokunxele eshiwo i-`track_left_edge_idx`, engazange ihambe.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Lokhu kweba okufana ne-`steal_left` kepha kweba izinto eziningi ngasikhathi sinye.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Qiniseka ukuthi sintshontsha ngokuphepha.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Hambisa idatha yeqabunga.
            {
                // Yenza isikhala sezinto ezebiwe enganeni efanele.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Hambisa izinto ezisuka enganeni yesobunxele ziye kwesokudla.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Hambisa ukubhangqa kwesokunxele kakhulu kumzali.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Hambisa ukubhangqa kwenani lokhiye enganeni elungile.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Yenza indawo yemiphetho eyebiwe.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ukweba imiphetho.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// I-clone ehambisanayo ye-`bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Qiniseka ukuthi sintshontsha ngokuphepha.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Hambisa idatha yeqabunga.
            {
                // Hambisa izithandani ezebiwe kwesokudla ziye kumzali.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Hambisa ukubhangqa kwenani lokhiye enganeni engakwesobunxele.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Hambisa izinto ezisuka enganeni engakwesokudla ziye kwesobunxele.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Gcwalisa igebe lapho izinto ezebiwe zazikhona.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ukweba imiphetho.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Gcwalisa igebe lapho imiphetho eyebiwe ibikade ikhona.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Isusa noma yiluphi ulwazi lwe-tuli oluqinisekisa ukuthi le node iyinodi ye-`Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Isusa noma yiluphi ulwazi lwe-static oluqinisekisa ukuthi le node iyinodi ye-`Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Ihlola ukuthi ngabe i-node eyisisekelo i-node ye-`Internal` noma i-node ye-`Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Hambisa isijobelelo ngemuva kwe-`self` usuke endaweni eyodwa uye kwesinye.I `right` kufanele ingabi nalutho.
    /// I-edge yokuqala ye-`right` ihlala ingashintshiwe.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Umphumela wokufakwa, lapho i-node idinga ukukhulisa ngaphezu kwamandla ayo.
pub struct SplitResult<'a, K, V, NodeType> {
    // I-node eshintshiwe esihlahleni esivele sinezinto nemiphetho engeyesobunxele se `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Omunye ukhiye nenani lihlukanisiwe, ukuze lifakwe kwenye indawo.
    pub kv: (K, V),
    // I-node entsha ephethwe, engaxhumekile, enezinto nemiphetho engakwesokudla kwe `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ukuthi izinkomba zama-node zalolu hlobo lokuboleka zivumela ukweqa kwamanye ama-node esihlahleni.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ITraversal ayidingeki, kwenzeka kusetshenziswa umphumela we `borrow_mut`.
        // Ngokukhubaza ukudabula, futhi nokwakha kuphela izinkomba ezintsha ezimpandeni, siyazi ukuthi zonke izinkomba zohlobo lwe `Owned` zisezimpandeni.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Ifaka inani kucezu lwezinto eziqaliwe ezilandelwa into eyodwa engaqalisiwe.
///
/// # Safety
/// Isilayidi sinezinto ezingaphezu kwe-`idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Isusa futhi ibuyise inani ocezwini lwazo zonke izinto eziqaliwe, kushiye ngemuva into eyodwa engaqaliwe.
///
///
/// # Safety
/// Isilayidi sinezinto ezingaphezu kwe-`idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Ishintsha izinto ngocezu lwezikhundla ze-`distance` ngakwesokunxele.
///
/// # Safety
/// Isilayidi sinezinto okungenani ze-`distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Ishintsha izinto ngocezu lwezikhundla ze `distance` kwesokudla.
///
/// # Safety
/// Isilayidi sinezinto okungenani ze-`distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ihambisa wonke amanani kusuka kusilayidi sezinto eziqaliwe kuya kusilayidi sezinto ezingakaqalwa, kushiya ngemuva i-`src` njengakho konke okungakaqalwa.
///
/// Isebenza njenge-`dst.copy_from_slice(src)` kepha ayidingi i-`T` ukuthi ibe yi-`Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;