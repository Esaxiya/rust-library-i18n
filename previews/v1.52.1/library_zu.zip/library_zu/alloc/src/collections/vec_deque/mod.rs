//! Ulayini ophela kabili osetshenzisiwe ngebhafa yendandatho engakhula.
//!
//! Lo mugqa uno-*O*(1) wokufaka okukhishwe ngaphakathi nokususwa kuzo zombili izinhlangothi zesiqukathi.
//! Ibuye ibe nenkomba ye-*O*(1) efana ne-vector.
//! Izinto eziqukethwe akudingeki ukuthi zikopisheke, futhi ulayini uzothunyelwa uma uhlobo oluqukethwe luthunyelwa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Amandla amakhulu kakhulu kungenzeka amabili

/// Ulayini ophela kabili osetshenzisiwe ngebhafa yendandatho engakhula.
///
/// Ukusetshenziswa kwe-"default" kwalolu hlobo njengomugqa ukusebenzisa i-[`push_back`] ukwengeza kulayini, ne-[`pop_front`] ukususa kulayini.
///
/// [`extend`] futhi i-[`append`] icindezela emuva ngale ndlela, futhi ukushayisana okungaphezu kwe-`VecDeque` kuya phambili kuya emuva.
///
/// Njengoba i-`VecDeque` iyisidikibha sendandatho, izakhi zayo akuzona neze ezokukhumbula.
/// Uma ufuna ukufinyelela ezintweni njengocezu olulodwa, olufana nokuhlelwa kahle, ungasebenzisa i [`make_contiguous`].
/// Izungezisa i `VecDeque` ukuze izinto zayo zingasongeli, bese ibuyisa isilayidi esiguquguqukayo kulokho okuhlangana manje.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // umsila nekhanda kuyizikhombisi zesikhashana.
    // Umsila uhlala ukhomba into yokuqala engafundwa, iNhloko ihlala ikhomba lapho kufanele kubhalwe khona idatha.
    //
    // Uma umsila==ikhanda ibhafa ayinalutho.Ubude be-ringbuffer buchazwa njengebanga phakathi kwalokhu okubili.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Isebenzisa umbhubhisi wazo zonke izinto kusilayidi lapho sehla (imvamisa noma ngesikhathi sokuphumula).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // sebenzisa i-drop ye-[T]
            ptr::drop_in_place(front);
        }
        // I-RawVec isingatha ukuhanjiswa
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Idala i-`VecDeque<T>` engenalutho.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Kancane kancane kube lula
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Kancane kancane kube lula
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Ezinhlotsheni ezingekho zero, sihlala sinamandla amakhulu
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Shintsha i-ptr ibe ucezu
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Shintsha i-ptr ibe ucezu lwe-mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Ihambisa into ngaphandle kwebhafa
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Ubhala into ku-buffer, eyihambisa.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Ibuyisa i-`true` uma i-buffer isebenza ngokugcwele.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Ibuyisa inkomba kubhafa engaphansi yenkomba yezinto ezinengqondo enikeziwe.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Ibuyisa inkomba kubhafa eyisisekelo ye-index enezici ezinengqondo enikeziwe.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Ibuyisa inkomba kubhafa engaphansi yenkomba yezinto ezinengqondo ezinikeziwe, ukukhipha.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Ikopisha ibhulokhi ehlanganayo yememori len kusuka ku-src kuya ku-dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Ikopisha ibhulokhi ehlanganayo yememori len kusuka ku-src kuya ku-dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Ikopisha ibhulokhi yememori lens engahle isongelwe isuka ku-src iye ekugcineni.
    /// (abs(dst - src) + len) akumele ibe nkulu kune-cap() (Kufanele okungenani kube nesifunda esisodwa esigudlanayo esiqhubekayo phakathi kwe-src ne-dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // I-src ayisongeli, i-dst ayisongeli
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst ngaphambi kwe-src, i-src ayisongeli, i-dst wraps
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // I-src ngaphambi kwe-dst, i-src ayisongeli, i-dst wraps
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst ngaphambi kwe-src, src ezisongelayo, i-dst ayisongeli
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // I-src ngaphambi kwe-dst, i-src isonga, i-dst ayisongeli
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst ngaphambi kokugoqwa kwe-src, i-src, i-dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // I-src ngaphambi kwe-dst, i-src isonga, i-dst wraps
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Izinhlaka zekhanda nomsila ezizungezile ukusingatha iqiniso lokuthi sisanda kwabelana kabusha.
    /// Akuphephile ngoba kuyathenjelwa amandla_akudala.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Hambisa isigaba esifushane kakhulu esihlanganayo sesisetshenziswa sendandatho i-TH
        //
        //   [o o o o o o o . ]
        //    ITHA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              IHTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // I-Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Idala i-`VecDeque` engenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Kwakha i-`VecDeque` engenalutho enesikhala okungenani sezinto ze-`capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ngoba i-ringbuffer ihlala ishiya isikhala esisodwa singenalutho
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Inikeza ireferensi yento enkombeni enikeziwe.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Inikezela ngesethenjwa esiguquguqukayo entweni enkombeni enikeziwe.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ishintsha izinto kuma-indices `i` naku-`j`.
    ///
    /// `i` futhi i-`j` ingalingana.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Panics
    ///
    /// I-Panics uma ngabe enye inkomba ingaphandle kwemingcele.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Ibuyisa inani lezinto i-`VecDeque` engazibamba ngaphandle kokuphinda ithunyelwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Igcina umthamo omncane wezinto ezingama-`additional` ngaphezulu ezizofakwa ku-`VecDeque` enikeziwe.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// Qaphela ukuthi umhlinzeki anganikeza iqoqo isikhala esengeziwe kunalokho elikucelayo.
    /// Ngakho-ke umthamo awunakuthenjelwa kuwo ukuthi ube mncane ngokunembile.
    /// Khetha i-[`reserve`] uma kulindelwe ukufakwa kwe-future.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha uchichima i-`usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Igcina amandla okungenani ama-`additional` ezinto eziningi ezizofakwa ku-`VecDeque` enikeziwe.
    /// Iqoqo lingagcina isikhala esithe xaxa ukugwema ukwabiwa kabusha okuvamile.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha uchichima i-`usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Izama ukugcina umthamo omncane wezinto ezingama-`additional` ngaphezulu ezizofakwa ku-`VecDeque<T>` enikeziwe.
    ///
    /// Ngemuva kokushayela i-`try_reserve_exact`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// Qaphela ukuthi umhlinzeki anganikeza iqoqo isikhala esengeziwe kunalokho elikucelayo.
    /// Ngakho-ke, umthamo awunakwethenjelwa kuwo ukuthi ube mncane ngokunembile.
    /// Khetha i-`reserve` uma kulindelwe ukufakwa kwe-future.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima i-`usize`, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le ayikwazi i OOM(Out-Of-Memory) maphakathi nomsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // kuyinkimbinkimbi kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Izama ukugcina umthamo okungenani wezinto ezingama-`additional` eziningi ezizofakwa ku-`VecDeque<T>` enikeziwe.
    /// Iqoqo lingagcina isikhala esithe xaxa ukugwema ukwabiwa kabusha okuvamile.
    /// Ngemuva kokushayela i-`try_reserve`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima i-`usize`, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le i-OOM ayikwazi phakathi nomsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // kuyinkimbinkimbi kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Yehlisa umthamo we `VecDeque` ngangokunokwenzeka.
    ///
    /// Izokwehla iseduze ngangokunokwenzeka ebangeni kepha umabi isazokwazisa i `VecDeque` ukuthi kunesikhala sezinto ezimbalwa ezengeziwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Yehlisa umthamo we `VecDeque` ngentambo ephansi.
    ///
    /// Umthamo uzohlala okungenani ukhulu njengokubili ubude nenani elinikeziwe.
    ///
    ///
    /// Uma umthamo wamanje ungaphansi komkhawulo ophansi, lena yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Akudingeki sikhathazeke ngokuchichima njengoba ne `self.len()` noma i `self.capacity()` zingasoze zaba yi `usize::MAX`.
        // +1 njengoba i-ringbuffer ihlala ishiya isikhala esisodwa singenalutho.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Kunamacala amathathu enzalo:
            //   Zonke izinto zingaphandle kwemingcele oyifunayo Izinto ziyacijwa, futhi ikhanda alikho kwemingcele oyifunayo Ama-elementi awaziwa, futhi umsila ungaphandle kwemingcele oyifunayo
            //
            //
            // Ngazo zonke ezinye izikhathi, izikhundla zezinto azithinteki.
            //
            // Kubonisa ukuthi izinto ezisekhanda kufanele zihanjiswe.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Hambisa izinto kusuka kumingcele oyifunayo (izikhundla ngemuva kwe-target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // I-HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Ifinyeza i `VecDeque`, igcine izakhi zokuqala ze-`len` bese ilahla okusele.
    ///
    ///
    /// Uma i-`len` inkulu kunobude bamanje be-`VecDeque`, lokhu akunamphumela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Isebenzisa umbhubhisi wazo zonke izinto kusilayidi lapho sehla (imvamisa noma ngesikhathi sokuphumula).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Kuphephile ngoba:
        //
        // * Noma yisiphi isilayidi esidluliselwe ku-`drop_in_place` sisebenza;icala lesibili line-`len <= front.len()` futhi ukubuyela ku-`len > self.len()` kuqinisekisa i-`begin <= back.len()` ecaleni lokuqala
        //
        // * Inhloko yeVecDeque iyasuswa ngaphambi kokushayela i `drop_in_place`, ngakho-ke alikho inani elilahlwayo kabili uma i-`drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Qiniseka ukuthi uhhafu wesibili wehlisiwe noma ngabe umonakalisi kweyokuqala i panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Ibuyisa iterator engaphambili nangemuva.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Ibuyisa iterator engaphambili nangemuva ebuyisa izinkomba eziguqukayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // UKUPHEPHA: Okungena ngaphakathi kwezokuphepha kwe `IterMut` kusungulwa ngoba
        // `ring` sakha ucezu olungasetshenziswanga lokuphila konke '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Ibuyisa izingcezwana eziqukethe, ngokulandelana, okuqukethwe yi-`VecDeque`.
    ///
    /// Uma i-[`make_contiguous`] ibibizwa ngaphambilini, zonke izinto ze-`VecDeque` zizoba kusilayidi sokuqala bese ucezu lwesibili luzobe lungenalutho.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Ibuyisa izingcezwana eziqukethe, ngokulandelana, okuqukethwe yi-`VecDeque`.
    ///
    /// Uma i-[`make_contiguous`] ibibizwa ngaphambilini, zonke izinto ze-`VecDeque` zizoba kusilayidi sokuqala bese ucezu lwesibili luzobe lungenalutho.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Ibuyisa inani lezinto ku-`VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Ibuyisa i-`true` uma i-`VecDeque` ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Idala i-iterator ehlanganisa ububanzi obucacisiwe ku-`VecDeque`.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala likhulu kunendawo yokugcina noma uma iphuzu lokugcina likhulu kunobude be-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Ububanzi obugcwele buhlanganisa konke okuqukethwe
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Isethenjwa esabiwe esinaso ku &self sigcinwa ku-'_ ye-Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Idala i-iterator emboza ububanzi obucacisiwe bokuguquguquka ku-`VecDeque`.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala likhulu kunendawo yokugcina noma uma iphuzu lokugcina likhulu kunobude be-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Ububanzi obugcwele buhlanganisa konke okuqukethwe
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // UKUPHEPHA: Okungena ngaphakathi kwezokuphepha kwe `IterMut` kusungulwa ngoba
        // `ring` sakha ucezu olungasetshenziswanga lokuphila konke '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Kwakha i-iterator yokukhipha esusa ububanzi obucacisiwe ku-`VecDeque` futhi iveze izinto ezisusiwe.
    ///
    /// Qaphela 1: Ububanzi bezinto buyasuswa noma ngabe i-iterator ingadliwanga kuze kube sekupheleni.
    ///
    /// Qaphela 2: Akucacisiwe ukuthi mangaki ama-elementi asuswe kudeski, uma inani le-`Drain` lingalahlwanga, kepha ukubolekwa elikuphethe kuyaphela (isb. Ngenxa ye-`mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala likhulu kunendawo yokugcina noma uma iphuzu lokugcina likhulu kunobude be-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Ububanzi obugcwele busula konke okuqukethwe
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Ukuphepha kwememori
        //
        // Lapho i Drain idalwa okokuqala, idesque yomthombo iyancishiswa ukuze kuqinisekiswe ukuthi azikho izinto ezingaqalisiwe noma ezisuswayo ezifinyeleleka nhlobo uma umchithi we Drain engakaze asebenze.
        //
        //
        // I-Drain izokhipha amanani okuzosuswa u-ptr::read.
        // Lapho isiqedile, idatha esele izokopishelwa emuva ukuvala umgodi, futhi amanani we-head/tail azobuyiselwa kahle.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Izakhi zedeque zehlukaniswe zaba izingxenye ezintathu:
        // * self.tail  -> drain_tail
        // * I-drain_tail-> drain_head
        // * I-drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=I-drain_tail;h=drain_head
        //
        // Sigcina i-drain_tail njenge-self.head, ne-drain_head ne-self.head njenge-after_tail kanye ne-after_head ngokulandelana ku-Drain.
        // Lokhu futhi kunciphisa ukuhleleka okusebenzayo okuthi uma i-Drain idaluliwe, sikhohliwe ngamanani angahle asuswe ngemuva kokuqala kwe-drain.
        //
        //
        //        I-H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" mayelana namanani ngemuva kokuqala kwe-drain kuze kube yilapho i-drain isiqedile futhi umchithi we-Drain eqhutshwa.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ngokweqile, sakha kuphela izinkomba ezabiwe kusuka ku-`self` lapha futhi sifunde kuzo.
                // Asibhaleli i-`self` noma siphinde sibuyisele emuva kusethenjwa esiguquguqukayo.
                // Ngakho-ke isikhombisi esiluhlaza esidale ngaphezulu, se `deque`, sihlala sisebenza.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Isula i `VecDeque`, isusa wonke amanani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Ibuyisa i-`true` uma i-`VecDeque` iqukethe into elingana nenani elinikeziwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Inikeza ireferensi kwinto yangaphambili, noma i-`None` uma i-`VecDeque` ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Inikezela ngesethenjwa esiguquguqukayo entweni yangaphambili, noma i-`None` uma i-`VecDeque` ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Inikeza ireferensi yento engemuva, noma i-`None` uma i-`VecDeque` ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Inikezela ngesethenjwa esiguquguqukayo entweni yangemuva, noma i-`None` uma i-`VecDeque` ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Isusa into yokuqala bese iyibuyisela, noma i-`None` uma i-`VecDeque` ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Isusa into yokugcina ku-`VecDeque` bese iyibuyisa, noma i-`None` uma ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Ilungiselela into eya ku-`VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Faka into ngemuva kwe `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Kufanele ngabe sibheke ukuthi i-`head == 0` isho
        // ukuthi i `self` iyahambisana?
        self.tail <= self.head
    }

    /// Isusa into kusuka noma ikuphi ku-`VecDeque` bese iyibuyisela, iyisuse ngento yokuqala.
    ///
    ///
    /// Lokhu akugcini uku-oda, kepha kungu *O*(1).
    ///
    /// Ibuyisa i-`None` uma i-`index` ingaphandle kwemingcele.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Isusa into kusuka noma ikuphi ku-`VecDeque` bese iyibuyisela, esikhundleni sayo kufakwe into yokugcina.
    ///
    ///
    /// Lokhu akugcini uku-oda, kepha kungu *O*(1).
    ///
    /// Ibuyisa i-`None` uma i-`index` ingaphandle kwemingcele.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Ifaka into ku-`index` ngaphakathi kwe-`VecDeque`, isusa zonke izinto ezinama-indices amakhulu noma alingana no-`index` emuva.
    ///
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`index` inkulu kunobude be-`VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Hambisa inani elincane lezinto kubha yeringini bese ufaka into enikeziwe
        //
        // Okungenani i-len/2, izinto ezi-1 zizohanjiswa. O(min(n, n-i))
        //
        // Kunamacala amathathu ayinhloko:
        //  Izinto ziyasebenza
        //      - ikesi elikhethekile lapho umsila u-0 Izinto azicaci kahle futhi okufakiwe kusengxenyeni yomsila Izinto azicaci kahle futhi okufakiwe kusigaba senhloko
        //
        //
        // Ngokukodwa kwalokhu kunamacala amabili ngaphezulu:
        //  I-Insert iseduze nomsila Faka eduze kwekhanda
        //
        // Ukhiye: H, self.head
        //      T, self.tail o, Into evumelekile I, Into yokufaka A, Into okufanele ibe ngemuva kwephoyinti lokufaka M, Ikhombisa into ehanjisiwe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Awuoooo.......
                //      .
                //      .]
                //
                //                       I-HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // contigigu, faka eduze komsila:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // iyathinteka, faka eduze komsila nomsila ngu-0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       I-HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Sivele sihambise umsila, ngakho-ke sikopisha kuphela izinto ze-`index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ethintekayo, faka eduze kwekhanda:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // okungaqondakali, faka eduze komsila, isigaba somsila:
                    //
                    //                   I-HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   I-HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, faka eduze kwekhanda, isigaba somsila:
                    //
                    //           I-HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             I-HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopisha izinto kuze kufike ekhanda elisha
                    self.copy(1, 0, self.head);

                    // kopisha into yokugcina endaweni engenalutho ngaphansi kwesikhala
                    self.copy(0, self.cap() - 1, 1);

                    // hambisa izinto kusuka ku-idx ziye ekugcineni zingafaki i-^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert iseduze nomsila, isigaba sekhanda, futhi isendaweni yenkomba ku-buffer yangaphakathi:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           I-HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopisha izinto kuze kube semsileni omusha
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopisha into yokugcina endaweni engenalutho ngaphansi kwesikhala
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // okungaqondakali, faka eduze komsila, isigaba sekhanda:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           I-HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopisha izinto kuze kube semsileni omusha
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopisha into yokugcina endaweni engenalutho ngaphansi kwesikhala
                    self.copy(self.cap() - 1, 0, 1);

                    // susa izinto kusuka ku-idx-1 uye phambili ziye phambili zingafaki ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, faka eduze kwekhanda, isigaba sekhanda:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     I-HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // umsila kungenzeka ukuthi ushintshiwe ngakho-ke sidinga ukubala kabusha
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Isusa futhi ibuyise into ku-`index` kusuka ku-`VecDeque`.
    /// Noma ikuphi ukuphela okusondele kwephoyinti lokususa kuzodluliswa ukuze kuvuleke indawo, futhi zonke izinto ezithintekile zizoyiswa ezikhundleni ezintsha.
    ///
    /// Ibuyisa i-`None` uma i-`index` ingaphandle kwemingcele.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Kunamacala amathathu ayinhloko:
        //  Ama-elementi athintekile Ama-elementi awacaci futhi okususiwe kusengxenyeni yomsila Ama-elementi awakhulumi futhi ukukhishwa kusesigabeni sekhanda
        //
        //      - icala elikhethekile lapho izinto zihlanganiswa ngobuchwepheshe, kepha i-self.head =0
        //
        // Ngokukodwa kwalokhu kunamacala amabili ngaphezulu:
        //  I-Insert iseduze nomsila Faka eduze kwekhanda
        //
        // Ukhiye: H, self.head
        //      T, self.tail o, Into evumelekile x, Into emakwe ukususwa R, Ikhombisa into esuswayo M, Ibonisa into ehanjisiwe
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // okuthintekayo, susa eduze komsila:
                    //
                    //             I-TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ethintekayo, susa eduze kwekhanda:
                    //
                    //             I-TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // okungaqondakali, susa eduze komsila, isigaba somsila:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   I-HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, susa eduze kwekhanda, isigaba sekhanda:
                    //
                    //               I-RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   I-HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, susa eduze kwekhanda, isigaba somsila:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           I-HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // noma okungaqondakali, susa eceleni kwekhanda, isigaba somsila:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // dweba izakhi esigabeni somsila
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Ivimbela ukugeleza.
                    if self.head != 0 {
                        // kopisha into yokuqala endaweni engenalutho
                        self.copy(self.cap() - 1, 0, 1);

                        // hambisa izinto kusigaba sekhanda emuva
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // okungaqondakali, susa eduze komsila, isigaba sekhanda:
                    //
                    //           I-RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           I-HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // dweba izakhi kuze kufike ku-idx
                    self.copy(1, 0, idx);

                    // kopisha into yokugcina endaweni engenalutho
                    self.copy(0, self.cap() - 1, 1);

                    // hambisa izinto ukusuka emsileni ziye ekugcineni, ngaphandle kokugcina
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Ihlukanisa i-`VecDeque` kabili enkombeni enikeziwe.
    ///
    /// Ibuyisa i-`VecDeque` esanda kwabiwa.
    /// `self` iqukethe izinto `[0, at)`, kanti i-`VecDeque` ebuyisiwe iqukethe izinto `[at, len)`.
    ///
    /// Qaphela ukuthi umthamo we `self` awuguquki.
    ///
    /// I-element ku-index 0 ingaphambili kolayini.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ilele esiwombeni sokuqala.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // vele uthathe sonke isigamu sesibili.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` lilele engxenyeni yesibili, sidinga ukubhekisisa izakhi eseseqe ngazo engxenyeni yokuqala.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Hlanza lapho kukhona khona ukuphela kwama-buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Ihambisa zonke izinto ze-`other` ziye ku-`self`, ishiya i-`other` ingenalutho.
    ///
    /// # Panics
    ///
    /// I-Panics uma inombolo entsha yezinto eku-self ichichima i-`usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // implive engenamqondo
        self.extend(other.drain(..));
    }

    /// Igcina kuphela izinto ezichazwe yisilandiso.
    ///
    /// Ngamanye amagama, susa zonke izinto ze-`e` ngendlela yokuthi i-`f(&e)` ibuya ingamanga.
    /// Le ndlela isebenza endaweni, ivakashela into ngayinye ngqo kanye ngohlelo lwangempela, futhi igcina ukuhleleka kwezinto ezigciniwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// I-oda eliqondile lingaba wusizo ekulandeleni isimo sangaphandle, njengenkomba.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Lokhu kungahle kube panic noma kukhishwe isisu
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Phinda kabili usayizi we-buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Iguqula i-`VecDeque` isendaweni ukuze i-`len()` ilingane ne-`new_len`, kungaba ngokususa izinto ezeqile ngemuva noma ngokufaka izinto ezakhiwe ngokubiza i-`generator` emuva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Ihlela kabusha ukugcinwa kwangaphakathi kwale deque ngakho-ke kuyisigaxa esisodwa esihlanganayo, esibuyiswayo.
    ///
    /// Le ndlela ayabi futhi ayishintshi ukuhleleka kwezinto ezifakiwe.Njengoba ibuyisa isilayidi esiguquguqukayo, lokhu kungasetshenziswa ukuhlunga ideski.
    ///
    /// Lapho isitoreji sangaphakathi sesixhumene, izindlela ze-[`as_slices`] ne-[`as_mut_slices`] zizobuyisa konke okuqukethwe kwe-`VecDeque` ngocezu olulodwa.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Ukuhlunga okuqukethwe kwedeski.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ukuhlunga ideski
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ukuyihlela ngokulandelana okuphindayo
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ukuthola ukufinyelela okungaguquki kocezu oluhlanganayo.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // manje singaqiniseka ukuthi i-`slice` iqukethe zonke izinto zedeski, ngenkathi inokufinyelela okungaphenduki kwe `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // kunesikhala esikhululekile esanele sokukopisha umsila ngasikhathi sinye, lokhu kusho ukuthi siqale sigudlise ikhanda emuva, bese sikopisha umsila endaweni efanele.
            //
            //
            // kusuka: DEFGH .... ABC
            // Ku: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Njengamanje asicabangi .... ABCDEFGH
            // ukuhlangana ngoba i `head` kuzoba yi `0` kuleli cala.
            // Ngenkathi sifuna ukuguqula lokhu akuyona into encane njengoba izindawo ezimbalwa zilindele ukuthi i-`is_contiguous` isho ukuthi singavele sisebenzise u-`buf[tail..head]`.
            //
            //

            // kunesikhala esanele samahhala sokukopisha ikhanda ngasikhathi sinye, lokhu kusho ukuthi siqale ngokushintshela phambili umsila, bese sikopisha ikhanda endaweni efanele.
            //
            //
            // kusuka: FGH .... ABCDE
            // ku: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // imahhala incane kunakho kokubili ikhanda nomsila, lokhu kusho ukuthi kufanele kancane "swap" umsila nekhanda.
            //
            //
            // kusuka ku: EFGHI ... ABCD noma i HIJK.ABCDEFG
            // ukuze: ABCDEFGHI ... noma ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Inkinga ejwayelekile ibukeka kanjena i-GHIJKLM ... ABCDEF, ngaphambi kwanoma yikuphi ukushintshaniswa kwe-ABCDEFM ... GHIJKL, ngemuva kokudlula okungu-1 kokushintshana kwe-ABCDEFGHIJM ... KL, shintsha kuze kube yilapho i-edge engakwesokunxele ifinyelela esitolo sesikhashana
                //                  - bese uqala kabusha i-algorithm ngesitolo esisha se-(smaller) Kwesinye isikhathi isitolo sesikhashana sifinyelelwa lapho i-edge yangakwesokudla isekugcineni kwe-buffer, lokhu kusho ukuthi sishaye i-oda elifanele ngama-swaps ambalwa!
                //
                // E.g
                // EF..ABCD ABCDEF .., ngemuva kokushintshana okune kuphela sesiqedile
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Izungezisa ulayini ophela kabili izindawo ze-`mid` ngakwesokunxele.
    ///
    /// Equivalently,
    /// - Izungezisa into engu-`mid` iye endaweni yokuqala.
    /// - Kuphakama izinto zokuqala ze-`mid` bese kuziphusha kuze kube sekugcineni.
    /// - Izungezisa izindawo ze-`len() - mid` ngakwesokudla.
    ///
    /// # Panics
    ///
    /// Uma i-`mid` inkulu kune-`len()`.
    /// Qaphela ukuthi i-`mid == len()` yenza i-_not_ panic futhi ingukujikeleza okungavumelani.
    ///
    /// # Complexity
    ///
    /// Kuthatha isikhathi se-`*O*(min(mid, len() - mid))` futhi asikho isikhala esingeziwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Izungezisa ulayini ophela kabili izindawo ze-`k` ngakwesokudla.
    ///
    /// Equivalently,
    /// - Izungezisa into yokuqala ibe sesikhundleni `k`.
    /// - Pops izinto zokugcina ze-`k` bese uziphusha ziye phambili.
    /// - Izungezisa izindawo ze-`len() - k` ngakwesokunxele.
    ///
    /// # Panics
    ///
    /// Uma i-`k` inkulu kune-`len()`.
    /// Qaphela ukuthi i-`k == len()` yenza i-_not_ panic futhi ingukujikeleza okungavumelani.
    ///
    /// # Complexity
    ///
    /// Kuthatha isikhathi se-`*O*(min(k, len() - k))` futhi asikho isikhala esingeziwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // UKUPHEPHA: izindlela ezimbili ezilandelayo zidinga ukuthi inani lokujikeleza
    // ube ngaphansi kwengxenye yobude bedeski.
    //
    // `wrap_copy` kudinga ukuthi i-`min(x, cap() - x) + copy_len <= cap()`, kepha kune-`min` ayisoze yaba ngaphezu kwesigamu somthamo, kungakhathalekile ukuthi yi-x, ngakho-ke kuzwakala ukubiza lapha ngoba sishaya nento engaphansi kwengxenye yobude, engakaze ibe ngaphezu kwesigamu somthamo.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Ukucinga kanambambili lokhu kuhlungwe i `VecDeque` ukuthola into ethile.
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.
    /// Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine.
    /// Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Uma ufuna ukufaka into ku-`VecDeque` ehleliwe, ngenkathi ugcina i-oda lokuhlunga:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Ukusesha kanambambili lokhu kuhlungwe i `VecDeque` ngomsebenzi wokuqhathanisa.
    ///
    /// Umsebenzi wokuqhathanisa kufanele usebenzise i-oda elihambisana nokuhleleka kohlobo lwe-`VecDeque` engaphansi, ibuyisa ikhodi ye-oda ekhombisa ukuthi impikiswano yayo iyi-`Less`, `Equal` noma i-`Greater` kunenhloso oyifunayo.
    ///
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine.Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Ukusesha kanambambili lokhu kuhlungwe i `VecDeque` ngomsebenzi wokhiye wokukhipha.
    ///
    /// Kuthathwa ukuthi i-`VecDeque` ihlelwa ngokhiye, ngokwesibonelo nge-[`make_contiguous().sort_by_key()`](#method.make_contiguous) isebenzisa umsebenzi ofanayo wokukhipha ukhiye.
    ///
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.
    /// Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine kocezwana lwamabhangqa ahlelwe ngezinto zawo zesibili.
    /// Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Iguqula i-`VecDeque` isendaweni ukuze i-`len()` ilingane ne-new_len, kungaba ngokususa izinto ezingeqile ngemuva noma ngokufaka ama-clones we-`value` emuva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Ibuyisa inkomba kubhafa engaphansi yenkomba yezinto ezinengqondo enikeziwe.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // usayizi uhlala ungamandla we-2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Bala inani lama-elementi asele ukuthi afundwe kubhafa
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // usayizi uhlala ungamandla we-2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Ihlukaniswa njalo ezigabeni ezintathu, isibonelo: self: [a b c|d e f] okunye: [0 1 2 3|4 5] front=3, mid=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Akunakwenzeka ukusebenzisa i-Hash::hash_slice kuzingcezu ezibuyiswe ngendlela ye-as_slices njengoba ubude bazo bungahluka emadekeni afanayo.
        //
        //
        // I-Hasher iqinisekisa kuphela ukulingana kwesethi efanayo yezingcingo ezindleleni zayo.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Isebenzisa i-`VecDeque` ibe iterator engaphambili nangemuva yokuveza izinto ngenani.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Lo msebenzi kufanele ulingane nokuziphatha okulandelayo:
        //
        //      wento eku-iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Guqula i-[`Vec<T>`] ibe yi-[`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Lokhu kugwema ukuhambisa kabusha kabusha lapho kungenzeka khona, kepha izimo zalokho ziqinile, futhi zingashintsha, ngakho-ke akufanele kuthenjelwe kuzo ngaphandle kokuthi i-`Vec<T>` ivela ku-`From<VecDeque<T>>` futhi ingakabelwa kabusha.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Akunasabelo sangempela sama-ZST sokukhathazeka ngomthamo, kepha i-`VecDeque` ayikwazi ukuphatha ubude obufana ne-`Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Sidinga ukukhulisa usayizi uma amandla engewona amandla wamabili, amancane kakhulu noma engenayo okungenani indawo eyodwa yamahhala.
            // Lokhu sikwenza ngenkathi ise-`Vec` ngakho izinto zizokwehla ku-panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Guqula i-[`VecDeque<T>`] ibe yi-[`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Lokhu akudingeki ukuthi kunikezwe kabusha, kepha kudinga ukwenza *O*(*n*) ukunyakaza kwedatha uma ibhafa eyindilinga ingenzeki ekuqaleni kwesabelo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Lona ngu *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Lokhu kudinga ukuhlela kabusha idatha.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}