use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Ukubhala isivivinyo sokuhlanganiswa phakathi kwababeli bezinkampani zangaphandle ne `RawVec` kuyinkohliso encane ngoba i-`RawVec` API ayivezi izindlela zokwabiwa okungenzeki, ngakho-ke asikwazi ukubheka ukuthi kwenzekani lapho umhlinzeki esekhathele (ngaphandle kokuthola i panic).
    //
    //
    // Esikhundleni salokho, lokhu kubheka nje ukuthi izindlela ze-`RawVec` okungenani zidlula kwi-Allocator API lapho igcina isitoreji.
    //
    //
    //
    //
    //

    // Isabelo esiyisimungulu esisebenzisa inani elinqunyelwe likaphethiloli ngaphambi kokuzama ukwabiwa siqala ukwehluleka.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (kubangela ukwabiwa kabusha, ngaleyo ndlela kusetshenziswe amayunithi kaphethiloli angama-50 + 150=200)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Okokuqala, i-`reserve` yabela njenge-`reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // I-97 ingaphezu kokuphindwe kabili kwe-7, ngakho-ke i-`reserve` kufanele isebenze njenge-`reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // I-3 ingaphansi kwesigamu se-12, ngakho-ke i-`reserve` kumele ikhule kakhulu.
        // Ngesikhathi sokubhala le factor test factor ingu-2, ngakho-ke amandla amasha angama-24, kepha, isici sokukhula se 1.5 silungile futhi.
        //
        // Ngakho-ke i-`>= 18` ku-assert.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}