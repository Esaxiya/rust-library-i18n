#![stable(feature = "rust1", since = "1.0.0")]

//! Izinkomba zokubala okuphephile kwe-Thread.
//!
//! Bona imibhalo ye [`Arc<T>`][Arc] ukuthola eminye imininingwane.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Umkhawulo othambile enanini lezinkomba ezingenziwa ku-`Arc`.
///
/// Ukudlula lo mkhawulo kuzokhipha uhlelo lwakho (yize kungenjalo ngempela) kuzinkomba ze-_exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// I-ThreadSanitizer ayizisekeli izicingo zememori.
// Ukugwema imibiko emihle emangeni ekusetshenzisweni kwe-Arc/Weak sebenzisa imithwalo ye-athomu ukuvumelanisa esikhundleni salokho.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Isikhombi sokubala isithenjwa esiphephile.I-'Arc' imele 'Ukubalwa Kwezikhombo ze-Atomically'.
///
/// Uhlobo lwe-`Arc<T>` luhlinzeka ngobunikazi okwabiwe benani lohlobo `T`, olunikezwe inqwaba.Ukufaka i-[`clone`][clone] ku-`Arc` kukhiqiza isibonelo esisha se-`Arc`, esikhomba ekwabelweni okufanayo kunqwaba njengomthombo `Arc`, ngenkathi kukhuphuka isibalo sesethenjwa.
/// Lapho isikhombi se-`Arc` sokugcina esabelweni esinikeziwe sonakala, inani eligcinwe kuleso sabelo (esivame ukubizwa nge-"inner value") nalo liyehla.
///
/// Izinkomba ezabiwe ku-Rust azivumeli ukuguqulwa ngokuzenzakalela, futhi i-`Arc` ayinjalo: ngeke ukwazi ukuthola ireferensi engaguquleka kokuthile okuphakathi kwe `Arc`.Uma udinga ukuguqula nge `Arc`, sebenzisa i [`Mutex`][mutex], [`RwLock`][rwlock], noma olunye lwezinhlobo ze [`Atomic`][atomic].
///
/// ## Intambo Ukuphepha
///
/// Ngokungafani ne-[`Rc<T>`], i-`Arc<T>` isebenzisa ukusebenza kwe-athomu ekubaleni kwayo okuyinkomba.Lokhu kusho ukuthi iphephe ngentambo.Okubi ukuthi ukusebenza kwe-athomu kubiza kakhulu kunokufinyelela okujwayelekile kwememori.Uma ungabelani ngesabelo esibalwe njengesithenjwa phakathi kwemicu, cabanga ukusebenzisa i-[`Rc<T>`] ngaphezulu okuphansi.
/// [`Rc<T>`] okuzenzakalelayo okuphephile, ngoba umhlanganisi uzobamba noma yimuphi umzamo wokuthumela i-[`Rc<T>`] phakathi kwemicu.
/// Kodwa-ke, umtapo wezincwadi ungakhetha i-`Arc<T>` ukuze unikeze abathengi bomtapo wolwazi ukuguquguquka okuthe xaxa.
///
/// `Arc<T>` izosebenzisa i-[`Send`] ne-[`Sync`] inqobo nje uma i-`T` isebenzisa i-[`Send`] ne-[`Sync`].
/// Kungani ungeke ubeke uhlobo olungaphephile lwentambo `T` ku-`Arc<T>` ukuyenza iphephe ngentambo?Lokhu kungahle kube okuphikisanayo ekuqaleni: ngemuva kwakho konke, akulona yini iphuzu lokuphepha kwentambo ye-`Arc<T>`?Ukhiye yilokhu: I-`Arc<T>` iyenza iphephe ngentambo ukuba nobunikazi obuningi bedatha efanayo, kepha ayifaki ukuphepha kwentambo kudatha yayo.
///
/// Cabanga i-`Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] akuyona i [`Sync`], futhi uma i-`Arc<T>` ibihlala iyi-[`Send`], `Arc <` [`RefCell<T>`]`>`kuzobe kunjalo.
/// Kepha-ke sizoba nenkinga:
/// [`RefCell<T>`] akuphephile ngentambo;Igcina umkhondo wesibalo sokuboleka isebenzisa imisebenzi engeyona eye-athomu.
///
/// Ekugcineni, lokhu kusho ukuthi ungadinga ukubhangqa i-`Arc<T>` nohlobo oluthile lohlobo lwe-[`std::sync`], imvamisa i-[`Mutex<T>`][mutex].
///
/// ## Ukwephula imijikelezo nge-`Weak`
///
/// Indlela ye [`downgrade`][downgrade] ingasetshenziselwa ukudala isikhombisi se-[`Weak`] esingesona esakho.Isikhombi se-[`Weak`] singaba [`thuthukisa`][thuthukisa] d sibe yi-`Arc`, kepha lokhu kuzobuyisa i-[`None`] uma inani eligcinwe kusabelo selivele lehlisiwe.
/// Ngamanye amagama, izikhombisi ze-`Weak` azigcini inani ngaphakathi kwesabelo liphila;noma kunjalo, bona *bagcina* isabelo (isitolo esisekelayo senani) siphila.
///
/// Umjikelezo ophakathi kwezikhombi ze `Arc` awusoze wasuswa.
/// Ngalesi sizathu, i [`Weak`] isetshenziselwa ukwephula imijikelezo.Isibonelo, isihlahla singaba nezikhombisi eziqinile ze-`Arc` kusuka kuma-node wabazali kuye ezinganeni, nezikhombisi ze-[`Weak`] ezisuka ezinganeni ezibuyela kubazali bazo.
///
/// # Izinkomba zokuhlanganisa
///
/// Ukwakha ireferensi entsha kusuka kusikhombi esibaliwe esenziwe ngesithenjwa kwenziwa kusetshenziswa i `Clone` trait esetshenziselwe i [`Arc<T>`][Arc] ne [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ama-syntaxes amabili ngezansi ayalingana.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, no-foo wonke ama-Arcs akhomba endaweni efanayo yememori
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ukubhekelwa ngokuzenzakalela ku-`T` (nge-[`Deref`][deref] trait), ukuze ushayele izindlela zika-T`ngenani lohlobo `Arc<T>`.Ukugwema ukungqubuzana kwamagama nezindlela zika-T`, izindlela ze-`Arc<T>` uqobo ziyimisebenzi ehambisanayo, ebizwa ngokuthi kusetshenziswa i-[fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `I-Arc<T>Ukusetshenziswa kwe-traits njenge-`Clone` kungabizwa futhi kusetshenziswa i-syntax efaneleke ngokuphelele.
/// Abanye abantu bakhetha ukusebenzisa i-syntax efaneleke ngokuphelele, kuyilapho abanye bekhetha ukusebenzisa indlela-yokubiza syntax.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Indlela yokubiza i-syntax
/// let arc2 = arc.clone();
/// // I-syntax efaneleke ngokuphelele
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ayisiyisi ireferensi ezenzakalelayo ku-`T`, ngoba inani langaphakathi kungenzeka ukuthi selivele lehlisiwe.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ukwabelana ngemininingwane engaphenduki phakathi kwemicu:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Qaphela ukuthi **asizenzi** lezi zivivinyo lapha.
// Abakhi be windows abajabuli kakhulu uma intambo idlula intambo enkulu bese iphuma ngasikhathi sinye (okuthile okungavunyelwe) ngakho-ke simane sikugweme ngokuphelele lokhu ngokungazenzi lezi zivivinyo.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ukwabelana nge-[`AtomicUsize`] eguqukayo:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Bona i [`rc` documentation][rc_examples] ukuthola izibonelo eziningi zokubalwa kwezethenjwa ngokujwayelekile.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` inguqulo ye-[`Arc`] ephethe ireferensi okungeyona eyakho kusabelo esilawulwayo.
/// Isabelo sifinyelelwa ngokubiza i-[`upgrade`] kusikhombi se-`Weak`, esibuyisa [[Inketho`]`` <`[` Arc`]`<T>> `.
///
/// Njengoba ireferensi ye-`Weak` ingabheki kubunikazi, ngeke ivikele inani eligcinwe esabelweni ukuthi lehliswe, futhi i-`Weak` uqobo alwenzi ziqinisekiso mayelana nenani elisekhona.
///
/// Ngakho-ke ingabuyisa i [`None`] lapho [`thuthukisa`] d.
/// Qaphela kepha ukuthi isethenjwa se-`Weak` * sivimbela ukwabiwa uqobo (isitolo esisekelayo) ekuhanjisweni.
///
/// Isikhombi se `Weak` siwusizo ekugcineni ireferensi yesikhashana esabelweni esilawulwa yi-[`Arc`] ngaphandle kokuvimbela inani laso langaphakathi ekubeni lehliswe.
/// Ibuye isetshenziselwe ukuvikela izinkomba eziyindilinga phakathi kwezikhombisi ze-[`Arc`], ngoba ukuba nezinkomba ezifanayo kungaze kuvumele ukuthi i [`Arc`] yehliswe.
/// Isibonelo, isihlahla singaba nezikhombisi eziqinile ze-[`Arc`] kusuka kuma-node wabazali kuya ezinganeni, nezikhombisi ze-`Weak` ezisuka ezinganeni ezibuyela kubazali bazo.
///
/// Indlela ejwayelekile yokuthola isikhombisi se-`Weak` ukubiza i [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Le yi-`NonNull` yokuvumela ukwengeza usayizi walolu hlobo kuma-enums, kepha akusona isikhombisi esivumelekile.
    //
    // `Weak::new` ibeka lokhu ku-`usize::MAX` ukuze ingadingi ukwaba isikhala enqwabeni.
    // Lokho akulona inani i-pointer yangempela eyoke ibe nalo ngoba i-RcBox inokuqondanisa okungenani okungu-2.
    // Lokhu kungenzeka kuphela lapho i-`T: Sized`;i-`T` engafakwanga usayizi ayikaze iphazamise.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Lokhu yi-repr(C) kuya ku-future-proof ngokumelene nokuhleleka kabusha kwensimu, okungaphazamisa i-[into|from]_raw() ephephile yezinhlobo zangaphakathi ezingadluliselwa.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // inani le-usize::MAX lisebenza njengentelitha ye "locking" okwesikhashana ikhono lokuthuthukisa izikhombisi ezibuthakathaka noma ukwehlisa ezinamandla;lokhu kusetshenziselwa ukugwema izinhlanga ku-`make_mut` naku-`get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Yakha i `Arc<T>` entsha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Qala isibalo sesikhombi esibuthakathaka njengo-1 okuyisikhombi esibuthakathaka esiphethwe yizo zonke izikhombisi eziqinile (kinda), bona i-std/rc.rs ukuthola eminye imininingwane
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Yakha i `Arc<T>` entsha isebenzisa ireferensi ebuthakathaka kuyo uqobo.
    /// Ukuzama ukuthuthukisa ireferensi ebuthakathaka ngaphambi kokuthi lo msebenzi ubuye kuzoholela kunani le-`None`.
    /// Kodwa-ke, ireferensi ebuthakathaka ingahlanganiswa ngokukhululekile futhi igcinwe ukuze isetshenziswe kamuva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Yakha okungaphakathi kusimo se "uninitialized" ngesethenjwa esisodwa esibuthakathaka.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Kubalulekile ukuthi singabunikeli ubunikazi besikhombi esibuthakathaka, noma kungenjalo imemori ingadedelwa ngesikhathi kubuya i `data_fn`.
        // Uma ngabe besifuna ngempela ukudlula ubunikazi, singazenzela isibonisi esibuthakathaka esengeziwe, kepha lokhu kungaholela ekuvuseleleni okungeziwe kusibalo sesethenjwa esibuthakathaka okungenzeka kungadingeki ngenye indlela.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Manje sesingaliqalisa ngokufanele inani elingaphakathi futhi siguqule ireferensi yethu ebuthakathaka ibe ireferensi enamandla.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Lokhu okungenhla kubhalela inkambu yedatha kufanele kubonakale kunoma imiphi imicu ebheka ukubalwa okuqinile okungewona u-zero.
            // Ngakho-ke sidinga uku-oda okungenani kwe-"Release" ukuze sivumelanise ne `compare_exchange_weak` ku `Weak::upgrade`.
            //
            // "Acquire" uku-oda akudingeki.
            // Lapho sicabanga ngokuziphatha okungenzeka kwe-`data_fn` sidinga kuphela ukubheka ukuthi kungenzani ngokubhekisa ku-`Weak` engeke ithuthukiswe:
            //
            // - Ingakwazi * ukuhlanganisa i-`Weak`, ikhuphule isibalo sesethenjwa esibuthakathaka.
            // - Ingalahla lawo ma-clones, inciphise ukubalwa kwesethenjwa okubuthakathaka (kepha ungaze uye kuziro).
            //
            // Le miphumela emibi ayisithinti nganoma iyiphi indlela, futhi ayikho eminye imiphumela emibi engenzeka ngekhodi ephephile kuphela.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Izinkomba eziqinile kufanele zihlangane zibe nesithenjwa esabiwe esabiwe, ngakho-ke ungasebenzisi umchithi wesithenjwa sethu sakudala esibuthakathaka.
        //
        mem::forget(weak);
        strong
    }

    /// Kwakhiwa i-`Arc` entsha enokuqukethwe okungakaqalwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kwakhiwa i-`Arc` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Yakha i `Pin<Arc<T>>` entsha.
    /// Uma i-`T` ingasebenzisi i-`Unpin`, i-`data` izophinwa kwimemori futhi ingakwazi ukuhanjiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Kwakhiwa i `Arc<T>` entsha, kubuyisa iphutha uma ukwabiwa kwehluleka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Qala isibalo sesikhombi esibuthakathaka njengo-1 okuyisikhombi esibuthakathaka esiphethwe yizo zonke izikhombisi eziqinile (kinda), bona i-std/rc.rs ukuthola eminye imininingwane
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Kwakhiwa i-`Arc` entsha enokuqukethwe okungakaqalwa, kubuyisa iphutha uma ukwabiwa kwehluleka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Kwakhiwa i `Arc` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we `0`, ibuyisa iphutha uma ukwabiwa kwehluleka.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ibuyisa inani elingaphakathi, uma i-`Arc` inesethenjwa esisodwa esiqinile.
    ///
    /// Ngaphandle kwalokho, i [`Err`] ibuyiselwa ne `Arc` efanayo edluliselwe kuyo.
    ///
    ///
    /// Lokhu kuzophumelela noma ngabe kukhona izinkomba ezivelele ezibuthakathaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Yenza isikhombisi esibuthakathaka ukuze uhlanze ireferensi eqinile eqinile
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Kwakha ucezu olusha olubalwe ngereferensi olunokuqukethwe okungaqaliwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Kwakhiwa ucezu olusha olubalwe nge-atomic olunokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Iguqulela ku-`Arc<T>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukuso kofonayo ukuqinisekisa ukuthi inani langaphakathi lisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Iguqulela ku-`Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukuso kofonayo ukuqinisekisa ukuthi inani langaphakathi lisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Isebenzisa i-`Arc`, ibuyisa isikhombisi esigoqiwe.
    ///
    /// Ukugwema ukuvuza kwenkumbulo isikhombisi kufanele siguqulelwe ku-`Arc` kusetshenziswa i-[`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Inikezela ngesikhombi esiluhlaza kudatha.
    ///
    /// Izibalo azithinteki nganoma iyiphi indlela futhi i-`Arc` ayidliwe.
    /// Isikhombi sisebenza inqobo nje uma kunokubala okuqinile ku-`Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // UKUPHEPHA: Lokhu akukwazi ukudlula ku-Deref::deref noma ku-RcBoxPtr::inner ngoba
        // lokhu kuyadingeka ukugcina ukutholakala kwe-raw/mut njengokuthi isib
        // `get_mut` ingabhala ngesikhombi ngemuva kokuthi i-Rc itholakale nge `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Yakha i-`Arc<T>` kusuka kusikhombi esiluhlaza.
    ///
    /// Isikhombi esiluhlaza kufanele ngabe sasibuyiswe ngaphambilini ngocingo oluya ku-[`Arc<U>::into_raw`][into_raw] lapho i-`U` kumele ibe nosayizi nokuqondaniswa okufanayo ne-`T`.
    /// Lokhu kuyiqiniso elincane uma i-`U` iyi-`T`.
    /// Qaphela ukuthi uma i-`U` kungeyona i-`T` kepha inosayizi nokuqondaniswa okufanayo, lokhu ngokufana nokuhambisa izinkomba zezinhlobo ezahlukahlukene.
    /// Bona i [`mem::transmute`][transmute] ukuthola eminye imininingwane yokuthi imiphi imikhawulo esebenzayo kuleli cala.
    ///
    /// Umsebenzisi we `from_raw` kufanele aqiniseke ukuthi inani elithile le-`T` lehla kanye kuphela.
    ///
    /// Lo msebenzi awuphephile ngoba ukusetshenziswa okungafanele kungaholela ekuphepheni kwememori, noma ngabe i-`Arc<T>` ebuyisiwe ayitholakali.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Guqulela emuva ku-`Arc` ukuvimbela ukuvuza.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ezinye izingcingo eziya ku `Arc::from_raw(x_ptr)` zingahle zingaphephi kwimemori.
    /// }
    ///
    /// // Imemori yakhululwa lapho i `x` iphuma esikalini ngaphezulu, ngakho-ke i `x_ptr` manje ilenga!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Buyisela emuva i-offset ukuze uthole i-ArcInner yangempela.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Kwakha isikhombi esisha se [`Weak`] kulesi sabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Lokhu kukhululeka kulungile ngoba sibheka inani ku-CAS engezansi.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // hlola ukuthi ingabe ikhawunta ebuthakathaka njengamanje i-"locked";uma kunjalo, spin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: le khodi njengamanje ayinaki ukuthi kungenzeka kuchichime kangakanani
            // ungene ku usize::MAX;ngokujwayelekile i-Rc ne-Arc idinga ukulungiswa ukuze ibhekane nokuchichima.
            //

            // Ngokungafani ne-Clone(), sidinga ukuthi lokhu kube ukuThola ukufundwa ukuvumelanisa nokubhala okuvela ku-`is_unique`, ukuze izehlakalo ezandulela lokho kubhala zenzeke ngaphambi kwalokhu kufundwa.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Qiniseka ukuthi asidali Obuthakathaka obulenga
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ithola inani lezikhombisi ze-[`Weak`] kulesi sabelo.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokwayo iphephile, kepha ukuyisebenzisa ngendlela efanele kudinga ukunakekelwa okwengeziwe.
    /// Enye intambo ingashintsha ukubala okubuthakathaka nganoma yisiphi isikhathi, kufaka phakathi okungenzeka kube phakathi kokushayela le ndlela nokwenza umphumela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Lokhu kugomela kunqunyelwe ngoba asabelananga i-`Arc` noma i-`Weak` phakathi kwemicu.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Uma inani elibuthakathaka likhiyiwe njengamanje, inani lesibalo belingu-0 ngaphambi nje kokuthatha ukhiye.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ithola inani lezikhombisi eziqinile ze-(`Arc`) kulesi sabelo.
    ///
    /// # Safety
    ///
    /// Le ndlela ngokwayo iphephile, kepha ukuyisebenzisa ngendlela efanele kudinga ukunakekelwa okwengeziwe.
    /// Enye intambo ingashintsha ukubala okuqinile nganoma yisiphi isikhathi, kufaka phakathi okungenzeka kube phakathi kokushayela le ndlela nokwenza umphumela.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Lokhu kugomela kunqunyelwe ngoba asabelananga i `Arc` phakathi kwemicu.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Kukhulisa isibalo sesethenjwa esiqinile ku-`Arc<T>` esihlobene nesikhombi esinikeziwe ngakunye.
    ///
    /// # Safety
    ///
    /// Isikhombi kufanele sitholwe nge-`Arc::into_raw`, futhi isibonelo esihlobene ne-`Arc` kufanele sisebenze (isb
    /// isibalo esinamandla kufanele okungenani sibe ngu-1) kubude bale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Lokhu kugomela kunqunyelwe ngoba asabelananga i `Arc` phakathi kwemicu.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Gcina i-Arc, kepha ungathinti ukubalwa kabusha ngokusonga ku-ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Manje khulisa ukubala kabusha, kepha ungalahli ukubalwa kabusha okusha
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ukwehlisa inani lesethenjwa eliqinile ku-`Arc<T>` elihlotshaniswa nesikhombi esinikeziwe ngakunye.
    ///
    /// # Safety
    ///
    /// Isikhombi kufanele sitholwe nge-`Arc::into_raw`, futhi isibonelo esihlobene ne-`Arc` kufanele sisebenze (isb
    /// ukubalwa okuqinile kufanele okungenani kube ngu-1) lapho kucelwa le ndlela.
    /// Le ndlela ingasetshenziselwa ukukhipha isitoreji sokugcina se-`Arc`, kepha **akufanele** ibizwe ngemuva kokukhishwa kwe `Arc` yokugcina.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Lokho kugomela kunqunyelwe ngoba asabelananga i `Arc` phakathi kwemicu.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Lokhu kungavikeleki kulungile ngoba ngenkathi le arc isaphila siqinisekisiwe ukuthi isikhombisi sangaphakathi sisebenza.
        // Ngaphezu kwalokho, siyazi ukuthi isakhiwo se `ArcInner` uqobo siyi-`Sync` ngoba idatha yangaphakathi iyi-`Sync` futhi, ngakho-ke silungile siboleka isikhombisi esingaguquki kulokhu okuqukethwe.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ingxenye engeyona ngaphakathi ye `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Chitha imininingwane ngalesi sikhathi, noma singeke sikhulule ukwabiwa kwebhokisi uqobo (kungahle kube nezikhombisi ezibuthakathaka ezilele nxazonke).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Beka i-Ref ebuthaka ngokuhlanganyela ebanjwe yizo zonke izinkomba eziqinile
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibuyisa i-`true` uma ama-`Arc` amabili ekhomba kusabelo esifanayo (emthanjeni ofana no-[`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Kwabela i `ArcInner<T>` enesikhala esanele senani langaphakathi elingalinganiselwe lapho inani linokuhlelwa okunikeziwe.
    ///
    /// Umsebenzi `mem_to_arcinner` ubizwa ngesikhombi sedatha futhi kufanele abuyisele isikhombisi (esingahle sibe namandla) se-`ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Bala isakhiwo usebenzisa ukwakheka kwenani elinikeziwe.
        // Phambilini, ukwakheka bekubalwa kusisho `&*(ptr as* const ArcInner<T>)`, kepha lokhu kudale ireferensi engafanele (bona i #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Kwabela i `ArcInner<T>` enesikhala esanele senani langaphakathi elingalinganisiwe lapho inani linokuhlelwa okunikeziwe, kubuyisa iphutha uma ukwabiwa kwehluleka.
    ///
    ///
    /// Umsebenzi `mem_to_arcinner` ubizwa ngesikhombi sedatha futhi kufanele abuyisele isikhombisi (esingahle sibe namandla) se-`ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Bala isakhiwo usebenzisa ukwakheka kwenani elinikeziwe.
        // Phambilini, ukwakheka bekubalwa kusisho `&*(ptr as* const ArcInner<T>)`, kepha lokhu kudale ireferensi engafanele (bona i #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Qalisa i-ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Kwabela i `ArcInner<T>` enesikhala esanele senani langaphakathi elingalinganiselwe.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Nikezela i `ArcInner<T>` usebenzisa inani elinikeziwe.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopisha inani njengamabhayithi
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Khulula isabelo ngaphandle kokulahla okuqukethwe kukho
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Kwabela i `ArcInner<[T]>` ngobude obunikeziwe.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopisha izinto ezisuka kusilayidi ziye ku-Arc <\[T\]> esanda kwabiwa
    ///
    /// Akuphephile ngoba umuntu ofonayo kufanele athathe ubunikazi noma abophe i-`T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Yakha i-`Arc<[T]>` kusuka ku-iterator eyaziwa njengosayizi othile.
    ///
    /// Ukuziphatha akuchazeki uma usayizi ungalungile.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // I-Panic iyaqapha ngenkathi ihlanganisa izakhi ze-T.
        // Uma kwenzeka kuba ne-panic, izinto ezibhalwe ku-ArcInner entsha zizokwehliswa, bese imemori ikhululwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Isikhombi sento yokuqala
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Konke kucacile.Khohlwa unogada ukuze ingakhululi i-ArcInner entsha.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ubungcweti be-trait busetshenziselwa i-`From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Kwenza ukulingana kwesikhombi se `Arc`.
    ///
    /// Lokhu kudala esinye isikhombisi kusabelo esifanayo, kukhulisa ukubalwa kwesethenjwa okuqinile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Kusetshenziswa ukuhleleka okuhlelekile lapha, njengoba ulwazi lwesethenjwa sokuqala luvimbela eminye imicu ekususeni into ngephutha.
        //
        // Njengoba kuchaziwe ku-[Boost documentation][1], Ukwengeza isithenjwa esiphikisayo kungenziwa njalo nge-memory_order_relaxed: Izinkomba ezintsha entweni zingakhiwa kuphela kusethenjwa esivele sikhona, futhi ukudlulisa ireferensi ekhona kusuka kolunye uchungechunge kuya kolunye kufanele kuvele kunikeze noma ikuphi ukuvumelanisa okudingekayo.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Kodwa-ke sidinga ukuqaphela ukubalwa kabusha okukhulu uma kwenzeka umuntu ethi `mem: : akhohlwe yi-Arcs.
        // Uma singakwenzi lokhu ukubala kungachichima futhi abasebenzisi bazosebenzisa-ngemuva kwamahhala.
        // Sigcwalisana ngobuhlanga ku-`isize::MAX` ngokucabanga ukuthi azikho izintambo eziyizigidigidi ze-~2 ezikhulisa isibalo sesethenjwa ngasikhathi sinye.
        //
        // Le branch ayisoze yathathwa kunoma yiluphi uhlelo olungokoqobo.
        //
        // Sikhipha isisu ngoba uhlelo olunjalo lonakele ngendlela emangalisayo, futhi asinandaba nokuluxhasa.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Yenza ireferensi engaguquleka ku-`Arc` enikeziwe.
    ///
    /// Uma kukhona ezinye izikhombisi ze-`Arc` noma ze-[`Weak`] esabelweni esifanayo, i-`make_mut` izokwakha isabelo esisha futhi ibize i-[`clone`][clone] kunani langaphakathi ukuqinisekisa ubunikazi obuhlukile.
    /// Lokhu kubizwa nangokuthi i-clone-on-write.
    ///
    /// Qaphela ukuthi lokhu kwehlukile ekuziphatheni kwe [`Rc::make_mut`] okuhlukanisa noma iziphi izikhombisi ze-`Weak` ezisele.
    ///
    /// Bona futhi i [`get_mut`][get_mut], ezokwehluleka kunokuhlangana.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ngeke uhlanganise lutho
    /// let mut other_data = Arc::clone(&data); // Ngeke ihlanganise idatha yangaphakathi
    /// *Arc::make_mut(&mut data) += 1;         // Idatha yangaphakathi yama-Clones
    /// *Arc::make_mut(&mut data) += 1;         // Ngeke uhlanganise lutho
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ngeke uhlanganise lutho
    ///
    /// // Manje i-`data` ne-`other_data` zikhomba ezabelweni ezahlukahlukene.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Qaphela ukuthi siphethe isethenjwa esiqinile nesethenjwa esibuthakathaka.
        // Ngakho-ke, ukukhipha ireferensi yethu eqinile ngeke, kukodwa, kubangele ukuthi imemori ihanjiswe.
        //
        // Sebenzisa i-Zuza ukuqinisekisa ukuthi sibona noma yikuphi okubhalwa ku-`weak` okwenzeka ngaphambi kokukhishwa kubhala (okungukuthi, ukwehla) kuya ku-`strong`.
        // Njengoba sinesibalo esibuthakathaka, alikho ithuba lokuthi i-ArcInner uqobo isuswe.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Esinye isikhombisi esinamandla sikhona, ngakho-ke kufanele sisebenzisane.
            // Nikeza inkumbulo kusengaphambili ukuvumela ukubhala inani elihlanganisiwe ngqo.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Ukukhululeka kwanele kulokhu okungenhla ngoba lokhu kungukusebenzisa ngokuphelele: sihlala sigijima ngezikhombisi ezibuthakathaka zishiywa.
            // Okubi kakhulu, sigcina sabelwe i-Arc entsha ngokungadingekile.
            //

            // Sisuse i-ref yokugcina eqinile, kepha kukhona amanye ama-refs abuthakathaka asele.
            // Sizokuhambisa okuqukethwe siye ku-Arc entsha, bese senza amanye ama-refs abuthakathaka asebenze.
            //

            // Qaphela ukuthi akunakwenzeka ukuthi ukufundwa kwe `weak` kuveze i-usize::MAX (isb, kukhiyiwe), ngoba isibalo esibuthakathaka singavalwa ngentambo kuphela ngesethenjwa esiqinile.
            //
            //

            // Faka into yethu isikhombisi esibuthakathaka ngokuphelele, ukuze ihlanze i-ArcInner njengoba kudingeka.
            //
            let _weak = Weak { ptr: this.ptr };

            // Ungavele untshontshe idatha, okusele ngu-Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Sasiyisikhombo sodwa salolo hlobo;bump back up the strong count count.
            //
            this.inner().strong.store(1, Release);
        }

        // Njengaku-`get_mut()`, ukungavikeleki kulungile ngoba ireferensi yethu yayihlukile ekuqaleni, noma yaba eyodwa lapho kuhlanganiswa okuqukethwe.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Ibuyisa ireferensi engaguquleka ku-`Arc` enikeziwe, uma zingekho ezinye izikhombisi ze-`Arc` noma ze-[`Weak`] kusabelo esifanayo.
    ///
    ///
    /// Ibuyisa i-[`None`] ngenye indlela, ngoba akuphephile ukuguqula inani elabiwe.
    ///
    /// Bona futhi i-[`make_mut`][make_mut], ezokwenza i-[`clone`][clone] inani elingaphakathi lapho kunezinye izikhombisi.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Lokhu kungavikeleki kulungile ngoba siqinisekisiwe ukuthi isikhombisi sibuyisiwe yisikhombisi *kuphela* esizobuyiselwa ku-T.
            // Ukubalwa kwethu kwezethenjwa kuqinisekiswe ukuthi kube ngu-1 kuleli qophelo, futhi besidinga i-Arc uqobo ukuthi ibe yi-`mut`, ngakho-ke sibuyisa okuwukuphela kwereferensi yedatha yangaphakathi.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Ibuyisa ireferensi engaguquleka ku-`Arc` enikeziwe, ngaphandle kwesheke.
    ///
    /// Bona futhi i [`get_mut`], ephephile futhi eyenza amasheke afanele.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Noma iziphi ezinye izikhombisi ze-`Arc` noma ze-[`Weak`] ezabiwe ngokufanayo akumele zikhonjiswe esikhathini sokubolekwa okubuyisiwe.
    ///
    /// Lokhu kwenzeka kancane uma kungekho izikhombisi ezinjalo, ngokwesibonelo ngemuva nje kwe `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Siqaphele ukuthi *singenzi* ireferensi emboza izinkambu ze-"count", ngoba lokhu kuzoba nama-alias anokufinyelela okuhambisanayo kokubalwa kwezethenjwa (isib.
        // nge-`Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Nquma ukuthi ingabe lesi yisethenjwa esiyingqayizivele (kufaka phakathi ama-refs abuthakathaka) kudatha engaphansi.
    ///
    ///
    /// Qaphela ukuthi lokhu kudinga ukukhiya isibalo se-ref esibuthakathaka.
    fn is_unique(&mut self) -> bool {
        // khiya isibalo sesikhombi esibuthakathaka uma sibonakala kungukuphela kwesibambi sesikhombi esibuthakathaka.
        //
        // Ilebuli yokuthola lapha iqinisekisa ubudlelwano obenzeka ngaphambi kwanoma yikuphi ukubhala ku-`strong` (ikakhulukazi ku-`Weak::upgrade`) ngaphambi kokuncipha kwesibalo se-`weak` (nge-`Weak::drop`, esebenzisa ukukhishwa).
        // Uma i-Ref ebuthakathaka ebuyekeziwe ingazange yehliswe, i-CAS lapha izokwehluleka ngakho-ke asikhathali ukuvumelanisa.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Lokhu kudinga ukuba yi-`Acquire` ukuvumelanisa nokwehla kwekhawunta ye-`strong` ku-`drop`-okuwukuphela kokufinyelela okwenzekayo lapho kukhona noma yisiphi isethenjwa sokugcina esishiwoyo.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Ukukhishwa bhala lapha kuvumelanisa nokufundwa ku-`downgrade`, kuvimbela ngempumelelo ukufundwa okungenhla kwe-`strong` ukuthi kungenzeki ngemuva kokubhala.
            //
            //
            self.inner().weak.store(1, Release); // dedela ingidi
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Iconsa i `Arc`.
    ///
    /// Lokhu kuzokwehlisa ukubalwa kwesethenjwa okuqinile.
    /// Uma ukubalwa kwesethenjwa okuqinile kufinyelela kuziro kuzona-ke ezinye izinkomba (uma zikhona) ezingama-[`Weak`], ngakho-ke thina si-`drop` inani langaphakathi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Akuphrinti lutho
    /// drop(foo2);   // Iphrinta i-"dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ngoba i `fetch_sub` isivele i-athomu, asidingi ukuvumelanisa neminye imicu ngaphandle kokuthi sizosusa into.
        // Lo mqondo ofanayo usebenza ku-`fetch_sub` engezansi kusibalo se-`weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Lolu thango luyadingeka ukuvimbela ukuhlela kabusha ukusetshenziswa kwedatha nokususwa kwedatha.
        // Ngoba kumakwe i-`Release`, ukwehla kwesibalo sereferensi kuyavumelanisa nalolu cingo lwe `Acquire`.
        // Lokhu kusho ukuthi ukusetshenziswa kwedatha kwenzeka ngaphambi kokwehla kokubalwa kwesethenjwa, okwenzeka ngaphambi kwalolu cingo, okwenzeka ngaphambi kokususwa kwedatha.
        //
        // Njengoba kuchaziwe ku [Boost documentation][1],
        //
        // > Kubalulekile ukuphoqelela noma yikuphi ukufinyelela kwento entweni eyodwa
        // > intambo (ngesethenjwa esivele sikhona) ukuze kwenzeke ngaphambi kokususa
        // > into ngentambo ehlukile.Lokhu kutholakala nge-"release"
        // > ukusebenza ngemuva kokulahla ireferensi (noma yikuphi ukufinyelela kwento
        // > ngalesi sithenjwa kufanele ngokusobala kwenzeke ngaphambili), kanye ne
        // > "acquire" ukusebenza ngaphambi kokususa into.
        //
        // Ikakhulu, ngenkathi okuqukethwe kwe-Arc kuvame ukungaguquki, kungenzeka ukuthi okubhaliwe kwangaphakathi kubhalelwe okuthile okufana neMutex<T>.
        // Njengoba i-Mutex ingatholakali lapho isuswa, asikwazi ukuthembela kumqondo wayo wokuvumelanisa ukwenza ukubhala ngentambo A kubonakale kumchithi osebenza ngentambo B.
        //
        //
        // Futhi qaphela ukuthi ukutholwa kocingo lapha kungenzeka kuthathelwe indawo indawo yokuThola umthwalo, ongathuthukisa ukusebenza ezimeni eziphikiswa kakhulu.Bona i [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ukuzama ukwehlisa i-`Arc<dyn Any + Send + Sync>` ohlotsheni lukakhonkolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwaba noma iyiphi inkumbulo.
    /// Ukushayela i-[`upgrade`] kunani lokubuyisa kuhlala kunikeza i-[`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Uhlobo losizi ukuvumela ukufinyelela ekubalweni kwesethenjwa ngaphandle kokwenza noma ikuphi ukuqinisekiswa mayelana nenkambu yedatha.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Ibuyisa isikhombi esiluhlaza entweni engu-`T` ekhonjwe yile `Weak<T>`.
    ///
    /// Isikhombi sisebenza kuphela uma kunezinkomba ezithile eziqinile.
    /// I-pointer ingahle ilenge, ingalingani noma i-[`null`] ngenye indlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Zombili zikhomba entweni efanayo
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Okuqinile lapha kuyigcina iphila, ngakho-ke sisengakwazi ukufinyelela entweni.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Kepha hhayi okunye.
    /// // Singakwenza i-weak.as_ptr(), kepha ukufinyelela kusikhombi kungaholela ekuziphatheni okungachazwanga.
    /// // assert_eq! ("sawubona", akuphephile {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Uma isikhombi silenga, sibuyisela i-sentinel ngqo.
            // Leli akulona ikheli elilayishiwe elikhokhelwayo, ngoba ukulayishwa okungenani kuqondaniswe ne-ArcInner (usize).
            ptr as *const T
        } else {
            // UKUPHEPHA: uma ngabe_ukulengiswa kubuya kungamanga, khona-ke isikhombisi asinakuphikwa.
            // Umthwalo okhokhelwayo ungahle wehlelwe kuleli qophelo, futhi kufanele sigcine imvelaphi, ngakho-ke sebenzisa ukukhohlisa kwesikhombi esiluhlaza.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Isebenzisa i-`Weak<T>` bese iyiguqula ibe yisikhombi esiluhlaza.
    ///
    /// Lokhu kuguqula isikhombisi esibuthakathaka sibe yisikhombi esiluhlaza, ngenkathi kugcinwa ubunikazi besethenjwa esisodwa esibuthakathaka (isibalo esibuthakathaka asiguqulwa yilokhu kusebenza).
    /// Ingabuyiselwa emuva ku-`Weak<T>` nge-[`from_raw`].
    ///
    /// Imikhawulo efanayo yokuthola okubhekiswe kusikhombi njengaku-[`as_ptr`] iyasebenza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Iguqula isikhombisi esiluhlaza esidalwe ngaphambilini yi-[`into_raw`] sibuyele ku-`Weak<T>`.
    ///
    /// Lokhu kungasetshenziselwa ukuthola ireferensi eqinile (ngokushayela i-[`upgrade`] ngokuhamba kwesikhathi) noma ukusabalalisa isibalo esibuthakathaka ngokulahla i-`Weak<T>`.
    ///
    /// Kuthatha ubunikazi besethenjwa esisodwa esibuthakathaka (ngaphandle kwezikhombisi ezenziwe yi-[`new`], ngoba lezi azinazinto; indlela isasebenza kubo).
    ///
    /// # Safety
    ///
    /// Isikhombi kufanele ukuthi sivele ku-[`into_raw`] futhi kusamele sibe nesethenjwa saso esingaba namandla.
    ///
    /// Kuvunyelwe ukuthi ukubalwa okuqinile kube ngu-0 ngesikhathi sokubiza lokhu.
    /// Noma kunjalo, lokhu kuthatha ubunikazi besethenjwa esisodwa esibuthakathaka njengamanje esiboniswe njengesikhombi esiluhlaza (isibalo esibuthakathaka asiguqulwa yilokhu kusebenza) ngakho-ke kufanele sibhangqwe nekholi yangaphambilini eya ku-[`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Yehlisa isibalo sokugcina esibuthakathaka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Bona i-Weak::as_ptr ngomongo wokuthi isikhombisi sokufaka sisuselwa kanjani.

        let ptr = if is_dangling(ptr as *mut T) {
            // Lokhu kubuthakathaka Obuthakathaka.
            ptr as *mut ArcInner<T>
        } else {
            // Ngaphandle kwalokho, siqinisekisiwe ukuthi i-pointer ivela ku-Weond engabambeki.
            // UKUPHEPHA: i-data_offset iphephile ukuyishayela, njengoba i-ptr ikhomba i-T yangempela (engahle yehle) T.
            let offset = unsafe { data_offset(ptr) };
            // Ngakho-ke, sibuyisela emuva i-offset ukuthola i-RcBox yonke.
            // UKUPHEPHA: i-pointer isuselwe ku-Weak, ngakho-ke le offset iphephile.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // UKUPHEPHA: manje sesisitholile isikhombisi sokuqala esibuthakathaka, ngakho-ke singadala Ababuthakathaka.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Imizamo yokuthuthukisa i-`Weak` pointer iye ku-[`Arc`], ukubambezela ukwehla kwenani langaphakathi uma kuphumelele.
    ///
    ///
    /// Ibuyisa i-[`None`] uma inani langaphakathi selivele lehlisiwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Chitha zonke izikhombisi eziqinile.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Sisebenzisa i-CAS loop ukukhulisa isibalo esiqinile esikhundleni se-fetch_add njengoba lo msebenzi ungalokothi uthathe isibalo sesethenjwa sisuka ku-zero siye kwesinye.
        //
        //
        let inner = self.inner()?;

        // Umthwalo okhululiwe ngoba noma yikuphi ukubhala okungu-0 esingakubona kushiya inkambu isesimweni esingu-zero ngokuphelele (ngakho-ke ukufundwa kwe-"stale" ngo-0 kulungile), futhi elinye inani liqinisekiswa nge-CAS engezansi.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Bona ukuphawula ku-`Arc::clone` ngokuthi kungani senza lokhu (nge-`mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Ukukhululeka kuhle ngecala lokwehluleka ngoba asinakulindela ngesimo esisha.
            // Ukuthola kudingekile ecaleni lempumelelo ukuvumelanisa ne `Arc::new_cyclic`, lapho inani langaphakathi lingaqaliswa ngemuva kokuthi izinkomba ze-`Weak` sezivele zenziwe.
            // Kuleso simo, silindele ukubona inani eliqaliswe ngokuphelele.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null kuhlolwe ngenhla
                Err(old) => n = old,
            }
        }
    }

    /// Ithola inani lezikhombisi eziqinile ze-(`Arc`) ezikhomba kulesi sabelo.
    ///
    /// Uma i-`self` yadalwa kusetshenziswa i-[`Weak::new`], lokhu kuzobuyisa u-0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ithola ukulinganiselwa kwenombolo yezikhombi ze-`Weak` ezikhomba kulesi sabelo.
    ///
    /// Uma i-`self` yadalwa kusetshenziswa i-[`Weak::new`], noma uma kungekho izikhombisi eziqinile ezisele, lokhu kuzobuyisa u-0.
    ///
    /// # Accuracy
    ///
    /// Ngenxa yemininingwane yokuqalisa, inani elibuyisiwe lingacishwa ngo-1 kunoma iyiphi inkomba lapho eminye imicu ilawula noma iyiphi i-`Arc`s noma `Weak`s ekhomba kulwabiwo olufanayo.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Njengoba sabona ukuthi kwakukhona okungenani isikhombisi esisodwa esiqinile ngemuva kokufunda isibalo esibuthakathaka, siyazi ukuthi ireferensi ebuthakathaka ngokuphelele (ekhona noma yikuphi lapho izinkomba eziqinile zisaphila) yayisekhona lapho sibona ukubala okubuthakathaka, ngakho-ke singakususa ngokuphepha.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Ibuyisa i-`None` lapho i-pointer ilenga futhi ingekho i-`ArcInner`, (okusho ukuthi, lapho le `Weak` idalwa yi-`Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Siqaphele ukuthi *singenzi* ireferensi emboza inkambu ye-"data", njengoba inkambu ingashintshwa ngasikhathi sinye (ngokwesibonelo, uma i-`Arc` yokugcina yehlisiwe, inkambu yedatha izobekwa endaweni).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibuyisa i-`true` uma omabili `Obuthakathaka bekhomba kusabelo esifanayo (esifana ne-[`ptr::eq`]), noma uma bobabili bengakhombisi kunoma yisiphi isabelo (ngoba badalwe nge-`Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Njengoba lokhu kuqhathanisa izikhombisi kusho ukuthi i-`Weak::new()` izolingana, noma ingakhombisi kunoma yisiphi isabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ukuqhathanisa i `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Kwenza ukufana kwesikhombi se-`Weak` esikhomba kusabelo esifanayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Bona imibono ku Arc::clone() yokuthi kungani lokhu kukhululeke.
        // Lokhu kungasebenzisa i-fetch_add (indiva ilokhi) ngoba isibalo esibuthakathaka sikhiyiwe kuphela lapho kungekho * ezinye izikhombisi ezibuthakathaka ezikhona.
        //
        // (Ngakho-ke asikwazi ukusebenzisa le khodi kuleso simo).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Bona ukuphawula ku-Arc::clone() ngokuthi kungani senza lokhu (nge-mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwaba inkumbulo.
    /// Ukushayela i-[`upgrade`] kunani lokubuyisa kuhlala kunikeza i-[`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Iconsa isikhombi se `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Akuphrinti lutho
    /// drop(foo);        // Iphrinta i-"dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Uma sithola ukuthi besiyisikhombi sokugcina esibuthakathaka, yisikhathi sayo sokuhambisa imininingwane ngokuphelele.Bona ingxoxo ku Arc::drop() mayelana nokuhleleka kwememori
        //
        // Akudingekile ukubheka isimo esikhiyiwe lapha, ngoba isibalo esibuthakathaka singavalwa kuphela uma bekukhona i-Ref eyodwa ebuthakathaka, okusho ukuthi ukwehla kungagcina kuphela ku-Ref esele ebuthakathaka, engenzeka kuphela ngemuva kokukhishwa kwengidi.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Lokhu sikwenza ngobuchwepheshe lapha, hhayi njengokusebenzisa okujwayelekile ku-`&T`, ngoba kungenjalo kungeza izindleko kukho konke ukuhlolwa kokulingana kuma-Ref.
/// Sicabanga ukuthi i-`Arc`s isetshenziselwa ukugcina amanani amakhulu, aphuza ukuhlangana, kepha futhi anzima ukuhlola ukulingana, okwenza le ndleko ikhokhe kalula.
///
/// Kungenzeka futhi ukuthi ube nama-clone amabili we-`Arc`, akhomba kunani elifanayo, kunama-`&T`s amabili.
///
/// Lokhu singakwenza kuphela lapho i-`T: Eq` njenge-`PartialEq` ingahle ingafinyeleli ngamabomu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Ukulingana kwama-`Arc`s amabili.
    ///
    /// Ama-`Arc`s amabili ayalingana uma amanani awo angaphakathi elingana, noma ngabe agcinwe ngokwabiwa okuhlukile.
    ///
    /// Uma i-`T` futhi isebenzisa i-`Eq` (okusho ukuguquguquka kokulingana), ama-`Arc` amabili akhomba kusabelo esifanayo ahlala elingana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ukungalingani kwama-`Arc`s amabili.
    ///
    /// Ama-`Arc`s amabili awalingani uma amanani abo angaphakathi engalingani.
    ///
    /// Uma i-`T` futhi isebenzisa i-`Eq` (okusho ukuguquguquka kokulingana), ama-`Arc` amabili akhomba kunani elifanayo awalokothi angalingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Ukuqhathanisa okuncane kwama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`partial_cmp()` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ngaphansi kokuqhathaniswa kwama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`<` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Okungaphansi noma okulingana nokuqhathaniswa kwama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`<=` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Kukhulu kunokuqhathanisa kwama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`>` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Okukhulu kunalokho noma okulingana' nokuqhathaniswa kwama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`>=` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Ukuqhathanisa ama-`Arc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`cmp()` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Idala i-`Arc<T>` entsha, ngenani le-`Default` le-`T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Nika ucezu olubalwe kusethenjwa bese ulugcwalisa ngokuhlanganisa izinto zika-``v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Nikezela i-`str` ebalwe yireferensi bese ukopisha i-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Nikezela i-`str` ebalwe yireferensi bese ukopisha i-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Hambisa into ebhokisiwe kusabelo esisha, esibalwe njengesethenjwa.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Nikezela ucezu olubalwe kusethenjwa bese uhambisa izinto `z 'kulo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Vumela i-Vec ukuthi ikhulule inkumbulo yayo, kepha ingabhubhisi okuqukethwe kwayo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Kuthatha into ngayinye ku-`Iterator` bese kuyiqoqela ku-`Arc<[T]>`.
    ///
    /// # Izici zokusebenza
    ///
    /// ## Icala elijwayelekile
    ///
    /// Esimweni esejwayelekile, ukuqoqelwa ku-`Arc<[T]>` kwenziwa ngokuqoqa okokuqala ku-`Vec<T>`.Okusho ukuthi, lapho ubhala okulandelayo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// lokhu kuziphatha sengathi sibhale:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Isethi yokuqala yezabelo yenzeka lapha.
    ///     .into(); // Isabelo sesibili se `Arc<[T]>` senzeka lapha.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Lokhu kuzokwaba kaningi ngangokunokwenzeka ekwakheni i `Vec<T>` bese kuzokwabelwa kanye ukuguqula i `Vec<T>` ibe yi `Arc<[T]>`.
    ///
    ///
    /// ## Ama-Iterator wobude obaziwayo
    ///
    /// Lapho i-`Iterator` yakho isebenzisa i-`TrustedLen` futhi isayizi elifanele, kuzokwabiwa i-`Arc<[T]>` eyodwa.Ngokwesibonelo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Isabelo esisodwa nje senzeka lapha.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Ubungcweti be-trait busetshenziselwa ukuqoqelwa ku-`Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Lokhu kunjalo nge-`TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // UKUPHEPHA: Sidinga ukuqinisekisa ukuthi i-iterator inebude obuqondile futhi sinakho.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Buyela emuva ekusetshenzisweni okujwayelekile.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Thola isaphulelo ngaphakathi kwe `ArcInner` ngokulayishwa okukhokhelwa ngemuva kwesikhombi.
///
/// # Safety
///
/// Isikhombi kumele sikhombe (futhi sibe nemethadatha evumelekile) yesimo esivele sisebenza ngaphambilini se-T, kepha i-T ivunyelwe ukuthi yehliswe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Qondanisa inani elingasetshenzisiwe ekugcineni kwe-ArcInner.
    // Ngoba i-RcBox iyi-repr(C), izohlala iyinkambu yokugcina kwimemori.
    // UKUPHEPHA: ngoba yizinhlobo ezingasetshenziswanga kuphela ezingaba yizicucu, izinto ze-trait,
    // nezinhlobo zangaphandle, imfuneko yokuphepha yokufaka okwamanje yanele ukwanelisa izidingo ze-align_of_val_raw;lena imininingwane yokuqalisa yolimi okungenzeka kungathenjelwa kuyo ngaphandle kwe-std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}