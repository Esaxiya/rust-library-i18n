//! Izicucu zezintambo ze-Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Uhlobo lwe-`&str` lungenye yezinhlobo ezimbili eziyinhloko zezintambo, enye i-`String`.
//! Ngokungafani nozakwabo we `String`, okuqukethwe kwayo kubolekiwe.
//!
//! # Ukusetshenziswa Okuyisisekelo
//!
//! Isimemezelo sentambo esiyisisekelo sohlobo lwe-`&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Lapha simemezele intambo ngokoqobo, eyaziwa nangokuthi ucezu lwentambo.
//! Izincwadi zezintambo zinempilo engaguquki, okusho ukuthi intambo `hello_world` iqinisekisiwe ukuthi izosebenza isikhathi sohlelo lonke.
//!
//! Singacacisa ngokusobala nesikhathi sempilo `sawomhlaba 'futhi:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Ukusetshenziswa okuningi kule module kusetshenziswa kuphela ekucushweni kokuhlolwa.
// Kuhlanzekile ukucisha nje i-unused_imports isixwayiso kunokuzilungisa.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: I-`str` ku-`Concat<str>` ayisho lutho lapha.
/// Lolu hlobo lwepharamitha le-trait lukhona kuphela ukunika amandla okunye okufakiwe.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // izihibe ezinobukhulu obufakwe amakhodi zisebenza ngokushesha okukhulu ngokukhethekile kwamacala anobude besihlukanisi esincane
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // ukubuyela emuva ngosayizi okungekho zero
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Ukwenziwa kokujoyina okwenzelwe ukusebenzela i-Vec yomibili<T>(T: Copy) kanye ne-vest yangaphakathi ye-String Njengamanje i-(2018-05-13) kunesiphazamisi esinokuthambekela kohlobo kanye nokwenza okuthile (bona ukukhishwa i-#36262) Ngalesi sizathu iSliceConcat<T>ayenzelwe i-T: Copy ne-SliceConcat<str>ukuphela komsebenzisi walo msebenzi.
// Kushiyelwe endaweni yesikhathi lapho lokho kulungiswa.
//
// imingcele ye-String-join yi-S: Boleka<str>nangokujoyina i-Vec Borrow <[T]> [T] futhi str zombili zifake i-AsRef <[T]> kwezinye ze-T
// => s.borrow().as_ref() futhi sihlala sinezilayi
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // Isilayidi sokuqala ukuphela kwaso ngaphandle kwesihlukanisi esandulelayo
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // bala ubude obuqhelele be-Vec ejoyinisiwe uma ukubalwa kwe-`len` kuchichima, sizoba yi-panic ngabe siphelelwe yimemori noma kunjalo futhi wonke umsebenzi udinga i-Vec yonke eyabelwe ukuphepha
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // lungiselela ibhafa engaqaliwe
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // isihlukanisi sekhophi nezingcezu ngaphandle kokuhlolwa kwemingcele kukhiqiza amaluphu ngokukhishwa okunamakhodi okuhlukaniswa okuncane kokuthuthuka okukhulu okungenzeka (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Ukusetshenziswa okuxakile kokubolekwa kungabuyisa izingcezu ezahlukahlukene zokubalwa kobude nekhophi langempela.
        //
        // Qiniseka ukuthi asivezi amabhayithi angaqaliwe kofonayo.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Izindlela zezingcezu zezintambo.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Iguqula i-`Box<str>` ibe yi-`Box<[u8]>` ngaphandle kokukopisha noma ukwaba.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Ishintsha konke ukufana kwephethini ngenye intambo.
    ///
    /// `replace` kwakha i [`String`] entsha, bese ikopisha idatha kusuka kulolu cucu lwentambo kuyo.
    /// Ngenkathi yenza njalo, izama ukuthola ukufana kwephethini.
    /// Uma ithola noma yini, ithatha isikhundla sayo ngocezu lwentambo engena esikhundleni.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Lapho iphethini ingafani:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Faka esikhundleni sokuqala ukufana kwe-N kwephethini ngenye intambo.
    ///
    /// `replacen` kwakha i [`String`] entsha, bese ikopisha idatha kusuka kulolu cucu lwentambo kuyo.
    /// Ngenkathi yenza njalo, izama ukuthola ukufana kwephethini.
    /// Uma ithola noma yini, ithatha isikhundla sayo ngocezu lwentambo engena esikhundleni kaningi kuma-`count`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Lapho iphethini ingafani:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Ngiyethemba ukunciphisa izikhathi zokwabiwa kabusha
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Ibuyisa okulingana nezinhlamvu ezincane zalesi siqeshana sentambo, njenge-[`String`] entsha.
    ///
    /// 'Lowercase' ichazwa ngokuya ngemigomo ye-Unicode Derives Core Property `Lowercase`.
    ///
    /// Njengoba ezinye izinhlamvu zingakhula zibe izinhlamvu eziningi lapho kushintshwa icala, lo msebenzi ubuyisa i-[`String`] esikhundleni sokushintsha ipharamitha endaweni.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Isibonelo esikhohlisayo, nesigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // kepha ekugcineni kwegama, ngu-ς, hhayi σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Izilimi ezingenacala azishintshiwe:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ amamephu kuya ku-σ, ngaphandle kokuthi kuphele igama lapho libeka khona amabalazwe ku-ς.
                // Le ukuphela kwe-(contextual) enemibandela kepha imephu ezimele olimini ku-`SpecialCasing.txt`, ngakho-ke yenza ikhodi enzima kunokuba nomshini ojwayelekile we-"condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // encazelweni ye `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Ibuyisa osonhlamvukazi abalingana nalesi siqeshana sentambo, njenge-[`String`] entsha.
    ///
    /// 'Uppercase' ichazwa ngokuya ngemigomo ye-Unicode Derives Core Property `Uppercase`.
    ///
    /// Njengoba ezinye izinhlamvu zingakhula zibe izinhlamvu eziningi lapho kushintshwa icala, lo msebenzi ubuyisa i-[`String`] esikhundleni sokushintsha ipharamitha endaweni.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Izikripthi ezingenacala azishintshiwe:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Uhlamvu olulodwa lungaba luningi:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Iguqula i-[`Box<str>`] ibe yi-[`String`] ngaphandle kokukopisha noma ukwaba.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Idala i-[`String`] entsha ngokuphinda intambo izikhathi ezingu-`n`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma umthamo ungachichima.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// I-panic lapho ichichima:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Ibuyisa ikhophi yaleyunithi yezinhlamvu lapho uhlamvu ngalunye lubekwe kumephu yokulingana kwalo kwe-ASCII ephezulu.
    ///
    ///
    /// Izinhlamvu ze-ASCII 'a' kuya ku-'z' zimakwe ku-'A' kuye ku-'Z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukuze usebenzise inani elikhulu endaweni, sebenzisa i-[`make_ascii_uppercase`].
    ///
    /// Ukuze usebenzise izinhlamvu ezinkulu ze-ASCII ngokungeziwe kuzinhlamvu ezingezona eze-ASCII, sebenzisa i-[`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() igcina okungajwayelekile kwe UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Ibuyisa ikhophi yale ntambo lapho uhlamvu ngalunye lubekwe kumephu yayo elinganayo ye-ASCII.
    ///
    ///
    /// Izinhlamvu ze-ASCII 'A' kuya ku-'Z' zimakwe ku-'a' kuye ku-'z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukwehlisa inani endaweni, sebenzisa i-[`make_ascii_lowercase`].
    ///
    /// Ukwehlisa izinhlamvu ze-ASCII ngaphezu kwezinhlamvu ezingezona eze-ASCII, sebenzisa i [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() igcina okungajwayelekile kwe UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Iguqula ucezu lwamabhayithi olufakwe ebhokisini lube lucezu lwentambo ebhokisini ngaphandle kokubheka ukuthi intambo iqukethe i-UTF-8 evumelekile.
///
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}