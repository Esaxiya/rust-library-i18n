//! Iyunithi yezinhlamvu efakwe ku-UTF-8, ekhulekayo.
//!
//! Le mojula iqukethe uhlobo lwe-[`String`], i-[`ToString`] trait yokuguqulela ezintanjeni, nezinhlobo eziningi zamaphutha ezingavela ekusebenzeni ne-[`String`] s.
//!
//!
//! # Examples
//!
//! Kunezindlela eziningi zokwenza i-[`String`] entsha ngentambo yangempela:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Ungadala i-[`String`] entsha kusuka kwesivele ikhona ngokuhlangana nayo
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Uma une-vector yama-UTF-8 byte avumelekile, ungenza i-[`String`] ngayo.Ungenza okuphambene nalokho.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Siyazi ukuthi la mabhayithi avumelekile, ngakho-ke sizosebenzisa i-`unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Iyunithi yezinhlamvu efakwe ku-UTF-8, ekhulekayo.
///
/// Uhlobo lwe `String` luhlobo lwentambo oluvame kakhulu olunobunikazi ngaphezu kokuqukethwe yunithi yezinhlamvu.Inobudlelwano obuseduze nozakwabo obolekisiwe, i-[`str`] yakudala.
///
/// # Examples
///
/// Ungadala i-`String` kusuka ku-[a literal string][`str`] nge-[`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Ungafaka i-[`char`] ku-`String` ngendlela ye-[`push`], bese ufaka i-[`&str`] ngendlela ye-[`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Uma une-vector yama-UTF-8 byte, ungakha i-`String` kuyo ngenqubo ye-[`from_utf8`]:
///
/// ```
/// // amanye ama-byte, ku-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Siyazi ukuthi la mabhayithi avumelekile, ngakho-ke sizosebenzisa i-`unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// Izintambo zihlala zivumelekile i-UTF-8.Lokhu kunemithelela embalwa, eyokuqala ukuthi uma udinga intambo engeyona eye-UTF-8, cabanga nge [`OsString`].Kuyafana, kepha ngaphandle kwesithiyo se UTF-8.Incazelo yesibili ukuthi awukwazi ukukhomba ku-`String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Ukwenza i-indexing kuhloswe ukuthi kube ukusebenza njalo, kepha ukufaka ikhodi kwe-UTF-8 akusivumeli ukuthi sikwenze lokhu.Ngaphezu kwalokho, akucaci ukuthi iyiphi inkomba okufanele iyibuyise: i-byte, i-codepoint, noma iqoqo le-grapheme.
/// Izindlela ze-[`bytes`] ne-[`chars`] zibuyisela ama-iterator ngaphezulu kwezimbili zokuqala, ngokulandelana.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Izintambo zisebenzisa [` Deref`]`<Target=str>`, ngakho-ke uzuze zonke izindlela ze-[` str`].Ngaphezu kwalokho, lokhu kusho ukuthi ungadlulisa i-`String` emsebenzini othatha i-[`&str`] ngokusebenzisa i-ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Lokhu kuzokwakha i-[`&str`] kusuka ku-`String` bese kuyidlulisa. Lokhu kuguqulwa akubizi kakhulu, ngakho-ke ngokuvamile, imisebenzi izokwamukela ama-[`&str`] njengezimpikiswano ngaphandle kokuthi badinga i-`String` ngesizathu esithile.
///
/// Ezimweni ezithile i Rust ayinalo ulwazi olwanele lokwenza lokhu kuguqulwa, okwaziwa ngokuthi ukuphoqelelwa kwe [`Deref`].Esibonelweni esilandelayo ucezu lwentambo [`&'a str`][`&str`] lusebenzisa i-trait `TraitExample`, futhi umsebenzi `example_func` uthatha noma yini esebenzisa i-trait.
/// Kulokhu i-Rust izodinga ukwenza ukuguqulwa okubili, i-Rust engenazo izindlela zokwenza.
/// Ngaleso sizathu, isibonelo esilandelayo ngeke sihlanganiswe.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Kunezinketho ezimbili ezingasebenza esikhundleni salokho.Okokuqala kuzoba ukuguqula umugqa u-`example_func(&example_string);` uye ku-`example_func(example_string.as_str());`, kusetshenziswa indlela engu-[`as_str()`] ukukhipha ngokusobala ucezu lwentambo oluqukethe intambo.
/// Indlela yesibili iguqula i-`example_func(&example_string);` ibe yi-`example_func(&*example_string);`.
/// Kulokhu sikhipha ireferencing i-`String` ibe yi-[`str`][`&str`], bese sikhomba i-[`str`][`&str`] emuva ku-[`&str`].
/// Indlela yesibili i-idiomatic, kepha bobabili basebenzela ukwenza ukuguqulwa ngokusobala kunokuba bancike ekuguqulweni okusobala.
///
/// # Representation
///
/// I-`String` yakhiwe ngezinto ezintathu: isikhombisi kwamanye ama-byte, ubude namandla.Isikhombi sikhomba kubhafa yangaphakathi i-`String` isebenzisa ukugcina idatha yayo.Ubude yinombolo yama-byte okwamanje agcinwe kubhafa, futhi umthamo ngusayizi we-buffer kuma-byte.
///
/// Kanjalo, ubude buzohlala buncane noma bulingana namandla.
///
/// Le bhafa igcinwa njalo enqwabeni.
///
/// Ungabheka lokhu ngezindlela ze-[`as_ptr`], [`len`], ne-[`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Vuselela lokhu lapho i-vec_into_raw_parts izinzile.
/// // Vimbela ukulahla ngokuzenzakalela idatha ye-String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // Indaba inama-byte ayishumi nesishiyagalolunye
/// assert_eq!(19, len);
///
/// // Singakha kabusha i-String out of ptr, len, and capacity.
/// // Konke lokhu akuphephile ngoba sinesibopho sokuqinisekisa ukuthi izingxenye ziyasebenza:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Uma i-`String` inamandla anele, ukungeza izinto kuyo ngeke kunikezwe kabusha.Isibonelo, cabanga ngalolu hlelo:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Lokhu kuzokhipha okulandelayo:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Ekuqaleni, asinayo inkumbulo eyabelwe nhlobo, kepha njengoba singena entanjeni, inyusa amandla ayo ngokufanele.Uma esikhundleni salokho sisebenzisa indlela ye [`with_capacity`] ukwaba amandla afanele ekuqaleni:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Sigcina ngokukhipha okwehlukile:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Lapha, asikho isidingo sokwaba inkumbulo eyengeziwe ngaphakathi kwe-loop.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Inani lephutha elingaba khona lapho uguqula i-`String` isuka ku-UTF-8 byte vector.
///
/// Lolu hlobo luhlobo lwephutha lwendlela ye-[`from_utf8`] ku-[`String`].
/// Idizayinelwe ngendlela yokugwema ngokucophelela ukwabiwa kabusha: indlela ye [`into_bytes`] izobuyisa i-Byte vector ebisetshenziswa emzameni wokuguqula.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Uhlobo lwe-[`Utf8Error`] olunikezwe i-[`std::str`] lumele iphutha elingavela lapho kuguqulwa ucezu luka-[`u8`] ku-[`&str`].
/// Ngalo mqondo, iyi-analogue eya ku-`FromUtf8Error`, futhi ungayithola ku-`FromUtf8Error` ngokusebenzisa indlela ye-[`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// // amanye amabhayithi angavumelekile, ku-vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Inani lephutha elingaba khona lapho uguqula i-`String` kusuka kusilayidi se-UTF-16 byte.
///
/// Lolu hlobo luhlobo lwephutha lwendlela ye-[`from_utf16`] ku-[`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Idala i-`String` entsha engenalutho.
    ///
    /// Njengoba kunikezwe ukuthi i `String` ayinalutho, lokhu ngeke kunikeze noma iyiphi i-buffer yokuqala.Ngenkathi lokho kusho ukuthi lo msebenzi wokuqala awubizi kakhulu, ungadala ukwabiwa ngokweqile kamuva lapho ufaka idatha.
    ///
    /// Uma unombono wokuthi i-`String` izobamba idatha engakanani, cabanga ngendlela ye-[`with_capacity`] yokuvimbela ukwabiwa ngokweqile.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Kwakha i-`String` engenalutho ngomthamo othile.
    ///
    /// I-String`s ine-buffer yangaphakathi yokubamba idatha yayo.
    /// Umthamo ubude baleyo buffer, futhi ungabuzwa ngendlela ye [`capacity`].
    /// Le ndlela idala i-`String` engenalutho, kodwa eyodwa ene-buffer yokuqala engabamba ama-`capacity` byte.
    /// Lokhu kuyasiza lapho kungenzeka ufaka inqwaba yedatha ku-`String`, wehlisa inani lokwabiwa kabusha okudingeka likwenze.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Uma umthamo onikeziwe kungu-`0`, akukho ukwabiwa okuzokwenzeka, futhi le ndlela iyefana nendlela ye-[`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // I-String ayiqukethe lutho, noma inamandla wokuningi
    /// assert_eq!(s.len(), 0);
    ///
    /// // Konke lokhu kwenziwa ngaphandle kokuphinda kubelwe indawo ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... kepha lokhu kungenza intambo ibambe kabusha
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): nge cfg(test) indlela yemvelo ye `[T]::to_vec`, edingekayo kule ncazelo yendlela, ayitholakali.
    // Njengoba asiyidingi le ndlela ngezinhloso zokuhlola, ngizovele ngiyikhumbuze NB bona imodyuli ye slice::hack ku slice.rs ukuthola eminye imininingwane
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Iguqula i-vector yamabhayithi ibe yi-`String`.
    ///
    /// Intambo ([`String`]) yenziwe ngama-byte ([`u8`]), kanti i-vector yamabhayithi ([`Vec<u8>`]) enziwe ngamabhayithi, ngakho-ke lo msebenzi uguquka phakathi kwalokhu okubili.
    /// Akuzona zonke izingcezu ze-byte ezisebenza `ngama-String`s, noma kunjalo: i-`String` idinga ukuthi ivumeleke i-UTF-8.
    /// `from_utf8()` amasheke ukuqinisekisa ukuthi ama-byte avumelekile i-UTF-8, bese kuguquka.
    ///
    /// Uma uqinisekile ukuthi ucezu lwe-byte luvumelekile i-UTF-8, futhi awufuni ukuzitholela isheke lokuqinisekisa, kunenguqulo engaphephile yalo msebenzi, i-[`from_utf8_unchecked`], enokuziphatha okufanayo kepha yeqa isheke.
    ///
    ///
    /// Le ndlela izonakekela ukungakopishi i vector, ngenxa yokusebenza kahle.
    ///
    /// Uma udinga i-[`&str`] esikhundleni se-`String`, cabanga nge-[`str::from_utf8`].
    ///
    /// Ukuphambana kwale ndlela ngu-[`into_bytes`].
    ///
    /// # Errors
    ///
    /// Ibuyisa i-[`Err`] uma isilayidi singesona i-UTF-8 nencazelo yokuthi kungani ama-byte ahlinzekiwe engeyona i-UTF-8.I-vector ongene kuyo nayo ifakiwe.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye ama-byte, ku-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Siyazi ukuthi la mabhayithi avumelekile, ngakho-ke sizosebenzisa i-`unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Amabhayithi angalungile:
    ///
    /// ```
    /// // amanye amabhayithi angavumelekile, ku-vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Bona amadokhumenti e-[`FromUtf8Error`] ukuthola eminye imininingwane yokuthi ungenzani ngaleli phutha.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Iguqula ucezu lwamabhayithi lube yunithi yezinhlamvu, kufaka phakathi izinhlamvu ezingavumelekile.
    ///
    /// Izintambo zenziwe ngama-byte ([`u8`]), nocezu lwama-byte ([`&[u8]`][byteslice]) lwenziwe ngamabhayithi, ngakho-ke lo msebenzi uguquka phakathi kwalokhu okubili.Akuzona zonke izingcezu ze-byte eziyizintambo ezivumelekile, kepha: izintambo ziyadingeka ukuthi zibe yi-UTF-8 evumelekile.
    /// Ngesikhathi sokuguqulwa, i-`from_utf8_lossy()` izothatha indawo yanoma ikuphi ukulandelana okungavumelekile kwe-UTF-8 nge-[`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], ebukeka kanjena:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Uma uqinisekile ukuthi ucezu lwe-byte luvumelekile i-UTF-8, futhi awufuni ukungena ngaphezulu kokuguqulwa, kunenguqulo engaphephile yalo msebenzi, i-[`from_utf8_unchecked`], enokuziphatha okufanayo kepha yeqa amasheke.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Lo msebenzi ubuyisa i-[`Cow<'a, str>`].Uma ucezu lwethu lwe-byte lungavumelekile i-UTF-8, lapho-ke sidinga ukufaka izinhlamvu ezizongena esikhundleni, ezizoshintsha usayizi wentambo, ngakho-ke, zidinga i-`String`.
    /// Kepha uma sekuvele kusebenza i-UTF-8, asidingi isabelo esisha.
    /// Lolu hlobo lokubuyisa lusivumela ukuthi siphathe womabili amacala.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye ama-byte, ku-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Amabhayithi angalungile:
    ///
    /// ```
    /// // amanye amabhayithi angavumelekile
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Nquma i-UTF-16-encoded vector `v` ibe yi-`String`, ibuyise i-[`Err`] uma i-`v` iqukethe noma iyiphi idatha engavumelekile.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Lokhu akwenziwa nge collect: : <Result<_, _>> () ngezizathu zokusebenza.
        // FIXME: umsebenzi ungenziwa lula futhi lapho i-#48994 ivaliwe.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Nquma ucezu olubhalwe nge-UTF-16 - u-`v` lube yi-`String`, esikhundleni sedatha engavumelekile ne-[the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ngokungafani ne-[`from_utf8_lossy`] ebuyisa i-[`Cow<'a, str>`], i-`from_utf16_lossy` ibuyisa i-`String` ngoba ukuguqulwa kwe-UTF-16 kuye ku-UTF-8 kudinga ukwabiwa kwememori.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Ibola i-`String` ibe izingxenye zayo eziluhlaza.
    ///
    /// Ibuyisa isikhombisi esiluhlaza kudatha engaphansi, ubude bezintambo (ngama-byte), namandla abiwe emininingwane (ngama-byte).
    /// Lezi yizimpikiswano ezifanayo ngokulandelana kwezimpikiswano eziya ku-[`from_raw_parts`].
    ///
    /// Ngemuva kokubiza lo msebenzi, ofonayo ubhekene nememori ephethwe yi-`String` ngaphambilini.
    /// Ukuphela kwendlela yokwenza lokhu ukuguqula i-pointer eluhlaza, ubude, nomthamo ubuyisele ku-`String` ngomsebenzi we-[`from_raw_parts`], uvumele umbhubhisi ukuthi enze ukuhlanza.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Idala i-`String` entsha kusuka kubude, umthamo, nesikhombi.
    ///
    /// # Safety
    ///
    /// Lokhu akuphephile kakhulu, ngenxa yenani labafakizicelo abangahloliwe:
    ///
    /// * Imemori eku-`buf` idinga ukuthi ngaphambili yabelwe isabelo esifanayo umtapo wolwazi ojwayelekile osetshenziswayo, ngokuqondanisa okudingekayo okuyi-1 ngqo.
    /// * `length` idinga ukuba ngaphansi noma ilingane ne-`capacity`.
    /// * `capacity` idinga ukuba yinani elifanele.
    /// * Ama-byte wokuqala we-`length` ku-`buf` adinga ukuba yi-UTF-8 evumelekile.
    ///
    /// Ukwephula lokhu kungadala izinkinga ezifana nokonakalisa izakhiwo zedatha yangaphakathi yomhlinzeki.
    ///
    /// Ubunikazi be `buf` budluliselwa ngempumelelo kwi-`String` engabe isabelana, isaba kabusha noma iguqule okuqukethwe kwememori ekhonjiswe yisikhombi ngentando.
    /// Qiniseka ukuthi akukho okunye okusebenzisa i-pointer ngemuva kokubiza lo msebenzi.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Vuselela lokhu lapho i-vec_into_raw_parts izinzile.
    ///     // Vimbela ukulahla ngokuzenzakalela idatha ye-String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Iguqula i-vector yamabhayithi ibe yi-`String` ngaphandle kokubheka ukuthi intambo iqukethe i-UTF-8 evumelekile.
    ///
    /// Bona inguqulo ephephile, i-[`from_utf8`], ukuthola eminye imininingwane.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba awubheki ukuthi ama-byte adluliselwe kuwo avumelekile i-UTF-8.
    /// Uma lesi sikhawulo siphuliwe, kungadala izingqinamba zokuphepha kwememori ngabasebenzisi be-future be-`String`, njengoba wonke umtapo wolwazi ojwayelekile uthatha ukuthi ama-`String`s avumelekile i-UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye ama-byte, ku-vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Iguqula i-`String` ibe yi-byte vector.
    ///
    /// Lokhu kudla i-`String`, ngakho-ke asidingi ukukopisha okuqukethwe kwayo.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Ikhipha ucezu lwentambo oluqukethe yonke i-`String`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Iguqula i-`String` ibe yisigaxa sentambo esiguquguqukayo.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Faka ucezu lwentambo olunikeziwe ekugcineni kwale `String`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Ibuyisa umthamo wale `String`, ngama-byte.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Iqinisekisa ukuthi amandla ale `String` okungenani ama-byte ayi-`additional` makhulu kunobude bawo.
    ///
    /// Umthamo ungakhushulwa ngaphezulu kwama-byte we-`additional` uma uthanda, ukuvimbela ukwabiwa kabusha okuvamile.
    ///
    ///
    /// Uma ungafuni le ndlela ye-"at least", bona indlela ye-[`reserve_exact`].
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha uchichima i-[`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Lokhu kungenzeka kungakhulisi umthamo:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s manje inobude obungu-2 namandla angu-10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Njengoba sesivele sinomthamo owengeziwe ongu-8, ukubiza lokhu ...
    /// s.reserve(8);
    ///
    /// // ... empeleni ayinyuki.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Iqinisekisa ukuthi umthamo wale `String` ungama-`additional` byte amakhulu kunobude bawo.
    ///
    /// Cabanga ukusebenzisa indlela ye [`reserve`] ngaphandle kokuthi wazi kangcono kunokwabiwayo.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha uchichima i-`usize`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Lokhu kungenzeka kungakhulisi umthamo:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s manje inobude obungu-2 namandla angu-10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Njengoba sesivele sinomthamo owengeziwe ongu-8, ukubiza lokhu ...
    /// s.reserve_exact(8);
    ///
    /// // ... empeleni ayinyuki.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Izama ukugcina umthamo okungenani wezinto ezingama-`additional` eziningi ezizofakwa ku-`String` enikeziwe.
    /// Iqoqo lingagcina isikhala esithe xaxa ukugwema ukwabiwa kabusha okuvamile.
    /// Ngemuva kokushayela i-`reserve`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le i-OOM ayikwazi phakathi nomsebenzi wethu onzima
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Izama ukugcina umthamo omncane wezinto ezingama-`additional` ngaphezulu ezizofakwa ku-`String` enikeziwe.
    ///
    /// Ngemuva kokushayela i-`reserve_exact`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// Qaphela ukuthi umhlinzeki anganikeza iqoqo isikhala esengeziwe kunalokho elikucelayo.
    /// Ngakho-ke, umthamo awunakwethenjelwa kuwo ukuthi ube mncane ngokunembile.
    /// Khetha i-`reserve` uma kulindelwe ukufakwa kwe-future.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le i-OOM ayikwazi phakathi nomsebenzi wethu onzima
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Inciphisa umthamo wale `String` ukufanisa ubude bayo.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Yehlisa umthamo wale `String` ngentambo ephansi.
    ///
    /// Umthamo uzohlala okungenani ukhulu njengokubili ubude nenani elinikeziwe.
    ///
    ///
    /// Uma umthamo wamanje ungaphansi komkhawulo ophansi, lena yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Ifaka i-[`char`] enikeziwe ekugcineni kwale `String`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Ibuyisa ucezu lwe-byte lokuqukethwe kwale `String`.
    ///
    /// Ukuphambana kwale ndlela ngu-[`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Ifinyeza le `String` kubude obucacisiwe.
    ///
    /// Uma i-`new_len` inkulu kunobude bamanje bezintambo, lokhu akunamphumela.
    ///
    ///
    /// Qaphela ukuthi le ndlela ayinamthelela kumthamo owabiwe wentambo
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`new_len` ingekho emngceleni we-[`char`].
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Isusa uhlamvu lokugcina kusikhumbuli sentambo bese iyibuyisela.
    ///
    /// Ibuyisa i-[`None`] uma le `String` ingenalutho.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Isusa i [`char`] kusuka kule `String` endaweni ye-byte bese iyibuyisa.
    ///
    /// Lokhu kungukusebenza kwe-*O*(*n*), njengoba kudinga ukukopisha yonke into kubhafa.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`idx` inkulu noma ilingana nobude be-`String`, noma uma ingekho emngceleni we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Susa konke ukufana kwephethini `pat` ku-`String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ukufana kuzotholwa futhi kususwe ngokweqile, ngakho-ke ezimweni lapho amaphethini egqagqana khona, kuzosuswa iphethini yokuqala kuphela:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // UKUPHEPHA: ukuqala nokuphela kuzoba semingceleni ye-utf8 byte
        // amadokhumenti Wosesho
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Igcina kuphela izinhlamvu ezichazwe yisilandiso.
    ///
    /// Ngamanye amagama, susa zonke izinhlamvu `c` ngendlela yokuthi i `f(c)` ibuyisa i `false`.
    /// Le ndlela isebenza endaweni, ivakashela uhlamvu ngalunye ngqo ngokulandelana kwasekuqaleni, futhi igcina ukuhleleka kwezinhlamvu ezigciniwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// I-oda eliqondile lingaba wusizo ekulandeleni isimo sangaphandle, njengenkomba.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Khomba i-idx kuchar elandelayo
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Ifaka uhlamvu kule `String` kusikhundla se-byte.
    ///
    /// Lokhu kungukusebenza kwe-*O*(*n*) njengoba kudinga ukukopisha yonke into kubhafa.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`idx` inkulu kunobude be-`String`, noma uma ingekho emngceleni we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Ifaka ucezu lwentambo kule `String` kusikhundla se-byte.
    ///
    /// Lokhu kungukusebenza kwe-*O*(*n*) njengoba kudinga ukukopisha yonke into kubhafa.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`idx` inkulu kunobude be-`String`, noma uma ingekho emngceleni we-[`char`].
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Ibuyisa ireferensi engaguquleka kokuqukethwe kwale `String`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba awubheki ukuthi ama-byte adluliselwe kuwo avumelekile i-UTF-8.
    /// Uma lesi sikhawulo siphuliwe, kungadala izingqinamba zokuphepha kwememori ngabasebenzisi be-future be-`String`, njengoba wonke umtapo wolwazi ojwayelekile uthatha ukuthi ama-`String`s avumelekile i-UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Ibuyisa ubude bale `String`, ngama-byte, hhayi [`char`] s noma ama-graphemes.
    /// Ngamanye amagama, kungahle kungabi yilokho umuntu akubheka njengobude bentambo.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Ibuyisa i-`true` uma le `String` inobude beqanda, futhi i-`false` ngenye indlela.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ihlukanisa intambo kabili ku-index ye-byte enikeziwe.
    ///
    /// Ibuyisa i-`String` esanda kwabiwa.
    /// `self` iqukethe amabhayithi `[0, at)`, kanti i-`String` ebuyisiwe iqukethe amabhayithi `[at, len)`.
    /// `at` kumele kube semngceleni wephoyinti lekhodi le-UTF-8.
    ///
    /// Qaphela ukuthi umthamo we `self` awuguquki.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`at` ingekho emngceleni wephoyinti le-`UTF-8`, noma uma ingaphezulu kwephoyinti lokugcina lentambo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Isusa le `String`, isusa konke okuqukethwe.
    ///
    /// Ngenkathi lokhu kusho ukuthi i `String` izoba nobude beqanda, ayithinti umthamo wayo.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Kwakha i-iterator yokukhipha esusa ububanzi obucacisiwe ku-`String` futhi iveze i-`chars` esusiwe.
    ///
    ///
    /// Note: Ububanzi bezinto buyasuswa noma ngabe i-iterator ingadliwanga kuze kube sekupheleni.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala noma iphuzu lokugcina lingekho kumngcele we-[`char`], noma uma kungaphandle kwemingcele.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Susa ibanga kuze kube u-β entanjeni
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Ububanzi obugcwele busula intambo
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Ukuphepha kwememori
        //
        // Uhlobo lwe-String lwe-Drain alunazo izingqinamba zokuphepha kwememori zohlobo lwe-vector.
        // Idatha ingama-byte nje.
        // Ngoba ukususwa kobubanzi kwenzeka eDrop, uma iterator ye Drain idaluliwe, ukususwa ngeke kwenzeke.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Khipha izikweletu ezimbili ngasikhathi sinye.
        // I-&mut String ngeke ifinyelelwe kuze kube yilapho kuqeda ukwenziwa, eDrop.
        let self_ptr = self as *mut _;
        // UKUPHEPHA: I-`slice::range` ne-`is_char_boundary` zenza amasheke wemingcele afanele.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Isusa ububanzi obucacisiwe entanjeni, bese iyifaka esikhundleni sentambo enikeziwe.
    /// Intambo enikeziwe ayidingi ukuba nobude obufanayo nobubanzi.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala noma iphuzu lokugcina lingekho kumngcele we-[`char`], noma uma kungaphandle kwemingcele.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Faka okunye esikhundleni sebanga kuze kube u-β ocingweni
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Ukuphepha kwememori
        //
        // Faka esikhundleni_ibanga alinazo izingqinamba zokuphepha kwememori ze-vector Splice.
        // yenguqulo ye vector.Imininingwane ingama-byte asobala.

        // ISEXWAYISO: Ukufakwa kokungafani kokungekho emthethweni kungaba yi-(#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ISEXWAYISO: Ukufakwa kokungafani kokungekho emthethweni kungaba yi-(#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ukusebenzisa i-`range` futhi bekungeke kutholakale i-(#81138) Sicabanga ukuthi imingcele ebikwe yi-`range` ihlala ifana, kepha ukusetshenziswa okuphikisanayo kungashintsha phakathi kwezingcingo
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Iguqula le `String` ibe i-[`Box`]`<`[`str`] `>`.
    ///
    /// Lokhu kuzokwehlisa noma imuphi umthamo okweqile.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Ibuyisa ucezu lwama-byte ka-[`u8`] azame ukuguqulela ku-`String`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye amabhayithi angavumelekile, ku-vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Ibuyisa amabhayithi azame ukuguqulela ku-`String`.
    ///
    /// Le ndlela yakhiwe ngokucophelela ukugwema ukwabiwa.
    /// Izosebenzisa iphutha, isuse ama-byte, ukuze ikhophi lama-byte lingadingi ukwenziwa.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye amabhayithi angavumelekile, ku-vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Landa i `Utf8Error` ukuthola imininingwane eminingi ngokuhluleka kokuguqulwa.
    ///
    /// Uhlobo lwe-[`Utf8Error`] olunikezwe i-[`std::str`] lumele iphutha elingavela lapho kuguqulwa ucezu luka-[`u8`] ku-[`&str`].
    /// Ngalo mqondo, iyi-analog ku-`FromUtf8Error`.
    /// Bona imibhalo yayo ukuthola eminye imininingwane yokuyisebenzisa.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // amanye amabhayithi angavumelekile, ku-vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ibhayithi lokuqala alivumelekile lapha
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ngoba sisebenza ngaphezulu kwe-`String`s, singagwema okungenani isabelo esisodwa ngokuthola intambo yokuqala kusuka ku-iterator bese siyifaka kuyo yonke intambo elandelayo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ngoba sisebenza ngaphezulu kwama-CoWs, singakwazi (potentially) ukugwema okungenani isabelo esisodwa ngokuthola into yokuqala bese siyifaka kuzo zonke izinto ezilandelayo.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Ukufakwa okulula okuthunyelwa ku-impl ye-`&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Idala i-`String` engenalutho.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Isebenzisa i-`+` opharetha wokuhlanganisa izintambo ezimbili.
///
/// Lokhu kudla i-`String` ngakwesobunxele bese iphinda isebenzise i-buffer yayo (ukuyikhulisa uma kunesidingo).
/// Lokhu kwenziwa ukugwema ukwaba i-`String` entsha nokukopisha konke okuqukethwe kukho konke ukusebenza, okungaholela kusikhathi sokusebenza * **(* n *^ 2) lapho kwakhiwa umucu we-* n *-byte Ngokuphindaphinda.
///
///
/// Intambo engakwesokudla ibolekwa kuphela;okuqukethwe kwayo kukopishelwa ku-`String` ebuyisiwe.
///
/// # Examples
///
/// Ukuhlanganisa ama-`String`s amabili kuthatha eyokuqala ngenani bese iboleka eyesibili:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` isuswa futhi ayisakwazi ukusetshenziswa lapha.
/// ```
///
/// Uma ufuna ukuqhubeka usebenzisa i-`String` yokuqala, ungayihlanganisa bese ungena ku-clone esikhundleni salokho:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` isasebenza lapha.
/// ```
///
/// Ukuhlanganisa izingcezu ze-`&str` kungenziwa ngokuguqula eyokuqala ibe yi-`String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Isebenzisa opharetha we `+=` ukufaka i `String`.
///
/// Lokhu kunokuziphatha okufanayo nendlela ye [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Uhlobo lwamagama we-[`Infallible`].
///
/// Le alias ikhona ngokuhambisana nokubuyela emuva, futhi ingahle yehliswe ekugcineni.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// I-trait yokuguqula inani libe yi-`String`.
///
/// Le trait isetshenziswa ngokuzenzakalela kunoma yiluphi uhlobo olusebenzisa i [`Display`] trait.
/// Kanjalo, i `ToString` akufanele isetshenziswe ngqo:
/// [`Display`] kufanele kusetshenziswe esikhundleni salokho, bese uthola ukusetshenziswa kwe `ToString` mahhala.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Iguqula inani elinikeziwe libe yi-`String`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Kulokhu kusetshenziswa, indlela ye-`to_string` panics uma ukusetshenziswa kwe-`Display` kubuyisa iphutha.
/// Lokhu kukhombisa ukusetshenziswa kwe-`Display` okungalungile ngoba i-`fmt::Write for String` ayikaze ibuyise iphutha uqobo.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Umhlahlandlela ovamile ukungafaki emugqeni imisebenzi ejwayelekile.
    // Kodwa-ke, ukususa i-`#[inline]` kule ndlela kubangela ukuhlehla okunganakwa.
    // Bona i <https://github.com/rust-lang/rust/pull/74852>, umzamo wokugcina wokuzama ukuyisusa.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Iguqula i-`&mut str` ibe yi-`String`.
    ///
    /// Umphumela wabiwa enqwabeni.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test kudonsela ku-libstd, okudala amaphutha lapha
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Iguqula ucezu lwe-`str` olunikeziwe lube yi-`String`.
    /// Kuyaphawuleka ukuthi ucezu lwe `str` luphethwe.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Iguqula i-`String` enikeziwe ibe ucezu lwebhokisi le-`str` okungelakhe.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Iguqula ucezu lwentambo lube okuhlukile okubolekwe.
    /// Akukho ukwabiwa kwenqwaba okwenziwayo, futhi intambo ayikopiswanga.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Iguqula intambo ibe okuhlukile okungumnikazi.
    /// Akukho ukwabiwa kwenqwaba okwenziwayo, futhi intambo ayikopiswanga.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Iguqula ireferensi ye-String ibe okuhlukile okubolekwe.
    /// Akukho ukwabiwa kwenqwaba okwenziwayo, futhi intambo ayikopiswanga.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Iguqula i-`String` enikeziwe ibe yi-vector `Vec` ephethe amanani ohlobo `u8`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// I-iterator ekhipha i-`String`.
///
/// Lesi sakhiwo senziwe ngendlela ye-[`drain`] ku-[`String`].
/// Bona imibhalo yayo ukuthola okuningi.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Izosetshenziswa njenge&'a mut String kumbhuqi
    string: *mut String,
    /// Ukuqala kwengxenye ukususa
    start: usize,
    /// Ukuphela kwengxenye ukususa
    end: usize,
    /// Ibanga lamanje elisele elizosuswa
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Sebenzisa i-Vec::drain.
            // "Reaffirm" ukubhekwa kwemingcele ukugwema ikhodi ye panic ukufakwa futhi.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Ibuyisa intambo esele (sub) yale iterator njengocezu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment I-AsRef ifaka ngezansi lapho izinza.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Uncomment lapho kuqiniswa i `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>kwe Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ye-Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}