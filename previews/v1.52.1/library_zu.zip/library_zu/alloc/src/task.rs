#![stable(feature = "wake_trait", since = "1.51.0")]
//! Izinhlobo kanye ne-Traits yokusebenza ngemisebenzi ye-asynchronous.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Ukuqaliswa kokuvusa umsebenzi kumabi wefa.
///
/// Le trait ingasetshenziselwa ukudala i [`Waker`].
/// Umabi wefa angachaza ukuqaliswa kwale trait, futhi akusebenzise lokho ukwakha i-Waker ukudlulisela emisebenzini eyenziwa kulowo owehlayo.
///
/// Le trait iyindlela ephephile yememori ne-ergonomic yokwakha i [`RawWaker`].
/// Ixhasa ukwakheka komphathi ovamile lapho idatha esetshenzisiwe ukuvusa umsebenzi igcinwa khona ku-[`Arc`].
/// Abanye abaphathi (ikakhulukazi labo bezinhlelo ezishumekiwe) abakwazi ukusebenzisa le API, yingakho i [`RawWaker`] ikhona njengenye indlela yalezo zinhlelo.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Umsebenzi we-`block_on` oyisisekelo othatha i-future bese uyigijimisa ize iqedwe ngentambo yamanje.
///
/// **Note:** Lesi sibonelo sidayisa ngokunemba ukuze kube lula.
/// Ukuze uvimbele izingqinamba, ukusetshenziswa kwebanga lokukhiqiza kuzodinga futhi ukuphatha izingcingo eziphakathi eziya ku-`thread::unpark` kanye nokunxusa okuhlanganisiwe.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// I-waker evusa intambo yamanje lapho ibizwa.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Qalisa i-future ukuze uqede ngentambo yamanje.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Namathisela i-future ukuze ikwazi ukupholishwa.
///     let mut fut = Box::pin(fut);
///
///     // Dala umongo omusha ozodluliselwa ku-future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Qalisa i-future uze uyiqede.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Vusa lo msebenzi.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vusa lo msebenzi ngaphandle kokusebenzisa i-waker.
    ///
    /// Uma umabi wefa esekela indlela eshibhile yokuvuka ngaphandle kokusebenzisa i-waker, kufanele ibhale le ndlela.
    /// Ngokuzenzakalelayo, ihlanganisa i-[`Arc`] futhi ibize i-[`wake`] ku-clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // UKUPHEPHA: Lokhu kuphephile ngoba i-raw_waker yakha ngokuphepha
        // i-RawWaker evela ku-Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Lo msebenzi wangasese wokwakha iRawWaker uyasetshenziswa, kunokuba
// ukufaka lokhu ku-`From<Arc<W>> for RawWaker` impl, ukuqinisekisa ukuthi ukuphepha kwe-`From<Arc<W>> for Waker` akuxhomekile ekuthumeleni okulungile kwe-trait, esikhundleni salokho zombili izixhumi zibiza lo msebenzi ngqo nangokucacile.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Khulisa isibalo sesethenjwa se-arc ukuze usihlanganise.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vuka ngenani, uhambise i-Arc kumsebenzi we-Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Vuka ngesethenjwa, songa i-waker ku-ManuallyDrop ukuze ugweme ukuyilahla
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Yehlisa ukubalwa kwesethenjwa kwe-Arc kudrophu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}