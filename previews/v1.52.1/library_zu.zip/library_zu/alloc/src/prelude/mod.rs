//! Isabelo Prelude
//!
//! Inhloso yale moduli ukunciphisa ukungeniswa kwezinto ezisetshenziswa kakhulu ze `alloc` crate ngokungeza ukungenisa kwe-glob phezulu kwamamojula:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;