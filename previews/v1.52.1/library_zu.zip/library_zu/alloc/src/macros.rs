/// Idala i-[`Vec`] equkethe izimpikiswano.
///
/// `vec!` ivumela `ama-Vec` achazwe nge-syntax efanayo nezincazelo zamalungu afanayo.
/// Kunezinhlobo ezimbili zalesi macro:
///
/// - Dala i-[`Vec`] equkethe uhlu olunikeziwe lwezinto:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Dala i-[`Vec`] kusuka entweni nosayizi onikeziwe:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Qaphela ukuthi ngokungafani nezinkulumo zamalungu afanayo le syntax isekela zonke izinto ezisebenzisa i-[`Clone`] futhi nenombolo yezinto akudingeki ukuthi ihlale ingaguquguquki.
///
/// Lokhu kuzosebenzisa i-`clone` ukuphinda kabili isisho, ngakho-ke umuntu kufanele aqaphele ukusebenzisa lokhu ngezinhlobo ezinokusetshenziswa okungamisiwe kwe-`Clone`.
/// Isibonelo, i-`vec![Rc::new(1);I-5] `izokwakha i-vector yezikhombo ezinhlanu kunani eliphelele elibhokisiwe, hhayi izinkomba ezinhlanu ezikhomba izinombolo ezizimele zebhokisi.
///
///
/// Futhi, qaphela ukuthi i-`vec![expr; 0]` ivunyelwe, futhi ikhiqiza i vector engenalutho.
/// Lokhu kusazovivinya i-`expr`, noma kunjalo, bese kwehla ngokushesha inani elivelayo, ngakho-ke khumbula imiphumela emibi.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): nge cfg(test) indlela yemvelo ye `[T]::into_vec`, edingekayo kule ncazelo enkulu, ayitholakali.
// Esikhundleni salokho sebenzisa umsebenzi we-`slice::into_vec` otholakala kuphela nge-cfg(test) NB bona imodyuli ye-slice::hack ku-slice.rs ukuthola eminye imininingwane
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Idala i-`String` isebenzisa ukuhumusha kwezincazelo zesikhathi sokusebenza.
///
/// Impikiswano yokuqala etholwa i-`format!` iyintambo yefomethi.Lokhu kufanele kube ngentambo ngokoqobo.Amandla wentambo yokufometha aqukethwe ku-`{}` s.
///
/// Amapharamitha angeziwe adluliselwe ku-`format!` angena esikhundleni se-`{}` s ngaphakathi kwentambo yokufometha ku-oda olunikeziwe ngaphandle kokuthi kusetshenziswe amapharamitha aqanjiwe noma wesimo;bona i [`std::fmt`] ukuthola eminye imininingwane.
///
///
/// Ukusetshenziswa okuvamile kwe `format!` ukuhlanganiswa kanye nokufakwa kwentambo.
/// Umhlangano ofanayo usetshenziswa nama-[`print!`] ne-[`write!`] macros, kuya ngendawo okuhlosiwe kuyo yentambo.
///
/// Ukuguqula inani elilodwa libe yunithi yezinhlamvu, sebenzisa indlela ye-[`to_string`].Lokhu kuzosebenzisa ukufomatha kwe-[`Display`] i trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` I-panics uma ukufometha kwe-trait kubuyisa iphutha.
/// Lokhu kukhombisa ukusetshenziswa okungalungile ngoba i `fmt::Write for String` ayikaze ibuyise iphutha uqobo.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Phoqelela i-AST node kusisho ukuze uthuthukise ukuxilongwa endaweni yephethini.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}