//! Uhlobo oluthambekayo lokukhula olunokuqukethwe okwabiwe ngenqwaba, elibhaliwe i-`Vec<T>`.
//!
//! I-Vectors ine-indexing ye-`O(1)`, i-amortized `O(1)` Push (kuze kube sekupheleni) ne-`O(1)` pop (kusuka ekugcineni).
//!
//!
//! Ama-Vectors aqinisekisa ukuthi awabeki ngaphezu kwama-byte we-`isize::MAX`.
//!
//! # Examples
//!
//! Ungadala ngokusobala i-[`Vec`] nge-[`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... noma ngokusebenzisa i-[`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // amaqanda ayishumi
//! ```
//!
//! Ungabeka amanani we-[`push`] ekugcineni kwe-vector (okuzokhulisa i-vector njengoba kudingeka):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Amanani wokuvela asebenza ngendlela efanayo:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! I-Vectors ibuye isekele inkomba (nge [`Index`] ne [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Uhlobo oluhlanganayo lokukhula olufanayo, olubhalwe njenge-`Vec<T>` laphinde lasho i-'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// I-[`vec!`] macro inikezwe ukwenza ukuqalisa kube lula kakhulu:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Futhi ingaqalisa into ngayinye ye-`Vec<T>` ngenani elinikeziwe.
/// Lokhu kungasebenza kangcono kunokwabiwa nokwenziwa ngezinyathelo ezihlukene, ikakhulukazi lapho kuqalwa i-vector yamazero:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Okulandelayo kuyalingana, kepha kungahle kuhambe kancane:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Ngeminye imininingwane, bona i [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Sebenzisa i-`Vec<T>` njengesitaki esisebenza kahle:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Iphrinta 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Uhlobo lwe `Vec` luvumela ukufinyelela amanani ngenkomba, ngoba isebenzisa i [`Index`] trait.Isibonelo sizocaca bha:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // izokhombisa i '2'
/// ```
///
/// Kodwa-ke qaphela: uma uzama ukufinyelela inkomba engekho ku-`Vec`, isoftware yakho izokwenza i panic!Awukwazi ukwenza lokhu:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Sebenzisa i-[`get`] ne-[`get_mut`] uma ufuna ukubheka ukuthi ngabe inkomba iku-`Vec` yini.
///
/// # Slicing
///
/// I-`Vec` ingaguquguquka.Ngakolunye uhlangothi, izingcezu izinto ezifundwayo kuphela.
/// Ukuze uthole i-[slice][prim@slice], sebenzisa i-[`&`].Isibonelo:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... futhi yilokho kuphela!
/// // ungakwenza futhi kanjena:
/// let u: &[usize] = &v;
/// // noma kanjena:
/// let u: &[_] = &v;
/// ```
///
/// Ku-Rust, kuvame ukwedlula izingcezu njengezimpikiswano kune-vectors lapho ufuna ukunikeza ukufinyelela kokufunda.Okufanayo kuya ku-[`String`] naku-[`&str`].
///
/// # Amandla kanye nokwabiwa kabusha
///
/// Umthamo we-vector yinani lesikhala esinikezwe noma yiziphi izinto ze-future ezizofakwa ku-vector.Lokhu akufanele kudidaniswe nobude * be-vector, obucacisa inani lezinto zangempela ngaphakathi kwe-vector.
/// Uma ubude be-vector budlula umthamo wabo, amandla ayo azokwandiswa ngokuzenzakalela, kepha izakhi zawo kuzodingeka zabiwe kabusha.
///
/// Isibonelo, i-vector enomthamo ongu-10 nobude 0 ingaba yi-vector engenalutho enesikhala sezinto eziyi-10 ezengeziwe.Ukududula izinto eziyi-10 noma ezimbalwa ku-vector ngeke kushintshe amandla ayo noma kubangele ukuthi ukwaba kabusha kwenzeke.
/// Kodwa-ke, uma ubude be-vector bukhuphukelwa ku-11, kuzofanele bube kabusha, obungahamba kancane.Ngalesi sizathu, kunconywa ukuthi usebenzise i-[`Vec::with_capacity`] lapho kungenzeka khona ukucacisa ukuthi i vector kulindeleke ukuthi ibe nkulu kangakanani.
///
/// # Guarantees
///
/// Ngenxa yemvelo yayo eyisisekelo ngokumangazayo, i `Vec` yenza iziqinisekiso eziningi ngokwakhiwa kwayo.Lokhu kuqinisekisa ukuthi ingaphezulu kakhulu ngangokunokwenzeka esimweni esejwayelekile, futhi ingasetshenziswa kahle ngezindlela zasendulo ngekhodi engaphephile.Qaphela ukuthi lezi ziqinisekiso zibhekise ku-`Vec<T>` engafanelekile.
/// Uma kungezwa amapharamitha wohlobo olungeziwe (isb., Ukuxhasa abahlinzeki ngokwezifiso), ukubhala ngaphezulu kokuzenzakalelayo kwabo kungashintsha ukusebenza.
///
/// Ngokuyinhloko, i-`Vec` ikhona futhi izohlala iyi-(pointer, umthamo, ubude) kathathu.Akusekho, noma ngaphansi.Ukuhleleka kwalezi zinkambu akucacisiwe ngokuphelele, futhi kufanele usebenzise izindlela ezifanele ukuguqula lezi.
/// Isikhombi asisoze saba yize, ngakho-ke lolu hlobo lwenziwe null-pointer-optimised.
///
/// Kodwa-ke, isikhombisi kungenzeka sikhombe kwimemori eyabiwe.
/// Ikakhulu, uma wakha i-`Vec` ngomthamo 0 nge-[`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], noma ngokushayela i-[`shrink_to_fit`] ku-Vec engenalutho, ngeke ikhiphe imemori.Ngokufanayo, uma ugcina izinhlobo ezilingana no-zero ngaphakathi kwe-`Vec`, ngeke yababele isikhala.
/// *Qaphela ukuthi kulokhu i-`Vec` kungenzeka ingabiki i-[`capacity`] ka-0*.
/// `Vec` izokwaba uma kuphela uma [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Ngokuvamile, imininingwane yokwabiwa kwe-`Vec` icashile kakhulu-uma uhlose ukwaba inkumbulo usebenzisa i-`Vec` bese uyisebenzisela okunye (noma ukudlulisela ikhodi engaphephile, noma ukwakha iqoqo lakho elenziwa ngememori), qiniseka ukusabalalisa le nkumbulo usebenzisa i-`from_raw_parts` ukuthola i-`Vec` bese uyilahla.
///
/// Uma i-`Vec`*inikeze* inkumbulo, imemori ekhomba kuyo isenqwabeni (njengoba kuchaziwe ngumhlinzeki i-Rust ihlelwe ukuthi isetshenziswe ngokuzenzakalela), futhi izikhombisi zayo zikhomba ku-[`len`] kuqalisiwe, izinto ezihlanganayo ngokulandelana (lokho ongakwenza bona ukuthi uyiphoqe yini ukuba ibe ngocezwana), kulandelwe [`umthamo`]`,`[`len`] okunengqondo okungaqalisiwe, izinto ezihlanganayo.
///
///
/// I-vector equkethe i-`'a'` ne-`'b'` enomthamo 4 ingabonwa ngezansi.Ingxenye ephezulu yisakhiwo se `Vec`, iqukethe isikhombisi enhloko yesabelo kunqwaba, ubude namandla.
/// Ingxenye engezansi isabelo esikwinqwaba, ibhulokhi yememori ehlanganayo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** imele imemori engaqaliwe, bona i [`MaybeUninit`].
/// - Note: i-ABI ayizinzile futhi i `Vec` ayenzi ziqinisekiso mayelana nokuhlelwa kwememori yayo (kufaka phakathi ukuhleleka kwezinkambu).
///
/// `Vec` ayisoze yenze i-"small optimization" lapho izinto zigcinwa esitaki ngezizathu ezimbili:
///
/// * Kungenza kube nzima kakhulu ngekhodi engaphephile ukusebenzisa i `Vec` ngokufanele.Okuqukethwe kwe-`Vec` bekungeke kube nekheli elizinzile ukube bekuhanjiswa kuphela, futhi kungaba nzima kakhulu ukuthola ukuthi ngabe i-`Vec` ibiyinike imemori ngempela yini.
///
/// * Kuzojezisa icala elijwayelekile, kufake i-branch eyengeziwe kukho konke ukufinyelela.
///
/// `Vec` ngeke ize izinciphise ngokuzenzekelayo, noma ingenalutho ngokuphelele.Lokhu kuqinisekisa ukuthi akukho ukwabiwa okungadingekile noma ukwabiwa kwemali okwenzekayo.Ukukhipha i-`Vec` bese uyigcwalisela emuva ku-[`len`] efanayo akufanele kutholakale izingcingo ezabiwe kumhlinzeki.Uma ufisa ukukhulula imemori engasetshenziswanga, sebenzisa i-[`shrink_to_fit`] noma i-[`shrink_to`].
///
/// [`push`] futhi i [`insert`] ayisoze (iphinde) yabele uma umthamo obikiwe wenele.I-[`push`] ne-[`insert`]* * zizophinda zinikeze uma [`len`]`=`` ``umthamo`].Lokho wukuthi, amandla abikiwe anembe ngokuphelele, futhi kungathenjelwa kuwo.Ingasetshenziselwa ngisho nokukhulula ngesandla imemori eyabelwe i-`Vec` uma ifunwa.
/// Izindlela zokufaka ngobuningi * zingabelwa kabusha, noma kungadingeki.
///
/// `Vec` ayiqinisekisi noma yiliphi isu lokukhula lapho ufaka kabusha lapho kugcwele, noma kubizwa i [`reserve`].Icebo lamanje liyisisekelo futhi lingakhombisa ukufiseleka ukusebenzisa isici sokukhula esingaguquguquki.Noma ngabe yiliphi isu elisetshenzisiwe ngokuqinisekile lizoqinisekisa *O*(1) i-[`push`] ekhokhelwe.
///
/// `vec![x; n]`, I `vec![a, b, c, d]`, ne [`Vec::with_capacity(n)`][`Vec::with_capacity`], konke kuzokhiqiza i `Vec` ngomthamo oceliwe ncamashi.
/// Uma [`len`]`==`[`umthamo`], (njengoba kunjalo nge-[`vec!`] macro), i-`Vec<T>` ingaguqulwa iye noma isuke ku-[`Box<[T]>`][owned slice] ngaphandle kokuphinda ihambise noma ihambise izinto.
///
/// `Vec` ngeke isule ngqo noma iyiphi idatha esuswe kuyo, kepha futhi ngeke iyigcine ngokuqondile.Imemori yayo engaqaliwe iyisikhala sokuqala esingase siyisebenzise noma ngabe sifuna kanjani.Ngokuvamile izokwenza noma yini esebenza kahle kakhulu noma okulula ukuyisebenzisa.Ungathembeli kudatha esusiwe ukuthi izosulwa ngezinjongo zokuphepha.
/// Noma ulahla i-`Vec`, i-buffer yayo ingavele isetshenziswe enye i-`Vec`.
/// Noma ngabe uqeda inkumbulo ye-Vec` kuqala, lokho kungenzeka kungenzeki ngoba i-optimizer ayibheki lokhu njengomphumela oseceleni okufanele ugcinwe.
/// Kunecala elilodwa esingeke siliphule, kepha: ukusebenzisa ikhodi ye-`unsafe` ukubhala kumthamo owedlulele, bese ukwandisa ubude ukufanisa, kuhlala kusebenza.
///
/// Njengamanje, i-`Vec` ayiqinisekisi ukuhleleka kwezinto ezehlisiwe.
/// I-oda lishintshile esikhathini esedlule futhi lingashintsha futhi.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Izindlela zemvelo
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Yakha i-`Vec<T>` entsha, engenalutho.
    ///
    /// I-vector ngeke yabele kuze kufakwe izinto kuyo.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Kwakha i-`Vec<T>` entsha, engenalutho nomthamo ocacisiwe.
    ///
    /// I-vector izokwazi ukubamba izakhi ze-`capacity` ngaphandle kokuphinda inikezwe.
    /// Uma i-`capacity` ingu-0, i-vector ngeke yabele.
    ///
    /// Kubalulekile ukuthi wazi ukuthi yize i-vector ebuyisiwe inamandla *acacisiwe, i-vector izoba no-zero* ubude *.
    ///
    /// Ukuthola incazelo ngomehluko phakathi kobude namandla, bona *[Amandla nokwabiwa kabusha]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // I-vector iqukethe izinto, noma inamandla wokuningi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Konke lokhu kwenziwa ngaphandle kokuphinda kubelwe indawo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kepha lokhu kungenza ukuthi i-vector iphinde isuswe
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Idala i-`Vec<T>` ngqo kusuka ezingxenyeni eziluhlaza zenye i-vector.
    ///
    /// # Safety
    ///
    /// Lokhu akuphephile kakhulu, ngenxa yenani labafakizicelo abangahloliwe:
    ///
    /// * `ptr` idinga ukwabiwa ngaphambilini nge-[`String`]/`Vec<T>`(okungenani, kungenzeka kakhulu ukuthi ayilungile uma bekungenjalo).
    /// * `T` idinga ukuba nosayizi nokuqondaniswa okufanayo nokuthi i `ptr` yabelwe ini.
    ///   (I-`T` enokuqondaniswa okuqinile kancane ayanele, ukuqondanisa kudinga ngempela ukulingana ukwanelisa isidingo se-[`dealloc`] sokuthi imemori kumele yabelwe futhi idluliselwe ngesakhiwo esifanayo.)
    ///
    /// * `length` idinga ukuba ngaphansi noma ilingane ne-`capacity`.
    /// * `capacity` idinga ukuba ngumthamo i-pointer eyabelwe ngawo.
    ///
    /// Ukwephula lokhu kungadala izinkinga ezifana nokonakalisa izakhiwo zedatha yangaphakathi yomhlinzeki.Isibonelo akuphephile ** ukwakha i-`Vec<u8>` kusuka kusikhombi kuya ku-C `char` array enobude `size_t`.
    /// Akuphephile nokwakha eyodwa kusuka ku-`Vec<u16>` nobude bayo, ngoba umhlinzeki ukhathalela ukuqondanisa, futhi lezi zinhlobo ezimbili zinokuqondaniswa okuhlukile.
    /// I-buffer yanikezwa ngokuqondanisa 2 (kwe-`u16`), kepha ngemuva kokuyiguqula ibe yi-`Vec<u8>` izodluliselwa ngokuqondanisa 1.
    ///
    /// Ubunikazi be `ptr` budluliselwa ngempumelelo kwi-`Vec<T>` engabe isabelana, isaba kabusha noma iguqule okuqukethwe kwememori ekhonjiswe yisikhombi ngentando.
    /// Qiniseka ukuthi akukho okunye okusebenzisa i-pointer ngemuva kokubiza lo msebenzi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Vuselela lokhu lapho i-vec_into_raw_parts izinzile.
    ///     // Vimbela ukubhujiswa kwe-`v` ngakho-ke silawula ngokuphelele isabelo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Khipha izingcezu zolwazi ezibalulekile ezahlukahlukene mayelana ne `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Bhala imemori nge-4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Beka konke ndawonye ku-Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Yakha i-`Vec<T, A>` entsha, engenalutho.
    ///
    /// I-vector ngeke yabele kuze kufakwe izinto kuyo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Kwakha i-`Vec<T, A>` entsha, engenalutho nomthamo ocacisiwe nomhlinzeki onikeziwe.
    ///
    /// I-vector izokwazi ukubamba izakhi ze-`capacity` ngaphandle kokuphinda inikezwe.
    /// Uma i-`capacity` ingu-0, i-vector ngeke yabele.
    ///
    /// Kubalulekile ukuthi wazi ukuthi yize i-vector ebuyisiwe inamandla *acacisiwe, i-vector izoba no-zero* ubude *.
    ///
    /// Ukuthola incazelo ngomehluko phakathi kobude namandla, bona *[Amandla nokwabiwa kabusha]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // I-vector iqukethe izinto, noma inamandla wokuningi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Konke lokhu kwenziwa ngaphandle kokuphinda kubelwe indawo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... kepha lokhu kungenza ukuthi i-vector iphinde isuswe
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Idala i-`Vec<T, A>` ngqo kusuka ezingxenyeni eziluhlaza zenye i-vector.
    ///
    /// # Safety
    ///
    /// Lokhu akuphephile kakhulu, ngenxa yenani labafakizicelo abangahloliwe:
    ///
    /// * `ptr` idinga ukwabiwa ngaphambilini nge-[`String`]/`Vec<T>`(okungenani, kungenzeka kakhulu ukuthi ayilungile uma bekungenjalo).
    /// * `T` idinga ukuba nosayizi nokuqondaniswa okufanayo nokuthi i `ptr` yabelwe ini.
    ///   (I-`T` enokuqondaniswa okuqinile kancane ayanele, ukuqondanisa kudinga ngempela ukulingana ukwanelisa isidingo se-[`dealloc`] sokuthi imemori kumele yabelwe futhi idluliselwe ngesakhiwo esifanayo.)
    ///
    /// * `length` idinga ukuba ngaphansi noma ilingane ne-`capacity`.
    /// * `capacity` idinga ukuba ngumthamo i-pointer eyabelwe ngawo.
    ///
    /// Ukwephula lokhu kungadala izinkinga ezifana nokonakalisa izakhiwo zedatha yangaphakathi yomhlinzeki.Isibonelo akuphephile ** ukwakha i-`Vec<u8>` kusuka kusikhombi kuya ku-C `char` array enobude `size_t`.
    /// Akuphephile nokwakha eyodwa kusuka ku-`Vec<u16>` nobude bayo, ngoba umhlinzeki ukhathalela ukuqondanisa, futhi lezi zinhlobo ezimbili zinokuqondaniswa okuhlukile.
    /// I-buffer yanikezwa ngokuqondanisa 2 (kwe-`u16`), kepha ngemuva kokuyiguqula ibe yi-`Vec<u8>` izodluliselwa ngokuqondanisa 1.
    ///
    /// Ubunikazi be `ptr` budluliselwa ngempumelelo kwi-`Vec<T>` engabe isabelana, isaba kabusha noma iguqule okuqukethwe kwememori ekhonjiswe yisikhombi ngentando.
    /// Qiniseka ukuthi akukho okunye okusebenzisa i-pointer ngemuva kokubiza lo msebenzi.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Vuselela lokhu lapho i-vec_into_raw_parts izinzile.
    ///     // Vimbela ukubhujiswa kwe-`v` ngakho-ke silawula ngokuphelele isabelo.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Khipha izingcezu zolwazi ezibalulekile ezahlukahlukene mayelana ne `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Bhala imemori nge-4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Beka konke ndawonye ku-Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Ibola i-`Vec<T>` ibe izingxenye zayo eziluhlaza.
    ///
    /// Ibuyisa isikhombisi esiluhlaza kudatha engaphansi, ubude be-vector (kuzinto), namandla abiwe emininingwane (kuzinto).
    /// Lezi yizimpikiswano ezifanayo ngokulandelana kwezimpikiswano eziya ku-[`from_raw_parts`].
    ///
    /// Ngemuva kokubiza lo msebenzi, ofonayo ubhekene nememori ephethwe yi-`Vec` ngaphambilini.
    /// Ukuphela kwendlela yokwenza lokhu ukuguqula i-pointer eluhlaza, ubude, nomthamo ubuyisele ku-`Vec` ngomsebenzi we-[`from_raw_parts`], uvumele umbhubhisi ukuthi enze ukuhlanza.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Manje sesingenza ushintsho kuzinto, njengokuhambisa isikhombisi esiluhlaza kuhlobo oluhambisanayo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Ibola i-`Vec<T>` ibe izingxenye zayo eziluhlaza.
    ///
    /// Ibuyisa isikhombisi esiluhlaza kudatha engaphansi, ubude be-vector (kuzinto), umthamo owabelwe wedatha (kuzinto), kanye nomabi.
    /// Lezi yizimpikiswano ezifanayo ngokulandelana kwezimpikiswano eziya ku-[`from_raw_parts_in`].
    ///
    /// Ngemuva kokubiza lo msebenzi, ofonayo ubhekene nememori ephethwe yi-`Vec` ngaphambilini.
    /// Ukuphela kwendlela yokwenza lokhu ukuguqula i-pointer eluhlaza, ubude, nomthamo ubuyisele ku-`Vec` ngomsebenzi we-[`from_raw_parts_in`], uvumele umbhubhisi ukuthi enze ukuhlanza.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Manje sesingenza ushintsho kuzinto, njengokuhambisa isikhombisi esiluhlaza kuhlobo oluhambisanayo.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Ibuyisa inani lezinto i-vector engazibamba ngaphandle kokuphinda ithunyelwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Igcina amandla okungenani ama-`additional` ezinto eziningi ezizofakwa ku-`Vec<T>` enikeziwe.
    /// Iqoqo lingagcina isikhala esithe xaxa ukugwema ukwabiwa kabusha okuvamile.
    /// Ngemuva kokushayela i-`reserve`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha wedlula ama-byte angu-`isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Igcina umthamo omncane wezinto ezingama-`additional` ngaphezulu ezizofakwa ku-`Vec<T>` enikeziwe.
    ///
    /// Ngemuva kokushayela i-`reserve_exact`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// Qaphela ukuthi umhlinzeki anganikeza iqoqo isikhala esengeziwe kunalokho elikucelayo.
    /// Ngakho-ke, umthamo awunakwethenjelwa kuwo ukuthi ube mncane ngokunembile.
    /// Khetha i-`reserve` uma kulindelwe ukufakwa kwe-future.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha uchichima i-`usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Izama ukugcina umthamo okungenani wezinto ezingama-`additional` eziningi ezizofakwa ku-`Vec<T>` enikeziwe.
    /// Iqoqo lingagcina isikhala esithe xaxa ukugwema ukwabiwa kabusha okuvamile.
    /// Ngemuva kokushayela i-`try_reserve`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional`.
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le i-OOM ayikwazi phakathi nomsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // kuyinkimbinkimbi kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Izama ukugcina umthamo omncane wezinto ezingama-`additional` ezizofakwa ku-`Vec<T>` enikeziwe.
    /// Ngemuva kokushayela i-`try_reserve_exact`, umthamo uzokuba mkhulu noma ulingane no-`self.len() + additional` uma ubuyisa i-`Ok(())`.
    ///
    /// Akenzi lutho uma umthamo usuvele wenele.
    ///
    /// Qaphela ukuthi umhlinzeki anganikeza iqoqo isikhala esengeziwe kunalokho elikucelayo.
    /// Ngakho-ke, umthamo awunakwethenjelwa kuwo ukuthi ube mncane ngokunembile.
    /// Khetha i-`reserve` uma kulindelwe ukufakwa kwe-future.
    ///
    /// # Errors
    ///
    /// Uma umthamo uchichima, noma umabi wabika ngokwehluleka, khona-ke iphutha liyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Gcina imemori kuqala, iphume uma singakwazi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Manje siyazi ukuthi le i-OOM ayikwazi phakathi nomsebenzi wethu onzima
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // kuyinkimbinkimbi kakhulu
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Yehlisa umthamo we-vector ngangokunokwenzeka.
    ///
    /// Izokwehla phansi ngokusondele ngangokunokwenzeka ebangeni kodwa isabelo singesazisa i-vector ukuthi kunesikhala sezinto ezimbalwa ezengeziwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Umthamo awusoze waba ngaphansi kobude, futhi akukho okumele ukwenze uma belingana, ngakho-ke singagwema icala le-panic ku-`RawVec::shrink_to_fit` ngokuyibiza ngomthamo omkhulu.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Yehlisa umthamo we-vector ngentambo ephansi.
    ///
    /// Umthamo uzohlala okungenani ukhulu njengokubili ubude nenani elinikeziwe.
    ///
    ///
    /// Uma umthamo wamanje ungaphansi komkhawulo ophansi, lena yi-no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Iguqula i-vector ibe yi-[`Box<[T]>`][owned slice].
    ///
    /// Qaphela ukuthi lokhu kuzokwehlisa noma imuphi umthamo okweqile.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Noma yimuphi umthamo ongaphezulu uyasuswa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Ifinyeza i-vector, igcina izinto zokuqala ze-`len` bese ilahla okusele.
    ///
    /// Uma i-`len` inkulu kunobude bamanje be-vector, lokhu akunamphumela.
    ///
    /// Indlela ye-[`drain`] ingalingisa i-`truncate`, kepha ibangela ukuthi izinto ezeqile zibuyiswe esikhundleni sokulahlwa.
    ///
    ///
    /// Qaphela ukuthi le ndlela ayinamthelela kumthamo owabiwe we-vector.
    ///
    /// # Examples
    ///
    /// Ukunciphisa into emihlanu u vector ezintweni ezimbili:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Akukho kuncipha okwenzeka lapho i-`len` inkulu kunobude bamanje be-vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Ukuncipha lapho i-`len == 0` ilingana nokubiza indlela ye-[`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Lokhu kuphephile ngoba:
        //
        // * isilayidi esidluliselwe ku-`drop_in_place` sisebenza;icala le-`len > self.len` ligwema ukudala ucezu olungavumelekile, futhi
        // * i `len` ye-vector inciphile ngaphambi kokushayela i-`drop_in_place`, ukuze kungabikho xabiso elizokwehliswa kabili uma kwenzeka i-`drop_in_place` iye ku-panic kanye (uma kungu-panics kabili, uhlelo luyayeka).
        //
        //
        //
        unsafe {
            // Note: Kuyinhloso ukuthi le yi `>` hhayi i `>=`.
            //       Ukuyishintshela ku-`>=` kunemithelela yokusebenza engemihle kwezinye izimo.
            //       Bona i #78884 ukuthola okuningi.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Ikhipha isilayidi esiqukethe yonke i vector.
    ///
    /// Ilingana ne-`&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ikhipha isilayidi esiguquguqukayo sayo yonke i vector.
    ///
    /// Ilingana ne-`&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Ibuyisa isikhombisi esiluhlaza kubhafa ye-vector.
    ///
    /// Oshaya ucingo kufanele aqinisekise ukuthi i-vector idlula isikhombi lapho lo msebenzi ubuya khona, uma kungenjalo izogcina ikhombe kudoti.
    /// Ukuguqula i-vector kungadala ukuthi i-buffer yayo iphinde ibekwe kabusha, okungenza noma yiziphi izikhombisi kuyo kungasebenzi.
    ///
    /// Oshayayo kufanele futhi aqinisekise ukuthi imemori isikhombisi esikhomba kuyo u (non-transitively) asikaze sibhalelwe yona (ngaphandle kwangaphakathi kwe `UnsafeCell`) kusetshenziswa lesi sikhombi noma yisiphi isikhombi esisuselwe kuso.
    /// Uma udinga ukushintsha okuqukethwe kocezu, sebenzisa i [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Sifaka indlela yocezu lwegama elifanayo ukugwema ukudlula ku-`deref`, edala ireferensi emaphakathi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ibuyisa isikhombisi esingaphepheki esingaguquleki kubhafa ye-vector.
    ///
    /// Oshaya ucingo kufanele aqinisekise ukuthi i-vector idlula isikhombi lapho lo msebenzi ubuya khona, uma kungenjalo izogcina ikhombe kudoti.
    ///
    /// Ukuguqula i-vector kungadala ukuthi i-buffer yayo iphinde ibekwe kabusha, okungenza noma yiziphi izikhombisi kuyo kungasebenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// // Nika i-vector enkulu ngokwanele ezintweni ezi-4.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Qalisa izinto nge-pointer eluhlaza kubhala, bese usetha ubude.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Sifaka indlela yocezu lwegama elifanayo ukugwema ukudlula ku-`deref_mut`, edala ireferensi emaphakathi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Ibuyisa ireferensi kusabelomali esingaphansi.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Iphoqa ubude be-vector kuye ku-`new_len`.
    ///
    /// Lokhu ukusebenza kwezinga eliphansi okungagcini okungenayo okuvamile kohlobo.
    /// Ngokujwayelekile ukushintsha ubude be-vector kwenziwa kusetshenziswa okukodwa kokusebenza okuphephile, njenge-[`truncate`], [`resize`], [`extend`], noma i-[`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` kufanele ibe ngaphansi noma ilingane no-[`capacity()`].
    /// - Izinto ezise `old_len..new_len` kufanele ziqaliswe.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Le ndlela ingaba wusizo ezimeni lapho i-vector isebenza njenge-buffer yenye ikhodi, ikakhulukazi ngaphezulu kwe-FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Lawa ngamathambo amancane nje wesibonelo sedokhumenti;
    /// # // ungasebenzisi lokhu njengesiqalo selabhulali yangempela.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Ngamadokhumenti endlela ye-FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // UKUPHEPHA: Lapho i-`deflateGetDictionary` ibuyisa i-`Z_OK`, iphethe ukuthi:
    ///     // 1. `dict_length` izinto zaqalwa.
    ///     // 2.
    ///     // `dict_length` <=umthamo (32_768) owenza i `set_len` iphephe ukuyishayela.
    ///     unsafe {
    ///         // Shaya ucingo lwe-FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... futhi ngivuselele ubude kokuqaliwe.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ngenkathi isibonelo esilandelayo sizwakala, kunokuvuza kwenkumbulo njengoba i vectors yangaphakathi ingakhululwanga ngaphambi kocingo lwe `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ayinalutho ngakho-ke azikho izinto ezidinga ukuqaliswa.
    /// // 2. `0 <= capacity` ihlala iphethe noma yini eyi-`capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Imvamisa, lapha, umuntu uzosebenzisa i [`clear`] esikhundleni sokulahla ngokufanele okuqukethwe ngakho-ke hhayi ukuvuza imemori.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Isusa into kusuka ku-vector bese iyibuyisela.
    ///
    /// Into ekhishiwe ithathelwe indawo yinto yokugcina ye-vector.
    ///
    /// Lokhu akugcini uku-oda, kepha kuyi-O(1).
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`index` ingaphandle kwemingcele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Simiselela i-self [index] ngento yokugcina.
            // Qaphela ukuthi uma ukuhlolwa kwemingcele ngenhla kuphumelela kufanele kube nento yokugcina (engaba yi-self [index] uqobo).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Ifaka i-elementi kusikhundla `index` ngaphakathi kwe-vector, ihambisa zonke izinto ngemuva kwayo ziye kwesokudla.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // isikhala sento entsha
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // ayinaphutha Indawo yokubeka inani elisha
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Shift konke ukuze wenze isikhala.
                // (Ukuphinda into ethi `index`th ezindaweni ezimbili ezilandelanayo.)
                ptr::copy(p, p.offset(1), len - index);
                // Yibhale, ubhale ngaphezulu ikhophi lokuqala lento `index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Isusa futhi ibuyise into kusikhundla `index` ngaphakathi kwe-vector, isuse zonke izinto ngemuva kwayo iye kwesobunxele.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`index` ingaphandle kwemingcele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // indawo esithatha kuyo.
                let ptr = self.as_mut_ptr().add(index);
                // ikopishe, ngokungaphephile ube nekhophi yenani kwisitaki naku vector ngasikhathi sinye.
                //
                ret = ptr::read(ptr);

                // Shift konke phansi ukugcwalisa leyo ndawo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Igcina kuphela izinto ezichazwe yisilandiso.
    ///
    /// Ngamanye amagama, susa zonke izinto `e` ngendlela yokuthi i `f(&e)` ibuyisa i `false`.
    /// Le ndlela isebenza endaweni, ivakashela into ngayinye ngqo kanye ngohlelo lwangempela, futhi igcina ukuhleleka kwezinto ezigciniwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ngoba izinto zivakashelwa kanye kanye ngokulandelana kwasekuqaleni, isimo sangaphandle singasetshenziswa ukunquma ukuthi iziphi izinto okufanele zigcinwe.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Gwema ukwehla okuphindwe kabili uma i-drop guard ingenziwa, ngoba singenza izimbobo ezithile ngesikhathi senqubo.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-kusetshenzwe len-> |^-eduze kokuhlola
        //                  | <-isuswe cnt-> |
        //      | <-original_len-> |Igcinwe: Izinto ezinesilandiso zibuyela ziyiqiniso ku.
        //
        // I-Hole: Ihanjiswe noma yehlisiwe i-elementi slot.
        // Akuhloliwe: Izakhi ezivumelekile ezingamakiwe.
        //
        // Lo unogada uzodonswa lapho isilandiso noma i-`drop` yento itatazekile.
        // Ishintsha izinto ezingamakiwe ukumboza izimbobo ne-`set_len` kubude obufanele.
        // Ezimweni lapho isimemezelo no-`drop` bengatatazeli, kuzothuthukiswa.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // UKUPHEPHA: Ukulandela ngomkhondo izinto ezingamakiwe kumele kuvumeleke ngoba asikaze sizithinte.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // UKUPHEPHA: Ngemuva kokugcwalisa izimbobo, zonke izinto zisememori ehlanganayo.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // UKUPHEPHA: Into engahloliwe kufanele isebenze.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Ngaphambi kwesikhathi kusengaphambili ukugwema ukwehla okuphindwe kabili uma i-`drop_in_place` itatazekile.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // UKUPHEPHA: Asiphinde siyithinte le nto ngemuva kokuwa.
                unsafe { ptr::drop_in_place(cur) };
                // Sivele sayithuthukisa ikhawunta.
                continue;
            }
            if g.deleted_cnt > 0 {
                // UKUPHEPHA: `deleted_cnt`> 0, ngakho-ke imbobo imbobo akumele ihlangane nento yamanje.
                // Sisebenzisa ikhophi ukunyakaza, futhi ungalokothi uthinte le nto futhi.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Yonke into iyacutshungulwa.Lokhu kungalungiselelwa ku-`set_len` yi-LLVM.
        drop(g);
    }

    /// Isusa konke ngaphandle kokuqala kwezinto ezilandelanayo ku-vector ezixazulula kukhiye ofanayo.
    ///
    ///
    /// Uma i-vector ihlelwa, lokhu kususa zonke izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Isusa konke ngaphandle kokuqala kwezinto ezilandelanayo ku-vector ezanelisa ubudlelwano bokulingana obunikeziwe.
    ///
    /// Umsebenzi we-`same_bucket` udluliselwe izinkomba kuzinto ezimbili ezivela ku-vector futhi kufanele unqume ukuthi ngabe izinto ziqhathanisa ukulingana.
    /// Izinto zidluliswa ngokulandelana okuphambene kusuka ku-oda lazo kusilayidi, ngakho-ke uma i-`same_bucket(a, b)` ibuyisa i-`true`, i-`a` iyasuswa.
    ///
    ///
    /// Uma i-vector ihlelwa, lokhu kususa zonke izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Faka into ngemuva kweqoqo.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha wedlula ama-byte angu-`isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Lokhu kuzoba yi-panic noma kukhiphe isisu uma sizokwabela ama-isize::MAX byte noma uma ukukhushulwa kobude kungachichima izinhlobo ezingosayizi.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Isusa into yokugcina ku-vector bese iyibuyisa, noma i-[`None`] uma ingenalutho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Ihambisa zonke izinto ze-`other` ziye ku-`Self`, ishiya i-`other` ingenalutho.
    ///
    /// # Panics
    ///
    /// I-Panics uma inani lezinto ku-vector ligcwala i-`usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Ifaka izinto ku-`Self` kusuka kwenye i-buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Kwakha i-iterator yokukhipha esusa ububanzi obucacisiwe ku-vector futhi iveze izinto ezisusiwe.
    ///
    /// Lapho i-iterator **is** yehlisiwe, zonke izinto ebangeni ziyasuswa ku-vector, noma ngabe i-iterator yayingasetshenziswanga ngokuphelele.
    /// Uma i-iterator ** ingadonswanga (nge-[`mem::forget`] ngokwesibonelo), akucacisiwe ukuthi zingaki izinto ezisusiwe.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala likhulu kunendawo yokugcina noma uma iphuzu lokugcina likhulu kunobude be-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Ububanzi obugcwele busula i-vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Ukuphepha kwememori
        //
        // Lapho i-Drain idalwa okokuqala, inciphisa ubude bomthombo i-vector ukuqinisekisa ukuthi azikho izinto ezingaqalisiwe noma ezisuswayo ezifinyeleleka nhlobo uma umchithi we-Drain engakaze asebenze.
        //
        //
        // I-Drain izokhipha amanani okuzosuswa u-ptr::read.
        // Lapho usuqedile, umsila osele we-vec ukopishwa ubuyiselwe ukumboza umgodi, futhi ubude be-vector bubuyiselwe kubude obusha.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // setha ubude be self.vec ukuqala, ukuze uphephe uma kwenzeka i Drain idaluliwe
            self.set_len(start);
            // Sebenzisa ukuboleka ku-IterMut ukukhombisa indlela oboleka ngayo yonke iterator ye Drain (njenge &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Isula i-vector, isusa wonke amanani.
    ///
    /// Qaphela ukuthi le ndlela ayinamthelela kumthamo owabiwe we-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Ibuyisa inani lezinto ku-vector, ebizwa nangokuthi yi-'length' yayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Ibuyisa i-`true` uma i-vector iqukethe izinto.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Uhlukanisa iqoqo kabili enkombeni enikeziwe.
    ///
    /// Ibuyisa i-vector esanda kwabiwa equkethe izinto kububanzi `[at, len)`.
    /// Ngemuva kocingo, i vector yoqobo izosala iqukethe izinto `[0, at)` ngomthamo wayo wangaphambili ungashintshiwe.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // i-vector entsha ingathatha i-buffer yangempela futhi igweme ikhophi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // I-`set_len` engaphephile bese ukopisha izinto ku-`other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Kukhulisa usayizi we-`Vec` endaweni ukuze i-`len` ilingane no-`new_len`.
    ///
    /// Uma i-`new_len` inkulu kune-`len`, i-`Vec` inwetshwa ngomehluko, lapho i-slot ngayinye eyengeziwe igcwaliswe ngomphumela wokubiza ukuvalwa kwe-`f`.
    ///
    /// Amanani wokubuyisa avela ku-`f` azogcina ku-`Vec` ngokulandelana akhiqizwe ngakho.
    ///
    /// Uma i-`new_len` ingaphansi kwe-`len`, i-`Vec` imane incishiswe.
    ///
    /// Le ndlela isebenzisa ukuvalwa ukudala amanani amasha kukho konke ukucindezela.Uma ungathanda i-[`Clone`] inani elinikeziwe, sebenzisa i-[`Vec::resize`].
    /// Uma ufuna ukusebenzisa i [`Default`] trait ukukhiqiza amanani, ungadlulisa i-[`Default::default`] njengengxabano yesibili.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Isebenzisa futhi ivuze i-`Vec`, ibuyisa ireferensi engaguquguquki kokuqukethwe, `&'a mut [T]`.
    /// Qaphela ukuthi uhlobo `T` kufanele luphile isikhathi sokuphila esikhethiwe i `'a`.
    /// Uma uhlobo lunezinkomba ezimile kuphela, noma lungekho nhlobo, khona-ke lokhu kungakhethwa ukuthi kube yi-`'static`.
    ///
    /// Lo msebenzi ufana nomsebenzi we-[`leak`][Box::leak] ku-[`Box`] ngaphandle kokuthi ayikho indlela yokuthola imemori evulekile.
    ///
    ///
    /// Lo msebenzi ulusizo kakhulu kudatha ephila ngokusalele kwempilo yohlelo.
    /// Ukulahla ireferensi ebuyisiwe kuzodala ukuvuza kwenkumbulo.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulula:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Ibuyisa umthamo osele we-vector njengocezu lwe-`MaybeUninit<T>`.
    ///
    /// Isilayidi esibuyisiwe singasetshenziswa ukugcwalisa i-vector ngemininingwane (isb
    /// ngokufunda kufayela) ngaphambi kokumaka idatha njengoba iqalisiwe kusetshenziswa indlela ye [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Nika i-vector enkulu ngokwanele ezintweni eziyi-10.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Gcwalisa izakhi zokuqala ezi-3.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Maka izinto zokuqala ezi-3 ze-vector njengeziqalisiwe.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Le ndlela ayifakwanga ngokuya nge-`split_at_spare_mut`, ukuvimbela ukungasebenzi kwezikhombi kubhafa.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Ibuyisa okuqukethwe kwe-vector njengocezu lwe-`T`, kanye nomthamo osele we-vector njengocezu lwe-`MaybeUninit<T>`.
    ///
    /// Isilayidi somthamo wesipele obuyisiwe singasetshenziswa ukugcwalisa i-vector ngemininingwane (isb. Ngokufunda kufayela) ngaphambi kokumaka idatha njengoba iqalisiwe kusetshenziswa indlela ye [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Qaphela ukuthi le yi-API esezingeni eliphansi, okufanele isetshenziswe ngokunakekela izinhloso zokusebenzisa kahle.
    /// Uma udinga ukufaka idatha ku-`Vec` ungasebenzisa i-[`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] noma i-[`resize_with`], ngokuya ngezidingo zakho ngqo.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Gcina isikhala esingeziwe esikhulu ngokwanele izinto eziyi-10.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Gcwalisa izakhi ezi-4 ezilandelayo.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Maka izinto ezi-4 ze-vector njengeziqalisiwe.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ayinakwa futhi ngakho ayikaze iguqulwe
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Ukuphepha: ukuguqulwa okubuyisiwe .2 (&mut usize) kuthathwa njengokufana nokushayela i `.set_len(_)`.
    ///
    /// Le ndlela isetshenziselwa ukufinyelela okuyingqayizivele kuzo zonke izingxenye ze-vec ngasikhathi sinye e `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` kuqinisekisiwe ukuthi kuzosebenza ezintweni ze-`len`
        // - `spare_ptr` ikhomba into eyodwa edlule i-buffer, ngakho-ke ayihambelani ne `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Kukhulisa usayizi we-`Vec` endaweni ukuze i-`len` ilingane no-`new_len`.
    ///
    /// Uma i-`new_len` inkulu kune-`len`, i-`Vec` inwetshwa ngomehluko, nge-slot ngayinye eyengeziwe egcwele i-`value`.
    ///
    /// Uma i-`new_len` ingaphansi kwe-`len`, i-`Vec` imane incishiswe.
    ///
    /// Le ndlela idinga i-`T` ukusebenzisa i-[`Clone`], ukuze ikwazi ukuhlanganisa inani elidlulisiwe.
    /// Uma udinga ukuguquguquka okwengeziwe (noma ufuna ukuthembela ku [`Default`] esikhundleni se [`Clone`]), sebenzisa i [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Ama-Clones futhi afaka zonke izinto kucezu lwe-`Vec`.
    ///
    /// Iterates phezu kwesilayidi `other`, ihlanganisa into ngayinye, bese iyifaka kule `Vec`.
    /// I-`other` vector idabuleke ngokulandelana.
    ///
    /// Qaphela ukuthi lo msebenzi uyefana ne-[`extend`] ngaphandle kokuthi ukhethekile ukusebenza ngezingcezu esikhundleni salokho.
    ///
    /// Uma futhi nini i-Rust ithola ubuchwepheshe lo msebenzi kungenzeka wehliswe (kepha usatholakala).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Ikopisha izinto ezisuka kububanzi be-`src` kuye ekugcineni kwe-vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` iqinisekisa ukuthi ububanzi obunikeziwe busebenza ekuzikhombeni ngokwakho
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Le khodi ihlanganisa i-`extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Nweba i-vector ngamanani we-`n`, usebenzisa i-generator enikeziwe.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Sebenzisa i-SetLenOnDrop ukusebenza ngokuzungeza i-bug lapho umhlanganisi engahle angaboni khona isitolo nge-`ptr` nge-self.set_len() ayi alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Bhala zonke izinto ngaphandle kweyokugcina
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Khulisa ubude kuzo zonke izinyathelo uma kwenzeka i-next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Singabhala into yokugcina ngqo ngaphandle kokuhlangana ngokungadingekile
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len isethwe ngumqaphi wokukala
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Isusa izinto eziphindaphindekayo ezilandelanayo ku-vector ngokuya nge-[`PartialEq`] trait ukuqaliswa.
    ///
    ///
    /// Uma i-vector ihlelwa, lokhu kususa zonke izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Izindlela zangaphakathi nemisebenzi
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` idinga ukuba yinkomba evumelekile
    /// - `self.capacity() - self.len()` kufanele kube yi-`>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len inyuswa kuphela ngemuva kokuqala izinto
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - abashayeli bezingcingo ukuthi i-src iyinkomba evumelekile
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - I-elementi iqaliswe nje nge-`MaybeUninit::write`, ngakho-ke kulungile ukukhulisa len
            // - len iyakhuphuka ngemuva kwento ngayinye ukuvimbela ukuvuza (bona ukukhishwa #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - amakholi wekholi ukuthi i-`src` iyinkomba evumelekile
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Zombili izikhombisi zenziwe ngezinkomba ezihlukile zesilayidi (`&mut [_]`) ngakho-ke zivumelekile futhi azidluli.
            //
            // - Izinto yilezi: Kopisha ngakho-ke kulungile ukuzikopisha, ngaphandle kokwenza noma yini ngamanani woqobo
            // - `count` ilingana nelen ye `source`, ngakho-ke umthombo uvumelekile ukufundwa kwe-`count`
            // - `.reserve(count)` iqinisekisa ukuthi i-`spare.len() >= count` ngakho-ke i-spare isebenza ku-`count` ebhalayo
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Izakhi ziqaliswe nje yi `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Ukusetshenziswa okujwayelekile kwe-trait kweVec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): nge cfg(test) indlela yemvelo ye `[T]::to_vec`, edingekayo kule ncazelo yendlela, ayitholakali.
    // Esikhundleni salokho sebenzisa umsebenzi we-`slice::to_vec` otholakala kuphela nge-cfg(test) NB bona imodyuli ye-slice::hack ku-slice.rs ukuthola eminye imininingwane
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // lahla noma yini engeke isulwe
        self.truncate(other.len());

        // self.len <= other.len ngenxa ye-truncate engenhla, ngakho-ke izingcezu lapha zihlala zingaphakathi kwemingcele.
        //
        let (init, tail) = other.split_at(self.len());

        // sebenzisa amanani aqukethwe allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Idala i-iterator eqothulayo, okungukuthi, eyodwa ekhipha inani ngalinye ku-vector (ukusuka ekuqaleni kuye ekugcineni).
    /// I-vector ayikwazi ukusetshenziswa ngemuva kokushayela lokhu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s inohlobo lwe-String, hhayi i-&String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf indlela ukusetshenziswa okuhlukile kwe-SpecFrom/SpecExtend okudlulisela kuyo lapho kungenakho okunye ukulungiselelwa okusebenzayo
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Lokhu kunjalo nge-iterator ejwayelekile.
        //
        // Lo msebenzi kufanele ulingane nokuziphatha okulandelayo:
        //
        //      wento eku-iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // I-NB ayikwazi ukugcwala ngoba bekuzodingeka ukuthi sabele isikhala sekheli
                self.set_len(len + 1);
            }
        }
    }

    /// Idala i-itlicator yokuphindisela engena esikhundleni sebanga elicacisiwe ku-vector nge-`replace_with` iterator enikeziwe bese iveza izinto ezisusiwe.
    ///
    /// `replace_with` Akudingeki ukuthi ilingane no-`range`.
    ///
    /// `range` isuswa noma ngabe i-iterator ingadliwanga kuze kube sekupheleni.
    ///
    /// Akucacisiwe ukuthi mangaki ama-elementi asuswe ku-vector uma inani le-`Splice` lidaluliwe.
    ///
    /// I-iterator yokufaka `replace_with` isetshenziswa kuphela lapho inani le-`Splice` lehla.
    ///
    /// Lokhu kulungile uma:
    ///
    /// * Umsila (izakhi ku-vector ngemuva kwe-`range`) awunalutho,
    /// * noma i-`replace_with` ikhiqiza izinto ezimbalwa noma ezilinganayo kunobude `bobubanzi`
    /// * noma isibopho esingezansi se `size_hint()` yayo sinembile.
    ///
    /// Ngaphandle kwalokho, i-vector yesikhashana iyabiwa futhi umsila uhanjiswa kabili.
    ///
    /// # Panics
    ///
    /// I-Panics uma iphoyinti lokuqala likhulu kunendawo yokugcina noma uma iphuzu lokugcina likhulu kunobude be-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Kwakha i-iterator esebenzisa ukuvalwa ukuthola ukuthi ngabe into ethile kufanele isuswe yini.
    ///
    /// Uma ukuvalwa kubuya kuyiqiniso, khona-ke into iyasuswa futhi ivezwe.
    /// Uma ukuvalwa kubuya kungamanga, into izohlala ku-vector futhi ngeke ivezwe yi-iterator.
    ///
    /// Sebenzisa le ndlela kulingana nekhodi elandelayo:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ikhodi yakho lapha
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Kepha i `drain_filter` kulula ukuyisebenzisa.
    /// `drain_filter` futhi isebenza kahle kakhulu, ngoba ingabuyisela emuva izinto zamalungu afanayo ngobuningi.
    ///
    /// Qaphela ukuthi i-`drain_filter` futhi ikuvumela ukuthi uguqule yonke into ekuvalweni kwesihlungi, noma ngabe ukhetha ukuyigcina noma uyisuse.
    ///
    ///
    /// # Examples
    ///
    /// Ukuhlukanisa uhlu oluningi ngokulingana nangobunzima, usebenzise isabelo sangempela:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Qaphela ukuthi singavuleki (ukukhulisa ukuvuza)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Nweba ukuqaliswa okukopisha izinto ngaphandle kwezinkomba ngaphambi kokuzicindezela ku-Vec.
///
/// Lokhu kuqaliswa kukhethekile kuma-slice iterators, lapho isebenzisa khona i-[`copy_from_slice`] ukufaka lonke ucezu ngasikhathi sinye.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Isebenzisa ukuqhathanisa kwe vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Isebenzisa uku-oda kwe-vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // sebenzisa i-drop ye-[T] sebenzisa isilayidi esiluhlaza ukubheka izinto ze-vector njengohlobo olubuthakathaka kunawo wonke oludingekayo;
            //
            // ingagwema imibuzo yokufaneleka ezimweni ezithile
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // I-RawVec isingatha ukuhanjiswa
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Idala i-`Vec<T>` engenalutho.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test kudonsela ku-libstd, okudala amaphutha lapha
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test kudonsela ku-libstd, okudala amaphutha lapha
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Ithola konke okuqukethwe kwe-`Vec<T>` njengamalungu afanayo, uma usayizi wayo ufana ncamashi nalowo wamalungu afanayo aceliwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Uma ubude bungafani, okokufaka kuyabuya ku-`Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Uma ukahle ngokuthola isiqalo se-`Vec<T>`, ungashayela i-[`.truncate(N)`](Vec::truncate) kuqala.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // UKUPHEPHA: I `.set_len(0)` ihlala izwakala.
        unsafe { vec.set_len(0) };

        // UKUPHEPHA: Isikhombi se-`Vec` sihlala siqondaniswe kahle, futhi
        // ukuqondaniswa kwamalungu afanayo okudingayo kuyafana nezinto.
        // Sabheka phambilini ukuthi sinezinto ezanele.
        // Izinto ngeke zehle kabili njengoba i `set_len` itshela i `Vec` ukuthi nayo ingazilahli.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}