use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Ubungcweti be-trait busetshenziselwa i-Vec::from_iter
///
/// ## Igrafu yokuthunyelwa:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Icala elijwayelekile lidlulisa i-vector iye emsebenzini oqoqeka ngokushesha ku-vector.
        // Singakufiphaza lokhu uma i-IntoIter ingakaqhubeki nhlobo.
        // Uma seyithuthukile Singaphinda sisebenzise imemori futhi sigudulele imininingwane ngaphambili.
        // Kepha senza lokho kuphela lapho i-Vec evelayo ibingeke ibe namandla amaningi angasetshenziswanga kunokuyidala ngokusebenzisa i-generic FromIterator ukuqaliswa.
        //
        // Lowo mkhawulo awudingeki ngokuphelele njengoba indlela yokuziphatha kwesabelo se-Vec kungachaziwe ngenhloso.
        // Kepha kuyindlela yokuzikhethela.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // kufanele idlulisele ku-spec_extend() ngoba i-extend() uqobo iyizithunywa ku-spec_from yama-Vec angenalutho
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Lokhu kusebenzisa i-`iterator.as_slice().to_vec()` ngoba i-spec_extend kufanele ithathe izinyathelo eziningi zokucabanga ngobude bokugcina + ubude futhi ngaleyo ndlela yenze umsebenzi omningi.
// `to_vec()` wabela ngqo inani elifanele futhi uligcwalise ngqo.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): nge cfg(test) indlela yemvelo ye `[T]::to_vec`, edingekayo kule ncazelo yendlela, ayitholakali.
    // Esikhundleni salokho sebenzisa umsebenzi we-`slice::to_vec` otholakala kuphela nge-cfg(test) NB bona imodyuli ye-slice::hack ku-slice.rs ukuthola eminye imininingwane
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}