use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Umaki wobuchwepheshe wokuqoqa ipayipi le-iterator ungene ku-Vec ngenkathi usebenzisa kabusha ukwabiwa komthombo, isb
/// isebenzisa ipayipi endaweni.
///
/// Umzali weSourceIter u trait uyadingeka ukuze umsebenzi owenza umsebenzi othile ufinyelele esabelweni esizosetshenziswa kabusha.
/// Kepha akwanele ukuthi ubuchwepheshe bube semthethweni.
/// Bona imingcele eyengeziwe ku-impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// I-std-yangaphakathi SourceIter/InPlaceIterable traits isetshenziswa kuphela ngamaketanga e-Adapter <Adapter<Adapter<IntoIter>>> (konke kungokwakwa-core/std).
// Imikhawulo eyengeziwe ekusetshenzisweni kwe-adaptha (ngaphesheya kwe `impl<I: Trait> Trait for Adapter<I>`) incike kuphela kwamanye ama-traits asevele amakwe njengokukhethekile i traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. umaka awuxhomekile esikhathini sokuphila sezinhlobo ezinikezwe ngumsebenzisi.Modulo umgodi weCopy, osuvele uncike kwezinye izinto ezimbalwa.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Izidingo ezingeziwe ezingakwazi ukuvezwa nge-trait bounds.Sithembele ku-const eval esikhundleni salokho:
        // a) awekho ama-ZST njengoba bekungeke kube khona isabelo sokuphinda usisebenzise futhi i-pointer arithmetic ibizoba ngu-panic b) umdlalo wesayizi njengoba kudingwa yinkontileka ka-Alloc c) ukuqondanisa kokuqondanisa njengoba kudingwa yinkontileka ka-Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ukubuyela emuva ekusebenzeni okujwayelekile
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // sebenzisa ukuzama kusukela lapho
        // - iveza amandla kangcono kuma-adaptha athile we-iterator
        // - ngokungafani nezindlela eziningi zangaphakathi ze-iteration, kuthatha kuphela i-&mut self
        // - Isivumela ukuthi sifake isikhombi sokubhala ngaphakathi kwaso bese siyibuyisa ekugcineni
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration iphumelele, ungalahli ikhanda
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // hlola ukuthi ngabe inkontileka yeSourceIter ibigcinwa njenge-caveat: uma bezingekho besingaze sifike kuleli qophelo
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // hlola inkontileka ye-InPlaceIterable.Lokhu kungenzeka kuphela uma i-iterator ithuthukise isikhombisi somthombo nhlobo.
        // Uma isebenzisa ukufinyelela okungamakiwe ngeTrustedRandomAccess lapho-ke isikhombisi somthombo sizohlala endaweni yaso yokuqala futhi asikwazi ukuyisebenzisa njengesethenjwa
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // lahla noma yimaphi amanani asele emsileni womthombo kepha uvimbele ukwehla kwesabelo uqobo lwaso uma i-IntoIter iphuma esikhaleni uma ukwehla kwe panics lapho-ke sibuye sivuze noma yiziphi izinto eziqoqelwe ku-dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // inkontileka ye-InPlaceIterable ayikwazi ukuqinisekiswa ngqo lapha ngoba i-try_fold inereferensi ekhethekile yesikhombi somthombo esingakwenza ukubheka ukuthi ngabe isesebangeni
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}