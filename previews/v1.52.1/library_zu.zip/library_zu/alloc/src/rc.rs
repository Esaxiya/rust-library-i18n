//! Izikhombi zokubala eziyinkomba eyodwa.I 'Rc' imele 'Inkomba
//! Counted'.
//!
//! Uhlobo lwe-[`Rc<T>`][`Rc`] luhlinzeka ngobunikazi okwabiwe benani lohlobo `T`, olunikezwe inqwaba.
//! Ukungenisa i-[`clone`][clone] ku-[`Rc`] kukhiqiza isikhombisi esisha esabelweni esifanayo kunqwaba.
//! Lapho isikhombi se-[`Rc`] sokugcina esabelweni esinikeziwe sonakala, inani eligcinwe kuleso sabelo (esivame ukubizwa nge-"inner value") nalo liyehla.
//!
//! Izinkomba ezabiwe ku-Rust azivumeli ukuguqulwa ngokuzenzakalela, futhi i-[`Rc`] ayiyona into ehlukile: awukwazi ukuthola ireferensi engaguquguquki entweni ethile ngaphakathi kwe [`Rc`].
//! Uma udinga ukuguquguquka, faka i-[`Cell`] noma i-[`RefCell`] ngaphakathi kwe-[`Rc`];bona i [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] isebenzisa ukubalwa kwesethenjwa okungeyona i-athomu.
//! Lokhu kusho ukuthi ngaphezulu kuncane kakhulu, kepha i-[`Rc`] ayikwazi ukuthunyelwa phakathi kwemicu, futhi ngenxa yalokho i-[`Rc`] ayisebenzisi i-[`Send`][send].
//! Njengomphumela, umhlanganisi we-Rust uzohlola *ngesikhathi sokuhlanganiswa* ongathumeli i-[`Rc`] s phakathi kwemicu.
//! Uma udinga imicu eminingi, ukubalwa kwesethenjwa kwe-athomu, sebenzisa i [`sync::Arc`][arc].
//!
//! Indlela ye [`downgrade`][downgrade] ingasetshenziselwa ukudala isikhombisi se-[`Weak`] esingesona esakho.
//! Isikhombi se-[`Weak`] singaba [`thuthukisa`][thuthukisa] d sibe yi-[`Rc`], kepha lokhu kuzobuyisa i-[`None`] uma inani eligcinwe kusabelo selivele lehlisiwe.
//! Ngamanye amagama, izikhombisi ze-`Weak` azigcini inani ngaphakathi kwesabelo liphila;noma kunjalo, bona *bagcina* isabelo (isitolo esisekelayo senani langaphakathi) siphila.
//!
//! Umjikelezo ophakathi kwezikhombi ze [`Rc`] awusoze wasuswa.
//! Ngalesi sizathu, i [`Weak`] isetshenziselwa ukwephula imijikelezo.
//! Isibonelo, isihlahla singaba nezikhombisi eziqinile ze-[`Rc`] kusuka kuma-node wabazali kuya ezinganeni, nezikhombisi ze-[`Weak`] ezisuka ezinganeni ezibuyela kubazali bazo.
//!
//! `Rc<T>` ukubhekisa ngokuzenzakalela ku-`T` (nge-[`Deref`] trait), ukuze ushayele izindlela zika-T` ngenani lohlobo [`Rc<T>`][`Rc`].
//! Ukugwema ukungqubuzana kwamagama nezindlela zika-T`, izindlela ze-[`Rc<T>`][`Rc`] uqobo ziyimisebenzi ehambisanayo, ebizwa ngokuthi kusetshenziswa i-[fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Ukusetshenziswa kwe-traits njenge-`Clone` kungabizwa futhi kusetshenziswa i-syntax efaneleke ngokuphelele.
//! Abanye abantu bakhetha ukusebenzisa i-syntax efaneleke ngokuphelele, kuyilapho abanye bekhetha ukusebenzisa indlela-yokubiza syntax.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Indlela yokubiza i-syntax
//! let rc2 = rc.clone();
//! // I-syntax efaneleke ngokuphelele
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ayisiyisi ireferensi ezenzakalelayo ku-`T`, ngoba inani langaphakathi kungenzeka ukuthi selivele lehlisiwe.
//!
//! # Izinkomba zokuhlanganisa
//!
//! Ukwakha ireferensi entsha ekunikezelweni okufanayo njengesikhombi esikhona sokubalwa kwesethenjwa kwenziwa kusetshenziswa i `Clone` trait esetshenziselwe i [`Rc<T>`][`Rc`] ne [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ama-syntaxes amabili ngezansi ayalingana.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a no-b bobabili bakhomba endaweni efanayo yememori njenge-foo.
//! ```
//!
//! I-syntax ye-`Rc::clone(&from)` yi-idiomatic kakhulu ngoba idlulisa ngokusobala incazelo yekhodi.
//! Esibonelweni esingenhla, le syntax yenza kube lula ukubona ukuthi le khodi idala ireferensi entsha kunokukopisha konke okuqukethwe yi-foo.
//!
//! # Examples
//!
//! Cabanga ngesimo lapho iqoqo `lamagajethi` liphethwe yi-`Owner` enikeziwe.
//! Sifuna ukukhomba `igajethi yethu ku-`Owner` yabo.Asikwazi ukwenza lokhu ngobunikazi obuhlukile, ngoba igajethi engaphezu kweyodwa ingaba ngeye-`Owner` efanayo.
//! [`Rc`] isivumela ukuthi sabelane nge-`Owner` phakathi kwama-`Gajethi` amaningi, futhi i-`Owner` ihlale yabelwe inqobo nje uma kukhona amaphuzu e-`Gadget` kuyo.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... eminye imikhakha
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... eminye imikhakha
//! }
//!
//! fn main() {
//!     // Dala i-`Owner` ebalwe yireferensi.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Dala `igajethi` ye-`gadget_owner`.
//!     // Ukuhlanganisa i-`Rc<Owner>` kusinikeza isikhombisi esisha kusabelo esifanayo se-`Owner`, sikhuphule isibalo sesethenjwa kwinqubo.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Lahla i-`gadget_owner` yethu yasendaweni eguquguqukayo.
//!     drop(gadget_owner);
//!
//!     // Ngaphandle kokulahla i-`gadget_owner`, sisakwazi ukuphrinta igama le-`Owner` yama-`Gadget`s.
//!     // Lokhu kungenxa yokuthi sishiye i-`Rc<Owner>` eyodwa kuphela, hhayi i-`Owner` ekhomba kuyo.
//!     // Inqobo nje uma kukhona okunye i-`Rc<Owner>` ekhomba kusabelo esifanayo se-`Owner`, izohlala ibukhoma.
//!     // Ukuqagela kwenkambu i-`gadget1.owner.name` kusebenza ngoba i-`Rc<Owner>` ibhekisa ngokuzenzakalela ku-`Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Ekupheleni komsebenzi, i-`gadget1` ne-`gadget2` ziyabhujiswa, futhi nazo izinkomba zokugcina ezibaliwe ze-`Owner` yethu.
//!     // IGadget Man manje nayo iyabhujiswa.
//!     //
//! }
//! ```
//!
//! Uma izidingo zethu zishintsha, futhi futhi sidinga ukukwazi ukweqa sisuka ku-`Owner` siye ku-`Gadget`, sizohlangabezana nezinkinga.
//! Isikhombi se [`Rc`] esisuka ku `Owner` kuye ku `Gadget` sethula umjikelezo.
//! Lokhu kusho ukuthi ukubalwa kwabo okuyizethenjwa akukwazi ukufika ku-0, futhi isabelo asisoze sabhujiswa:
//! ukuvuza kwenkumbulo.Ukuze uzungeze lokhu, singasebenzisa izikhombisi ze-[`Weak`].
//!
//! I-Rust empeleni ikwenza kube nzima ukukhiqiza le loop kwasekuqaleni.Ukuze ugcine unamanani amabili akhomba komunye nomunye, elinye lawo lidinga ukuguquguquka.
//! Lokhu kunzima ngoba i [`Rc`] iphoqelela ukuphepha kwememori ngokunikeza kuphela izinkomba ezabiwe zenani elisongelayo, futhi lokhu akuvumeli ukuguqulwa okuqondile.
//! Sidinga ukugoqa ingxenye yenani esifisa ukuyiguqula ku-[`RefCell`], enikezela *ukuguquguquka kwangaphakathi*: indlela yokufeza ukuguquguquka ngesethenjwa esabiwe.
//! [`RefCell`] iphoqelela imithetho ebolekayo ye-Rust ngesikhathi sokusebenza.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... eminye imikhakha
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... eminye imikhakha
//! }
//!
//! fn main() {
//!     // Dala i-`Owner` ebalwe yireferensi.
//!     // Qaphela ukuthi sibeke i-vector yomnikazi `we-Gadget`s ngaphakathi kwe-`RefCell` ukuze sikwazi ukuyiguqula ngesethenjwa esabiwe.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Dala `igajethi` ye-`gadget_owner`, njengakuqala.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Faka ama-Gadget ku-`Owner` yabo.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ukuboleka okunamandla kuphelela lapha.
//!     }
//!
//!     // Hlukanisa `amaGadget` ethu, uprinte imininingwane yawo.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` iyi-`Weak<Gadget>`.
//!         // Njengoba izikhombisi ze-`Weak` zingaqinisekisi ukuthi isabelo sisekhona, sidinga ukushayela i-`upgrade`, ebuyisa i-`Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Kulokhu siyazi ukuthi isabelo sisekhona, ngakho-ke simane sithi `unwrap` i-`Option`.
//!         // Kuhlelo oluyinkimbinkimbi, ungadinga ukuphatha ngomusa iphutha lomphumela we `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Ekupheleni komsebenzi, i-`gadget_owner`, i-`gadget1`, ne-`gadget2` ziyabhujiswa.
//!     // Manje azikho izikhombisi eziqinile ze-(`Rc`) kumagajethi, ngakho-ke ziyabhujiswa.
//!     // Lokhu zeroes ukubalwa kwesethenjwa kuGadget Man, ngakho-ke uyabhujiswa futhi.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Lokhu yi-repr(C) kuya ku-future-proof ngokumelene nokuhleleka kabusha kwensimu, okungaphazamisa i-[into|from]_raw() ephephile yezinhlobo zangaphakathi ezingadluliselwa.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Isikhombi sokubala sokubala esisodwa.I 'Rc' imele 'Inkomba
/// Counted'.
///
/// Bona i [module-level documentation](./index.html) ukuthola eminye imininingwane.
///
/// Izindlela zemvelo ze-`Rc` yonke iyimisebenzi ehambisanayo, okusho ukuthi kufanele uzibize njenge-eg, [`Rc::get_mut(&mut value)`][get_mut] esikhundleni se-`value.get_mut()`.
/// Lokhu kugwema ukungqubuzana nezindlela zohlobo lwangaphakathi i `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Lokhu kungavikeleki kulungile ngoba ngenkathi le Rc isaphila siqinisekisiwe ukuthi isikhombisi sangaphakathi sisebenza.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Yakha i `Rc<T>` entsha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Kukhona isikhombisi esibuthakathaka esiphelele esiphethwe yizo zonke izikhombi ezinamandla, okuqinisekisa ukuthi umbhubhisi obuthakathaka akalokothi akhulule ukwabiwa ngenkathi umonakalisi onamandla esebenza, noma ngabe isikhombisi esibuthakathaka sigcinwe ngaphakathi kwesinamandla.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Yakha i `Rc<T>` entsha isebenzisa ireferensi ebuthakathaka kuyo uqobo.
    /// Ukuzama ukuthuthukisa ireferensi ebuthakathaka ngaphambi kokuthi lo msebenzi ubuye kuzoholela kunani le-`None`.
    ///
    /// Kodwa-ke, ireferensi ebuthakathaka ingahlanganiswa ngokukhululekile futhi igcinwe ukuze isetshenziswe kamuva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... izinkambu eziningi
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Yakha okungaphakathi kusimo se "uninitialized" ngesethenjwa esisodwa esibuthakathaka.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Kubalulekile ukuthi singabunikeli ubunikazi besikhombi esibuthakathaka, noma kungenjalo imemori ingadedelwa ngesikhathi kubuya i `data_fn`.
        // Uma ngabe besifuna ngempela ukudlula ubunikazi, singazenzela isibonisi esibuthakathaka esengeziwe, kepha lokhu kungaholela ekuvuseleleni okungeziwe kusibalo sesethenjwa esibuthakathaka okungenzeka kungadingeki ngenye indlela.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Izinkomba eziqinile kufanele zihlangane zibe nesithenjwa esabiwe esabiwe, ngakho-ke ungasebenzisi umchithi wesithenjwa sethu sakudala esibuthakathaka.
        //
        mem::forget(weak);
        strong
    }

    /// Kwakhiwa i-`Rc` entsha enokuqukethwe okungakaqalwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kwakhiwa i-`Rc` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Kwakhiwa i `Rc<T>` entsha, kubuyisa iphutha uma isabelo sehluleka
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Kukhona isikhombisi esibuthakathaka esiphelele esiphethwe yizo zonke izikhombi ezinamandla, okuqinisekisa ukuthi umbhubhisi obuthakathaka akalokothi akhulule ukwabiwa ngenkathi umonakalisi onamandla esebenza, noma ngabe isikhombisi esibuthakathaka sigcinwe ngaphakathi kwesinamandla.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Kwakhiwa i-`Rc` entsha enokuqukethwe okungakaqalwa, kubuyisa iphutha uma isabelo sehluleka
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Kwakhiwa i-`Rc` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`, ibuyisa iphutha uma ukwabiwa kwehluleka
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Yakha i `Pin<Rc<T>>` entsha.
    /// Uma i-`T` ingasebenzisi i-`Unpin`, i-`value` izophinwa kwimemori futhi ingakwazi ukuhanjiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Ibuyisa inani elingaphakathi, uma i-`Rc` inesethenjwa esisodwa esiqinile.
    ///
    /// Ngaphandle kwalokho, i [`Err`] ibuyiselwa ne `Rc` efanayo edluliselwe kuyo.
    ///
    ///
    /// Lokhu kuzophumelela noma ngabe kukhona izinkomba ezivelele ezibuthakathaka.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopisha into equkethwe

                // Khombisa Ababuthakathaka ukuthi abakwazi ukukhuthazwa ngokunciphisa ukubalwa okuqinile, bese besusa isikhombisi se-"strong weak" esisobala ngenkathi futhi besingatha ukucabanga kokulahla ngokwenza ubuthakathaka mbumbulu.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Kwakha isilayidi esinezibaluli esinezinkomba ezinokuqukethwe okungakaqalwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Kwakhiwa ucezu olusha-olubalwa lwesithenjwa olunokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Iguqulela ku-`Rc<T>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukuso kofonayo ukuqinisekisa ukuthi inani langaphakathi lisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Iguqulela ku-`Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukuso kofonayo ukuqinisekisa ukuthi inani langaphakathi lisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Isebenzisa i-`Rc`, ibuyisa isikhombisi esigoqiwe.
    ///
    /// Ukugwema ukuvuza kwenkumbulo isikhombisi kufanele siguqulelwe ku-`Rc` kusetshenziswa i-[`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Inikezela ngesikhombi esiluhlaza kudatha.
    ///
    /// Izibalo azithinteki nganoma iyiphi indlela futhi i-`Rc` ayidliwe.
    /// Isikhombi sisebenza inqobo nje uma kukhona izibalo eziqinile ku-`Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // UKUPHEPHA: Lokhu akukwazi ukudlula ku-Deref::deref noma ku-Rc::inner ngoba
        // lokhu kuyadingeka ukugcina ukutholakala kwe-raw/mut njengokuthi isib
        // `get_mut` ingabhala ngesikhombi ngemuva kokuthi i-Rc itholakale nge `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Yakha i-`Rc<T>` kusuka kusikhombi esiluhlaza.
    ///
    /// Isikhombi esiluhlaza kufanele ngabe sasibuyiswe ngaphambilini ngocingo oluya ku-[`Rc<U>::into_raw`][into_raw] lapho i-`U` kumele ibe nosayizi nokuqondaniswa okufanayo ne-`T`.
    /// Lokhu kuyiqiniso elincane uma i-`U` iyi-`T`.
    /// Qaphela ukuthi uma i-`U` kungeyona i-`T` kepha inosayizi nokuqondaniswa okufanayo, lokhu ngokufana nokuhambisa izinkomba zezinhlobo ezahlukahlukene.
    /// Bona i [`mem::transmute`][transmute] ukuthola eminye imininingwane yokuthi imiphi imikhawulo esebenzayo kuleli cala.
    ///
    /// Umsebenzisi we `from_raw` kufanele aqiniseke ukuthi inani elithile le-`T` lehla kanye kuphela.
    ///
    /// Lo msebenzi awuphephile ngoba ukusetshenziswa okungafanele kungaholela ekuphepheni kwememori, noma ngabe i-`Rc<T>` ebuyisiwe ayitholakali.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Guqulela emuva ku-`Rc` ukuvimbela ukuvuza.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ezinye izingcingo eziya ku `Rc::from_raw(x_ptr)` zingahle zingaphephi kwimemori.
    /// }
    ///
    /// // Imemori yakhululwa lapho i `x` iphuma esikalini ngaphezulu, ngakho-ke i `x_ptr` manje ilenga!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Phindela emuva i-offset ukuze uthole i-RcBox yangempela.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Kwakha isikhombi esisha se [`Weak`] kulesi sabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Qiniseka ukuthi asidali Obuthakathaka obulenga
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ithola inani lezikhombisi ze-[`Weak`] kulesi sabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ithola inani lezikhombisi eziqinile ze-(`Rc`) kulesi sabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Ibuyisa i-`true` uma zingekho ezinye izikhombisi ze-`Rc` noma ze-[`Weak`] kulesi sabelo.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Ibuyisa ireferensi engaguquleka ku-`Rc` enikeziwe, uma zingekho ezinye izikhombisi ze-`Rc` noma ze-[`Weak`] kusabelo esifanayo.
    ///
    ///
    /// Ibuyisa i-[`None`] ngenye indlela, ngoba akuphephile ukuguqula inani elabiwe.
    ///
    /// Bona futhi i-[`make_mut`][make_mut], ezokwenza i-[`clone`][clone] inani elingaphakathi lapho kunezinye izikhombisi.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Ibuyisa ireferensi engaguquleka ku-`Rc` enikeziwe, ngaphandle kwesheke.
    ///
    /// Bona futhi i [`get_mut`], ephephile futhi eyenza amasheke afanele.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Noma iziphi ezinye izikhombisi ze-`Rc` noma ze-[`Weak`] ezabiwe ngokufanayo akumele zikhonjiswe esikhathini sokubolekwa okubuyisiwe.
    ///
    /// Lokhu kwenzeka kancane uma kungekho izikhombisi ezinjalo, ngokwesibonelo ngemuva nje kwe `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Siqaphele *ukungakhi* isethenjwa esifaka izinkambu ze-"count", ngoba lokhu kungangqubuzana nokufinyelela ekubalweni kwezethenjwa (isib.
        // nge-`Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Ibuyisa i-`true` uma ama-`Rc` amabili ekhomba kusabelo esifanayo (emthanjeni ofana ne-[`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Yenza ireferensi engaguquleka ku-`Rc` enikeziwe.
    ///
    /// Uma kukhona ezinye izikhombisi ze-`Rc` esabelweni esifanayo, i-`make_mut` izokwenza i-[`clone`] inani langaphakathi kusabelo esisha ukuqinisekisa ubunikazi obuhlukile.
    /// Lokhu kubizwa nangokuthi i-clone-on-write.
    ///
    /// Uma zingekho ezinye izikhombisi ze-`Rc` kulesi sabelo, izikhombisi ze-[`Weak`] kulesi sabelo zizohlukaniswa.
    ///
    /// Bona futhi i [`get_mut`], ezokwehluleka kunokuhlangana.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ngeke uhlanganise lutho
    /// let mut other_data = Rc::clone(&data);    // Ngeke ihlanganise idatha yangaphakathi
    /// *Rc::make_mut(&mut data) += 1;        // Idatha yangaphakathi yama-Clones
    /// *Rc::make_mut(&mut data) += 1;        // Ngeke uhlanganise lutho
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ngeke uhlanganise lutho
    ///
    /// // Manje i-`data` ne-`other_data` zikhomba ezabelweni ezahlukahlukene.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] izikhombisi zizohlukaniswa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Uthole ukuhlanganisa idatha, kukhona amanye ama-Rcs.
            // Nikeza inkumbulo kusengaphambili ukuvumela ukubhala inani elihlanganisiwe ngqo.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Ungavele untshontshe idatha, okusele ngu-Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Susa i-Ref enamandla-buthakathaka (asikho isidingo sokwenza Ubuthakathaka obungelona lapha-siyazi ukuthi Obunye Ubuthakathaka bungasihlanzela)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Lokhu kungavikeleki kulungile ngoba siqinisekisiwe ukuthi isikhombisi sibuyisiwe yisikhombisi *kuphela* esizobuyiselwa ku-T.
        // Ukubalwa kwethu okuyizethenjwa kuqinisekisiwe ukuthi kuzoba ngu-1 kuleli qophelo, futhi besidinga i-`Rc<T>` uqobo lwayo ukuthi ibe yi-`mut`, ngakho-ke sibuyisela okuwukuphela kwereferensi ekunikezelweni.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Ukuzama ukwehlisa i-`Rc<dyn Any>` ohlotsheni lukakhonkolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Kwabela i `RcBox<T>` enesikhala esanele senani langaphakathi elingalinganiselwe lapho inani linokuhlelwa okunikeziwe.
    ///
    /// Umsebenzi `mem_to_rcbox` ubizwa ngesikhombi sedatha futhi kufanele abuyisele isikhombisi (esingahle sibe namandla) se-`RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Bala isakhiwo usebenzisa ukwakheka kwenani elinikeziwe.
        // Phambilini, ukwakheka bekubalwa kusisho `&*(ptr as* const RcBox<T>)`, kepha lokhu kudale ireferensi engafanele (bona i #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Kwabela i `RcBox<T>` enesikhala esanele senani langaphakathi elingalinganisiwe lapho inani linokuhlelwa okunikeziwe, kubuyisa iphutha uma ukwabiwa kwehluleka.
    ///
    ///
    /// Umsebenzi `mem_to_rcbox` ubizwa ngesikhombi sedatha futhi kufanele abuyisele isikhombisi (esingahle sibe namandla) se-`RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Bala isakhiwo usebenzisa ukwakheka kwenani elinikeziwe.
        // Phambilini, ukwakheka bekubalwa kusisho `&*(ptr as* const RcBox<T>)`, kepha lokhu kudale ireferensi engafanele (bona i #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Nikezela ngesakhiwo.
        let ptr = allocate(layout)?;

        // Qalisa i-RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Kwabela i `RcBox<T>` enesikhala esanele senani langaphakathi elingalinganiselwe
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Nikezela i `RcBox<T>` usebenzisa inani elinikeziwe.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopisha inani njengamabhayithi
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Khulula isabelo ngaphandle kokulahla okuqukethwe kukho
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Kwabela i `RcBox<[T]>` ngobude obunikeziwe.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopisha izinto ezisuka kusilayidi ziye ku-Rc <\[T\]> esanda kwabiwa
    ///
    /// Akuphephile ngoba umuntu ofonayo kufanele athathe ubunikazi noma abophe i-`T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Yakha i-`Rc<[T]>` kusuka ku-iterator eyaziwa njengosayizi othile.
    ///
    /// Ukuziphatha akuchazeki uma usayizi ungalungile.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // I-Panic iyaqapha ngenkathi ihlanganisa izakhi ze-T.
        // Uma kwenzeka kuba ne-panic, izinto ezibhalwe ku-RcBox entsha zizokwehliswa, bese imemori ikhululwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Isikhombi sento yokuqala
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Konke kucacile.Khohlwa unogada ukuze ingayikhululi i-RcBox entsha.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ubungcweti be-trait busetshenziselwa i-`From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Iconsa i `Rc`.
    ///
    /// Lokhu kuzokwehlisa ukubalwa kwesethenjwa okuqinile.
    /// Uma ukubalwa kwesethenjwa okuqinile kufinyelela kuziro kuzona-ke ezinye izinkomba (uma zikhona) ezingama-[`Weak`], ngakho-ke thina si-`drop` inani langaphakathi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Akuphrinti lutho
    /// drop(foo2);   // Iphrinta i-"dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // chitha into equkethwe
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // susa isikhombisi se-"strong weak" esisobala manje njengoba sesikuchithile okuqukethwe.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Kwenza ukulingana kwesikhombi se `Rc`.
    ///
    /// Lokhu kudala esinye isikhombisi kusabelo esifanayo, kukhulisa ukubalwa kwesethenjwa okuqinile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Idala i-`Rc<T>` entsha, ngenani le-`Default` le-`T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack ukuvumela ukugxila ku-`Eq` noma i-`Eq` inendlela.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Lokhu sikwenza ngobuchwepheshe lapha, hhayi njengokusebenzisa okujwayelekile ku-`&T`, ngoba kungenjalo kungeza izindleko kukho konke ukuhlolwa kokulingana kuma-Ref.
/// Sicabanga ukuthi ama-Rc`s asetshenziselwa ukugcina amanani amakhulu, aphuza ukuhlangana, kepha futhi anzima ukubheka ukulingana, okwenza le ndleko ikhokhe kalula.
///
/// Kungenzeka futhi ukuthi ube nama-clone amabili we-`Rc`, akhomba kunani elifanayo, kunama-`&T`s amabili.
///
/// Lokhu singakwenza kuphela lapho i-`T: Eq` njenge-`PartialEq` ingahle ingafinyeleli ngamabomu.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Ukulingana kwama-`Rc`s amabili.
    ///
    /// Ama-`Rc`s amabili ayalingana uma amanani awo angaphakathi elingana, noma ngabe agcinwe ngokwabiwa okuhlukile.
    ///
    /// Uma i-`T` futhi isebenzisa i-`Eq` (okusho ukuguquguquka kokulingana), ama-`Rc`s amabili akhomba kusabelo esifanayo ahlala elingana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Ukungalingani kwama-`Rc`s amabili.
    ///
    /// Ama-`Rc`s amabili awalingani uma amanani abo angaphakathi engalingani.
    ///
    /// Uma i-`T` futhi isebenzisa i-`Eq` (okusho ukuguquguquka kokulingana), ama-`Rc`s amabili akhomba kusabelo esifanayo awalokothi angalingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Ukuqhathanisa okuncane kwama-`Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`partial_cmp()` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Ngaphansi kokuqhathaniswa kwama-`Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`<` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Okungaphansi noma okulingana nokuqhathaniswa kwama-`Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`<=` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Okukhulu kunokuqhathanisa kwama-`Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`>` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Okukhulu kunalokho noma okulingana' nokuqhathaniswa kwama-Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`>=` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Ukuqhathanisa ama-`Rc`s amabili.
    ///
    /// Laba bobabili baqhathaniswa ngokubiza i-`cmp()` kumanani abo angaphakathi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Nika ucezu olubalwe kusethenjwa bese ulugcwalisa ngokuhlanganisa izinto zika-``v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Nikezela ucezu lwentambo olubalwe ngesithenjwa bese ukopisha i-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Nikezela ucezu lwentambo olubalwe ngesithenjwa bese ukopisha i-`v` kuyo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Hambisa into ebhokisiwe kusabelo esisha, ukubalwa kwesethenjwa.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Nikezela ucezu olubalwe kusethenjwa bese uhambisa izinto `z 'kulo.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Vumela i-Vec ukuthi ikhulule inkumbulo yayo, kepha ingabhubhisi okuqukethwe kwayo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Kuthatha into ngayinye ku-`Iterator` bese kuyiqoqela ku-`Rc<[T]>`.
    ///
    /// # Izici zokusebenza
    ///
    /// ## Icala elijwayelekile
    ///
    /// Esimweni esejwayelekile, ukuqoqelwa ku-`Rc<[T]>` kwenziwa ngokuqoqa okokuqala ku-`Vec<T>`.Okusho ukuthi, lapho ubhala okulandelayo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// lokhu kuziphatha sengathi sibhale:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Isethi yokuqala yezabelo yenzeka lapha.
    ///     .into(); // Isabelo sesibili se `Rc<[T]>` senzeka lapha.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Lokhu kuzokwaba kaningi ngangokunokwenzeka ekwakheni i `Vec<T>` bese kuzokwabelwa kanye ukuguqula i `Vec<T>` ibe yi `Rc<[T]>`.
    ///
    ///
    /// ## Ama-Iterator wobude obaziwayo
    ///
    /// Lapho i-`Iterator` yakho isebenzisa i-`TrustedLen` futhi isayizi elifanele, kuzokwabiwa i-`Rc<[T]>` eyodwa.Ngokwesibonelo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Isabelo esisodwa nje senzeka lapha.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Ubungcweti be-trait busetshenziselwa ukuqoqelwa ku-`Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Lokhu kunjalo nge-`TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // UKUPHEPHA: Sidinga ukuqinisekisa ukuthi i-iterator inebude obuqondile futhi sinakho.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Buyela emuva ekusetshenzisweni okujwayelekile.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` inguqulo ye-[`Rc`] ephethe ireferensi okungeyona eyakho kusabelo esilawulwayo.Isabelo sifinyelelwa ngokubiza i-[`upgrade`] kusikhombi se-`Weak`, esibuyisa i [`Option`]``<` [`Rc`]`<T>>`.
///
/// Njengoba ireferensi ye-`Weak` ingabheki kubunikazi, ngeke ivikele inani eligcinwe esabelweni ukuthi lehliswe, futhi i-`Weak` uqobo alwenzi ziqinisekiso mayelana nenani elisekhona.
/// Ngakho-ke ingabuyisa i [`None`] lapho [`thuthukisa`] d.
/// Qaphela kepha ukuthi isethenjwa se-`Weak` * sivimbela ukwabiwa uqobo (isitolo esisekelayo) ekuhanjisweni.
///
/// Isikhombi se `Weak` siwusizo ekugcineni ireferensi yesikhashana esabelweni esilawulwa yi-[`Rc`] ngaphandle kokuvimbela inani laso langaphakathi ekubeni lehliswe.
/// Ibuye isetshenziselwe ukuvikela izinkomba eziyindilinga phakathi kwezikhombisi ze-[`Rc`], ngoba ukuba nezinkomba ezifanayo kungaze kuvumele ukuthi i [`Rc`] yehliswe.
/// Isibonelo, isihlahla singaba nezikhombisi eziqinile ze-[`Rc`] kusuka kuma-node wabazali kuya ezinganeni, nezikhombisi ze-`Weak` ezisuka ezinganeni ezibuyela kubazali bazo.
///
/// Indlela ejwayelekile yokuthola isikhombisi se-`Weak` ukubiza i [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Le yi-`NonNull` yokuvumela ukwengeza usayizi walolu hlobo kuma-enums, kepha akusona isikhombisi esivumelekile.
    //
    // `Weak::new` ibeka lokhu ku-`usize::MAX` ukuze ingadingi ukwaba isikhala enqwabeni.
    // Lokho akulona inani i-pointer yangempela eyoke ibe nalo ngoba i-RcBox inokuqondanisa okungenani okungu-2.
    // Lokhu kungenzeka kuphela lapho i-`T: Sized`;i-`T` engafakwanga usayizi ayikaze iphazamise.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Yakha i `Weak<T>` entsha, ngaphandle kokwaba noma iyiphi inkumbulo.
    /// Ukushayela i-[`upgrade`] kunani lokubuyisa kuhlala kunikeza i-[`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Uhlobo losizi ukuvumela ukufinyelela ekubalweni kwesethenjwa ngaphandle kokwenza noma ikuphi ukuqinisekiswa mayelana nenkambu yedatha.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Ibuyisa isikhombi esiluhlaza entweni engu-`T` ekhonjwe yile `Weak<T>`.
    ///
    /// Isikhombi sisebenza kuphela uma kunezinkomba ezithile eziqinile.
    /// I-pointer ingahle ilenge, ingalingani noma i-[`null`] ngenye indlela.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Zombili zikhomba entweni efanayo
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Okuqinile lapha kuyigcina iphila, ngakho-ke sisengakwazi ukufinyelela entweni.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Kepha hhayi okunye.
    /// // Singakwenza i-weak.as_ptr(), kepha ukufinyelela kusikhombi kungaholela ekuziphatheni okungachazwanga.
    /// // assert_eq! ("sawubona", akuphephile {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Uma isikhombi silenga, sibuyisela i-sentinel ngqo.
            // Leli akulona ikheli elilayishiwe elikhokhelwayo, ngoba ukulayishwa okungenani kuqondaniswe ne-RcBox (usize).
            ptr as *const T
        } else {
            // UKUPHEPHA: uma ngabe_ukulengiswa kubuya kungamanga, khona-ke isikhombisi asinakuphikwa.
            // Umthwalo okhokhelwayo ungahle wehlelwe kuleli qophelo, futhi kufanele sigcine imvelaphi, ngakho-ke sebenzisa ukukhohlisa kwesikhombi esiluhlaza.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Isebenzisa i-`Weak<T>` bese iyiguqula ibe yisikhombi esiluhlaza.
    ///
    /// Lokhu kuguqula isikhombisi esibuthakathaka sibe yisikhombi esiluhlaza, ngenkathi kugcinwa ubunikazi besethenjwa esisodwa esibuthakathaka (isibalo esibuthakathaka asiguqulwa yilokhu kusebenza).
    /// Ingabuyiselwa emuva ku-`Weak<T>` nge-[`from_raw`].
    ///
    /// Imikhawulo efanayo yokuthola okubhekiswe kusikhombi njengaku-[`as_ptr`] iyasebenza.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Iguqula isikhombisi esiluhlaza esidalwe ngaphambilini yi-[`into_raw`] sibuyele ku-`Weak<T>`.
    ///
    /// Lokhu kungasetshenziselwa ukuthola ireferensi eqinile (ngokushayela i-[`upgrade`] ngokuhamba kwesikhathi) noma ukusabalalisa isibalo esibuthakathaka ngokulahla i-`Weak<T>`.
    ///
    /// Kuthatha ubunikazi besethenjwa esisodwa esibuthakathaka (ngaphandle kwezikhombisi ezenziwe yi-[`new`], ngoba lezi azinazinto; indlela isasebenza kubo).
    ///
    /// # Safety
    ///
    /// Isikhombi kufanele ukuthi sivele ku-[`into_raw`] futhi kusamele sibe nesethenjwa saso esingaba namandla.
    ///
    /// Kuvunyelwe ukuthi ukubalwa okuqinile kube ngu-0 ngesikhathi sokubiza lokhu.
    /// Noma kunjalo, lokhu kuthatha ubunikazi besethenjwa esisodwa esibuthakathaka njengamanje esiboniswe njengesikhombi esiluhlaza (isibalo esibuthakathaka asiguqulwa yilokhu kusebenza) ngakho-ke kufanele sibhangqwe nekholi yangaphambilini eya ku-[`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Yehlisa isibalo sokugcina esibuthakathaka.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Bona i-Weak::as_ptr ngomongo wokuthi isikhombisi sokufaka sisuselwa kanjani.

        let ptr = if is_dangling(ptr as *mut T) {
            // Lokhu kubuthakathaka Obuthakathaka.
            ptr as *mut RcBox<T>
        } else {
            // Ngaphandle kwalokho, siqinisekisiwe ukuthi i-pointer ivela ku-Weond engabambeki.
            // UKUPHEPHA: i-data_offset iphephile ukuyishayela, njengoba i-ptr ikhomba i-T yangempela (engahle yehle) T.
            let offset = unsafe { data_offset(ptr) };
            // Ngakho-ke, sibuyisela emuva i-offset ukuthola i-RcBox yonke.
            // UKUPHEPHA: i-pointer isuselwe ku-Weak, ngakho-ke le offset iphephile.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // UKUPHEPHA: manje sesisitholile isikhombisi sokuqala esibuthakathaka, ngakho-ke singadala Ababuthakathaka.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Imizamo yokuthuthukisa i-`Weak` pointer iye ku-[`Rc`], ukubambezela ukwehla kwenani langaphakathi uma kuphumelele.
    ///
    ///
    /// Ibuyisa i-[`None`] uma inani langaphakathi selivele lehlisiwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Chitha zonke izikhombisi eziqinile.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ithola inani lezikhombisi eziqinile ze-(`Rc`) ezikhomba kulesi sabelo.
    ///
    /// Uma i-`self` yadalwa kusetshenziswa i-[`Weak::new`], lokhu kuzobuyisa u-0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ithola inani lezikhombisi ze-`Weak` ezikhomba kulesi sabelo.
    ///
    /// Uma kungekho izikhombi eziqinile ezisele, lokhu kuzobuyisa zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // khipha i-ptr ebuthakathaka ngokuphelele
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Ibuyisa i-`None` lapho i-pointer ilenga futhi ingekho i-`RcBox`, (okusho ukuthi, lapho le `Weak` idalwa yi-`Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Siqaphele ukuthi *singenzi* ireferensi emboza inkambu ye-"data", njengoba inkambu ingashintshwa ngasikhathi sinye (ngokwesibonelo, uma i-`Rc` yokugcina yehlisiwe, inkambu yedatha izobekwa endaweni).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Ibuyisa i-`true` uma omabili `Obuthakathaka bekhomba kusabelo esifanayo (esifana ne-[`ptr::eq`]), noma uma bobabili bengakhombisi kunoma yisiphi isabelo (ngoba badalwe nge-`Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Njengoba lokhu kuqhathanisa izikhombisi kusho ukuthi i-`Weak::new()` izolingana, noma ingakhombisi kunoma yisiphi isabelo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Ukuqhathanisa i `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Iconsa isikhombi se `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Akuphrinti lutho
    /// drop(foo);        // Iphrinta i-"dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // isibalo esibuthakathaka siqala ku-1, futhi sizoya kuziro kuphela uma zonke izikhombisi eziqinile sezinyamalele.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Kwenza ukufana kwesikhombi se-`Weak` esikhomba kusabelo esifanayo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Kwakhiwa i `Weak<T>` entsha, kwabiwa imemori ye `T` ngaphandle kokuyiqala.
    /// Ukushayela i-[`upgrade`] kunani lokubuyisa kuhlala kunikeza i-[`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Sihlole_ngeze lapha ukubhekana ne mem::forget ngokuphepha.Ngokuqondene
// uma wena mem::forget Rcs (noma Weaks), ukubalwa kabusha kungagcwala, bese ungakhulula isabelo ngenkathi ama-Rcs asele (noma Obuthakathaka) akhona.
//
// Sikhipha isisu ngoba lesi yisimo esonakele kangangoba asinandaba nokuthi kwenzekani-alukho uhlelo lwangempela okufanele luthole lokhu.
//
// Lokhu kufanele kube nekhanda elinganakwa ngoba awudingi empeleni ukukuhlanganisa lokhu ku-Rust sibonga ubunikazi kanye nama-semantics wokuhambisa.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Sifuna ukukhipha ukuchichima kunokuchithwa kwenani.
        // Isibalo sesethenjwa asisoze saba zero uma lokhu kubizwa;
        // noma kunjalo, sifaka isisu lapha ukusikisela i-LLVM ekusebenzeni okungaphuthelwe ngenye indlela.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Sifuna ukukhipha ukuchichima kunokuchithwa kwenani.
        // Isibalo sesethenjwa asisoze saba zero uma lokhu kubizwa;
        // noma kunjalo, sifaka isisu lapha ukusikisela i-LLVM ekusebenzeni okungaphuthelwe ngenye indlela.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Thola isaphulelo ngaphakathi kwe `RcBox` ngokulayishwa okukhokhelwa ngemuva kwesikhombi.
///
/// # Safety
///
/// Isikhombi kumele sikhombe (futhi sibe nemethadatha evumelekile) yesimo esivele sisebenza ngaphambilini se-T, kepha i-T ivunyelwe ukuthi yehliswe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Qondanisa inani elingasetshenzisiwe ekugcineni kwe-RcBox.
    // Ngoba i-RcBox iyi-repr(C), izohlala iyinkambu yokugcina kwimemori.
    // UKUPHEPHA: ngoba yizinhlobo ezingasetshenziswanga kuphela ezingaba yizicucu, izinto ze-trait,
    // nezinhlobo zangaphandle, imfuneko yokuphepha yokufaka okwamanje yanele ukwanelisa izidingo ze-align_of_val_raw;lena imininingwane yokuqalisa yolimi okungenzeka kungathenjelwa kuyo ngaphandle kwe-std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}