//! Uhlobo lwesikhombi lokwabiwa kwenqwaba.
//!
//! [`Box<T>`], okubizwa ngokungajwayelekile njenge-'box', inikeza indlela elula yokwabiwa kwenqwaba ku-Rust.Amabhokisi ahlinzeka ngobunikazi balesi sabelo, futhi alahle okuqukethwe kwawo lapho ephuma esikhaleni.Amabhokisi aqinisekisa nokuthi awabeki ngaphezu kwama-byte ayi-`isize::MAX`.
//!
//! # Examples
//!
//! Hambisa inani kusuka esitaki uye enqwabeni ngokwenza i-[`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Hambisa inani lisuke ku-[`Box`] libuyele kwisitaki ngo-[dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Ukwakha ukwakheka kwedatha okuphindayo:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Lokhu kuzophrinta `Cons (1, Cons(2, Nil))`.
//!
//! Izakhiwo eziphindaphindekayo kumele zishaywe ngamabhokisi, ngoba uma incazelo ye `Cons` ibukeka kanjena:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Kwakungeke kusebenze.Lokhu kungenxa yokuthi usayizi we-`List` uncike ekutheni zingaki izinto ezisohlwini, ngakho-ke asazi ukuthi ingakanani imemori okufanele siyabele i `Cons`.Ngokwethula i-[`Box<T>`], enosayizi ochaziwe, siyazi ukuthi i-`Cons` kumele ibe nkulu kangakanani.
//!
//! # Isakhiwo sememori
//!
//! Kumanani angenasayizi zero, i-[`Box`] izosebenzisa isabelo se-[`Global`] ekunikezelweni kwayo.Kuvumelekile ukuguqula zombili izindlela phakathi kwe-[`Box`] nesikhombi esiluhlaza esabiwe nomnikezeli we-[`Global`], ngenxa yokuthi i-[`Layout`] esetshenziswe nomhlinzeki ilungile ohlotsheni.
//!
//! Ngokuqondile, i-`value:*mut T` enikezwe isabelo se-[`Global`] nge-`Layout::for_value(&* value)` ingaguqulwa ibe ibhokisi elisebenzisa i-[`Box::<T>::from_raw(value)`].
//! Ngakolunye uhlangothi, imemori esekela i-`value:*mut T` etholwe ku-[`Box::<T>::into_raw`] ingahle idluliselwe kusetshenziswa isabelo se-[`Global`] nge-[`Layout::for_value(&* value)`].
//!
//! Ngamanani alingana no-zero, isikhombisi se-`Box` kusamele sibe yi-[valid] ukuze sifunde futhi sibhale futhi siqondaniswe ngokwanele.
//! Ikakhulu, ukuphonsa noma iliphi inani elihambisanayo elingaqondile zero ku-pointer eluhlaza kuveza isikhombisi esivumelekile, kepha isikhombi esikhomba kwimemori eyabiwe ngaphambilini yokuthi selokhu yakhululwa ayisebenzi.
//! Indlela enconyiwe yokwakha ibhokisi ku-ZST uma i-`Box::new` ingasetshenziswa ukusebenzisa i-[`ptr::NonNull::dangling`].
//!
//! Uma nje i-`T: Sized`, i-`Box<T>` iqinisekisiwe ukuthi izomelwa njengesikhombi esisodwa futhi ihambisana ne-ABI nezikhombi ze-C (isb. Uhlobo lwe-C `T*`).
//! Lokhu kusho ukuthi uma unemisebenzi yangaphandle ye-"C" Rust ezobizwa kusuka ku-C, ungachaza leyo misebenzi ye Rust usebenzisa izinhlobo ze-`Box<T>`, bese usebenzisa i-`T*` njengohlobo olufanayo ohlangothini luka-C.
//! Njengesibonelo, cabanga ngale nhloko engu-C ememezela imisebenzi eyenza futhi ichithe uhlobo oluthile lwenani le-`Foo`:
//!
//! ```c
//! /* C unhlokweni */
//!
//! /* Ibuyisa ubunikazi koshayayo */
//! struct Foo* foo_new(void);
//!
//! /* Kuthatha ubunikazi koshayayo;akukho-op lapho icelwa nge-NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Le misebenzi emibili ingaqaliswa ku-Rust ngokulandelayo.Lapha, uhlobo lwe `struct Foo*` olusuka ku-C luhunyushelwa ku-`Box<Foo>`, olubamba izingqinamba zobunikazi.
//! Qaphela futhi ukuthi impikiswano engenakususwa ku-`foo_delete` imelwe ku-Rust njenge-`Option<Box<Foo>>`, ngoba i-`Box<Foo>` ayinakuba yize.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Noma i `Box<T>` inokumelwa okufanayo ne-C ABI njengesikhombi se-C, lokhu akusho ukuthi ungaguqula i-`T*` ngokungqubuzanayo ibe yi-`Box<T>` futhi ulindele ukuthi izinto zisebenze.
//! `Box<T>` amanani azohlala aqondaniswe ngokuphelele, izikhombisi ezingezona ezingasebenzi.Ngaphezu kwalokho, umbhubhisi we `Box<T>` uzozama ukukhulula inani ngesabi somhlaba jikelele.Ngokuvamile, umkhuba omuhle kakhulu ukusebenzisa kuphela i-`Box<T>` kwizikhombisi ezivela kumabi womhlaba jikelele.
//!
//! **Okubalulekile.** Okungenani okwamanje, kufanele ugweme ukusebenzisa izinhlobo ze-`Box<T>` ngemisebenzi echazwe ku-C kepha icelwe ku-Rust.Kulezo zimo, kufanele uzibhekise ngqo izinhlobo ze-C ngokushesha ngangokunokwenzeka.
//! Kusetshenziswa izinhlobo ezinjenge-`Box<T>` lapho incazelo C isebenzisa nje i-`T*` kungaholela ekuziphatheni okungachazwanga, njengoba kuchaziwe ku-[rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Uhlobo lwesikhombi lokwabiwa kwenqwaba.
///
/// Bona i [module-level documentation](../../std/boxed/index.html) ukuthola okuningi.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Kwabela inkumbulo enqwabeni bese ifaka i `x` kuyo.
    ///
    /// Lokhu empeleni akukwabeli uma i-`T` ilingana no-zero.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Kwakha ibhokisi elisha elinokuqukethwe okungakaqalwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Kwakhiwa i-`Box` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Yakha i `Pin<Box<T>>` entsha.
    /// Uma i-`T` ingasebenzisi i-`Unpin`, i-`x` izophinwa kwimemori futhi ingakwazi ukuhanjiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Kwabela inkumbulo enqwabeni bese ibeka i `x` kuyo, ibuyisa iphutha uma isabelo sehluleka
    ///
    ///
    /// Lokhu empeleni akukwabeli uma i-`T` ilingana no-zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Kwakhiwa ibhokisi elisha elinokuqukethwe okungakaqalwa kunqwaba, kubuyisa iphutha uma ukwabiwa kwehluleka
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Kwakhiwa i `Box` entsha enokuqukethwe okungafakwanga, imemori igcwaliswa ngamabhayithi we `0` kunqwaba
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Kwabela inkumbulo kusabelomali esinikeziwe bese ibeka i-`x` kuyo.
    ///
    /// Lokhu empeleni akukwabeli uma i-`T` ilingana no-zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Kwabela inkumbulo kusabelomali esinikeziwe bese ifaka i-`x` kuyo, ibuyisa iphutha uma isabelo sehluleka
    ///
    ///
    /// Lokhu empeleni akukwabeli uma i-`T` ilingana no-zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Kwakha ibhokisi elisha elinokuqukethwe okungavulwanga kusabelomali esinikeziwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Uncamela ukufanisa ngaphezu kwe-unwrap_or_else ngoba ukuvalwa kwesinye isikhathi akunakulungiswa.
        // Lokho kungenza usayizi wekhodi ube mkhulu.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Kwakhiwa ibhokisi elisha elinokuqukethwe okungakaqalwa kusabelomali esinikeziwe, kubuyisa iphutha uma ukwabiwa kwehluleka
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Kwakhiwa i-`Box` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0` kusabiwo esinikeziwe.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Uncamela ukufanisa ngaphezu kwe-unwrap_or_else ngoba ukuvalwa kwesinye isikhathi akunakulungiswa.
        // Lokho kungenza usayizi wekhodi ube mkhulu.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Kwakhiwa i-`Box` entsha enokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we-`0` kusabelomali esinikeziwe, ibuyisa iphutha uma ukwabiwa kwehluleka,
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Yakha i `Pin<Box<T, A>>` entsha.
    /// Uma i-`T` ingasebenzisi i-`Unpin`, i-`x` izophinwa kwimemori futhi ingakwazi ukuhanjiswa.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Iguqula i-`Box<T>` ibe yi-`Box<[T]>`
    ///
    /// Lokhu kuguqulwa akwabeki enqwabeni futhi kwenzeka endaweni.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Isebenzisa i-`Box`, ibuyisa inani eligoqiwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Kwakha ucezu olusha lwebhokisi olunokuqukethwe okungakaqalwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Kwakhiwa ucezu olusha lwebhokisi olunokuqukethwe okungakaqalwa, imemori igcwaliswa ngamabhayithi we `0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Kwakha ucezu olusha lwebhokisi olunokuqukethwe okungakaqalwa kusabelomali esinikeziwe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Kwakhiwa ucezu olusha lwebhokisi olunokuqukethwe okungafakwanga kusabelomali esinikeziwe, inkumbulo igcwaliswa ngamabhayithi we-`0`.
    ///
    ///
    /// Bona i [`MaybeUninit::zeroed`][zeroed] ngezibonelo zokusetshenziswa okulungile nokungalungile kwale ndlela.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Iguqulela ku-`Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukumuntu ofonayo ukuqinisekisa ukuthi inani lisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Iguqulela ku-`Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Njengaku-[`MaybeUninit::assume_init`], kukuso koshayayo ukuqinisekisa ukuthi amanani asesimweni sokuqalisa ngempela.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ukuqalisa okuhlehlisiwe:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Yakha ibhokisi kusuka kusikhombi esiluhlaza.
    ///
    /// Ngemuva kokubiza lo msebenzi, i-pointer eluhlaza iphethwe yi-`Box` evelayo.
    /// Ngokuqondile, umonakalisi we `Box` uzobiza umbhubhisi we `T` futhi akhulule imemori eyabiwe.
    /// Ukuze lokhu kuphephe, imemori kumele yabelwe ngokuya nge [memory layout] esetshenziswa yi `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba ukusetshenziswa okungafanele kungaholela ezinkingeni zememori.
    /// Isibonelo, i-double-free ingenzeka uma umsebenzi ubizwa kabili kusikhombi esifanayo esiluhlaza.
    ///
    /// Izimo zokuphepha zichazwe esigabeni [memory layout].
    ///
    /// # Examples
    ///
    /// Dala kabusha i-`Box` eyayiguqulwe ngaphambili yaba yisikhombi esiluhlaza kusetshenziswa i-[`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Ngesandla dala i `Box` kusuka ekuqaleni usebenzisa isabelo sembulunga yonke:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Ngokuvamile i-.write iyadingeka ukugwema ukuzama ukonakalisa okuqukethwe kwe-(uninitialized) kwangaphambilini kwe-`ptr`, yize kulesi sibonelo esilula i-`*ptr = 5` nayo ibizosebenza.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Yakha ibhokisi kusuka kusikhombi esiluhlaza kusabelomali esinikeziwe.
    ///
    /// Ngemuva kokubiza lo msebenzi, i-pointer eluhlaza iphethwe yi-`Box` evelayo.
    /// Ngokuqondile, umonakalisi we `Box` uzobiza umbhubhisi we `T` futhi akhulule imemori eyabiwe.
    /// Ukuze lokhu kuphephe, imemori kumele yabelwe ngokuya nge [memory layout] esetshenziswa yi `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba ukusetshenziswa okungafanele kungaholela ezinkingeni zememori.
    /// Isibonelo, i-double-free ingenzeka uma umsebenzi ubizwa kabili kusikhombi esifanayo esiluhlaza.
    ///
    /// # Examples
    ///
    /// Dala kabusha i-`Box` eyayiguqulwe ngaphambili yaba yisikhombi esiluhlaza kusetshenziswa i-[`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Ngesandla dala i `Box` kusuka ekuqaleni ngokusebenzisa isabelo sohlelo:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Ngokuvamile i-.write iyadingeka ukugwema ukuzama ukonakalisa okuqukethwe kwe-(uninitialized) kwangaphambilini kwe-`ptr`, yize kulesi sibonelo esilula i-`*ptr = 5` nayo ibizosebenza.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Isebenzisa i-`Box`, ibuyisa isikhombisi esiluhlaza esigoqiwe.
    ///
    /// Isikhombi sizoqondiswa kahle futhi singasebenzi.
    ///
    /// Ngemuva kokubiza lo msebenzi, ofonayo ubhekene nememori ephethwe yi-`Box` ngaphambilini.
    /// Ikakhulu, ofonayo kufanele abhubhise kahle i-`T` futhi adedele imemori, ecabangela i-[memory layout] esetshenziswa yi-`Box`.
    /// Indlela elula yokwenza lokhu ukuguqula i-pointer eluhlaza ibuyisele ku-`Box` ngomsebenzi we-[`Box::from_raw`], uvumele umchithi we-`Box` ukuthi enze ukuhlanza.
    ///
    ///
    /// Note: lo ngumsebenzi ohambisanayo, okusho ukuthi kufanele uwubize njengo-`Box::into_raw(b)` esikhundleni se-`b.into_raw()`.
    /// Lokhu kwenzelwa ukuthi kungangqubuzani nendlela ethile ohlobo lwangaphakathi.
    ///
    /// # Examples
    /// Ukuguqula i-pointer eluhlaza ibuyisele ku-`Box` nge-[`Box::from_raw`] yokuhlanza okuzenzakalelayo:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Ukuhlanzwa okwenziwa ngesandla ngokwenza ngokusobala umbhubhisi nokususa imemori:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Isebenzisa i-`Box`, ibuyisa isikhombisi esiluhlaza esigoqiwe kanye nomabi.
    ///
    /// Isikhombi sizoqondiswa kahle futhi singasebenzi.
    ///
    /// Ngemuva kokubiza lo msebenzi, ofonayo ubhekene nememori ephethwe yi-`Box` ngaphambilini.
    /// Ikakhulu, ofonayo kufanele abhubhise kahle i-`T` futhi adedele imemori, ecabangela i-[memory layout] esetshenziswa yi-`Box`.
    /// Indlela elula yokwenza lokhu ukuguqula i-pointer eluhlaza ibuyisele ku-`Box` ngomsebenzi we-[`Box::from_raw_in`], uvumele umchithi we-`Box` ukuthi enze ukuhlanza.
    ///
    ///
    /// Note: lo ngumsebenzi ohambisanayo, okusho ukuthi kufanele uwubize njengo-`Box::into_raw_with_allocator(b)` esikhundleni se-`b.into_raw_with_allocator()`.
    /// Lokhu kwenzelwa ukuthi kungangqubuzani nendlela ethile ohlobo lwangaphakathi.
    ///
    /// # Examples
    /// Ukuguqula i-pointer eluhlaza ibuyisele ku-`Box` nge-[`Box::from_raw_in`] yokuhlanza okuzenzakalelayo:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Ukuhlanzwa okwenziwa ngesandla ngokwenza ngokusobala umbhubhisi nokususa imemori:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Ibhokisi libonwa njenge-"unique pointer" ngabakwa-Stacked Borrows, kepha ngaphakathi liyisikhombi esiluhlaza sohlelo lohlobo.
        // Ukuyiguqula ngqo kusikhombi esiluhlaza bekungeke kubonakale njenge-"releasing" isikhombisi esihlukile sokuvumela ukufinyelela okuluhlaza okungafani, ngakho-ke zonke izindlela zesikhombi esiluhlaza kufanele zidlule ku-`Box::leak`.
        //
        // Ukuguqula * lokho kuya kusikhombi esiluhlaza kuziphatha kahle.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Ibuyisa ireferensi kusabelomali esingaphansi.
    ///
    /// Note: lo ngumsebenzi ohambisanayo, okusho ukuthi kufanele uwubize njengo-`Box::allocator(&b)` esikhundleni se-`b.allocator()`.
    /// Lokhu kwenzelwa ukuthi kungangqubuzani nendlela ethile ohlobo lwangaphakathi.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Isebenzisa futhi ivuze i-`Box`, ibuyisa ireferensi engaguquguqukayo, `&'a mut T`.
    /// Qaphela ukuthi uhlobo `T` kufanele luphile isikhathi sokuphila esikhethiwe i `'a`.
    /// Uma uhlobo lunezinkomba ezimile kuphela, noma lungekho nhlobo, khona-ke lokhu kungakhethwa ukuthi kube yi-`'static`.
    ///
    /// Lo msebenzi ulusizo kakhulu kudatha ephila ngokusalele kwempilo yohlelo.
    /// Ukulahla ireferensi ebuyisiwe kuzodala ukuvuza kwenkumbulo.
    /// Uma lokhu kungamukeleki, ireferensi kufanele igoqwe kuqala ngomsebenzi we-[`Box::from_raw`] okhiqiza i-`Box`.
    ///
    /// Le `Box` ingahle yehliswe ezokonakalisa kahle i-`T` futhi ikhulule imemori eyabiwe.
    ///
    /// Note: lo ngumsebenzi ohambisanayo, okusho ukuthi kufanele uwubize njengo-`Box::leak(b)` esikhundleni se-`b.leak()`.
    /// Lokhu kwenzelwa ukuthi kungangqubuzani nendlela ethile ohlobo lwangaphakathi.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulula:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Idatha engalinganiselwe:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Iguqula i-`Box<T>` ibe yi-`Pin<Box<T>>`
    ///
    /// Lokhu kuguqulwa akwabeki enqwabeni futhi kwenzeka endaweni.
    ///
    /// Lokhu kuyatholakala nge [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Akunakwenzeka ukuhambisa noma ukubuyisela okungaphakathi kwe-`Pin<Box<T>>` lapho i-`T: !Unpin`, ngakho-ke kuphephile ukuyiphina ngqo ngaphandle kwezidingo ezingeziwe.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ungenzi lutho, ukulahla okwamanje kwenziwa ngumhlanganisi.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Idala i-`Box<T>`, ngenani le-`Default` le-T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Ibuyisa ibhokisi elisha eline-`clone()` yokuqukethwe kwaleli bhokisi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Inani liyafana
    /// assert_eq!(x, y);
    ///
    /// // Kepha ziyizinto ezihlukile
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Nikeza inkumbulo kusengaphambili ukuvumela ukubhala inani elihlanganisiwe ngqo.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Amakhophi okuqukethwe komthombo ku-`self` ngaphandle kokudala isabelo esisha.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Inani liyafana
    /// assert_eq!(x, y);
    ///
    /// // Futhi akukho sabelo esenzekile
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // lokhu kwenza ikhophi ledatha
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Iguqula uhlobo olujwayelekile i-`T` ibe yi-`Box<T>`
    ///
    /// Ukuguqulwa kwabiwa enqwabeni bese kususa i-`t` kusuka esitaki kuye.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Iguqula i-`Box<T>` ibe yi-`Pin<Box<T>>`
    ///
    /// Lokhu kuguqulwa akwabeki enqwabeni futhi kwenzeka endaweni.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Iguqula i-`&[T]` ibe yi-`Box<[T]>`
    ///
    /// Lokhu kuguqulwa kwabiwa enqwabeni futhi kwenza ikhophi le-`slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // dala i-&[u8] ezosetshenziselwa ukudala i-Box <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Iguqula i-`&str` ibe yi-`Box<str>`
    ///
    /// Lokhu kuguqulwa kwabiwa enqwabeni futhi kwenza ikhophi le-`s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Iguqula i-`Box<str>` ibe yi-`Box<[u8]>`
    /// Lokhu kuguqulwa akwabeki enqwabeni futhi kwenzeka endaweni.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // dala ibhokisi<str>ezosetshenziselwa ukudala Ibhokisi <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // dala i-&[u8] ezosetshenziselwa ukudala i-Box <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Iguqula i-`[T; N]` ibe yi-`Box<[T]>`
    /// Lokhu kuguqulwa kuhambisa uhlu kumemori esanda kunikwa inqwaba.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Ukuzama ukwehlisa ibhokisi ngohlobo lukakhonkolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Ukuzama ukwehlisa ibhokisi ngohlobo lukakhonkolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Ukuzama ukwehlisa ibhokisi ngohlobo lukakhonkolo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Akunakwenzeka ukukhipha i-Uniq yangaphakathi ngqo kwiBhokisi, esikhundleni salokho siyiphonsa ku-const * ehlukanisa i-Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Ubungcweti bobukhulu obulinganiselwe obusebenzisa ukuqaliswa kwe-`last()` esikhundleni se-default.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}