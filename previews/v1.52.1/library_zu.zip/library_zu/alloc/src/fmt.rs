//! Izinsiza zokufometha nokuphrinta `String`s.
//!
//! Le mojula iqukethe ukusekelwa kwesikhathi sokusebenza kwesandiso se-[`format!`] syntax.
//! Le macro isetshenziswa kumhlanganisi ukukhipha izingcingo kule module ukuze kufomethwe izimpikiswano ngesikhathi sokuqalisa zibe izintambo.
//!
//! # Usage
//!
//! I-[`format!`] macro ihloselwe ukujwayela labo abavela emisebenzini ye-C's `printf`/`fprintf` noma ku-Python's `str.format` function.
//!
//! Ezinye izibonelo zesandiso se-[`format!`] yilezi:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ngamaqanda aholayo
//! ```
//!
//! Kulokhu, ungabona ukuthi impikiswano yokuqala iyintambo yefomethi.Kudingeka umhlanganisi ukuthi lokhu kube yintambo engokoqobo;akunakuba okuguquguqukayo okudluliselwe (ukuze kwenziwe ukuhlolwa kokufaneleka).
//! Umhlanganisi uzobe ehlwaya intambo yefomethi bese enquma ukuthi uhlu lwama-agumenti anikeziwe lufanelekile ukudluliselwa kule ntambo yefomethi.
//!
//! Ukuguqula inani elilodwa libe yunithi yezinhlamvu, sebenzisa indlela ye-[`to_string`].Lokhu kuzosebenzisa ukufomatha kwe-[`Display`] i trait.
//!
//! ## Amapharamitha wokuma
//!
//! Ukuphikisana ngakunye kokufometha kuvunyelwe ukucacisa ukuthi iyiphi impikiswano yenani ekhomba kuyo, futhi uma ishiywe kuthathwa ngokuthi yi-"the next argument".
//! Isibonelo, intambo yefomethi `{} {} {}` izothatha amapharamitha amathathu, futhi izofomethwa ngendlela efanayo naleyo enikezwe ngayo.
//! Intambo yefomethi `{2} {1} {0}`, noma kunjalo, izofometha izingxabano ngokulandelana okuphindayo.
//!
//! Izinto zingakhohliseka kancane uma uqala ukuxubana nezinhlobo ezimbili zokucaciswa kwesimo.Isichazi se-"next argument" singacatshangwa njenge-iterator ngaphezulu kwempikiswano.
//! Ngaso sonke isikhathi lapho kucaciswa i-"next argument", i-iterator iyathuthuka.Lokhu kuholela ekuziphatheni okunjengale:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! I-iterator yangaphakathi yengxabano ayizange yathuthuka ngesikhathi i-`{}` yokuqala ibonakala, ngakho-ke iphrinta impikiswano yokuqala.Lapho-ke lapho ifinyelela i-`{}` yesibili, i-iterator iqhubekele phambili kwingxabano yesibili.
//! Empeleni, amapharamitha abeka ngokusobala impikiswano yabo awathinti amapharamitha angaqambi impikiswano ngokuya kokucaciswa kwesimo.
//!
//! Intambo yefomethi iyadingeka ukusebenzisa zonke izimpikiswano zayo, ngaphandle kwalokho kuyiphutha lesikhathi sokuhlanganisa.Ungabheka kwingxabano efanayo kaningi kunentambo yefomethi.
//!
//! ## Amapharamitha aqanjwe igama
//!
//! I-Rust uqobo ayinayo i-Python efana namapharamitha aqanjiwe ekusebenzeni, kepha i-[`format!`] macro isandiso se-syntax esivumela ukuthi sisebenzise amapharamitha aqanjwe amagama.
//! Amapharamitha aqanjiwe abhalwe ekugcineni kohlu lokuphikisana futhi anesi syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Isibonelo, izinkulumo ezilandelayo ze-[`format!`] zisebenzisa ingxabano enegama:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Akuvumelekile ukubeka amapharamitha wesimo (lawo angenamagama) ngemuva kwezimpikiswano ezinamagama.Njengamapharamitha wesimo, akuvumelekile ukuhlinzeka ngamapharamitha aqanjiwe angasetshenziswa ngentambo yefomethi.
//!
//! # Ukufometha Amapharamitha
//!
//! Ingxabano ngayinye efomethwayo ingaguqulwa ngamapharamitha amaningi wokufomatha (ahambelana ne-`format_spec` ku-[the syntax](#syntax)). Lezi zinhlaka zithinta ukumelwa kwentambo kokufomethwayo.
//!
//! ## Width
//!
//! ```
//! // Konke lokhu kuphrinta i "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Le ipharamitha ye-"minimum width" ifomethi okufanele iyithathe.
//! Uma intambo yenani ingagcwalisi lezi zinhlamvu eziningi, khona-ke ukugoqwa okushiwo yi-fill/alignment kuzosetshenziselwa ukuthatha isikhala esidingekayo (bona ngezansi).
//!
//! Inani lobubanzi lingaphinde linikezwe njenge-[`usize`] ohlwini lwamapharamitha ngokungeza i-postfix `$`, ekhombisa ukuthi impikiswano yesibili iyi-[`usize`] ecacisa ububanzi.
//!
//! Ukubhekisa empikiswaneni ne-syntax yedola akuthinti ikhawunta ye-"next argument", ngakho-ke imvamisa umqondo omuhle ukubhekisa kuzimpikiswano ngesikhundla, noma usebenzise izimpikiswano eziqanjwe ngamagama.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Uhlamvu lokugcwalisa lokuzikhethela nokulungiswa kunikezwa ngokujwayelekile ngokuhlangana ne-[`width`](#width) parameter.Kufanele ichazwe ngaphambi kwe `width`, ngemuva nje kwe `:`.
//! Lokhu kukhombisa ukuthi uma inani elifomethwayo lincane kune-`width` kuzophrintwa ezinye izinhlamvu ezizungezile.
//! Ukugcwaliswa kuza ngokuhluka okulandelayo kokuqondaniswa okuhlukile:
//!
//! * `[fill]<` - impikiswano iqondaniswe kwesobunxele kumakholomu we-`width`
//! * `[fill]^` - impikiswano iqondaniswe maphakathi kumakholomu we-`width`
//! * `[fill]>` - impikiswano iqondaniswe kwesokudla kumakholomu we-`width`
//!
//! I-[fill/alignment](#fillalignment) ezenzakalelayo yezinombolo ezingezona izibalo iyindawo eqondaniswe nesobunxele.Okuzenzakalelayo kwamafomethi ezinombolo kubuye kube ngumlingiswa wesikhala kepha ngokuqondanisa kwesokudla.
//! Uma ifulegi le-`0` (bheka ngezansi) licacisiwe ngezinombolo, khona-ke umlingiswa ogcwalisiwe ongu-`0`.
//!
//! Qaphela ukuthi ukuqondanisa kungahle kungasetshenziswa ezinye izinhlobo.Ikakhulu, ayisebenzi kakhulu i `Debug` trait.
//! Indlela enhle yokuqinisekisa ukuthi kusetshenziswa i-padding ukufometha okokufaka kwakho, bese unamathisela le ntambo evelayo ukuthola umphumela wakho:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Sawubona Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Lawa wonke amafulegi aguqula ukusebenza kwefomathi.
//!
//! * `+` - Lokhu kwenzelwe izinhlobo zezinombolo futhi kukhombisa ukuthi uphawu kufanele luhlale luphrintwa.Izimpawu ezivumayo azikaze ziphrintwe ngokuzenzakalela, kanti uphawu olubi luphrintwa ngokuzenzakalela kuphela nge `Signed` trait.
//! Leli fulegi likhombisa ukuthi uphawu oluyilo (`+` noma i `-`) kufanele luphrintwe njalo.
//! * `-` - Okwamanje ayisetshenzisiwe
//! * `#` - Leli fulegi likhombisa ukuthi ifomu lokuphrinta le-"alternate" kufanele lisetshenziswe.Amanye amafomu yile:
//!     * `#?` - phrinta kahle ifomethi ye-[`Debug`]
//!     * `#x` - kwandulela impikiswano nge-`0x`
//!     * `#X` - kwandulela impikiswano nge-`0x`
//!     * `#b` - kwandulela impikiswano nge-`0b`
//!     * `#o` - kwandulela impikiswano nge-`0o`
//! * `0` - Lokhu kusetshenziselwa ukukhombisa amafomethi aphelele ukuthi ukufakwa kwi-`width` kufanele kwenziwe zombili ngohlamvu lwe-`0` kanye nokwazi uphawu.
//! Ifomethi efana ne-`{:08}` izokhipha i-`00000001` yenombolo engu-`1`, kuyilapho ifomethi efanayo izokhipha i-`-0000001` yenombolo engu-`-1`.
//! Qaphela ukuthi inguqulo engemihle ineqanda elilodwa elilodwa kunaleyo evumayo.
//!         Qaphela ukuthi ama-padding zero ahlala abekwa ngemuva kwesibonakaliso (uma sikhona) nangaphambi kwamadijithi.Lapho isetshenziswa kanye nefulegi le-`#`, kusebenza umthetho ofanayo: ama-padding zero afakwa ngemuva kwesiqalo kodwa ngaphambi kwamadijithi.
//!         Isiqalo sifakiwe kububanzi obuphelele.
//!
//! ## Precision
//!
//! Ngezinhlobo ezingezona izinombolo, lokhu kungathathwa njenge-"maximum width".
//! Uma intambo evelayo yinde ukudlula lobu bubanzi, bese incishiselwa phansi kulezi zinhlamvu eziningi futhi lelo nani elincishisiwe likhishwa nge-`fill` efanelekile, i-`alignment` ne-`width` uma leyo mingcele isethiwe.
//!
//! Ngezinhlobo ezihlanganisiwe, lokhu akunakwa.
//!
//! Ngezinhlobo zamaphoyinti entantayo, lokhu kukhombisa ukuthi mangaki amadijithi ngemuva kwephoyinti okufanele liphrintwe.
//!
//! Kunezindlela ezintathu zokucacisa i-`precision` oyifunayo:
//!
//! 1. Inombolo engu-`.N`:
//!
//!    inani eliphelele i-`N` uqobo lunembe.
//!
//! 2. Inani eliphelele noma igama elilandelwa isibonakaliso sedola `.N$`:
//!
//!    sebenzisa ifomethi *impikiswano*`N` (okumele kube yi-`usize`) njengokuqonda.
//!
//! 3. I-asterisk `.*`:
//!
//!    `.*` kusho ukuthi le `{...}` ihlotshaniswa nokufakwa kwefomethi engu-*ezimbili* kunokukodwa: okokufaka kokuqala kuphethe ukunemba kwe-`usize`, bese kuthi okwesibili kuphathe inani lokuphrinta.
//!    Qaphela ukuthi kuleli cala, uma umuntu esebenzisa umucu wefomethi `{<arg>:<spec>.*}`, ingxenye ye `<arg>` ibhekisa kunani* lokuphrinta, futhi i `precision` kufanele ingene kokufakwayo okungaphambi kwe `<arg>`.
//!
//! Isibonelo, okulandelayo kubiza konke ukuphrinta into efanayo `Hello x is 0.01000`:
//!
//! ```
//! // Sawubona {arg 0 ("x")} ngu {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Sawubona {arg 1 ("x")} ngu {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Sawubona {arg 0 ("x")} ngu {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Sawubona {next arg ("x")} ngu {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Sawubona {next arg ("x")} ngu {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Sawubona {next arg ("x")} ngu {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Ngenkathi lokhu:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! phrinta izinto ezintathu ezihluke kakhulu:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Kwezinye izilimi ezihlelayo, ukusebenza kwemisebenzi yokufomatha intambo kuncike kulungiselelo lwendawo yohlelo lokusebenza.
//! Imisebenzi yefomethi enikezwe umtapo wezincwadi ojwayelekile we-Rust awunawo umqondo wendawo futhi izokhiqiza imiphumela efanayo kuzo zonke izinhlelo ngaphandle kokucushwa komsebenzisi.
//!
//! Isibonelo, ikhodi elandelayo izohlala iphrinta i-`1.5` noma ngabe indawo yohlelo isebenzisa isihlukanisi sedesimali ngaphandle kw ichashazi.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Izinhlamvu ezingokoqobo i-`{` ne-`}` zingafakwa entanjeni ngokuzandulela ngohlamvu olufanayo.Isibonelo, uhlamvu lwe-`{` luphunyukile nge-`{{` futhi uhlamvu lwe-`}` luphunyukile nge-`}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ukufingqa, lapha ungathola uhlelo olugcwele lwezintambo zefomethi.
//! I-syntax yolimi lokufomatha olusetshenzisiwe idonswe kwezinye izilimi, ngakho-ke akufanele ihluke kakhulu.Izimpikiswano zifomethwe nge-syntax efana ne-Python, okusho ukuthi izimpikiswano zizungezwe i-`{}` esikhundleni se-C-like `%`.
//! Uhlelo lwangempela lohlelo lokufomatha ngu:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Kuhlelo lolimi olungenhla, i-`text` kungenzeka ingaqukathi noma yiziphi izinhlamvu ze-`'{'` noma ze-`'}'`.
//!
//! # Ukufomatha i-traits
//!
//! Lapho ucela ukuthi impikiswano ifomethwe ngohlobo oluthile, empeleni ucela ukuthi impikiswano inikeze i trait ethile.
//! Lokhu kuvumela izinhlobo eziningi zangempela ukuthi zifomethwe nge-`{:x}` (njenge-[`i8`] kanye ne-[`isize`]).Imephu yamanje yezinhlobo eya ku-traits yile:
//!
//! * *lutho* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ I-[`Debug`] enezinhlamvu ezincane ezinama-hexadecimal
//! * `X?` ⇒ I-[`Debug`] enezinombolo ezinkulu ezinama-hexadecimal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Lokhu kusho ukuthi noma yiluphi uhlobo lwempikiswano olusebenzisa i [`fmt::Binary`][`Binary`] trait lungabe selufomethwa nge `{:b}`.Kusetshenziswa okuhlinzekwayo kwalezi traits zezinhlobo eziningi zasendulo ngomtapo wezincwadi ojwayelekile.
//!
//! Uma kungekho fomethi ecacisiwe (njengaku-`{}` noma i-`{:6}`), khona-ke ifomethi engu-trait esetshenzisiwe yi-[`Display`] trait.
//!
//! Lapho usebenzisa ifomethi ye trait yohlobo lwakho, kuzofanele usebenzise indlela yesiginesha:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // uhlobo lwethu lwenkambiso
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Uhlobo lwakho luzodluliswa njengereferensi ye-`self`, bese umsebenzi kufanele ukhiphe okukhiphayo ekusakazweni kwe-`f.buf`.Kukwifomethi ngayinye ye-trait ukuqaliswa ukunamathela ngokufanele kumingcele wokufometha oceliwe.
//! Amanani ale mingcele azofakwa kuhlu emkhakheni we-[`Formatter`] struct.Ukuze usize ngalokhu, isakhiwo se [`Formatter`] sihlinzeka nangezinye izindlela zokusiza.
//!
//! Ngokwengeziwe, inani lokubuyisa lalo msebenzi yi-[`fmt::Result`] okuyi-alias yohlobo lwe-(`Umphumela`]`<(),`[`std: : fmt::Error`] `>`.
//! Ukufometha ukusetshenziswa kufanele kuqinisekise ukuthi basabalalisa amaphutha kusuka ku-[`Formatter`] (isb., Lapho kufonelwa i-[`write!`]).
//! Kodwa-ke, akufanele baphindise amaphutha ngokungafanele.
//! Lokho, ukusetshenziswa kokufometha kufanele futhi kungabuyisa iphutha kuphela uma i-[`Formatter`] eyedlule ibuyisa iphutha.
//! Lokhu kungenxa yokuthi, ngokuphambene nalokho okungasikiselwa yisiginesha yomsebenzi, ukufomatha intambo kungukusebenza okungenaphutha.
//! Lo msebenzi ubuyisa umphumela kuphela ngoba ukubhala ekusakazweni okungaphansi kungahle kwehluleke futhi kufanele kunikeze indlela yokusabalalisa iqiniso lokuthi kwenzeke iphutha emuva kwesitaki.
//!
//! Isibonelo sokusebenzisa ukufomatha i traits kungabonakala:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Inani le `f` lisebenzisa i `Write` trait, okuyilokho okubhaliwe!imacro ilindele.
//!         // Qaphela ukuthi lokhu kufomatha kungazinaki amafulegi ahlukahlukene anikezwe ukufometha izintambo.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // I-traits ehlukile ivumela izinhlobo ezahlukahlukene zokukhishwa kohlobo.
//! // Okushiwo yile fomethi ukuphrinta ubukhulu be-vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Hlonipha amafulegi wokufomatha ngokusebenzisa indlela yomsizi `pad_integral` entweni yeFomathi.
//!         // Bona imibhalo yendlela ukuthola imininingwane, futhi umsebenzi we-`pad` ungasetshenziselwa ukufaka izintambo.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Lawa mafomethi amabili we-traits anezinhloso ezihlukile:
//!
//! - [`fmt::Display`][`Display`] ukusetshenziswa kugomela ukuthi uhlobo lungamelwa ngokwethembeka njengeyunithi yezinhlamvu ze-UTF-8 ngaso sonke isikhathi.Kulindelwe ** ukuthi zonke izinhlobo zisebenzise i-[`Display`] trait.
//! - [`fmt::Debug`][`Debug`] ukusetshenziswa kufanele kusetshenziselwe **zonke** izinhlobo zomphakathi.
//!   Umphumela uzomela isimo sangaphakathi ngokuthembeka ngangokunokwenzeka.
//!   Inhloso ye [`Debug`] trait ukwenza lula ukulungisa ikhodi ye Rust.Ezimweni eziningi, ukusebenzisa i-`#[derive(Debug)]` kwanele futhi kuyanconywa.
//!
//! Ezinye izibonelo zokukhipha kuzo zombili i traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Ama-macro ahlobene
//!
//! Kunama-macro amaningi ahlobene emndenini we [`format!`].Lezo ezisetshenziswayo njengamanje yilezi:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Lokhu ne-[`writeln!`] ngamamakhro amabili asetshenziselwa ukukhipha intambo yefomethi ekusakazweni okucacisiwe.Lokhu kusetshenziselwa ukuvimbela ukwabiwa okuphakathi kwezintambo zefomethi futhi esikhundleni salokho kubhale ngqo umphumela.
//! Ngaphansi kwe-hood, lo msebenzi empeleni unxenxa umsebenzi we-[`write_fmt`] ochazwe ku-[`std::io::Write`] trait.
//! Ukusetshenziswa kwesibonelo ngu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Lokhu ne-[`println!`] kukhipha umphumela wazo ku-stdout.Ngokufanayo ne-[`write!`] macro, inhloso yalawa ma-macros ukugwema ukwabiwa okuphakathi lapho kuprintwa okukhiphayo.Ukusetshenziswa kwesibonelo ngu:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Ama-[`eprint!`] ne-[`eprintln!`] macros ayefana ne-[`print!`] ne-[`println!`], ngokulandelana, ngaphandle kokuthi akhiphe umphumela wawo ku-stderr.
//!
//! ### `format_args!`
//!
//! Le macro enelukuluku esetshenziselwa ukudlula ngokuphepha ezungeze into engabonakali echaza intambo yefomethi.Le nto ayidingi ukwabiwa kwenqwaba ukudala, futhi ikhomba kuphela imininingwane esitaki.
//! Ngaphansi kwe-hood, wonke ama-macro ahlobene ayasetshenziswa ngokwalokhu.
//! Okokuqala, ukusetshenziswa kwesibonelo ngu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Umphumela we-[`format_args!`] macro uyinani lohlobo [`fmt::Arguments`].
//! Lesi sakhiwo singabe sesidluliselwa emisebenzini ye-[`write`] ne-[`format`] ngaphakathi kwale module ukuze kucutshungulwe intambo yefomethi.
//! Inhloso yale macro ukuvikela ngokwengeziwe ukwabiwa okuphakathi lapho kusebenza ngentambo yokufomatha.
//!
//! Isibonelo, umtapo wolwazi wokungena ngemvume ungasebenzisa i-syntax ejwayelekile yokufomatha, kepha izodlula ngaphakathi isizungeze lesi sakhiwo kuze kube kunqunywa ukuthi umphumela kufanele uye kuphi.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Umsebenzi we-`format` uthatha isakhiwo se-[`Arguments`] bese ubuyisa intambo efomathiwe eholelekile.
///
///
/// Isibonelo se [`Arguments`] singakhiwa nge-[`format_args!`] macro.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Uyacelwa ukuthi uqaphele ukuthi ukusebenzisa i [`format!`] kungahle kube ngcono.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}