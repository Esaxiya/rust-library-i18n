#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Okuqukethwe kwememori entsha akuqalisiwe.
    Uninitialized,
    /// Imemori entsha iqinisekisiwe ukukhishwa.
    Zeroed,
}

/// Ukusetshenziswa kwezinga eliphansi lokwabiwa kwe-ergonomically, ukwabiwa kabusha, nokuhanjiswa kwesikhala sememori enqwabeni ngaphandle kokukhathazeka ngawo wonke amacala ekhoneni abandakanyekile.
///
/// Lolu hlobo luhle kakhulu ekwakheni izakhiwo zedatha yakho njenge-Vec neVecDeque.
/// Ngokuqondene:
///
/// * Ikhiqiza i-`Unique::dangling()` ngezinhlobo ezingosayizi.
/// * Ikhiqiza i-`Unique::dangling()` ekunikezelweni kobude obungu-zero.
/// * Igwema ukukhulula i-`Unique::dangling()`.
/// * Kubanjwa konke okuchichimayo ekuhlanganisweni komthamo (kukhuphula ku-"capacity overflow" panics).
/// * Abaqaphi abamele amasistimu angama-32-bit abela ngaphezulu kwama-isize::MAX byte.
/// * Abaqaphi ngokumelene nokuchichima ubude bakho.
/// * Izingcingo `handle_alloc_error` ngezabelo ezingekho.
/// * Iqukethe i-`ptr::Unique` ngakho-ke inika umsebenzisi zonke izinzuzo ezihlobene.
/// * Isebenzisa okweqile okubuyiselwe kusuka kusabelomali ukusebenzisa umthamo omkhulu kunayo yonke etholakalayo.
///
/// Lolu hlobo aluhloli nakanjani imemori eyilawulayo.Lapho ilahliwe *izokhulula inkumbulo yayo, kepha* ngeke izame ukulahla okuqukethwe kwayo.
/// Kukumsebenzisi we `RawVec` ukuphatha izinto zangempela *ezigcinwe* ngaphakathi kwe `RawVec`.
///
/// Qaphela ukuthi ukweqiwa kwezinhlobo ezingusayizi we-zero kuhlala kungapheli, ngakho-ke i `capacity()` ihlala ibuyisa i `usize::MAX`.
/// Lokhu kusho ukuthi udinga ukuthi uqaphele lapho uzungeza lolu hlobo nge-`Box<[T]>`, ngoba i-`capacity()` ngeke ikhiqize ubude.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Lokhu kutholakala ngoba ama-`#[unstable]` `const fn`s awadingi ukuhambisana ne-`min_const_fn` ngakho-ke ngeke abizwe kuma`min_const_fn`s nawo.
    ///
    /// Uma uguqula i-`RawVec<T>::new` noma ukuncika, sicela uqaphele ukuthi ungangenisi noma yini ezophula ngempela i `min_const_fn`.
    ///
    /// NOTE: Singakugwema lokhu kugenca futhi sihlole ukuhambisana nesibaluli se-`#[rustc_force_min_const_fn]` esidinga ukuhambisana ne-`min_const_fn` kepha akuvumeli ukuyibiza nge-`stable(...) const fn`/ikhodi yomsebenzisi enganiki i-`foo` lapho i-`#[rustc_const_unstable(feature = "foo", issue = "01234")]` ikhona.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Kwakha i-`RawVec` enkulu kunazo zonke (kunqwaba yohlelo) ngaphandle kokwaba.
    /// Uma i-`T` inosayizi omuhle, lokhu kwenza i-`RawVec` ngomthamo `0`.
    /// Uma i-`T` ilingana no-zero, khona-ke yenza i-`RawVec` ngomthamo `usize::MAX`.
    /// Ilusizo ekusebenziseni ukwabiwa okubambezelekile.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Idala i-`RawVec` (kunqwaba yesistimu) enesilinganiso namandla kanye nokuqondanisa kwe `[T; capacity]`.
    /// Lokhu kulingana nokubiza i-`RawVec::new` lapho i-`capacity` ingu-`0` noma i-`T` ilingana no-zero.
    /// Qaphela ukuthi uma i-`T` ilingana no-zero lokhu kusho ukuthi ngeke * uthole i-`RawVec` ngomthamo oceliwe.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo oceliwe ungaphezu kwama-byte angu-`isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Ukukhishwa kwezisu ku-OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Njenge-`with_capacity`, kepha iqinisekisa ukuthi i-buffer ayisebenzi.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Yakha kabusha i-`RawVec` kusuka kusikhombi namandla.
    ///
    /// # Safety
    ///
    /// I-`ptr` kufanele yabelwe (kunqwaba yohlelo), nange-`capacity` enikeziwe.
    /// I-`capacity` ayikwazi ukweqa i-`isize::MAX` ngezinhlobo ezinosayizi.(kuphela ukukhathazeka kuzinhlelo ezingama-32-bit).
    /// I-ZST vectors ingaba namandla afinyelela ku-`usize::MAX`.
    /// Uma i-`ptr` ne-`capacity` zivela ku-`RawVec`, lokhu kuqinisekisiwe.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Ama-Vec amancane ayisimungulu.Yeqela ku:
    // - 8 uma usayizi wento engu-1, ngoba noma imuphi umhlinzeki wenqwaba kungenzeka aqoqe isicelo esingaphansi kwamabhayithi ayi-8 okungenani ama-byte ayi-8.
    //
    // - 4 uma izinto zinosayizi omaphakathi (<=1 KiB).
    // - 1 kungenjalo, ukugwema ukuchitha isikhala esiningi kakhulu ngama-Vec amafushane kakhulu.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Njengo-`new`, kepha yenziwa ipharamitha ngokukhetha isabelo se-`RawVec` ebuyisiwe.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` kusho i "unallocated".Izinhlobo ezingosayizi abunakwa.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Njengo-`with_capacity`, kepha yenziwa ipharamitha ngokukhetha isabelo se-`RawVec` ebuyisiwe.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Njengo-`with_capacity_zeroed`, kepha yenziwa ipharamitha ngokukhetha isabelo se-`RawVec` ebuyisiwe.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Iguqula i-`Box<[T]>` ibe yi-`RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Iguqula yonke i-buffer ibe yi-`Box<[MaybeUninit<T>]>` nge-`len` ebekiwe.
    ///
    /// Qaphela ukuthi lokhu kuzokwakha kabusha noma iziphi izinguquko ze-`cap` okungenzeka zenziwe.(Bheka incazelo yohlobo ngemininingwane.)
    ///
    /// # Safety
    ///
    /// * `len` kufanele ibe nkulu noma ilingane nomthamo osanda kucelwa, futhi
    /// * `len` kufanele ibe ngaphansi noma ilingane no-`self.capacity()`.
    ///
    /// Qaphela, ukuthi umthamo oceliwe ne-`self.capacity()` zingahluka, njengoba umhlinzeki engabeka ngaphezulu indawo futhi abuyisele inkumbulo enkulu kunaleyo eceliwe.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-hlola ingxenye eyodwa yezidingo zokuphepha (asikwazi ukubheka enye ingxenye).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Sigwema i-`unwrap_or_else` lapha ngoba ivimba inani le-LLVM IR elenziwe.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Yakha kabusha i-`RawVec` kusuka kusikhombi, umthamo, nomhlinzeki.
    ///
    /// # Safety
    ///
    /// I-`ptr` kufanele yabelwe (ngokusebenzisa isinikezeli esinikeziwe i-`alloc`), kanye ne-`capacity` enikeziwe.
    /// I-`capacity` ayikwazi ukweqa i-`isize::MAX` ngezinhlobo ezinosayizi.
    /// (kuphela ukukhathazeka kuzinhlelo ezingama-32-bit).
    /// I-ZST vectors ingaba namandla afinyelela ku-`usize::MAX`.
    /// Uma i-`ptr` ne-`capacity` zivela ku-`RawVec` eyenziwe nge-`alloc`, lokhu kuqinisekisiwe.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ithola isikhombi esiluhlaza ekuqaleni kwesabelo.
    /// Qaphela ukuthi le yi-`Unique::dangling()` uma i-`capacity == 0` noma i-`T` ilingana no-zero.
    /// Esimweni esidlule, kufanele uqaphele.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ithola amandla esabelo.
    ///
    /// Lokhu kuzohlala kuyi-`usize::MAX` uma i-`T` ilingana no-zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Ibuyisa ireferensi eyabiwe kumhlinzeki osekela le `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Sine-chunk yememori eyabelwe, ngakho-ke singadlula amasheke wesikhathi sokusebenza ukuthola ukwakheka kwethu kwamanje.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Iqinisekisa ukuthi i-buffer iqukethe okungenani isikhala esanele sokubamba izinto ze-`len + additional`.
    /// Uma ingenawo amandla anele, izokwaba kabusha isikhala esanele kanye nesikhala esanele sokunethezeka ukuze ithole ukukhishwa kwe-*O*(1).
    ///
    /// Izokhawulela lokhu kuziphatha uma kungazibangela ngokungadingekile ku-panic.
    ///
    /// Uma i-`len` idlula i-`self.capacity()`, lokhu kungahle kwehluleke ukwaba isikhala esiceliwe.
    /// Lokhu akuphephile ngempela, kepha ikhodi engaphephile * oyibhalayo ethembele ekuziphatheni kwalo msebenzi ingahle yephule.
    ///
    /// Lokhu kulungele ukusebenzisa ukusebenza kwe-bulk-Push njenge-`extend`.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha wedlula ama-byte angu-`isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Ukukhishwa kwezisu ku-OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // Ukulondolozwa bekuyobe kukhishwe isisu noma kutatazelwe uma i-len yeqe i-`isize::MAX` ngakho-ke lokhu kuphephile ukwenziwa kungamakiwe manje.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Kuyafana ne `reserve`, kepha kubuya emaphutheni esikhundleni sokwethuka noma ukukhipha isisu.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Iqinisekisa ukuthi i-buffer iqukethe okungenani isikhala esanele sokubamba izinto ze-`len + additional`.
    /// Uma ingakabikho, izokwaba kabusha inani lememori elincane elikhona.
    /// Ngokuvamile lokhu kuzoba impela inani lememori elidingekayo, kepha ngokomthetho owabayo ukhululekile ukubuyisa okungaphezulu kwalokho esikucelile.
    ///
    ///
    /// Uma i-`len` idlula i-`self.capacity()`, lokhu kungahle kwehluleke ukwaba isikhala esiceliwe.
    /// Lokhu akuphephile ngempela, kepha ikhodi engaphephile * oyibhalayo ethembele ekuziphatheni kwalo msebenzi ingahle yephule.
    ///
    /// # Panics
    ///
    /// I-Panics uma umthamo omusha wedlula ama-byte angu-`isize::MAX`.
    ///
    /// # Aborts
    ///
    /// Ukukhishwa kwezisu ku-OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Kuyafana ne `reserve_exact`, kepha kubuya emaphutheni esikhundleni sokwethuka noma ukukhipha isisu.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Nciphisa isabelo siye enanini elicacisiwe.
    /// Uma inani elinikeziwe lingu-0, empeleni kususwa ngokuphelele.
    ///
    /// # Panics
    ///
    /// I-Panics uma inani elinikeziwe likhulu * kunomthamo wamanje.
    ///
    /// # Aborts
    ///
    /// Ukukhishwa kwezisu ku-OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Ibuyisa uma i-buffer idinga ukukhula ukuze igcwalise umthamo owengeziwe odingekayo.
    /// Isetshenziselwe ukwenza izingcingo zokubekisa ezifakwa ngaphakathi ngaphandle kokufaka u `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Le ndlela ivame ukufakwa izikhathi eziningi.Ngakho-ke sifuna ukuthi libe lincane ngangokunokwenzeka, ukuthuthukisa izikhathi zokuhlanganisa.
    // Kepha sifuna nokuqukethwe kwayo okuningi kube ngokwezibalo ngangokunokwenzeka, ukwenza ikhodi ekhiqizwayo iqhubeke ngokushesha.
    // Ngakho-ke, le ndlela ibhalwe ngokucophelela ukuze yonke ikhodi encike ku-`T` ingaphakathi kuyo, ngenkathi ikhodi eningi enganciki ku-`T` ngangokunokwenzeka isemisebenzini engeyona ejwayelekile kune-`T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Lokhu kuqinisekiswa yizimo zokushaya.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Njengoba sibuyisa umthamo we `usize::MAX` lapho i `elem_size` iyi
            // 0, ukufika lapha empeleni kusho ukuthi i `RawVec` igcwele ngokweqile.
            return Err(CapacityOverflow);
        }

        // Akukho esingakwenza ngempela ngalezi masheke, ngokudabukisayo.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Lokhu kuqinisekisa ukukhula okukhulayo.
        // Ukuphindaphindwa akukwazi ukugcwala ngoba i-`cap <= isize::MAX` nohlobo lwe-`cap` ngu-`usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` akuyona ejwayelekile ngaphezu kwe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Izingqinamba ezikule ndlela zifana kakhulu nalezi ezikwi-`grow_amortized`, kepha le ndlela ivame ukufakwa kaningi ngakho-ke ayigxeki kakhulu.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Njengoba sibuyisa umthamo we `usize::MAX` lapho usayizi wohlobo engu-
            // 0, ukufika lapha empeleni kusho ukuthi i `RawVec` igcwele ngokweqile.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` akuyona ejwayelekile ngaphezu kwe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Lo msebenzi ungaphandle kwe-`RawVec` ukunciphisa izikhathi zokuhlanganisa.Bona ukuphawula ngenhla kwe-`RawVec::grow_amortized` ukuthola imininingwane.
// (Ipharamitha ye `A` ayibalulekile, ngoba inani lezinhlobo ezahlukahlukene ze-`A` ezibonwe ekusebenzeni lincane kakhulu kunenombolo yezinhlobo ze-`T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Bheka iphutha lapha ukunciphisa usayizi we `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Umabi wabheka ukulingana kokuqondanisa
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Ikhulula imemori ye-`RawVec`*ngaphandle* kokuzama ukulahla okuqukethwe kwayo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Umsebenzi ophakathi wokusingathwa kokuphathwa kwephutha.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Sidinga ukuqinisekisa okulandelayo:
// * Asikaze sabele izinto zosayizi we-`> isize::MAX` byte.
// * Asichichimi i `usize::MAX` futhi empeleni sabela okuncane kakhulu.
//
// Ku-64-bit sidinga nje ukubheka ukuchichima ngoba ukuzama ukwaba ama-`> isize::MAX` byte kuzokwehluleka nakanjani.
// Ku-32-bit no-16-bit sidinga ukufaka okunye ukuqapha kulokhu uma sisebenza kungxenyekazi engasebenzisa yonke i-4GB esikhaleni somsebenzisi, isb., PAE noma x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Umsebenzi owodwa ophakathi obhekene nomthamo wokubika uchichima.
// Lokhu kuzoqinisekisa ukuthi ukwenziwa kwekhodi okuhlobene nalezi panics kuncane njengoba kunendawo eyodwa kuphela eyi-panics kunokuba ibe yiqembu kuyo yonke imodyuli.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}