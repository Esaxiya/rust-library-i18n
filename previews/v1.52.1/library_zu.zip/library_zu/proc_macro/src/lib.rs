//! Umtapo wolwazi osekela ababhali be-macro lapho kuchazwa ama-macros amasha.
//!
//! Lo mtapo wezincwadi, ohlinzekwa ukusatshalaliswa okujwayelekile, uhlinzeka ngezinhlobo ezisetshenzisiwe kwizikhombisi-ndlela zezincazelo ze-macro ezichazwe ngokwenqubo ezinjenge-macro `#[proc_macro]` efana nomsebenzi, izimfanelo ezinkulu ze-`#[proc_macro_attribute]` nezimpawu zokuthola ngokwezifiso`##proc_macro_derive]`.
//!
//!
//! Bona i [the book] ukuthola okuningi.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Inquma ukuthi i-proc_macro yenziwe yatholakalela uhlelo olusebenzayo njengamanje.
///
/// I-proc_macro crate yenzelwe kuphela ukusetshenziswa ngaphakathi kokuqaliswa kwama-macros enqubo.Yonke imisebenzi ekule crate panic uma icelwe ngaphandle kwenqubo enkulu, efana neskripthi sokwakha noma ukuhlolwa kweyunithi noma kanambambili ojwayelekile we-Rust.
///
/// Ngokucatshangelwa kwemitapo yolwazi ye-Rust eyenzelwe ukuxhasa amacala wokusebenzisa ama-macro kanye non-macro, i-`proc_macro::is_available()` inikeza indlela engatatazeli yokuthola ukuthi ngabe ingqalasizinda edingekayo ukusebenzisa i-API ye-proc_macro okwamanje iyatholakala.
/// Ibuyisa iqiniso uma icelwe ngaphakathi kwenqubo enkulu, ngamanga uma icelwe kunoma iyiphi enye kanambambili.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Uhlobo oluyinhloko olunikezwe yi-crate, emele ukusakazwa okungabonakali kwe-tokens, noma, ikakhulukazi, ukulandelana kwezihlahla ze-token.
/// Uhlobo luhlinzeka ngezindawo zokuxhumana eziphindaphindwayo kulezo zihlahla ze-token futhi, ngakolunye uhlangothi, luqoqa izihlahla eziningi ze-token zibe umfudlana owodwa.
///
///
/// Lokhu kokubili ukufakwa nokukhishwa kwezincazelo ze-`#[proc_macro]`, `#[proc_macro_attribute]` ne-`#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Iphutha libuyisiwe kusuka ku-`TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Ibuyisa i-`TokenStream` engenalutho engenazo izihlahla ze-token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Ihlola ukuthi ngabe le `TokenStream` ayinalutho.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Imizamo yokugqashula intambo ibe yi-tokens bese ihlunga lezo tokens emseleni we-token.
/// Ingahle ihluleke ngenxa yezizathu eziningi, ngokwesibonelo, uma intambo iqukethe abalingisi abalinganisiwe noma izinhlamvu ezingekho olimini.
///
/// Onke ama-tokens ekusakazweni okuhlukanisiwe athola izikhala ze-`Span::call_site()`.
///
/// NOTE: amanye amaphutha angadala i-panics esikhundleni sokubuyisa i-`LexError`.Sinelungelo lokushintsha la maphutha abe yi-`LexError`s ngokuhamba kwesikhathi.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Iphrinta ukusakazwa kwe-token njengeyunithi yezinhlamvu okufanele iguqulwe ngokungalahleki ibuyele ekusakazeni okufanayo kwe-token (modulo spans), ngaphandle kokuthi kungenzeka kube yi-`TokenTree: : Group`s enamalayini we-`Delimiter::None` kanye nemibhalo yezinombolo ezingezinhle.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Iphrinta i token ngendlela elula yokulungisa iphutha.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Kwakha ukusakaza kwe-token okuqukethe isihlahla esisodwa se-token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Iqoqa inani lezihlahla ze-token emfuleni owodwa.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Ukusebenza kwe-"flattening" emifudlaneni ye-token, kuqoqa izihlahla ze-token kusuka kwimifudlana eminingi ye-token ibe ngumfudlana owodwa.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Sebenzisa ukuqaliswa okulungiselelwe kwe-if/when kungenzeka.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Imininingwane yokuqalisa yomphakathi yohlobo lwe `TokenStream`, njengama-iterators.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// I-iterator ngaphezulu kwe-``TokenTream`'s 'TokenTree`s.
    /// I-iteration yi-"shallow", isb. I-iterator ayibuyeli emaqenjini ahlukanisiwe, futhi ibuyisa amaqembu aphelele njengezihlahla ze-token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` yamukela i-tokens ngokungafanele futhi inwebeke ibe yi-`TokenStream` echaza okokufaka.
/// Isibonelo, i-`quote!(a + b)` izokhiqiza isisho, okuthi, lapho sihlolwa, sakhe i-`TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ukucaphula kwenziwa nge-`$`, futhi kusebenza ngokuthatha i-ident elandelayo eyodwa njengegama elingacashuniwe.
/// Ukucaphuna i `$` uqobo, sebenzisa i `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Isifunda sekhodi yomthombo, kanye nemininingwane yokwandiswa kwe-macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Idala i-`Diagnostic` entsha nge-`message` enikeziwe ku-span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Isikhathi esixazululeka kusayithi lokuchazwa kwemacro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Isikhathi sokuncenga kwenqubo yamanje enkulu.
    /// Izihlonzi ezenziwe ngalesi sikhathi zizolungiswa kube sengathi zibhalwe ngqo endaweni yezingcingo ezinkulu (inqubomgomo yesiza sezingcingo) nenye ikhodi esikhungweni sezingcingo ezinkulu izokwazi ukubhekisa nakuzo.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Isikhathi esimele ukuhlanzeka kwe-`macro_rules`, futhi kwesinye isikhathi sixazululwe endaweni yokuchazwa kwe-macro (okuguquguqukayo kwasendaweni, amalebula, i-`$crate`) futhi kwesinye isikhathi kusayithi lezingcingo ezinkulu (konke okunye).
    ///
    /// Indawo yesikhala ithathwa kusayithi lezingcingo.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Ifayela lomthombo loqobo lapho lesi sikhathi sikhomba khona.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// I-`Span` ye-tokens ekunwetshisweni okwedlule kwe-macro lapho i-`self` yenziwa khona, uma ikhona.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Ububanzi bekhodi yomthombo we-`self` abenziwe kuyo.
    /// Uma le `Span` ingakhiwanga kusuka kokunye ukukhuliswa okukhulu, inani lokubuyisa liyafana ne `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ithola i-line/column yokuqala kufayela lomthombo lalesi sikhathi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ithola ukuphela kwe-line/column kufayela lomthombo lalesi sikhathi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Kwakha ispan esisha esihlanganisa i-`self` ne-`other`.
    ///
    /// Ibuyisa i-`None` uma i-`self` ne-`other` zisuka kumafayela ahlukile.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Idala isikhala esisha esinemininingwane efanayo ye-line/column njenge-`self` kepha lokho kuxazulula izimpawu ngokungathi ku-`other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Idala isikhala esisha esinokuziphatha kokulungiswa kwegama okufanayo ne-`self` kepha ngolwazi lwe-line/column le-`other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Iqhathanisa nezikhala ukubona ukuthi ziyalingana yini.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Ibuyisa umbhalo ongumthombo ngemuva kwesikhawu.
    /// Lokhu kugcina ikhodi yoqobo yomthombo, kufaka phakathi izikhala namazwana.
    /// Ibuyisa kuphela umphumela uma i-span ihambelana nekhodi yangempela yomthombo.
    ///
    /// Note: Umphumela obonakalayo we-macro kufanele uncike kuphela ku-tokens hhayi kulo mbhalo womthombo.
    ///
    /// Umphumela walo msebenzi ngumzamo omuhle kakhulu ongasetshenziselwa ukuxilonga kuphela.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Iphrinta i-span ngendlela elula yokulungisa iphutha.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ipheya lekholomu elimela ukuqala noma ukuphela kwe-`Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Ulayini onenkomba engu-1 kufayela lomthombo lapho i-span iqala khona noma iphela khona i-(inclusive)
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Ikholomu enezinkomba eziyi-0 (ngezinhlamvu ze-UTF-8) kufayela lomthombo lapho i-span iqala khona noma iphela khona i-(inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Ifayela eliwumthombo le-`Span` enikeziwe.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ithola indlela eya kuleli fayela lomthombo.
    ///
    /// ### Note
    /// Uma ubude bekhodi obuhlotshaniswa nale `SourceFile` bukhiqizwe yi-macro yangaphandle, le macro, lokhu kungenzeka kungabi yindlela yangempela kuhlelo lwefayela.
    /// Sebenzisa i-[`is_real`] ukuhlola.
    ///
    /// Futhi qaphela ukuthi noma ngabe i-`is_real` ibuyisa i-`true`, uma i-`--remap-path-prefix` idluliswe kulayini womyalo, indlela enikeziwe kungenzeka ingasebenzi.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Ibuyisa i-`true` uma ngabe leli fayela eliwumthombo liyifayela lomthombo langempela, futhi alivelwanga ukunwetshwa kwangaphandle okukhulu.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Lokhu kuwukugenca kuze kube kwenziwa izikhala ze-intercrate futhi singaba namafayela womthombo wangempela wezikhala ezakhiwe kuma-macros angaphandle.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// I-token eyodwa noma ukulandelana okuhlukanisiwe kwezihlahla ze-token (isb., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Ukusakaza kwe-token okuzungezwe ngabanqwabeli bebakaki.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Isikhombi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Uhlamvu olulodwa lwezimpawu zokubhala (`+ +`, `,`, `$`, njll.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Uhlamvu lwangempela (`'a'`), intambo (`"hello"`), inombolo (`2.3`), njll.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Ibuyisa ubude besikhathi salesi sihlahla, idlulisela indlela ye-`span` ye-token equkethe noma umfudlana onqunyelwe.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Ilungiselela isikhathi se-span se *token* kuphela.
    ///
    /// Qaphela ukuthi uma le token iyi-`Group` khona-ke le ndlela ngeke ilungiselele ubude besikhala ngasinye se-tokens, lokhu kuzothumela indlela ye-`set_span` yokwahluka ngakunye.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Phrinta umuthi we-token ngendlela elula yokulungisa iphutha.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ngayinye yalezi inegama kuhlobo lwe-struct ekususeni iphutha elithathiwe, ngakho-ke ungazihluphi ngongqimba owengeziwe wokuqondiswa
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Iphrinta umuthi we-token njengeyunithi yezinhlamvu okufanele iguqulwe ngokungalahleki ibuyele esihlahleni esifanayo se-token (i-modulo spans), ngaphandle kokuthi kungenzeka kube yi-`TokenTree: : Group`s enezinqamuleli ze-`Delimiter::None` kanye nemibhalo yezinombolo ezingezinhle.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ukusakazwa komkhawulo we-token.
///
/// I-`Group` ngaphakathi iqukethe i-`TokenStream` ezungezwe ama-Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Ichaza ukuthi kulandelwa kanjani ukulandelana kwezihlahla ze-token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// I-delimiter engacacisiwe, engahle, ngokwesibonelo, ivele izungeze i-tokens evela ku-"macro variable" `$var`.
    /// Kubalulekile ukugcina izinto eziza kuqala ku-opharetha ezimeni ezinjenge-`$var * 3` lapho i-`$var` iyi-`1 + 2`.
    /// Ama-delimers asobala angahle angasinda ohambweni lokujikeleza lwe-token ngentambo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Idala i-`Group` entsha nge-delimiter enikeziwe nokusakazwa kwe-token.
    ///
    /// Lo makhi uzosetha ubude baleli qembu ku-`Span::call_site()`.
    /// Ukushintsha i-span ungasebenzisa indlela ye-`set_span` engezansi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ibuyisa umkhawulo we-`Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Ibuyisa i-`TokenStream` ye-tokens enqunyelwe kule `Group`.
    ///
    /// Qaphela ukuthi ukusakazwa okubuyisiwe kwe-token akubandakanyi umkhawulo obuyiselwe ngaphezulu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Ibuyisa iskhathi sabadali bokuhlukaniswa kwalokhu kusakazwa kwe-token, ithatha yonke i-`Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ibuyisa ubude obukhomba umkhawulo wokuvula waleli qembu.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Ibuyisa ubude obukhomba umkhawulo wokuvala waleli qembu.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Ilungiselela ubude besiphetho sale ``Group`'s delimiters, kepha hhayi i-tokens yangaphakathi.
    ///
    /// Le ndlela **ngeke** isethe ububanzi bazo zonke i-tokens zangaphakathi ezisatshalaliswe yileli qembu, kepha kunalokho izosetha kuphela ububanzi besinqunyiwe se-tokens ezingeni le-`Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Iphrinta iqembu njengeyunithi yezinhlamvu okufanele iguqulwe ingalahleki ibuyele eqenjini elifanayo (ama-modulo spans), ngaphandle kokuthi kungenzeka kube yi-`TokenTree: : Group`s enamalungu we-`Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// I-`Punct` iyinhlamvu eyodwa yezimpawu zokuloba efana ne-`+`, `-` noma i-`#`.
///
/// Ama-opharetha abalingiswa abaningi abanjengo-`+=` amelwe njengezimo ezimbili ze-`Punct` ezinezinhlobo ezahlukahlukene ze-`Spacing` ezibuyisiwe.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ukuthi i-`Punct` ilandelwa ngokushesha yini enye i-`Punct` noma ilandelwe enye i-token noma i-whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// isb., `+` iyi-`Alone` ku-`+ =`, `+ident` noma i-`+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// isb., `+` iyi-`Joint` ku-`+=` noma i-`'#`.
    /// Ngokwengeziwe, i-quote eyodwa i-`'` ingajoyina nezikhombi ukwenza i-`'ident` yesikhathi sokuphila.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Idala i-`Punct` entsha kusuka kumlingiswa onikeziwe nesikhala.
    /// Ukungqubuzana kwe-`ch` kufanele kube uhlamvu lwezimpawu lwezimpawu oluvumelekile oluvunyelwe ulimi, ngaphandle kwalokho umsebenzi uzoba yi-panic.
    ///
    /// I-`Punct` ebuyisiwe izoba nesikhala esizenzakalelayo se-`Span::call_site()` esingahle silungiselelwe ngendlela ye-`set_span` engezansi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Ibuyisa inani lalesi sici sezimpawu zokuloba njenge-`char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Ibuyisa isikhala saloluhlamvu lwezimpawu, okukhombisa ukuthi ngabe ilandelwa ngokushesha yini enye i-`Punct` ekusakazweni kwe-token, ukuze ikwazi ukuhlanganiswa ibe yi-opharetha enezinhlamvu eziningi i-(`Joint`), noma ilandelwe enye i token noma i-whitespace (`Alone`) ngakho-ke opharetha ngokuqinisekile yaphela.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Ibuyisa ubude besikhala saloluhlamvu lwezimpawu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Lungiselela ubude besikhala saloluhlamvu lwezimpawu zokubhala.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Iphrinta umlingiswa wezimpawu zokuloba njengeyunithi yezinhlamvu okufanele iguqulwe ingalahleki ibuyele kuhlamvu olufanayo.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Isikhombi (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Idala i-`Ident` entsha nge-`string` enikeziwe kanye ne-`span` ebekiwe.
    /// Ukuphikisana kwe-`string` kufanele kube okokuhlonza okuvumelekile okuvunyelwe ulimi (kufaka phakathi amagama angukhiye, isb. `self` noma i-`fn`).Ngaphandle kwalokho, umsebenzi uzoba ngu-panic.
    ///
    /// Qaphela ukuthi i `span`, okwamanje eku rustc, ilungiselela imininingwane yenhlanzeko yalesi sikhombi.
    ///
    /// Kuze kube manje i-`Span::call_site()` ingena ngokusobala kwinhlanzeko ye-"call-site" okusho ukuthi okokuhlonza okwenziwe ngalesi sikhathi kuzoxazululwa kube sengathi kubhalwe ngqo endaweni yekholi enkulu, futhi enye ikhodi esizeni sezingcingo ezikhulu izokwazi ukubhekisa kuyo nabo futhi.
    ///
    ///
    /// Ngokuhamba kwesikhathi izikhala ezinjenge-`Span::def_site()` zizovumela ukungena kwinhlanzeko ye-"definition-site" okusho ukuthi okokuhlonza okwenziwe ngalesi sikhathi kuzolungiswa endaweni yencazelo enkulu futhi enye ikhodi kusayithi lezingcingo ze-macro ngeke ikwazi ukubhekisela kuyo.
    ///
    /// Ngenxa yokubaluleka kwamanje kwenhlanzeko lo makhi, ngokungafani nezinye i tokens, kudinga ukuthi kuchazwe i `Span` ekwakhiweni.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Ifana ne-`Ident::new`, kepha idala okokuhlonza okuluhlaza okungu-(`r#ident`).
    /// Impikiswano ye-`string` iba yisikhombi esivumelekile esivunyelwe ulimi (kufaka phakathi amagama angukhiye, isb. `fn`).
    /// Amagama angukhiye asetshenziswa kwizigaba zendlela (isb
    /// `self`, `super`) akusekelwa, futhi kuzodala i-panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Ibuyisa ubude bale `Ident`, obuhlanganisa yonke intambo ebuyiswe yi-[`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ilungiselela ubude bale `Ident`, ngokunokwenzeka iguqule umongo wayo wenhlanzeko.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Phrinta okokuhlonza njengeyunithi yezinhlamvu okufanele iguqulwe ingalahleki ibuyele kusihlonzi esifanayo.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Intambo yoqobo engu-(`"hello"`), umucu we-byte (`b"hello"`), umlingiswa u-(`'a'`), umlingiswa we-byte u-(`b'a'`), inombolo ephelele noma yenombolo yephoyinti enesijobelelo noma esingenaso (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Izincwadi ze-Boolean ezifana ne-`true` ne-`false` akuzona ezalapha, zingama-``Id`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Idala inani eliphelele lesijobelelo esinenani elicacisiwe.
        ///
        /// Lo msebenzi uzokwakha inani eliphelele njenge-`1u32` lapho inani eliphelele elishiwo liyingxenye yokuqala ye-token futhi okuhlanganisiwe nakho kunesixhumi ekugcineni.
        /// Ama-Literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili ohambweni olujikelezayo nge-`TokenStream` noma ngentambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
        ///
        ///
        /// Izincwadi ezakhiwe ngale ndlela zinesikhala se-`Span::call_site()` ngokuzenzakalela, esingalungiswa ngendlela ye-`set_span` engezansi.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Kwakha inani eliphelele elingaxutshiwe elinenani elicacisiwe.
        ///
        /// Lo msebenzi uzokwakha inani eliphelele njenge-`1` lapho inani eliphelele elishiwo liyingxenye yokuqala ye-token.
        /// Asikho isijobelelo esichazwe kule token, okusho ukuthi ukuncenga okunjenge-`Literal::i8_unsuffixed(1)` kulingana no-`Literal::u32_unsuffixed(1)`.
        /// Ama-literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili lapho kudilika khona i-`TokenStream` noma izintambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
        ///
        ///
        /// Izincwadi ezakhiwe ngale ndlela zinesikhala se-`Span::call_site()` ngokuzenzakalela, esingalungiswa ngendlela ye-`set_span` engezansi.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Kwakha iphuzu lephuzu elintantayo elisha elingenasiphazamisi.
    ///
    /// Lo makhi uyefana nalabo abanjengo-`Literal::i8_unsuffixed` lapho inani le-float likhishwa ngqo ku-token kepha akusetshenziswa isijobelelo, ngakho-ke kungahle kuthiwe yi-`f64` ngokuhamba kwesikhathi ku-compiler.
    ///
    /// Ama-literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili lapho kudilika khona i-`TokenStream` noma izintambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
    ///
    /// # Panics
    ///
    /// Lo msebenzi udinga ukuthi iflothi ecacisiwe iphele, ngokwesibonelo uma ingaphansi noma i-NaN lo msebenzi uzoba yi-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Kwakha iphuzu lephuzu elintantayo elisha elinombhalo ongokoqobo.
    ///
    /// Lo makhi uzokwakha ngokoqobo njenge-`1.0f32` lapho inani elicacisiwe liyingxenye eyandulele ye token futhi i-`f32` iyisijobelelo se-token.
    /// Le token izohlala iqondiswa njenge-`f32` kusihlanganisi.
    /// Ama-literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili lapho kudilika khona i-`TokenStream` noma izintambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
    ///
    ///
    /// # Panics
    ///
    /// Lo msebenzi udinga ukuthi iflothi ecacisiwe iphele, ngokwesibonelo uma ingaphansi noma i-NaN lo msebenzi uzoba yi-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Kwakha iphuzu lephuzu elintantayo elisha elingenasiphazamisi.
    ///
    /// Lo makhi uyefana nalabo abanjengo-`Literal::i8_unsuffixed` lapho inani le-float likhishwa ngqo ku-token kepha akusetshenziswa isijobelelo, ngakho-ke kungahle kuthiwe yi-`f64` ngokuhamba kwesikhathi ku-compiler.
    ///
    /// Ama-literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili lapho kudilika khona i-`TokenStream` noma izintambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
    ///
    /// # Panics
    ///
    /// Lo msebenzi udinga ukuthi iflothi ecacisiwe iphele, ngokwesibonelo uma ingaphansi noma i-NaN lo msebenzi uzoba yi-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Kwakha iphuzu lephuzu elintantayo elisha elinombhalo ongokoqobo.
    ///
    /// Lo makhi uzokwakha ngokoqobo njenge-`1.0f64` lapho inani elicacisiwe liyingxenye eyandulele ye token futhi i-`f64` iyisijobelelo se-token.
    /// Le token izohlala iqondiswa njenge-`f64` kusihlanganisi.
    /// Ama-literal adalwe kusuka ezinombolweni ezingezinhle kungenzeka angaphili lapho kudilika khona i-`TokenStream` noma izintambo futhi angahle aphulwe abe yi-tokens (`-` ne-literal positive).
    ///
    ///
    /// # Panics
    ///
    /// Lo msebenzi udinga ukuthi iflothi ecacisiwe iphele, ngokwesibonelo uma ingaphansi noma i-NaN lo msebenzi uzoba yi-panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Umugqa ngokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Uhlamvu ngokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Intambo ye-Byte ingokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Ibuyisa ubude obufaka lokhu okungokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ilungiselela ubude besikwele obuhlobene nalokhu ngokoqobo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Ibuyisa i-`Span` eyi-subset ye-`self.span()` equkethe kuphela amabhayithi womthombo ebangeni le-`range`.
    /// Ibuyisa i-`None` uma ubude obunqunyiwe bungaphandle kwemingcele ye-`self`.
    ///
    // FIXME(SergioBenitez): hlola ukuthi uhla lwe-byte luqala luphele kumngcele we-UTF-8 womthombo.
    // ngaphandle kwalokho, kungenzeka ukuthi i-panic izokwenzeka kwenye indawo lapho umbhalo womthombo uphrintiwe.
    // FIXME(SergioBenitez): ayikho indlela yokuthi umsebenzisi azi ukuthi yini ngempela i-`self.span()` emephu, ngakho-ke le ndlela okwamanje ingabizwa ngokungaboni.
    // Isibonelo, i-`to_string()` yohlamvu 'c' ibuyisa i-"'\u{63}'";ayikho indlela yokuthi umsebenzisi azi ukuthi ngabe umbhalo oyisiqalo kwakungu-'c' noma ngabe kwakungu-'\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) okuthile okufana ne-`Option::cloned`, kepha kwe-`Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// I-NB, ibhuloho linikeza kuphela i-`to_string`, isebenzisa i-`fmt::Display` ngokuya ngalo (okuphambene nobudlelwano obujwayelekile phakathi kwalaba ababili).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Iphrinta okungokoqobo njengeyunithi yezinhlamvu okufanele iguqulwe ngokungalahleki ibuyele kuqobo olufanayo (ngaphandle kokuzungeza izintambo zamanani entanta).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ukulandelelwa kokuguquguqukayo kwemvelo.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Buyisa ukuguquguquka kwemvelo bese uyengeza ekwakheni imininingwane yokuncika.
    /// Isistimu yokwakha ehlanganisa umhlanganisi izokwazi ukuthi okuguquguqukayo kufinyelelwe ngesikhathi sokuhlanganiswa, futhi kuzokwazi ukuphinda kuqalwe kabusha ukwakhiwa lapho inani lalokho kuguquguquka lishintsha.
    ///
    /// Ngaphandle kokulandela umkhondo wokuncika lo msebenzi kufanele ulingane no-`env::var` kusuka kumtapo wezincwadi ojwayelekile, ngaphandle kokuthi impikiswano kufanele ibe yi-UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}