// rsbegin.o futhi i-rsend.o ibizwa kanjalo nge-"compiler runtime startup objects".
// Ziqukethe ikhodi edingekayo ukuqala kahle isikhathi sokusebenza somhlanganisi.
//
// Lapho isithombe esisebenzisekayo noma se-dylib sixhunywe, wonke amakhodi womsebenzisi nemitapo yolwazi angama-"sandwiched" phakathi kwalawa mafayela wezinto ezimbili, ngakho-ke ikhodi noma idatha evela ku-rsbegin.o iba ngeyokuqala ezigabeni ezifanele zesithombe, kanti ikhodi nedatha evela ku-rsend.o iba ngeyokugcina.
// Lo mphumela ungasetshenziswa ukubeka izimpawu ekuqaleni noma ekugcineni kwesigaba, kanye nokufaka noma yiziphi izihloko noma onyaweni abadingekayo.
//
// Qaphela ukuthi iphoyinti lokungena lemodyuli likhona entweni yokuqalisa yesikhathi sokuqalisa engu-C (imvamisa ebizwa ngokuthi yi-`crtX.o`), ebese incenga izingqalasizinda zokuqalisa zezinye izinto zesikhathi sokusebenza (ezibhaliswe ngenye ingxenye yesithombe ekhethekile).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Amamaki aqala esigabeni solwazi lwesitaki sokuphumula
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch space for unwinder yangaphakathi yokugcina incwadi.
    // Lokhu kuchazwa njenge-`struct object` ku-$ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Susa umoya imikhuba ye-registration/deregistration.
    // Bona amadokhumenti e-libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // bhalisa imininingwane yokuphumula ekuqaleni kwesimo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // susa ukubhaliswa ekuvaleni
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Ukubhaliswa okujwayelekile kwe-MinGW init/uninit
    pub mod mingw_init {
        // Izinto zokuqalisa zeMinGW (crt0.o/dllcrt0.o) zizonxenxa abakhi bomhlaba wonke ezigabeni ze .ctors ne .dtors ekuqaleni nasekuphumeni.
        // Endabeni yama-DLL, lokhu kwenziwa lapho i-DLL ilayishwa futhi ilayishwa.
        //
        // I-linker izohlunga izigaba, eziqinisekisa ukuthi ama-callbacks ethu atholakala ekugcineni kohlu.
        // Njengoba abakhi beqhutshwa ngokulandelana okuphambene, lokhu kuqinisekisa ukuthi ama-callbacks ethu angabokuqala nabokugcina ababulawa.
        //
        //

        #[link_section = ".ctors.65535"] // . odokotela. *: C ukuqaliswa kokubuyiselwa emuva
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C ukuqeda izingcingo emuva
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}