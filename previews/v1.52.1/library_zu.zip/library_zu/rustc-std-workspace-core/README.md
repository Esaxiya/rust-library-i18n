# I `rustc-std-workspace-core` crate

Le crate iyi-shim futhi ayinalutho i crate okuncike nje ku `libcore` bese iphinda ithengisa kabusha konke okuqukethwe kuyo.
I-crate yi-crux yokunika amandla umtapo wezincwadi ojwayelekile ukuze uncike ku-crates kusuka ku-crates.io

I-Crates ku-crates.io ukuthi umtapo wezincwadi ojwayelekile uncike esidingweni sokuncika ku-`rustc-std-workspace-core` crate kusuka ku-crates.io, engenalutho.

Sisebenzisa i-`[patch]` ukuyikhipha kule crate kule ndawo yokugcina izinto.
Njengomphumela, i-crates ku-crates.io izodonsa ukuncika kwe-edge kuya ku-`libcore`, inguqulo echazwe kuleli khosombe.
Lokho kufanele kudwebe yonke imiphetho yokuncika ukuqinisekisa ukuthi i Cargo yakha i crates ngempumelelo!

Qaphela ukuthi i-crates ku-crates.io idinga ukuncika kule crate enegama le-`core` ukuze yonke into isebenze kahle.Ukwenza lokho abangakusebenzisa:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ngokusebenzisa ukhiye we-`package` i-crate iqanjwe kabusha ibe yi-`core`, okusho ukuthi izobukeka

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

lapho i-Cargo icela umhlanganisi, yanelisa ukuqondiswa okusobala kwe-`extern crate core` okujojowe ngumhlanganisi.




