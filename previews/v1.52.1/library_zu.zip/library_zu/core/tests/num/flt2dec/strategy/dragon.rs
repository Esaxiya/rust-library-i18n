use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // UMiri uhamba kancane
fn exact_sanity_test() {
    // Lokhu kuhlolwa kugcina kusebenza engingacabanga ukuthi kuyicala elithile lekhoneni lomsebenzi welabhulali ye-`exp2`, echazwe kunoma yisiphi isikhathi sokusebenza kwe-C esisisebenzisayo.
    // Ku-VS 2013 lo msebenzi ngokusobala ubenenkinga njengoba lokhu kuhlolwa kwehluleka lapho kuxhunyaniswa, kepha nge-VS 2015 isiphazamisi sibonakala silungisiwe njengoba isivivinyo sihamba kahle.
    //
    // Isiphazamisi sibonakala sihlukile kunani lokubuyisa le-`exp2(-1057)`, lapho ku-VS 2013 ibuyisa okuphindwe kabili ngephethini ye-bit 0x2 kuthi ku-VS 2015 ibuyise i 0x20000.
    //
    //
    // Okwamanje vele ungakunaki lokhu kuhlolwa ngokuphelele ku-MSVC njengoba kuhlolwe kwenye indawo noma kunjalo futhi asinantshisekelo enkulu ekuhloleni ukuqaliswa kwe-exp2 ngayinye yesikhulumi.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}