use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Le akuyona indawo ezinzile, kepha isiza ukugcina i-`?` ishibhile phakathi kwabo, noma ngabe i-LLVM ingakwazi ukusizakala ngaso sonke isikhathi njengamanje.
    //
    // (Umphumela odabukisayo nenketho akuhambelani, ngakho-ke i-ControlFlow ayikwazi ukufanisa zombili.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}