//! Ukusekelwa kwe-Panic kwe-libcore
//!
//! Umtapo wezincwadi oyinhloko awunakukuchaza ukwethuka, kepha kuyasho * ukumemezela ukwethuka.
//! Lokhu kusho ukuthi imisebenzi engaphakathi kwe-libcore ivunyelwe ku-panic, kepha ukuze ibe wusizo i-crate enyukayo kumele ichaze ukwethuka kwe-libcore ukuze isetshenziswe.
//! I-interface yamanje yokwethuka yile:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Le ncazelo ivumela ukwethuka nganoma yimuphi umyalezo ojwayelekile, kepha ayikuvumeli ukwehluleka ngenani le-`Box<Any>`.
//! (I-`PanicInfo` iqukethe nje i-`&(dyn Any + Send)`, esigcwalisela kuyo inani ledummy ku-`PanicInfo: : internal_constructor`.) Isizathu salokhu ukuthi i-libcore ayivunyelwe ukwaba.
//!
//!
//! Le mojula iqukethe eminye imisebenzi embalwa yokwethusa, kepha lezi yizinto nje ezidingekayo ze-lang zomhlanganisi.Onke ama-panics afakwa kulo msebenzi owodwa.
//! Uphawu lwangempela lumenyezelwa ngemfanelo ye-`#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Ukusetshenziswa okuyisisekelo kwe-XcoreX macro ye-libcore lapho kungekho ukufometha okusetshenziswayo.
#[cold]
// ungalokothi ulayini ngaphandle kokuthi panic_immediate_abort ukugwema ukuqunjelwa kwekhodi kumasayithi wezingcingo ngangokunokwenzeka
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // idingwa yi-codegen ye-panic ekuchichimeni nakwamanye amathemu we-`Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Sebenzisa i-Arguments::new_v1 esikhundleni se-format_args! ("{}", Expr) ukuze wehlise ubukhulu bokusayizi ngaphezulu.
    // I-format_args!I-macro isebenzisa i-str's Display trait ukubhala i-expr, ebiza i-Formatter::pad, okumele ifake i-truncation ye-string ne-padding (noma kungekho okusetshenziswe lapha).
    //
    // Sebenzisa i-Arguments::new_v1 kungavumela umhlanganisi ukuthi ashiye i-Formatter::pad kokukhipha kanambambili, kulondolozwa kufinyelela kuma-kilobytes ambalwa.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // kuyadingeka ku-panics ehlolwe yi-const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // idinga i-codegen ye panic ekufinyeleleni kwe-OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Ukuqaliswa okuyisisekelo kwe-libcore's `panic!` macro lapho kusetshenziswa ukufomatha.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // QAPHELA Lo msebenzi awudluli umngcele we-FFI;kuyikholi ye-Rust-to-Rust exazululwa emsebenzini we-`#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // UKUPHEPHA: I-`panic_impl` ichazwa ngekhodi ye Rust ephephile ngakho-ke kuphephile ukuyishayela.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Umsebenzi wangaphakathi we-`assert_eq!` ne-`assert_ne!` macros
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}