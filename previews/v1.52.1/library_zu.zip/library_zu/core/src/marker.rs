//! I-Primitive traits nezinhlobo ezimele izakhiwo eziyisisekelo zezinhlobo.
//!
//! Izinhlobo ze-Rust zingahlukaniswa ngezindlela ezahlukahlukene eziwusizo ngokusho kwezakhiwo zazo zangaphakathi.
//! Lokhu kuhlukaniswa kumelwe njenge traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Izinhlobo ezingadluliselwa ngaphesheya kwemingcele yochungechunge.
///
/// Le trait isetshenziswa ngokuzenzakalela lapho umhlanganisi enquma ukuthi kufanelekile.
///
/// Isibonelo sohlobo olungelona olungu-`Send` yisikhombi sokubala inkomba [`rc::Rc`][`Rc`].
/// Uma imicu emibili izama ukuhlanganisa [`Rc`] s leyo ekhomba kunani elifanayo elibalwe yireferensi, bangazama ukubuyekeza inani lesethenjwa ngasikhathi sinye, okuyi-[undefined behavior][ub] ngoba i-[`Rc`] ayisebenzisi ukusebenza kwe-athomu.
///
/// Umzala wakhe u-[`sync::Arc`][arc] usebenzisa ukusebenza kwe-athomu (okuhlasela ngaphezulu) ngakho-ke yi-`Send`.
///
/// Bona i [the Nomicon](../../nomicon/send-and-sync.html) ukuthola eminye imininingwane.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Izinhlobo ezinosayizi ojwayelekile owaziwa ngesikhathi sokuhlanganiswa.
///
/// Yonke imingcele yohlobo inesibopho se-`Sized` ngokuphelele.I-syntax ekhethekile i-`?Sized` ingasetshenziselwa ukususa lesi sibopho uma kungafanele.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // isakhiwo FooUse(Foo<[i32]>);//iphutha: Usayizi awusetshenziswanga ku-[i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Okukodwa okuhlukile uhlobo lwe-`Self` lwe-trait.
/// I-trait ayinayo i-`Sized` eboshiwe njengoba lokhu kungahambelani ne-[trait object] lapho, ngencazelo, i-trait idinga ukusebenzisana nabo bonke abaqalisi abangaba khona, futhi ngaleyo ndlela ingaba yinoma yimuphi usayizi.
///
///
/// Yize i-Rust izokuvumela ukuthi ubophe i-`Sized` ku-trait, ngeke ukwazi ukuyisebenzisa ukuze wakhe into ye trait ngokuhamba kwesikhathi:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ake y: &dyn Bar= &Impl;//iphutha: i-trait `Bar` ayinakwenziwa into
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // Okokuzenzakalelayo, ngokwesibonelo, okudinga ukuthi i `[T]: !Default` ihlolwe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Izinhlobo ezingaba yi-"unsized" ohlotsheni olunamandla amakhulu.
///
/// Isibonelo, uhlobo lwamalungu afanayo we-`[i8; 2]` lusebenzisa i-`Unsize<[i8]>` ne-`Unsize<dyn fmt::Debug>`.
///
/// Konke ukusetshenziswa kwe `Unsize` kunikezwa ngokuzenzakalela ngumhlanganisi.
///
/// `Unsize` isetshenziselwa:
///
/// - `[T; N]` ingu-`Unsize<[T]>`
/// - `T` ngu `Unsize<dyn Trait>` lapho i `T: Trait`
/// - `Foo<..., T, ...>` ngu `Unsize<Foo<..., U, ...>>` uma:
///   - `T: Unsize<U>`
///   - UFoo uyisakhiwo
///   - Inkambu yokugcina ye-`Foo` kuphela enohlobo olufaka i-`T`
///   - `T` akuyona ingxenye yohlobo lweminye imikhakha
///   - `Bar<T>: Unsize<Bar<U>>`, uma inkambu yokugcina ye `Foo` inohlobo `Bar<T>`
///
/// `Unsize` isetshenziswa kanye ne-[`ops::CoerceUnsized`] ukuvumela iziqukathi ze-"user-defined" ezinjenge-[`Rc`] ukuthi ziqukathe izinhlobo ezinosayizi onamandla.
/// Bona i [DST coercion RFC][RFC982] ne [the nomicon entry on coercion][nomicon-coerce] ukuthola eminye imininingwane.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// I-trait edingekayo yezingqinamba ezisetshenziswe kumeshi yephethini.
///
/// Noma yiluphi uhlobo oluthola i-`PartialEq` lusebenzisa ngokuzenzakalela le trait,*kungakhathalekile* ukuthi ingabe amapharamitha alo wohlobo ayayisebenzisa yini i `Eq`.
///
/// Uma into engu-`const` iqukethe uhlobo oluthile olungasebenzisi le trait, lolo hlobo noma i-(1.) alusebenzisi i-`PartialEq` (okusho ukuthi okuqhubekayo ngeke kunikeze leyo ndlela yokuqhathanisa, ekhishwa yikhodi etholakalayo), noma i-(2.) isebenzisa *eyayo* Uhlobo lwe-`PartialEq` (esicabanga ukuthi aluhambelani nokuqhathanisa kwesakhiwo).
///
///
/// Kuzo zombili lezi zimo ezingenhla, siyakwenqaba ukusetshenziswa kokufana okunjalo kumeshi wephethini.
///
/// Bona futhi i [structural match RFC][RFC1445], ne [issue 63438] okukhuthaze ukufuduka kusuka ekwakhiweni okususelwa kumfanelo kuye kule trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// I-trait edingekayo yezingqinamba ezisetshenziswe kumeshi yephethini.
///
/// Noma yiluphi uhlobo oluthola i-`Eq` lusebenzisa ngokuzenzakalela le trait,*kungakhathalekile* ukuthi ngabe amapharamitha ohlobo lwayo ayayisebenzisa yini i `Eq`.
///
/// Lokhu kuwukukhohlisa ukusebenza ngokuzungeza ohlelweni lwethu lohlobo.
///
/// # Background
///
/// Sifuna ukufuna ukuthi izinhlobo zama-consts ezisetshenziswe ekufanisweni kwephethini zinemfanelo `#[derive(PartialEq, Eq)]`.
///
/// Ezweni elihle ngokwengeziwe, singabheka leyo mfuneko ngokubheka nje ukuthi uhlobo olunikeziwe lusebenzisa i-`StructuralPartialEq` trait *kanye* ne-`Eq` trait.
/// Kodwa-ke, ungaba nama-ADTs enza * i-`derive(PartialEq, Eq)`, futhi ube yicala esifuna ukuthi umhlanganisi alamukele, kepha nokho uhlobo lokuhlala njalo luyahluleka ukusebenzisa i-`Eq`.
///
/// Okungukuthi, icala elifana naleli:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Inkinga kule khodi engenhla ukuthi i `Wrap<fn(&())>` ayisebenzisi i `PartialEq`, noma i `Eq`, ngoba `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Ngakho-ke, asikwazi ukuthembela ekuhlolweni okungenamqondo kwe `StructuralPartialEq` kanye ne `Eq` nje.
///
/// Njengokweqa ukusebenza ngalokhu, sisebenzisa i traits ezimbili ezijojowe ngakunye kokutholakala kwe (`#[derive(PartialEq)]` ne `#[derive(Eq)]`) bese ubheka ukuthi zombili lezi ziyingxenye yokuhlola ukwakheka komdlalo.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Izinhlobo ezinamanani wazo angaphindwa kabili ngokukopisha izingcezu.
///
/// Ngokuzenzakalelayo, izibopho eziguquguqukayo zine 'move semantics.'Ngamanye amazwi:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ithuthele ku-`y`, ngakho-ke ayinakusetshenziswa
///
/// // println! ("{: ?}", x);//iphutha: ukusetshenziswa kwenani elihanjisiwe
/// ```
///
/// Kodwa-ke, uma uhlobo lusebenzisa i-`Copy`, kunalokho ine-'copy semantics':
///
/// ```
/// // Singathola ukusetshenziswa kwe-`Copy`.
/// // `Clone` kuyadingeka, njengoba kungumfanekiso omkhulu we-`Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` yikhophi ye `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Kubalulekile ukuthi wazi ukuthi kulezi zibonelo ezimbili, umehluko kuphela ukuthi uvunyelwe yini ukufinyelela ku-`x` ngemuva kwesabelo.
/// Ngaphansi kwe-hood, kokubili ikhophi nokuhamba kungaholela ekutheni izingcezu zikopishwe kwimemori, yize lokhu kwesinye isikhathi kulungiselelwa kude.
///
/// ## Ngingayisebenzisa kanjani i `Copy`?
///
/// Kunezindlela ezimbili zokusebenzisa i-`Copy` kuhlobo lwakho.Okulula kakhulu ukusebenzisa i `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ungasebenzisa futhi i-`Copy` ne-`Clone` ngesandla:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Kunomehluko omncane phakathi kwalokhu okubili: isu le `derive` lizophinde libeke i-`Copy` eboshwe ngamapharamitha wohlobo, angafuneki njalo.
///
/// ## Uyini umehluko phakathi kwe `Copy` ne `Clone`?
///
/// Amakhophi enzeka ngokuphelele, ngokwesibonelo njengengxenye yesabelo `y = x`.Ukuziphatha kwe `Copy` akulayishwa ngokweqile;ihlala iyikhophi elula ehlakaniphile.
///
/// Ukwenza i-Cloning isenzo esicacile, i-`x.clone()`.Ukuqaliswa kwe [`Clone`] kunganikeza noma yikuphi ukuziphatha okuqondene nohlobo okudingekayo ukuphinda amanani ngokuphepha.
/// Isibonelo, ukusetshenziswa kwe-[`Clone`] kwe-[`String`] kudinga ukukopisha i-buffer ekhonjiswe ngentambo enqwabeni.
/// Ikhophi elula elula yamanani we-[`String`] izomane ikopishe isikhombisi, okuholele ekukhululekeni okuphindwe kabili phansi kolayini.
/// Ngalesi sizathu, i-[`String`] iyi-[`Clone`] kepha hhayi i-`Copy`.
///
/// [`Clone`] i-supertrait enkulu ye-`Copy`, ngakho-ke konke okuyi-`Copy` kufanele futhi kusebenze i-[`Clone`].
/// Uma uhlobo luyi-`Copy` ukusetshenziswa kwalo kwe-[`Clone`] kudinga kuphela ukubuyisa i-`*self` (bona isibonelo esingenhla).
///
/// ## Uhlobo lwami lungaba nini i `Copy`?
///
/// Uhlobo lungasebenzisa i-`Copy` uma zonke izinto zalo zisebenzisa i-`Copy`.Isibonelo, lesi sakhiwo singaba yi-`Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Isakhiwo singaba yi-`Copy`, kuthi i-[`i32`] ibe yi-`Copy`, ngakho-ke i-`Point` iyafaneleka ukuba yi-`Copy`.
/// Ngokuphambene, cabanga
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Isakhiwo `PointList` asikwazi ukusebenzisa i `Copy`, ngoba i [`Vec<T>`] akuyona i `Copy`.Uma sizama ukuthola ukusetshenziswa kwe-`Copy`, sizothola iphutha:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Izinkomba ezabiwe (`&T`) nazo ziyi-`Copy`, ngakho-ke uhlobo lungaba yi-`Copy`, noma ngabe iphethe izinkomba ezabiwe zezinhlobo `T` ezingezona * i `Copy`.
/// Cabanga nge-struct elandelayo, engasebenzisa i-`Copy`, ngoba kuphela iphethe *ireferensi eyabiwe* kuhlobo lwethu lwe-non-`Copy` `PointList` kusuka phezulu:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Ngabe uhlobo * lwami alikwazi ukuba yi `Copy`?
///
/// Ezinye izinhlobo azikwazi ukukopishwa ngokuphepha.Isibonelo, ukukopisha i-`&mut T` kuzodala ireferensi enokuguquguquka engabizi.
/// Ukukopisha i-[`String`] kuzophinda umthwalo ophindaphindiwe wokuphatha ibhafa ye-[`String`], okuholele ekukhululekeni okuphindwe kabili.
///
/// Ukwenza icala lakamuva, noma yiluphi uhlobo olusebenzisa i-[`Drop`] ngeke kube yi-`Copy`, ngoba lilawula insiza ethile ngaphandle kwama-byte alo e-[`size_of::<T>`].
///
/// Uma uzama ukusebenzisa i-`Copy` kusakhiwo noma i-enum equkethe idatha engeyona eye-`Copy`, uzothola iphutha i-[E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Ngabe * uhlobo lwami kufanele lube yi `Copy`?
///
/// Ngokuvamile, uma uhlobo lwakho lwe-_can_ lusebenzisa i-`Copy`, kufanele.
/// Khumbula, noma kunjalo, ukuthi ukusebenzisa i-`Copy` kuyingxenye ye-API yomphakathi yohlobo lwakho.
/// Uma uhlobo lungahle lube yi-`Copy` ku-future, kungaba ukuhlakanipha ukushiya ukuqaliswa kwe-`Copy` manje, ukugwema ukushintsha kwe-API.
///
/// ## Abaqalisi abengeziwe
///
/// Ngaphezu kwe-[implementors listed below][impls], izinhlobo ezilandelayo nazo zisebenzisa i-`Copy`:
///
/// * Izinhlobo zezinto zomsebenzi (okungukuthi, izinhlobo ezihlukile ezichazwe ngomsebenzi ngamunye)
/// * Izinhlobo zesikhombi somsebenzi (isb. `fn() -> i32`)
/// * Izinhlobo ze-Array, zawo wonke amasayizi, uma uhlobo lwento nalo lusebenzisa i-`Copy` (isb., `[i32; 123456]`)
/// * Izinhlobo zeTuple, uma into ngayinye nayo isebenzisa i `Copy` (isb., `()`, `(i32, bool)`)
/// * Izinhlobo zokuvalwa, uma zingabambi inani emvelweni noma uma wonke amanani anjalo atholakele esebenzisa i `Copy` uqobo.
///   Qaphela ukuthi okuguquguqukayo okufakwe kusethenjwa okwabiwe ngaso sonke isikhathi kusebenzisa i-`Copy` (noma ngabe okuqondiswayo kungakwenzi), kuyilapho okuguquguqukayo okuthathwe yisethenjwa esiguquguqukayo kungasebenzisi i `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Lokhu kuvumela ukukopisha uhlobo olungasebenzisi i-`Copy` ngenxa yemingcele yokuphila enganelisekile (ukukopisha i-`A<'_>` lapho kungu-`A<'static>: Copy` no-`A<'_>: Clone` kuphela).
// Le mfanelo sinayo lapha okwamanje ngoba kunezici ezimbalwa ezikhona ku `Copy` esevele zikhona kumtapo wezincwadi ojwayelekile, futhi ayikho indlela yokuba nalokhu kuziphatha ngokuphepha njengamanje.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// IDerive macro edala ukufakwa kwe trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Izinhlobo okuphephe kuzo ukwabelana ngezinkomba phakathi kwemicu.
///
/// Le trait isetshenziswa ngokuzenzakalela lapho umhlanganisi enquma ukuthi kufanelekile.
///
/// Incazelo eqondile yile: uhlobo `T` ngu-[`Sync`] uma futhi kuphela uma i-`&T` iyi-[`Send`].
/// Ngamanye amagama, uma ingekho i-[undefined behavior][ub] (kufaka phakathi imijaho yedatha) lapho kudluliswa izinkomba ze-`&T` phakathi kwemicu.
///
/// Njengoba umuntu angalindela, izinhlobo zakudala ezinjenge-[`u8`] ne-[`f64`] zonke ziyi-[`Sync`], futhi kanjalo nezinhlobo ezilula ezihlanganisiwe eziqukethe, njengezimpuphu, ama-structs kanye nama-enum.
/// Izibonelo eziningi zezinhlobo eziyisisekelo ze-[`Sync`] zifaka izinhlobo ze-"immutable" njenge-`&T`, nalabo abanokuguquguquka okulula okuzuzwe njengefa, njenge-[`Box<T>`][box], [`Vec<T>`][vec] nezinye izinhlobo eziningi zokuqoqwa.
///
/// (Amapharamitha ejwayelekile adinga ukuba yi-[`Sync`] ukuze isitsha sawo sibe [`Vumelanisa`].)
///
/// Umphumela othusayo wencazelo ukuthi i `&mut T` iyi-`Sync` (uma i-`T` iyi-`Sync`) noma kubonakala sengathi lokho kunganikeza ukuguqulwa okungavumelanisiwe.
/// Icebo ukuthi isethenjwa esiguquguqukayo ngemuva kwesethenjwa esabiwe (okungukuthi, i-`& &mut T`) sifundwa kuphela, kube sengathi yi-`& &T`.
/// Ngakho-ke abukho ubungozi bomjaho wedatha.
///
/// Izinhlobo ezingezona i-`Sync` yilezo ezine-"interior mutability" ngendlela engaphephile yentambo, njenge-[`Cell`][cell] ne-[`RefCell`][refcell].
/// Lezi zinhlobo zivumela ukuguqulwa kokuqukethwe kwazo ngisho nangesithenjwa esingaguquguquki, esabiwe.
/// Isibonelo indlela ye-`set` ku-[`Cell<T>`][cell] ithatha i-`&self`, ngakho-ke idinga kuphela ireferensi eyabiwe [`&Cell<T>`][cell].
/// Le ndlela ayenzi ukuvumelanisa, ngakho-ke i-[`Cell`][cell] ayinakuba yi-`Sync`.
///
/// Esinye isibonelo sohlobo olungelona olungu-`Sync` yisikhombi sokubala inkomba [`Rc`][rc].
/// Njengoba unikezwe noma iyiphi i-[`&Rc<T>`][rc], ungabumba i-[`Rc<T>`][rc] entsha, uguqule ukubalwa kwesethenjwa ngendlela engeyona eye-athomu.
///
/// Ezimweni lapho umuntu edinga ukuguquguquka kwangaphakathi okuphephe ngentambo, i-Rust inikeza i-[atomic data types], kanye nokukhiya okucacile nge-[`sync::Mutex`][mutex] ne-[`sync::RwLock`][rwlock].
/// Lezi zinhlobo ziqinisekisa ukuthi noma yikuphi ukuguquka kwezakhi ngeke kubangele imijaho yedatha, yingakho izinhlobo zingu-`Sync`.
/// Ngokufanayo, i-[`sync::Arc`][arc] inikeza i-analogue ephephile ye-[`Rc`][rc].
///
/// Noma iziphi izinhlobo ezinokuguquguquka kwangaphakathi kufanele futhi zisebenzise i-[`cell::UnsafeCell`][unsafecell] wrapper ezungeze i-value(s) engaguqulwa ngesethenjwa esabiwe.
/// Ukwehluleka ukwenza lokhu yi-[undefined behavior][ub].
/// Isibonelo, [`transmute`][transmute]-ing kusuka ku-`&T` kuye ku-`&mut T` akuvumelekile.
///
/// Bona i [the Nomicon][nomicon-send-and-sync] ukuthola eminye imininingwane nge `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kanye ukusekelwa ukwengeza amanothi emazweni we-`rustc_on_unimplemented` ku-beta, futhi kunwetshiwe ukubheka ukuthi ukuvalwa kukhona noma yikuphi kuketanga lwezidingo, kunwebe kanjalo (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Uhlobo olulingana noZero olusetshenziselwe ukumaka izinto ukuthi i-"act like" zine-`T`.
///
/// Ukungeza inkambu ye-`PhantomData<T>` kuhlobo lwakho kutshela umhlanganisi ukuthi uhlobo lwakho lusebenza ngokungathi lugcina inani lohlobo `T`, noma kungenjalo empeleni.
/// Lolu lwazi lusetshenziswa lapho kufakwa izici ezithile zokuphepha.
///
/// Ukuthola incazelo ejulile yokuthi uyisebenzisa kanjani i-`PhantomData<T>`, sicela ubone i [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Inothi elibuhlungu 👻👻👻
///
/// Yize bobabili benamagama asabekayo, i-`PhantomData` kanye 'nezinhlobo ze-phantom' zihlobene, kepha azifani.Ipharamitha yohlobo lwe-phantom imane nje yipharamitha yohlobo engakaze isetshenziswe.
/// Ku-Rust, lokhu kuvame ukudala ukuthi umhlanganisi akhononde, futhi isixazululo ukwengeza ukusetshenziswa kwe "dummy" ngendlela ye `PhantomData`.
///
/// # Examples
///
/// ## Amapharamitha wempilo angasetshenziswanga
///
/// Mhlawumbe icala elisetshenziswa kakhulu le-`PhantomData` isakhiwo esinepharamitha yokuphila engasetshenziswanga, imvamisa njengengxenye yekhodi ethile engaphephile.
/// Isibonelo, nayi i-`Slice` enezikhombisi ezimbili zohlobo `*const T`, okungenzeka ikhombe kumalungu afanayo kwenye indawo:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Inhloso ukuthi idatha eyisisekelo isebenza kuphela ku-`'a` yempilo yonke, ngakho-ke i-`Slice` akufanele idlule i-`'a`.
/// Kodwa-ke, le nhloso ayivezwanga kukhodi, ngoba akukho ukusetshenziswa kwempilo ye `'a` ngakho-ke akucaci ukuthi isebenza kuphi idatha.
/// Singakulungisa lokhu ngokutshela umhlanganisi ukuthi enze * sengathi i-`Slice` struct iqukethe inkomba `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Lokhu futhi kudinga isichasiselo `T: 'a`, okukhombisa ukuthi noma yiziphi izinkomba ku `T` zivumelekile esikhathini sempilo i `'a`.
///
/// Lapho uqala i-`Slice` umane unikeze inani le-`PhantomData` lenkambu `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Amapharamitha wohlobo olungasetshenzisiwe
///
/// Kwenzeka kwesinye isikhathi ukuthi unamapharamitha wohlobo olungasetshenziswanga akhombisa ukuthi hlobo luni lwedatha i-struct eyi-"tied" kuye, noma leyo datha ingatholakali empeleni kusakhiwo uqobo.
/// Nasi isibonelo lapho lokhu kuvela nge [FFI].
/// I-interface yangaphandle isebenzisa izibambo zohlobo `*mut ()` ukubhekisa kumanani we-Rust ezinhlobo ezahlukene.
/// Silandelela uhlobo lwe-Rust sisebenzisa ipharamitha yohlobo lwe-phantom ku-X `ExternalResource` esonga isibambo.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ubunikazi nesheke lokwehla
///
/// Ukungeza inkambu yohlobo `PhantomData<T>` kukhombisa ukuthi uhlobo lwakho luphethe idatha yohlobo `T`.Lokhu futhi kusho ukuthi lapho uhlobo lwakho lwehliswa, lungahle lwehle izehlakalo esisodwa noma eziningi zohlobo `T`.
/// Lokhu kuthinta ukuhlaziywa kwe-[drop check] komhlanganisi we-Rust.
///
/// Uma i-struct yakho empeleni ingenayo *idatha yohlobo `T`, kungcono ukusebenzisa uhlobo lwesethenjwa, njenge-`PhantomData<&'a T>` (ideally) noma i-`PhantomData<* const T>` (uma kungekho sikhathi sokuphila esisebenzayo), ukuze ungakhombisi ubunikazi.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// I-compiler-internal trait isetshenziselwe ukukhombisa uhlobo lwe-enum discriminators.
///
/// Le trait isetshenziswa ngokuzenzakalela ngayo yonke inhlobo futhi ayifaki iziqinisekiso ku-[`mem::Discriminant`].
/// Kuyindlela **engachazwanga** ukudlulisa phakathi kwe `DiscriminantKind::Discriminant` ne `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Uhlobo lobandlululo, okumele lwanelise i-trait bounds edingwa yi-`mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// I-compiler-internal trait isetshenziselwe ukuthola ukuthi ngabe uhlobo luqukethe i-`UnsafeCell` ngaphakathi, kepha hhayi nge-indirection.
///
/// Lokhu kuthinta, isibonelo, noma ngabe i-`static` yalolo hlobo ibekwe kwimemori engaguquki yokufunda kuphela noma kwimemori ye-static ebhaliwe.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Izinhlobo ezingasuswa ngokuphepha ngemuva kokuphinwa.
///
/// I-Rust uqobo ayinayo imibono yezinhlobo ezinganyakaziseki, futhi ibheka ukuhamba (isb. Ngokunikezwa noma nge-[`mem::replace`]) ukuthi kuphephe njalo.
///
/// Uhlobo lwe [`Pin`][Pin] luyasetshenziswa esikhundleni salokho ukuvikela ukuhamba ngohlelo lohlobo.Ama-pointers `P<T>` asongwe nge-[`Pin<P<T>>`][Pin] wrapper awakwazi ukukhishwa kuwo.
/// Bona imibhalo ye [`pin` module] ukuthola eminye imininingwane ngokuphina.
///
/// Ukusebenzisa i-`Unpin` trait ye `T` kuphakamisa imikhawulo yokuphina uhlobo, okuvumela ukuhambisa i `T` ngaphandle kwe [`Pin<P<T>>`][Pin] ngemisebenzi efana ne [`mem::replace`].
///
///
/// `Unpin` ayinamphumela nhlobo kwimininingwane engaphiniwe.
/// Ikakhulu, i-[`mem::replace`] ihambisa ngenjabulo idatha ye-`!Unpin` (isebenza kunoma iyiphi i-`&mut T`, hhayi lapho i-`T: Unpin` kuphela).
/// Kodwa-ke, awukwazi ukusebenzisa i-[`mem::replace`] kudatha ehlanganiswe ngaphakathi kwe-[`Pin<P<T>>`][Pin] ngoba awukwazi ukuthola i-`&mut T` oyidingayo yalokho, futhi * yilokho okwenza lolu hlelo lusebenze.
///
/// Ngakho-ke lokhu, ngokwesibonelo, kungenziwa kuphela ezinhlotsheni ezisebenzisa i-`Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Sidinga ireferensi enokuguquguquka ukubiza i-`mem::replace`.
/// // Singathola ireferensi enjalo nge-(implicitly) efaka i-`Pin::deref_mut`, kepha lokho kungenzeka kuphela ngoba i-`String` isebenzisa i-`Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Le trait isetshenziswa ngokuzenzakalela cishe lonke uhlobo.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Uhlobo lomaka olungasebenzisi i-`Unpin`.
///
/// Uma uhlobo luqukethe i-`PhantomPinned`, ngeke isebenzise i-`Unpin` ngokuzenzakalela.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Ukuqaliswa kwe `Copy` yezinhlobo zasendulo.
///
/// Ukusebenza okungeke kuchazwe ku-Rust kwenziwa ku-`traits::SelectionContext::copy_clone_conditions()` ku-`rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Izinkomba ezabiwe zingakopishwa, kepha izinkomba eziguqukayo *azikwazi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}