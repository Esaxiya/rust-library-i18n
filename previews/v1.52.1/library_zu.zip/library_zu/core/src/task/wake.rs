#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// I-`RawWaker` ivumela umqalisi womphathi womsebenzi ukuthi enze i-[`Waker`] enikezela ngokuziphatha kokuvuka okwenziwe ngokwezifiso.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Inesikhombi sedatha ne-[virtual function pointer table (vtable)][vtable] eyenza ngokwezifiso ukusebenza kwe `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Isikhombi sedatha, esingasetshenziswa ukugcina idatha engqubuzanayo njengoba kudingwa ngumabi wefa.
    /// Lokhu kungaba isib
    /// i-pointer esuswe ngohlobo eya ku-`Arc` ehlotshaniswa nomsebenzi.
    /// Inani lale nkambu lidluliselwa kuyo yonke imisebenzi eyingxenye ye-vtable njengepharamitha yokuqala.
    ///
    data: *const (),
    /// Ithebula lesikhombi somsebenzi we-Virtual elenza ngendlela oyifisayo ukusebenza kwalesi siphaphama.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Idala i-`RawWaker` entsha kusuka kusikhombi esihlinzekiwe se-`data` ne-`vtable`.
    ///
    /// Isikhombi se `data` singasetshenziswa ukugcina idatha engqubuzanayo njengoba kudingwa ngumabi wefa.Lokhu kungaba isib
    /// i-pointer esuswe ngohlobo eya ku-`Arc` ehlotshaniswa nomsebenzi.
    /// Inani lalesi sikhombi lizodluliselwa kuyo yonke imisebenzi eyingxenye ye-`vtable` njengepharamitha yokuqala.
    ///
    /// I-`vtable` yenza ngokwezifiso ukusebenza kwe-`Waker` edalwa kusuka ku-`RawWaker`.
    /// Ekusebenzeni ngakunye kwe-`Waker`, umsebenzi ohambisanayo ku-`vtable` we-`RawWaker` oyisisekelo uzobizwa.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Itafula lesikhombi somsebenzi elibonakalayo (vtable) elicacisa ukusebenza kwe [`RawWaker`].
///
/// Isikhombi esidluliselwe kuyo yonke imisebenzi ngaphakathi kwe-vtable yisikhombi se-`data` kusuka entweni ebiyelwe ye-[`RawWaker`].
///
/// Imisebenzi engaphakathi kwalesi sakhiwo ihloselwe ukubizelwa kusikhombi se-`data` sento eyakhiwe kahle ye-[`RawWaker`] ngaphakathi kokuqaliswa kwe-[`RawWaker`].
/// Ukubiza omunye wemisebenzi equkethwe usebenzisa noma iyiphi enye i-`data` pointer kuzodala ukusebenza okungachazwanga.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Lo msebenzi uzobizwa lapho i-[`RawWaker`] ihlanganiswa, isb. Lapho i-[`Waker`] lapho i-[`RawWaker`] igcinwa khona ihlanganiswa.
    ///
    /// Ukuqaliswa kwalo msebenzi kufanele kugcine zonke izinsizakusebenza ezidingekayo kulesi simo esingeziwe se-[`RawWaker`] nomsebenzi ohambisanayo.
    /// Ukushayela i-`wake` ku-[`RawWaker`] eholelekile kufanele kuholele ekuvukeni komsebenzi ofanayo obekungavuswa yi-[`RawWaker`] yoqobo.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Lo msebenzi uzobizwa lapho i-`wake` ibizwa ku-[`Waker`].
    /// Kufanele ivuse umsebenzi ohambisana nale [`RawWaker`].
    ///
    /// Ukuqaliswa kwalo msebenzi kumele kuqinisekiswe ukukhipha noma yiziphi izinsizakusebenza ezihlotshaniswa nalesi sibonelo se-[`RawWaker`] nomsebenzi ohambisanayo.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Lo msebenzi uzobizwa lapho i-`wake_by_ref` ibizwa ku-[`Waker`].
    /// Kufanele ivuse umsebenzi ohambisana nale [`RawWaker`].
    ///
    /// Lo msebenzi ufana ne-`wake`, kepha akumele usebenzise isikhombisi sedatha esinikeziwe.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Lo msebenzi ubizwa lapho i-[`RawWaker`] yehla.
    ///
    /// Ukuqaliswa kwalo msebenzi kumele kuqinisekiswe ukukhipha noma yiziphi izinsizakusebenza ezihlotshaniswa nalesi sibonelo se-[`RawWaker`] nomsebenzi ohambisanayo.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Idala i-`RawWakerVTable` entsha kusuka kwimisebenzi enikeziwe ye-`clone`, `wake`, `wake_by_ref`, ne-`drop`.
    ///
    /// # `clone`
    ///
    /// Lo msebenzi uzobizwa lapho i-[`RawWaker`] ihlanganiswa, isb. Lapho i-[`Waker`] lapho i-[`RawWaker`] igcinwa khona ihlanganiswa.
    ///
    /// Ukuqaliswa kwalo msebenzi kufanele kugcine zonke izinsizakusebenza ezidingekayo kulesi simo esingeziwe se-[`RawWaker`] nomsebenzi ohambisanayo.
    /// Ukushayela i-`wake` ku-[`RawWaker`] eholelekile kufanele kuholele ekuvukeni komsebenzi ofanayo obekungavuswa yi-[`RawWaker`] yoqobo.
    ///
    /// # `wake`
    ///
    /// Lo msebenzi uzobizwa lapho i-`wake` ibizwa ku-[`Waker`].
    /// Kufanele ivuse umsebenzi ohambisana nale [`RawWaker`].
    ///
    /// Ukuqaliswa kwalo msebenzi kumele kuqinisekiswe ukukhipha noma yiziphi izinsizakusebenza ezihlotshaniswa nalesi sibonelo se-[`RawWaker`] nomsebenzi ohambisanayo.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Lo msebenzi uzobizwa lapho i-`wake_by_ref` ibizwa ku-[`Waker`].
    /// Kufanele ivuse umsebenzi ohambisana nale [`RawWaker`].
    ///
    /// Lo msebenzi ufana ne-`wake`, kepha akumele usebenzise isikhombisi sedatha esinikeziwe.
    ///
    /// # `drop`
    ///
    /// Lo msebenzi ubizwa lapho i-[`RawWaker`] yehla.
    ///
    /// Ukuqaliswa kwalo msebenzi kumele kuqinisekiswe ukukhipha noma yiziphi izinsizakusebenza ezihlotshaniswa nalesi sibonelo se-[`RawWaker`] nomsebenzi ohambisanayo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// I-`Context` yomsebenzi we-asynchronous.
///
/// Njengamanje, i-`Context` isebenza kuphela ukuhlinzeka ukufinyelela ku-`&Waker` engasetshenziselwa ukuvusa umsebenzi wamanje.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Qiniseka ukuthi thina future-ubufakazi obuphikisana nezinguquko ezahlukahlukene ngokuphoqelela isikhathi sempilo ukuba singaguquguquki (isikhathi sokuphila sokuphikisana siphikisana lapho isikhathi sokuphila sesikhundla sokubuyela siphakathi).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Dala i-`Context` entsha kusuka ku-`&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Ibuyisa ireferensi ye-`Waker` ngomsebenzi wamanje.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// I-`Waker` iyisibambo sokuvusa umsebenzi ngokwazisa umenzi wayo ukuthi ikulungele ukusebenza.
///
/// Lesi sibambo sifaka phakathi isibonelo se-[`RawWaker`], esichaza indlela yokuziphatha ekhethekile yomphangi.
///
///
/// Isebenzisa i-[`Clone`], [`Send`], ne-[`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Vusa umsebenzi ohambisana nale `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Ikholi yangempela yokuvuka idluliselwe ngekholi yomsebenzi ebonakalayo ekusetshenzisweni okuchazwa ngumabi wefa.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ungashayi i-`drop`-i-waker izosetshenziswa yi-`wake`.
        crate::mem::forget(self);

        // UKUPHEPHA: Lokhu kuphephile ngoba i `Waker::from_raw` ukuphela kwendlela
        // ukuqalisa i `wake` ne `data` edinga umsebenzisi ukuthi avume ukuthi inkontileka ye `RawWaker` iyagcinwa.
        //
        unsafe { (wake)(data) };
    }

    /// Vusa umsebenzi ohambisana nale `Waker` ngaphandle kokusebenzisa i `Waker`.
    ///
    /// Lokhu kufana ne-`wake`, kepha kungahle kungasebenzi kahle esimweni lapho kutholakala khona i-`Waker`.
    /// Le ndlela kufanele incanyelwe ukubiza i-`waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Ikholi yangempela yokuvuka idluliselwe ngekholi yomsebenzi ebonakalayo ekusetshenzisweni okuchazwa ngumabi wefa.
        //

        // UKUPHEPHA: bheka i `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Ibuyisa i `true` uma le `Waker` nenye i `Waker` zivuse umsebenzi ofanayo.
    ///
    /// Lo msebenzi usebenza ngokuzikhandla okukhulu, futhi ungabuyisa amanga noma ngabe ama-Waker angavusa umsebenzi ofanayo.
    /// Kodwa-ke, uma lo msebenzi ubuyisa i-`true`, kuqinisekisiwe ukuthi ama-Waker azovusa umsebenzi ofanayo.
    ///
    /// Lo msebenzi usetshenziselwa izinhloso zokusebenzisa kahle.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Idala i-`Waker` entsha kusuka ku-[`RawWaker`].
    ///
    /// Ukuziphatha kwe `Waker` ebuyisiwe akucacisiwe uma inkontileka echazwe kumadokhumenti ka-[`RawWaker`] kanye ne-[`RawWakerVTable`] ayigciniwe.
    ///
    /// Ngakho-ke le ndlela ayiphephile.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // UKUPHEPHA: Lokhu kuphephile ngoba i `Waker::from_raw` ukuphela kwendlela
            // ukuqalisa i `clone` ne `data` edinga umsebenzisi ukuthi avume ukuthi inkontileka ye [`RawWaker`] iyagcinwa.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // UKUPHEPHA: Lokhu kuphephile ngoba i `Waker::from_raw` ukuphela kwendlela
        // ukuqalisa i `drop` ne `data` edinga umsebenzisi ukuthi avume ukuthi inkontileka ye `RawWaker` iyagcinwa.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}