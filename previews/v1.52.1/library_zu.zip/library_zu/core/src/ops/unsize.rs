use crate::marker::Unsize;

/// I-Trait ekhombisa ukuthi lesi yisikhombi noma ukugoqa okukodwa, lapho kungenziwa khona unsizing kwipheyinti.
///
/// Bona i [DST coercion RFC][dst-coerce] ne [the nomicon entry on coercion][nomicon-coerce] ukuthola eminye imininingwane.
///
/// Ngezinhlobo zesikhombi se-builtin, izikhombi eziya ku-`T` zizophoqelela izikhombisi eziya ku-`U` uma i-`T: Unsize<U>` ngokuguqula ukusuka kusikhombi esincanyana kuya kwesikhombi esinamafutha.
///
/// Ngezinhlobo zenkambiso, ukuphoqelelwa lapha kusebenza ngokuphoqa i-`Foo<T>` kuye ku-`Foo<U>` inikeze ukufakwa kwe-`CoerceUnsized<Foo<U>> for Foo<T>` kukhona.
/// Ukufakwa okunjalo kungabhalwa kuphela uma i-`Foo<T>` inenkambu eyodwa engeyona i-phantomdata ehilela i-`T`.
/// Uma uhlobo lwenkambu luyi-`Bar<T>`, ukusetshenziswa kwe-`CoerceUnsized<Bar<U>> for Bar<T>` kufanele kube khona.
/// Ukuphoqelela kuzosebenza ngokuphoqelela inkambu ye-`Bar<T>` ku-`Bar<U>` bese ugcwalisa ezinye izinkambu kusuka ku-`Foo<T>` ukudala i-`Foo<U>`.
/// Lokhu kuzokwehlela ngempumelelo enkanjini yesikhombi bese kukuqinisa lokho.
///
/// Ngokuvamile, kwizikhombisi ezihlakaniphile uzosebenzisa i-`CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, nge-`?Sized` yokuzikhethela eboshwe ku-`T` uqobo.
/// Ngezinhlobo ezisongelayo ezishumeka ngqo i `T` njenge `Cell<T>` ne `RefCell<T>`, ungasebenzisa ngqo i `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Lokhu kuzovumela ukuphoqelelwa kwezinhlobo ezinjenge-`Cell<Box<T>>` zisebenze.
///
/// [`Unsize`][unsize] isetshenziselwa ukumaka izinhlobo ezingaphoqelelwa kuma-DSTs uma ngemuva kwezikhombi.Kwenziwa ngokuzenzakalela ngumhlanganisi.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Lokhu kusetshenziselwa ukuphepha kwento, ukubheka ukuthi uhlobo lwendlela yomamukeli lungathunyelwa kuyo.
///
/// Ukuqaliswa kwesibonelo kwe trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}