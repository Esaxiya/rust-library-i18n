use crate::marker::Unpin;
use crate::pin::Pin;

/// Umphumela wokuqalisa kabusha kwe-generator.
///
/// Le enum ibuyiswa ngendlela ye-`Generator::resume` futhi ikhombisa amanani wokubuya we-generator.
/// Njengamanje lokhu kufana nendawo yokumiswa engu-(`Yielded`) noma indawo yokumisa i-(`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// I-generator imiswe ngenani.
    ///
    /// Lo mbuso ukhombisa ukuthi i-generator imisiwe, futhi ngokujwayelekile iyahambelana nesitatimende se-`yield`.
    /// Inani elihlinzekwe kulokhu okuhlukile lihambelana nesisho esidluliselwe ku-`yield` futhi sivumela ama-generator ukuthi anikeze inani njalo lapho likhiqiza.
    ///
    ///
    Yielded(Y),

    /// I-generator igcwaliswe ngenani lokubuyisa.
    ///
    /// Lesi simo sikhombisa ukuthi i-generator isiqedile ukwenziwa ngenani elinikeziwe.
    /// Lapho i-generator isibuyisile i-`Complete` kuthathwa njengephutha lohlelo ukubiza i-`resume` futhi.
    ///
    Complete(R),
}

/// I-trait isetshenziswe yizinhlobo ze-generator eyakhiwe.
///
/// Ama-generator, nawo abizwa kakhulu ngama-coroutines, njengamanje ayisici solimi sokuhlola ku-Rust.
/// Kungezwe kuma-generator e-[RFC 2033] njengamanje kuhloswe ukuthi kunikeze ngokuyinhloko ibhulokhi yokwakha ye-async/await syntax kepha kungenzeka inwebe futhi ekunikezeni incazelo ye-ergonomic yama-iterators namanye ama-primitives.
///
///
/// I-syntax nama-semantics ama-generator awazinzile futhi azodinga enye i-RFC ukuze kuqiniswe.Ngalesi sikhathi, noma kunjalo, i-syntax ifana nokuvalwa:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Imibhalo eminingi yama-generator ingatholakala encwadini engazinzile.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Uhlobo lwenani olukhiqizwa yile generator.
    ///
    /// Lolu hlobo oluhambisanayo luhambisana nesisho se-`yield` namanani avunyelwe ukuthi abuyiswe isikhathi ngasinye lapho kukhiqizwa i-generator.
    ///
    /// Isibonelo i-iterator-as-a-generator ingahle ibe nalolu hlobo njenge-`T`, uhlobo olushaywayo ngaphezulu.
    ///
    type Yield;

    /// Uhlobo lwenani olubuyiswa yile generator.
    ///
    /// Lokhu kufana nohlobo olubuyiswe luvela ku-generator kungaba ngesitatimende se-`return` noma ngokuphelele njengesisho sokugcina se-generator ngokoqobo.
    /// Isibonelo i-futures izosebenzisa lokhu njenge-`Result<T, E>` njengoba imele i future ephelele.
    ///
    ///
    type Return;

    /// Iqala kabusha ukwenziwa kwale generator.
    ///
    /// Lo msebenzi uzoqala ukwenziwa kwe-generator noma uqale ukwenziwa uma ungakakwenzi.
    /// Le kholi izobuyela endaweni yokugcina yokumisa i-generator, iqale kabusha ukwenziwa kusuka ku-`yield` yakamuva.
    /// I-generator izoqhubeka nokwenza ize iveze noma ibuyise, lapho lo msebenzi uzobuya khona.
    ///
    /// # Buyisela inani
    ///
    /// I-`GeneratorState` enum ebuyisiwe ivela kulo msebenzi ikhombisa ukuthi injani i-generator ekubuyeni kwayo.
    /// Uma okuhlukile kwe-`Yielded` kubuyiswa i-generator ifinyelele endaweni yokumiswa futhi inani likhishiwe.
    /// Ama-generator akulesi sifundazwe ayatholakala ukuze aqale kabusha ngokuhamba kwesikhathi.
    ///
    /// Uma i-`Complete` ibuyisiwe i-generator isiqede ngokuphelele ngenani elinikeziwe.Akuvumelekile ukuthi i-generator iqaliswe futhi.
    ///
    /// # Panics
    ///
    /// Lo msebenzi ungahle ube yi-panic uma ubizwa ngemuva kokuthi ukwahluka kwe-`Complete` kubuyiswe ngaphambilini.
    /// Ngenkathi imibhalo ye-generator ngolimi iqinisekisiwe ku-panic ngokuqalisa kabusha ngemuva kwe-`Complete`, lokhu akuqinisekisiwe kukho konke ukusetshenziswa kwe-`Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}