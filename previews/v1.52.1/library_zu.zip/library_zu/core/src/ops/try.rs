/// I-trait yokwenza ngokwezifiso ukusebenza kwe-`?` opharetha.
///
/// Uhlobo olusebenzisa i-`Try` ngolunye olunendlela ye-canonical yokuyibuka ngokwe-success/failure dichotomy.
/// Le trait ivumela womabili ukukhipha lawo manani empumelelo noma okwehluleka esimweni esivele sikhona futhi adale isibonelo esisha kusuka kunani lempumelelo noma lokwehluleka.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Uhlobo lwaleli nani uma lubhekwa njengoluyimpumelelo.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Uhlobo lwaleli nani uma lubhekwa njengehlulekile.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Kusetshenziswa opharetha we "?".Ukubuyiswa kwe-`Ok(t)` kusho ukuthi ukwenziwa kufanele kuqhubeke ngokujwayelekile, futhi umphumela we-`?` inani le-`t`.
    /// Ukubuyiswa kwe-`Err(e)` kusho ukuthi ukwenziwa kufanele kuthi i branch iye ngaphakathi ngaphakathi kwe-`catch`, noma ibuye emsebenzini.
    ///
    /// Uma umphumela we-`Err(e)` ubuyiswa, inani le-`e` lizoba yi-"wrapped" ngohlobo lokubuyisa lwesilinganiso sokuvala (okumele sona ngokwaso sisebenzise i-`Try`).
    ///
    /// Ngokuqondile, inani le-`X::from_error(From::from(e))` liyabuyiselwa, lapho i-`X` iluhlobo lokubuyisa lomsebenzi ovalekile.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Songa inani lephutha ukwakha umphumela ohlanganisiwe.
    /// Isibonelo, i-`Result::Err(x)` ne-`Result::from_error(x)` ziyalingana.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Songa inani elilungile ukwakha umphumela ohlanganisiwe.
    /// Isibonelo, i-`Result::Ok(x)` ne-`Result::from_ok(x)` ziyalingana.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}