//! Ama-opharetha alayishwa ngokweqile.
//!
//! Ukwenza lezi traits kukuvumela ukuthi ulayishe ngokweqile opharetha abathile.
//!
//! Amanye ama-traits angeniswa yi-prelude, ngakho-ke ayatholakala kuzo zonke izinhlelo ze-Rust.Ama-opharetha asekelwa yi-traits kuphela angalayishwa ngokweqile.
//! Isibonelo, i-opharetha yokufaka i-(`+`) ingalayishwa ngokweqile nge-[`Add`] trait, kepha njengoba opharetha abelwe (`=`) engenayo i-trait esekelayo, ayikho indlela yokulayisha ngokweqile ama-semantics awo.
//! Ngokwengeziwe, le module ayinikezeli nganoma iyiphi indlela yokwenza opharetha abasha.
//! Uma ukulayishwa ngokweqile okungenasici noma opharetha benkambiso kudingeka, kufanele ubheke kuma-macros noma ama-plugins we-compiler ukunweba i-syntax ye Rust.
//!
//! Ukuqaliswa kwe-opharetha i traits kufanele kungamangazi ezimeni zazo, kukhunjulwe izincazelo zazo ezijwayelekile kanye ne [operator precedence].
//! Isibonelo, lapho usebenzisa i-[`Mul`], ukusebenza kufanele kufane nokuphindaphindeka (futhi kwabelane ngezakhiwo ezilindelekile njengokuhlangana).
//!
//! Qaphela ukuthi ama-`&&` no-`||` opharetha abafushane, okungukuthi, bahlola kuphela i-opharetha yabo yesibili uma inegalelo emphumeleni.Njengoba lokhu kuziphatha kungaphoqelelwa yi-traits, i-`&&` ne-`||` azisekelwa njengabasebenza ngokweqile.
//!
//! Abasebenzisi abaningi bathatha ama-opharetha abo ngenani.Ezimweni ezingezona ezejwayelekile ezibandakanya izinhlobo ezakhelwe ngaphakathi, lokhu ngokuvamile akuyona inkinga.
//! Kodwa-ke, ukusebenzisa laba opharetha ngekhodi ejwayelekile, kudinga ukunakekelwa okuthile uma amanani kufanele asetshenziswe kabusha ngokungafani nokuvumela opharetha ukuthi bawadle.Inketho eyodwa ukusebenzisa i [`clone`] ngezikhathi ezithile.
//! Enye inketho ukuthembela ezinhlotsheni ezibandakanyekile ekunikezeni ukwenziwa okwengeziwe kwe-opharetha kwezinkomba.
//! Isibonelo, ngohlobo oluchazwe ngumsebenzisi i-`T` okufanele isekele ukungezwa, mhlawumbe kungumbono omuhle ukuthi zombili i-`T` ne-`&T` zisebenzise i-traits [`Add<T>`][`Add`] ne-[`Add<&T>`][`Add`] ukuze ikhodi ejwayelekile ibhalwe ngaphandle kokuhlangana okungadingekile.
//!
//!
//! # Examples
//!
//! Lesi sibonelo sakha isakhiwo se-`Point` esisebenzisa i-[`Add`] ne-[`Sub`], bese sikhombisa ukungeza nokususa ama-`Point`s amabili.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Bona imibhalo ye-trait ngayinye ngokusetshenziswa kwesibonelo.
//!
//! I [`Fn`], [`FnMut`], ne [`FnOnce`] traits zenziwa ngezinhlobo ezingasetshenziswa njengemisebenzi.Qaphela ukuthi i-[`Fn`] ithatha i-`&self`, i-[`FnMut`] ithatha i-`&mut self` kuthi i-[`FnOnce`] ithathe i-`self`.
//! Lokhu kuhambelana nezinhlobo ezintathu zezindlela ezingasetshenziswa kwesinye isikhathi: ukubiza ngereferensi, ireferensi yokubiza-ngokuguqukayo, nokubiza ngenani.
//! Ukusetshenziswa okuvame kakhulu kwalezi traits ukwenza njengemingcele yemisebenzi esezingeni eliphakeme ethatha imisebenzi noma ukuvalwa njengezimpikiswano.
//!
//! Ukuthatha i-[`Fn`] njengepharamitha:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Ukuthatha i-[`FnMut`] njengepharamitha:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Ukuthatha i-[`FnOnce`] njengepharamitha:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` isebenzisa okuguqukayo kwayo okufakiwe, ngakho-ke ayikwazi ukuqhutshwa kaningi
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Ukuzama ukufaka i-`func()` futhi kuzophonsa iphutha le-`use of moved value` le-`func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ngeke isakwazi ukubizwa kuleli phuzu
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;