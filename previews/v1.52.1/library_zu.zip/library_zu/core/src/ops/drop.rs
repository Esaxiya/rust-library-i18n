/// Ikhodi yangokwezifiso ngaphakathi kombhubhisi.
///
/// Lapho inani lingasadingeki, i-Rust izosebenzisa i-"destructor" kulelo nani.
/// Indlela ejwayelekile kunazo zonke yokuthi inani alisadingeki kulapho liphuma esikalini.Ababhubhisi bangaqhubeka basebenza kwezinye izimo, kepha sizogxila kububanzi bezibonelo lapha.
/// Ukuze ufunde ngamanye alawa amanye amacala, sicela ubone isigaba se [the reference] kwababhubhisi.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Lo mbhubhisi unezinto ezimbili:
/// - Ucingo oluya ku-`Drop::drop` ngalelo nani, uma le `Drop` trait ekhethekile isetshenziselwe uhlobo lwayo.
/// - I-"drop glue" ekhiqizwe ngokuzenzakalela ephinda ibize ababhubhisi bazo zonke izinkambu zaleli nani.
///
/// Njengoba i-Rust ibiza ngokuzenzakalela ababhubhisi bayo yonke imikhakha equkethwe, akudingeki usebenzise i-`Drop` ezimweni eziningi.
/// Kepha kukhona ezinye izimo lapho kusiza khona, ngokwesibonelo izinhlobo eziqondisa ngqo insiza.
/// Leyo nsiza ingaba yimemori, ingaba isichazi sefayela, kungaba yisokhethi yenethiwekhi.
/// Lapho inani lolo hlobo lingasazukusetshenziswa, kufanele "clean up" isisetshenziswa salo ngokukhulula imemori noma ukuvala ifayili noma isokhethi.
/// Lona ngumsebenzi wencithakalo, ngakho-ke umsebenzi we `Drop::drop`.
///
/// ## Examples
///
/// Ukubona ababhubhisi besebenza, ake sibheke lolu hlelo olulandelayo:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// I-Rust izoqala ishayele i-`Drop::drop` nge-`_x` bese kuthi kubo bobabili i-`_x.one` ne-`_x.two`, okusho ukuthi ukusebenzisa lokhu kuzophrinta
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Noma sisusa ukusetshenziswa kwe `Drop` kwe `HasTwoDrop`, abonakalisi bezinkambu zayo basabizwa.
/// Lokhu kuzoholela ku-
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Awukwazi ukushayela i `Drop::drop` ngokwakho
///
/// Ngoba i `Drop::drop` isetshenziselwa ukuhlanza inani, kungaba yingozi ukusebenzisa leli nani ngemuva kokuba indlela isibiziwe.
/// Njengoba i `Drop::drop` ingathathi okokufaka kwayo, i Rust ivimbela ukusetshenziswa kabi ngokungakuvumeli ukuthi ushayele i `Drop::drop` ngqo.
///
/// Ngamanye amagama, uma uzama ukubiza ngokucacile i-`Drop::drop` kusibonelo esingenhla, uzothola iphutha lokuhlanganisa.
///
/// Uma ungathanda ukubiza ngokusobala umbhubhisi wenani, i-[`mem::drop`] ingasetshenziswa esikhundleni salokho.
///
/// [`mem::drop`]: drop
///
/// ## Beka i-oda
///
/// Yikuphi kokuwa kwethu kwe-`HasDrop` kuqala, noma kunjalo?Okwezakhiwo, kungumyalo ofanayo abamenyezelwe wona: kuqala i-`one`, bese kuba yi-`two`.
/// Uma ungathanda ukuzama lokhu ngokwakho, ungaguqula i-`HasDrop` ngaphezulu ukuze iqukathe imininingwane ethile, njengenamba ephelele, bese uyisebenzisa ku-`println!` ngaphakathi kwe-`Drop`.
/// Lokhu kuziphatha kuqinisekiswa ngolimi.
///
/// Ngokungafani nokwakhiwa, okuguquguqukayo kwasendaweni kwehliswa ngokulandelana:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Lokhu kuzophrinta
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Sicela ubone i-[the reference] ngemithetho ephelele.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` futhi i-`Drop` ikhethekile
///
/// Awukwazi ukusebenzisa zombili i-[`Copy`] ne-`Drop` ngohlobo olufanayo.Izinhlobo ezi-`Copy` ziphindwa ngokuphelele ngumhlanganisi, okwenza kube nzima kakhulu ukubikezela ukuthi nini, futhi ababulali abazobulawa kaningi kangakanani.
///
/// Kanjalo, lezi zinhlobo azinakuba nababhubhisi.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Yenza umchithi walolu hlobo.
    ///
    /// Le ndlela ibizwa ngokusobala lapho inani liphuma esikalini, futhi alikwazi ukubizwa ngokusobala (leli iphutha lokuhlanganisa i [E0040]).
    /// Kodwa-ke, umsebenzi we-[`mem::drop`] ku-prelude ungasetshenziselwa ukubiza ukuqaliswa kwe-`Drop` kokuphikisana.
    ///
    /// Lapho le ndlela ibizwa, i `self` ayikasuswa.
    /// Lokho kwenzeka kuphela ngemuva kokuthi indlela isiphelile.
    /// Uma lokhu bekungenjalo, i-`self` ibingaba ireferensi elengayo.
    ///
    /// # Panics
    ///
    /// Njengoba kunikezwe ukuthi i-[`panic!`] izobiza i-`drop` njengoba ivuleka, noma iyiphi i-[`panic!`] ekusetshenzisweni kwe-`drop` kungenzeka ihlehle.
    ///
    /// Qaphela ukuthi noma ngabe le panics, inani libhekwa njengokwehliswa;
    /// Akufanele ubangele ukuthi i `drop` ibizwe futhi.
    /// Lokhu kuvamise ukuphathwa ngokuzenzakalela ngumhlanganisi, kepha uma usebenzisa ikhodi engaphephile, kwesinye isikhathi kungavela ngokungahlosile, ikakhulukazi lapho usebenzisa i [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}