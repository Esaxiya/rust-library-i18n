/// Isetshenziselwa imisebenzi yokungaphenduki yokungasetshenziswa, njenge-`*v`.
///
/// Ngokungeziwe ekusetshenzisweni kokucaciswa kokucaciswa kokuchithwa kokusebenza kwe-(unary) `*` kuzimo ezingaguquki, i `Deref` nayo isetshenziswa ngokuphelele ngumhlanganisi ezimweni eziningi.
/// Le ndlela ibizwa nge ['`Deref` coercion'][more].
/// Ezimweni eziguqukayo, kusetshenziswa i [`DerefMut`].
///
/// Ukuqalisa i-`Deref` ngezikhombisi ezihlakaniphile kwenza ukufinyelela idatha ngemuva kwabo kube lula, yingakho basebenzisa i `Deref`.
/// Ngakolunye uhlangothi, imithetho ephathelene ne `Deref` ne [`DerefMut`] yayenzelwe ngokukhethekile ukwamukela izikhombisi ezihlakaniphile.
/// Ngenxa yalokhu,**`Deref` kufanele isetshenziselwe kuphela izikhombisi ezihlakaniphile** ukugwema ukudideka.
///
/// Ngezizathu ezifanayo,**le trait akufanele yehluleke**.Ukwehluleka ngesikhathi sokususwa ekuchazeni kungadida kakhulu lapho i-`Deref` icelwa ngokuphelele.
///
/// # Okuningi ekuphoqelelweni kwe `Deref`
///
/// Uma i-`T` isebenzisa i-`Deref<Target = U>`, futhi i-`x` iyinani lohlobo `T`, khona-ke:
///
/// * Ezimweni ezingaguquki, i-`*x` (lapho i-`T` ingeyona inkomba noma isikhombisi esiluhlaza) ilingana ne-`* Deref::deref(&x)`.
/// * Amanani ohlobo `&T` aphoqelelwa kumanani ohlobo `&U`
/// * `T` kusebenzisa ngokuphelele zonke izindlela ze-(immutable) zohlobo `U`.
///
/// Ngemininingwane engaphezulu, vakashela i-[the chapter in *The Rust Programming Language*][book] kanye nezingxenye zokubhekisela ku-[the dereference operator][ref-deref-op], [method resolution] naku-[type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Isakhiwo esinenkambu eyodwa efinyeleleka ngokungasusi ukwakheka kwesakhiwo.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Uhlobo oluholelwayo ngemuva kokuyekiswa kabusha
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Ibonisa inani.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Isetshenziselwe imisebenzi yokususa ukuguquguquka, njengakwi `*v = 1;`.
///
/// Ngokwengeziwe ekusetshenzisweni kokucaciswa kokucaciswa kokuchithwa kokusebenza kwe-(unary) `*` kuzimo eziguqukayo, i `DerefMut` nayo isetshenziswa ngokuphelele ngumhlanganisi ezimweni eziningi.
/// Le ndlela ibizwa nge ['`Deref` coercion'][more].
/// Ezimweni ezingaguquki, kusetshenziswa i [`Deref`].
///
/// Ukuqalisa i-`DerefMut` ngezikhombisi ezihlakaniphile kwenza ukuguqulela idatha engemuva kwayo kube lula, yingakho basebenzisa i-`DerefMut`.
/// Ngakolunye uhlangothi, imithetho ephathelene ne [`Deref`] ne `DerefMut` yayenzelwe ngokukhethekile ukwamukela izikhombisi ezihlakaniphile.
/// Ngenxa yalokhu,**`DerefMut` kufanele isetshenziselwe kuphela izikhombisi ezihlakaniphile** ukugwema ukudideka.
///
/// Ngezizathu ezifanayo,**le trait akufanele yehluleke**.Ukwehluleka ngesikhathi sokususwa ekuchazeni kungadida kakhulu lapho i-`DerefMut` icelwa ngokuphelele.
///
/// # Okuningi ekuphoqelelweni kwe `Deref`
///
/// Uma i-`T` isebenzisa i-`DerefMut<Target = U>`, futhi i-`x` iyinani lohlobo `T`, khona-ke:
///
/// * Ezimweni eziguqukayo, i-`*x` (lapho i-`T` ingeyona inkomba noma isikhombisi esiluhlaza) ilingana ne-`* DerefMut::deref_mut(&mut x)`.
/// * Amanani ohlobo `&mut T` aphoqelelwa kumanani ohlobo `&mut U`
/// * `T` kusebenzisa ngokuphelele zonke izindlela ze-(mutable) zohlobo `U`.
///
/// Ngemininingwane engaphezulu, vakashela i-[the chapter in *The Rust Programming Language*][book] kanye nezingxenye zokubhekisela ku-[the dereference operator][ref-deref-op], [method resolution] naku-[type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Isakhiwo esinenkambu eyodwa engaguquguquka ngokususa ukwakheka kwesakhiwo.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Ngokungaqondakali kunikezwa inani.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Kubonisa ukuthi i-struct ingasetshenziswa njengomamukeli wendlela, ngaphandle kwesici se-`arbitrary_self_types`.
///
/// Lokhu kusetshenziswa yizinhlobo zesikhombi se-stdlib njenge-`Box<T>`, `Rc<T>`, `&T`, ne-`Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}