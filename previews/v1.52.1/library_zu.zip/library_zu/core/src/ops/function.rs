/// Uhlobo lwesisebenzisi socingo oluthatha umamukeli ongaphenduki.
///
/// Izimo ze-`Fn` zingabizwa kaninginingi ngaphandle kokuguqula isimo.
///
/// *Le trait (`Fn`) akumele ididaniswe ne [function pointers] (`fn`).*
///
/// `Fn` kwenziwa ngokuzenzakalela ngokuvalwa okuthatha kuphela izinkomba ezingaguquki kokuguquguqukayo okuthathiwe noma kungabambi lutho, kanye ne (safe) [function pointers] (enezinye izigaxa, bona imibhalo yabo ukuthola eminye imininingwane).
///
/// Ngokwengeziwe, nganoma yiluphi uhlobo i-`F` esebenzisa i-`Fn`, i-`&F` isebenzisa i-`Fn`, nayo.
///
/// Njengoba zombili i-[`FnMut`] ne-[`FnOnce`] zingama-supertraits we-`Fn`, noma isiphi isibonelo se-`Fn` singasetshenziswa njengepharamitha lapho kulindeleke khona i-[`FnMut`] noma i-[`FnOnce`].
///
/// Sebenzisa i-`Fn` njengesibopho lapho ufuna ukwamukela ipharamitha yohlobo olunjengomsebenzi futhi udinga ukuyibiza iphindaphinda futhi ngaphandle kokuguqula isimo (isb. Uma uyibiza ngasikhathi sinye).
/// Uma ungazidingi izidingo eziqinile ezinjalo, sebenzisa i-[`FnMut`] noma i-[`FnOnce`] njengemingcele.
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ukuthola eminye imininingwane ngalesi sihloko.
///
/// Futhi okuphawulayo yi-syntax ekhethekile ye `Fn` traits (isb
/// `Fn(usize, bool) -> sebenzisa`).Labo abanentshisekelo emininingwaneni yezobuchwepheshe yalokhu bangabhekisa ku [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kubizwa ukuvalwa
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Kusetshenziswa ipharamitha ye `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i regex ithembele kuleyo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Yenza umsebenzi wokushaya ucingo.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Uhlobo lwesisebenzisi socingo oluthatha isamukeli esiguqukayo.
///
/// Izimo ze-`FnMut` zingabizwa ziphindaphindwe futhi zingaguqula isimo.
///
/// `FnMut` kwenziwa ngokuzenzakalela ngokuvalwa okuthatha izinkomba eziguquguqukayo kokuguquguqukayo okufakiwe, kanye nazo zonke izinhlobo ezisebenzisa i-[`Fn`], isb., (safe) [function pointers] (ngoba i-`FnMut` iyindawo enkulu ye-[`Fn`]).
/// Ngokwengeziwe, nganoma yiluphi uhlobo i-`F` esebenzisa i-`FnMut`, i-`&mut F` isebenzisa i-`FnMut`, nayo.
///
/// Njengoba i-[`FnOnce`] i-supertrait ephezulu ye-`FnMut`, noma isiphi isibonelo se-`FnMut` singasetshenziswa lapho kulindeleke khona i-[`FnOnce`], futhi njengoba i-[`Fn`] ingaphansi kwe-`FnMut`, noma isiphi isibonelo se-[`Fn`] singasetshenziswa lapho kulindeleke khona i-`FnMut`.
///
/// Sebenzisa i-`FnMut` njengesibopho lapho ufuna ukwamukela ipharamitha yohlobo olufana nomsebenzi futhi udinga ukuyibiza iphindelela, ngenkathi uyivumela ukuthi iguqule isimo.
/// Uma ungafuni ukuthi ipharamitha iguqule isimo, sebenzisa i-[`Fn`] njengesibopho;uma ungadingi ukuyibiza kaninginingi, sebenzisa i [`FnOnce`].
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ukuthola eminye imininingwane ngalesi sihloko.
///
/// Futhi okuphawulayo yi-syntax ekhethekile ye `Fn` traits (isb
/// `Fn(usize, bool) -> sebenzisa`).Labo abanentshisekelo emininingwaneni yezobuchwepheshe yalokhu bangabhekisa ku [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Ukubiza ukuvalwa kokuthwebula okuguqukayo
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Kusetshenziswa ipharamitha ye `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i regex ithembele kuleyo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Yenza umsebenzi wokushaya ucingo.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Uhlobo lwe-opharetha wezingcingo oluthatha inani elamukelayo.
///
/// Izimo ze-`FnOnce` zingabizwa, kepha kungenzeka zingabizi kaningi.Ngenxa yalokhu, uma ukuphela kwento eyaziwa ngohlobo ukuthi isebenzisa i-`FnOnce`, ingabizwa kube kanye kuphela.
///
/// `FnOnce` kwenziwa ngokuzenzakalela ngokuvalwa okungadla okuguquguqukayo okufakiwe, kanye nazo zonke izinhlobo ezisebenzisa i-[`FnMut`], isb., (safe) [function pointers] (ngoba i-`FnOnce` iyindawo enkulu ye-[`FnMut`]).
///
///
/// Njengoba zombili i-[`Fn`] ne-[`FnMut`] zingaphansi kwe-`FnOnce`, noma isiphi isibonelo se-[`Fn`] noma i-[`FnMut`] singasetshenziswa lapho kulindeleke khona i-`FnOnce`.
///
/// Sebenzisa i-`FnOnce` njengesibopho lapho ufuna ukwamukela ipharamitha yohlobo olunjengomsebenzi futhi udinga ukuyibiza kanye kuphela.
/// Uma udinga ukubiza ipharamitha kaninginingi, sebenzisa i-[`FnMut`] njengesibopho;uma futhi uyidinga ukuthi ungaguquguquki, sebenzisa i [`Fn`].
///
/// Bona i [chapter on closures in *The Rust Programming Language*][book] ukuthola eminye imininingwane ngalesi sihloko.
///
/// Futhi okuphawulayo yi-syntax ekhethekile ye `Fn` traits (isb
/// `Fn(usize, bool) -> sebenzisa`).Labo abanentshisekelo emininingwaneni yezobuchwepheshe yalokhu bangabhekisa ku [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Kusetshenziswa ipharamitha ye `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` isebenzisa okuguqukayo kwayo okufakiwe, ngakho-ke ayikwazi ukuqhutshwa kaningi.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Ukuzama ukufaka i-`func()` futhi kuzophonsa iphutha le-`use of moved value` le-`func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ngeke isakwazi ukubizwa kuleli phuzu
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ukuze i regex ithembele kuleyo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Uhlobo olubuyisiwe ngemuva kokusebenzisa opharetha wezingcingo.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Yenza umsebenzi wokushaya ucingo.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}