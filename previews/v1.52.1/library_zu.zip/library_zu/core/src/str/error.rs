//! Ichaza uhlobo lwephutha le-utf8.

use crate::fmt;

/// Amaphutha angenzeka lapho uzama ukutolika ukulandelana kwe [`u8`] njengeyunithi yezinhlamvu.
///
/// Kanjalo, umndeni we-`from_utf8` wemisebenzi nezindlela zombili [`String`] s kanye ne-[`&str`] s zisebenzisa leli phutha, ngokwesibonelo.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Izindlela zalolu hlobo lwephutha zingasetshenziselwa ukudala ukusebenza okufana ne `String::from_utf8_lossy` ngaphandle kokwaba inqwaba yememori:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Ibuyisa inkomba entanjeni enikeziwe lapho i-UTF-8 evumelekile yaqinisekiswa khona.
    ///
    /// Kuyinkomba ephezulu yokuthi i `from_utf8(&input[..index])` izobuyisa i `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::str;
    ///
    /// // amanye amabhayithi angavumelekile, ku-vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ibuyisa i-Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // i-byte yesibili ayisebenzi lapha
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Inikeza imininingwane eminingi ngokuhluleka:
    ///
    /// * `None`: ukuphela kokufaka kufinyelelwe ngokungalindelekile.
    ///   `self.valid_up_to()` ngu-1 kuye ku-3 amabhayithi kusukela ekugcineni kokufaka.
    ///   Uma ukusakazwa nge-byte (okufana nefayela noma isokhethi yenethiwekhi) kukhishwa ikhodi ngokwengeziwe, lokhu kungaba yi-`char` evumelekile ukulandelana kwayo kwe-UTF-8 byte kudlula iziqubu eziningi.
    ///
    ///
    /// * `Some(len)`: kuhlangatshezwane ne-byte ebingalindelekile.
    ///   Ubude obunikeziwe yilobo bokulandelana kwe-byte okungavumelekile okuqala enkombeni enikezwe yi-`valid_up_to()`.
    ///   Ukukhipha ikhodi kufanele kuqhubeke ngemuva kwalapho kulandelana (ngemuva kokufaka i-[`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) uma kwenzeka ukulahleka kwamakhodi.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Kuvele iphutha lapho kudluliswa i-`bool` kusetshenziswa i-[`from_str`] kwehluleka
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}