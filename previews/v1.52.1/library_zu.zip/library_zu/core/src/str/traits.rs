//! Ukusetshenziswa kwe-Trait kwe-`str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Isebenzisa uku-oda kwezintambo.
///
/// Izintambo zi-odwe i-[lexicographically](Ord#lexicographical-comparison) ngamanani wazo we-byte.
/// Lokhu kuyala amaphuzu ekhodi we-Unicode ngokususelwa kuzikhundla zawo kumashadi wekhodi.
/// Lokhu akufani neze ne-"alphabetical" oda, ehluka ngolimi nendawo.
/// Ukuhlunga izintambo ngokuya ngamazinga amukelwa ngamasiko kudinga idatha eqondene nendawo engaphandle kobubanzi bohlobo lwe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Isebenzisa imisebenzi yokuqhathanisa ezintanjeni.
///
/// Izintambo ziqhathaniswa ne-[lexicographically](Ord#lexicographical-comparison) ngamanani wazo we-byte.
/// Lokhu kuqhathanisa amaphuzu ekhodi we-Unicode ngokuya ngezikhundla zawo kumashadi wekhodi.
/// Lokhu akufani neze ne-"alphabetical" oda, ehluka ngolimi nendawo.
/// Ukuqhathanisa izintambo ngokuya ngamazinga amukelwa ngamasiko kudinga idatha eqondene nendawo engaphandle kobubanzi bohlobo lwe `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[..]` noma i-`&mut self[..]`.
///
/// Ibuyisa ucezu lwentambo yonke, okungukuthi, ibuyisa i-`&self` noma i-`&mut self`.Ilingana ne `&self [0 ..
/// len] `noma`&mut self [0 ..
/// len]`.
/// Ngokungafani neminye imisebenzi yokukhomba, lokhu ngeke neze kube yi-panic.
///
/// Lo msebenzi ngu *O*(1).
///
/// Ngaphambi kwe-1.20.0, le misebenzi yokukhomba ibisasekelwa ukusetshenziswa okuqondile kwe-`Index` ne-`IndexMut`.
///
/// Ilingana ne-`&self[0 .. len]` noma i-`&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[begin .. end]` noma i-`&mut self[begin .. end]`.
///
/// Ibuyisa ucezu lwentambo enikeziwe kusuka kububanzi be-byte [`start`, `end`).
///
/// Lo msebenzi ngu *O*(1).
///
/// Ngaphambi kwe-1.20.0, le misebenzi yokukhomba ibisasekelwa ukusetshenziswa okuqondile kwe-`Index` ne-`IndexMut`.
///
/// # Panics
///
/// I-Panics uma i-`begin` noma i-`end` ingakhombisi ukuqalwa kwe-byte yokuqala komlingiswa (njengoba kuchaziwe yi-`is_char_boundary`), uma i-`begin > end`, noma i-`end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // lokhu kuzokwenza i-panic:
/// // i-byte 2 ilele ngaphakathi kwe `ö`:
/// // &s [2 ..3];
///
/// // i-byte 8 ilele ngaphakathi kwe-`老`&s [1 ..
/// // 8];
///
/// // i-byte 100 ingaphandle kwentambo nama-s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` ne `end` zisemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            // Siphinde sabheka imingcele yamashadi, ngakho-ke lokhu kuyi-UTF-8 evumelekile.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` ne `end` zisemngceleni wamashadi.
            // Siyazi ukuthi i-pointer ihlukile ngoba siyithole ku-`slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UKUPHEPHA: ofonayo uqinisekisa ukuthi i-`self` isemingceleni ye-`slice`
        // eyanelisa yonke imibandela ye `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // UKUPHEPHA: bona imibono ye `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ihlola ukuthi inkomba iku-[0, .len()] ayikwazi ukusebenzisa i-`get` njengangenhla, ngenxa yenkinga ye-NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` ne `end` zisemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[.. end]` noma i-`&mut self[.. end]`.
///
/// Ibuyisa ucezu lwentambo enikeziwe kusuka kububanzi be-byte [`0`, `end`).
/// Ilingana ne-`&self[0 .. end]` noma i-`&mut self[0 .. end]`.
///
/// Lo msebenzi ngu *O*(1).
///
/// Ngaphambi kwe-1.20.0, le misebenzi yokukhomba ibisasekelwa ukusetshenziswa okuqondile kwe-`Index` ne-`IndexMut`.
///
/// # Panics
///
/// I-Panics uma i-`end` ingakhombisi ekuqaleni kwe-byte yohlamvu (njengoba kuchazwe yi-`is_char_boundary`), noma uma i-`end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // UKUPHEPHA: ngibheke nje ukuthi i `end` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // UKUPHEPHA: ngibheke nje ukuthi i `end` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // UKUPHEPHA: ngibheke nje ukuthi i `end` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[begin ..]` noma i-`&mut self[begin ..]`.
///
/// Ibuyisa ucezu lwentambo enikeziwe kusuka kububanzi be-byte [`start`, `len`).Ilingana ne `&self [qala ..
/// len] `noma`&mut self [qala ..
/// len]`.
///
/// Lo msebenzi ngu *O*(1).
///
/// Ngaphambi kwe-1.20.0, le misebenzi yokukhomba ibisasekelwa ukusetshenziswa okuqondile kwe-`Index` ne-`IndexMut`.
///
/// # Panics
///
/// I-Panics uma i-`begin` ingakhombisi ekuqaleni kwe-byte yohlamvu (njengoba kuchazwe yi-`is_char_boundary`), noma uma i-`begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // UKUPHEPHA: ofonayo uqinisekisa ukuthi i-`self` isemingceleni ye-`slice`
        // eyanelisa yonke imibandela ye `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // UKUPHEPHA: kufana ne `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // UKUPHEPHA: ngibheke nje ukuthi i `start` isemngceleni wamashadi,
            // futhi sidlulisa ireferensi ephephile, ngakho-ke inani lokubuyisa lizoba linye.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[begin ..= end]` noma i-`&mut self[begin ..= end]`.
///
/// Ibuyisa ucezu lwentambo enikeziwe kusuka kububanzi be-byte [`begin`, `end`].Ilingana ne-`&self [begin .. end + 1]` noma i-`&mut self[begin .. end + 1]`, ngaphandle kokuthi i-`end` inenani eliphakeme le-`usize`.
///
/// Lo msebenzi ngu *O*(1).
///
/// # Panics
///
/// I-Panics uma i-`begin` ingakhombisi ukuqalwa kwe-byte yokuqala komlingiswa (njengoba kuchaziwe yi-`is_char_boundary`), uma i-`end` ingakhombisi ukuqedwa kwe-byte okuphela komlingiswa (i-`end + 1` kungaba yi-byte offset yokuqala noma ilingana no-`len`), uma i-`begin > end`, noma uma i-`end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Isebenzisa ukusikwa kwe-substring nge-syntax `&self[..= end]` noma i-`&mut self[..= end]`.
///
/// Ibuyisa ucezu lwentambo enikeziwe kusuka kububanzi be-Byte [0, `end`].
/// Ilingana ne-`&self [0 .. end + 1]`, ngaphandle kokuthi i-`end` inenani eliphakeme le-`usize`.
///
/// Lo msebenzi ngu *O*(1).
///
/// # Panics
///
/// I-Panics uma i-`end` ingakhombisi ukuqedwa kwe-byte yokuphela komlingiswa (i-`end + 1` kungaba yi-offset yokuqala njengoba kuchazwe yi-`is_char_boundary`, noma ilingana no-`len`), noma uma i-`end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Hlanganisa inani lentambo
///
/// Indlela ye-XSX ephuma ku-trtr isetshenziswa kaningi, ngokusebenzisa indlela ye-[`parse`] [`str`].
/// Bona imibhalo ka-[`parse`] ngezibonelo.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ayinayo ipharamitha yempilo yonke, ngakho-ke ungahlwaya kuphela izinhlobo ezingenayo ipharamitha yempilo uqobo.
///
/// Ngamanye amagama, ungadlulisa i-`i32` nge-`FromStr`, kepha hhayi i-`&i32`.
/// Ungahlwaya isakhiwo esine-`i32`, kepha hhayi eyodwa equkethe i-`&i32`.
///
/// # Examples
///
/// Ukuqaliswa okuyisisekelo kwe `FromStr` ngohlobo lwe-`Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Iphutha elihambisanayo elingabuyiselwa ekuhlukaneni.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Ihambisa umucu `s` ukubuyisa inani lolu hlobo.
    ///
    /// Uma ukwehlukaniswa kuphumelela, buyisela inani ngaphakathi kwe-[`Ok`], ngaphandle kwalokho lapho intambo ifomethwe kabi ibuyisa iphutha elithile ngaphakathi kwe [`Err`].
    /// Uhlobo lwephutha lucacisiwe ekusetshenzisweni kwe-trait.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo nge [`i32`], uhlobo olusebenzisa i `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Hlanganisa i-`bool` ngentambo.
    ///
    /// Iveza i-`Result<bool, ParseBoolError>`, ngoba i-`s` kungenzeka noma ingabonakali kalula.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Qaphela, ezimweni eziningi, indlela ye-`.parse()` ku-`str` ilunge kakhulu.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}