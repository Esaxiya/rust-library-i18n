//! Ukusebenza okuhlobene nokuqinisekiswa kwe-UTF-8.

use crate::mem;

use super::Utf8Error;

/// Ibuyisa isiqongeleli se-codepoint sokuqala se-byte yokuqala.
/// I-byte yokuqala ikhethekile, ifuna kuphela izingcezu ezi-5 ezingezansi ngobubanzi 2, izingcezu ezi-4 zobubanzi 3, no-3 izingcezu zobubanzi obungu-4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Ibuyisa inani le-`ch` elibuyekezwe nge-byte yokuqhubeka `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Ihlola ukuthi ngabe i-byte iyi-byte yokuqhubeka ye-UTF-8 (okungukuthi, iqala ngamabhithi `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Ifunda iphuzu lekhodi elilandelayo nge-byte iterator (kucatshangelwa ukufaka ikhodi okufana ne-UTF-8).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Nquma i-UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Icala leMultibyte lilandela ukubhala phansi kusuka kwinhlanganisela ye-byte ku: [[[x y] z] w]
    //
    // NOTE: Ukusebenza kuyazwela ekwakhiweni ngqo lapha
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] icala
        // I-5th bit ku-0xE0 .. I-0xEF ihlala icacile, ngakho-ke i-`init` isasebenza
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ukusetshenziswa kwecala kuphela izingcezu ezi-3 ezingezansi ze-`init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Ifunda iphuzu lokugcina lekhodi nge-byte iterator (kucatshangelwa ukufakwa ikhodi okufana ne-UTF-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Nquma i-UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Icala leMultibyte lilandela i-Decode kusuka enhlanganisweni ye-byte ephuma ku: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// sebenzisa i-truncation ukulinganisa i-u64 kusayizi
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Ibuyisa i-`true` uma ngabe kukhona i-byte ezwi `x` engeyona i-nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Ihamba nge-`v` ibheka ukuthi ukulandelana okuvumelekile kwe-UTF-8, ibuyisa i-`Ok(())` kuleso simo, noma, uma kungavumelekile, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // besidinga idatha, kepha bekungekho: iphutha!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Ukufakwa amakhodi okungu-2-byte kwenzelwa ama-codepoints\u {0080} to\u {07ff} first C2 80 last DF BF
            // Ukufakwa kwekhodi okungu-3-byte kwenzelwa ama-codepoints\u {0800} ukuze\u {ffff} kuqala i-E0 A0 80 yokugcina i-EF BF BF ngaphandle kwama-surrogate codepoints\u {d800} to\u {dfff} ED A0 80 to ED BF BF
            // Ukufakwa amakhodi okungu-4-byte kwenzelwa amakhodi,\u {1000} 0 kuye\u {10ff} ff kuqala F0 90 80 80 last F4 8F BF BF
            //
            // Sebenzisa i-syntax ye-UTF-8 evela ku-RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // I-UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-tail UTF8-3= %xE0% xA0-BF UTF8-tail/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-tail/% xEE-I-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Icala le-Ascii, zama ukweqa uye phambili ngokushesha.
            // Lapho isikhombi siqondisiwe, funda amagama ama-2 edatha ngakunye kuze kube sithola igama eliqukethe i-byte engeyona i-ascii.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // UKUPHEPHA: ngoba i `align - index` ne `ascii_block_size` yilezi
                    // Ukuphindaphinda kwe-`usize_bytes`, i-`block = ptr.add(index)` kuhlala kuqondaniswa ne-`usize` ngakho-ke kuphephile ukubhekisisa kokubili i-`block` ne-`block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // break uma kukhona i-nonascii byte
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // suka lapho iphuzu lapho i-loop engamagama ime khona
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Njengoba kunikezwe i-byte yokuqala, kunquma ukuthi mangaki ama-byte akule nhlamvu ye-UTF-8.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Imaski yamabhithi wenani le-byte yokuqhubeka.
const CONT_MASK: u8 = 0b0011_1111;
/// Inani lamathegi wamathegi (imaski yethegi yi-!CONT_MASK) yebhayithi yokuqhubeka.
const TAG_CONT_U8: u8 = 0b1000_0000;

// unciphise i-`&str` ubude ilingana kakhulu ne-`max` buyisela i-`true` uma incishisiwe, ne-str entsha.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}