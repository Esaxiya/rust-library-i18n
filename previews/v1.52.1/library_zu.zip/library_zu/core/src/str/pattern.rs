//! Iyunithi yezinhlamvu ze-API.
//!
//! I-Pattern API inikeza indlela ejwayelekile yokusebenzisa izinhlobo zephethini ezahlukahlukene lapho usesha ngentambo.
//!
//! Ngemininingwane engaphezulu, bona i traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ne [`DoubleEndedSearcher`].
//!
//! Yize le API ingazinzile, ivezwa ngama-API azinzile ohlobo lwe [`str`].
//!
//! # Examples
//!
//! [`Pattern`] yi-[implemented][pattern-impls] ku-API ezinzile ye [`&str`][`str`], [`char`], izingcezu ze [`char`], nemisebenzi nokuvalwa okusebenzisa i `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // iphethini ye-char
//! assert_eq!(s.find('n'), Some(2));
//! // ucezu lwephethini yezinsimbi
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // iphethini yokuvalwa
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Iphethini yezintambo.
///
/// I-`Pattern<'a>` iveza ukuthi uhlobo olusebenzisayo lungasetshenziswa njengephethini yentambo yokusesha ku-[`&'a str`][str].
///
/// Isibonelo, womabili i-`'a'` ne-`"aa"` amaphethini angafana enkombeni `1` ngentambo `"baaaab"`.
///
/// I-trait uqobo isebenza njengomakhi wohlobo oluhambisanayo lwe-[`Searcher`], elenza umsebenzi wangempela wokuthola ukuvela kwephethini ngentambo.
///
///
/// Ngokuya ngohlobo lwephethini, ukusebenza kwezindlela ezinjenge-[`str::find`] ne-[`str::contains`] kungashintsha.
/// Ithebula elingezansi lichaza okunye kokuziphatha.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Isisesheli esihambisanayo saleli phethini
    type Searcher: Searcher<'a>;

    /// Yakha isesheli esihambisanayo kusuka ku-`self` naku-`haystack` ongayiseshela kuyo.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Ihlola ukuthi ngabe iphethini iyafana yini noma kuphi ku-haystack
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Ihlola ukuthi iphethini iyafana yini ngaphambili kwefula
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Ihlola ukuthi ingabe iphethini iyafana ngemuva kwe-haystack
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Isusa iphethini ngaphambili kwe-haystack, uma ifana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // UKUPHEPHA: I-`Searcher` yaziwa ngokubuyisa izinkomba ezivumelekile.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Isusa iphethini ngemuva kwe-haystack, uma ifana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // UKUPHEPHA: I-`Searcher` yaziwa ngokubuyisa izinkomba ezivumelekile.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Umphumela wokubiza i-[`Searcher::next()`] noma i-[`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Iveza ukuthi umdlalo wephethini utholakele ku-`haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Iveza ukuthi i `haystack[a..b]` inqatshiwe njengokufana okungenzeka kwephethini.
    ///
    /// Qaphela ukuthi kungahle kube ne-`Reject` engaphezu kweyodwa phakathi kwama-`Match`es amabili, asikho isidingo sokuthi ahlanganiswe abe munye.
    ///
    ///
    Reject(usize, usize),
    /// Izwakalisa ukuthi yonke i-byte ye-haystack ivakashelwe, kuqeda ukuphindaphindwa kwayo.
    ///
    Done,
}

/// Isesheli sephethini yochungechunge.
///
/// Le trait inikeza izindlela zokucinga ukufana okungagqagqene kwephethini eqala ngaphambili kwe (left) yochungechunge.
///
/// Izosetshenziswa ngezinhlobo ezihambisanayo ze `Searcher` ze [`Pattern`] trait.
///
/// I-trait imakwe njengengaphephile ngoba izinkomba ezibuyiselwe izindlela ze-[`next()`][Searcher::next] ziyadingeka ukuba zilele emingceleni ye-utf8 esemthethweni ku-haystack.
/// Lokhu kunika amandla abathengi bale trait ukusika ifolishi ngaphandle kokuhlolwa okwengeziwe kwesikhathi sokusebenza.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// I-Getter ngentambo engaphansi ezoseshwa kuyo
    ///
    /// Sizohlala sibuyisa i [`&str`][str] efanayo.
    fn haystack(&self) -> &'a str;

    /// Yenza isinyathelo sokusesha esilandelayo kusuka ngaphambili.
    ///
    /// - Ibuyisa i-[`Match(a, b)`][SearchStep::Match] uma i-`haystack[a..b]` ifana nephethini.
    /// - Ibuyisa i-[`Reject(a, b)`][SearchStep::Reject] uma i-`haystack[a..b]` ingakwazi ukufana nephethini, noma kancane.
    /// - Ibuyisa i-[`Done`][SearchStep::Done] uma yonke i-byte ye-haystack ivakashelwe.
    ///
    /// Ukusakazwa kwamanani we-[`Match`][SearchStep::Match] ne-[`Reject`][SearchStep::Reject] kuze kufike ku-[`Done`][SearchStep::Done] kuzoqukatha amabanga ezinkomba aseduze, angagqagqelani, amboza yonke ifolishi, futhi abeke imingcele ye-utf8.
    ///
    ///
    /// Umphumela we-[`Match`][SearchStep::Match] udinga ukuqukatha iphethini yonke ehambisanayo, kepha imiphumela ye-[`Reject`][SearchStep::Reject] ingahlukaniswa ibe izingcezwana eziningi eziseduze.Womabili la mabanga angaba nobude obungu-zero.
    ///
    /// Njengesibonelo, iphethini `"aaa"` ne-haystack `"cbaaaaab"` ingahle ikhiqize ukusakazwa
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Ithola umphumela olandelayo we-[`Match`][SearchStep::Match].Bona i [`next()`][Searcher::next].
    ///
    /// Ngokungafani ne-[`next()`][Searcher::next], asikho isiqinisekiso sokuthi amabanga abuyisiwe alokhu ne-[`next_reject`][Searcher::next_reject] azodlula.
    /// Lokhu kuzobuyisa i `(start_match, end_match)`, lapho i-start_match iyinkomba yalapho umdlalo uqala khona, futhi i-end_match yinkomba ngemuva kokuphela komdlalo.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ithola umphumela olandelayo we-[`Reject`][SearchStep::Reject].Bona i [`next()`][Searcher::next] ne [`next_match()`][Searcher::next_match].
    ///
    /// Ngokungafani ne-[`next()`][Searcher::next], asikho isiqinisekiso sokuthi amabanga abuyisiwe alokhu ne-[`next_match`][Searcher::next_match] azodlula.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Isesheli esibuyela emuva sephethini yochungechunge.
///
/// Le trait inikeza izindlela zokusesha ukufana okungagqagqene kwephethini eqala emuva ku-(right) emuva kwentambo.
///
/// Izosetshenziswa yizinhlobo ze-[`Searcher`] ezihambisanayo ze-[`Pattern`] trait uma iphethini isekela ukuyifuna ngemuva.
///
///
/// Amabanga ezinkomba abuyiswe yile trait awadingeki ukuthi afane ncamashi nalawo okuseshwa phambili ngokuhlehla.
///
/// Ngesizathu sokuthi kungani le trait ibhalwe ukuthi ayiphephile, babone njengomzali u trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Yenza isinyathelo sokusesha esilandelayo kusuka emuva.
    ///
    /// - Ibuyisa i-[`Match(a, b)`][SearchStep::Match] uma i-`haystack[a..b]` ifana nephethini.
    /// - Ibuyisa i-[`Reject(a, b)`][SearchStep::Reject] uma i-`haystack[a..b]` ingakwazi ukufana nephethini, noma kancane.
    /// - Ibuyisa i-[`Done`][SearchStep::Done] uma yonke i-byte ye-haystack ivakashelwe
    ///
    /// Ukusakazwa kwamanani we-[`Match`][SearchStep::Match] ne-[`Reject`][SearchStep::Reject] kuze kufike ku-[`Done`][SearchStep::Done] kuzoqukatha amabanga ezinkomba aseduze, angagqagqelani, amboza yonke ifolishi, futhi abeke imingcele ye-utf8.
    ///
    ///
    /// Umphumela we-[`Match`][SearchStep::Match] udinga ukuqukatha iphethini yonke ehambisanayo, kepha imiphumela ye-[`Reject`][SearchStep::Reject] ingahlukaniswa ibe izingcezwana eziningi eziseduze.Womabili la mabanga angaba nobude obungu-zero.
    ///
    /// Njengesibonelo, iphethini `"aaa"` ne-haystack `"cbaaaaab"` ingahle ikhiqize ukusakaza i-`[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Ithola umphumela olandelayo we [`Match`][SearchStep::Match].
    /// Bona i [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Ithola umphumela olandelayo we [`Reject`][SearchStep::Reject].
    /// Bona i [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Umaka trait ukuveza ukuthi i [`ReverseSearcher`] ingasetshenziselwa ukuqaliswa kwe [`DoubleEndedIterator`].
///
/// Ngalokhu, ukufakwa kwe [`Searcher`] ne [`ReverseSearcher`] kudinga ukulandela le mibandela:
///
/// - Yonke imiphumela ye-`next()` idinga ukufana nemiphumela ye-`next_back()` ngokulandelana okuphindayo.
/// - `next()` futhi i-`next_back()` idinga ukuthi iziphathe njengeziphetho ezimbili zebanga elithile, okungukuthi azikwazi i-"walk past each other".
///
/// # Examples
///
/// `char::Searcher` iyi-`DoubleEndedSearcher` ngoba ukufuna i-[`char`] kudinga ukubheka eyodwa ngasikhathi sinye, esiziphatha ngendlela efanayo kuzo zombili izinhlangothi.
///
/// `(&str)::Searcher` akuyona i-`DoubleEndedSearcher` ngoba iphethini `"aa"` ku-haystack `"aaa"` ifana ne-`"[aa]a"` noma i-`"a[aa]"`, kuya ngokuthi iseshwa ngakuluphi uhlangothi.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl nge-char
/////////////////////////////////////////////////////////////////////////////

/// Uhlobo oluhlanganisiwe lwe-`<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // okungajwayelekile kokuphepha: I-`finger`/`finger_back` kufanele ibe yinkomba ye-utf8 byte evumelekile ye-`haystack` Le nto engaguquguquki ingahle yephulwe *ngaphakathi kwe-* next_match naku-next_match_back, kepha-ke kufanele baphume ngeminwe emingceleni yamaphoyinti evumelekile.
    //
    //
    /// `finger` inkomba ye-byte yamanje yokusesha phambili.
    /// Cabanga ukuthi ikhona ngaphambi kwe-byte enkombeni yayo, isb
    /// `haystack[finger]` yi-byte yokuqala yocezu okufanele siluhlole lapho kuseshwa phambili
    ///
    finger: usize,
    /// `finger_back` inkomba ye-byte yamanje yokusesha okuphindayo.
    /// Cabanga ukuthi ikhona ngemuva kwe-byte enkombeni yayo, isb
    /// i-haystack [i-finger_back, 1] yi-byte yokugcina yocezu okufanele siluhlole lapho kuseshwa phambili (futhi ngaleyo ndlela ibhayithi lokuqala elizohlolwa lapho kubizwa i-next_back()).
    ///
    finger_back: usize,
    /// Umlingiswa oseshwayo
    needle: char,

    // okungahlali kuphephile: I-`utf8_size` kufanele ibe ngaphansi kuka-5
    /// Inani lama-byte `needle` linyuka lapho kufakwe ikhodi ku-utf8.
    utf8_size: usize,
    /// Ikhophi le-utf8 elifakiwe le-`needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // UKUPHEPHA: 1-4 isiqinisekiso sokuphepha kwe `get_unchecked`
        // 1. `self.finger` futhi i-`self.finger_back` igcinwa emingceleni ye-unicode (lokhu akuvamile)
        // 2. `self.finger >= 0` ngoba iqala ku-0 futhi inyuka kuphela
        // 3. `self.finger < self.finger_back` ngoba uma kungenjalo i-char `iter` izobuyisa i-`SearchStep::Done`
        // 4.
        // `self.finger` iza ngaphambi kokuphela kwe-haystack ngoba i-`self.finger_back` iqala ekugcineni futhi incipha kuphela
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // engeza ukukhishwa kwe-byte kohlamvu lwamanje ngaphandle kokufaka ikhodi kabusha njenge-utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // thola i-haystack ngemuva kokutholwa komlingiswa wokugcina
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // i-byte yokugcina ye-utf8 encoded needle SAFETY: sine-invariant ukuthi i-`utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Umunwe omusha uyinkomba ye-byte esiyitholile, kanye neyodwa, ngoba simemela i-byte yokugcina yomlingiswa.
                //
                // Qaphela ukuthi lokhu akusiniki njalo umunwe emngceleni we UTF8.
                // Uma thina *singatholanga* uhlamvu lwethu kungenzeka sikhombe kunombolo engeyona eyokugcina yohlamvu lwama-3-byte noma u-4-byte.
                // Asikwazi ukweqa nje nge-byte elandelayo evumelekile ngoba umlingiswa onjengo-ꁁ (U + A041 YI SYLLABLE PA), i-utf-8 `EA 81 81` izosinika njalo i-byte yesibili lapho sifuna owesithathu.
                //
                //
                // Kodwa-ke, lokhu kulungile impela.
                // Ngenkathi sinokungaguquguquki kokuthi i-self.finger isemngceleni we-UTF8, lokhu okuguquguqukayo akuthembelwanga ngaphakathi kwale ndlela (kuncike kuyo ku-CharSearcher::next()).
                //
                // Siphuma kuphela kule ndlela lapho sifinyelela ekugcineni kwentambo, noma uma sithola okuthile.Lapho sithola okuthile i `finger` izosethwa kumngcele we UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // akutholanga lutho, phuma
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // vumela olandelayo_nqabe ukusebenzisa ukuqaliswa okuzenzakalelayo kusuka ku-Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // UKUPHEPHA: bona ukuphawula kwe next() ngenhla
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // khipha i-byte offset yohlamvu lwamanje ngaphandle kokufaka ikhodi kabusha njenge-utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // thola i-haystack kuze kube kodwa ungafaki uhlamvu lokugcina oluseshwe
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // i-byte yokugcina ye-utf8 encoded needle SAFETY: sine-invariant ukuthi i-`utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // siseshe isilayidi esasicashunwe yi self.finger, engeza i self.finger ukuthola kabusha inkomba yangempela
                //
                let index = self.finger + index;
                // i-memrchr izobuyisa inkomba ye-byte esifisa ukuyithola.
                // Uma kwenzeka uhlamvu lwe-ASCII, lokhu bekungukuthi besifisa sengathi umunwe wethu omusha ube ("after" the char found in the paradigm of reverse iteration).
                //
                // Kuma-multibyte chars sidinga ukweqa phansi ngenombolo yama-byte amaningi anayo kune-ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // hambisa umunwe ngaphambi kokuthi uhlamvu lutholakale (okusho, enkombeni yalo yokuqala)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Asikwazi ukusebenzisa i-finger_back=index, size + 1 lapha.
                // Uma sithole i-char yokugcina yenhlamvu engosayizi ohlukile (noma i-byte ephakathi nohlamvu ohlukile) sidinga ukushaya umunwe_ubuyele phansi ku-`index`.
                // Lokhu ngokufanayo kwenza i `finger_back` ibe namandla okuthi ingabe isaba semngceleni, kepha lokhu KULUNGILE ngoba sishiya lo msebenzi kuphela emngceleni noma lapho ifula lefula seliseshwe ngokuphelele.
                //
                //
                // Ngokungafani ne-next_match lokhu akunankinga yama-byte aphindaphindiwe ku-utf-8 ngoba sifuna i-byte yokugcina, futhi singathola kuphela i-byte yokugcina lapho sisesha emuva.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // akutholanga lutho, phuma
                return None;
            }
        }
    }

    // vumela i-next_reject_back isebenzise ukuqaliswa okuzenzakalelayo kusuka ku-Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Usesho lwamashadi alingana ne-[`char`] enikeziwe.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl yesisongeli seMultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Qhathanisa ubude be-byte slice iterator yangaphakathi ukuthola ubude be-char yamanje
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Qhathanisa ubude be-byte slice iterator yangaphakathi ukuthola ubude be-char yamanje
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Shintsha/Susa ngenxa yokungaqondakali kwencazelo.

/// Uhlobo oluhlanganisiwe lwe-`<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Usesho lwamashadi alingana nanoma yimaphi ama-[`char`] kucezu.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye-F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Uhlobo oluhlanganisiwe lwe-`<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Usesho lwama-[`char`] olufana nesilandiso esinikeziwe.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye&&str
/////////////////////////////////////////////////////////////////////////////

/// Izithunywa ku-`&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl ye &str
/////////////////////////////////////////////////////////////////////////////

/// Ukusesha okungaphansi kokwabiwa okungaphansi.
///
/// Izophatha iphethini `""` njengokubuyisa ukufana okungenalutho emngceleni ngamunye wezinhlamvu.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Ihlola ukuthi iphethini iyafana yini ngaphambili kwefula.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Isusa iphethini ngaphambili kwe-haystack, uma ifana.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // UKUPHEPHA: isiqalo siqinisekiswe nje ukuthi sikhona.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Ihlola ukuthi ingabe iphethini iyafana ngemuva kwe-haystack.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Isusa iphethini ngemuva kwe-haystack, uma ifana.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // UKUPHEPHA: Isijobelelo siqinisekiswe nje ukuthi sikhona.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Isesheli se-Two Way substring
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Uhlobo oluhlanganisiwe lwe-`<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // inaliti engenalutho yenqaba yonke i-char futhi ifanisa yonke intambo engenalutho phakathi kwabo
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // I-TwoWaySearcher ikhiqiza izinkomba ezivumelekile ze-*Match* ezihlukaniswa kwimingcele yamashadi inqobo nje uma ikwenza ukufaniswa okulungile nokuthi i-haystack nenaliti zisebenza i-UTF-8 *Rejects* kusuka ku-algorithm ingawela kunoma iziphi izinkomba, kepha sizozihamba ngesandla siye emngceleni wezinhlamvu olandelayo, ukuze ziphephe i-utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // yeqela kumngcele olandelayo we-char
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // bhala amacala e-`true` ne-`false` ukukhuthaza umhlanganisi ukuthi enze ngokukhethekile amacala womabili ngokwahlukana.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // yeqela kumngcele olandelayo we-char
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // bhala i `true` ne `false`, njenge `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Isimo sangaphakathi se-substring search algorithm sezindlela ezimbili.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// inkomba ye-factorization ebucayi
    crit_pos: usize,
    /// inkomba ye-factorization ebucayi yenaliti eguquliwe
    crit_pos_back: usize,
    period: usize,
    /// `byteset` isandiso (hhayi ingxenye yezindlela ezimbili ze-algorithm);
    /// yi-64-bit "fingerprint" lapho isethi ngayinye engu-`j` ifana ne (byte&63)==j ekhona enalithini.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// Inkomba yenaliti ngaphambi kwayo esivele ifanisiwe
    memory: usize,
    /// index inaliti ngemuva kwalokho esivele simatanisile
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Incazelo efundeka ngokukhethekile yalokho okwenzeka lapha ingatholakala encwadini kaCrochemore noRytter "Text Algorithms", isahluko 13.
        // Ngokuqondile bona ikhodi ye "Algorithm CP" ekhasini.
        // 323.
        //
        // Okwenzekayo ukuthi sine-factorization ebalulekile (u, v) yenaliti, futhi sifuna ukunquma ukuthi ingabe uyisijobelelo se-&v [.. period].
        // Uma kunjalo, sisebenzisa i-"Algorithm CP1".
        // Ngaphandle kwalokho sisebenzisa i-"Algorithm CP2", elungiselelwe ukuthi isikhathi senaliti sikhulu yini.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // icala lesikhathi esifushane-inkathi ilingana ngqo nokubala okuhlukile okubalulekile kwenaliti eguquliwe x=u 'v' lapho | v '|<period(x).
            //
            // Lokhu kusheshiswa yisikhathi esivele saziwa.
            // Qaphela ukuthi icala elifana no-x= "acba" lingahle lifakwe phambili liye phambili (crit_pos=1, period=3) ngenkathi lihlanganiswa nesikhathi esilinganiselwe emuva (crit_pos=2, period=2).
            // Sisebenzisa i-reverse factorization enikeziwe kepha sigcina isikhathi esiqondile.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // icala lesikhathi eside-sinokulinganiselwa kwesikhathi sangempela, futhi ungasebenzisi ngekhanda.
            //
            //
            // Cishe isikhathi ngokubopha okuphansi i-max(|u|, |v|) + 1.
            // Isici esibucayi sisebenza kahle ekusetshenzisweni kokubheka phambili nokubuyela emuva.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Inani ledummy ukukhombisa ukuthi inkathi yinde
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Omunye wemibono esemqoka yeTwo-Way ukuthi sifaka inaliti ezingxenyeni ezimbili, (u, v), bese siqala ukuzama ukuthola v ku-haystack ngokuskena kwesobunxele kwesokudla.
    // Uma i-v ifana, sizama ukukufanisa ngokuskena ngakwesokudla kwesobunxele.
    // Singagxuma kangakanani lapho sihlangabezana nokungafani konke kususelwa ekutheni (u, v) kuyinto ebucayi yenaliti.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` isebenzisa i-`self.position` njengesikhombisi sayo
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Bheka ukuthi sinendawo yokusesha endaweni + yenaliti_last ayikwazi ukugcwala uma sicabanga ukuthi izingcezu ziboshwe ibanga le-isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Yeqa ngokushesha izingxenye ezinkulu ezingahlobene ne-substring yethu
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Bona ukuthi ingxenye efanele yenaliti iyafana yini
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Bheka ukuthi ingxenye yesinxele iyafana yini nenaliti
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Sithole umentshisi!
            let match_pos = self.position;

            // Note: engeza i-self.period esikhundleni se-needle.len() ukuze ube nokufana okugqagqene
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // setha ku-needle.len(), self.period ngemidlalo egqagqene
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ulandela imibono ku-`next()`.
    //
    // Izincazelo ziyalingana, ne-period(x) = period(reverse(x)) ne-local_period(u, v) = local_period(reverse(v), reverse(u)), ngakho-ke uma (u, v) kuyinto ebucayi, kanjalo ne (reverse(v), reverse(u)).
    //
    //
    // Ngecala elibuyela emuva sibhale i-factorization ebucayi x=u 'v' (inkambu `crit_pos_back`).Sidinga | u |<period(x) yecala lokuya phambili futhi ngaleyo ndlela | v '|<period(x) yokuhlehla.
    //
    // Ukusesha ukubuyela emuva nge-haystack, sibheka phambili nge-haystack eguquliwe ngenaliti ebuyisiwe, okufanisa u-u kuqala bese u-v '.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` isebenzisa i-`self.end` njengesikhombisi sayo-ukuze i-`next()` ne-`next_back()` zizimele.
        //
        let old_end = self.end;
        'search: loop {
            // Bheka ukuthi sinendawo yokucinga ekugcineni, i needle.len() izosonga lapho ingekho enye indawo, kepha ngenxa yemingcele yobude besilayidi ayinakuze isongele emuva ibude be-haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Yeqa ngokushesha izingxenye ezinkulu ezingahlobene ne-substring yethu
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Bheka ukuthi ingxenye yesinxele iyafana yini nenaliti
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Bona ukuthi ingxenye efanele yenaliti iyafana yini
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Sithole umentshisi!
            let match_pos = self.end - needle.len();
            // Note: i-sub self.period esikhundleni se-needle.len() ukuze ibe nokufana okugqagqene
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Bala isijobelelo esikhulu se-`arr`.
    //
    // Isijobelelo sobukhulu besici esibucayi okungenzeka sibucayi (u, v) se-`arr`.
    //
    // Returns (`i`, `p`) lapho i-`i` iyinkomba yokuqala ye-v ne-`p` isikhathi se-v.
    //
    // `order_greater` inquma uma i-lexical i-`<` noma i-`>`.
    // Womabili la ma-oda kufanele abalwe-uku-oda nge-`i` enkulu kunika into ebalulekile.
    //
    //
    // Ezimweni zesikhathi eside, isikhathi esivelile asisiqondile (sifushane kakhulu).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Ihambisana ne-i ephepheni
        let mut right = 1; // Ihambisana no-j ephepheni
        let mut offset = 0; // Ihambisana no-k ephepheni, kepha iqala ngo-0
        // ukuqondanisa inkomba engu-0.
        let mut period = 1; // Ihambisana nep ekhasini

        while let Some(&a) = arr.get(right + offset) {
            // `left` kuzoba okungenayo uma i `right` ingu.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Isijobelelo sincane, isikhathi siyisiqalo sonke kuze kube manje.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Dlulela phambili ngokuphindaphinda kwesikhathi samanje.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Isijobelelo sikhulu, qala phansi kusuka endaweni yamanje.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Bala isijobelelo sobukhulu besilinganiselo se-`arr`.
    //
    // Isijobelelo sobukhulu besici esibucayi okungenzeka ukuthi sibucayi (u ', v') se-`arr`.
    //
    // Ibuyisa i-`i` lapho i-`i` iyinkomba yokuqala ye-v ', evela emuva;
    // ibuya ngokushesha lapho kufinyelelwa isikhathi se-`known_period`.
    //
    // `order_greater` inquma uma i-lexical i-`<` noma i-`>`.
    // Womabili la ma-oda kufanele abalwe-uku-oda nge-`i` enkulu kunika into ebalulekile.
    //
    //
    // Ezimweni zesikhathi eside, isikhathi esivelile asisiqondile (sifushane kakhulu).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Ihambisana ne-i ephepheni
        let mut right = 1; // Ihambisana no-j ephepheni
        let mut offset = 0; // Ihambisana no-k ephepheni, kepha iqala ngo-0
        // ukuqondanisa inkomba engu-0.
        let mut period = 1; // Ihambisana nep ekhasini
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Isijobelelo sincane, isikhathi siyisiqalo sonke kuze kube manje.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Dlulela phambili ngokuphindaphinda kwesikhathi samanje.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Isijobelelo sikhulu, qala phansi kusuka endaweni yamanje.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// I-TwoWayStr Strategy ivumela i-algorithm ukuthi yeqe okungahambisani ngokushesha okukhulu, noma isebenze ngemodi lapho ikhipha khona iRejects ngokushesha okukhulu.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Yeqa ukufanisa izikhawu ngokushesha okukhulu
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// I-Emit Yenqaba njalo
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}