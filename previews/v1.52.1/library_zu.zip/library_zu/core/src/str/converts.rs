//! Izindlela zokwenza i-`str` kusuka ku-byte slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Iguqula ucezu lwama-byte lube ucezu lwentambo.
///
/// Ucezu lwentambo i-([`&str`]) lwenziwe ngama-byte ([`u8`]), kanti ucezu lwe-byte ([`&[u8]`][byteslice]) lwenziwe ngamabhayithi, ngakho-ke lo msebenzi uguquka phakathi kwalokhu okubili.
/// Akuzona zonke izingcezu ze-byte eziyizigaxa zezintambo ezivumelekile, noma kunjalo: i-[`&str`] idinga ukuthi iyi-UTF-8 evumelekile.
/// `from_utf8()` amasheke ukuqinisekisa ukuthi ama-byte avumelekile i-UTF-8, bese kuguquka.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Uma uqinisekile ukuthi ucezu lwe-byte luvumelekile i-UTF-8, futhi awufuni ukuzitholela isheke lokuqinisekisa, kunenguqulo engaphephile yalo msebenzi, i-[`from_utf8_unchecked`], enokuziphatha okufanayo kepha yeqa isheke.
///
///
/// Uma udinga i-`String` esikhundleni se-`&str`, cabanga nge-[`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Ngoba ungabela i-`[u8; N]`, futhi ungathatha i-[`&[u8]`][byteslice] yayo, lo msebenzi ungenye yezindlela zokuba nentambo eyabiwe ngesitaki.Kukhona isibonelo salokhu esigabeni sesibonelo ngezansi.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Ibuyisa i-`Err` uma isilayidi singesona i-UTF-8 nencazelo yokuthi ucezu olunikeziwe aluyona i-UTF-8.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::str;
///
/// // amanye ama-byte, ku-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Siyazi ukuthi la mabhayithi avumelekile, ngakho-ke vele usebenzise i-`unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Amabhayithi angalungile:
///
/// ```
/// use std::str;
///
/// // amanye amabhayithi angavumelekile, ku-vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Bona amadokhumenti e-[`Utf8Error`] ukuthola eminye imininingwane ngezinhlobo zamaphutha ezingabuyiselwa.
///
/// I-"stack allocated string":
///
/// ```
/// use std::str;
///
/// // amanye ama-byte, kumalungu afanayo abelwe isitaki
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Siyazi ukuthi la mabhayithi avumelekile, ngakho-ke vele usebenzise i-`unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // UKUPHEPHA: Vele usebenze ukuqinisekiswa.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Iguqula ucezu olungaguquguquki lwama-byte lube ucezu lwentambo eguquguqukayo.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" njenge-vector engaguquguquki
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Njengoba sazi ukuthi la mabhayithi avumelekile, singasebenzisa i-`unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Amabhayithi angalungile:
///
/// ```
/// use std::str;
///
/// // Amanye amabhayithi angavumelekile ku-vector engaguquguquki
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Bona amadokhumenti e-[`Utf8Error`] ukuthola eminye imininingwane ngezinhlobo zamaphutha ezingabuyiselwa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // UKUPHEPHA: Vele usebenze ukuqinisekiswa.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Iguqula ucezu lwama-byte lube ucezu lwentambo ngaphandle kokubheka ukuthi intambo iqukethe i-UTF-8 evumelekile.
///
/// Bona inguqulo ephephile, i [`from_utf8`], ukuthola eminye imininingwane.
///
/// # Safety
///
/// Lo msebenzi awuphephile ngoba awubheki ukuthi ama-byte adluliselwe kuwo avumelekile i-UTF-8.
/// Uma lesi sikhawulo siphuliwe, imiphumela yokuziphatha engachazwanga, njengoba yonke enye i-Rust icabanga ukuthi [`&str`] s zivumelekile i-UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::str;
///
/// // amanye ama-byte, ku-vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi ama-byte `v` yi-UTF-8 evumelekile.
    // Futhi kuncike ku-`&str` naku-`&[u8]` enesakhiwo esifanayo.
    unsafe { mem::transmute(v) }
}

/// Iguqula ucezu lwama-byte lube ucezu lwentambo ngaphandle kokubheka ukuthi intambo iqukethe i-UTF-8 evumelekile;Uhlobo olungaguquguquka.
///
///
/// Bona inguqulo engaphenduki, i [`from_utf8_unchecked()`] ukuthola eminye imininingwane.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi ama-byte `v`
    // zivumelekile i-UTF-8, ngakho-ke ukusakazwa ku-`*mut str` kuphephile.
    // Futhi, ukubhekiswa kwesikhombi kuphephile ngoba leso sikhombi sivela kusethenjwa esiqinisekisiwe ukuthi sisebenza ekubhaleni.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}