//! Ukuqaliswa kwe-SipHash.

#![allow(deprecated)] // izinhlobo ezikule mojuli zehlisiwe

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Ukusetshenziswa kwe-SipHash 1-3.
///
/// Lokhu njengamanje kungumsebenzi ozenzakalelayo we-hashing osetshenziswa umtapo wezincwadi ojwayelekile (isb.
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Ukusetshenziswa kwe-SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Ukusetshenziswa kwe-SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// I-SipHash ingumsebenzi ojwayelekile wenhloso: isebenza ngejubane elihle (incintisana ne-Spooky ne-City) futhi ivumela i-_keyed_ hashing enamandla.
///
/// Lokhu kukuvumela ukhiye amatafula akho we-hash kusuka ku-RNG eqinile, njenge-[`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Yize i-algorithm ye-SipHash ibhekwa njengokuqinile ngokuvamile, ayihloselwe izinhloso ze-cryptographic.
/// Kanjalo, konke ukusetshenziswa kwe-cryptographic kwalokhu kuqaliswa yi-_strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // sicubungule amabhayithi amangaki
    state: State,  // Isifundazwe se-hash
    tail: u64,     // ama-byte angasetshenziswanga le
    ntail: usize,  // mangaki amabhayithi asemsileni avumelekile
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, I-v2 ne-v1, i-v3 zivela ngababili ku-algorithm, futhi ukusetshenziswa kwe-simd kwe-SipHash kuzosebenzisa i-vectors ye-v02 ne-v13.
    //
    // Ngokubabeka ngale ndlela ku-struct, umhlanganisi angalanda kokulungiselelwa okumbalwa kwe-simd ngokwakho.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Ukulayisha inani eliphelele lohlobo olufunayo kusuka ekusakazweni kwe-byte, nge-LE oda.
/// Isebenzisa i-`copy_nonoverlapping` ukuvumela umhlanganisi ukuthi akhiqize indlela esebenza kahle kakhulu yokuyilayisha kusuka kukheli okungenzeka ukuthi alivumelanisiwe.
///
///
/// Akuphephile ngoba: inkomba engamakiwe ku-i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Ukulayisha i-u64 kusetshenziswa kufika kuma-byte ayi-7 wocezu lwe-byte.
/// Kubukeka kuxakile kepha izingcingo ze-`copy_nonoverlapping` ezenzeka (nge-`load_int_le!`) zonke zinosayizi abaguqukile futhi zigwema ukubiza i-`memcpy`, elungele ijubane.
///
///
/// Akuphephile ngoba: inkomba engamakiwe ekuqaleni..qala + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // inkomba ye-byte yamanje (evela ku-LSB) kokukhipha i-u64
    let mut out = 0;
    if i + 3 < len {
        // UKUPHEPHA: I-`i` ayinakuba nkulu kune-`len`, futhi ofonayo kufanele aqinisekise
        // ukuthi inkomba iqala..start + len is in bounds.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // UKUPHEPHA: kufana nalokhu okungenhla.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // UKUPHEPHA: kufana nalokhu okungenhla.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Idala i-`SipHasher` entsha ngokhiye bokuqala ababili abasethwe ku-0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Idala i-`SipHasher` ekhishwe kukhiye ohlinzekiwe.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Idala i-`SipHasher13` entsha ngokhiye bokuqala ababili abasethwe ku-0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Idala i-`SipHasher13` ekhishwe kukhiye ohlinzekiwe.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: azikho izindlela zokubala eziphelele (`write_u *`, `write_i*`) ezichaziwe
    // yalolu hlobo.
    // Singabangeza, sikopishe ukusetshenziswa kwe-`short_write` ku-librustc_data_structures/sip128.rs, bese sengeza izindlela ze-`write_u *`/`write_i*` ku-`SipHasher`, `SipHasher13`, naku-`DefaultHasher`.
    //
    // Lokhu kuzosheshisa kakhulu ama-hasher aphelele, ngenani lokwehlisa ijubane lokuhlanganisa isivinini kwamanye amabhentshi.
    // Bona i #69152 ngemininingwane.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // UKUPHEPHA: I-`cmp::min(length, needed)` iqinisekisiwe ukuthi ingabi ngaphezu kwe-`length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Umsila obanjiwe manje usuhluziwe, cubungula ukufaka okusha.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // UKUPHEPHA: ngoba i-`len - left` ingukuphindaphinda okukhulu kakhulu okungu-8 ngaphansi
            // `len`, futhi ngoba i `i` iqala ku `needed` lapho i `len` ingu `length - needed`, i `i + 8` iqinisekisiwe ukuthi ibe ngaphansi noma ilingane ne `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // UKUPHEPHA: I-`i` manje seyi-`needed + len.div_euclid(8) * 8`,
        // ngakho-ke i-`i + left` = `needed + len` = `length`, okuyincazelo elingana ne-`msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Idala i-`Hasher<S>` ngezinkinobho ezimbili zokuqala ezisethwe ku-0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}