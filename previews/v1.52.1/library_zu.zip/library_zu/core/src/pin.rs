//! Izinhlobo ezifaka idatha endaweni yayo kwimemori.
//!
//! Kwesinye isikhathi kuyasiza ukuba nezinto eziqinisekisiwe ukuthi zingahambi, ngomqondo wokuthi ukubekwa kwazo enkumbulweni akuguquki, ngakho-ke kungathenjelwa kukho.
//! Isibonelo esivelele sesimo esinjalo kungaba ukwakha izitebhisi zokuzikhethela, ngoba ukuhambisa into enezikhombisi kuyo kuzokwenza kungasebenzi, okungadala isimilo esingachazeki.
//!
//! Ezingeni eliphakeme, i-[`Pin<P>`] iqinisekisa ukuthi i-pointee yanoma yiluphi uhlobo lwesikhombi i-`P` inendawo ezinzile kwimemori, okusho ukuthi ayikwazi ukuhanjiswa kwenye indawo futhi inkumbulo yayo ayikwazi ukuhanjiswa ize ilahle.Sithi i-pointee ngu-"pinned".Izinto ziba nobuqili ngokwengeziwe lapho kukhulunywa ngezinhlobo ezihlanganisa okuphiniwe nemininingwane engaphiniwe;[see below](#projections-and-structural-pinning) ukuthola eminye imininingwane.
//!
//! Ngokuzenzakalelayo, zonke izinhlobo ku-Rust ziyahanjiswa.
//! I-Rust ivumela ukudlulisa zonke izinhlobo ngenani, futhi izinhlobo ezijwayelekile ze-smart-pointer ezinjenge-[`Box<T>`] ne-`&mut T` zivumela ukufaka esikhundleni nokuhambisa amanani aqukethe: ungaphuma ku-[`Box<T>`], noma ungasebenzisa i-[`mem::swap`].
//! [`Pin<P>`] isonga uhlobo lwesikhombi `P`, ngakho [`Pin`]`<<`[`Box`] `<T>>`isebenza kakhulu njengokujwayelekile
//!
//! [`Box<T>`]: when a [`Pin`]`<<[`Box`]` `<T>>`iyalahlwa, kanjalo nokuqukethwe kwayo, nememori iyathola
//!
//! kususwe.Ngokufanayo, [`Pin`]`<&mut T>`ifana kakhulu ne `&mut T`.Kodwa-ke, i-[`Pin<P>`] ayivumeli amaklayenti ukuthi athole i-[`Box<T>`] noma i-`&mut T` kwimininingwane ephiniwe, okusho ukuthi awukwazi ukusebenzisa imisebenzi efana ne-[`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` idinga i `&mut T`, kepha asikwazi ukuyithola.
//!     // Simile, asikwazi ukushintshanisa okuqukethwe yilezi zinkomba.
//!     // Singasebenzisa i-`Pin::get_unchecked_mut`, kepha lokho akuphephile ngesizathu:
//!     // asivunyelwe ukuyisebenzisela ukususa izinto kwi-`Pin`.
//! }
//! ```
//!
//! Kuyafaneleka ukuphinda uthi i-[`Pin<P>`]*ayilishintshi iqiniso lokuthi umhlanganisi we-Rust ubheka zonke izinhlobo ezihambayo.I-[`mem::swap`] ihlala ingabiza nganoma iyiphi i-`T`.Esikhundleni salokho, i-[`Pin<P>`] ivimbela amanani athile*(akhonjwe yizikhombi ezisongwe nge-[`Pin<P>`]) ekuhanjisweni ngokwenza kube nzima ukubiza izindlela ezidinga i-`&mut T` kuzo (njenge-[`mem::swap`]).
//!
//! [`Pin<P>`] ingasetshenziselwa ukugoqa noma yiluphi uhlobo lwesikhombi `P`, futhi ngenxa yalokho ixhumana ne [`Deref`] ne [`DerefMut`].I-[`Pin<P>`] lapho i-`P: Deref` kufanele ibhekwe njenge-"`P`-style pointer" kuya ku-`P::Target` ephiniwe-ngakho-ke, [`Pin`]`<<([`Box`]`<T>> `yisikhombi esinomnikazi we-`T` ephiniwe, ne-[` Pin`]`<<[[Rc`]`<T>> `yisikhombi esibalwe njengesethenjwa ku-`T` ephiniwe.
//! Ngokunemba, i [`Pin<P>`] ithembela ekusetshenzisweni kwe [`Deref`] ne [`DerefMut`] ukuze ingaphumi kupharamitha yayo ye `self`, futhi ihlale ibuyisa isikhombisi kwimininingwane ephiniwe lapho ibizwa kusikhombi esikhonjiwe.
//!
//! # `Unpin`
//!
//! Izinhlobo eziningi zihlala zihanjiswa ngokukhululeka, noma ngabe ziphiniwe, ngoba azithembi ekubeni nekheli elizinzile.Lokhu kufaka zonke izinhlobo eziyisisekelo (njenge-[`bool`], [`i32`], nezinkomba) kanye nezinhlobo eziqukethe lezi zinhlobo kuphela.Izinhlobo ezingakhathaleli ukuphina zisebenzisa i-[`Unpin`] auto-trait, ekhansela umphumela we-[`Pin<P>`].
//! Okwe `T: Unpin`, [`Pin`]`<<[`Box`]`<T>> `nomsebenzi we-[`Box<T>`] ngokufanayo, njengoba kwenza [` Pin`]`<&mut T>` ne-`&mut T`.
//!
//! Qaphela ukuthi ukuphina ne-[`Unpin`] kuthinta kuphela uhlobo olukhonjisiwe i-`P::Target`, hhayi uhlobo lwesikhombi `P` uqobo esigoqwe ku-[`Pin<P>`].Isibonelo, noma ngabe i-[`Box<T>`] iyi-[`Unpin`] ayinamphumela ekuziphatheni kwe-[`Pin`]`<<`[`Box`] `<T>>`(lapha, i-`T` wuhlobo olukhonjisiwe).
//!
//! # Isibonelo: isakhiwo esizimele
//!
//! Ngaphambi kokungena emininingwaneni eminingi ukuchaza iziqinisekiso nezinketho ezihambisana ne `Pin<T>`, sixoxa ngezibonelo ezithile zokuthi ingasetshenziswa kanjani.
//! Zizwe ukhululekile ku [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Lesi isakhiwo esizimele ngoba inkambu yesilayidi ikhomba kunkambu yedatha.
//! // Asikwazi ukwazisa umhlanganisi ngalokho ngesethenjwa esijwayelekile, ngoba leli phethini alikwazi ukuchazwa ngemithetho ejwayelekile yokuboleka.
//! //
//! // Esikhundleni salokho sisebenzisa isikhombisi esiluhlaza, noma sisaziwa ukuthi asilutho, njengoba sazi ukuthi sikhomba entanjeni.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Ukuqinisekisa ukuthi idatha ayinyakazi lapho umsebenzi ubuya, siyibeka enqwabeni lapho izohlala khona impilo yonke yento, futhi ukuphela kwendlela yokuyithola kungaba ngesikhombi kuyo.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // sakha isikhombisi kuphela uma idatha isikhona kungenjalo izobe isivele ihambile ngaphambi kokuthi siqale
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // siyazi ukuthi lokhu kuphephile ngoba ukuguqula inkambu akuhambisi isakhiwo sonke
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Isikhombi kufanele sikhombe indawo eyiyo, inqobo nje uma i-struct ingahambanga.
//! //
//! // Okwamanje, sikhululekile ukuhambisa isikhombi.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Njengoba uhlobo lwethu lungasebenzisi i-Unpin, lokhu kuzohluleka ukuhlanganisa:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Isibonelo: uhlu oluxhunyaniswe kabili oluphazamisayo
//!
//! Kuhlu oluxhunyaniswe kabili oluphazamisayo, iqoqo empeleni alinikezi imemori yezinto uqobo.
//! Ukwabiwa kulawulwa ngamakhasimende, futhi izinto zingahlala kuhlaka lwesitaki oluhlala lufushane kuneqoqo.
//!
//! Ukwenza lo msebenzi, yonke into inezikhombisi kulowo owandulelayo nozothatha isikhundla ohlwini.Izinto zingangezwa kuphela lapho ziphiniwe, ngoba ukuhambisa izinto ezizungezile kuzokwenza izinkomba zingasebenzi.Ngaphezu kwalokho, ukuqaliswa kwe-[`Drop`] kwento yohlu exhunyiwe kuzonamathisela izikhombisi zalowo owandulelayo nowangena esikhundleni sakhe ukuze zisuse ohlwini.
//!
//! Ngokweqile, kufanele sikwazi ukuthembela ekubizeni kwe-[`drop`].Uma into ingahanjiswa noma ngenye indlela ingasebenzi ngaphandle kokubiza i-[`drop`], izikhombisi ezikuyo ezivela ezintweni ezingomakhelwane zizoba ezingavumelekile, ezingaphula ukwakheka kwedatha.
//!
//! Ngakho-ke, ukuphina futhi kuza nesiqinisekiso esihlobene ne-[`drop"].
//!
//! # `Drop` guarantee
//!
//! Inhloso yokuphina ukwazi ukuthembela ekubekweni kwedatha ethile kwimemori.
//! Ukwenza lo msebenzi, hhayi nje ukuhambisa imininingwane kunqunyelwe;Ukuhambisa kabusha, ukufaka kabusha, noma ukwenza imemori esetshenziselwe ukugcina idatha kungavinjelwe, nakho.
//! Ngokukholwayo, ngemininingwane ephiniwe kufanele ugcine okungaguquguquki ukuthi *inkumbulo yayo ngeke ivunyelwe noma iphinde ibuyiselwe emuva kusukela lapho iphiniwe kuze kube yilapho kubizwa i [`drop`]*.Kanye kuphela lapho i-[`drop`] ibuya noma i-panics, imemori ingaphinde isetshenziswe.
//!
//! Imemori ingaba yi-"invalidated" ngokuhanjiswa, kepha futhi ngokufaka i-[`Some(v)`] nge-[`None`], noma ukubiza i-[`Vec::set_len`] ku-"kill" ezinye izinto zisuswe ku-vector.Ingaphinde ikhethwe kabusha ngokusebenzisa i-[`ptr::write`] ukuyibhala ngaphezulu ngaphandle kokubiza umbhubhisi kuqala.Akukho kulokhu okuvunyelwe kwimininingwane ephiniwe ngaphandle kokushayela i-[`drop`].
//!
//! Lolu yilona kanye uhlobo lwesiqinisekiso sokuthi uhlu oluxhunyanisiwe oluthintekayo oluvela esigabeni esedlule ludinga ukusebenza kahle.
//!
//! Qaphela ukuthi lesi siqinisekiso asisho *ukuthi inkumbulo ayivuzi!Kusalungile ngokuphelele ukuthi ungaze ushayele i-[`drop`] entweni ephiniwe (isb., Usengashayela i-[`mem::forget`] ku-[`Pin`]`<<`[`Box`] `<T>>`).Esibonelweni sohlu oluxhunywe kabili, leyo nto ingahlala nje ohlwini.Kodwa-ke ungeke usikhulule noma usisebenzise kabusha isitoreji* ngaphandle kokushaya i-[`drop`] *.
//!
//! # `Drop` implementation
//!
//! Uma uhlobo lwakho lisebenzisa ukuphina (njengezibonelo ezimbili ezingenhla), kufanele uqaphele lapho usebenzisa i-[`Drop`].Umsebenzi we-[`drop`] uthatha i-`&mut self`, kepha lokhu kubizwa *noma ngabe uhlobo lwakho belukade luphiniwe phambilini*!Kunjengokungathi umhlanganisi ubizwa ngokuzenzakalela i-[`Pin::get_unchecked_mut`].
//!
//! Lokhu ngeke kuze kubangele inkinga kwikhodi ephephile ngoba ukusebenzisa uhlobo oluthembele ekuphiniwe kudinga ikhodi engaphephile, kepha qaphela ukuthi ukunquma ukusebenzisa ukuphina ohlobo lwakho (ngokwesibonelo ngokuqalisa ukusebenza okuthile ku-[`Pin`]`<&Self>`noma [`Pin`] `<&mut Self>` `) kunemiphumela ekusetshenzisweni kwakho kwe [`Drop`] futhi: uma ngabe into yohlobo lwakho ibingaphinwa, kufanele uphathe i [`Drop`] njengokuthatha ngokuphelele [` Pin`]`<<&mut Ukuzimela> `.
//!
//!
//! Isibonelo, ungasebenzisa i-`Drop` ngokulandelayo:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` kulungile ngoba siyazi ukuthi leli nani aliphinde lisetshenziswe ngemuva kokulahlwa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Ikhodi yangempela yokudonsa iya lapha.
//!         }
//!     }
//! }
//! ```
//!
//! Umsebenzi `inner_drop` unohlobo okumele u [`drop`] * abe nalo, ngakho-ke lokhu kuqinisekisa ukuthi awusebenzisi ngephutha i `self`/`this` ngendlela engqubuzana nokuphina.
//!
//! Ngaphezu kwalokho, uma uhlobo lwakho luyi-`#[repr(packed)]`, umhlanganisi uzohambisa izinkambu ngokuzenzekelayo azokwazi ukuzilahla.Kungakwenzela lokho nasemikhakheni eyenzeka iqondaniswe ngokwanele.Ngenxa yalokho, awukwazi ukusebenzisa ukuphina ngohlobo lwe-`#[repr(packed)]`.
//!
//! # Ukuqagela nokuphina okwakhiwe
//!
//! Lapho usebenza ngezakhiwo eziphiniwe, umbuzo uvela ukuthi umuntu angafinyelela kanjani izinkambu zaleso sakhiwo ngendlela ethatha nje [`Pin`]`<&mut Struct>`.
//! Indlela ejwayelekile ukubhala izindlela zabasizi (ezibizwa ngokuthi *ukuqagela*) eziguqula [`Pin`]`<&mut Struct>`zibe inkomba yenkambu, kepha leso sithenjwa kufanele sibe nohlobo luni?Ingabe i-[`Pin`]`<&mut Field>`noma i `&mut Field`?
//! Umbuzo ofanayo uvela ngezinkambu ze-`enum`, futhi futhi uma ucubungula izinhlobo ze-container/wrapper ezinjenge-[`Vec<T>`], [`Box<T>`], noma i-[`RefCell<T>`].
//! (Lo mbuzo usebenza kuzo zombili izinkomba eziguqukayo nezabelwe, simane sisebenzise isimo esivame kakhulu sezinkomba eziguqukayo lapha ukwenza umfanekiso.)
//!
//! Kuvela ukuthi empeleni kuxhomeke kumbhali wesakhiwo sedatha ukuthi anqume ukuthi ngabe ukuqagela okuphiniwe kwenkambu ethile kuguqula [`Pin`]`<&mut Struct>`ibe [[Pin`]` <<mut mut>> `noma I-`&mut Field`.Kukhona ezinye izingqinamba noma kunjalo, futhi umkhawulo obaluleke kakhulu ukuvumelana *:
//! yonke inkambu ingakhonjwa *kusethenjwa esiphiniwe,* noma * kususwe ukuphina njengengxenye yesilinganiso.
//! Uma zombili zenzelwe insimu efanayo, lokho kungahle kungabi nalutho!
//!
//! Njengombhali wesakhiwo sedatha kufanele uthathe isinqumo ngenkambu ngayinye ukuthi uphina i-"propagates" kule nkambu noma cha.
//! Ukuphina okusabalalisa kubizwa nangokuthi i "structural", ngoba ilandela ukwakheka kohlobo.
//! Ezigatshaneni ezilandelayo, sichaza ukucatshangelwa okufanele kwenziwe kunoma iyiphi inketho.
//!
//! ## Ukuphina * akuyona into eyakhiwayo ye `field`
//!
//! Kungabonakala njengokuphikisana nokuthi inkambu yesakhiwo esiphiniwe kungenzeka ingaphinwa, kepha lokho empeleni kuyindlela elula kunazo zonke: uma i-[`Pin`]`<&mut Field>`ingakaze idalwe, akukho okungahambi kahle!Ngakho-ke, uma uthatha isinqumo sokuthi inkambu ethile ayinakho ukuphina okwakhiwe, okumele ukukuqinisekise nje ukuthi awusoze wakha ireferensi ephiniwe kuleyo nkambu.
//!
//! Izinkambu ezingenakho ukuphina okwakhiwe zingaba nendlela yokuqagela eguqula [`Pin`]`<&mut Struct>`ibe yi-`&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Lokhu kulungile ngoba i `field` ayikaze icatshangwe ukuthi iphiniwe.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Ungahle futhi ube ne-`impl Unpin for Struct`*noma ngabe* uhlobo lwe-`field` akuyona i-[`Unpin`].Okucatshangwa yilolo hlobo ngokuphina akubalulekile uma kungekho [`Pin`]`<&mut Field>`` eyake yakhiwa.
//!
//! ## Ukuphina * kusakhiwo se `field`
//!
//! Enye inketho ukunquma ukuthi ukuphina yi-"structural" ye-`field`, okusho ukuthi uma isakhiwo siphiniwe kanjalo nensimu.
//!
//! Lokhu kuvumela ukubhala ukuqagela okudala i-[`Pin`]`<&mut Field>``, Ngalokho kufakaza ukuthi inkambu iphiniwe:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Lokhu kulungile ngoba i-`field` iphiniwe lapho i-`self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Noma kunjalo, ukuphina kwesakhiwo kuza nezidingo ezimbalwa ezingeziwe:
//!
//! 1. Isakhiwo kufanele sibe yi-[`Unpin`] kuphela uma zonke izinkambu zesakhiwo ziyi-[`Unpin`].Lokhu okuzenzakalelayo, kepha i-[`Unpin`] iyi-trait ephephile, ngakho-ke njengombhali wesakhiwo kungumsebenzi wakho *hhayi* ukufaka into efana ne `impl<T> Unpin for Struct<T>`.
//! (Qaphela ukuthi ukufaka umsebenzi wokuqagela kudinga ikhodi engaphephile, ngakho-ke iqiniso lokuthi i-[`Unpin`] iyi-trait ephephile ayiphuli umgomo wokuthi kufanele ukhathazeke nganoma yikuphi kwalokhu uma usebenzisa okungaphephile`.)
//! 2. Umbhubhisi wesakhiwo akumele asuse izinkambu zesakhiwo kungxabano yaso.Leli yiphuzu ngqo elikhuliswe ku-[previous section][drop-impl]: I-`drop` ithatha i-`&mut self`, kepha i-struct (futhi ngenxa yalokho izinkambu zayo) kungenzeka ukuthi iphiniwe phambilini.
//!     Kufanele uqinisekise ukuthi awuhambisi inkambu ngaphakathi kokuqaliswa kwe-[`Drop`].
//!     Ikakhulu, njengoba kuchaziwe phambilini, lokhu kusho ukuthi isakhiwo sakho akumele sibe * yi-`#[repr(packed)]`.
//!     Bona leso sigaba sendlela yokubhala i [`drop`] ngendlela yokuthi umhlanganisi angakusiza ukuthi ungaphuli ngephutha ukuphina.
//! 3. Kufanele uqiniseke ukuthi uphakamisa i [`Drop` guarantee][drop-guarantee]:
//!     uma isakhiwo sakho siphiniwe, imemori equkethe okuqukethwe ayibhalwa phansi noma ihanjiswe ngaphandle kokubiza ababhubhisi bokuqukethwe.
//!     Lokhu kungaba yinkohliso, njengoba kufakazelwe yi [`VecDeque<T>`]: umbhubhisi we [`VecDeque<T>`] angahluleka ukubiza i-[`drop`] kuzo zonke izinto uma omunye wababhubhisi u panics.Lokhu kwephula isiqinisekiso se-[`Drop`], ngoba kungaholela ekutheni izinto zihanjiswe ngaphandle kokubizwa kombhubhisi wazo.(I-[`VecDeque<T>`] ayinakho ukuqagela okuphiniwe, ngakho-ke lokhu akubangeli ukungaqondi.)
//! 4. Akufanele unikeze noma yikuphi okunye ukusebenza okungaholela ekudlulisweni kwedatha ngaphandle kwezinkambu zesakhiwo lapho uhlobo lwakho luphiniwe.Isibonelo, uma i-struct iqukethe i-[`Option<T>`] futhi kukhona ukusebenza okufana nokuthatha nohlobo `fn(Pin<&mut Struct<T>>) -> Option<T>`, lowo msebenzi ungasetshenziswa ukukhipha i-`T` ngaphandle kwe-`Struct<T>` ephiniwe-okusho ukuthi ukuphina akukwazi ukwakhiwa kwenkambu ebambe lokhu idatha.
//!
//!     Ngesibonelo esiyinkimbinkimbi sokuhambisa idatha ngohlobo oluphiniwe, cabanga ukuthi ngabe i-[`RefCell<T>`] ibinendlela engu-`fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Ngemuva kwalokho singenza okulandelayo:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Lokhu kuyinhlekelele, kusho ukuthi singaphina kuqala okuqukethwe yi-[`RefCell<T>`] (sisebenzisa i-`RefCell::get_pin_mut`) bese sigudluza lokho okuqukethwe sisebenzisa isethenjwa esiguquguqukayo esisithole kamuva.
//!
//! ## Examples
//!
//! Ohlobo olufana ne-[`Vec<T>`], womabili amathuba (ukuphina okwakhiwe noma cha) kunengqondo.
//! I-[`Vec<T>`] enokuphina okwakhiwe ingaba nezindlela ze-`get_pin`/`get_pin_mut` zokuthola izinkomba eziphiniwe zezinto.Kodwa-ke, ayikwazanga * ukuvumela ukubiza i-[`pop`][Vec::pop] ku-[`Vec<T>`] ephiniwe ngoba lokho kungahambisa okuqukethwe (okuphiniwe kahle)!Futhi ibingavumeli i-[`push`][Vec::push], engahle ihlukanise futhi futhi ihambise nokuqukethwe.
//!
//! I-[`Vec<T>`] ngaphandle kokuphina okwakhiwe ingahle ibe yi-`impl<T> Unpin for Vec<T>`, ngoba okuqukethwe akukaze kuphinwe futhi i-[`Vec<T>`] uqobo nayo ilungile ngokuhanjiswa.
//! Ngaleso sikhathi ukuphina akunamthelela nakancane ku-vector.
//!
//! Kumtapo wezincwadi ojwayelekile, izinhlobo zesikhombi ngokuvamile azinakho ukuphina okwakhiwe, futhi ngenxa yalokho azikuniki ukuqagela okuphiniwe.Kungakho i-`Box<T>: Unpin` ibamba yonke i-`T`.
//! Kunengqondo ukukwenza lokhu ngezinhlobo zesikhombi, ngoba ukuhambisa i `Box<T>` empeleni akuyisusi i `T`: i [`Box<T>`] ingahambiseka ngokukhululeka (aka `Unpin`) noma ngabe i `T` ingekho.Empeleni, ngisho [`Pin`]`<<[[Box]]`<T>> `futhi [` Pin`]`<&mut T>` bahlala be-[`Unpin`] uqobo, ngesizathu esifanayo: okuqukethwe kwabo (i-`T`) kuphiniwe, kepha izikhombisi uqobo zingasuswa ngaphandle kokuhambisa imininingwane ephiniwe.
//! Kokubili i-[`Box<T>`] ne-[`Pin`]``<` [`Box`]`<T>>`, Ukuthi okuqukethwe kuphiniwe kuzimele ngokuphelele ekutheni isikhombisi siphiniwe, okusho ukuthi ukuphina * akukona okwakhiwe.
//!
//! Lapho usebenzisa i-[`Future`] combinator, imvamisa uzodinga ukuphina okwakhiwe kwe-futures esidleke, njengoba udinga ukuthola izinkomba eziphiniwe kubo ukuze ushayele i-[`poll`].
//! Kepha uma isihlanganisi sakho siqukethe noma iyiphi enye idatha engadingi ukuphina, ungenza lezo zinkambu zingabi ngesakhiwo ngakho-ke ufinyelele kuzo ngokukhululeka ngesethenjwa esiguquguqukayo noma ngabe une-[`Pin`]`<&mut Self>`` (such njengokuqalisa kwakho kwe [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Isikhombi esiphiniwe.
///
/// Lesi isisongelo esizungeze uhlobo lwesikhombi esenza leyo pointer "pin" ivelu yayo isendaweni, evimbela inani elikhonjwe yilelo pointer ukuthi lisuswe ngaphandle kokuthi lisebenzise i [`Unpin`].
///
///
/// *Bona imibhalo ye [`pin` module] ukuthola incazelo yokuphina.*
///
/// [`pin` module]: self
///
// Note: i `Clone` etholakala ngezansi ibangela ukungaqondakali njengoba kungenzeka ukusebenzisa
// `Clone` ukuthola izinkomba eziguqukayo.
// Bona i <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> ukuthola eminye imininingwane.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Ukuqaliswa okulandelayo akutholwanga ukuze kugwenywe izingqinamba ezizwakalayo.
// `&self.pointer` akufanele kufinyeleleke ekusetshenzisweni okungathembeki kwe-trait.
//
// Bona i <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> ukuthola eminye imininingwane.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Yakha i-`Pin<P>` entsha ezungeze isikhombi sedatha ethile yohlobo olusebenzisa i-[`Unpin`].
    ///
    /// Ngokungafani ne-`Pin::new_unchecked`, le ndlela iphephile ngoba izinkomba zesikhombi ze-`P` zohlobo [`Unpin`], ezikhansela iziqinisekiso zokuphina.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // UKUPHEPHA: inani elikhonjwe ku-`Unpin`, ngakho-ke alinazo izidingo
        // ukuzungeza ukuphina.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Isonga le `Pin<P>` ibuyisa isikhombisi esingaphansi.
    ///
    /// Lokhu kudinga ukuthi idatha engaphakathi kwale `Pin` ibe yi-[`Unpin`] ukuze sikwazi ukuziba okungenayo okuphina lapho sikuvula.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Yakha i-`Pin<P>` entsha ezungeze ireferensi yedatha ethile yohlobo olungasebenzisa noma olungasebenzisi i-`Unpin`.
    ///
    /// Uma izinkomba ze-`pointer` zohlobo `Unpin`, i `Pin::new` kufanele isetshenziswe esikhundleni salokho.
    ///
    /// # Safety
    ///
    /// Lo makhi akaphephile ngoba asikwazi ukuqinisekisa ukuthi idatha ekhonjwe yi-`pointer` iphiniwe, okusho ukuthi idatha ngeke isuswe noma isitoreji sayo singasebenzi kuze kube yilapho ilahlwa.
    /// Uma i-`Pin<P>` eyakhiwe ingaqinisekisi ukuthi i-data `P` ikhomba kuyo iphiniwe, lokho kungukwephula isivumelwano se-API futhi kungaholela ekuziphatheni okungachazwanga ekusebenzeni kwe-(safe) kamuva.
    ///
    /// Ngokusebenzisa le ndlela, wenza i-promise mayelana nokuqaliswa kwe-`P::Deref` ne-`P::DerefMut`, uma kukhona.
    /// Okubaluleke kakhulu, akumele baphume ezingxabanweni zabo ze-`self`: I-`Pin::as_mut` ne-`Pin::as_ref` bazobiza i-`DerefMut::deref_mut` ne-`Deref::deref`*kusikhombi esikhonjiwe* futhi balindele ukuthi lezi zindlela ziphakamise okufikayo kokuphina.
    /// Ngaphezu kwalokho, ngokubiza le ndlela wena promise ukuthi izingcaphuno ze-`P` ngeke zisasuswa futhi;ikakhulukazi, akumele kube khona ukuthola i-`&mut P::Target` bese uphuma kuleso sithenjwa (usebenzisa, ngokwesibonelo [`mem::swap`]).
    ///
    ///
    /// Isibonelo, ukubiza i-`Pin::new_unchecked` nge-`&'a mut T` akuphephile ngoba ngenkathi ukwazi ukuyinamathisela isikhathi sokuphila esinikeziwe i-`'a`, awukwazi ukulawula ukuthi igcinwa iphiniwe uma i-`'a` isiphelile:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Lokhu kufanele kusho ukuthi i-pointee `a` ngeke iphinde inyakaze.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Ikheli le `a` lishintshele kwisitaki se-`b`, ngakho-ke i `a` yahanjiswa yize sasike sayiphina phambilini!Sephule isivumelwano sokuphina se-API.
    /////
    /// }
    /// ```
    ///
    /// Inani, uma liphiniwe, kufanele lihlale liphiniwe unomphela (ngaphandle kokuthi uhlobo lwalo lusebenzisa i-`Unpin`).
    ///
    /// Ngokufanayo, ukubiza i-`Pin::new_unchecked` nge-`Rc<T>` akuphephile ngoba kungaba khona izibizo kudatha efanayo engaphansi kwemikhawulo yokuphina:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Lokhu kufanele kusho ukuthi i-pointee ngeke iphinde inyakaze.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Manje, uma i-`x` bekungukuphela kwesethenjwa, sinesethenjwa esiguquguqukayo sedatha esiyibambe ngaphezulu, esingayisebenzisa ukuyisusa njengoba sibonile esibonelweni esedlule.
    ///     // Sephule isivumelwano sokuphina se-API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ithola ireferensi eyabiwe ephiniwe kusuka kulesi sikhombi esiphiniwe.
    ///
    /// Le ndlela ejwayelekile ukusuka ku-`&Pin<Pointer<T>>` kuye ku-`Pin<&T>`.
    /// Kuphephile ngoba, njengengxenye yesivumelwano se-`Pin::new_unchecked`, i-pointee ayikwazi ukuhamba ngemuva kokuthi i-`Pin<Pointer<T>>` idaliwe.
    ///
    /// "Malicious" ukuqaliswa kwe-`Pointer::Deref` nakho kukhishwe ngaphandle kwenkontileka ye `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // UKUPHEPHA: bona imibhalo ngalo msebenzi
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Isonga le `Pin<P>` ibuyisa isikhombisi esingaphansi.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile.Kufanele uqinisekise ukuthi uzoqhubeka nokuphatha i-pointer `P` njengoba iphiniwe ngemuva kokubiza lo msebenzi, ukuze okungenayo kohlobo lwe-`Pin` kugcinwe.
    /// Uma ikhodi esebenzisa i-`P` evelayo ingaqhubeki nokugcina okokufaka okuphiniwe okwephula inkontileka ye-API futhi kungaholela ekuziphatheni okungachazwanga ekusebenzeni kwe (safe) kamuva.
    ///
    ///
    /// Uma imininingwane eyisisekelo ingu-[`Unpin`], i-[`Pin::into_inner`] kufanele isetshenziswe esikhundleni salokho.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ithola ireferensi ephathekayo ephiniwe kusuka kulesi sikhombi esiphiniwe.
    ///
    /// Le ndlela ejwayelekile ukusuka ku-`&mut Pin<Pointer<T>>` kuye ku-`Pin<&mut T>`.
    /// Kuphephile ngoba, njengengxenye yesivumelwano se-`Pin::new_unchecked`, i-pointee ayikwazi ukuhamba ngemuva kokuthi i-`Pin<Pointer<T>>` idaliwe.
    ///
    /// "Malicious" ukuqaliswa kwe-`Pointer::DerefMut` nakho kukhishwe ngaphandle kwenkontileka ye `Pin::new_unchecked`.
    ///
    /// Le ndlela iyasebenziseka lapho wenza izingcingo eziningi emisebenzini esebenzisa uhlobo oluphiniwe.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // enza into
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` kudla i-`self`, ngakho-ke buyisa kabusha i-`Pin<&mut Self>` nge-`as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // UKUPHEPHA: bona imibhalo ngalo msebenzi
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Inika inani elisha kwimemori ngemuva kwesethenjwa esiphiniwe.
    ///
    /// Lokhu kubhala ngaphezulu idatha ephiniwe, kepha lokho kulungile: umbhubhisi wayo uqala ukusebenza ngaphambi kokuthi ubhalwe phansi, ngakho-ke asikho isiqinisekiso sokuphina esephulwayo.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Wakha iphini entsha ngokufaka imephu inani langaphakathi.
    ///
    /// Isibonelo, uma ufuna ukuthola i-`Pin` yenkambu yento ethile, ungakusebenzisa lokhu ukufinyelela kuleyo nkambu kulayini owodwa wekhodi.
    /// Kodwa-ke, kukhona ama-gotchas amaningi analawa ma "pinning projections";
    /// bona imibhalo ye [`pin` module] ukuthola eminye imininingwane ngaleso sihloko.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile.
    /// Kufanele uqinisekise ukuthi idatha oyibuyisayo ngeke ihambe inqobo nje uma inani lokuphikisana lingasuki (ngokwesibonelo, ngoba lingenye yezinkambu zalelo nani), nokuthi awusuki empikiswaneni oyithola umsebenzi wangaphakathi.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // UKUPHEPHA: inkontileka yezokuphepha ye `new_unchecked` kumele ibe njalo
        // kugcinwa ofonayo.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ithola ireferensi eyabiwayo iphini.
    ///
    /// Lokhu kuphephile ngoba akunakwenzeka ukuphuma kusithenjwa esabiwe.
    /// Kungabonakala ngathi kunodaba lapha ngokuguquguquka kwangaphakathi: empeleni,*kungenzeka* ukukhipha i `T` ngaphandle kwe `&RefCell<T>`.
    /// Kodwa-ke, lokhu akuyona inkinga inqobo nje uma ingekho i-`Pin<&T>` ekhomba idatha efanayo, futhi i-`RefCell<T>` ayikuvumeli ukuthi wenze ireferensi ephiniwe kokuqukethwe kwayo.
    ///
    /// Bona ingxoxo ku ["pinning projections"] ukuthola eminye imininingwane.
    ///
    /// Note: I-`Pin` futhi isebenzisa i-`Deref` kulitshe, elingasetshenziswa ukufinyelela inani langaphakathi.
    /// Kodwa-ke, i-`Deref` inikezela kuphela ngesethenjwa esiphila isikhathi eside njengokubolekwa kwe-`Pin`, hhayi impilo ye `Pin` uqobo.
    /// Le ndlela ivumela ukuguqula i-`Pin` ibe ireferensi ngempilo efanayo ne-`Pin` yoqobo.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Iguqula le `Pin<&mut T>` ibe yi-`Pin<&T>` ngempilo efanayo.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ithola ireferensi engaguquguquki yedatha engaphakathi kwale `Pin`.
    ///
    /// Lokhu kudinga ukuthi idatha engaphakathi kwale `Pin` ibe yi-`Unpin`.
    ///
    /// Note: I-`Pin` ibuye isebenzise i-`DerefMut` kudatha, engasetshenziselwa ukufinyelela inani elingaphakathi.
    /// Kodwa-ke, i-`DerefMut` inikezela kuphela ngesethenjwa esiphila isikhathi eside njengokubolekwa kwe-`Pin`, hhayi impilo ye `Pin` uqobo.
    ///
    /// Le ndlela ivumela ukuguqula i-`Pin` ibe ireferensi ngempilo efanayo ne-`Pin` yoqobo.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ithola ireferensi engaguquguquki yedatha engaphakathi kwale `Pin`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile.
    /// Kufanele uqinisekise ukuthi awusoze wakhipha imininingwane ngaphandle kwesethenjwa esiguquguqukayo osithola lapho ushayela lo msebenzi, ukuze okungenayo kohlobo lwe `Pin` bakwazi ukugcinwa.
    ///
    ///
    /// Uma imininingwane eyisisekelo ingu-`Unpin`, i-`Pin::get_mut` kufanele isetshenziswe esikhundleni salokho.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Yakha iphini entsha ngokumaka inani langaphakathi.
    ///
    /// Isibonelo, uma ufuna ukuthola i-`Pin` yenkambu yento ethile, ungakusebenzisa lokhu ukufinyelela kuleyo nkambu kulayini owodwa wekhodi.
    /// Kodwa-ke, kukhona ama-gotchas amaningi analawa ma "pinning projections";
    /// bona imibhalo ye [`pin` module] ukuthola eminye imininingwane ngaleso sihloko.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile.
    /// Kufanele uqinisekise ukuthi idatha oyibuyisayo ngeke ihambe inqobo nje uma inani lokuphikisana lingasuki (ngokwesibonelo, ngoba lingenye yezinkambu zalelo nani), nokuthi awusuki empikiswaneni oyithola umsebenzi wangaphakathi.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // UKUPHEPHA: umuntu ofonayo unesibopho sokungahambisi i-
        // value Kule nkomba.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // UKUPHEPHA: njengoba inani le-`this` liqinisekisiwe ukuthi alinalo
        // ikhishwe, le kholi eya ku-`new_unchecked` iphephile.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Thola ireferensi ephiniwe kusuka kusithenjwa esimile.
    ///
    /// Lokhu kuphephile, ngoba i `T` ibolekwa impilo ye `'static`, engapheli.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // UKUPHEPHA: I-static loan iqinisekisa ukuthi idatha ngeke ibe yiyo
        // moved/invalidated ize ilahle (okungakaze kube njalo).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Thola inkomba ephikisiwe engaguquguquki evela kusithenjwa esingaguquki esimile.
    ///
    /// Lokhu kuphephile, ngoba i `T` ibolekwa impilo ye `'static`, engapheli.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // UKUPHEPHA: I-static loan iqinisekisa ukuthi idatha ngeke ibe yiyo
        // moved/invalidated ize ilahle (okungakaze kube njalo).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: lokhu kusho ukuthi noma yikuphi ukufakwa kwe `CoerceUnsized` okuvumela ukuphoqelelwa kusuka ku-
// uhlobo olufaka i-`Deref<Target=impl !Unpin>` ohlotsheni olufaka i-`Deref<Target=Unpin>` alunangqondo.
// Noma yikuphi ukufakwa okunjalo kungenzeka kungabi bikho ngenxa yezinye izizathu, noma kunjalo, ngakho-ke sidinga nje ukunakekela ukungavumeli ama-impls anjalo ukuthi ahlale e std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}