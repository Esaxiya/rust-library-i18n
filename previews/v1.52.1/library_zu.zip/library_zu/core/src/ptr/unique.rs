use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Isisongeli esizungeze i-`*mut T` eluhlaza engahluziwe ekhombisa ukuthi umnikazi walesi sisongelo ungumnikazi waso.
/// Ilusizo ekwakhiweni kokukhishwa okufana ne `Box<T>`, `Vec<T>`, `String`, ne `HashMap<K, V>`.
///
/// Ngokungafani ne-`*mut T`, i-`Unique<T>` iziphatha njenge-"as if" bekuyisibonelo se-`T`.
/// Isebenzisa i-`Send`/`Sync` uma i-`T` iyi-`Send`/`Sync`.
/// Kusho nokuthi uhlobo lokuqina oluqinile lokuqinisekisa ukuthi i-`T` ingalindela:
/// okuqondiswa kwesikhombi akufanele kuguqulwe ngaphandle kwendlela eyingqayizivele eya ekubeni kwayo okuhlukile.
///
/// Uma ungaqiniseki ukuthi kulungile ukusebenzisa i-`Unique` ngezinhloso zakho, cabanga ukusebenzisa i-`NonNull`, enama-semantics antekenteke.
///
///
/// Ngokungafani ne-`*mut T`, i-pointer kufanele ihlale ingasebenzi, noma ngabe i-pointer ayikaze iphinde ichazwe.
/// Lokhu kwenzelwa ukuthi ama-enum asebenzise leli nani elinqatshelwe njengokubandlulula-i-`Option<Unique<T>>` inosayizi ofanayo no-`Unique<T>`.
/// Kodwa-ke isikhombisi sisengakhungatheka uma singasetshenziswanga.
///
/// Ngokungafani ne-`*mut T`, i-`Unique<T>` i-covariant ngaphezulu kwe-`T`.
/// Lokhu kufanele ngaso sonke isikhathi kube okulungile kunoma yiluphi uhlobo oluphakamisa izidingo zokuzikhethela ezihlukile.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: lo maki awunamphumela wokwehluka, kodwa uyadingeka
    // ukuze i-dropck iqonde ukuthi sinomnikazi we-`T`.
    //
    // Ngemininingwane, bheka:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` izikhombisi ziyi-`Send` uma i-`T` ingu-`Send` ngoba idatha abayikhombayo iyasetshenziswa.
/// Qaphela ukuthi lokhu okungajwayelekile akusebenzisi uhlelo lohlobo;ukukhishwa okusebenzisa i-`Unique` kufanele kuyiphoqelele.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` izikhombisi ziyi-`Sync` uma i-`T` ingu-`Sync` ngoba idatha abayikhombayo iyasetshenziswa.
/// Qaphela ukuthi lokhu okungajwayelekile akusebenzisi uhlelo lohlobo;ukukhishwa okusebenzisa i-`Unique` kufanele kuyiphoqelele.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Kwakha i `Unique` entsha elengayo, kepha eqondaniswe kahle.
    ///
    /// Lokhu kuyasiza ekuqaliseni izinhlobo ezabiwe ngobuvila, njengoba kwenza i `Vec::new`.
    ///
    /// Qaphela ukuthi inani lesikhombi lingamela isikhombisi esivumelekile ku-`T`, okusho ukuthi lokhu akumele kusetshenziswe njengenani le-"not yet initialized" sentinel.
    /// Izinhlobo ezabiwa ngobuvila kufanele zilandelele ukuqaliswa ngezinye izindlela.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // UKUPHEPHA: I-mem::align_of() ibuyisa isikhombisi esivumelekile, esingenzi lutho.I-
        // Imibandela yokubiza i-new_unchecked() ihlonishwa ngaleyo ndlela.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Idala i `Unique` entsha.
    ///
    /// # Safety
    ///
    /// `ptr` akumele kungasebenzi.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`ptr` ayiyona into engekho.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Idala i-`Unique` entsha uma i-`ptr` ingasebenzi.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // UKUPHEPHA: Isikhombi sesivele sihloliwe futhi asisebenzi.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Ithola isikhombisi esingaphansi se `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ikhetha okuqukethwe.
    ///
    /// Isikhathi sokuphila esiholelekile sibophezelekile kithi ngakho-ke lokhu kuziphatha njenge-"as if" empeleni bekuyisibonelo se-T esibolekwayo.
    /// Uma kudingeka isikhathi eside se-(unbound), sebenzisa i-`&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zereferensi.
        unsafe { &*self.as_ptr() }
    }

    /// Kukhonjiswa ngokuvumelana ngokuqukethwe.
    ///
    /// Isikhathi sokuphila esiholelekile sibophezelekile kithi ngakho-ke lokhu kuziphatha njenge-"as if" empeleni bekuyisibonelo se-T esibolekwayo.
    /// Uma kudingeka isikhathi eside se-(unbound), sebenzisa i-`&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zesethenjwa esiguquguqukayo.
        unsafe { &mut *self.as_ptr() }
    }

    /// Isakaza kusikhombi solunye uhlobo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // UKUPHEPHA: I-Unique::new_unchecked() idala okuyingqayizivele nezidingo ezintsha
        // isikhombi esinikezwe ukuthi singasebenzi.
        // Njengoba sidlula ngokwethu njengesikhombi, akunakuba yize.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // UKUPHEPHA: Isethenjwa esiguquguqukayo asikwazi ukungasebenzi
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}