//! Phatha ngesandla inkumbulo ngezikhombisi eziluhlaza.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Imisebenzi eminingi kule mojule ithatha izikhombisi eziluhlaza njengezimpikiswano futhi uzifunde kusuka noma ubhalele zona.Ukuze lokhu kuphephe, lezi zikhombisi kumele zibe *zivumelekile*.
//! Ukuthi isikhombisi sisebenza ngokuya ngomsebenzi esisetshenziselwa wona (funda noma ukubhala), kanye nobukhulu bememori efinyelelwe (okusho ukuthi mangaki ama-byte ayi-read/written).
//! Imisebenzi eminingi isebenzisa i-`*mut T` ne-`* const T` ukufinyelela inani elilodwa kuphela, lapho imibhalo ishiya usayizi bese ithatha ngokuphelele ukuthi ingamabhayithi we-`size_of::<T>()`.
//!
//! Imithetho eqondile yokusebenza ayikanqunywa okwamanje.Iziqinisekiso ezinikezwe kuleli phuzu zincane kakhulu:
//!
//! * Isikhombi se-[null]*asivumelekile*, ngisho nokufinyelela kwe-[size zero][zst].
//! * Ukuze isikhombisi sisebenze, kuyadingeka, kepha akwenele ngaso sonke isikhathi, ukuthi isikhombisi singaba *esingahlonipheki*: uhla lwememori losayizi onikeziwe oqala kusikhombi kumele lube semingceleni yento eyodwa eyabiwe.
//!
//! Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
//! * Ngisho nasekusebenzeni kwe [size zero][zst], isikhombisi akumele sikhombe kwimemori edlulisiwe, okusho ukuthi, ukuhanjiswa kwedatha kwenza izikhombisi zingavumelekile nakumisebenzi esayizi-zero.
//! Kodwa-ke, ukuphonsa noma yiliphi inani elingewona u-zero *ngokoqobo* kusikhombi kuvumelekile ekufinyelelweni okungusayizi we-zero, noma ngabe inkumbulo ethile ikhona kulelo kheli bese isatshalaliswa.
//! Lokhu kufana nokubhala owabayo owabayo: ukwaba izinto ezilingana no-zero akunzima kangako.
//! Indlela ye-canonical yokuthola isikhombisi esivumelekile ekufinyeleleni okungusayizi we-zero yi-[`NonNull::dangling`].
//! * Konke ukufinyelela okwenziwe ngemisebenzi kule mojule kungukuthi *akuyona i-athomu* ngomqondo we-[atomic operations] osetshenziselwa ukuvumelanisa phakathi kwemicu.
//! Lokhu kusho ukuthi kungukuziphatha okungachazwanga ukwenza ukufinyelela okuhambisanayo endaweni efanayo kusuka kwimicu ehlukene ngaphandle kokuthi bobabili bafinyelela kuphela kufundwa kusuka kwimemori.
//! Qaphela ukuthi lokhu kufaka ngokusobala i-[`read_volatile`] ne-[`write_volatile`]: Ukufinyelela okungajwayelekile akukwazi ukusetshenziselwa ukuvumelanisa kwe-inter-thread.
//! * Umphumela wokuphonsa ireferensi kusikhombi uvumelekile inqobo nje uma into eyisisekelo isaphila futhi asikho ireferensi (izikhombisi eziluhlaza) ezisetshenziselwa ukufinyelela kwimemori efanayo.
//!
//! Lawa ma-axioms, kanye nokusetshenziswa ngokucophelela kwe-[`offset`] ye-pointer arithmetic, anele ukusebenzisa kahle izinto eziningi eziwusizo ngekhodi engaphephile.
//! Iziqinisekiso ezinamandla zizonikezwa ekugcineni, njengoba kunqunywa imithetho ye [aliasing].
//! Ngemininingwane engaphezulu, bheka i [book] kanye nengxenye yesethenjwa enikelwe ku [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Izikhombi eziluhlaza ezivumelekile njengoba kuchaziwe ngenhla azihambelani kahle (lapho ukuqondaniswa kwe-"proper" kuchazwa ngohlobo lwe-pointee, okungukuthi, i-`*const T` kufanele ihambisane ne-`mem::align_of::<T>()`).
//! Kodwa-ke, imisebenzi eminingi idinga ukuthi izimpikiswano zabo ziqondaniswe kahle, futhi izosho ngokusobala le mfuneko kumadokhumenti abo.
//! Ukukhishwa okuphawuleka kulokhu yi-[`read_unaligned`] ne-[`write_unaligned`].
//!
//! Lapho umsebenzi udinga ukuqondaniswa okufanele, wenza kanjalo noma ngabe ukufinyelela kunosayizi 0, okungukuthi, noma imemori ingathintwanga empeleni.Cabanga ukusebenzisa i-[`NonNull::dangling`] ezimweni ezinjalo.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Yenza umchithi (uma kukhona) wenani elikhonjisiwe (uma likhona).
///
/// Lokhu kulingana ngokufana nokubiza i-[`ptr::read`] nokulahla umphumela, kepha kunezinzuzo ezilandelayo:
///
/// * Kuyadingeka * ukusebenzisa i-`drop_in_place` ukulahla izinhlobo ezingasetshenzisiwe njengezinto ze-trait, ngoba azikwazi ukufundwa esitaki futhi zehle ngokujwayelekile.
///
/// * Kungumusa ku-optimizer ukwenza lokhu ngaphezulu kwe-[`ptr::read`] lapho ulahla inkumbulo eyabiwe ngesandla (isb., Ekusebenzeni kwe-`Box`/`Rc`/`Vec`), njengoba umhlanganisi engadingi ukufakazela ukuthi kuzwakala ukusebenzisa i-agar.
///
///
/// * Ingasetshenziselwa ukulahla idatha ye-[pinned] lapho i-`T` kungeyona i-`repr(packed)` (idatha ephiniwe akumele isuswe ngaphambi kokuthi yehliswe).
///
/// Amanani angahlelwanga awakwazi ukudonswa endaweni, kufanele akopishelwe endaweni eqondaniswe kuqala kusetshenziswa i-[`ptr::read_unaligned`].Okwakhiwe okugcwele, lokhu kuhamba kwenziwa ngokuzenzakalela ngumhlanganisi.
/// Lokhu kusho ukuthi izinkambu zeziqu ezigcwele aziphonswa endaweni.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `to_drop` kufanele kube yi-[valid] yakho kokubili okufundwayo nokubhalayo.
///
/// * `to_drop` kumele iqondaniswe kahle.
///
/// * Inani le-`to_drop` elikhomba kufanele livumeleke ekudonselweni phansi, okungasho ukuthi kufanele lisekele okufakiwe okungeziwe, lokhu kuncike kohlobo.
///
/// Ngokwengeziwe, uma i-`T` kungeyona i-[`Copy`], ukusebenzisa inani elikhonjisiwe ngemuva kokushayela i-`drop_in_place` kungadala isimilo esingachazwanga.Qaphela ukuthi i-`*to_drop = foo` ibalwa njengokusetshenziswa ngoba kuzodala ukuthi inani liphinde liphindwe.
/// [`write()`] ingasetshenziselwa ukubhala ngaphezulu idatha ngaphandle kokubangela ukuthi ilahlwe.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ngesandla susa into yokugcina ku-vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Thola isikhombi esiluhlaza entweni yokugcina ku-`v`.
///     let ptr = &mut v[1] as *mut _;
///     // Fushanisa i-`v` ukuvikela into yokugcina ukuthi yehliswe.
///     // Sikwenza lokho kuqala, ukuvikela izingqinamba uma i `drop_in_place` engezansi kwe panics.
///     v.set_len(1);
///     // Ngaphandle kocingo `drop_in_place`, into yokugcina ibingasoze yehliswa, futhi inkumbulo eyilawulayo ibizodalulwa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Qinisekisa ukuthi into yokugcina ilahliwe.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Qaphela ukuthi umhlanganisi wenza le khophi ngokuzenzakalela lapho ewisa izakhiwo ezigcwele, okusho ukuthi, akudingeki ukhathazeke ngezinkinga ezinjalo ngaphandle kokuthi ushayele i-`drop_in_place` ngesandla.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Ikhodi lapha ayinandaba, lokhu kuthathelwa indawo yi-drop real glue ngumhlanganisi.
    //

    // UKUPHEPHA: bona ukuphawula ngenhla
    unsafe { drop_in_place(to_drop) }
}

/// Idala isikhombisi esiluhlaza esingasebenzi.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Idala isikhombisi esiluhlaza esingaguquki.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// I-Manual impl iyadingeka ukugwema ukuboshwa kwe-`T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// I-Manual impl iyadingeka ukugwema ukuboshwa kwe-`T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Yakha ucezu oluhlaza kusuka kusikhombi nobude.
///
/// Impikiswano ye-`len` iyinombolo yezinto **, hhayi inombolo yamabhayithi.
///
/// Lo msebenzi uphephile, kepha empeleni ukusebenzisa inani lokubuyisa akuphephile.
/// Bona imibhalo ye [`slice::from_raw_parts`] ngezidingo zokuphepha kocezu.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // dala isikhombisi sesilayidi lapho uqala ngesikhombi sento yokuqala
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye-`Repr` kuphephile ngoba * const [T]
        //
        // neFatPtr inezakhiwo ezifanayo zememori.std kuphela engenza lesi siqinisekiso.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Yenza ukusebenza okufana ne-[`slice_from_raw_parts`], ngaphandle kokuthi kubuyiselwa ucezu olungaguquguquki oluhlukile, ngokungafani nocezu olungaphenduki oluhlaza.
///
///
/// Bona imibhalo ye [`slice_from_raw_parts`] ukuthola eminye imininingwane.
///
/// Lo msebenzi uphephile, kepha empeleni ukusebenzisa inani lokubuyisa akuphephile.
/// Bona imibhalo ye [`slice::from_raw_parts_mut`] ngezidingo zokuphepha kocezu.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // nikeza inani enkombeni kusilayidi
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye-`Repr` kuphephile kusukela * mut [T]
        // neFatPtr inezakhiwo ezifanayo zememori
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ishintsha amanani asezindaweni ezimbili eziguquguqukayo zohlobo olufanayo, ngaphandle kokukhipha futhi.
///
/// Kepha kokuhlukile okubili okulandelayo, lo msebenzi ulingana ngokwe-[`mem::swap`]:
///
///
/// * Isebenza kuzikhombi eziluhlaza esikhundleni sezinkomba.
/// Lapho izinkomba zitholakala, kufanele kukhethwe i [`mem::swap`].
///
/// * Amanani amabili akhonjwe kumanani angagqagqana.
/// Uma amanani egqagqana, kuzosetshenziswa indawo egqagqene yememori esuka ku `x`.
/// Lokhu kukhonjiswa esibonelweni sesibili esingezansi.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * Kokubili i-`x` ne-`y` kumele kube yi-[valid] kokufunda nokubhala.
///
/// * Kokubili i-`x` ne-`y` kumele kuqondaniswe kahle.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, izikhombisi kumele zingabi ze-NULL futhi ziqondaniswe kahle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ishintsha izifunda ezimbili ezingagqagqani:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // lena yi `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // lena yi `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Ukushintshanisa izifunda ezimbili ezigqagqene:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // lena yi `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // lena yi `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Ama-indices `1..3` wesilayidi agqagqana phakathi kwe `x` ne `y`.
///     // Imiphumela ezwakalayo kuzoba yi-`[2, 3]`, ukuze izinkomba `0..3` zibe yi-`[1, 2, 3]` (ezifanayo `y` ngaphambi kwe `swap`);noma babe yi-`[0, 1]` ukuze ama-indices `1..4` abe yi-`[0, 1, 2]` (afanayo ne-`x` ngaphambi kwe-`swap`).
/////
///     // Lokhu kuqaliswa kuchazwa ukwenza ukukhetha kokugcina.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Sinikeze isikhala sokuqala esizosebenza naso.
    // Akudingeki sikhathazeke ngamaconsi: I `MaybeUninit` ayenzi lutho lapho yehliswa.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Yenza okushintshanayo UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`x` ne-`y` zivumelekile ekubhaleni nasekuqondisweni kahle.
    // `tmp` ayikwazi ukweqa noma i-`x` noma i-`y` ngoba i-`tmp` yamane yabiwa esitaki njengento eyabiwe ehlukile.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` futhi i-`y` ingahlangana
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ishintsha ama-byte `count * size_of::<T>()` phakathi kwezifunda ezimbili zememori eziqala ku-`x` naku-`y`.
/// Lezi zifunda zombili akumele zidlule.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * Kokubili i-`x` ne-`y` kumele kube yi-[valid] yakho kokubili okufundwayo futhi kubhale ngo-count *
///   usayizi_of: :<T>() `amabhayithi.
///
/// * Kokubili i-`x` ne-`y` kumele kuqondaniswe kahle.
///
/// * Isifunda sememori esiqala ku-`x` ngosayizi we `count *
///   usayizi_of: :<T>() `bytes akumele * igqagqene nesifunda sememori esiqala ku-`y` ngosayizi ofanayo.
///
/// Qaphela ukuthi noma ngabe usayizi okopishwe ngempumelelo (`count * size_of: :<T>()`) ngu-`0`, izikhombisi kumele zingabi ze-NULL futhi ziqondaniswe kahle.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`x` ne-`y`
    // isebenza ngokubhala nokuqondaniswe kahle.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Ngezinhlobo ezincane kunokusebenziseka okuhle kwebhulokhi ngezansi, mane ushintshe ngqo ukugwema ukucabanga nge-codegen.
    //
    if mem::size_of::<T>() < 32 {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`x` ne-`y` zivumelekile
        // Ukubhala, kuqondaniswe kahle, nokungagqagqene.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Indlela lapha ukusebenzisa i-simd ukushintsha i-x&y kahle.
    // Ukuhlolwa kuveza ukuthi ukushintshanisa ama-byte angama-32 noma ama-byte angama-64 ngasikhathi sinye kusebenza kahle kakhulu kuma-processor we-Intel Haswell E.
    // I-LLVM ikwazi ukwengeza kangcono uma sinikeza i-#[repr(simd)] yokwakha, noma ngabe singasebenzisi lolu hlelo ngqo.
    //
    //
    // I-FIXME repr(simd) iphukile ku-emscripten naku-redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop through x&y, ukopisha kubo i-`Block` ngasikhathi I-optimizer kufanele ivule iluphu ngokuphelele ezinhlotsheni eziningi ze-NB
    // Asikwazi ukusebenzisa iluphu njengoba i `range` impl ibiza i `mem::swap` iphindayo
    //
    let mut i = 0;
    while i + block_size <= len {
        // Dala imemori engaqaliwe njengesikhala sokuqala Ukumemezela i-`t` lapha kugwema ukuqondanisa isitaki lapho le loop ingasetshenziswanga
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // UKUPHEPHA: Njengo-`i < len`, futhi njengoba ofonayo kufanele aqinisekise ukuthi i-`x` ne-`y` zivumelekile
        // kuma-byte e-`len`, i-`x + i` ne-`y + i` kumele kube amakheli avumelekile, afeza inkontileka yezokuphepha ye-`add`.
        //
        // Futhi, ofonayo kufanele aqinisekise ukuthi i-`x` ne-`y` zivumelekile ekubhaleni, kuqondaniswe kahle, futhi kungagqagqene, okufeza inkontileka yezokuphepha ye `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Shintsha ibhulokhi lama-byte we-x&y, usebenzisa i-t njengesikhashana sesikhashana Lokhu kufanele kuthuthukiswe ekusebenzeni kahle kwe-SIMD lapho kutholakala khona
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Shintsha noma yimaphi amabhayithi asele
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // UKUPHEPHA: bheka ukuphepha kwangaphambilini.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Ihambisa i-`src` ku-`dst` ekhonjiwe, ibuyisa inani langaphambilini le-`dst`.
///
/// Alikho inani elilahliwe.
///
/// Lo msebenzi ulingana ngokomqondo no-[`mem::replace`] ngaphandle kokuthi usebenza kwizikhombi eziluhlaza esikhundleni sezinkomba.
/// Lapho izinkomba zitholakala, kufanele kukhethwe i [`mem::replace`].
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `dst` kufanele kube yi-[valid] yakho kokubili okufundwayo nokubhalayo.
///
/// * `dst` kumele iqondaniswe kahle.
///
/// * `dst` kumele ikhombe kunani eliqalwe kahle lohlobo `T`.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` kuzoba nomphumela ofanayo ngaphandle kokudinga ibhlokhi engaphephile.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`dst` isebenza ngokusemthethweni
    // phonsa kusethenjwa esiguquguqukayo (esivumelekile ekubhaleni, kuqondaniswe, kuqalisiwe), futhi asikwazi ukweqa i-`src` ngoba i-`dst` kumele ikhombe entweni eyabiwe ehlukile.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ayikwazi ukugqagqana
    }
    src
}

/// Ifunda inani kusuka ku-`src` ngaphandle kokuyihambisa.Lokhu kushiya imemori ku-`src` kungashintshiwe.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `src` kufanele kube yi-[valid] yokufunda.
///
/// * `src` kumele iqondaniswe kahle.Sebenzisa i-[`read_unaligned`] uma kungenjalo.
///
/// * `src` kumele ikhombe kunani eliqalwe kahle lohlobo `T`.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Sebenzisa mathupha i [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Dala ikhophi elincanyana levelu ku-`a` ku-`tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukuphuma kuleli phuzu (kungaba ngokubuyisa ngokusobala noma ngokushayela umsebenzi okuyi-panics) okungadala ukuthi inani ku-`tmp` lehle ngenkathi inani elifanayo lisabhekiswa yi-`a`.
///         // Lokhu kungadala isimilo esingachazwanga uma i-`T` kungeyona i-`Copy`.
/////
/////
///
///         // Dala ikhophi elincanyana levelu ku-`b` ku-`a`.
///         // Lokhu kuphephile ngoba izinkomba eziguqukayo azikwazi ukubizwa ngegama.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Njengoba ngenhla, ukuphuma lapha kungadala isimilo esingachazwanga ngoba inani elifanayo likhonjwa yi-`a` ne-`b`.
/////
///
///         // Hambisa i-`tmp` ibe yi-`b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ihanjisiwe (i `write` ithatha ubunikazi bempikiswano yayo yesibili), ngakho-ke akukho lutho oluphonswa lapha.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ubunikazi bevelu ebuyisiwe
///
/// `read` kwakha ikhophi elincanyana le-`T`, noma ngabe i-`T` iyi-[`Copy`].
/// Uma i-`T` kungeyona i-[`Copy`], ukusebenzisa kokubili inani elibuyisiwe nenani eliku-`*src` kungaphula ukuphepha kwememori.
/// Qaphela ukuthi ukwabela ukubalwa kwe-`*src` njengokusebenzisa ngoba kuzozama ukwehlisa inani ku-`* src`.
///
/// [`write()`] ingasetshenziselwa ukubhala ngaphezulu idatha ngaphandle kokubangela ukuthi ilahlwe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` manje ikhomba kwimemori efanayo eyisisekelo njenge-`s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Ukunikezwa ku-`s2` kubangela ukuthi inani laso loqobo lehle.
///     // Ngale kwaleli phuzu, i `s` akumele isasetshenziswa, njengoba imemori eyisisekelo ikhululiwe.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Ukunikezwa ku-`s` kungadala ukuthi inani elidala lehle futhi, okuholele ekuziphatheni okungachazwanga.
/////
///     // s= String::from("bar");//IPHUTHA
///
///     // `ptr::write` ingasetshenziselwa ukubhala ngaphezulu inani ngaphandle kokulahla.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`src` isebenza ngokufundwayo.
    // `src` ayikwazi ukweqa i `tmp` ngoba i-`tmp` yamane yabelwa isitaki njengento eyabiwe ehlukile.
    //
    //
    // Futhi, njengoba sisanda kubhala inani elivumelekile ku-`tmp`, kuqinisekisiwe ukuthi kuqaliswe kahle.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Ifunda inani kusuka ku-`src` ngaphandle kokuyihambisa.Lokhu kushiya imemori ku-`src` kungashintshiwe.
///
/// Ngokungafani ne-[`read`], i-`read_unaligned` isebenza ngezikhombi ezingahambelananga.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `src` kufanele kube yi-[valid] yokufunda.
///
/// * `src` kumele ikhombe kunani eliqalwe kahle lohlobo `T`.
///
/// Njengo-[`read`], i-`read_unaligned` idala ikhophi elincanyana le-`T`, noma ngabe i-`T` iyi-[`Copy`].
/// Uma i-`T` kungeyona i-[`Copy`], kusetshenziswa kokubili inani elibuyisiwe nenani eliku-`*src` kungaba yi-[violate memory safety][read-ownership].
///
/// Qaphela ukuthi noma i `T` inosayizi `0`, isikhombisi kufanele singabi yi-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Ku-`packed` kuyakhanya
///
/// Okwamanje akunakwenzeka ukudala izikhombisi ezingavuthiwe ezinkambini ezingakahlelwanga zesakhiwo esigcwele.
///
/// Ukuzama ukudala isikhombi esiluhlaza kunkambu ye-`unaligned` enesisho esifana ne-`&packed.unaligned as *const FieldType` kwakha ireferensi engaphakathi engafakwanga ngaphambi kokuguqula lokho kube yisikhombi esiluhlaza.
///
/// Ukuthi lesi sithenjwa esesikhashana futhi sisheshe senziwe asibalulekile ngoba umhlanganisi uhlala elindele ukuthi izinkomba ziqondaniswe kahle.
/// Njengomphumela, ukusebenzisa i-`&packed.unaligned as *const FieldType` kubangela isimilo* esingaqondakali * ngokushesha kuhlelo lwakho.
///
/// Isibonelo sokuthi yini okungafanele uyenze nokuthi lokhu kuhlobana kanjani ne `read_unaligned` yile:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Lapha sizama ukuthatha ikheli lenombolo engu-32-bit engahambelani.
///     let unaligned =
///         // Isethenjwa esingahleliwe sesikhashana senziwa lapha esiholela ekuziphatheni okungachazeki noma ngabe ireferensi iyasetshenziswa noma cha.
/////
///         &packed.unaligned
///         // Ukuphonswa kusikhombi esiluhlaza akusizi;iphutha selivele lenzekile.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Ukuthola izinkambu ezingakahleliwe ngqo nesb. `packed.unaligned` kuphephile noma kunjalo.
///
///
///
///
///
///
// FIXME: Buyekeza amadokhumenti ngokususelwa kumphumela we-RFC #2582 nabangane.
/// # Examples
///
/// Funda inani le-usize kusuka kubhafa ye-byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`src` isebenza ngokufundwayo.
    // `src` ayikwazi ukweqa i `tmp` ngoba i-`tmp` yamane yabelwa isitaki njengento eyabiwe ehlukile.
    //
    //
    // Futhi, njengoba sisanda kubhala inani elivumelekile ku-`tmp`, kuqinisekisiwe ukuthi kuqaliswe kahle.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Ibhala indawo yememori ngenani elinikeziwe ngaphandle kokufunda noma ukulahla inani elidala.
///
/// `write` ayikushiyi okuqukethwe yi-`dst`.
/// Lokhu kuphephile, kepha kungavuza ukwabiwa noma izinsizakusebenza, ngakho-ke kufanele kuqikelelwe ukuthi kungabhalwa ngaphezulu into okufanele yehliswe.
///
///
/// Ngokwengeziwe, ayilahli i-`src`.Ngokomfanekiso, i-`src` idluliselwa endaweni ekhonjwe yi-`dst`.
///
/// Lokhu kufanelekile ukuqala imemori engaqaliwe, noma ukubhala imemori ebikade iyi [`read`] kusuka kuyo.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `dst` kufanele kube yi-[valid] yokubhala.
///
/// * `dst` kumele iqondaniswe kahle.Sebenzisa i-[`write_unaligned`] uma kungenjalo.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Sebenzisa mathupha i [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Dala ikhophi elincanyana levelu ku-`a` ku-`tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukuphuma kuleli phuzu (kungaba ngokubuyisa ngokusobala noma ngokushayela umsebenzi okuyi-panics) okungadala ukuthi inani ku-`tmp` lehle ngenkathi inani elifanayo lisabhekiswa yi-`a`.
///         // Lokhu kungadala isimilo esingachazwanga uma i-`T` kungeyona i-`Copy`.
/////
/////
///
///         // Dala ikhophi elincanyana levelu ku-`b` ku-`a`.
///         // Lokhu kuphephile ngoba izinkomba eziguqukayo azikwazi ukubizwa ngegama.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Njengoba ngenhla, ukuphuma lapha kungadala isimilo esingachazwanga ngoba inani elifanayo likhonjwa yi-`a` ne-`b`.
/////
///
///         // Hambisa i-`tmp` ibe yi-`b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ihanjisiwe (i `write` ithatha ubunikazi bempikiswano yayo yesibili), ngakho-ke akukho lutho oluphonswa lapha.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Sibiza ama-intrinsics ngqo ukugwema izingcingo zomsebenzi kukhodi ekhiqiziwe njengoba i `intrinsics::copy_nonoverlapping` ingumsebenzi wokugoqa.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`dst` ivumelekile ekubhaleni.
    // `dst` ayikwazi ukweqa i `src` ngoba umuntu oshayayo unokufinyelela okungaguquguquki kwe-`dst` ngenkathi i-`src` kungumnikazi walo msebenzi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Ibhala indawo yememori ngenani elinikeziwe ngaphandle kokufunda noma ukulahla inani elidala.
///
/// Ngokungafani ne-[`write()`], i-pointer ingahle ingalingani.
///
/// `write_unaligned` ayikushiyi okuqukethwe yi-`dst`.Lokhu kuphephile, kepha kungavuza ukwabiwa noma izinsizakusebenza, ngakho-ke kufanele kuqikelelwe ukuthi kungabhalwa ngaphezulu into okufanele yehliswe.
///
/// Ngokwengeziwe, ayilahli i-`src`.Ngokomfanekiso, i-`src` idluliselwa endaweni ekhonjwe yi-`dst`.
///
/// Lokhu kufanelekile ukuqala imemori engaqaliwe, noma ukubhala imemori ebikade ifundwe ne [`read_unaligned`].
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `dst` kufanele kube yi-[valid] yokubhala.
///
/// Qaphela ukuthi noma i `T` inosayizi `0`, isikhombisi kufanele singabi yi-NULL.
///
/// [valid]: self#safety
///
/// ## Ku-`packed` kuyakhanya
///
/// Okwamanje akunakwenzeka ukudala izikhombisi ezingavuthiwe ezinkambini ezingakahlelwanga zesakhiwo esigcwele.
///
/// Ukuzama ukudala isikhombi esiluhlaza kunkambu ye-`unaligned` enesisho esifana ne-`&packed.unaligned as *const FieldType` kwakha ireferensi engaphakathi engafakwanga ngaphambi kokuguqula lokho kube yisikhombi esiluhlaza.
///
/// Ukuthi lesi sithenjwa esesikhashana futhi sisheshe senziwe asibalulekile ngoba umhlanganisi uhlala elindele ukuthi izinkomba ziqondaniswe kahle.
/// Njengomphumela, ukusebenzisa i-`&packed.unaligned as *const FieldType` kubangela isimilo* esingaqondakali * ngokushesha kuhlelo lwakho.
///
/// Isibonelo sokuthi yini okungafanele uyenze nokuthi lokhu kuhlobana kanjani ne `write_unaligned` yile:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Lapha sizama ukuthatha ikheli lenombolo engu-32-bit engahambelani.
///     let unaligned =
///         // Isethenjwa esingahleliwe sesikhashana senziwa lapha esiholela ekuziphatheni okungachazeki noma ngabe ireferensi iyasetshenziswa noma cha.
/////
///         &mut packed.unaligned
///         // Ukuphonswa kusikhombi esiluhlaza akusizi;iphutha selivele lenzekile.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Ukuthola izinkambu ezingakahleliwe ngqo nesb. `packed.unaligned` kuphephile noma kunjalo.
///
///
///
///
///
///
///
///
///
// FIXME: Buyekeza amadokhumenti ngokususelwa kumphumela we-RFC #2582 nabangane.
/// # Examples
///
/// Bhala inani le-usize kubhafa ye-byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`dst` ivumelekile ekubhaleni.
    // `dst` ayikwazi ukweqa i `src` ngoba umuntu oshayayo unokufinyelela okungaguquguquki kwe-`dst` ngenkathi i-`src` kungumnikazi walo msebenzi.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Sibiza okungaphakathi ngqo ukugwema izingcingo zomsebenzi kukhodi ekhiqiziwe.
        intrinsics::forget(src);
    }
}

/// Yenza ukufundwa okuguquguqukayo kwenani kusuka ku-`src` ngaphandle kokuyihambisa.Lokhu kushiya imemori ku-`src` kungashintshiwe.
///
/// Ukusebenza okuguquguqukayo kuhloswe ngakho ukwenza kwimemori ye-I/O, futhi kuqinisekisiwe ukuthi ngeke kuphakanyiswe noma kuhlelwe kabusha ngumhlanganisi kweminye imisebenzi eguquguqukayo.
///
/// # Notes
///
/// I-Rust okwamanje ayinayo imodeli yenkumbulo eqinile futhi echazwe ngokusemthethweni, ngakho-ke ama-semantics aqondile alokho okushiwo i-"volatile" lapha angashintsha ngokuhamba kwesikhathi.
/// Uma kushiwo lokho, ama-semantics cishe azogcina efana nse ne [C11's definition of volatile][c11].
///
/// Umhlanganisi akufanele aguqule i-oda elihlobene noma inombolo yokusebenza kwenkumbulo okuguquguqukayo.
/// Kodwa-ke, ukusebenza kwememori okuguquguqukayo ezinhlotsheni ezingusayizi we-zero (isb., Uma uhlobo olungusayizi we-zero lidluliselwe ku-`read_volatile`) ama-noops futhi angahle anganakwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `src` kufanele kube yi-[valid] yokufunda.
///
/// * `src` kumele iqondaniswe kahle.
///
/// * `src` kumele ikhombe kunani eliqalwe kahle lohlobo `T`.
///
/// Njengo-[`read`], i-`read_volatile` idala ikhophi elincanyana le-`T`, noma ngabe i-`T` iyi-[`Copy`].
/// Uma i-`T` kungeyona i-[`Copy`], kusetshenziswa kokubili inani elibuyisiwe nenani eliku-`*src` kungaba yi-[violate memory safety][read-ownership].
/// Kodwa-ke, ukugcina izinhlobo ezingezizo ze-[`Copy`] kwimemori eshintshashintshayo cishe akulungile.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Njengakwi-C, ukuthi ukusebenza kuguquguquka akunamthelela nakancane emibuzweni ehilela ukufinyelela ngasikhathi sinye emicwini eminingi.Ukufinyelela okuguquguqukayo kuziphatha ngokufana nokufinyelela okungeyona kwe-athomu kuleyo ndaba.
///
/// Ikakhulu, umjaho ophakathi kwe `read_volatile` nanoma yikuphi ukusebenza kokubhala endaweni efanayo kungukuziphatha okungachazwanga.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ukungatatazeli ukugcina umthelela we-codegen uncane.
        abort();
    }
    // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Yenza ukubhala okungahambi kahle kwendawo yememori ngenani elinikeziwe ngaphandle kokufunda noma ukulahla inani elidala.
///
/// Ukusebenza okuguquguqukayo kuhloswe ngakho ukwenza kwimemori ye-I/O, futhi kuqinisekisiwe ukuthi ngeke kuphakanyiswe noma kuhlelwe kabusha ngumhlanganisi kweminye imisebenzi eguquguqukayo.
///
/// `write_volatile` ayikushiyi okuqukethwe yi-`dst`.Lokhu kuphephile, kepha kungavuza ukwabiwa noma izinsizakusebenza, ngakho-ke kufanele kuqikelelwe ukuthi kungabhalwa ngaphezulu into okufanele yehliswe.
///
/// Ngokwengeziwe, ayilahli i-`src`.Ngokomfanekiso, i-`src` idluliselwa endaweni ekhonjwe yi-`dst`.
///
/// # Notes
///
/// I-Rust okwamanje ayinayo imodeli yenkumbulo eqinile futhi echazwe ngokusemthethweni, ngakho-ke ama-semantics aqondile alokho okushiwo i-"volatile" lapha angashintsha ngokuhamba kwesikhathi.
/// Uma kushiwo lokho, ama-semantics cishe azogcina efana nse ne [C11's definition of volatile][c11].
///
/// Umhlanganisi akufanele aguqule i-oda elihlobene noma inombolo yokusebenza kwenkumbulo okuguquguqukayo.
/// Kodwa-ke, ukusebenza kwememori okuguquguqukayo ezinhlotsheni ezingusayizi we-zero (isb., Uma uhlobo olungusayizi we-zero lidluliselwe ku-`write_volatile`) ama-noops futhi angahle anganakwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `dst` kufanele kube yi-[valid] yokubhala.
///
/// * `dst` kumele iqondaniswe kahle.
///
/// Qaphela ukuthi noma ngabe i-`T` inosayizi `0`, isikhombisi kufanele singabi se-NULL futhi siqondaniswe kahle.
///
/// [valid]: self#safety
///
/// Njengakwi-C, ukuthi ukusebenza kuguquguquka akunamthelela nakancane emibuzweni ehilela ukufinyelela ngasikhathi sinye emicwini eminingi.Ukufinyelela okuguquguqukayo kuziphatha ngokufana nokufinyelela okungeyona kwe-athomu kuleyo ndaba.
///
/// Ikakhulu, umjaho ophakathi kwe `write_volatile` nokunye ukusebenza (ukufunda noma ukubhala) endaweni efanayo kungukuziphatha okungachazwanga.
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ukungatatazeli ukugcina umthelela we-codegen uncane.
        abort();
    }
    // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Qondanisa isikhombi `p`.
///
/// Bala i-offset (ngokwezinto ze-`stride` stride) okufanele isetshenziswe ku-pointer `p` ukuze i-pointer `p` ihambisane ne-`a`.
///
/// Note: Lokhu kuqaliswa kuhlelwe ngokucophelela hhayi i-panic.Yi-UB yalokhu kuya ku-panic.
/// Okuwukuphela koshintsho lwangempela olungenziwa lapha ushintsho lwe-`INV_TABLE_MOD_16` nezakhi ezihambisanayo.
///
/// Uma kwenzeka sithathe isinqumo sokwenza ukuthi sikwazi ukubiza okungaphakathi nge-`a` okungesikho amandla okubili, kungahle kube ukuhlakanipha okukhulu ukushintshela ekusebenzeni okungenamqondo kunokuba sizame ukuvumelanisa nalokhu ukuze kwamukele lolo shintsho.
///
///
/// Noma yimiphi imibuzo iya ku@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Ukusetshenziswa okuqondile kwalezi zingaphakathi kuthuthukisa kakhulu i-codegen ezingeni lokukhetha <=
    // 1, lapho izinhlobo zezindlela zalokhu kusebenza zingadalulwanga.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Bala okuphindaphindekayo kwe-modular inverse ye-`x` modulo `m`.
    ///
    /// Lokhu kuqaliswa kwenzelwe i-`align_offset` futhi kunezimo ezilandelayo:
    ///
    /// * `m` amandla-amabili;
    /// * `x < m`; (uma i-`x ≥ m`, dlula ku-`x % m` esikhundleni)
    ///
    /// Ukuqaliswa kwalo msebenzi ngeke kube yi-panic.Njalo.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// I-modulo ephindaphindekayo yemodyuli ephambene 2⁴=16.
        ///
        /// Qaphela, ukuthi leli thebula aliqukethe amanani lapho okuphambene kungekho khona (isb., `0⁻¹ mod 16`, `2⁻¹ mod 16`, njll.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo eyenzelwe i `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // UKUPHEPHA: I-`m` iyadingeka ukuba ibe ngamandla amabili, ngakho-ke engeyona zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Silinganisela i-"up" sisebenzisa ifomula elandelayo:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // kuze kube 2²ⁿ ≥ m.Ngemuva kwalokho singanciphisa siye ku-`m` esiyifunayo ngokuthatha imiphumela engu-`mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Qaphela, ukuthi sisebenzisa imisebenzi yokugoqa lapha ngenhloso-ifomula yoqobo isebenzisa isib., Ukukhipha i-`mod n`.
                // Kuhle impela ukukwenza i-`mod usize::MAX` esikhundleni salokho, ngoba sithatha umphumela we-`mod n` ekugcineni noma kunjalo.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // UKUPHEPHA: I-`a` ingamandla amabili, ngakho-ke akuyona i-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` icala lingabalwa kalula ngokusebenzisa i-`-p (mod a)`, kepha ukwenza kanjalo kuvimbela ikhono le-LLVM lokukhetha imiyalo efana ne-`lea`.Esikhundleni salokho sibala
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // esabalalisa imisebenzi ezungeze ukuthwala umthwalo, kepha ithemba i `and` ngokwanele ukuze i-LLVM ikwazi ukusebenzisa ukulungiselelwa okuhlukahlukene eyazi ngakho.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Kuqondaniswe kakadeYebo!
        return 0;
    } else if stride == 0 {
        // Uma isikhombi singaqondisiwe, futhi into ilingana no-zero, khona-ke alikho inani lezinto eliyoke liqondise isikhombi.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // UKUPHEPHA: a is power-of-two therefore non-zero.stride==0 icala liphathwe ngenhla.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // UKUPHEPHA: i-gcdpow inezibopho ezingaphezulu ezinenombolo yamabhithi asetshenzisiwe.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // UKUPHEPHA: i-gcd ihlala njalo inkulu noma ilingana no-1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Le branch ixazulula le equation elandelayo yomugqa wokuhlangana:
        //
        // ` p + so = 0 mod a `
        //
        // `p` nali inani lesikhombi, i-`s`, igxathu le-`T`, i-`o` offset ku-`T`s, ne-`a`, ukuqondanisa okuceliwe.
        //
        // Nge-`g = gcd(a, s)`, futhi lesi simo esingenhla sigomela ukuthi i-`p` nayo ihlukaniswa yi-`g`, singakhomba i-`a' = a/g`, `s' = s/g`, `p' = p/g`, khona-ke lokhu kuba kulingana no:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Ithemu lokuqala ngu-"the relative alignment of `p` to `a`" (lihlukaniswe yi-`g`), igama lesibili lingu-"how does incrementing `p` by `s` bytes change the relative alignment of `p`" (liphinde lahlukaniswa ngo-`g`).
        //
        // Ukwahlukaniswa nge-`g` kuyadingeka ukwenza okuphambene kwakheke kahle uma i-`a` ne-`s` kungeyona eyokuqala.
        //
        // Ngaphezu kwalokho, umphumela okhiqizwe yilesi sixazululo akuyona i-"minimal", ngakho-ke kuyadingeka ukuthatha umphumela we-`o mod lcm(s, a)`.Singashintsha i-`lcm(s, a)` nge-`a'` nje.
        //
        //
        //
        //
        //

        // UKUPHEPHA: I-`gcdpow` inomkhawulo oboshwe ngaphezulu hhayi kunombolo yokulandela ngomkhondo ama-0-bits ku-`a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // UKUPHEPHA: `a2` akuyona zero.Ukususa i-`a` nge-`gcdpow` akukwazi ukukhipha noma yimaphi ama-bits
        // ku-`a` (lapho inenye ncamashi eyodwa).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // UKUPHEPHA: I-`gcdpow` inomkhawulo oboshwe ngaphezulu hhayi kunombolo yokulandela ngomkhondo ama-0-bits ku-`a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // UKUPHEPHA: I-`gcdpow` inesibopho esiphezulu esingeqile kunenombolo yokulandela ngemuva okungu-0-bits
        // `a`.
        // Ngaphezu kwalokho, ukukhipha akukwazi ukugcwala, ngoba i-`a2 = a >> gcdpow` izohlala ikhulu ngokuqinile kune-`(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // UKUPHEPHA: I-`a2` ingamandla amabili, njengoba kufakazelwe ngenhla.I-`s2` incane kune-`a2`
        // ngoba i-`(s % a) >> gcdpow` incane kune-`a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ayikwazi ukuqondaniswa nhlobo.
    usize::MAX
}

/// Qhathanisa izikhombisi eziluhlaza zokulingana.
///
/// Lokhu kuyefana nokusebenzisa i-`==` opharetha, kepha akujwayelekile:
/// izimpikiswano kufanele zibe izikhombisi eziluhlaza ze-`*const T`, hhayi noma yini esebenzisa i-`PartialEq`.
///
/// Lokhu kungasetshenziselwa ukuqhathanisa izinkomba ze-`&T` (eziphoqelela ngokuphelele ku-`*const T`) ngekheli labo kunokuqhathanisa amanani abakhomba kuwo (okuyilokho okwenziwa yi-`PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Izingcezu nazo ziqhathaniswa nobude bazo (izikhombisi zamafutha):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// I-Traits nayo iqhathaniswa nokusebenza kwayo:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Izikhombi zinamakheli alinganayo.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Izinto zinamakheli alinganayo, kepha i-`Trait` inokusetshenziswa okwehlukile.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Ukuguqula ireferensi ibe yi-`*const u8` kuqhathaniswa nekheli.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash a pointer eluhlaza.
///
/// Lokhu kungasetshenziselwa ukwenza i-hash ireferensi ye-`&T` (ephoqelela ku-`*const T` ngokuphelele) ngekheli layo kunenani elikhomba kulo (okuyilokho okwenziwa yi-`Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls yezikhombi zomsebenzi
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ukusakazwa okumaphakathi njengosayizi kuyadingeka ku-AVR
                // ukuze isikhala sekheli lesikhombi somthombo sigcinwe kusikhombi sokugcina somsebenzi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Ukusakazwa okumaphakathi njengosayizi kuyadingeka ku-AVR
                // ukuze isikhala sekheli lesikhombi somthombo sigcinwe kusikhombi sokugcina somsebenzi.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ayikho imisebenzi ehlukahlukene enamapharamitha ayi-0
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Dala i-pointer eluhlaza ye-`const` endaweni, ngaphandle kokudala inkomba ephakathi.
///
/// Ukwakha ireferensi nge-`&`/`&mut` kuvunyelwe kuphela uma isikhombi siqondaniswe kahle futhi sikhomba idatha eqalisiwe.
/// Ezimweni lapho lezo zidingo zingabambi khona, izikhombisi ezingavuthiwe kufanele zisetshenziswe esikhundleni salokho.
/// Kodwa-ke, i `&expr as *const _` idala ireferensi ngaphambi kokuyiphonsa kusikhombi esiluhlaza, futhi leso sithenjwa singaphansi kwemithetho efanayo nazo zonke ezinye izinkomba.
///
/// Le macro ingadala i-pointer eluhlaza *ngaphandle* kokudala inkomba kuqala.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` kuzokwakha ireferensi engafakwanga uphawu, futhi ngaleyo ndlela kube yi-Undefined Behaviour!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Dala i-pointer eluhlaza ye-`mut` endaweni, ngaphandle kokudala inkomba ephakathi.
///
/// Ukwakha ireferensi nge-`&`/`&mut` kuvunyelwe kuphela uma isikhombi siqondaniswe kahle futhi sikhomba idatha eqalisiwe.
/// Ezimweni lapho lezo zidingo zingabambi khona, izikhombisi ezingavuthiwe kufanele zisetshenziswe esikhundleni salokho.
/// Kodwa-ke, i `&mut expr as *mut _` idala ireferensi ngaphambi kokuyiphonsa kusikhombi esiluhlaza, futhi leso sithenjwa singaphansi kwemithetho efanayo nazo zonke ezinye izinkomba.
///
/// Le macro ingadala i-pointer eluhlaza *ngaphandle* kokudala inkomba kuqala.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` kuzokwakha ireferensi engafakwanga uphawu, futhi ngaleyo ndlela kube yi-Undefined Behaviour!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` iphoqa ukukopisha inkambu esikhundleni sokwakha ireferensi.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}