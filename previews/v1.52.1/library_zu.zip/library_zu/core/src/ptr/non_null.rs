use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` kepha okungeyona i-zero ne-covariant.
///
/// Le nto ngokuvamile iyinto efanelekile ongayisebenzisa lapho wakha izakhiwo zedatha usebenzisa izikhombisi ezingavuthiwe, kepha ekugcineni kuyingozi kakhulu ukuyisebenzisa ngenxa yezakhiwo zayo ezingeziwe.Uma ungaqiniseki ukuthi kufanele usebenzise i `NonNull<T>`, vele usebenzise i `*mut T`!
///
/// Ngokungafani ne-`*mut T`, i-pointer kufanele ihlale ingasebenzi, noma ngabe i-pointer ayikaze iphinde ichazwe.Lokhu kwenzelwa ukuthi ama-enum asebenzise leli nani elinqatshelwe njengokubandlulula-i-`Option<NonNull<T>>` inosayizi ofanayo no-`* mut T`.
/// Kodwa-ke isikhombisi sisengakhungatheka uma singasetshenziswanga.
///
/// Ngokungafani ne-`*mut T`, i-`NonNull<T>` yakhethwa ukuba ibe yi-covariant ngaphezulu kwe-`T`.Lokhu kwenza ukuthi kube nokwenzeka ukusebenzisa i-`NonNull<T>` lapho kwakhiwa izinhlobo ze-covariant, kepha kwethula ubungozi bokungaqondakali uma kusetshenziswe ohlotsheni okungafanele ukuthi lube yi-covariant empeleni.
/// (Ukukhetha okuphambene kwenzelwe i `*mut T` noma ngobuchwepheshe ukungabi nangqondo kungadalwa kuphela ngokubiza imisebenzi engaphephile.)
///
/// I-Covariance ilungile ekukhishweni okuphephe kakhulu, njenge-`Box`, `Rc`, `Arc`, `Vec`, ne-`LinkedList`.Lokhu kunjalo ngoba banikela nge-API yomphakathi elandela imithetho evamile eyabiwe ye-XOR eguqukayo ye Rust.
///
/// Uma uhlobo lwakho lungeke luhlangane ngokuphepha, kufanele uqinisekise ukuthi luqukethe inkambu eyengeziwe yokuhlinzeka ngokungajwayelekile.Imvamisa le nkambu kuzoba uhlobo lwe-[`PhantomData`] njenge-`PhantomData<Cell<T>>` noma i-`PhantomData<&'a mut T>`.
///
/// Qaphela ukuthi i-`NonNull<T>` inesibonelo se-`From` se-`&T`.Kodwa-ke, lokhu akulishintshi iqiniso lokuthi ukuguqula (isikhombisi esisuselwe ku-) ireferensi eyabiwe kungukuziphatha okungachazwanga ngaphandle kokuthi ukuguquka kwenzeka ngaphakathi kwe [`UnsafeCell<T>`].Okufanayo kwenza ireferensi enokuguquguquka kusuka kusethenjwa esabiwe.
///
/// Lapho usebenzisa lesi sibonelo se-`From` ngaphandle kwe-`UnsafeCell<T>`, kuwumsebenzi wakho ukuqinisekisa ukuthi i-`as_mut` ayibizwa, futhi i-`as_ptr` ayisetshenziselwa ukuguqula isimo.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` izikhombisi akuzona i-`Send` ngoba idatha abayikhombayo ingahle ihlukaniswe.
// NB, lokhu kufaka akudingekile, kepha kufanele kunikeze ngemiyalezo engcono yephutha.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` izikhombisi akuzona i-`Sync` ngoba idatha abayikhombayo ingahle ihlukaniswe.
// NB, lokhu kufaka akudingekile, kepha kufanele kunikeze ngemiyalezo engcono yephutha.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Kwakha i `NonNull` entsha elengayo, kepha eqondaniswe kahle.
    ///
    /// Lokhu kuyasiza ekuqaliseni izinhlobo ezabiwe ngobuvila, njengoba kwenza i `Vec::new`.
    ///
    /// Qaphela ukuthi inani lesikhombi lingamela isikhombisi esivumelekile ku-`T`, okusho ukuthi lokhu akumele kusetshenziswe njengenani le-"not yet initialized" sentinel.
    /// Izinhlobo ezabiwa ngobuvila kufanele zilandelele ukuqaliswa ngezinye izindlela.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // UKUPHEPHA: I-mem::align_of() ibuyisa usize ongewona uziro bese usakazwa
        // ku-* mut T.
        // Ngakho-ke, i-`ptr` ayisebenzi futhi imibandela yokubiza i-new_unchecked() iyahlonishwa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Ibuyisa izinkomba ezabiwe kunani.Ngokuphikisana ne-[`as_ref`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// Kumlingani ongaguquguquka bheka i [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zereferensi.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Ibuyisa izinkomba ezihlukile kunani.Ngokuphikisana ne-[`as_mut`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// Kumlingani owabiwe bheka i [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///
    ///   Ikakhulu, ngesikhathi sale mpilo, inkumbulo isikhombisi esikhomba kuyo akufanele itholakale (ifundwe noma ibhalwe) nganoma yisiphi esinye isikhombisi.
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zereferensi.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Idala i `NonNull` entsha.
    ///
    /// # Safety
    ///
    /// `ptr` akumele kungasebenzi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`ptr` ayiyona into engekho.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Idala i-`NonNull` entsha uma i-`ptr` ingasebenzi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // UKUPHEPHA: Isikhombi sesivele sihloliwe futhi asisebenzi
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Yenza ukusebenza okufana ne-[`std::ptr::from_raw_parts`], ngaphandle kokuthi isikhombisi se-`NonNull` siyabuyiselwa, ngokungafani nesikhombi se-`*const` eluhlaza.
    ///
    ///
    /// Bona imibhalo ye [`std::ptr::from_raw_parts`] ukuthola eminye imininingwane.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // UKUPHEPHA: Umphumela we-`ptr::from::raw_parts_mut` awusebenzi ngoba i-`data_address` iyi-.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Bola isikhombisi (ngokunokwenzeka esibanzi) esikhangisweni nasekwakheni imethadatha.
    ///
    /// Isikhombi singabuye sakhiwe kabusha nge [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Ithola isikhombisi esingaphansi se `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Ibuyisa ireferensi eyabiwe kunani.Uma inani lingavulwa, i-[`as_uninit_ref`] kufanele isetshenziswe esikhundleni salokho.
    ///
    /// Kumlingani ongaguquguquka bheka i [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Isikhombi kufanele sikhombe esimweni sokuqala se-`T`.
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    /// (Ingxenye mayelana nokuqaliswa ayikanqunywa ngokuphelele, kepha kuze kube yilapho, ukuphela kwendlela ephephile ukuqinisekisa ukuthi ziyaqalwa ngempela.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zereferensi.
        unsafe { &*self.as_ptr() }
    }

    /// Ibuyisa ireferensi eyingqayizivele kunani.Uma inani lingavulwa, i-[`as_uninit_mut`] kufanele isetshenziswe esikhundleni salokho.
    ///
    /// Kumlingani owabiwe bheka i [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Isikhombi kufanele sikhombe esimweni sokuqala se-`T`.
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///
    ///   Ikakhulu, ngesikhathi sale mpilo, inkumbulo isikhombisi esikhomba kuyo akufanele itholakale (ifundwe noma ibhalwe) nganoma yisiphi esinye isikhombisi.
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    /// (Ingxenye mayelana nokuqaliswa ayikanqunywa ngokuphelele, kepha kuze kube yilapho, ukuphela kwendlela ephephile ukuqinisekisa ukuthi ziyaqalwa ngempela.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zesethenjwa esiguquguqukayo.
        unsafe { &mut *self.as_ptr() }
    }

    /// Isakaza kusikhombi solunye uhlobo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // UKUPHEPHA: I-`self` iyisikhombi se-`NonNull` okungeyona engeyona null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Kwakha isilayidi esiluhlaza esingasetshenziswanga esivela kusikhombi esincane nobude.
    ///
    /// Impikiswano ye-`len` iyinombolo yezinto **, hhayi inombolo yamabhayithi.
    ///
    /// Lo msebenzi uphephile, kepha ukureferencere inani lokubuyisa akuphephile.
    /// Bona imibhalo ye [`slice::from_raw_parts`] ngezidingo zokuphepha kocezu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // dala isikhombisi sesilayidi lapho uqala ngesikhombi sento yokuqala
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Qaphela ukuthi lesi sibonelo siveza ukusetshenziswa kwale ndlela, kepha `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // UKUPHEPHA: I-`data` iyisikhombi se-`NonNull` okungeyona engeyona null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Ibuyisa ubude besilayidi esiluhlaza esingasasebenzi ngalutho.
    ///
    /// Inani elibuyisiwe liyinombolo yezinto **, hhayi inombolo yamabhayithi.
    ///
    /// Lo msebenzi uphephile, noma ngabe isilayidi esiluhlaza esingasetshenziswanga asikwazi ukubhekiswa kucezu ngoba isikhombisi asinalo ikheli elivumelekile.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Ibuyisa isikhombisi esingenzi lutho kubha yesilayidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // UKUPHEPHA: Siyazi ukuthi i `self` ayiyona into engekho.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Ibuyisa isikhombi esiluhlaza kubha yesilayidi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Ibuyisa ireferensi eyabiwe kucezu lwamanani okungenzeka awaqaliwe.Ngokuphikisana ne-[`as_ref`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// Kumlingani ongaguquguquka bheka i [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele sibe yi-[valid] ukuze ifundelwe ama-`ptr.len() * mem::size_of::<T>()` amabhayithi amaningi, futhi kufanele aqondaniswe kahle.Lokhu kusho ikakhulukazi:
    ///
    ///     * Lonke uhla lwememori lwalesi siqeshana kufanele luqukathe entweni eyodwa eyabiwe!
    ///       Izingcezu azisoze zawela ezintweni eziningi ezabiwe.
    ///
    ///     * Isikhombi kufanele siqondaniswe nezingcezu zobude obungu-zero.
    ///     Isizathu esisodwa salokhu ukuthi ukulungiselelwa kokuhlelwa kwe-enum kungahle kuncike kuzinkomba (kufaka phakathi izingcezu zanoma ibuphi ubude) eziqondisiwe nezingasebenzi ukuze zihlukaniswe nenye idatha.
    ///
    ///     Ungathola i-pointer engasetshenziswa njenge-`data` yezingcezu zobude obunguziro usebenzisa i-[`NonNull::dangling()`].
    ///
    /// * Usayizi ophelele we-`ptr.len() * mem::size_of::<T>()` wocezu akumele ube mkhulu kune-`isize::MAX`.
    ///   Bona imibhalo yezokuphepha ye [`pointer::offset`].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// Bheka futhi i [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Ibuyisa ireferensi eyingqayizivele kucezu lwamanani okungenzeka angaqaliwe.Ngokuphikisana ne-[`as_mut`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// Kumlingani owabiwe bheka i [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Lapho ushayela le ndlela, kufanele uqinisekise ukuthi konke okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele sibe yi-[valid] yokufunda futhi sibhalele ama-byte ayi-`ptr.len() * mem::size_of::<T>()` amaningi, futhi kufanele siqondaniswe kahle.Lokhu kusho ikakhulukazi:
    ///
    ///     * Lonke uhla lwememori lwalesi siqeshana kufanele luqukathe entweni eyodwa eyabiwe!
    ///       Izingcezu azisoze zawela ezintweni eziningi ezabiwe.
    ///
    ///     * Isikhombi kufanele siqondaniswe nezingcezu zobude obungu-zero.
    ///     Isizathu esisodwa salokhu ukuthi ukulungiselelwa kokuhlelwa kwe-enum kungahle kuncike kuzinkomba (kufaka phakathi izingcezu zanoma ibuphi ubude) eziqondisiwe nezingasebenzi ukuze zihlukaniswe nenye idatha.
    ///
    ///     Ungathola i-pointer engasetshenziswa njenge-`data` yezingcezu zobude obunguziro usebenzisa i-[`NonNull::dangling()`].
    ///
    /// * Usayizi ophelele we-`ptr.len() * mem::size_of::<T>()` wocezu akumele ube mkhulu kune-`isize::MAX`.
    ///   Bona imibhalo yezokuphepha ye [`pointer::offset`].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///   Ikakhulu, ngesikhathi sale mpilo, inkumbulo isikhombisi esikhomba kuyo akufanele itholakale (ifundwe noma ibhalwe) nganoma yisiphi esinye isikhombisi.
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// Bheka futhi i [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Lokhu kuphephile njengoba i-`memory` isebenza ukufundwa futhi ibhalela ama-`memory.len()` amabhayithi amaningi.
    /// // Qaphela ukuthi ukubiza i-`memory.as_mut()` akuvunyelwe lapha njengoba okuqukethwe kungahle kungaqaliswa.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Ibuyisa isikhombisi esiluhlaza entweni ethile noma ekubhaliseni, ngaphandle kokuhlola imingcele.
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele noma lapho i-`self` ingenakudluliswa kungaboniswa * *[indlela engachazwanga] * noma ngabe isikhombisi esiphumelayo asisetshenzisiwe.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // UKUPHEPHA: umuntu ofonayo uqinisekisa ukuthi i-`self` ayinakuguqulwa futhi i-`index` iyimingcele.
        // Njengomphumela, isikhombisi esivelayo asikwazi ukuba yi-NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // UKUPHEPHA: Isikhombi esiyingqayizivele asikwazi ukungasebenzi, ngakho-ke izimo ze-
        // new_unchecked() ziyahlonishwa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // UKUPHEPHA: Isethenjwa esiguquguqukayo asikwazi ukungasebenzi.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // UKUPHEPHA: Isethenjwa asikwazi ukungasebenzi, ngakho-ke imibandela ye-
        // new_unchecked() ziyahlonishwa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}