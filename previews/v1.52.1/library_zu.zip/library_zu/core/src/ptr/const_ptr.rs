use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Ibuyisa i-`true` uma i-pointer ingasebenzi.
    ///
    /// Qaphela ukuthi izinhlobo ezingalinganiswanga zinezikhombisi eziningi ezingenamsebenzi, njengoba kubhekwa kuphela i-pointer yedatha eluhlaza, hhayi ubude bayo, i-vtable, njll.
    /// Ngakho-ke, izikhombisi ezimbili ezingenamsebenzi zingahle zingalingani ngokulingana.
    ///
    /// ## Ukuziphatha ngesikhathi sokuhlolwa kwe-const
    ///
    /// Lapho lo msebenzi usetshenziswa ngesikhathi sokuhlolwa kwe-const, ungabuyisa i-`false` yezinkomba ezizoba yize ngesikhathi sokusebenza.
    /// Ngokuqondile, lapho isikhombisi sememori ethile sisuselwa ngaphesheya kwemingcele yaso ngendlela yokuthi i-pointer evelayo ayisebenzi, umsebenzi usazobuyisa i-`false`.
    ///
    /// Ayikho indlela yokuthi i-CTFE yazi isikhundla esiphelele saleyo nkumbulo, ngakho-ke asikwazi ukusho ukuthi ngabe i-pointer ayisebenzi noma cha.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Qhathanisa nge-cast kwisikhombi esincane, ngakho-ke izikhombisi ezinonile zibheka kuphela ingxenye yazo ye-"data" ye-null-ness.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Isakaza kusikhombi solunye uhlobo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Bola isikhombisi (ngokunokwenzeka esibanzi) esikhangisweni nasekwakheni imethadatha.
    ///
    /// Isikhombi singabuye sakhiwe kabusha nge [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Ibuyisa i-`None` uma i-pointer ingasebenzi, noma uma ibuyisa ireferensi eyabiwe kunani elisongwe nge-`Some`.Uma inani lingavulwa, i-[`as_uninit_ref`] kufanele isetshenziswe esikhundleni salokho.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Lapho ubiza le ndlela, kufanele uqinisekise ukuthi *i* pointer iyi-NULL *noma* konke lokhu okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Isikhombi kufanele sikhombe esimweni sokuqala se-`T`.
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    /// (Ingxenye mayelana nokuqaliswa ayikanqunywa ngokuphelele, kepha kuze kube yilapho, ukuphela kwendlela ephephile ukuqinisekisa ukuthi ziyaqalwa ngempela.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Uhlobo olungamakiwe olungasebenzi
    ///
    /// Uma uqinisekile ukuthi isikhombi asisoze sasebenza futhi sifuna uhlobo oluthile lwe-`as_ref_unchecked` olubuyisa i-`&T` esikhundleni se-`Option<&T>`, yazi ukuthi ungasikhomba ngqo isikhombi.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` isebenza ngokusemthethweni
        // ukuthola ireferensi uma kungasebenzi.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Ibuyisa i-`None` uma i-pointer ingasebenzi, noma uma ibuyisa ireferensi eyabiwe kunani elisongwe nge-`Some`.
    /// Ngokuphikisana ne-[`as_ref`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Lapho ubiza le ndlela, kufanele uqinisekise ukuthi *i* pointer iyi-NULL *noma* konke lokhu okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele siqondaniswe kahle.
    ///
    /// * Kufanele kube yi-"dereferencable" ngomqondo ochazwe ku-[the module documentation].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` ihlangabezana nakho konke
        // izidingo zereferensi.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ibala isamba kusuka kusikhombi.
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Uma ngabe kukhona kwalezi zimo ezephuliwe, umphumela yi-Undefined Behaeve:
    ///
    /// * Kokubili isikhombisi sokuqala nokuholelekayo kufanele kube semikhawulweni noma nge-byte eyodwa kudlule ukuphela kwento efanayo eyabiwe.
    /// Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// * I-offset ebaliwe,**ngama-byte**, ayikwazi ukugcwala i-`isize`.
    ///
    /// * I-offset esemikhawulweni ayikwazi ukuthembela ku-"wrapping around" esikhaleni sekheli.Okusho ukuthi, isamba esingenamkhawulo sokucaciswa,**kuma-byte** kufanele silingane kusayizi.
    ///
    /// Umhlanganisi nomtapo wezincwadi ojwayelekile ngokuvamile uzama ukuqinisekisa ukuthi ukwabiwa akufinyeleli kusayizi lapho i-offset iyinkinga.
    /// Isibonelo, i-`Vec` ne-`Box` baqinisekisa ukuthi ababi ngaphezu kwama-byte ayi-`isize::MAX`, ngakho-ke i-`vec.as_ptr().add(vec.len())` ihlale iphephile.
    ///
    /// Amapulatifomu amaningi empeleni awakwazi nokwakha isabelo esinjalo.
    /// Isibonelo, alikho ipulatifomu elaziwa ngama-64-bit elingake lisebenzise isicelo sama-byte ayi-2 <sup>63</sup> ngenxa yokulinganiselwa kwetafula lekhasi noma ukuhlukanisa isikhala sekheli.
    /// Kodwa-ke, amanye amapulatifomu angama-32-bit no-16-bit angasebenza ngempumelelo isicelo sama-byte we-`isize::MAX` ngezinto ezifana ne-Physical Address Extension.
    ///
    /// Njengoba kunje, imemori etholwe ngqo kusuka kubanikezeli noma kumafayela amakwe imemori * ingahle ibe nkulu kakhulu ukuthi ingaphathwa ngalo msebenzi.
    ///
    /// Cabanga ukusebenzisa i-[`wrapping_offset`] esikhundleni uma lezi zingqinamba kunzima ukuzanelisa.
    /// Okuwukuphela kwendlela yale ndlela ukuthi inika amandla ukwenziwa okuhle kakhulu kokuhlanganiswa.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Ibala isamba kusuka kusikhombi kusetshenziswa izibalo zokugoqa.
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala uphephile, kepha ukusebenzisa isikhombisi esivelayo akunjalo.
    ///
    /// Isikhombi esivelayo sihlala sinamathiselwe entweni efanayo eyabiwe i-`self` ekhomba kuyo.
    /// Kungenzeka * ingasetshenziswanga ukufinyelela entweni eyabiwe ehlukile.Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_offset((y as isize) - (x as isize))` ayenzi * i-`z` ifane ne-`y` noma ngabe sicabanga ukuthi i-`T` inosayizi `1` futhi akukho okuchichimayo: I-`z` isanamathele entweni i-`x` enamathiselwe kuyo, futhi ukuyichaza kungukuziphatha okungachazwanga ngaphandle kokuthi i-`x` ne I-`y` ikhomba entweni efanayo eyabiwe.
    ///
    /// Uma kuqhathaniswa ne-[`offset`], le ndlela ibambezela imfuneko yokuhlala ngaphakathi kwento efanayo eyabiwe: I-[`offset`] iyindlela yokuziphatha engachazeki ngokushesha lapho weqa imingcele yento;I-`wrapping_offset` ikhiqiza isikhombisi kepha isaholela ekuziphatheni okungachazeki uma isikhombi siboniswa uma singaphandle kwemingcele yento enamathiselwe kuyo.
    /// [`offset`] ingenziwa ngcono kangcono futhi ngenxa yalokho ikhetha ikhodi ezwela ukusebenza.
    ///
    /// Isheke elibambezelekile libheka kuphela inani lesikhombi ebelingasetshenziswanga, hhayi amanani aphakathi nendawo asetshenziswe ngesikhathi kubalwa umphumela wokugcina.
    /// Isibonelo, i-`x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` ihlala ifana ne-`x`.Ngamanye amagama, ukushiya into oyabelwe bese uyifaka kabusha emuva kwesikhathi kuvunyelwe.
    ///
    /// Uma udinga ukweqa imingcele yento, phonsa isikhombi kunamba bese wenza izibalo lapho.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // Iterate usebenzisa i-pointer eluhlaza ngokunyuka kwezinto ezimbili
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Le loop iphrinta i "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // UKUPHEPHA: i-`arith_offset` intrinsic ayinakho okudingeka ukuthi kubizwe.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Ibala ibanga phakathi kwezikhombi ezimbili.Inani elibuyisiwe lingamayunithi we-T: ibanga lama-byte lihlukaniswe ngu-`mem::size_of::<T>()`.
    ///
    /// Lo msebenzi ukuphambana kwe [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Uma ngabe kukhona kwalezi zimo ezephuliwe, umphumela yi-Undefined Behaeve:
    ///
    /// * Kokubili isikhombisi sokuqala nesinye kufanele kube semikhawulweni noma nge-byte eyodwa kudlule ukuphela kwento efanayo eyabiwe.
    /// Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// * Zombili izikhombisi kufanele zithathwe * kusikhombi sento efanayo.
    ///   (Bheka isibonelo ngezansi.)
    ///
    /// * Ibanga phakathi kwezikhombi, ngama-byte, kufanele libe ukuphindaphinda ngqo kosayizi we-`T`.
    ///
    /// * Ibanga phakathi kwezikhombi,**ngama-byte**, alikwazi ukugcwala i-`isize`.
    ///
    /// * Ibanga elisemikhawulweni alikwazi ukuthembela ku-"wrapping around" esikhaleni sekheli.
    ///
    /// Izinhlobo ze-Rust azikaze zibe nkulu kunokwabiwa kwe-`isize::MAX` ne-Rust azikaze zisonge isikhala sekheli, ngakho-ke izikhombisi ezimbili ezingaphakathi kwenani elithile lanoma yiluphi uhlobo lwe-Rust `T` zizohlala ziyanelisa izimo ezimbili zokugcina.
    ///
    /// Umtapo wezincwadi ojwayelekile futhi uqinisekisa ukuthi ukwabiwa akufinyeleli kusayizi lapho i-offset iyinkinga.
    /// Isibonelo, i-`Vec` ne-`Box` baqinisekisa ukuthi ababeki ngaphezu kwama-byte ayi-`isize::MAX`, ngakho-ke i-`ptr_into_vec.offset_from(vec.as_ptr())` ihlala yanelisa imibandela emibili yokugcina.
    ///
    /// Amapulatifomu amaningi empeleni awakwazi nokwakha isabelo esikhulu kangaka.
    /// Isibonelo, alikho ipulatifomu elaziwa ngama-64-bit elingake lisebenzise isicelo sama-byte ayi-2 <sup>63</sup> ngenxa yokulinganiselwa kwetafula lekhasi noma ukuhlukanisa isikhala sekheli.
    /// Kodwa-ke, amanye amapulatifomu angama-32-bit no-16-bit angasebenza ngempumelelo isicelo sama-byte we-`isize::MAX` ngezinto ezifana ne-Physical Address Extension.
    /// Njengoba kunje, imemori etholwe ngqo kusuka kubanikezeli noma kumafayela amakwe imemori * ingahle ibe nkulu kakhulu ukuthi ingaphathwa ngalo msebenzi.
    /// (Qaphela ukuthi i-[`offset`] ne-[`add`] nazo zinomkhawulo ofanayo ngakho-ke azinakusetshenziswa kuzabelo ezinkulu kangako.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Lo msebenzi i-panics uma i-`T` iluhlobo lwe-Zero-Sized ("ZST").
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Ukusetshenziswa okungalungile *:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Yenza i-ptr2_other ibe yi-"alias" ye-ptr2, kepha etholwe ku-ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Njengoba i-ptr2_other ne-ptr2 zisuselwa kuzikhombi ziye ezintweni ezahlukahlukene, ukusebenzisa i-offset yabo kungukuziphatha okungachazwanga, noma bekhomba ekhelini elifanayo!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Ukuziphatha Okungachazwanga
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Ibuyisa ukuthi ngabe izikhombisi ezimbili ziqinisekisiwe ukuthi ziyalingana.
    ///
    /// Ngesikhathi sokusebenza lo msebenzi uziphatha njenge-`self == other`.
    /// Kodwa-ke, kwezinye izimo (isb., Ukuhlanganiswa kwesikhathi sesikhathi), akwenzeki ngaso sonke isikhathi ukunquma ukulingana kwezikhombisi ezimbili, ngakho-ke lo msebenzi ungabuyisa ngokuxakile i-`false` yezikhombisi ezizogcina ngokulingana.
    ///
    /// Kepha uma ibuyisa i-`true`, izikhombisi ziqinisekisiwe ukuthi ziyalingana.
    ///
    /// Lo msebenzi uyisibuko se-[`guaranteed_ne`], kepha hhayi ukuphambana kwawo.Kukhona ukuqhathanisa kwesikhombi lapho yomibili imisebenzi ibuyisa i-`false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Inani lokubuyisa lingashintsha ngokuya ngohlobo lomhlanganisi futhi ikhodi engaphephile ingahle ingathembeli emphumeleni walo msebenzi ukuzwakala.
    /// Kuphakanyiswa ukuthi kusetshenziswe lo msebenzi kuphela ekusebenzeni kokusebenza lapho amanani abuyisayo e-`false` ngalo msebenzi engathinti umphumela, kepha ukusebenza kuphela.
    /// Imiphumela yokusebenzisa le ndlela ukwenza isikhathi sokusebenza nokuhlanganisa ikhodi yesikhathi iziphathe ngendlela ehlukile ayikahlolwa.
    /// Le ndlela akufanele isetshenziselwe ukwethula umehluko onjalo, futhi futhi akufanele isimamiswe ngaphambi kokuthi siyiqonde kangcono le nkinga.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Ibuyisa ukuthi izikhombi ezimbili ziqinisekisiwe yini ukuthi azilingani.
    ///
    /// Ngesikhathi sokusebenza lo msebenzi uziphatha njenge-`self != other`.
    /// Kodwa-ke, kwezinye izimo (isb., Ukuhlanganiswa kwesikhathi sesikhathi), akwenzeki ngaso sonke isikhathi ukunquma ukungalingani kwezikhombisi ezimbili, ngakho-ke lo msebenzi ungabuyisa ngokuxakile i-`false` yezikhombisi ezizogcina zingalingani.
    ///
    /// Kepha uma ibuyisa i-`true`, izikhombisi ziqinisekisiwe ukuthi azilingani.
    ///
    /// Lo msebenzi uyisibuko se-[`guaranteed_eq`], kepha hhayi ukuphambana kwawo.Kukhona ukuqhathanisa kwesikhombi lapho yomibili imisebenzi ibuyisa i-`false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Inani lokubuyisa lingashintsha ngokuya ngohlobo lomhlanganisi futhi ikhodi engaphephile ingahle ingathembeli emphumeleni walo msebenzi ukuzwakala.
    /// Kuphakanyiswa ukuthi kusetshenziswe lo msebenzi kuphela ekusebenzeni kokusebenza lapho amanani abuyisayo e-`false` ngalo msebenzi engathinti umphumela, kepha ukusebenza kuphela.
    /// Imiphumela yokusebenzisa le ndlela ukwenza isikhathi sokusebenza nokuhlanganisa ikhodi yesikhathi iziphathe ngendlela ehlukile ayikahlolwa.
    /// Le ndlela akufanele isetshenziselwe ukwethula umehluko onjalo, futhi futhi akufanele isimamiswe ngaphambi kokuthi siyiqonde kangcono le nkinga.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Ibala isamba kusuka kusikhombi (i-`.offset(count as isize)`) elula.
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Uma ngabe kukhona kwalezi zimo ezephuliwe, umphumela yi-Undefined Behaeve:
    ///
    /// * Kokubili isikhombisi sokuqala nokuholelekayo kufanele kube semikhawulweni noma nge-byte eyodwa kudlule ukuphela kwento efanayo eyabiwe.
    /// Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// * I-offset ebaliwe,**ngama-byte**, ayikwazi ukugcwala i-`isize`.
    ///
    /// * I-offset esemikhawulweni ayikwazi ukuthembela ku-"wrapping around" isikhala sekheli.Lokho okungukuthi, isamba esingenamkhawulo sokunemba kufanele silingane ku-`usize`.
    ///
    /// Umhlanganisi nomtapo wezincwadi ojwayelekile ngokuvamile uzama ukuqinisekisa ukuthi ukwabiwa akufinyeleli kusayizi lapho i-offset iyinkinga.
    /// Isibonelo, i-`Vec` ne-`Box` baqinisekisa ukuthi ababi ngaphezu kwama-byte ayi-`isize::MAX`, ngakho-ke i-`vec.as_ptr().add(vec.len())` ihlale iphephile.
    ///
    /// Amapulatifomu amaningi empeleni awakwazi nokwakha isabelo esinjalo.
    /// Isibonelo, alikho ipulatifomu elaziwa ngama-64-bit elingake lisebenzise isicelo sama-byte ayi-2 <sup>63</sup> ngenxa yokulinganiselwa kwetafula lekhasi noma ukuhlukanisa isikhala sekheli.
    /// Kodwa-ke, amanye amapulatifomu angama-32-bit no-16-bit angasebenza ngempumelelo isicelo sama-byte we-`isize::MAX` ngezinto ezifana ne-Physical Address Extension.
    ///
    /// Njengoba kunje, imemori etholwe ngqo kusuka kubanikezeli noma kumafayela amakwe imemori * ingahle ibe nkulu kakhulu ukuthi ingaphathwa ngalo msebenzi.
    ///
    /// Cabanga ukusebenzisa i-[`wrapping_add`] esikhundleni uma lezi zingqinamba kunzima ukuzanelisa.
    /// Okuwukuphela kwendlela yale ndlela ukuthi inika amandla ukwenziwa okuhle kakhulu kokuhlanganiswa.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ibala isamba kusuka kusikhombi (ukusebenziseka kwe-`.offset ((bala njenge-isize).wrapping_neg())`).
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Uma ngabe kukhona kwalezi zimo ezephuliwe, umphumela yi-Undefined Behaeve:
    ///
    /// * Kokubili isikhombisi sokuqala nokuholelekayo kufanele kube semikhawulweni noma nge-byte eyodwa kudlule ukuphela kwento efanayo eyabiwe.
    /// Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// * I-offset ebaliwe ayikwazi ukwedlula i-`isize::MAX`**byte**.
    ///
    /// * I-offset esemikhawulweni ayikwazi ukuthembela ku-"wrapping around" esikhaleni sekheli.Okusho ukuthi, isamba esingenamkhawulo sokucaca kufanele silingane nosayizi.
    ///
    /// Umhlanganisi nomtapo wezincwadi ojwayelekile ngokuvamile uzama ukuqinisekisa ukuthi ukwabiwa akufinyeleli kusayizi lapho i-offset iyinkinga.
    /// Isibonelo, i-`Vec` ne-`Box` baqinisekisa ukuthi ababi ngaphezu kwama-byte ayi-`isize::MAX`, ngakho-ke i-`vec.as_ptr().add(vec.len()).sub(vec.len())` ihlale iphephile.
    ///
    /// Amapulatifomu amaningi empeleni awakwazi nokwakha isabelo esinjalo.
    /// Isibonelo, alikho ipulatifomu elaziwa ngama-64-bit elingake lisebenzise isicelo sama-byte ayi-2 <sup>63</sup> ngenxa yokulinganiselwa kwetafula lekhasi noma ukuhlukanisa isikhala sekheli.
    /// Kodwa-ke, amanye amapulatifomu angama-32-bit no-16-bit angasebenza ngempumelelo isicelo sama-byte we-`isize::MAX` ngezinto ezifana ne-Physical Address Extension.
    ///
    /// Njengoba kunje, imemori etholwe ngqo kusuka kubanikezeli noma kumafayela amakwe imemori * ingahle ibe nkulu kakhulu ukuthi ingaphathwa ngalo msebenzi.
    ///
    /// Cabanga ukusebenzisa i-[`wrapping_sub`] esikhundleni uma lezi zingqinamba kunzima ukuzanelisa.
    /// Okuwukuphela kwendlela yale ndlela ukuthi inika amandla ukwenziwa okuhle kakhulu kokuhlanganiswa.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ibala isamba kusuka kusikhombi kusetshenziswa izibalo zokugoqa.
    /// (lula i `.wrapping_offset(count as isize)`)
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala uphephile, kepha ukusebenzisa isikhombisi esivelayo akunjalo.
    ///
    /// Isikhombi esivelayo sihlala sinamathiselwe entweni efanayo eyabiwe i-`self` ekhomba kuyo.
    /// Kungenzeka * ingasetshenziswanga ukufinyelela entweni eyabiwe ehlukile.Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_add((y as usize) - (x as usize))` ayenzi * i-`z` ifane ne-`y` noma ngabe sicabanga ukuthi i-`T` inosayizi `1` futhi akukho okuchichimayo: I-`z` isanamathele entweni i-`x` enamathiselwe kuyo, futhi ukuyichaza kungukuziphatha okungachazwanga ngaphandle kokuthi i-`x` ne I-`y` ikhomba entweni efanayo eyabiwe.
    ///
    /// Uma kuqhathaniswa ne-[`add`], le ndlela ibambezela imfuneko yokuhlala ngaphakathi kwento efanayo eyabiwe: I-[`add`] iyindlela yokuziphatha engachazeki ngokushesha lapho weqa imingcele yento;I-`wrapping_add` ikhiqiza isikhombisi kepha isaholela ekuziphatheni okungachazeki uma isikhombi siboniswa uma singaphandle kwemingcele yento enamathiselwe kuyo.
    /// [`add`] ingenziwa ngcono kangcono futhi ngenxa yalokho ikhetha ikhodi ezwela ukusebenza.
    ///
    /// Isheke elibambezelekile libheka kuphela inani lesikhombi ebelingasetshenziswanga, hhayi amanani aphakathi nendawo asetshenziswe ngesikhathi kubalwa umphumela wokugcina.
    /// Isibonelo, i-`x.wrapping_add(o).wrapping_sub(o)` ihlala ifana ne-`x`.Ngamanye amagama, ukushiya into oyabelwe bese uyifaka kabusha emuva kwesikhathi kuvunyelwe.
    ///
    /// Uma udinga ukweqa imingcele yento, phonsa isikhombi kunamba bese wenza izibalo lapho.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // Iterate usebenzisa i-pointer eluhlaza ngokunyuka kwezinto ezimbili
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Le loop iphrinta i "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ibala isamba kusuka kusikhombi kusetshenziswa izibalo zokugoqa.
    /// (lula kwe-`.wrapping_offset ((count as isize).wrapping_neg())`)
    ///
    /// `count` kumayunithi ka-T;isb., i-`count` ka-3 imele ukukhishwa kwesikhombi sama-byte ayi-`3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Lo msebenzi ngokwawo uhlala uphephile, kepha ukusebenzisa isikhombisi esivelayo akunjalo.
    ///
    /// Isikhombi esivelayo sihlala sinamathiselwe entweni efanayo eyabiwe i-`self` ekhomba kuyo.
    /// Kungenzeka * ingasetshenziswanga ukufinyelela entweni eyabiwe ehlukile.Qaphela ukuthi ku-Rust, konke ukuguquguquka kwe-(stack-allocated) kubhekwa njengento ehlukanisiwe eyabiwe.
    ///
    /// Ngamanye amagama, i-`let z = x.wrapping_sub((x as usize) - (y as usize))` ayenzi * i-`z` ifane ne-`y` noma ngabe sicabanga ukuthi i-`T` inosayizi `1` futhi akukho okuchichimayo: I-`z` isanamathele entweni i-`x` enamathiselwe kuyo, futhi ukuyichaza kungukuziphatha okungachazwanga ngaphandle kokuthi i-`x` ne I-`y` ikhomba entweni efanayo eyabiwe.
    ///
    /// Uma kuqhathaniswa ne-[`sub`], le ndlela ibambezela imfuneko yokuhlala ngaphakathi kwento efanayo eyabiwe: I-[`sub`] iyindlela yokuziphatha engachazeki ngokushesha lapho weqa imingcele yento;I-`wrapping_sub` ikhiqiza isikhombisi kepha isaholela ekuziphatheni okungachazeki uma isikhombi siboniswa uma singaphandle kwemingcele yento enamathiselwe kuyo.
    /// [`sub`] ingenziwa ngcono kangcono futhi ngenxa yalokho ikhetha ikhodi ezwela ukusebenza.
    ///
    /// Isheke elibambezelekile libheka kuphela inani lesikhombi ebelingasetshenziswanga, hhayi amanani aphakathi nendawo asetshenziswe ngesikhathi kubalwa umphumela wokugcina.
    /// Isibonelo, i-`x.wrapping_add(o).wrapping_sub(o)` ihlala ifana ne-`x`.Ngamanye amagama, ukushiya into oyabelwe bese uyifaka kabusha emuva kwesikhathi kuvunyelwe.
    ///
    /// Uma udinga ukweqa imingcele yento, phonsa isikhombi kunamba bese wenza izibalo lapho.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // Iterate usebenzisa i-pointer eluhlaza ngokunyuka kwezinto ezimbili (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Le loop iphrinta i "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Isetha inani lesikhombi ku-`ptr`.
    ///
    /// Uma kwenzeka i-`self` iyisikhombi se-(fat) sohlobo olungasetshenzisiwe, lo msebenzi uzothinta kuphela ingxenye yesikhombi, kanti izikhombisi ze-(thin) ezinhlobonhlobo ezinesayizi, lokhu kunomphumela ofanayo njengesabelo esilula.
    ///
    /// Isikhombi esizophuma sizoba nokutholwa kwe-`val`, okungukuthi, i-pointer enonile, lo msebenzi ufana ncamashi nokwakha isikhombisi esisha samafutha ngenani lesikhombi sedatha ye-`val` kodwa imethadatha ye-`self`.
    ///
    ///
    /// # Examples
    ///
    /// Lo msebenzi ulusizo olukhulu ekuvumeleni i-byte-wise pointer arithmetic kuzikhombi ezingaba namafutha:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // izophrinta i "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // UKUPHEPHA: Uma kwenzeka ukhomba okuncane, lokhu kusebenza kuyafana
        // esabelweni esilula.
        // Uma kwenzeka ukhomba okunamafutha, ngokuqaliswa kokuhlelwa kwesikhombi samafutha, inkambu yokuqala yesikhombi esinjalo ihlala iyisikhombi sedatha, esabiwa ngokufanayo.
        //
        unsafe { *thin = val };
        self
    }

    /// Ifunda inani kusuka ku-`self` ngaphandle kokuyihambisa.
    /// Lokhu kushiya imemori ku-`self` kungashintshiwe.
    ///
    /// Bona i [`ptr::read`] ngezinkinga zokuphepha nezibonelo.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `read`.
        unsafe { read(self) }
    }

    /// Yenza ukufundwa okuguquguqukayo kwenani kusuka ku-`self` ngaphandle kokuyihambisa.Lokhu kushiya imemori ku-`self` kungashintshiwe.
    ///
    /// Ukusebenza okuguquguqukayo kuhloswe ngakho ukwenza kwimemori ye-I/O, futhi kuqinisekisiwe ukuthi ngeke kuphakanyiswe noma kuhlelwe kabusha ngumhlanganisi kweminye imisebenzi eguquguqukayo.
    ///
    ///
    /// Bona i [`ptr::read_volatile`] ngezinkinga zokuphepha nezibonelo.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Ifunda inani kusuka ku-`self` ngaphandle kokuyihambisa.
    /// Lokhu kushiya imemori ku-`self` kungashintshiwe.
    ///
    /// Ngokungafani ne-`read`, i-pointer ingahle ingalingani.
    ///
    /// Bona i [`ptr::read_unaligned`] ngezinkinga zokuphepha nezibonelo.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Amakhophi we-`count * size_of<T>` byte kusuka ku-`self` kuye ku-`dest`.
    /// Umthombo nendawo oya kuyo ingagqagqana.
    ///
    /// NOTE: lokhu kune-oda * lokuphikisana elifanayo ne-[`ptr::copy`].
    ///
    /// Bona i [`ptr::copy`] ngezinkinga zokuphepha nezibonelo.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Amakhophi we-`count * size_of<T>` byte kusuka ku-`self` kuye ku-`dest`.
    /// Umthombo nendawo oya kuyo kungenzeka * zingagudluki.
    ///
    /// NOTE: lokhu kune-oda * lokuphikisana elifanayo ne-[`ptr::copy_nonoverlapping`].
    ///
    /// Bona i [`ptr::copy_nonoverlapping`] ngezinkinga zokuphepha nezibonelo.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Icacisa okusetshenziswayo okudingeka ukuthi kusetshenziswe kusikhombi ukuze iqondaniswe ne-`align`.
    ///
    /// Uma kungenakwenzeka ukuqondanisa isikhombi, ukuqaliswa kubuyisa i-`usize::MAX`.
    /// Kuvumelekile ukuqaliswa ukubuyisela njalo i-`usize::MAX`.
    /// Ukusebenza kwe-algorithm yakho kuphela okungancika ekutholeni i-offset ezisebenzisekayo lapha, hhayi ukunemba kwayo.
    ///
    /// I-offset ivezwe ngenani lezinto ze-`T`, hhayi ama-byte.Inani elibuyisiwe lingasetshenziswa ngendlela ye-`wrapping_add`.
    ///
    /// Azikho iziqinisekiso zokuthi ukususa i-pointer ngeke kuchichime noma kudlule isabelo isikhombi esikhomba kuso.
    ///
    /// Kusekufoneni ukuqinisekisa ukuthi i-offset ebuyisiwe ilungile kuyo yonke imigomo ngaphandle kokuqondanisa.
    ///
    /// # Panics
    ///
    /// Umsebenzi we-panics uma i-`align` kungewona amandla-amabili.
    ///
    /// # Examples
    ///
    /// Ifinyelela eduze kwe `u8` njenge `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ngenkathi i-pointer ingaqondaniswa nge-`offset`, izokhomba ngaphandle kwesabelo
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // UKUPHEPHA: I-`align` ihlolwe ukuthi ingamandla ka-2 ngenhla
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Ibuyisa ubude besilayidi esiluhlaza.
    ///
    /// Inani elibuyisiwe liyinombolo yezinto **, hhayi inombolo yamabhayithi.
    ///
    /// Lo msebenzi uphephile, noma ngabe ucezu oluhlaza lungasakazwa kusithenjwa sesilayi ngoba isikhombi asisebenzi noma asihlelelwanga.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // UKUPHEPHA: lokhu kuphephile ngoba i-`*const [T]` ne-`FatPtr<T>` zinokuhlelwa okufanayo.
            // Yi-`std` kuphela engenza lesi siqinisekiso.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Ibuyisa isikhombi esiluhlaza kubha yesilayidi.
    ///
    /// Lokhu kulingana nokusakaza i-`self` kuye ku-`*const T`, kepha kuphephe kakhulu ngohlobo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Ibuyisa isikhombisi esiluhlaza entweni ethile noma ekubhaliseni, ngaphandle kokuhlola imingcele.
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele noma lapho i-`self` ingenakudluliswa kungaboniswa * *[indlela engachazwanga] * noma ngabe isikhombisi esiphumelayo asisetshenzisiwe.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // UKUPHEPHA: umuntu ofonayo uqinisekisa ukuthi i-`self` ayinakuguqulwa futhi i-`index` iyimingcele.
        unsafe { index.get_unchecked(self) }
    }

    /// Ibuyisa i-`None` uma i-pointer ingasebenzi, noma-ke ibuyisela isilayidi esabiwe kunani elisongwe nge-`Some`.
    /// Ngokuphikisana ne-[`as_ref`], lokhu akudingi ukuthi inani kufanele liqaliswe.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Lapho ubiza le ndlela, kufanele uqinisekise ukuthi *i* pointer iyi-NULL *noma* konke lokhu okulandelayo kuyiqiniso:
    ///
    /// * Isikhombi kufanele sibe yi-[valid] ukuze ifundelwe ama-`ptr.len() * mem::size_of::<T>()` amabhayithi amaningi, futhi kufanele aqondaniswe kahle.Lokhu kusho ikakhulukazi:
    ///
    ///     * Lonke uhla lwememori lwalesi siqeshana kufanele luqukathe entweni eyodwa eyabiwe!
    ///       Izingcezu azisoze zawela ezintweni eziningi ezabiwe.
    ///
    ///     * Isikhombi kufanele siqondaniswe nezingcezu zobude obungu-zero.
    ///     Isizathu esisodwa salokhu ukuthi ukulungiselelwa kokuhlelwa kwe-enum kungahle kuncike kuzinkomba (kufaka phakathi izingcezu zanoma ibuphi ubude) eziqondisiwe nezingasebenzi ukuze zihlukaniswe nenye idatha.
    ///
    ///     Ungathola i-pointer engasetshenziswa njenge-`data` yezingcezu zobude obunguziro usebenzisa i-[`NonNull::dangling()`].
    ///
    /// * Usayizi ophelele we-`ptr.len() * mem::size_of::<T>()` wocezu akumele ube mkhulu kune-`isize::MAX`.
    ///   Bona imibhalo yezokuphepha ye [`pointer::offset`].
    ///
    /// * Kufanele uphoqelele imithetho ejwayelekile ye-Rust, ngoba isikhathi sempilo esibuyisiwe i-`'a` sikhethwe ngokungekho emthethweni futhi asikhombisi isikhathi sangempela sedatha.
    ///   Ikakhulu, esikhathini salesi sikhathi sempilo, inkumbulo isikhombisi esikhomba kuyo akumele iguqulwe (ngaphandle kwangaphakathi kwe `UnsafeCell`).
    ///
    /// Lokhu kusebenza noma ngabe umphumela wale ndlela ungasetshenziswanga!
    ///
    /// Bheka futhi i [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Ukulingana kwezikhombi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Ukuqhathanisa izikhombisi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}