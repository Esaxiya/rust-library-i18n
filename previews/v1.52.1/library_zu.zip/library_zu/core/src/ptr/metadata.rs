#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Inikeza uhlobo lwemethadatha yesikhombi sanoma yiluphi uhlobo olukhombe.
///
/// # Imethadatha yesikhombi
///
/// Izinhlobo zesikhombi se-Raw nezinhlobo zezethenjwa ku-Rust kungacatshangwa ukuthi zenziwe izingxenye ezimbili:
/// isikhombi sedatha esiqukethe ikheli lememori lenani, kanye nemethadatha ethile.
///
/// Izinhlobo ezinosayizi (ezisebenzisa i-`Sized` traits) kanye nezinhlobo ze-`extern`, izikhombisi kuthiwa "zincane": imethadatha ilingana no-zero kanti uhlobo lwayo yi-`()`.
///
///
/// Izikhombi eziya ku [dynamically-sized types][dst] kuthiwa `zibanzi` noma `zinonile`, zinemethadatha engalingani
///
/// * Okwezinsimbi inkambu yazo yokugcina eyi-DST, imethadatha imethadatha yenkambu yokugcina
/// * Ngohlobo lwe-`str`, imethadatha ubude kuma-byte njenge-`usize`
/// * Izinhlobo zezinhlamvu ezifana ne-`[T]`, imethadatha ubude bezinto njenge-`usize`
/// * Okwezinto ze-trait ezifana ne-`dyn SomeTrait`, imethadatha ngu-[`DynMetadata<Self>`][DynMetadata] (isb. `DynMetadata<dyn SomeTrait>`)
///
/// Ku-future, ulimi lwe-Rust lungathola izinhlobo ezintsha zezinhlobo ezinemethadatha ehlukile yesikhombi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # I `Pointee` trait
///
/// Iphuzu lale trait uhlobo lwayo oluhambisana ne `Metadata`, okuyi-`()` noma i-`usize` noma i-`DynMetadata<_>` njengoba kuchaziwe ngenhla.
/// Kwenziwa ngokuzenzakalela kuzo zonke izinhlobo.
/// Kungacatshangwa ukuthi kungasetshenziswa kumongo ojwayelekile, noma ngaphandle kokubopha okuhambisanayo.
///
/// # Usage
///
/// Izikhombisi ezingavuthiwe zingachithwa kukheli ledatha nezakhi zemethadatha ngendlela yazo ye [`to_raw_parts`].
///
/// Ngenye indlela, imethadatha kuphela ingakhishwa ngomsebenzi we-[`metadata`].
/// Isethenjwa singadluliswa ku-[`metadata`] futhi siphoqelelwe ngokuphelele.
///
/// Isikhombi se-(possibly-wide) singabuyiselwa ndawonye kusuka kukheli laso nemethadatha ene-[`from_raw_parts`] noma i-[`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Uhlobo lwemethadatha kwizikhombi nezethenjwa ze-`Self`.
    #[lang = "metadata_type"]
    // NOTE: Gcina i-trait bounds ku-`static_assert_expected_bounds_for_metadata`
    //
    // ku-`library/core/src/ptr/metadata.rs` ngokuvumelanisa nalabo abalapha:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Izikhombisi zezinhlobo ezisebenzisa lezi zibizo ze-trait `zincane`.
///
/// Lokhu kufaka izinhlobo ze-statized-`Sized` nezinhlobo ze-`extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: musa ukukuzinzisa lokhu ngaphambi kokuthi iziteketiso ze-trait zingazinzi olimini?
pub trait Thin = Pointee<Metadata = ()>;

/// Khipha ingxenye yemethadatha yesikhombi.
///
/// Amanani ohlobo `*mut T`, `&T`, noma i-`&mut T` angadluliselwa ngqo kulo msebenzi njengoba ephoqa ngokuphelele i `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye `PtrRepr` kuphephile kusukela * const T
    // kanye ne-PtrComponents<T>unezakhiwo ezifanayo zememori.
    // std kuphela engenza lesi siqinisekiso.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Yenza i-pointer eluhlaza ye-(possibly-wide) kusuka kukheli ledatha nemethadatha.
///
/// Lo msebenzi uphephile kepha isikhombisi esibuyisiwe asiphephile ekunciphisweni.
/// Ngezicucu, bona imibhalo ye [`slice::from_raw_parts`] ngezidingo zokuphepha.
/// Okwezinto ze-trait, imethadatha kufanele isuke isuka kusikhombi iye ohlotsheni olufanayo lokuncipha.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye `PtrRepr` kuphephile kusukela * const T
    // kanye ne-PtrComponents<T>unezakhiwo ezifanayo zememori.
    // std kuphela engenza lesi siqinisekiso.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Yenza ukusebenza okufana ne-[`from_raw_parts`], ngaphandle kokuthi isikhombisi se-`*mut` eluhlaza siyabuyiselwa, ngokungafani nesikhombi se-`* const` eluhlaza.
///
///
/// Bona imibhalo ye [`from_raw_parts`] ukuthola eminye imininingwane.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye `PtrRepr` kuphephile kusukela * const T
    // kanye ne-PtrComponents<T>unezakhiwo ezifanayo zememori.
    // std kuphela engenza lesi siqinisekiso.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// I-Manual impl iyadingeka ukugwema ukuboshwa kwe-`T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// I-Manual impl iyadingeka ukugwema ukuboshwa kwe-`T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Imethadatha yohlobo lwento engu-`Dyn = dyn SomeTrait` trait.
///
/// Kuyisikhombi setafula le-vtable (itafula lokushaya elibonakalayo) elimele lonke ulwazi oludingekayo lokukhohlisa uhlobo lukakhonkolo olugcinwe ngaphakathi kwento ye trait.
/// I-vtable ngokuphawulekayo iqukethe:
///
/// * usayizi wohlobo
/// * ukuqondanisa kohlobo
/// * isikhombi sohlobo lwe-`drop_in_place` impl (kungahle kube yi-no-op yedatha-endala-idatha)
/// * izikhombisi kuzo zonke izindlela zokuqalisa kohlobo lwe-trait
///
/// Qaphela ukuthi ezintathu zokuqala zikhethekile ngoba ziyadingeka ukwaba, ukulahla, nokusabalalisa noma iyiphi into eyi-trait.
///
/// Kungenzeka ukuqamba lesi sakhiwo ngohlobo lwepharamitha olungeyona into eyi-`dyn` trait (ngokwesibonelo `DynMetadata<u64>`) kepha hhayi ukuthola inani elizwakalayo laleso sakhiwo.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Isiqalo esivamile sawo wonke ama-vtable.Kulandelwa izikhombisi zomsebenzi zezindlela ze-trait.
///
/// Imininingwane yokuqalisa kwangasese ye `DynMetadata::size_of` njll.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Ibuyisa usayizi wohlobo oluhambisana nale vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ibuyisa ukuqondanisa kohlobo oluhambisana nale vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ibuyisa usayizi nokuqondanisa ndawonye njenge-`Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // UKUPHEPHA: umhlanganisi ukhiphe le vtable yohlobo lukakhonkolo i-Rust
        // iyaziwa ukuthi inesakhiwo esivumelekile.Isizathu esifanayo ne-`Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ama-impls enziwe ngesandla adingeka ukugwema imingcele ye-`Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}