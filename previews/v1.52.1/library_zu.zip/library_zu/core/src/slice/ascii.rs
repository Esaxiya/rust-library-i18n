//! Ukusebenza ku-ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Ihlola ukuthi ngabe wonke ama-byte akulesi sigaba angaphakathi kwebanga le-ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Ihlola ukuthi izingcezu ezimbili ziwumdlalo we-ASCII ongenandaba.
    ///
    /// Kuyafana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, kepha ngaphandle kokwaba nokukopisha ama-temporari.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Iguqula lesi silayidi sibe i-ASCII esezingeni eliphezulu elilinganayo endaweni.
    ///
    /// Izinhlamvu ze-ASCII 'a' kuya ku-'z' zimakwe ku-'A' kuye ku-'Z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukubuyisa inani elisha eliphezulu ngaphandle kokushintsha elikhona, sebenzisa i-[`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Iguqula lesi silayidi sibe i-ASCII esezingeni elilinganayo endaweni yaso.
    ///
    /// Izinhlamvu ze-ASCII 'A' kuya ku-'Z' zimakwe ku-'a' kuye ku-'z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukubuyisa inani elisha elincishisiwe ngaphandle kokushintsha elikhona, sebenzisa i-[`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Ibuyisa i-`true` uma ngabe kukhona i-byte ezwi `v` engeyona i-nonascii (>=128).
/// I-Snarfed kusuka ku-`../str/mod.rs`, eyenza into efanayo ngokuqinisekiswa kwe-utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Ukuhlolwa okwenziwe kahle kwe-ASCII okuzosebenzisa ukusebenza kwe-us-at-a esikhundleni sokusebenza kwe-byte-at-a-time (lapho kungenzeka).
///
/// I-algorithm esiyisebenzisa lapha ilula kakhulu.Uma i-`s` imfushane kakhulu, simane sihlole i-byte ngayinye bese siyenziwa ngayo.Ngaphandle kwalokho:
///
/// - Funda igama lokuqala elinomthwalo ongalinganisiwe.
/// - Qondanisa isikhombi, funda amagama alandelayo kuze kube sekupheleni ngemithwalo ehambisanayo.
/// - Funda i `usize` yokugcina kusuka ku `s` ngomthwalo ongalinganiselwanga.
///
/// Uma enye yale mithwalo ikhiqiza okuthile i-`contains_nonascii` (above) ebuya iyiqiniso, siyazi ukuthi impendulo ingamanga.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Uma singeke sithole lutho ekusetshenzisweni kwegama-at-a-time, buyela emuva ku-scalar loop.
    //
    // Lokhu futhi sikwenzela izakhiwo lapho i-`size_of::<usize>()` ingekho ukuqondanisa okwanele kwe-`usize`, ngoba kuyicala elixakile le-edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Sihlala silifunda igama lokuqala elithi unaligned, okusho ukuthi i `align_offset` iyi
    // 0, besizofunda inani elifanayo futhi ekufundeni okuhambisanayo.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // UKUPHEPHA: Siqinisekisa i-`len < USIZE_SIZE` ngenhla.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Sikubheke lokhu ngenhla, ngandlela thile.
    // Qaphela ukuthi i-`offset_to_aligned` kungaba i-`align_offset` noma i-`USIZE_SIZE`, womabili ahlolwe ngokusobala ngenhla.
    //
    debug_assert!(offset_to_aligned <= len);

    // UKUPHEPHA: i-word_ptr yi-ustr (eqondaniswe kahle) usize ptr esiyisebenzisa ukufunda i-
    // isinqamu esiphakathi socezu.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` inkomba ye-byte ye-`word_ptr`, esetshenziselwa ukuhlola ukuphela kwe-loop.
    let mut byte_pos = offset_to_aligned;

    // I-Paranoia hlola ukulumbana, ngoba sesizokwenza inqwaba yemithwalo engalingani.
    // Ngokwenza lokhu lokhu kufanele kungabi khona ukuvimbela isiphazamisi ku-`align_offset` noma kunjalo.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Funda amagama alandelayo kuze kube igama lokugcina eliqondaniswe, ngaphandle kwegama lokugcina eliqondaniswe ngokwalo elizokwenziwa ekuhloleni umsila ngokuhamba kwesikhathi, ukuqinisekisa ukuthi umsila uhlala uyi-`usize` eyodwa kuya ku-branch `byte_pos == len` eyengeziwe.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Bheka kahle ukuthi ukufundwa kukhawulelwe yini
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Futhi lokho esikucabangayo mayelana ne-`byte_pos` ibambile.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // UKUPHEPHA: Siyazi ukuthi i `word_ptr` iqondaniswe kahle (ngenxa ye-
        // `align_offset`), futhi siyazi ukuthi sinamabhayithi anele phakathi kwe `word_ptr` nokuphela
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // UKUPHEPHA: Siyayazi leyo `byte_pos <= len - USIZE_SIZE`, okusho ukuthi
        // ngemuva kwale `add`, i `word_ptr` izobe idlula kokukodwa kuze kube sekupheleni.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ukuhlolwa kwesanity ukuqinisekisa ukuthi ngempela kukhona i-`usize` eyodwa esele.
    // Lokhu kufanele kuqinisekiswe yisimo sethu se-loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // UKUPHEPHA: Lokhu kuncike ku `len >= USIZE_SIZE`, esiyihlola ekuqaleni.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}