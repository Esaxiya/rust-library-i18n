//! Ukuhlunga ucezu
//!
//! Le mojula iqukethe i-algorithm yokuhlunga ngokususelwa ku-Orson Peters 'yokunqoba iphethini i-quicksort, eshicilelwe ku: <https://github.com/orlp/pdqsort>
//!
//!
//! Ukuhlunga okungazinzile kuhambisana ne-libcore ngoba ayinikezi imemori, ngokungafani nokuqaliswa kwethu kokuhlunga okuzinzile.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Lapho ilahliwe, amakhophi asuka ku-`src` aya ku-`dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // UKUPHEPHA: Lesi isigaba sabasizi.
        //          Sicela ubheke ekusetshenzisweni kwayo ngokunemba.
        //          Okungukuthi, umuntu kufanele aqiniseke ukuthi i-`src` ne-`dst` azidluli njengoba kufunwa yi-`ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Ihambisa into yokuqala iye kwesokudla ize ihlangane nento enkulu noma elinganayo.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // UKUPHEPHA: Imisebenzi engaphephile engezansi ihilela ukufaka inkomba ngaphandle kwesheke eliboshiwe (`get_unchecked` ne `get_unchecked_mut`)
    // nokukopisha inkumbulo (`ptr::copy_nonoverlapping`).
    //
    // a.Inkomba:
    //  1. Sibheke usayizi wamalungu afanayo ku>> 2.
    //  2. Konke ukukhonjiswa esizokwenza kuhlale kuphakathi kwe {0 <= index < len} kakhulu.
    //
    // b.Ukukopisha imemori
    //  1. Sithola izikhombisi ezikhomba okuqinisekisiwe ukuthi zivumelekile.
    //  2. Azikwazi ukugqagqana ngoba sithola izikhombisi kuma-indices we-slice.
    //     Okungukuthi, i-`i` ne-`i-1`.
    //  3. Uma ucezu luqondaniswe kahle, izakhi ziqondaniswe kahle.
    //     Kungumsebenzi wofonayo ukuqinisekisa ukuthi ucezu luhambisana kahle.
    //
    // Bona imibono engezansi ukuthola eminye imininingwane.
    unsafe {
        // Uma izinto ezimbili zokuqala ziphelelwe isikhathi ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Funda into yokuqala kokuguquguqukayo okwabiwe ngesitaki.
            // Uma umsebenzi olandelayo wokuqhathanisa i-panics, i-`hole` izokwehliswa bese ibhala ngokuzenzakalela into kucezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Hambisa `i`-th element indawo eyodwa kwesobunxele, ngaleyo ndlela ususe imbobo ngakwesokudla.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` iyehla bese ngaleyo ndlela ikopisha i-`tmp` emgodini osele ku-`v`.
        }
    }
}

/// Ihambisa into yokugcina iye kwesokunxele ize ihlangane nento encane noma elinganayo.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // UKUPHEPHA: Imisebenzi engaphephile engezansi ihilela ukufaka inkomba ngaphandle kwesheke eliboshiwe (`get_unchecked` ne `get_unchecked_mut`)
    // nokukopisha inkumbulo (`ptr::copy_nonoverlapping`).
    //
    // a.Inkomba:
    //  1. Sibheke usayizi wamalungu afanayo ku>> 2.
    //  2. Konke ukukhonjiswa esizokwenza kuhlale kuphakathi kwe `0 <= index < len-1` kakhulu.
    //
    // b.Ukukopisha imemori
    //  1. Sithola izikhombisi ezikhomba okuqinisekisiwe ukuthi zivumelekile.
    //  2. Azikwazi ukugqagqana ngoba sithola izikhombisi kuma-indices we-slice.
    //     Okungukuthi, i-`i` ne-`i+1`.
    //  3. Uma ucezu luqondaniswe kahle, izakhi ziqondaniswe kahle.
    //     Kungumsebenzi wofonayo ukuqinisekisa ukuthi ucezu luhambisana kahle.
    //
    // Bona imibono engezansi ukuthola eminye imininingwane.
    unsafe {
        // Uma izinto ezimbili zokugcina zingaphandle kwe-oda ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Funda into yokugcina kokuguquguqukayo okwabiwe ngesitaki.
            // Uma umsebenzi olandelayo wokuqhathanisa i-panics, i-`hole` izokwehliswa bese ibhala ngokuzenzakalela into kucezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Hambisa `i`-th element indawo eyodwa kwesokudla, ngaleyo ndlela ususe imbobo ngakwesobunxele.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` iyehla bese ngaleyo ndlela ikopisha i-`tmp` emgodini osele ku-`v`.
        }
    }
}

/// Hlunga kancane ucezu ngokususa izinto ezithile ezingaphandle kwe-oda nxazonke.
///
/// Ibuyisa i-`true` uma ucezu luhlungwe ekugcineni.Lo msebenzi uyicala elibi kakhulu elithi *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Inombolo enkulu yamabhangqa aphume ngaphandle kwe-oda azoshintshwa.
    const MAX_STEPS: usize = 5;
    // Uma isilayidi sifushane kunalokhu, ungashintshi noma yiziphi izinto.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // UKUPHEPHA: Sesivele sikwenze ngokusobala ukubheka nge-`i < len`.
        // Konke ukukhonjiswa kwethu okulandelayo kusebangeni le-`0 <= index < len` kuphela
        unsafe {
            // Thola ipheya elilandelayo lezinto eziseduze kwe-oda.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ngabe sesiqedile?
        if i == len {
            return true;
        }

        // Ungashintshi izinto kumalungu afushane amafushane, anezindleko zokusebenza.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Shintsha izakhi ezitholakele.Lokhu kubabeka ngokulandelana okulungile.
        v.swap(i - 1, i);

        // Shift i-elementi encane iye kwesokunxele.
        shift_tail(&mut v[..i], is_less);
        // Shift i-elementi enkulu iye kwesokudla.
        shift_head(&mut v[i..], is_less);
    }

    // Ayiphumelelanga ukuhlela ucezu ezinombolweni ezinqunyelwe zezinyathelo.
    false
}

/// Ihlunga ucezu kusetshenziswa uhlobo lokufaka, okuyi-O *(* n * ^ 2) eyicala elibi kakhulu.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ihlunga i-`v` isebenzisa i-heapsort, eqinisekisa i-*O*(*n*\*log(* n*)) icala elibi kakhulu.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Le nqwaba kanambambili ihlonipha i-`parent >= child` engaguquki.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Izingane ze-`node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Khetha ingane enkulu.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Misa uma okungajwayelekile kubambe ku-`node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Shintsha i-`node` nengane enkulu, hambisa igxathu elilodwa phansi, bese uqhubeka uhlunga.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Yakha inqwaba ngesikhathi esifanele.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Izinto eziphezulu kakhulu ze-Pop ezivela enqwabeni.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Izingxenye `v` zibe izakhi ezincane kuno-`pivot`, zilandelwe izinto ezingaphezulu noma ezilingana ne-`pivot`.
///
///
/// Ibuyisa inani lezinto ezincane kuno-`pivot`.
///
/// Ukwahlukanisa kwenziwa nge-block-by-block ukuze kuncishiswe izindleko zokusebenza kwegatsha.
/// Lo mbono wethulwe ephepheni le [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Inani lezakhi kubhulokhi elijwayelekile.
    const BLOCK: usize = 128;

    // I-algorithm yokuhlukanisa iphinda lezi zinyathelo ezilandelayo kuze kube sekuqedeni:
    //
    // 1. Landzelela ibhulokhi kusuka ohlangothini lwesobunxele ukuze ukhombe izinto ezinkulu noma ezilingana ne-pivot.
    // 2. Landzelela ibhulokhi kusuka ohlangothini lwesokudla ukukhomba izinto ezincane kune-pivot.
    // 3. Shintshanisa izinto ezikhonjiwe phakathi kohlangothi lwesobunxele nolwesokudla.
    //
    // Sigcina okuguqukayo okulandelayo kwebhulokhi lezinto:
    //
    // 1. `block` - Inani lezakhi kubhulokhi.
    // 2. `start` - Qala isikhombisi kuhlu lwe-`offsets`.
    // 3. `end` - Isikhombi sokugcina kuhlu lwe-`offsets`.
    // 4. `ukukhokhelwa, ama-Indices wezinto ezingaphandle kwe-oda ngaphakathi kwebhulokhi.

    // Ibhlokhi yamanje ohlangothini lwesobunxele (kusuka ku-`l` kuye ku-`l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Ibhulokhi yamanje engakwesokudla (kusuka ku-`r.sub(block_r)` to `r`).
    // UKUPHEPHA: Imibhalo ye .add() isho ngokuqondile ukuthi i `vec.as_ptr().add(vec.len())` ihlale iphephile`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Lapho sithola ama-VLAs, zama ukudala uhlu olulodwa lobude be-`min(v.len(), 2 * BLOCK) `kunalokho
    // kunamalungu amabili wosayizi ongaguquki wobude `BLOCK`.Ama-VLA angahle asebenze ngokwengeziwe kunqolobane.

    // Ibuyisa inani lezinto eziphakathi kwezikhombi `l` (inclusive) ne `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Senziwe ngokuhlukanisa i-block-by-block lapho i-`l` ne-`r` zisondela kakhulu.
        // Ngemuva kwalokho senza umsebenzi wokuhlanganisa ukuze sihlukanise izinto ezisele phakathi.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Inani lezinto ezisele (namanje alifaniswa nepivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Lungisa osayizi bamabhulokhi ukuze ibhulokhi yesobunxele nakwesokudla ingagudluki, kodwa uqondaniswe kahle ukumboza igebe lonke elisele.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Landela izinto ze-`block_l` kusuka ohlangothini lwesobunxele.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // UKUPHEPHA: Imisebenzi yokuphepha engezansi ibandakanya ukusetshenziswa kwe `offset`.
                //         Ngokuya ngezimo ezifunwa umsebenzi, siyazanelisa ngoba:
                //         1. `offsets_l` kunikezwe isitaki, futhi ngaleyo ndlela kubhekwe njengento ehlukanisiwe eyabiwe.
                //         2. Umsebenzi `is_less` ubuyisa i-`bool`.
                //            Ukusakaza i-`bool` ngeke kuze kuchichime i `isize`.
                //         3. Siqinisekisile ukuthi i-`block_l` izoba yi-`<= BLOCK`.
                //            Futhi, i `end_l` ekuqaleni yayisethelwe kusikhombi sokuqala se `offsets_` esamenyezelwa esitaki.
                //            Ngakho-ke, siyazi ukuthi noma esimweni esibi kakhulu (konke ukunxuswa kwe `is_less` kubuya kungamanga) sizobe sesidlula okungenani i-byte eyodwa ekugcineni.
                //        Okunye ukusebenza okungaphephile lapha ukususa i-`elem`.
                //        Kodwa-ke, i `elem` ekuqaleni bekuyisikhombi sokuqala kocezu oluhlala lusebenza.
                unsafe {
                    // Ukuqhathanisa okungenagatsha.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Landela izinto ze-`block_r` kusuka ohlangothini lwesokudla.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // UKUPHEPHA: Imisebenzi yokuphepha engezansi ibandakanya ukusetshenziswa kwe `offset`.
                //         Ngokuya ngezimo ezifunwa umsebenzi, siyazanelisa ngoba:
                //         1. `offsets_r` kunikezwe isitaki, futhi ngaleyo ndlela kubhekwe njengento ehlukanisiwe eyabiwe.
                //         2. Umsebenzi `is_less` ubuyisa i-`bool`.
                //            Ukusakaza i-`bool` ngeke kuze kuchichime i `isize`.
                //         3. Siqinisekisile ukuthi i-`block_r` izoba yi-`<= BLOCK`.
                //            Futhi, i `end_r` ekuqaleni yayisethelwe kusikhombi sokuqala se `offsets_` esamenyezelwa esitaki.
                //            Ngakho-ke, siyazi ukuthi noma esimweni esibi kakhulu (konke ukunxuswa kwe `is_less` kubuya kube yiqiniso) sizobe sesidlula okungenani i-1 byte ukuphela kokuphela.
                //        Okunye ukusebenza okungaphephile lapha ukususa i-`elem`.
                //        Kodwa-ke, i `elem` ekuqaleni yayingu-`1 *sizeof(T)` kudlule ukuphela futhi sayinciphisa ngo-`1* sizeof(T)` ngaphambi kokuyithola.
                //        Futhi, i-`block_r` yaqinisekiswa ukuthi ingaphansi kuka-`BLOCK` futhi i-`elem` ngakho-ke izobe ikhomba ekuqaleni kocezu.
                unsafe {
                    // Ukuqhathanisa okungenagatsha.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Inombolo yezinto ezingaphandle koku-oda ezizoshintshaniswa phakathi kohlangothi lwesobunxele nolwesokudla.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Esikhundleni sokushintshanisa i-pair eyodwa ngaleso sikhathi, kusebenza kahle ukwenza imvume yokujikeleza.
            // Lokhu akulingani ngokuqinile nokushintshanisa, kepha kuveza umphumela ofanayo usebenzisa imisebenzi emincane yememori.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Zonke izinto ezingaphandle kwe-oda kubhulokhi yesobunxele zihanjisiwe.Iya kwibhulokhi elilandelayo.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Zonke izinto ezingaphandle kwe-oda kubhulokhi engakwesokudla zihanjisiwe.Iya kubhulokhi yangaphambilini.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Konke okusele manje kunebhulokhi elilodwa (kungaba kwesobunxele noma kwesokudla) ngezinto ezingaphandle kwe-oda ezidinga ukuhanjiswa.
    // Izinto ezinjalo ezisele zingashintshelwa ekugcineni phakathi kwebhulokhi labo.
    //

    if start_l < end_l {
        // Ibhlokhi elingakwesobunxele lihlala.
        // Hambisa izinto zalo ezisele zingaphandle koku-oda ziye kwesokudla kakhulu.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Ibhlokhi elifanele lihlala.
        // Hambisa izakhi zalo ezingaphandle kwe-oda ezisele ngakwesokunxele.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Akukho okunye okufanele sikwenze, sesiqedile.
        width(v.as_mut_ptr(), l)
    }
}

/// Izingxenye `v` zibe izakhi ezincane kuno-`v[pivot]`, zilandelwe izinto ezingaphezulu noma ezilingana ne-`v[pivot]`.
///
///
/// Ibuyisa isiHlathi se:
///
/// 1. Inani lezinto ezincane kuno-`v[pivot]`.
/// 2. Kuyiqiniso uma i `v` ibivele yahlukanisiwe.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Beka i-pivot ekuqaleni kocezu.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Funda i-pivot kokuguquguqukayo okwabiwe ngesitaki ukuze kusebenze kahle.
        // Uma umsebenzi wokuqhathanisa olandelayo u-panics, i-pivot izobhalwa ngokuzenzakalela iphinde ibuyele kucezu.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Thola izakhi zokuqala ezingaphandle koku-oda.
        let mut l = 0;
        let mut r = v.len();

        // UKUPHEPHA: Ukuphepha okungezansi kubandakanya ukufaka inkomba kumalungu afanayo.
        // Eyokuqala: Sesivele senza imingcele ebheka lapha nge `l < r`.
        // Eyesibili: Ekuqaleni sine-`l == 0` ne-`r == v.len()` futhi salibheka lelo `l < r` kuyo yonke imisebenzi yokukhomba.
        //                     Ukusuka lapha siyazi ukuthi i-`r` kufanele okungenani ibe yi-`r == l` ekhonjiswe ukuthi isebenza kusukela kowokuqala.
        unsafe {
            // Thola into yokuqala enkulu noma elingana ne-pivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Thola into yokugcina incane kune-pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` iphuma esikhaleni bese ibhala i-pivot (okuhlukanisiwe okwabiwe isitaki) emuva kucezwana lapho yayikhona ekuqaleni.
        // Lesi sinyathelo sibalulekile ekuqinisekiseni ukuphepha!
        //
    };

    // Beka i-pivot phakathi kwalezi zingxenye ezimbili.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Izingxenye `v` zibe izakhi ezilingana no-`v[pivot]` zilandelwe yizinto ezinkulu kune-`v[pivot]`.
///
/// Ibuyisa inani lezinto ezilingana ne-pivot.
/// Kucatshangwa ukuthi i-`v` ayiqukethe izinto ezincane kune-pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Beka i-pivot ekuqaleni kocezu.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Funda i-pivot kokuguquguqukayo okwabiwe ngesitaki ukuze kusebenze kahle.
    // Uma umsebenzi wokuqhathanisa olandelayo u-panics, i-pivot izobhalwa ngokuzenzakalela iphinde ibuyele kucezu.
    // UKUPHEPHA: Isikhombi lapha sivumelekile ngoba sitholwe kusuka ekubhekisweni kocezwana.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Manje hlukanisa ucezu.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // UKUPHEPHA: Ukuphepha okungezansi kubandakanya ukufaka inkomba kumalungu afanayo.
        // Eyokuqala: Sesivele senza imingcele ebheka lapha nge `l < r`.
        // Eyesibili: Ekuqaleni sine-`l == 0` ne-`r == v.len()` futhi salibheka lelo `l < r` kuyo yonke imisebenzi yokukhomba.
        //                     Ukusuka lapha siyazi ukuthi i-`r` kufanele okungenani ibe yi-`r == l` ekhonjiswe ukuthi isebenza kusukela kowokuqala.
        unsafe {
            // Thola into yokuqala enkulu kune-pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Thola into yokugcina elingana ne-pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ngabe sesiqedile?
            if l >= r {
                break;
            }

            // Shintsha izinto ezingaphandle kwe-oda ezitholakele.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Sithole izinto ze-`l` ezilingana ne-pivot.Faka u-1 ku-akhawunti ye-pivot uqobo.
    l + 1

    // `_pivot_guard` iphuma esikhaleni bese ibhala i-pivot (okuhlukanisiwe okwabiwe isitaki) emuva kucezwana lapho yayikhona ekuqaleni.
    // Lesi sinyathelo sibalulekile ekuqinisekiseni ukuphepha!
}

/// Isabalalisa ezinye izinto ezizungezile ngomzamo wokwephula amaphethini angadala ukwahlukaniswa okungalingani ku-quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // I-Pseudorandom number generator evela ephepheni le "Xorshift RNGs" nguGeorge Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Thatha izinombolo ezingahleliwe modulo yale nombolo.
        // Inombolo ingena ku-`usize` ngoba i-`len` ayinkulu kune-`isize::MAX`.
        let modulus = len.next_power_of_two();

        // Abanye abakhethiweyo be-pivot bazoba seduze kwale nkomba.Ake sizenze zingahleliwe.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Khiqiza inombolo engahleliwe modulo `len`.
            // Kodwa-ke, ukuze sigweme imisebenzi ebizayo siqale siyithathe modulo amandla amabili, bese sehla ngo-`len` ize ilingane nebanga le-`[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` kuqinisekisiwe ukuthi ngaphansi kuka-`2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Ikhetha i-pivot ku-`v` bese ibuyisa inkomba ne-`true` uma ucezu kungenzeka seluvele luhleliwe.
///
/// Izinto ezise-`v` zingahle zihlelwe kabusha kwinqubo.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ubude obuncane bokukhetha indlela ye-median-of-medians.
    // Izingcezu ezimfushane zisebenzisa indlela elula ephakathi nendawo kwezintathu.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Inombolo enkulu yokushintshana engenziwa kulo msebenzi.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Izinkomba ezintathu esiseduze lapho sizokhetha khona i-pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Ibala inani eliphelele lokushintshaniswa esesizokwenza ngenkathi sihlela izinkomba.
    let mut swaps = 0;

    if len >= 8 {
        // Ishintsha ama-indices ukuze i-`v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Ishintsha ama-indices ukuze i-`v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Ithola i-median ye-`v[a - 1], v[a], v[a + 1]` bese igcina inkomba ku-`a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Thola abalamuli ezindaweni ezingomakhelwane ze `a`, `b`, ne `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Thola imedian phakathi kwe `a`, `b`, ne `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Inani eliphezulu lokushintshaniswa lenziwe.
        // Amathuba ukuthi ucezu luyehla noma luyehla kakhulu, ngakho-ke ukubuyela emuva kungasiza ukuluhlela ngokushesha.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Izinhlobo `v` eziphindayo.
///
/// Uma ucezu lwalunomanduleli kumalungu afanayo okuqala, luchazwa njenge-`pred`.
///
/// `limit` yinombolo yamahlukanisi angalingani angalingani ngaphambi kokushintshela ku-`heapsort`.
/// Uma kungu-zero, lo msebenzi uzoshintshela ku-heapsort ngokushesha.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Izingcezu ezifika kuleli banga zihlelwa kusetshenziswa uhlobo lokufaka.
    const MAX_INSERTION: usize = 20;

    // Kuyiqiniso uma ukwahlukanisa kokugcina bekulinganiswe kahle.
    let mut was_balanced = true;
    // Kuyiqiniso uma ukwahlukanisa kokugcina kungashintshanga izinto (isilayidi besivele sihlukanisiwe).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Izilayi ezifushane kakhulu ziyahlelwa kusetshenziswa uhlobo lokufakwa.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Uma kukhethwe izinqumo ezimbi kakhulu ze-pivot, mane ubuyele emuva ku-heapsort ukuze uqinisekise icala elibi kakhulu le-`O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Uma ukwahlukanisa kokugcina bekungalingani, zama ukwephula amaphethini kocezu ngokushova ezinye izinto nxazonke.
        // Sethemba ukuthi sizokhetha i-pivot engcono kulokhu.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Khetha i-pivot bese uzama ukuqagela ukuthi ucezu seluhleliwe yini.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Uma ukwahlukanisa kokugcina bekulinganiswe ngokufanele futhi kungashintshanga izinto, futhi uma ukukhethwa kwe-pivot kubikezela ucezu kungenzeka ukuthi seluhleliwe kakade ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Zama ukukhomba izinto ezithile ezingaphandle kwe-oda futhi uzihambise kuzikhundla ezilungile.
            // Uma ucezu luphela luhlungwa ngokuphelele, sesiqedile.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Uma i-pivot ekhethiwe ilingana neyandulelayo, khona-ke yinto encane kunazo zonke kucezu.
        // Hlukanisa ucezu kuzinto ezilingana nezinto ezinkulu kune-pivot.
        // Leli cala livame ukushaywa lapho ucezu luqukethe izinto eziningi eziyimpinda.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Qhubeka uhlunga ama-elementi amakhulu kune-pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Hlukanisa ucezu.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Hlukanisa isilayidi ku-`left`, `pivot`, naku-`right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Phindela emuva ohlangothini olufushane kuphela ukuze unciphise inani eliphelele lezingcingo eziphindaphindwayo futhi usebenzise isikhala esincane sesitaki.
        // Ngemuva kwalokho vele uqhubeke nohlangothi olude (lokhu kufana nokuphindwaphindwa komsila).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ihlwaya i-`v` isebenzisa iphethini ehlula iphethini, okuyi-*O*(*n*\*log(* n*)).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ukuhlunga akunakho ukuziphatha okunengqondo ezinhlotsheni ezingusayizi zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Nciphisa inani lokwahlukaniswa okungalingani ku-`floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Okwezingcezu ezifika kulobude mhlawumbe kuyashesha ukuzihlunga.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Khetha i-pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Uma i-pivot ekhethiwe ilingana neyandulelayo, khona-ke yinto encane kunazo zonke kucezu.
        // Hlukanisa ucezu kuzinto ezilingana nezinto ezinkulu kune-pivot.
        // Leli cala livame ukushaywa lapho ucezu luqukethe izinto eziningi eziyimpinda.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Uma sidlulise inkomba yethu, khona-ke silungile.
                if mid > index {
                    return;
                }

                // Ngaphandle kwalokho, qhubeka uhlunga izinto ezinkulu kune-pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Hlukanisa isilayidi ku-`left`, `pivot`, naku-`right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Uma i-mid==index, lapho-ke sesiqedile, ngoba i-partition() iqinisekise ukuthi zonke izinto ngemuva maphakathi zikhulu noma zilingana naphakathi.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ukuhlunga akunakho ukuziphatha okunengqondo ezinhlotsheni ezingusayizi zero.Ungenzi lutho.
    } else if index == v.len() - 1 {
        // Thola isici se-max bese usibeka endaweni yokugcina yamalungu afanayo.
        // Sikhululekile ukusebenzisa i-`unwrap()` lapha ngoba siyazi ukuthi i-v akumele ingabi nalutho.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Thola into engu-min bese uyibeka endaweni yokuqala yamalungu afanayo.
        // Sikhululekile ukusebenzisa i-`unwrap()` lapha ngoba siyazi ukuthi i-v akumele ingabi nalutho.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}