// Ukuqaliswa koqobo kuthathwe ku-rust-memchr.
// I-copyright ka-2015 u-Andrew Gallant, bluss noNicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Sebenzisa ukusika.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Ibuyisa i-`true` uma i-`x` iqukethe noma iyiphi i-zero byte.
///
/// Kusuka ku-*Matters Computational*, J. Arndt:
///
/// "Umqondo ngukususa elilodwa kumabhayithi ngamunye bese ubheka amabhayithi lapho okubolekwe kusakazeka khona kwaze kwaba sekubaluleke kakhulu
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Ibuyisa inkomba yokuqala efana ne-byte `x` ku-`text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Indlela esheshayo yezingcezu ezincane
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skena inani elilodwa le-byte ngokufunda amagama amabili we-`usize` ngasikhathi.
    //
    // Hlukanisa i `text` ngezingxenye ezintathu
    // - ingxenye yokuqala engaqondisiwe, ngaphambi kwekheli lokuqala eliqondaniswe nombhalo
    // - umzimba, thwebula ngamagama ama-2 ngasikhathi
    // - ingxenye yokugcina esele, <2 usayizi wamagama

    // sesha kuze kufike kumngcele oqondanisiwe
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // sesha umzimba wombhalo
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // UKUPHEPHA: isilandiso sesikhathi siqinisekisa ibanga okungenani lama-2 * usize_bytes
        // phakathi kwe-offset nokuphela kwesilayidi.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break uma kukhona i-byte efanayo
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Thola i-byte ngemuva kwephoyinti ukuma komzimba.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Ibuyisa inkomba yokugcina efana ne-byte `x` ku-`text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skena inani elilodwa le-byte ngokufunda amagama amabili we-`usize` ngasikhathi.
    //
    // Hlukanisa i `text` ngezingxenye ezintathu:
    // - umsila ongavumelanisiwe, ngemuva kwekheli lokugcina eliqondaniswe nombhalo,
    // - umzimba, uskenwe ngamagama ama-2 ngasikhathi,
    // - ama-byte okuqala asele, <2 size size.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Lokhu sikubiza nje ukuthola ubude besiqalo nesijobelelo.
        // Maphakathi nendawo sihlala sicubungula izihlanganisi ezimbili ngasikhathi sinye.
        // UKUPHEPHA: ukuhambisa i-`[u8]` kuye ku-`[usize]` kuphephile ngaphandle kokwehluka kosayizi okuphathwa yi-`align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Sesha umzimba wombhalo, qiniseka ukuthi asiweli i-min_aligned_offset.
    // i-offset ihlala iqondaniswe, ngakho-ke ukuhlola nje i-`>` kwanele futhi kugwema ukugcwala okungaba khona.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // UKUPHEPHA: i-offset iqala ku-len, i-suffix.len(), inqobo nje uma inkulu kune-
        // i-min_aligned_offset (prefix.len()) ibanga elisele okungenani li-2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Phula uma kune-byte efanayo.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Thola i-byte ngaphambi kwephuzu lapho i-loop yomzimba imile.
    text[..offset].iter().rposition(|elt| *elt == x)
}