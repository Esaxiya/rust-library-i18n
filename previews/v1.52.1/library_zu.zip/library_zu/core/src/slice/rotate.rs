// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Izungezisa ububanzi be-`[mid-left, mid+right)` ngendlela yokuthi into eku-`mid` iba yinto yokuqala.Ngokulinganayo, ijikelezisa uhla lwezinto ze-`left` kwesokunxele noma izinto ze-`right` ngakwesokudla.
///
/// # Safety
///
/// Ububanzi obucacisiwe kufanele buvumeleke ekufundeni nasekubhaleni.
///
/// # Algorithm
///
/// I-Algorithm 1 isetshenziselwa amanani amancane we-`left + right` noma i-`T` enkulu.
/// Ama-elementi athuthelwa ezindaweni zawo zokugcina ngasikhathi sinye eqala ku-`mid - left` futhi ethuthuka ngezinyathelo ze-`right` modulo `left + right`, njengokuthi kudingeka isikhashana kuphela.
/// Ekugcineni, sifika emuva ku `mid - left`.
/// Kodwa-ke, uma i-`gcd(left + right, right)` kungesona esingu-1, lezi zinyathelo ezingenhla zeqe izinto.
/// Ngokwesibonelo:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Ngenhlanhla, inani lezinto ezeqiwe phakathi kwezinto eziphothuliwe lihlala lilingana, ngakho-ke singamane silinganise indawo yethu yokuqala futhi senze imizuliswano eminingi (inani eliphelele lama-rounds yi-`gcd(left + right, right)` value).
///
/// Umphumela uba ukuthi zonke izinto ziphothulwe kanye kanye kanye kuphela.
///
/// I-Algorithm 2 isetshenziswa uma i-`left + right` inkulu kepha i-`min(left, right)` incane ngokwanele ukuthi inganela isitaki sesitaki.
/// Izakhi ze-`min(left, right)` zikopishelwa kubhafa, i-`memmove` isetshenziswa kwezinye, kuthi lezo ezikubhafa zibuyiselwe emgodini ohlangothini oluphambene nalapho zisuka khona.
///
/// Ama-algorithms angenziwa i-vectorised adlula lokhu okungenhla uma i-`left + right` iba nkulu ngokwanele.
/// I-Algorithm 1 ingenziwa i-vectorised ngokunqamula nokwenza imijikelezo eminingi ngasikhathi sinye, kepha kunemijikelezo embalwa kakhulu ngokwesilinganiso kuze kube yilapho i-`left + right` inkulu kakhulu, futhi icala elibi kakhulu lomjikelezo owodwa lihlala likhona njalo.
/// Esikhundleni salokho, i-algorithm 3 isebenzisa ukushintshwa okuphindaphindwayo kwezinto ze-`min(left, right)` kuze kushiye inkinga encane yokuzungezisa.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// lapho i-`left < right` ukushintshwa kwenzeka kusuka kwesobunxele esikhundleni.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ama-algorithm angezansi angahluleka uma lawa macala engahloliswanga
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // I-Algorithm 1 Microbenchmarks ikhombisa ukuthi ukusebenza okujwayelekile kokushintshwa okungahleliwe kungcono kuyo yonke indlela kuze kube cishe yi-`left + right == 32`, kepha ukusebenza kwecala elibi kakhulu kwehla ngisho nxazonke ze-16.
            // 24 wakhethwa njengomhlaba ophakathi nendawo.
            // Uma ubukhulu be-`T` bukhulu kune-4 `usize`s, le algorithm futhi idlula amanye ama-algorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ukuqala komzuliswano wokuqala
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ingatholwa ngaphambi kwesandla ngokubala i-`gcd(left + right, right)`, kepha kuyashesha ukwenza iluphu eyodwa ebala i-gcd njengomphumela oseceleni, bese wenza konke okusalayo
            //
            //
            let mut gcd = right;
            // amabhentshi aveza ukuthi kushesha ukushintshanisa ama-temporaries yonke indawo esikhundleni sokufunda okwesikhashana kanye, ukukopisha emuva, bese ubhala leso sikhashana ekugcineni.
            // Lokhu kungenzeka kungenxa yokuthi ukushintsha noma ukufaka ama-temporari kusetshenziswa ikheli elilodwa lememori ku-loop esikhundleni sokudinga ukuphatha amabili.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // esikhundleni sokukhulisa i-`i` bese ubheka ukuthi ngabe ingaphandle kwemingcele, sibheka ukuthi i-`i` izophuma ngaphandle kwemingcele ekukhuphukeni okulandelayo.
                // Lokhu kuvimbela noma yikuphi ukugoqwa kwezikhombi noma i-`usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ukuphela komzuliswano wokuqala
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // lo mbandela kufanele ube lapha uma i-`left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // qeda isinqamu ngamarounds amaningi
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` akuyona uhlobo olungu-zero, ngakho-ke kulungile ukuhlukanisa ngosayizi wayo.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // I-Algorithm 2 I-`[T; 0]` lapha ukuqinisekisa ukuthi iqondaniswe kahle ne-T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // I-Algorithm 3 Kunenye indlela yokushintshanisa ebandakanya ukuthola ukuthi ukushintshaniswa kokugcina kwale algorithm kuzoba kuphi, nokushintshanisa usebenzisa leyo chunk yokugcina esikhundleni sokushintshanisa izihlanganisi eziseduze njengale algorithm eyenzayo, kepha le ndlela ishesha kakhulu.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // I-Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}