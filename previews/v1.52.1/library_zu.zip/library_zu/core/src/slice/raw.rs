//! Imisebenzi yamahhala yokwenza i-`&[T]` ne-`&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Yakha ucezu kusuka kusikhombi nobude.
///
/// Impikiswano ye-`len` iyinombolo yezinto **, hhayi inombolo yamabhayithi.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `data` kumele kube yi-[valid] yokufundwa kwama-byte ayi-`len * mem::size_of::<T>()` amaningi, futhi kufanele iqondaniswe kahle.Lokhu kusho ikakhulukazi:
///
///     * Lonke uhla lwememori lwalesi siqeshana kufanele luqukathe entweni eyodwa eyabiwe!
///       Izingcezu azisoze zawela ezintweni eziningi ezabiwe.Bona i [below](#incorrect-usage) ngokwesibonelo ngokungakufaki ngokungafanele lokhu.
///     * `data` akumele ingasebenzi futhi iqondaniswe ngisho nezicucu zobude obungu-zero.
///     Isizathu esisodwa salokhu ukuthi ukulungiselelwa kokuhlelwa kwe-enum kungahle kuncike kuzinkomba (kufaka phakathi izingcezu zanoma ibuphi ubude) eziqondisiwe nezingasebenzi ukuze zihlukaniswe nenye idatha.
///     Ungathola i-pointer engasetshenziswa njenge-`data` yezingcezu zobude obunguziro usebenzisa i-[`NonNull::dangling()`].
///
/// * `data` kumele ikhombe ku-`len` amanani aqaliswe ngokufanelekile ohlobo `T`.
///
/// * Imemori ebalulwe ngocezu olubuyiselwe akumele ishintshwe isikhathi sempilo engu-`'a`, ngaphandle kwangaphakathi kwe `UnsafeCell`.
///
/// * Usayizi ophelele we-`len * mem::size_of::<T>()` wocezu akumele ube mkhulu kune-`isize::MAX`.
///   Bona imibhalo yezokuphepha ye [`pointer::offset`].
///
/// # Caveat
///
/// Isikhathi sokuphila sesilayidi esibuyiselwe sisuselwa ekusetshenzisweni kwaso.
/// Ukuvimbela ukusetshenziswa kabi ngengozi, kuphakanyiswa ukuthi ubophele isikhathi sokuphila kunoma imuphi umthombo wokuphila ophephile kumongo, njengokuhlinzeka ngomsebenzi womsizi othatha isikhathi sempilo senani lomsingathi locezu, noma ngesichasiselo esicacile.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bonisa ucezu lwento eyodwa
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Ukusetshenziswa okungalungile
///
/// Umsebenzi olandelayo we-`join_slices` ngu-**unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Isisho esingenhla siqinisekisa ukuthi i-`fst` ne-`snd` ziyathintana, kepha kungenzeka ukuthi ziqukethe ngaphakathi kwe _different allocated objects_, lapho-ke ukudala lesi siqephu kungukuziphatha okungachazwanga.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` futhi i `b` yizinto ezahlukanisiwe ezabiwe ...
///     let a = 42;
///     let b = 27;
///     // ... okungabekwa ngokungafaniyo kwimemori: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Yenza ukusebenza okufanayo ne-[`from_raw_parts`], ngaphandle kokuthi kubuyiselwa ucezu olungaguquguquka.
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `data` kufanele kube yi-[valid] yakho kokubili okufundwayo futhi ibhalele ama-`len * mem::size_of::<T>()` amabhayithi amaningi, futhi kufanele iqondaniswe kahle.Lokhu kusho ikakhulukazi:
///
///     * Lonke uhla lwememori lwalesi siqeshana kufanele luqukathe entweni eyodwa eyabiwe!
///       Izingcezu azisoze zawela ezintweni eziningi ezabiwe.
///     * `data` akumele ingasebenzi futhi iqondaniswe ngisho nezicucu zobude obungu-zero.
///     Isizathu esisodwa salokhu ukuthi ukulungiselelwa kokuhlelwa kwe-enum kungahle kuncike kuzinkomba (kufaka phakathi izingcezu zanoma ibuphi ubude) eziqondisiwe nezingasebenzi ukuze zihlukaniswe nenye idatha.
///
///     Ungathola i-pointer engasetshenziswa njenge-`data` yezingcezu zobude obunguziro usebenzisa i-[`NonNull::dangling()`].
///
/// * `data` kumele ikhombe ku-`len` amanani aqaliswe ngokufanelekile ohlobo `T`.
///
/// * Imemori ebalulwe ngocezu olubuyiselwe akumele ifinyelelwe nganoma isiphi esinye isikhombisi (esingatholakali kunani lokubuyisa) isikhathi sempilo engu-`'a`.
///   Kokubili ukufinyelela nokufunda nokubhala akuvunyelwe.
///
/// * Usayizi ophelele we-`len * mem::size_of::<T>()` wocezu akumele ube mkhulu kune-`isize::MAX`.
///   Bona imibhalo yezokuphepha ye [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Iguqula ireferensi ku-T ibe ucezu lobude 1 (ngaphandle kokukopisha).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Iguqula ireferensi ku-T ibe ucezu lobude 1 (ngaphandle kokukopisha).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}