//! AmaMacros asetshenziswa ama-iterators wesilayidi.

// Ukufakwa ku-is_empty futhi len kwenza umehluko omkhulu wokusebenza
macro_rules! is_empty {
    // Indlela esibhala ngayo ubude be-iterator yeZST, lokhu kusebenza zombili iZST kanye ne-non-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Ukususa amasheke athile wemingcele (bona i-`position`), sibala ubude ngendlela engalindelekile.
// (Kuhlolwe nge-codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // kwesinye isikhathi sisetshenziswa ngaphakathi kwebhlokhi engaphephile

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Le _cannot_ isebenzisa i-`unchecked_sub` ngoba sincike ekugoqeni ukumela ubude bama-iterator ama-ZST amade.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Siyazi ukuthi i `start <= end`, ngakho-ke ingenza kangcono kune-`offset_from`, edinga ukubhekana nesayini esayiniwe.
            // Ngokusetha amafulegi afanele lapha singatshela i-LLVM lokhu, okusiza ukuthi kususwe ukuhlolwa kwemingcele.
            // UKUPHEPHA: Ngohlobo olungaguquguquki, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ngokuphinda utshele i-LLVM ukuthi izikhombisi zihlukaniswe ngosayizi wohlobo ngqo, ingalungiselela i-`len() == 0` iye phansi ibe yi-`start == end` esikhundleni se-`(end - start) < size`.
            //
            // UKUPHEPHA: Ngohlobo olungaguquguquki, izikhombisi zihambelana ngakho
            //         ibanga phakathi kwabo kufanele libe ngosayizi we-pointee ophindaphindiwe
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Incazelo eyabiwe yama-iterator e-`Iter` ne-`IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Ibuyisa into yokuqala bese ihambisa ukuqala kwe-iterator phambili ngo-1.
        // Kuthuthukisa kakhulu ukusebenza kuqhathaniswa nomsebenzi ofakwe ngaphakathi.
        // I-iterator akumele ingabi nalutho.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Ibuyisa into yokugcina bese ihambisa ukuphela kwe-iterator emuva nge-1.
        // Kuthuthukisa kakhulu ukusebenza kuqhathaniswa nomsebenzi ofakwe ngaphakathi.
        // I-iterator akumele ingabi nalutho.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Nciphisa i-iterator lapho i-T iyi-ZST, ngokuhambisa ukuphela kwe-iterator emuva nge-`n`.
        // `n` akumele yeqe i-`self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Umsebenzi Womsizi wokwakha isilayidi esivela ku-iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // UKUPHEPHA: i-iterator yadalwa kusuka kusilayidi esine-pointer
                // `self.ptr` nobude `len!(self)`.
                // Lokhu kuqinisekisa ukuthi zonke izimfuneko ze-`from_raw_parts` ziyagcwaliseka.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Umsebenzi Womsizi wokuhambisa ukuqala kwe-iterator phambili ngezinto ze-`offset`, kubuyisa isiqalo esidala.
            //
            // Akuphephile ngoba isethi ebekiwe akufanele yeqe i-`self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // UKUPHEPHA: ofonayo uqinisekisa ukuthi i-`offset` ayidluli i-`self.len()`,
                    // ngakho-ke lesi sikhombi esisha singaphakathi kwe `self` futhi ngaleyo ndlela siqinisekisiwe ukuthi asiyona-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Umsebenzi wosizi wokuhambisa ukuphela kwe-iterator emuva ngezinto ze-`offset`, kubuyiswe ukuphela okusha.
            //
            // Akuphephile ngoba isethi ebekiwe akufanele yeqe i-`self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // UKUPHEPHA: ofonayo uqinisekisa ukuthi i-`offset` ayidluli i-`self.len()`,
                    // okuqinisekisiwe ukuthi ayichichimi i `isize`.
                    // Futhi, i-pointer evelayo isemingceleni ye-`slice`, egcwalisa ezinye izidingo ze-`offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kungenziwa kusetshenziswe izingcezu, kepha lokhu kugwema ukubhekwa kwemingcele

                // UKUPHEPHA: Izingcingo ze-`assume` ziphephile kusukela kusikhombi sokuqala kocezu
                // kumele zingasebenzi, futhi izingcezu ezingaphezu kwama-ZSTs nazo kufanele zibe nesikhombi sokugcina esingeyona into.
                // Ucingo oluya ku-`next_unchecked!` luphephile ngoba sihlola ukuthi ngabe i-iterator ayinalutho yini kuqala.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Le iterator manje ayinalutho.
                    if mem::size_of::<T>() == 0 {
                        // Kufanele sikwenze ngale ndlela njengoba i `ptr` ingahle ingabi ngu-0, kepha i-`end` ingaba (ngenxa yokugoqa).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // UKUPHEPHA: ukuphela akunakuba ngu-0 uma i-T kungeyona i-ZST ngoba i-ptr ayisi-0 futhi iyaphela>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // UKUPHEPHA: Silinganiselwe.I-`post_inc_start` yenza okufanele ngisho nakuma-ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            // Futhi, i `assume` igwema isheke lemingcele.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // UKUPHEPHA: siqinisekisiwe ukuthi sizokuba semikhawulweni yi-loop invariant:
                        // lapho i-`i >= n`, i-`self.next()` ibuyisa i-`None` bese i-loop ikhefu.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Sibhala ngaphezulu ukusetshenziswa okuzenzakalelayo, okusebenzisa i `try_fold`, ngoba lokhu kusetshenziswa okulula kukhiqiza i-LLVM IR encane futhi kuyashesha ukuhlanganiswa.
            // Futhi, i `assume` igwema isheke lemingcele.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // UKUPHEPHA: I-`i` kufanele ibe ngaphansi kuka-`n` njengoba iqala ku-`n`
                        // futhi kuncipha kuphela.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`i` isemikhawulweni ye-
                // isilayidi esingaphansi, ngakho-ke i-`i` ayikwazi ukugcwala i-`isize`, futhi izinkomba ezibuyisiwe ziqinisekisiwe ukuthi zibhekisa entweni yesilayidi futhi ngaleyo ndlela kuqinisekiswe ukuthi ziyasebenza.
                //
                // Futhi qaphela ukuthi ofonayo uphinde aqinisekise ukuthi asikaze sibizwe ngenkomba efanayo futhi, nokuthi azikho ezinye izindlela ezizofinyelela kulokhu kubizwa ezibiziwe, ngakho-ke kuvumelekile ukuthi ireferensi ebuyisiwe iguquke esimweni se
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kungenziwa kusetshenziswe izingcezu, kepha lokhu kugwema ukubhekwa kwemingcele

                // UKUPHEPHA: Izingcingo ze-`assume` ziphephile ngoba isikhombisi sesiqeshana kufanele singasebenzi,
                // futhi izingcezu ngaphezulu kwama-non-ZSTs kufanele futhi zibe nesikhombi sokuphela okungekho null.
                // Ucingo oluya ku-`next_back_unchecked!` luphephile ngoba sihlola ukuthi ngabe i-iterator ayinalutho yini kuqala.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Le iterator manje ayinalutho.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // UKUPHEPHA: Silinganiselwe.I-`pre_dec_end` yenza okufanele ngisho nakuma-ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}