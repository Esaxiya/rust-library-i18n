// ignore-tidy-filelength

//! Ukuphathwa kwesilayidi nokukhohlisa.
//!
//! Ngemininingwane engaphezulu bona i [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ukuqaliswa kwememchr okumsulwa kwe rust, kuthathwe ku rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Lo msebenzi usesidlangalaleni kuphela ngoba ayikho enye indlela yokuthola i-unit test heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Ibuyisa inani lezinto kucezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // UKUPHEPHA: umsindo we-const ngoba sidlulisa inkambu yobude njengosayizi (okumele ngabe uyena)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // UKUPHEPHA: lokhu kuphephile ngoba i-`&[T]` ne-`FatPtr<T>` zinokuhlelwa okufanayo.
            // Yi-`std` kuphela engenza lesi siqinisekiso.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Faka esikhundleni se `crate::ptr::metadata(self)` lapho lokho kuzinzile.
            // Ngokuloba lokhu kubangela iphutha le-"Const-stable functions can only call other const-stable functions".
            //

            // UKUPHEPHA: Ukufinyelela inani elivela kwinyunyana ye `PtrRepr` kuphephile kusukela * const T
            // kanye ne-PtrComponents<T>unezakhiwo ezifanayo zememori.
            // std kuphela engenza lesi siqinisekiso.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Ibuyisa i-`true` uma isilayidi sinobude obungu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ibuyisa into yokuqala yesilayidi, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ibuyisa isikhombisi esiguquguqukayo entweni yokuqala yesilayidi, noma i-`None` uma singenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Ibuyisa eyokuqala nazo zonke ezinye izinto zesilayidi, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibuyisa eyokuqala nazo zonke ezinye izinto zesilayidi, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Ibuyisa okokugcina nazo zonke ezinye izinto zesilayidi, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibuyisa okokugcina nazo zonke ezinye izinto zesilayidi, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Ibuyisa into yokugcina yocezu, noma i-`None` uma ingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ibuyisa isikhombisi esiguquguqukayo entweni yokugcina kucezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Ibuyisa ireferensi entweni noma ekubhalisweni kuya ngohlobo lwenkomba.
    ///
    /// - Uma unikezwe isikhundla, ubuyisa ireferensi yento ekuleso sikhundla noma i-`None` uma ingekho emingceleni.
    ///
    /// - Uma unikezwe ibanga, ibuyisa okungaphansi okuhambelana nalawo banga, noma i-`None` uma ingekho emingceleni.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Ibuyisa ireferensi enokuguquguquka entweni noma ekubhalisweni kuya ngohlobo lwenkomba (bona i-[`get`]) noma i-`None` uma inkomba ingaphandle kwemingcele.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Ibuyisa ireferensi kwinto ethile noma ekubhaliseni, ngaphandle kokuhlola imingcele.
    ///
    /// Ngokuthola enye indawo ephephile bona i [`get`].
    ///
    /// # Safety
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele ngu *[undefined behaviour]* noma ngabe ireferensi evelayo ayisetshenziswanga.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // UKUPHEPHA: ofonayo kufanele agcine iningi lezidingo zokuphepha ze-`get_unchecked`;
        // isilayidi asikwazi ukukhishwa ngoba i `self` iyinkomba ephephile.
        // Isikhombi esibuyisiwe siphephile ngoba ama-impls we-`SliceIndex` kufanele aqinisekise ukuthi kunjalo.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Ibuyisa ireferensi enokuguquguquka entweni noma ekubhalisweni, ngaphandle kokuhlola imingcele.
    ///
    /// Ngokuthola enye indawo ephephile bona i [`get_mut`].
    ///
    /// # Safety
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele ngu *[undefined behaviour]* noma ngabe ireferensi evelayo ayisetshenziswanga.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // UKUPHEPHA: ofonayo kufanele agcine izidingo zokuphepha ze-`get_unchecked_mut`;
        // isilayidi asikwazi ukukhishwa ngoba i `self` iyinkomba ephephile.
        // Isikhombi esibuyisiwe siphephile ngoba ama-impls we-`SliceIndex` kufanele aqinisekise ukuthi kunjalo.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Ibuyisa isikhombi esiluhlaza kubha yesilayidi.
    ///
    /// Oshaya ucingo kufanele aqinisekise ukuthi ucezu ludlula isikhombisi kulo msebenzi, noma kungenjalo luzogcina lukhomba kudoti.
    ///
    /// Oshayayo kufanele futhi aqinisekise ukuthi imemori isikhombisi esikhomba kuyo u (non-transitively) asikaze sibhalelwe yona (ngaphandle kwangaphakathi kwe `UnsafeCell`) kusetshenziswa lesi sikhombi noma yisiphi isikhombi esisuselwe kuso.
    /// Uma udinga ukushintsha okuqukethwe kocezu, sebenzisa i [`as_mut_ptr`].
    ///
    /// Ukuguqula isitsha esiboniswe yilesi silayidi kungadala ukuthi i-buffer yaso iphinde yabiwa, okungenza noma yiziphi izikhombisi kuso kungasebenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Ibuyisa isikhombisi esingaphepheki esiguqulwa sesilayidi.
    ///
    /// Oshaya ucingo kufanele aqinisekise ukuthi ucezu ludlula isikhombisi kulo msebenzi, noma kungenjalo luzogcina lukhomba kudoti.
    ///
    /// Ukuguqula isitsha esiboniswe yilesi silayidi kungadala ukuthi i-buffer yaso iphinde yabiwa, okungenza noma yiziphi izikhombisi kuso kungasebenzi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Ibuyisa izikhombi ezimbili ezingavuthiwe eziwela ucezu.
    ///
    /// Ububanzi obubuyisiwe buvulwe uhhafu, okusho ukuthi isikhombi sokuphela sikhomba *okukodwa okudlule* into yokugcina yocezu.
    /// Ngale ndlela, ucezu olungenalutho lumelwe yizikhombi ezimbili ezilinganayo, futhi umehluko phakathi kwezikhombi ezimbili umele ubukhulu besilayidi.
    ///
    /// Bona i [`as_ptr`] ukuthola izexwayiso ngokusebenzisa lezi zikhombisi.Isikhombi sokugcina sidinga ukuqaphela okwengeziwe, ngoba asikhombisi entweni evumelekile kusilayidi.
    ///
    /// Lo msebenzi ulusizo ekuhlanganyeleni nokuhlangana kwangaphandle okusebenzisa izikhombisi ezimbili ukubhekisa kububanzi bezinto kumemori, njengoba kujwayelekile ku-C++ .
    ///
    ///
    /// Kungasiza futhi ukubheka ukuthi ngabe isikhombisi sento sibhekisa entweni yalesi silayidi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // UKUPHEPHA: I `add` lapha iphephile, ngoba:
        //
        //   - Zombili izikhombisi ziyingxenye yento efanayo, njengoba ukukhomba ngqo kudlule entweni nakho kuyabalwa.
        //
        //   - Usayizi wesilayidi awukaze ube mkhulu kune-isize::MAX byte, njengoba kuphawuliwe lapha:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Akukho ukugoqwa okuzungezile okubandakanyekile, njengoba izingcezu azisongeli kudlule ukuphela kwesikhala sekheli.
        //
        // Bona imibhalo ye pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ibuyisa izikhombisi ezimbili ezingaphephile ezingaguquguquka ezisika ucezu.
    ///
    /// Ububanzi obubuyisiwe buvulwe uhhafu, okusho ukuthi isikhombi sokuphela sikhomba *okukodwa okudlule* into yokugcina yocezu.
    /// Ngale ndlela, ucezu olungenalutho lumelwe yizikhombi ezimbili ezilinganayo, futhi umehluko phakathi kwezikhombi ezimbili umele ubukhulu besilayidi.
    ///
    /// Bona i [`as_mut_ptr`] ukuthola izexwayiso ngokusebenzisa lezi zikhombisi.
    /// Isikhombi sokugcina sidinga ukuqaphela okwengeziwe, ngoba asikhombisi entweni evumelekile kusilayidi.
    ///
    /// Lo msebenzi ulusizo ekuhlanganyeleni nokuhlangana kwangaphandle okusebenzisa izikhombisi ezimbili ukubhekisa kububanzi bezinto kumemori, njengoba kujwayelekile ku-C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // UKUPHEPHA: Bona i as_ptr_range() ngenhla ukuthi kungani i `add` lapha iphephile.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Ishintsha izinto ezimbili kucezu.
    ///
    /// # Arguments
    ///
    /// * a, Inkomba yento yokuqala
    /// * b, Inkomba yento yesibili
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`a` noma i-`b` ingaphandle kwemingcele.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Awukwazi ukuthatha izimalimboleko ezimbili eziguqukayo kusuka ku-vector eyodwa, ngakho-ke esikhundleni salokho sebenzisa izikhombisi ezingavuthiwe.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // UKUPHEPHA: I-`pa` ne-`pb` zidaliwe kusuka kuzinkomba eziphephile ezingaguquleka futhi zibhekiswe
        // kuzinto ezikulayidi ngakho-ke kuqinisekisiwe ukuthi zivumelekile futhi ziqondaniswe.
        // Qaphela ukuthi ukufinyelela kuzakhi ezingemuva kwe-`a` ne-`b` kuhlolwe futhi kuzokwenza i-panic uma ingekho emingceleni.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ibuyisa ukuhleleka kwezinto ezikucezu, endaweni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Ezinhlotsheni ezincane kakhulu, konke okufundwa ngabanye ngendlela ejwayelekile kwenza kabi.
        // Singenza kangcono, uma sinikezwe i-load/store esebenza kahle engaxhunywanga, ngokulayisha isinqamu esikhulu futhi sibuyisela emuva irejista.
        //

        // Ngokufanelekile i-LLVM izosenzela lokhu, njengoba yazi kangcono kunalokho esikwenzayo ukuthi ukufundwa okungahambelanisiwe kuyasebenza (ngoba lokho kuguquka phakathi kwezinhlobo ezahlukahlukene ze-ARM, ngokwesibonelo) nokuthi usayizi we-chunk ongcono kakhulu ungaba yini.
        // Ngeshwa, kusukela nge-LLVM 4.0 (2017-05) ivula kuphela iluphu, ngakho-ke nathi sidinga ukuzenzela lokhu.
        // (I-Hypothesis: i-reverse inenkinga ngoba izinhlangothi zingaqondaniswa ngokuhlukile-kuzoba njalo, lapho ubude bungajwayelekile-ngakho-ke ayikho indlela yokukhipha i-pre-ne-postludes yokusebenzisa i-SIMD eqondaniswe ngokuphelele phakathi.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Sebenzisa okungaphakathi kwe llvm.bswap ukuhlehlisa u8s kusayizi
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // UKUPHEPHA: Kunezinto eziningana ongazihlola lapha:
                //
                // - Qaphela ukuthi i-`chunk` ingaba ngu-4 noma u-8 ngenxa yesheke le-cfg elingenhla.Ngakho-ke i-`chunk - 1` iyakhanya.
                // - Ukukhomba nge-index `i` kulungile njengoba isheke le-loop liqinisekisa
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Ukukhomba nge-index `ln - i - chunk = ln - (i + chunk)` kulungile:
                //   - `i + chunk > 0` kuyiqiniso okuncane.
                //   - Ukuhlolwa kwe-loop kuqinisekisa:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ngakho-ke ukukhipha akuhambi.
                // - Izingcingo ze `read_unaligned` ne `write_unaligned` zilungile:
                //   - `pa` zikhomba kunkomba `i` lapho i-`i < ln / 2 - (chunk - 1)` (bheka ngenhla) nama-`pb` akhomba ku-index `ln - i - chunk`, ngakho-ke womabili okungenani angama-`chunk` amaningi amabhayithi kude nokuphela kwe `self`.
                //
                //   - Noma iyiphi imemori eqaliwe i-`usize` evumelekile.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Sebenzisa ukushintshanisa nge-16 ukubuyisela emuva ama-u16 ku-u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // UKUPHEPHA: I-u32 engafakwanga kahle ingafundwa kusuka ku-`i` uma i-`i + 1 < ln`
                // (futhi ngokusobala i-`i < ln`), ngoba into ngayinye ingamabhayithi ama-2 futhi sifunda u-4.
                //
                // `i + chunk - 1 < ln / 2` # ngenkathi isimo
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Njengoba ingaphansi kobude obuhlukaniswe u-2, khona-ke kufanele ibe semikhawulweni.
                //
                // Lokhu kusho nokuthi isimo `0 < i + chunk <= ln` sihlala sihlonishwa, kuqinisekiswa ukuthi isikhombisi se `pb` singasetshenziswa ngokuphepha.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // UKUPHEPHA: I-`i` ingaphansi kwengxenye yobude besilayi ngakho
            // ukufinyelela i-`i` ne-`ln - i - 1` kuphephile (i-`i` iqala ngo-0 futhi ngeke idlule kune-`ln / 2 - 1`).
            // Izinkomba eziholelekile i-`pa` ne-`pb` ngakho-ke zivumelekile futhi ziqondisiwe, futhi zingafundwa zisuka futhi zibhalelwe ku.
            //
            //
            unsafe {
                // Ukushintshana okungaphephile ukugwema ukubhekwa kwemingcele ekushintsheni okuphephile.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Ibuyisa i-iterator ngaphezulu kwesilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Ibuyisa i-iterator evumela ukuguqula inani ngalinye.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Ibuyisa i-iterator phezu kwayo yonke i-windows yobude be-`size`.
    /// Ukugqagqana kwe windows.
    /// Uma isilayidi sifushane kune-`size`, i-iterator ayibuyisi amanani.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Uma isilayidi sifushane kune-`size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Izihlanganisi ziyizigaxa futhi azihambelani.Uma i-`chunk_size` ingahlukanisi ubude besilayidi, i-chunk yokugcina ngeke ibe nobude be-`chunk_size`.
    ///
    /// Bona i [`chunks_exact`] ngokuhluka kwalesi iterator esibuyisa izigaxa zezinto ezingama-`chunk_size` njalo, ne-[`rchunks`] nge-iterator efanayo kepha kuqala ekugcineni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Ama-chunks ayizigaxa eziguquguqukayo, futhi azihambelani.Uma i-`chunk_size` ingahlukanisi ubude besilayidi, i-chunk yokugcina ngeke ibe nobude be-`chunk_size`.
    ///
    /// Bona i [`chunks_exact_mut`] ngokuhluka kwalesi iterator esibuyisa izigaxa zezinto ezingama-`chunk_size` njalo, ne-[`rchunks_mut`] nge-iterator efanayo kepha kuqala ekugcineni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Izihlanganisi ziyizigaxa futhi azihambelani.
    /// Uma i-`chunk_size` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`chunk_size-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`remainder` we-iterator.
    ///
    ///
    /// Ngenxa yesigaxa ngasinye esinezinto ze-`chunk_size` ngqo, umhlanganisi uvame ukwengeza ikhodi eliphumayo kangcono kunase [`chunks`].
    ///
    /// Bona i-[`chunks`] ngokuhluka kwalesi iterator esibuyisa okusele njenge-chunk encane, ne-[`rchunks_exact`] nge-iterator efanayo kepha kuqala ekugcineni kocezu.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Ama-chunks ayizigaxa eziguquguqukayo, futhi azihambelani.
    /// Uma i-`chunk_size` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`chunk_size-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`into_remainder` we-iterator.
    ///
    ///
    /// Ngenxa yesigaxa ngasinye esinezinto ze-`chunk_size` ngqo, umhlanganisi uvame ukwengeza ikhodi eliphumayo kangcono kunase [`chunks_mut`].
    ///
    /// Bona i-[`chunks_mut`] ngokuhluka kwalesi iterator esibuyisa okusele njenge-chunk encane, ne-[`rchunks_exact_mut`] nge-iterator efanayo kepha kuqala ekugcineni kocezu.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Ihlukanisa isilayidi kucezu lwe-`N`-element arrays, kucatshangwa ukuthi akukho okusele.
    ///
    ///
    /// # Safety
    ///
    /// Lokhu kungabizwa kuphela nini
    /// - Isilayidi sihlukana ngqo ku-`N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // UKUPHEPHA: Izihlanganisi zezinto ezi-1 azikaze zibe nokusele
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // UKUPHEPHA: Ubude besilayidi i-(6) buphindaphindwa ngo-3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Lokhu kungaba okungenangqondo:
    /// // ake iziqu: &[[_ _;5]]= slice.as_chunks_unchecked()//Ubude besilayidi abukona ukuphindaphindwa kwezi-5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//Zero length chunks are never allowed
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // UKUPHEPHA: Isandulela sethu yilokho kanye okudingekayo ukubiza lokhu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // UKUPHEPHA: Siphonsa ucezu lwezinto ze-`new_len * N` ku
        // ucezu lwama-`new_len` ama-`N` wezinto eziningi.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Sahlukanisa isilayidi kucezu lwe-`N`-element arrays, kuqala ekuqaleni kocezu, nocezu olusele olunobude ngaphansi kwe-`N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // UKUPHEPHA: Besivele sishaywe uvalo ngoziro, futhi saqinisekisa ngokwakhiwa
        // ukuthi ubude be-subslice buningi be-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Sihlukanisa isilayidi kucezu lwama-elementi we-`N`-element, kuqala ekugcineni kocezu, nocezu lwensali esele ngobude bungaphansi kakhulu kwe-`N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // UKUPHEPHA: Besivele sishaywe uvalo ngoziro, futhi saqinisekisa ngokwakhiwa
        // ukuthi ubude be-subslice buningi be-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`N` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Ama-chunks ayizethenjwa ezihlelekile futhi awahambelani.
    /// Uma i-`N` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`N-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`remainder` we-iterator.
    ///
    ///
    /// Le ndlela yi-const generic elingana ne-[`chunks_exact`].
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Ihlukanisa isilayidi kucezu lwe-`N`-element arrays, kucatshangwa ukuthi akukho okusele.
    ///
    ///
    /// # Safety
    ///
    /// Lokhu kungabizwa kuphela nini
    /// - Isilayidi sihlukana ngqo ku-`N`-element chunks (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // UKUPHEPHA: Izihlanganisi zezinto ezi-1 azikaze zibe nokusele
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // UKUPHEPHA: Ubude besilayidi i-(6) buphindaphindwa ngo-3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Lokhu kungaba okungenangqondo:
    /// // ake iziqu: &[[_ _;5]]= slice.as_chunks_unchecked_mut()//Ubude besilayidi abukona ukuphindaphindwa kwezi-5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//Zero length chunks are never allowed
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // UKUPHEPHA: Isandulela sethu yilokho kanye okudingekayo ukubiza lokhu
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // UKUPHEPHA: Siphonsa ucezu lwezinto ze-`new_len * N` ku
        // ucezu lwama-`new_len` ama-`N` wezinto eziningi.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Sahlukanisa isilayidi kucezu lwe-`N`-element arrays, kuqala ekuqaleni kocezu, nocezu olusele olunobude ngaphansi kwe-`N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // UKUPHEPHA: Besivele sishaywe uvalo ngoziro, futhi saqinisekisa ngokwakhiwa
        // ukuthi ubude be-subslice buningi be-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Sihlukanisa isilayidi kucezu lwama-elementi we-`N`-element, kuqala ekugcineni kocezu, nocezu lwensali esele ngobude bungaphansi kakhulu kwe-`N`.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // UKUPHEPHA: Besivele sishaywe uvalo ngoziro, futhi saqinisekisa ngokwakhiwa
        // ukuthi ubude be-subslice buningi be-N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`N` zesilayidi ngasikhathi, kuqala ekuqaleni kocezu.
    ///
    /// Ama-chunks ayizethenjwa ezihlelekile eziguquguqukayo futhi azihambelani.
    /// Uma i-`N` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`N-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`into_remainder` we-iterator.
    ///
    ///
    /// Le ndlela yi-const generic elingana ne-[`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0. Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganisa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Ibuyisa i-iterator eyeqa ngaphezulu kwe-windows yezakhi ze-`N` zocezu, kuqala ekuqaleni kocezu.
    ///
    ///
    /// Lokhu kulingana okufana no-[`windows`].
    ///
    /// Uma i-`N` inkulu kunosayizi wesilayidi, ngeke ibuyise i windows.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`N` ingu-0.
    /// Leli sheke cishe lizoguqulwa libe yiphutha lesikhathi sokuhlanganiswa ngaphambi kokuba le ndlela iqiniswe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekugcineni kocezu.
    ///
    /// Izihlanganisi ziyizigaxa futhi azihambelani.Uma i-`chunk_size` ingahlukanisi ubude besilayidi, i-chunk yokugcina ngeke ibe nobude be-`chunk_size`.
    ///
    /// Bona i [`rchunks_exact`] ngokuhluka kwalesi iterator esibuyisa izigaxa zezinto ezingama-`chunk_size` njalo, ne-[`chunks`] nge-iterator efanayo kepha kuqala ekuqaleni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekugcineni kocezu.
    ///
    /// Ama-chunks ayizigaxa eziguquguqukayo, futhi azihambelani.Uma i-`chunk_size` ingahlukanisi ubude besilayidi, i-chunk yokugcina ngeke ibe nobude be-`chunk_size`.
    ///
    /// Bona i [`rchunks_exact_mut`] ngokuhluka kwalesi iterator esibuyisa izigaxa zezinto ezingama-`chunk_size` njalo, ne-[`chunks_mut`] nge-iterator efanayo kepha kuqala ekuqaleni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekugcineni kocezu.
    ///
    /// Izihlanganisi ziyizigaxa futhi azihambelani.
    /// Uma i-`chunk_size` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`chunk_size-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`remainder` we-iterator.
    ///
    /// Ngenxa yesigaxa ngasinye esinezinto ze-`chunk_size` ngqo, umhlanganisi uvame ukwengeza ikhodi eliphumayo kangcono kunase [`chunks`].
    ///
    /// Bona i-[`rchunks`] ngokuhluka kwalesi iterator esibuyisa okusele njenge-chunk encane, ne-[`chunks_exact`] nge-iterator efanayo kepha kuqala ekuqaleni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinto ze-`chunk_size` zesilayidi ngasikhathi, kuqala ekugcineni kocezu.
    ///
    /// Ama-chunks ayizigaxa eziguquguqukayo, futhi azihambelani.
    /// Uma i-`chunk_size` ingahlukanisi ubude besilayidi, khona-ke izinto zokugcina ezifika ku-`chunk_size-1` zizokhishwa futhi zingabuyiselwa emsebenzini we-`into_remainder` we-iterator.
    ///
    /// Ngenxa yesigaxa ngasinye esinezinto ze-`chunk_size` ngqo, umhlanganisi uvame ukwengeza ikhodi eliphumayo kangcono kunase [`chunks_mut`].
    ///
    /// Bona i-[`rchunks_mut`] ngokuhluka kwalesi iterator esibuyisa okusele njenge-chunk encane, ne-[`chunks_exact_mut`] nge-iterator efanayo kepha kuqala ekuqaleni kocezu.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`chunk_size` ingu-0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Ibuyisa i-iterator ngaphezulu kwesilayidi esikhiqiza ukugijima okungagudluki kwezinto kusetshenziswa isilandiso ukuzehlukanisa.
    ///
    /// Isilandiso sibizwa ngezinto ezimbili ezizilandelayo, kusho ukuthi isilandiso sibizwa ngo-`slice[0]` no-`slice[1]` bese kuthi ku-`slice[1]` naku-`slice[2]` njalo njalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Le ndlela ingasetshenziselwa ukukhipha izinhlinzeko ezihleliwe:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwesilayidi esikhiqiza izinto ezingagudluki ezingaguquguquki zezinto zisebenzisa isilandiso ukuzehlukanisa.
    ///
    /// Isilandiso sibizwa ngezinto ezimbili ezizilandelayo, kusho ukuthi isilandiso sibizwa ngo-`slice[0]` no-`slice[1]` bese kuthi ku-`slice[1]` naku-`slice[2]` njalo njalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Le ndlela ingasetshenziselwa ukukhipha izinhlinzeko ezihleliwe:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Hlukanisa ucezu olulodwa lube kabili enkombeni.
    ///
    /// Owokuqala uzoqukatha wonke ama-indices kusuka ku-`[0, mid)` (ngaphandle kwenkomba i-`mid` uqobo) kuthi eyesibili izoqukatha wonke ama-indices kusuka ku-`[mid, len)` (ngaphandle kwenkomba i-`len` uqobo).
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // UKUPHEPHA: I-`[ptr; mid]` ne-`[mid; len]` zingaphakathi kwe `self`, okuyi
        // igcwalisa izidingo ze-`from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Ihlukanisa isigaxa esisodwa esiguqukayo sibe kabili enkombeni.
    ///
    /// Owokuqala uzoqukatha wonke ama-indices kusuka ku-`[0, mid)` (ngaphandle kwenkomba i-`mid` uqobo) kuthi eyesibili izoqukatha wonke ama-indices kusuka ku-`[mid, len)` (ngaphandle kwenkomba i-`len` uqobo).
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // UKUPHEPHA: I-`[ptr; mid]` ne-`[mid; len]` zingaphakathi kwe `self`, okuyi
        // igcwalisa izidingo ze-`from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Ihlukanisa ucezu olulodwa lube kabili enkombeni, ngaphandle kokubheka imingcele.
    ///
    /// Owokuqala uzoqukatha wonke ama-indices kusuka ku-`[0, mid)` (ngaphandle kwenkomba i-`mid` uqobo) kuthi eyesibili izoqukatha wonke ama-indices kusuka ku-`[mid, len)` (ngaphandle kwenkomba i-`len` uqobo).
    ///
    ///
    /// Ngokuthola enye indawo ephephile bona i [`split_at`].
    ///
    /// # Safety
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele ngu *[undefined behaviour]* noma ngabe ireferensi evelayo ayisetshenziswanga.Oshaya ucingo kufanele aqinisekise ukuthi i `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // UKUPHEPHA: Oshaya ucingo kufanele ahlole ukuthi i `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Ihlukanisa isigaxa esisodwa esiguqukayo sibe kabili enkombeni, ngaphandle kokubheka imingcele.
    ///
    /// Owokuqala uzoqukatha wonke ama-indices kusuka ku-`[0, mid)` (ngaphandle kwenkomba i-`mid` uqobo) kuthi eyesibili izoqukatha wonke ama-indices kusuka ku-`[mid, len)` (ngaphandle kwenkomba i-`len` uqobo).
    ///
    ///
    /// Ngokuthola enye indawo ephephile bona i [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Ukushayela le ndlela ngenkomba engaphandle kwemingcele ngu *[undefined behaviour]* noma ngabe ireferensi evelayo ayisetshenziswanga.Oshaya ucingo kufanele aqinisekise ukuthi i `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // UKUPHEPHA: Oshaya ucingo kufanele ahlole ukuthi i `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` futhi i-`[mid; len]` ayigqagqelani, ngakho-ke ukubuyisa ireferensi engaguquguqukayo kulungile.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred`.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Uma into yokuqala ifaniswe, isilayidi esingenalutho sizoba yinto yokuqala ebuyiswa yi-iterator.
    /// Ngokufanayo, uma into yokugcina kucezu ifaniswe, isilayidi esingenalutho sizoba yinto yokugcina ebuyiswe i-iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Uma izinto ezimbili ezihambisanayo zisondele ngqo, kuzobe kukhona ucezu olungenalutho phakathi kwabo:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kokungaguquguquki okuguqukayo okuhlukaniswe ngezinto ezifana ne-`pred`.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred`.
    /// Into ehambisanayo iqukethwe ekugcineni kwe-subslice yangaphambilini njenge-terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Uma into yokugcina yocezu ifanisiwe, leyo nto izobhekwa njengesinqamuli sesilayidi esandulele.
    ///
    /// Leyo ngcezu kuzoba yinto yokugcina ebuyiswe yi-iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kokungaguquguquki okuguqukayo okuhlukaniswe ngezinto ezifana ne-`pred`.
    /// Into efanisiwe iqukethwe kokungaphansi okwedlule njengesinqamuli.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwezinhlawulo ezihlukaniswe ngezinto ezifana ne-`pred`, eziqala ekugcineni kwesilayidi bese zisebenza emuva.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njengaku-`split()`, uma into yokuqala noma yokugcina ifaniswe, isilayidi esingenalutho sizoba yinto yokuqala (noma yokugcina) ebuyiswe yi-iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kokungaguquguquki okuguqukayo okuhlukaniswe ngezinto ezifana ne-`pred`, kuqala ekugcineni kocezu futhi kusebenze emuva.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred`, kukhawulelwe ekubuyiseleni kakhulu izinto eziyi-`n`.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// Into yokugcina ebuyisiwe, uma ikhona, izoqukatha okusele kocezu.
    ///
    /// # Examples
    ///
    /// Phrinta ucezu oluhlukaniswe kanye ngezinombolo ezihlukaniswa ngo-3 (ie, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred`, kukhawulelwe ekubuyiseleni kakhulu izinto eziyi-`n`.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// Into yokugcina ebuyisiwe, uma ikhona, izoqukatha okusele kocezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred` enqunyelwe ekubuyiseleni kakhulu izinto eziyi-`n`.
    /// Lokhu kuqala ekugcineni kocezu futhi kusebenza emuva.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// Into yokugcina ebuyisiwe, uma ikhona, izoqukatha okusele kocezu.
    ///
    /// # Examples
    ///
    /// Phrinta uqhekeko lwesilayidi kanye, uqale ekugcineni, ngezinombolo ezihlukaniswa ngo-3 (ie, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Ibuyisa i-iterator ngaphezulu kwemibhalo ehlukaniswe yizinto ezifana ne-`pred` enqunyelwe ekubuyiseleni kakhulu izinto eziyi-`n`.
    /// Lokhu kuqala ekugcineni kocezu futhi kusebenza emuva.
    /// Into efanisiwe ayiqukethwe kokungaphansi.
    ///
    /// Into yokugcina ebuyisiwe, uma ikhona, izoqukatha okusele kocezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Ibuyisa i-`true` uma isilayidi siqukethe into enenani elinikeziwe.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Uma ungenayo i-`&T`, kepha une-`&U` nje ukuthi i-`T: Borrow<U>` (isb
    /// Intambo: Boleka<str>`), ungasebenzisa i-`iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ucezu lwe `String`
    /// assert!(v.iter().any(|e| e == "hello")); // sesha nge `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Ibuyisa i-`true` uma i-`needle` isiqalo socezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Ihlala ibuyisa i `true` uma i-`needle` isilayidi esingenalutho:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Ibuyisa i-`true` uma i-`needle` iyisijobelelo sesilayidi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Ihlala ibuyisa i `true` uma i-`needle` isilayidi esingenalutho:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Ibuyisa okukhokhelwayo kususwe isiqalo.
    ///
    /// Uma isilayidi siqala ngo-`prefix`, sibuyisa okulandelayo ngemuva kwesiqalo, sisongwe nge-`Some`.
    /// Uma i-`prefix` ingenalutho, mane ubuyise isilayidi sokuqala.
    ///
    /// Uma ucezu lungaqali nge-`prefix`, lubuyisa i-`None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Lo msebenzi uzodinga ukubhala kabusha uma futhi lapho iSlicePattern iba yinkimbinkimbi ngokwengeziwe.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Ibuyisa okukhokhelwayo okususwe isijobelelo.
    ///
    /// Uma isilayidi sigcina ngo-`suffix`, sibuyisa isijeziso ngaphambi kwesijobelelo, sisongwe nge-`Some`.
    /// Uma i-`suffix` ingenalutho, mane ubuyise isilayidi sokuqala.
    ///
    /// Uma ucezu lungapheli ngo-`suffix`, lubuyisa i-`None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Lo msebenzi uzodinga ukubhala kabusha uma futhi lapho iSlicePattern iba yinkimbinkimbi ngokwengeziwe.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// I-Binary isesha lesi silayidi esihleliwe ngento ethile.
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.
    /// Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    ///
    /// Bheka futhi i [`binary_search_by`], [`binary_search_by_key`], ne [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine.
    /// Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Uma ufuna ukufaka into ku-vector ehleliwe, ngenkathi ugcina i-oda lokuhlunga:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// I-Binary isesha lesi silayidi esihleliwe ngomsebenzi wokuqhathanisa.
    ///
    /// Umsebenzi wokuqhathanisa kufanele usebenzise i-oda elihambisana nokuhleleka kocezu olungaphansi, kubuyiswe ikhodi ye-oda ekhombisa ukuthi impikiswano yayo iyi-`Less`, `Equal` noma i-`Greater` ilitshe olifunayo.
    ///
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    /// Bheka futhi i [`binary_search`], [`binary_search_by_key`], ne [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine.Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // UKUPHEPHA: ucingo lwenziwa luphephe ngabahlaseli abalandelayo:
            // - `mid >= 0`
            // - `mid < size`: I-`mid` inqunyelwe yi-`[left; right)` eboshiwe.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Isizathu esenza sisebenzise ukugeleza kokulawulwa kwe-if/else kunokufanisa kungenxa yokuthi imisebenzi yokuqhathanisa ukuqondiswa kabusha komdlalo, ebucayi kakhulu.
            //
            // Le yi-x86 asm ye u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// I-Binary isesha lesi silayidi esihleliwe ngomsebenzi wokhiye wokukhipha.
    ///
    /// Kuthathwa ukuthi ucezu luhlungwe ngokhiye, ngokwesibonelo nge-[`sort_by_key`] kusetshenziswa umsebenzi ofanayo wokukhipha ukhiye.
    ///
    /// Uma inani litholakala bese i-[`Result::Ok`] ibuyiselwa, equkethe inkomba yento efanayo.
    /// Uma kunokufana okuningi, khona-ke noma yikuphi okunye okufanayo kungabuyiselwa.
    /// Uma inani lingatholakali i-[`Result::Err`] iyabuyiselwa, iqukethe inkomba lapho into efanayo ingafakwa khona ngenkathi kugcinwa ukuhleleka okuhleliwe.
    ///
    ///
    /// Bheka futhi i [`binary_search`], [`binary_search_by`], ne [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Ibheka uchungechunge lwezinto ezine kocezwana lwamabhangqa ahlelwe ngezinto zawo zesibili.
    /// Eyokuqala itholakala, inesikhundla esinqunyelwe ngokukhethekile;owesibili nowesithathu abatholakali;owesine angafanisa noma yisiphi isikhundla ku-`[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // I-Lint rustdoc::broken_intra_doc_links ivunyelwe njengoba i-`slice::sort_by_key` iku crate `alloc`, futhi ngenxa yalokho ayikho okwamanje lapho kwakhiwa i `core`.
    //
    // izixhumanisi ezisezansi kwe crate: #74481.Njengoba ama-primitives abhalwe kuphela ku-libstd (#73423), lokhu akusoze kwaholela ekuxhumaneni okuphukile ekusebenzeni.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ihlunga isilayidi, kepha kungenzeka ingalondolozi ukuhleleka kwezinto ezilinganayo.
    ///
    /// Lolu hlobo aluzinzile (okungukuthi, lungahlela kabusha izinto ezilinganayo), endaweni (okungukuthi, alunikeli), futhi *O*(*n*\*log(* n*)) icala elibi kakhulu.
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa ku-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, ohlanganisa icala elisheshayo lesilinganiso se-quicksort engahleliwe necala elisheshayo elibi kakhulu le-heapsort, ngenkathi kufinyelelwa isikhathi somugqa ezincekeni ezinamaphethini athile.
    /// Isebenzisa ukungahleliwe okuthile ukuvikela amacala okonakala, kepha nge-seed engaguquki ukuhlinzeka njalo ngokuziphatha kokunquma.
    ///
    /// Ngokuvamile kushesha kunokuhlunga okuzinzile, ngaphandle kwamacala ambalwa akhethekile, isb., Lapho ucezu luqukethe ukulandelana okuhleliwe okuhlanganisiwe okuningana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ihlunga isilayidi ngomsebenzi wokuqhathanisa, kepha kungenzeka ingalondolozi ukuhleleka kwezinto ezilinganayo.
    ///
    /// Lolu hlobo aluzinzile (okungukuthi, lungahlela kabusha izinto ezilinganayo), endaweni (okungukuthi, alunikeli), futhi *O*(*n*\*log(* n*)) icala elibi kakhulu.
    ///
    /// Umsebenzi wokuqhathanisa kufanele uchaze uku-oda okuphelele kwezinto kusilayidi.Uma uku-oda kungaphelele, ukuhleleka kwezinto akucacisiwe.I-oda li-oda eliphelele uma likhona (lazo zonke i-`a`, `b` ne-`c`):
    ///
    /// * total and antisymmetric: ncamashi eyodwa ye `a < b`, `a == b` noma i `a > b` iyiqiniso, futhi
    /// * okuguqukayo, i-`a < b` ne-`b < c` kusho i-`a < c`.Okufanayo kufanele kubambe kokubili i-`==` ne-`>`.
    ///
    /// Isibonelo, ngenkathi i-[`f64`] ingasebenzisi i-[`Ord`] ngoba i-`NaN != NaN`, singasebenzisa i-`partial_cmp` njengomsebenzi wethu wokuhlunga lapho sazi ukuthi ucezu alunayo i-`NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa ku-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, ohlanganisa icala elisheshayo lesilinganiso se-quicksort engahleliwe necala elisheshayo elibi kakhulu le-heapsort, ngenkathi kufinyelelwa isikhathi somugqa ezincekeni ezinamaphethini athile.
    /// Isebenzisa ukungahleliwe okuthile ukuvikela amacala okonakala, kepha nge-seed engaguquki ukuhlinzeka njalo ngokuziphatha kokunquma.
    ///
    /// Ngokuvamile kushesha kunokuhlunga okuzinzile, ngaphandle kwamacala ambalwa akhethekile, isb., Lapho ucezu luqukethe ukulandelana okuhleliwe okuhlanganisiwe okuningana.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ukuhlunga okuphambene
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ihlunga isilayidi ngomsebenzi wokhiye wokukhipha, kepha kungenzeka ingalondolozi ukuhleleka kwezinto ezilinganayo.
    ///
    /// Lolu hlobo aluzinzile (okungukuthi, lungahlela kabusha izinto ezilinganayo), endaweni (okungukuthi, alunikeli), futhi *O*(m\* * n *\* log(*n*)) icala elibi kakhulu, lapho umsebenzi obalulekile kungu *O*(*m*).
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa ku-[pattern-defeating quicksort][pdqsort] ngu-Orson Peters, ohlanganisa icala elisheshayo lesilinganiso se-quicksort engahleliwe necala elisheshayo elibi kakhulu le-heapsort, ngenkathi kufinyelelwa isikhathi somugqa ezincekeni ezinamaphethini athile.
    /// Isebenzisa ukungahleliwe okuthile ukuvikela amacala okonakala, kepha nge-seed engaguquki ukuhlinzeka njalo ngokuziphatha kokunquma.
    ///
    /// Ngenxa yecebo layo lokhiye lokushaya, i [`sort_unstable_by_key`](#method.sort_unstable_by_key) kungenzeka yehle kancane kune-[`sort_by_cached_key`](#method.sort_by_cached_key) ezimweni lapho umsebenzi wokhiye ubiza.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Hlela kabusha ucezu ngendlela yokuthi into eku-`index` isendaweni yayo yokugcina ihlelwe.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Hlela kabusha isilayidi ngomsebenzi wokuqhathanisa ukuze into eku-`index` isendaweni yayo yokugcina ihlelwe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Hlela kabusha ucezu ngomsebenzi wokhiye wokukhipha onjengokuthi into eku-`index` isendaweni yayo yokugcina ehleliwe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Hlela kabusha ucezu ngendlela yokuthi into eku-`index` isendaweni yayo yokugcina ihlelwe.
    ///
    /// Lokhu kuhlelwa kabusha kunesakhiwo esingeziwe sokuthi noma iliphi inani elisesikhundleni esingu-`i < index` lizoba ngaphansi noma lilingane nanoma yiliphi inani endaweni engu-`j > index`.
    /// Ngokwengeziwe, lokhu kuhlela kabusha akuzinzile (isb
    /// noma yiliphi inani lezinto ezilinganayo lingagcina lisesikhundleni `index`), endaweni (isb
    /// ayabi), futhi *O*(*n*) icala elibi kakhulu.
    /// Lo msebenzi waziwa futhi njenge-"kth element" kweminye imitapo yolwazi.
    /// Ibuyisa i-triplet yamanani alandelayo: zonke izinto ezingaphansi kwaleyo yenkomba enikeziwe, inani enkombeni enikeziwe, nazo zonke izinto ezinkulu kunezinye kunkomba enikeziwe.
    ///
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa engxenyeni esheshayo yokukhetha ye-algorithm efanayo ye-quicksort esetshenziselwa i-[`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// I-Panics lapho i-`index >= len()`, okusho ukuthi ihlale iyi-panics ezingxenyeni ezingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Thola ophakathi
    /// v.select_nth_unstable(2);
    ///
    /// // Siqinisekiswe kuphela ukuthi isilayidi sizoba ngokulandelayo, ngokususelwa endleleni esihlela ngayo inkomba ebekiwe.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Hlela kabusha isilayidi ngomsebenzi wokuqhathanisa ukuze into eku-`index` isendaweni yayo yokugcina ihlelwe.
    ///
    /// Lokhu kuhlela kabusha kunesakhiwo esingeziwe sokuthi noma iliphi inani elisesikhundleni esingu-`i < index` lizoba ngaphansi noma lilingane nanoma yiliphi inani endaweni engu-`j > index` kusetshenziswa umsebenzi wokuqhathanisa.
    /// Ngokwengeziwe, lokhu ku-oda kabusha akuzinzile (isb. Noma iliphi inani lezinto ezilinganayo lingagcina lisesikhundleni `index`), endaweni (okusho ukuthi ayinikezi), kanye necala elibi kakhulu elithi *O*(*n*).
    /// Lo msebenzi waziwa nangokuthi yi-"kth element" kweminye imitapo yolwazi.
    /// Ibuyisa i-triplet yamanani alandelayo: zonke izinto ezingaphansi kwaleyo yenkomba enikeziwe, inani enkombeni enikeziwe, nazo zonke izinto ezinkulu kunezinye kunkomba enikeziwe, kusetshenziswa umsebenzi onikeziwe wokuqhathanisa.
    ///
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa engxenyeni esheshayo yokukhetha ye-algorithm efanayo ye-quicksort esetshenziselwa i-[`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// I-Panics lapho i-`index >= len()`, okusho ukuthi ihlale iyi-panics ezingxenyeni ezingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Thola ophakathi sengathi ucezu luhlelwe ngokulandelana.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Siqinisekiswe kuphela ukuthi isilayidi sizoba ngokulandelayo, ngokususelwa endleleni esihlela ngayo inkomba ebekiwe.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Hlela kabusha ucezu ngomsebenzi wokhiye wokukhipha onjengokuthi into eku-`index` isendaweni yayo yokugcina ehleliwe.
    ///
    /// Lokhu ku-oda kabusha kunempahla eyengeziwe yokuthi noma iliphi inani elisesikhundleni `i < index` lizoba ngaphansi noma lilingane nanoma yiliphi inani endaweni engu-`j > index` kusetshenziswa umsebenzi wokhiye wokukhipha.
    /// Ngokwengeziwe, lokhu ku-oda kabusha akuzinzile (isb. Noma iliphi inani lezinto ezilinganayo lingagcina lisesikhundleni `index`), endaweni (okusho ukuthi ayinikezi), kanye necala elibi kakhulu elithi *O*(*n*).
    /// Lo msebenzi waziwa nangokuthi yi-"kth element" kweminye imitapo yolwazi.
    /// Ibuyisa i-triplet yamanani alandelayo: zonke izinto ezingaphansi kwaleyo yenkomba enikeziwe, inani enkombeni enikeziwe, nazo zonke izinto ezinkulu kunezinye kunkomba enikeziwe, kusetshenziswa umsebenzi wokukhipha ukhiye onikeziwe.
    ///
    ///
    /// # Ukuqaliswa kwamanje
    ///
    /// I-algorithm yamanje isuselwa engxenyeni esheshayo yokukhetha ye-algorithm efanayo ye-quicksort esetshenziselwa i-[`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// I-Panics lapho i-`index >= len()`, okusho ukuthi ihlale iyi-panics ezingxenyeni ezingenalutho.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Buyisa imedian kube sengathi uhlu luhlelwe ngokwenani eliphelele.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Siqinisekiswe kuphela ukuthi isilayidi sizoba ngokulandelayo, ngokususelwa endleleni esihlela ngayo inkomba ebekiwe.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Ihambisa zonke izinto eziphindaphindekayo zilandelana ziye ekugcineni kocezu ngokusho kwe-[`PartialEq`] trait.
    ///
    ///
    /// Ibuyisa izingcezu ezimbili.Eyokuqala ayiqukethe izinto eziphindaphindekayo ezilandelanayo.
    /// Owesibili uqukethe zonke izimpinda ngaphandle kwe-oda ebekiwe.
    ///
    /// Uma ucezu luhlungwe, ucezu olubuyisiwe lokuqala alunazo izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Ihambisa konke ngaphandle kokuqala kwezinto ezilandelanayo kuye ekugcineni kocezu kwanelisa ubudlelwano bokulingana obunikeziwe.
    ///
    /// Ibuyisa izingcezu ezimbili.Eyokuqala ayiqukethe izinto eziphindaphindekayo ezilandelanayo.
    /// Owesibili uqukethe zonke izimpinda ngaphandle kwe-oda ebekiwe.
    ///
    /// Umsebenzi we-`same_bucket` udluliselwe izinkomba ezintweni ezimbili ezivela kucezu futhi kufanele unqume ukuthi ngabe izinto ziqhathanisa ukulingana.
    /// Izinto zidluliswa ngokulandelana okuphambene kusuka ku-oda lazo kucezu, ngakho-ke uma i-`same_bucket(a, b)` ibuyisa i-`true`, i-`a` ihanjiswa ekugcineni kocezu.
    ///
    ///
    /// Uma ucezu luhlungwe, ucezu olubuyisiwe lokuqala alunazo izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Yize sinesethenjwa esiguquguqukayo ku-`self`, asikwazi ukwenza ushintsho *lokuphikisana*.Izingcingo ze-`same_bucket` zingaba yi-panic, ngakho-ke kufanele siqinisekise ukuthi ucezu lusesimweni esivumelekile ngaso sonke isikhathi.
        //
        // Indlela esiphatha ngayo lokhu ukusebenzisa ukushintshana;sihlikihla phezu kwazo zonke izakhi, sishintsha njengoba sihamba ukuze ekugcineni izinto esifisa ukuzigcina ziphambili, kuthi labo esifisa ukubenqaba bangasemuva.
        // Ngemuva kwalokho singahlukanisa ucezu.
        // Lo msebenzi kuseseyi-`O(n)`.
        //
        // Isibonelo: Siqala kulesi simo, lapho i-`r` imele "ngokulandelayo
        // funda "futhi i-`w` imele" okulandelayo_kubhala`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Ukuqhathanisa i-self[r] ngokumelene ne-self [w-1], lokhu akuyona impinda, ngakho-ke sishintsha i-self[r] ne-self[w] (akunamthelela njengo-r==w) bese sikhuphula u-r no-w, kusishiya no:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Uma kuqhathaniswa i-self[r] ne-self [w-1], leli nani liyimpinda, ngakho-ke sikhuphula i-`r` kepha sishiya konke okunye kungashintshiwe:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Ukuqhathanisa i-self[r] ngokumelene ne-self [w-1], lokhu akuyona impinda, ngakho-ke shintsha i-self[r] ne-self[w] bese uqhubekela phambili u-r no-w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Akuyona impinda, phinda:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Impinda, i-advance r. End yesilayidi.Hlukanisa ku-w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // UKUPHEPHA: isimo se-`while` siqinisekisa i-`next_read` ne-`next_write`
        // angaphansi kuka-`len`, ngakho-ke angaphakathi kwe `self`.
        // `prev_ptr_write` ikhomba entweni eyodwa ngaphambi kwe `ptr_write`, kepha i `next_write` iqala ngo-1, ngakho-ke i `prev_ptr_write` ayikaze ibe ngaphansi kuka-0 futhi ingaphakathi kwesilayidi.
        // Lokhu kugcwalisa izidingo zokuyekisa ukukhishwa kwe-`ptr_read`, `prev_ptr_write` ne-`ptr_write`, nokusebenzisa i-`ptr.add(next_read)`, `ptr.add(next_write - 1)` ne-`prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` futhi ikhushulwa okungenani kanye nge-loop ngayinye okusho ukuthi ayikho into eyeqwayo lapho ingadinga ukushintshwa.
        //
        // `ptr_read` futhi i-`prev_ptr_write` ayikaze ikhombe entweni efanayo.Lokhu kuyadingeka ukuze i-`&mut *ptr_read`, `&mut* prev_ptr_write` iphephe.
        // Incazelo imane nje ithi i-`next_read >= next_write` ihlale iyiqiniso, ngakho-ke i-`next_read > next_write - 1` nayo iyiqiniso.
        //
        //
        //
        //
        //
        unsafe {
            // Gwema ukuhlolwa kwemingcele ngokusebenzisa izikhombisi eziluhlaza.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Ihambisa konke ngaphandle kokuqala kwezinto ezilandelanayo kuye ekugcineni kocezu oluxazulula ukhiye ofanayo.
    ///
    ///
    /// Ibuyisa izingcezu ezimbili.Eyokuqala ayiqukethe izinto eziphindaphindekayo ezilandelanayo.
    /// Owesibili uqukethe zonke izimpinda ngaphandle kwe-oda ebekiwe.
    ///
    /// Uma ucezu luhlungwe, ucezu olubuyisiwe lokuqala alunazo izimpinda.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Izungezisa isilayidi endaweni yokuthi izinto zokuqala ezingu-`mid` zesilayidi ziye ekugcineni lapho izinto zokugcina ze-`self.len() - mid` zihambela phambili.
    /// Ngemuva kokubiza i-`rotate_left`, into ngaphambilini enkombeni `mid` izoba yinto yokuqala kusilayidi.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma i-`mid` inkulu kunobude besilayidi.Qaphela ukuthi i-`mid == self.len()` yenza i-_not_ panic futhi ingukujikeleza okungavumelani.
    ///
    /// # Complexity
    ///
    /// Ithatha umugqa (ngesikhathi `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Ukushintshanisa isikhokhelo:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // UKUPHEPHA: Ububanzi `[p.add(mid) - mid, p.add(mid) + k)` buncane
        // isebenza ngokufunda nokubhala, njengoba kudingwa yi-`ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Izungezisa isilayidi endaweni yokuthi izinto zokuqala ezingu-`self.len() - k` zesilayidi ziye ekugcineni lapho izinto zokugcina ze-`k` zihambela phambili.
    /// Ngemuva kokubiza i-`rotate_right`, into ngaphambilini enkombeni `self.len() - k` izoba yinto yokuqala kusilayidi.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma i-`k` inkulu kunobude besilayidi.Qaphela ukuthi i-`k == self.len()` yenza i-_not_ panic futhi ingukujikeleza okungavumelani.
    ///
    /// # Complexity
    ///
    /// Ithatha umugqa (ngesikhathi `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Zungezisa okubhalisile:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // UKUPHEPHA: Ububanzi `[p.add(mid) - mid, p.add(mid) + k)` buncane
        // isebenza ngokufunda nokubhala, njengoba kudingwa yi-`ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Igcwalisa i-`self` ngezinto ngokuhlanganisa i-`value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Igcwalisa i `self` ngezinto ezibuyisiwe ngokubiza ukuvalwa kaninginingi.
    ///
    /// Le ndlela isebenzisa ukuvalwa ukudala amanani amasha.Uma ungathanda i-[`Clone`] inani elinikeziwe, sebenzisa i-[`fill`].
    /// Uma ufuna ukusebenzisa i [`Default`] trait ukukhiqiza amanani, ungadlulisa i-[`Default::default`] njengengxabano.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Ikopisha izinto ezisuka ku-`src` ziye ku-`self`.
    ///
    /// Ubude be-`src` kufanele bufane no-`self`.
    ///
    /// Uma i-`T` isebenzisa i-`Copy`, ingahle isebenze kangcono ukusebenzisa i-[`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma izingcezu ezimbili zinobude obuhlukile.
    ///
    /// # Examples
    ///
    /// Ukuhlanganisa izinto ezimbili kusuka kusilayidi kuye kwesinye:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ngoba izingcezu kufanele zibe nobude obufanayo, sisika ucezu lomthombo kusuka ezintweni ezine kuye kwezimbili.
    /// // Kuzoba yi-panic uma singakwenzi lokhu.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// I-Rust iphoqelela ukuthi kungaba nesethenjwa esisodwa esiguqukayo esingenazo izinkomba ezingaguquki kucezu oluthile lwedatha kusilinganiso esithile.
    /// Ngenxa yalokhu, ukuzama ukusebenzisa i-`clone_from_slice` kucezu olulodwa kuzoholela ekuhlulekeni kokuhlanganisa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza kulokhu, singasebenzisa i-[`split_at_mut`] ukwakha izingcezwana ezimbili ezihlukile kusuka kucezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Ikopisha zonke izinto ezisuka ku-`src` ziye ku-`self`, zisebenzisa i-memcpy.
    ///
    /// Ubude be-`src` kufanele bufane no-`self`.
    ///
    /// Uma i-`T` ingasebenzisi i-`Copy`, sebenzisa i-[`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma izingcezu ezimbili zinobude obuhlukile.
    ///
    /// # Examples
    ///
    /// Ukukopisha izinto ezimbili kusuka kusilayidi kuye kwesinye:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ngoba izingcezu kufanele zibe nobude obufanayo, sisika ucezu lomthombo kusuka ezintweni ezine kuye kwezimbili.
    /// // Kuzoba yi-panic uma singakwenzi lokhu.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// I-Rust iphoqelela ukuthi kungaba nesethenjwa esisodwa esiguqukayo esingenazo izinkomba ezingaguquki kucezu oluthile lwedatha kusilinganiso esithile.
    /// Ngenxa yalokhu, ukuzama ukusebenzisa i-`copy_from_slice` kucezu olulodwa kuzoholela ekuhlulekeni kokuhlanganisa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza kulokhu, singasebenzisa i-[`split_at_mut`] ukwakha izingcezwana ezimbili ezihlukile kusuka kucezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Indlela yekhodi ye panic yafakwa emsebenzini obandayo ukuze ingavimbeli indawo yokushayela izingcingo.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // UKUPHEPHA: I-`self` isebenza kuzakhi ze-`self.len()` ngencazelo, futhi i-`src` yayikhona
        // ihlolwe ukuba nobude obulinganayo.
        // Izingcezu azikwazi ukugqagqana ngoba izinkomba eziguqukayo zikhethekile.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Ikopisha izinto kusuka engxenyeni yesilayidi iye kwenye ingxenye yaso, kusetshenziswa i-memmove.
    ///
    /// `src` ububanzi obungaphakathi kwe `self` ongakopisha kusuka kubo.
    /// `dest` inkomba yokuqala yobubanzi obungu-`self` ongakopishela kuyo, obuzoba nobude obulingana no-`src`.
    /// Amabanga amabili angagqagqana.
    /// Imikhawulo yamabanga amabili kufanele ibe ngaphansi noma ilingane no-`self.len()`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma ngabe ububanzi bunye budlula ukuphela kocezu, noma uma ukuphela kwe-`src` kungaphambi kokuqala.
    ///
    ///
    /// # Examples
    ///
    /// Ukukopisha amabhayithi amane ngaphakathi kocezu:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // UKUPHEPHA: izimo ze `ptr::copy` zonke zihloliwe ngenhla,
        // njengoba kunalezo ze-`ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ishintsha zonke izinto ku-`self` nalezo eziku-`other`.
    ///
    /// Ubude be-`other` kufanele bufane no-`self`.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma izingcezu ezimbili zinobude obuhlukile.
    ///
    /// # Example
    ///
    /// Ukuswayipha izinto ezimbili ezincekwini:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// I-Rust iphoqelela ukuthi kungabakhona ireferensi eyodwa kuphela eguqukayo kucezu oluthile lwedatha kusilinganiso esithile.
    ///
    /// Ngenxa yalokhu, ukuzama ukusebenzisa i-`swap_with_slice` kucezu olulodwa kuzoholela ekuhlulekeni kokuhlanganisa:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Ukusebenza ngalokhu, singasebenzisa i-[`split_at_mut`] ukudala izingcezwana ezimbili eziguqukayo eziguqukayo kusuka kucezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // UKUPHEPHA: I-`self` isebenza kuzakhi ze-`self.len()` ngencazelo, futhi i-`src` yayikhona
        // ihlolwe ukuba nobude obulinganayo.
        // Izingcezu azikwazi ukugqagqana ngoba izinkomba eziguqukayo zikhethekile.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Umsebenzi wokubala ubude besilayidi esiphakathi nesilandelayo se-`align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Esizokwenza nge-`rest` ukuthola ukuthi yikuphi okungu-``U`s esingakufaka kwinani eliphansi kakhulu lama-`T`s.
        //
        // Futhi mangaki ama-T`s esiwadinga nge-"multiple" ngayinye.
        //
        // Cabanga ngokwesibonelo T=u8 U=u16.Ngemuva kwalokho singabeka u-1 U ku-2 Ts.Okulula.
        // Manje, cabanga ngokwesibonelo icala lapho usayizi_of: :<T>=16, usayizi_of::<U>=24.</u>
        // Singabeka i-2 Us esikhundleni sawo wonke ama-3 Ts kocezu lwe `rest`.
        // Kuyinkimbinkimbi ngokwengeziwe.
        //
        // Ifomula yokubala lokhu yile:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Kunwetshiwe futhi kwenziwa lula:
        //
        // Us=usayizi_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=usayizi_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Ngenhlanhla ngoba konke lokhu kuhlolwe njalo ... ukusebenza lapha akubalulekile!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Iterative stein's algorithm Kufanele sisaqhubeka nokwenza le `const fn` (bese sibuyela ku-algorithm ephindayo uma senza) ngoba ukuthembela ku-llvm ukwenza konke lokhu kuyi…kahle, kungenza ngingakhululeki.
            //
            //

            // UKUPHEPHA: I-`a` ne-`b` zihlolwe njengamanani angewona awuziro.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // susa zonke izici ezi-2 ku-b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // UKUPHEPHA: I-`b` ihlolwe ukuthi ayiyona zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Sihlome ngalolu lwazi, singathola ukuthi mangaki ama-`U`s esingalingana nawo!
        let us_len = self.len() / ts * us;
        // Futhi mangaki ama-T`s azobe esesilayidi esilandelayo!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Shintsha ucezu lube ucezu lolunye uhlobo, uqinisekise ukuthi ukuhleleka kwalezi zinhlobo kuyagcinwa.
    ///
    /// Le ndlela ihlukanisa ucezu lube izingcezu ezintathu ezihlukile: isiqalo, ucezu olumaphakathi oluqondaniswe kahle lwohlobo olusha, nocezu lwesijobelelo.
    /// Le ndlela ingenza ucezu oluphakathi lube nobude obukhulu kunabo bonke bohlobo olunikeziwe nocezu lokufaka, kepha ukusebenza kwe-algorithm yakho kuphela okufanele kuncike kulokho, hhayi ukunemba kwayo.
    ///
    /// Kuvunyelwe yonke idatha yokufaka ukuthi ibuyiselwe njengesiqalo noma ucezu lwesijobelelo.
    ///
    /// Le ndlela ayinanjongo lapho into yokufaka `T` noma into yokukhipha `U` ilingana no-zero futhi izobuyisa isilayidi sokuqala ngaphandle kokuhlukanisa noma yini.
    ///
    /// # Safety
    ///
    /// Le ndlela empeleni iyi-`transmute` maqondana nezinto eziseqhekweni eliphakathi elibuyisiwe, ngakho-ke yonke imihume ejwayelekile ephathelene ne `transmute::<T, U>` nayo iyasebenza lapha.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Qaphela ukuthi iningi lalo msebenzi lizohlolwa njalo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // phatha ama-ZST ngokukhethekile, okungukuthi-ungawaphathi nhlobo.
            return (self, &[], &[]);
        }

        // Okokuqala, thola ukuthi sehlukane ngasiphi isikhathi phakathi kocezu lokuqala nolwesibili.
        // Kulula nge ptr.align_offset.
        let ptr = self.as_ptr();
        // UKUPHEPHA: Bona indlela ye `align_to_mut` ukuthola ukuphawula okuningiliziwe.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // UKUPHEPHA: manje i `rest` iqondaniswe nakanjani, ngakho-ke i `from_raw_parts` engezansi ilungile,
            // ngoba ofonayo uqinisekisa ukuthi singadlulisa i-`T` iye ku-`U` ngokuphepha.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Shintsha ucezu lube ucezu lolunye uhlobo, uqinisekise ukuthi ukuhleleka kwalezi zinhlobo kuyagcinwa.
    ///
    /// Le ndlela ihlukanisa ucezu lube izingcezu ezintathu ezihlukile: isiqalo, ucezu olumaphakathi oluqondaniswe kahle lwohlobo olusha, nocezu lwesijobelelo.
    /// Le ndlela ingenza ucezu oluphakathi lube nobude obukhulu kunabo bonke bohlobo olunikeziwe nocezu lokufaka, kepha ukusebenza kwe-algorithm yakho kuphela okufanele kuncike kulokho, hhayi ukunemba kwayo.
    ///
    /// Kuvunyelwe yonke idatha yokufaka ukuthi ibuyiselwe njengesiqalo noma ucezu lwesijobelelo.
    ///
    /// Le ndlela ayinanjongo lapho into yokufaka `T` noma into yokukhipha `U` ilingana no-zero futhi izobuyisa isilayidi sokuqala ngaphandle kokuhlukanisa noma yini.
    ///
    /// # Safety
    ///
    /// Le ndlela empeleni iyi-`transmute` maqondana nezinto eziseqhekweni eliphakathi elibuyisiwe, ngakho-ke yonke imihume ejwayelekile ephathelene ne `transmute::<T, U>` nayo iyasebenza lapha.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Qaphela ukuthi iningi lalo msebenzi lizohlolwa njalo,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // phatha ama-ZST ngokukhethekile, okungukuthi-ungawaphathi nhlobo.
            return (self, &mut [], &mut []);
        }

        // Okokuqala, thola ukuthi sehlukane ngasiphi isikhathi phakathi kocezu lokuqala nolwesibili.
        // Kulula nge ptr.align_offset.
        let ptr = self.as_ptr();
        // UKUPHEPHA: Lapha siqinisekisa ukuthi sizosebenzisa izikhombisi ezihambisanayo ze-U ze-
        // enye indlela.Lokhu kwenziwa ngokudlulisa isikhombisi ku-&[T] ngokuqondanisa okubhekiswe ku-U.
        // `crate::ptr::align_offset` ibizwa ngesikhombi esiqondiswe kahle nesisebenza kahle i-`ptr` (sivela kusethenjwa se-`self`) nangosayizi ongamandla amabili (ngoba kuvela ekuqondanisweni kwe-U), sanelisa izingqinamba zokuphepha.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Asikwazi ukusebenzisa i-`rest` futhi ngemuva kwalokhu, lokho kuzokwenza i-alias yayo i-`mut_ptr` ingasebenzi!UKUPHEPHA: bona imibono ye `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Ihlola ukuthi ngabe izinto zalesi slice zihleliwe yini.
    ///
    /// Lokho wukuthi, into ngayinye i-`a` nento elandelayo `b`, i-`a <= b` kufanele ibambe.Uma ucezu luthela ngqo u-zero noma into eyodwa, i-`true` iyabuyiselwa.
    ///
    /// Qaphela ukuthi uma i-`Self::Item` ingu-`PartialOrd` kuphela, kepha hhayi i-`Ord`, incazelo engenhla isho ukuthi lo msebenzi ubuyisa i-`false` uma ngabe kukhona izinto ezimbili ezilandelanayo ezingalingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Ihlola ukuthi ngabe izinto zalesi slice zihlungwe kusetshenziswa umsebenzi onikeziwe wokuqhathanisa.
    ///
    /// Esikhundleni sokusebenzisa i-`PartialOrd::partial_cmp`, lo msebenzi usebenzisa umsebenzi owunikiwe we-`compare` ukuthola ukuhleleka kwezinto ezimbili.
    /// Ngaphandle kwalokho, ilingana ne [`is_sorted`];bona imibhalo yayo ukuthola eminye imininingwane.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Ihlola ukuthi ngabe izinto zalesi slice zihlungwe kusetshenziswa umsebenzi wokukhipha ukhiye onikeziwe.
    ///
    /// Esikhundleni sokuqhathanisa izinto zesilayidi ngqo, lo msebenzi uqhathanisa okhiye bezinto, njengoba kunqunywe yi-`f`.
    /// Ngaphandle kwalokho, ilingana ne [`is_sorted`];bona imibhalo yayo ukuthola eminye imininingwane.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Ibuyisa inkomba yephoyinti lokuhlukanisa ngokuya ngesilandiso esinikeziwe (inkomba yento yokuqala yokwahlukanisa kwesibili).
    ///
    /// Isilayidi kucatshangwa ukuthi sehlukaniswa ngokwesilandiso esinikeziwe.
    /// Lokhu kusho ukuthi zonke izinto isilandiso esibuya kuzo ziyiqiniso ekuqaleni kocezu futhi zonke izinto isilandiso esibuyisa amanga zisekugcineni.
    ///
    /// Isibonelo, i-[7, 15, 3, 5, 4, 12, 6] ihlukaniswe ngaphansi kwesilandiso x% 2!=0 (zonke izinombolo eziyinqaba zisekuqaleni, zonke zisekugcineni).
    ///
    /// Uma lesi silayidi singahlukanisiwe, umphumela obuyisiwe awucacisiwe futhi awunanjongo, njengoba le ndlela yenza uhlobo lokusesha kanambambili.
    ///
    /// Bheka futhi i [`binary_search`], [`binary_search_by`], ne [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // UKUPHEPHA: Lapho i-`left < right`, `left <= mid < right`.
            // Ngakho-ke i-`left` ihlala inyuka futhi i-`right` ihlala incipha, futhi enye yazo iyakhethwa.Kuzo zombili lezi zimo i `left <= right` yanelisekile.Ngakho-ke uma i-`left < right` esinyathelweni, i-`left <= right` yanelisekile esinyathelweni esilandelayo.
            //
            // Ngakho-ke inqobo nje uma i-`left != right`, i-`0 <= left < right <= len` yanelisekile futhi uma ngabe leli cala i-`0 <= mid < len` linelisekile nalo.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Sidinga ukuzisika ngokusobala ngobude obufanayo
        // ukwenza kube lula ukuthi i-optimizer ihlolisise imingcele ye-elide.
        // Kepha njengoba kungenakuthenjelwa kukho futhi sinobuchwepheshe obucacile be-T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Kwakha ucezu olungenalutho.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Kwakha isilayidi esingenalutho esingaguquguquki.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Amaphethini ezincekeni, okwamanje, asetshenziswa kuphela yi-`strip_prefix` ne-`strip_suffix`.
/// Ephuzwini le-future, sethemba ukwenza i-`core::str::Pattern` (okuyothi ngesikhathi sokubhala ikhawulelwe ku-`str`) kube izingcezu, bese kuthi le trait ishintshwe noma isuswe.
///
pub trait SlicePattern {
    /// Uhlobo lwento locezu olufaniswa nalo.
    type Item;

    /// Njengamanje, abathengi be `SlicePattern` badinga ucezu.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}