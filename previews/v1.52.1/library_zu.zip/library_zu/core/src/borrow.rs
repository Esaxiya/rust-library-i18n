//! Imodyuli yokusebenza nedatha ebolekiwe.

#![stable(feature = "rust1", since = "1.0.0")]

/// I-trait yedatha yokuboleka.
///
/// Ku-Rust, kujwayelekile ukuhlinzeka ngezethulo ezahlukahlukene zohlobo lwamacala ahlukile wokusebenzisa.
/// Isibonelo, indawo yokugcina kanye nokuphathwa kwenani kungakhethwa ngokukhethekile njengokufanele ukusetshenziswa okuthile ngezinhlobo zesikhombi ezinjenge-[`Box<T>`] noma i-[`Rc<T>`].
/// Ngaphandle kwalezi ezisongelayo ezijwayelekile ezingasetshenziswa nganoma yiluphi uhlobo, ezinye izinhlobo zinikela ngezici zokuzikhethela ezihlinzeka ngokusebenza okungabiza kakhulu.
/// Isibonelo sohlobo olunjalo yi-[`String`] engeza amandla wokunweba intambo ku-[`str`] eyisisekelo.
/// Lokhu kudinga ukugcina imininingwane eyengeziwe ingadingeki ngentambo elula, engaphenduki.
///
/// Lezi zinhlobo zinikeza ukufinyelela kwedatha eyisisekelo ngokubhekisela kohlobo lwedatha leyo.Kuthiwa 'babolekwe njengalolo' hlobo.
/// Isibonelo, i-[`Box<T>`] ingaboleka njenge-`T` ngenkathi i-[`String`] ingaboleka njenge-`str`.
///
/// Izinhlobo ziveza ukuthi zingabolekiswa njengohlobo oluthile lwe-`T` ngokusebenzisa i-`Borrow<T>`, zinikeze ireferensi ku-`T` ngendlela ye trait's [`borrow`].Uhlobo lukhululekile ukuboleka njengezinhlobo ezahlukahlukene ezahlukahlukene.
/// Uma ifisa ukuboleka ngokuguqukayo njengohlobo-ivumela idatha eyisisekelo ukuthi iguqulwe, ingafaka futhi i-[`BorrowMut<T>`].
///
/// Ngaphezu kwalokho, lapho kunikezwa ukusetshenziswa kwe-traits eyengeziwe, kuzodingeka ukuthi kubhekwe ukuthi ngabe kufanele baziphathe ngokufana nalezo zohlobo oluphansi njengomphumela wokusebenza njengabamele lolo hlobo oluyisisekelo.
/// Ikhodi ejwayelekile isebenzisa i-`Borrow<T>` lapho incike ekuziphatheni okufanayo kwalokhu kufakwa okwengeziwe kwe-trait.
/// Lezi traits kungenzeka zivele njenge-trait bounds eyengeziwe.
///
/// Ikakhulukazi i-`Eq`, i-`Ord` ne-`Hash` kumele zilingane namanani abolekwe nakawo: I-`x.borrow() == y.borrow()` kufanele inikeze umphumela ofanayo ne-`x == y`.
///
/// Uma ikhodi ejwayelekile idinga ukusebenzela zonke izinhlobo ezinganikeza ireferensi yohlobo oluhlobene i `T`, kuvame ukuba ngcono ukusebenzisa i [`AsRef<T>`] njengoba izinhlobo eziningi zingayisebenzisa ngokuphepha.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Njengeqoqo ledatha, i [`HashMap<K, V>`] ingumnikazi womabili okhiye namanani.Uma imininingwane yangempela yokhiye isongwe ngohlobo lokuphatha lohlobo oluthile, kufanele, noma kunjalo, kusengaba khona ukucinga inani kusetshenziswa ireferensi yedatha yokhiye.
/// Isibonelo, uma ukhiye uyintambo, khona-ke kungenzeka ukuthi igcinwe nemephu ye-hash njenge-[`String`], ngenkathi kufanele kusetshenziswe kusetshenziswa i-[`&str`][`str`].
/// Ngakho-ke, i-`insert` idinga ukusebenza ku-`String` ngenkathi i-`get` idinga ukwazi ukusebenzisa i-`&str`.
///
/// Yenziwe lula kancane, izingxenye ezifanele ze-`HashMap<K, V>` zibukeka kanjena:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // izinkambu zishiyiwe
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Yonke imephu ye-hashi yenziwe ngohlobo lokhiye `K`.Ngoba lezi zinkinobho zigcinwa ngemephu ye-hash, lolu hlobo kufanele lube nemininingwane yokhiye.
/// Lapho ufaka ipheya lenani lokhiye, imephu inikezwa i-`K` enjalo futhi idinga ukuthola ibhakede elifanele le-hash bese ubheka ukuthi ukhiye usuvele ukhona ngokuya ngaleyo `K`.Ngakho-ke idinga i-`K: Hash + Eq`.
///
/// Lapho ufuna inani emephini, noma kunjalo, kufanele unikeze ireferensi ku-`K` njengokhiye wokuyifuna kungadinga ukudala njalo inani elinjalo.
/// Okhiye bezintambo, lokhu kungasho ukuthi inani le-`String` lidinga ukwenziwa ngokuseshwa kwamacala lapho kutholakala kuphela i-`str`.
///
/// Esikhundleni salokho, indlela ye-`get` ingejwayelekile ngohlobo lwedatha eyisihluthulelo, ebizwa nge-`Q` kusiginesha yendlela engenhla.Ithi i `K` iboleka njenge-`Q` ngokudinga leyo `K: Borrow<Q>`.
/// Ngokungeziwe ngokudinga i-`Q: Hash + Eq`, itshengisa isidingo sokuthi i-`K` ne-`Q` zisebenzise i-`Hash` ne-`Eq` traits ezikhiqiza imiphumela efanayo.
///
/// Ukuqaliswa kwe `get` kuncike ikakhulukazi ekusetshenzisweni okufanayo kwe `Hash` ngokunquma ibhakede le-hash yokhiye ngokubiza i-`Hash::hash` kunani le-`Q` noma ngabe lifake ukhiye ngokususelwa kunani le-hash elibalwe kusukela kunani le-`K`.
///
///
/// Ngenxa yalokho, imephu ye-hash iyaqhekeka uma i-`K` esonga inani le-`Q` ikhiqiza i-hash ehlukile kune-`Q`.Isibonelo, ake ucabange ukuthi unohlobo olusonga intambo kepha luqhathanise izinhlamvu ze-ASCII ezingazinaki izindaba zazo:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ngoba amanani amabili alinganayo adinga ukukhiqiza inani elifanayo le-hash, ukusetshenziswa kwe-`Hash` kudinga ukunganaki icala le-ASCII, futhi:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ingabe i-`CaseInsensitiveString` ingasebenzisa i-`Borrow<str>`?Impela inganikeza ireferensi kocezu lwentambo ngentambo yayo ephethwe.
/// Kepha ngoba ukusetshenziswa kwayo kwe `Hash` kwehlukile, kuziphatha ngendlela ehlukile kune-`str` ngakho-ke akumele, empeleni, kusebenze i `Borrow<str>`.
/// Uma ifuna ukuvumela abanye ukuthi bangene ku-`str` engaphansi, ingakwenza lokho nge-`AsRef<str>` engathwali ezinye izidingo.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Uboleka ngokungazelelwe kunani eliphethwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// I-trait yedatha yokuboleka ngokuguqukayo.
///
/// Njengomngane we [`Borrow<T>`] le trait ivumela uhlobo ukuthi luboleke njengohlobo oluyisisekelo ngokunikeza ireferensi engaguquguqukayo.
/// Bona i [`Borrow<T>`] ukuthola eminye imininingwane ngokuboleka njengolunye uhlobo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Ibolekwe ngokuguqukayo kunani eliphethwe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}