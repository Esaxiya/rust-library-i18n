//! Ukwabiwa kwememori ama-API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Iphutha le-`AllocError` likhombisa ukwehluleka kwesabelo okungahle kube ngenxa yokukhathala kwezinsizakusebenza noma okuthile okungahambi kahle lapho kuhlanganiswa izimpikiswano zokufaka ezinikeziwe nalo mhlinzeki.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (sikudinga lokhu ukuthola okungaphansi kwe trait Iphutha)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Ukuqaliswa kwe-`Allocator` kungabela, kukhule, kunciphise, futhi kuhambise amabhlokhi wedatha angqubuzanayo achazwe nge [`Layout`][].
///
/// `Allocator` yenzelwe ukuthi isetshenziswe kuma-ZST, izinkomba, noma izikhombisi ezihlakaniphile ngoba ukuba nesabelo esinjenge-`MyAlloc([u8; N])` akukwazi ukuhanjiswa, ngaphandle kokubuyekeza izikhombisi kwimemori eyabiwe.
///
/// Ngokungafani ne-[`GlobalAlloc`][], izabelo ezilingana no-zero zivunyelwe ku-`Allocator`.
/// Uma isabelo esingezansi singakusekeli lokhu (njenge-jemalloc) noma sibuyise isikhombisi esingasebenzi (njenge-`libc::malloc`), lokhu kufanele kubanjwe ukuqaliswa.
///
/// ### Imemori eyabiwe njengamanje
///
/// Ezinye zezindlela zidinga ukuthi i-memory block *inikezwe* njengamanje ngesabeluli.Lokhu kusho ukuthi:
///
/// * ikheli lokuqala laleyo block memory lalibuyiselwe i-[`allocate`], [`grow`], noma i-[`shrink`], ne
///
/// * i-memory block ayikasuswa kamuva, lapho amabhulokhi ahanjiswa ngqo ngokudluliselwa ku-[`deallocate`] noma aguqulwe ngokudluliselwa ku-[`grow`] noma ku-[`shrink`] okubuyisa i-`Ok`.
///
/// Uma i-`grow` noma i-`shrink` ibuyise i-`Err`, isikhombisi esidlulisiwe sihlala sisebenza.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Imemori efanelekayo
///
/// Ezinye zezindlela zidinga ukuthi ukwakheka *kulingane* nebhulokhi yememori.
/// Okushiwo ukwakheka ku-"fit" ibhulokhi yememori kusho (noma ngokulinganayo, kwebhulokhi yememori ku-"fit" ukwakheka) ukuthi izimo ezilandelayo kufanele zibambe:
///
/// * Ibhlokhi kufanele yabelwe ngokuqondanisa okufanayo ne [`layout.align()`], futhi
///
/// * I-[`layout.size()`] enikeziwe kufanele iwele ebangeni `min ..= max`, lapho:
///   - `min` ubukhulu besakhiwo esisetshenziswe kamuva ukwaba ibhulokhi, futhi
///   - `max` usayizi wangempela wakamuva ubuyiswe kusuka ku-[`allocate`], [`grow`], noma ku-[`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Amabhulokhi ememori abuyiswe kusuka kusabelomali kufanele akhombe kwimemori evumelekile futhi agcine ukusebenza kwawo kuze kube yilapho isibonelo nawo wonke ama-clone aso ewa,
///
/// * Ukuhlanganisa noma ukuhambisa isabelo kufanele kungavimbeli imemori block ebuyiswe kulo mhlinzeki.Isabelo esenziwe ngobumba kufanele siziphathise okwabiwayo okufanayo, futhi
///
/// * noma isiphi isikhombisi esiku-memory block okuyi-[*currently allocated*] singadluliselwa kunoma iyiphi enye indlela yokwaba.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Imizamo yokwaba ibhulokhi yenkumbulo.
    ///
    /// Empumelelweni, kubuyisa umhlangano we-[`NonNull<[u8]>`][NonNull] ngosayizi nokuqinisekisa kokuqondanisa kwe `layout`.
    ///
    /// Ibhulokhi ebuyisiwe ingahle ibe nosayizi omkhulu kunokuchazwe yi-`layout.size()`, futhi ingahle iqalise noma ingahle ingatholi okuqukethwe kwayo.
    ///
    /// # Errors
    ///
    /// Ukubuyisa i-`Err` kukhombisa ukuthi imemori iphelile noma i-`layout` ayihlangabezani nosayizi womhlinzeki noma izingqinamba zokuqondanisa.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiswe i-`Err` ekukhathalelweni kwememori kunokwethuka noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Iziphatha njenge-`allocate`, kepha futhi iqinisekisa ukuthi imemori ebuyisiwe ayiqaliwe ngo-zero.
    ///
    /// # Errors
    ///
    /// Ukubuyisa i-`Err` kukhombisa ukuthi imemori iphelile noma i-`layout` ayihlangabezani nosayizi womhlinzeki noma izingqinamba zokuqondanisa.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiswe i-`Err` ekukhathalelweni kwememori kunokwethuka noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // UKUPHEPHA: I-`alloc` ibuyisa i-memory block evumelekile
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Isusa imemori ebalulwe yi `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` kufanele ichaze ibhulokhi yememori [*currently allocated*] ngalomhlinzeki, futhi
    /// * `layout` kufanele [*fit*] lelo bhulokhi lememori.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Imizamo yokwelula ibhulokhi yememori.
    ///
    /// Ibuyisa i-[`NonNull<[u8]>`][NonNull] entsha equkethe i-pointer nosayizi wangempela wememori eyabiwe.Isikhombi silungele ukubamba idatha echazwe yi-`new_layout`.
    /// Ukufeza lokhu, umhlinzeki anganweba isabelo esiboniswe yi-`ptr` ukuze silingane nesakhiwo esisha.
    ///
    /// Uma lokhu kubuyisa i-`Ok`, khona-ke ubunikazi be-memory block obhekiswe ku-`ptr` budluliselwe kulo mhlinzeki.
    /// Imemori kungenzeka ikhululwe noma kungenzeka ingakhululwa, futhi kufanele ibhekwe njengengasebenziseki ngaphandle kokuthi ibuyiselwe kumuntu oshayayo futhi ngenani lokubuyisa lale ndlela.
    ///
    /// Uma le ndlela ibuyisa i-`Err`, khona-ke ubunikazi be-memory block abukwedluliselwanga kulo mhlinzeki, futhi okuqukethwe kwebhulokhi yememori akukuguquliwe.
    ///
    /// # Safety
    ///
    /// * `ptr` kufanele ichaze ibhulokhi yememori [*currently allocated*] ngalomhlinzeki.
    /// * `old_layout` Kufanele i-[*fit*] leyo block memory (Impikiswano ye-`new_layout` ayidingi ukuyilingana.).
    /// * `new_layout.size()` kufanele ibe nkulu noma ilingane no-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i-`Err` uma isakhiwo esisha singahlangabezani nosayizi womhlinzeki kanye nezingqinamba zokuqondanisa zomhlinzeki, noma uma ukukhula ngenye indlela kwehluleka.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiswe i-`Err` ekukhathalelweni kwememori kunokwethuka noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // UKUPHEPHA: ngoba i `new_layout.size()` kumele ibe nkulu noma ilingane nayo
        // `old_layout.size()`, ukwabiwa kwememori endala nokusha kuvumelekile ukufundwa futhi kubhalelwa ama-`old_layout.size()` byte.
        // Futhi, ngoba isabelo esidala besingakahanjiswa, asikwazi ukweqa i `new_ptr`.
        // Ngakho-ke, ucingo oluya ku `copy_nonoverlapping` luphephile.
        // Inkontileka yezokuphepha ye `dealloc` kufanele igcinwe yilowo ofonayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Iziphatha njenge-`grow`, kepha futhi iqinisekisa ukuthi okuqukethwe okusha kusethwe ku-zero ngaphambi kokubuyiselwa.
    ///
    /// Ibhulokhi yememori izoqukatha okuqukethwe okulandelayo ngemuva kocingo oluphumelele ku-
    /// `grow_zeroed`:
    ///   * Ama-Byte `0..old_layout.size()` alondoloziwe kusuka kusabelo sangempela.
    ///   * Ama-Byte `old_layout.size()..old_size` azogcinwa noma ahanjiswe, kuya ngokuqaliswa kwesabelo.
    ///   `old_size` kubhekiswa kusayizi webhulokhi yememori ngaphambi kocingo lwe-`grow_zeroed`, olungaba lukhulu kunosayizi owawucelwe ekuqaleni ngenkathi unikezwa.
    ///   * Ama-Byte `old_size..new_size` akhishiwe.I-`new_size` isho usayizi webhulokhi yememori obuyiswe yikholi ye-`grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` kufanele ichaze ibhulokhi yememori [*currently allocated*] ngalomhlinzeki.
    /// * `old_layout` Kufanele i-[*fit*] leyo block memory (Impikiswano ye-`new_layout` ayidingi ukuyilingana.).
    /// * `new_layout.size()` kufanele ibe nkulu noma ilingane no-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i-`Err` uma isakhiwo esisha singahlangabezani nosayizi womhlinzeki kanye nezingqinamba zokuqondanisa zomhlinzeki, noma uma ukukhula ngenye indlela kwehluleka.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiswe i-`Err` ekukhathalelweni kwememori kunokwethuka noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // UKUPHEPHA: ngoba i `new_layout.size()` kumele ibe nkulu noma ilingane nayo
        // `old_layout.size()`, ukwabiwa kwememori endala nokusha kuvumelekile ukufundwa futhi kubhalelwa ama-`old_layout.size()` byte.
        // Futhi, ngoba isabelo esidala besingakahanjiswa, asikwazi ukweqa i `new_ptr`.
        // Ngakho-ke, ucingo oluya ku `copy_nonoverlapping` luphephile.
        // Inkontileka yezokuphepha ye `dealloc` kufanele igcinwe yilowo ofonayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Imizamo yokunciphisa isivimbelo sememori.
    ///
    /// Ibuyisa i-[`NonNull<[u8]>`][NonNull] entsha equkethe i-pointer nosayizi wangempela wememori eyabiwe.Isikhombi silungele ukubamba idatha echazwe yi-`new_layout`.
    /// Ukufeza lokhu, umhlinzeki angahle anciphise isabelo esiboniswe yi-`ptr` ukuze silingane nesakhiwo esisha.
    ///
    /// Uma lokhu kubuyisa i-`Ok`, khona-ke ubunikazi be-memory block obhekiswe ku-`ptr` budluliselwe kulo mhlinzeki.
    /// Imemori kungenzeka ikhululwe noma kungenzeka ingakhululwa, futhi kufanele ibhekwe njengengasebenziseki ngaphandle kokuthi ibuyiselwe kumuntu oshayayo futhi ngenani lokubuyisa lale ndlela.
    ///
    /// Uma le ndlela ibuyisa i-`Err`, khona-ke ubunikazi be-memory block abukwedluliselwanga kulo mhlinzeki, futhi okuqukethwe kwebhulokhi yememori akukuguquliwe.
    ///
    /// # Safety
    ///
    /// * `ptr` kufanele ichaze ibhulokhi yememori [*currently allocated*] ngalomhlinzeki.
    /// * `old_layout` Kufanele i-[*fit*] leyo block memory (Impikiswano ye-`new_layout` ayidingi ukuyilingana.).
    /// * `new_layout.size()` kufanele ibe ncane kune noma ilingane no-`old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Ibuyisa i-`Err` uma isakhiwo esisha singahlangabezani nosayizi womhlinzeki kanye nezingqinamba zokuqondanisa zomhlinzeki, noma uma ukuncipha ngenye indlela kwehluleka.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiswe i-`Err` ekukhathalelweni kwememori kunokwethuka noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // UKUPHEPHA: ngoba i `new_layout.size()` kumele ibe ngaphansi kunalokho noma ilingane nayo
        // `old_layout.size()`, ukwabiwa kwememori endala nokusha kuvumelekile ukufundwa futhi kubhalelwa ama-`new_layout.size()` byte.
        // Futhi, ngoba isabelo esidala besingakahanjiswa, asikwazi ukweqa i `new_ptr`.
        // Ngakho-ke, ucingo oluya ku `copy_nonoverlapping` luphephile.
        // Inkontileka yezokuphepha ye `dealloc` kufanele igcinwe yilowo ofonayo.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Idala i-adaptha ye-"by reference" yalesi sibonelo se-`Allocator`.
    ///
    /// I-adaptha ebuyisiwe ibuye isebenzise i `Allocator` futhi izomane iboleke lokhu.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // UKUPHEPHA: inkontileka yezokuphepha kumele igcinwe yilowo ofonayo
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKUPHEPHA: inkontileka yezokuphepha kumele igcinwe yilowo ofonayo
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKUPHEPHA: inkontileka yezokuphepha kumele igcinwe yilowo ofonayo
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // UKUPHEPHA: inkontileka yezokuphepha kumele igcinwe yilowo ofonayo
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}