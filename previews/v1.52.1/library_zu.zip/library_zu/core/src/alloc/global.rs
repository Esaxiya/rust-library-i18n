use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Ukwabiwa kwememori okungabhaliswa njengokuzenzakalelayo komtapo wolwazi okujwayelekile ngesichasiso se-`#[global_allocator]`.
///
/// Ezinye zezindlela zidinga ukuthi i-memory block *inikezwe* njengamanje ngesabeluli.Lokhu kusho ukuthi:
///
/// * ikheli lokuqala laleyo block memory lalibuyiselwe ucingo langaphambilini ngendlela yokwabiwa efana ne `alloc`, kanye
///
/// * ibhulokhi yememori ayikasuswa kamuva, lapho amabhlokhi ahanjiswa khona ngokudluliswa kundlela yokuhambisa efana ne `dealloc` noma ngokudluliselwa kundlela yokwabiwa kabusha ebuyisa isikhombisi esingelona iqiniso.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// I-`GlobalAlloc` trait iyi-`unsafe` trait ngezizathu eziningi, futhi abaqalisi kumele baqinisekise ukuthi bayazithobela lezi zinkontileka:
///
/// * Ukuziphatha okungachazeki uma abahlinzeki bomhlaba bephumula.Lo mkhawulo ungaphakanyiswa ku-future, kepha njengamanje i-panic kusuka kunoma iyiphi yale misebenzi ingaholela ekuphepheni kwememori.
///
/// * `Layout` imibuzo kanye nokubala kukonke kufanele kube okulungile.Abashayela le trait bavunyelwe ukuthembela kuzinkontileka ezichazwe kundlela ngayinye, futhi abaqambi kumele baqinisekise ukuthi lezo zinkontileka zihlala ziyiqiniso.
///
/// * Ungahle ungathembeli ekwabiweni okwenzeka empeleni, noma ngabe kunokwabiwa okucacile kwenqwaba emthonjeni.
/// Isisebenzisi esivumayo singathola ukwabiwa okungasetshenziswanga esingakususa ngokuphelele noma sithuthele isitaki futhi ngaleyo ndlela singalokothi sincenge umabi.
/// Isisebenzisi singaqhubeka sicabange ukuthi ukwabiwa akunaphutha, ngakho-ke ikhodi ebikade yehluleka ngenxa yokwehluleka kwesabelo manje ingahle isebenze ngokuzumayo ngoba i-optimizer isebenze eduze kwesidingo sesabelo.
/// Ngokusobala, isibonelo sekhodi elandelayo asinangqondo, kungakhathalekile ukuthi owabela ngokwezifiso ukuvumela yini ukubala ukuthi kungakanani ukwabiwa okwenzekile.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Qaphela ukuthi ukulungiselelwa okukhulunywe ngenhla akuyona ukuphela kokusebenzisa okungasetshenziswa.Ungahle ungathembeli ekwabelweni kwenqwaba okwenzekayo uma kungasuswa ngaphandle kokushintsha ukusebenza kohlelo.
///   Ukuthi ukwabiwa kuyenzeka noma cha akuyona ingxenye yokuziphatha kohlelo, noma kungatholwa ngesabelo esilandelela ukwabiwa ngokushicilela noma ngenye indlela kube nemiphumela engemihle.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Nika inkumbulo njengoba kuchaziwe yi-`layout` enikeziwe.
    ///
    /// Ibuyisa isikhombisi kwimemori esanda kunikezwa, noma i-null ukukhombisa ukwehluleka kwesabelo.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba isimilo esingachazwanga singavela uma ofonayo engaqinisekisi ukuthi i-`layout` inosayizi ongeyena uziro.
    ///
    /// (Ukwehliswa kwesandiso kungahlinzeka ngemikhawulo ethile ekuziphatheni, isb. Ukuqinisekisa ikheli le-sentinel noma i-pointer eyize ekuphenduleni isicelo sokwabiwa okungu-zero.)
    ///
    /// Ibhulokhi eyabelwe inkumbulo ingaqalwa noma ingaqalwa.
    ///
    /// # Errors
    ///
    /// Ukubuyisa isikhombisi esingenalutho kukhombisa ukuthi imemori iphelile noma i-`layout` ayihlangabezani nosayizi walomabi noma izingqinamba zokuqondanisa.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiselwe emuva ukukhathala kwememori kunokukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Nikeza i-block yememori kusikhombi se-`ptr` esinikeziwe nge-`layout` enikeziwe.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba isimilo esingachazwanga singavela uma ofonayo engaqinisekisi konke okulandelayo:
    ///
    ///
    /// * `ptr` kufanele ichaze ibhulokhi yememori njengamanje enikezwe lo mhlinzeki,
    ///
    /// * `layout` kufanele kube ukwakheka okufanayo okusetshenziselwe ukwaba lelo bhulokhi lememori.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Iziphatha njenge-`alloc`, kepha futhi iqinisekisa ukuthi okuqukethwe kusethwe kwaba zero ngaphambi kokubuyiselwa.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngezizathu ezifanayo ne-`alloc`.
    /// Kodwa-ke ibhulokhi yememori eyabiwe iqinisekisiwe ukuthi iqalwe.
    ///
    /// # Errors
    ///
    /// Ukubuyisa isikhombisi esingenalutho kukhombisa ukuthi imemori iphelile noma i-`layout` ayihlangabezani nosayizi womhlinzeki noma izingqinamba zokuqondanisa, njengakwi `alloc`.
    ///
    /// Amakhasimende afisa ukukhipha ukukhishwa kwekhompyutha ngokuphendula iphutha lokwabiwa ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // UKUPHEPHA: inkontileka yokuphepha ye `alloc` kufanele igcinwe yilowo ofonayo.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // UKUPHEPHA: njengoba ukwabiwa kuphumelele, isifunda sisuka ku `ptr`
            // ngosayizi `size` kuqinisekisiwe ukuthi kufanelekile ekubhaleni.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Nciphisa noma khulisa ibhulokhi yememori ku-`new_size` enikeziwe.
    /// Ibhlokhi lichazwa yisikhombi esinikezwe i `ptr` kanye ne `layout`.
    ///
    /// Uma lokhu kubuyisa isikhombisi esingelona iqiniso, ubunikazi be-memory block obhekiswe ku-`ptr` budluliselwe kulo mhlinzeki.
    /// Imemori ingahle ihanjiswe noma ingahanjiswanga, futhi kufanele ibhekwe njengengasebenziseki (ngaphandle kokuthi idluliselwe kumuntu oshayayo futhi ngenani lokubuyisa lale ndlela).
    /// I-memory block entsha inikezwe i-`layout`, kepha i-`size` ivuselelwe ku-`new_size`.
    /// Lesi sakhiwo esisha kufanele sisetshenziswe lapho kufakwa i-memory block entsha nge-`dealloc`.
    /// Ububanzi `0..min(layout.size(), new_size) `be-memory block entsha buqinisekisiwe ukuthi bunamanani afanayo ne-block yasekuqaleni.
    ///
    /// Uma le ndlela ibuya ize, khona-ke ubunikazi be-memory block abukadluliswanga kulo mhlinzeki, futhi okuqukethwe kwebhulokhi yememori akukuguquliwe.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile ngoba isimilo esingachazwanga singavela uma ofonayo engaqinisekisi konke okulandelayo:
    ///
    /// * `ptr` kufanele okwamanje yabelwe ngalo mhlinzeki,
    ///
    /// * `layout` kufanele kube ukwakheka okufanayo okusetshenziselwe ukwaba lelo bhlokhi lememori,
    ///
    /// * `new_size` kufanele ibe nkulu kunoziro.
    ///
    /// * `new_size`, lapho iqoqelwa kokuphindwe kaningi kwe-`layout.align()`, akumele ichichime (isb., inani elihlanganisiwe kufanele libe ngaphansi kuka-`usize::MAX`).
    ///
    /// (Ukwehliswa kwesandiso kungahlinzeka ngemikhawulo ethile ekuziphatheni, isb. Ukuqinisekisa ikheli le-sentinel noma i-pointer eyize ekuphenduleni isicelo sokwabiwa okungu-zero.)
    ///
    /// # Errors
    ///
    /// Ibuyisa okungasebenzi uma isakhiwo esisha singahlangabezani nosayizi nezingqinamba zokuqondanisa zomhlinzeki, noma uma ukwabiwa kabusha ngenye indlela kwehluleka.
    ///
    /// Ukusebenza kuyakhuthazwa ukuthi kubuyiselwe emuva ukukhathala kwememori kunokushaywa uvalo noma ukukhipha isisu, kepha lokhu akuyona imfuneko eqinile.
    /// (Ngokukodwa: kusemthethweni * ukusebenzisa le trait engaphezulu komtapo wolwazi owabelwe bomdabu ovumela ukukhathala kwememori.)
    ///
    /// Amaklayenti afisa ukukhipha isisombululo ekubhekaneni nephutha lokwabiwa kabusha kwezindawo ayakhuthazwa ukuba abize umsebenzi we-[`handle_alloc_error`], kunokufaka ngqo ku-`panic!` noma okufanayo.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i `new_size` ayichichimi.
        // `layout.align()` ivela ku-`Layout` ngakho-ke iqinisekisiwe ukuthi isebenza.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`new_layout` inkulu kuneqanda.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // UKUPHEPHA: ibhulokhi eyabiwe ngaphambilini ayikwazi ukweqa ibhlokhi elisanda kwabiwa.
            // Inkontileka yezokuphepha ye `dealloc` kufanele igcinwe yilowo ofonayo.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}