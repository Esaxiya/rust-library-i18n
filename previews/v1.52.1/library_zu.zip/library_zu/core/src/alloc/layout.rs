use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ngenkathi lo msebenzi usetshenziswa endaweni eyodwa futhi ukuqaliswa kwawo kungalandelwa, imizamo yangaphambilini yokwenza kanjalo yenze i rustc yehle kancane:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Ukuhlelwa kwebhulokhi yememori.
///
/// Isibonelo se `Layout` sichaza ukwakheka okuthile kwememori.
/// Wakha i-`Layout` njengokufaka ongayinikeza isabelo.
///
/// Zonke izakhiwo zinosayizi ohambisanayo nokuqondaniswa kwamandla-amabili.
///
/// (Qaphela ukuthi ukwakheka *akudingeki* ukuthi kube nosayizi ongewona u-zero, noma i-`GlobalAlloc` idinga ukuthi zonke izicelo zememori zingabi ngosayizi.
/// Oshaya ucingo kufanele aqinisekise ukuthi izimo ezinjengalezi ziyahlangatshezwa, asebenzise ama-allocator athile anezidingo ezikhululekile, noma asebenzise isikhombimsebenzisi esivumelana kakhulu ne `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // usayizi webhulokhi yememori eceliwe, elinganiswa ngamabhayithi.
    size_: usize,

    // ukuqondaniswa kwebhulokhi yememori eceliwe, elinganiswa ngamabhayithi.
    // siqinisekisa ukuthi lokhu kuhlala kungamandla amabili, ngoba ama-API afana ne `posix_memalign` ayayidinga futhi kuyisithiyo esifanele ukuphoqelela abakhi be-Layout.
    //
    //
    // (Noma kunjalo, asidingi ngokufanisa i-`align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Yakha i-`Layout` kusuka ku-`size` ne-`align` enikeziwe, noma ibuyisa i-`LayoutError` uma kunanoma iyiphi yale mibandela elandelayo engahlangabezwanga:
    ///
    /// * `align` akumele kube uziro,
    ///
    /// * `align` kumele kube amandla amabili,
    ///
    /// * `size`, lapho iqoqelwa kokuphindwe kaningi kwe-`align`, akumele ichichime (isb., inani elihlanganisiwe kufanele libe ngaphansi noma lilingane no-`usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (amandla-amabili asho ukuqondanisa!=0.)

        // Usayizi ohlanganisiwe ngu:
        //   size_rounded_up=(size + qondanisa, 1)&! (qondanisa, 1);
        //
        // Siyazi ngenhla ukuthi ukuqondanisa!=0.
        // Uma ukungeza (qondanisa, 1) kungachichimi, khona-ke ukuqoqwa kuzolunga.
        //
        // Ngakolunye uhlangothi,&-masking with! (Qondanisa, 1) kuzokhipha ama-oda we-oda eliphansi kuphela.
        // Ngakho-ke uma ukuchichima kwenzeka ngesamba, i-&-mask Ayikwazi ukususa ngokwanele ukulungisa lokho kuchichima.
        //
        //
        // Ngenhla kusho ukuthi ukubheka ukugcwala kokufingqa kuyadingeka futhi kwanele.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // UKUPHEPHA: imibandela ye `from_size_align_unchecked` ibilokhu ikhona
        // kuhlolwe ngenhla.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Kwakha ukwakheka, kudlula konke ukuhlola.
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile njengoba ungaqinisekisi imibandela evela ku-[`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`align` inkulu kuneqanda.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Usayizi omncane wama-byte webhulokhi yememori yalolu hlu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Ukuqondanisa okuncane kwe-byte kwebhulokhi yememori yalolu hlu.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Yakha i-`Layout` efanelekile ukubamba inani lohlobo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // UKUPHEPHA: ukuqondanisa kuqinisekiswe yi-Rust ukuba namandla amabili futhi
        // usayizi + wokuqondanisa combo uqinisekisiwe ukulingana esikhaleni sethu sekheli.
        // Ngenxa yalokho sebenzisa umakhi ongamakiwe lapha ukugwema ukufaka ikhodi i panics uma ingalungiselelwe kahle ngokwanele.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Kukhiqizwa ukwakheka okuchaza irekhodi ebingasetshenziswa ukwaba isakhiwo sokweseka se-`T` (okungaba yi-trait noma olunye uhlobo olungafakwanga usayizi njengocezu).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // UKUPHEPHA: bona umqondo ku-`new` ukuthi kungani lokhu kusebenzisa okuhlukile okungaphephile
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Kukhiqizwa ukwakheka okuchaza irekhodi ebingasetshenziswa ukwaba isakhiwo sokweseka se-`T` (okungaba yi-trait noma olunye uhlobo olungafakwanga usayizi njengocezu).
    ///
    /// # Safety
    ///
    /// Lo msebenzi uphephile ukubizwa uma izimo ezilandelayo zibamba:
    ///
    /// - Uma i-`T` iyi-`Sized`, lo msebenzi uhlala uphephile ukuwubiza.
    /// - Uma umsila ongalinganiselwe we `T` uthi:
    ///     - i-[slice], khona-ke ubude bomsila wocezu kufanele bube inombolo ephelele, nosayizi wenani *eliphelele*(ubude bomsila obunamandla + isiqalo esilinganiselwe ngokwezibalo) kufanele lilingane ku-`isize`.
    ///     - i-[trait object], khona-ke ingxenye ekhombayo yesikhombi kufanele ikhombe ku-vtable evumelekile yohlobo `T` etholwe yi-coeringion engalingisi, nosayizi wenani *lonke*(amandla omsila onamandla + isiqalo sesilinganiso sobukhulu) kufanele ilingane ku-`isize`.
    ///
    ///     - i (unstable) [extern type], khona-ke lo msebenzi uhlala uphephile ukuwushayela, kepha kwangathi i panic noma ngenye indlela ingabuyisa inani elingalungile, njengoba ukwakheka kohlobo lwangaphandle kungaziwa.
    ///     Lokhu kuziphatha okufanayo ne [`Layout::for_value`] kusethenjwa somsila wohlobo lwangaphandle.
    ///     - ngaphandle kwalokho, ngokuvunyelwe akuvunyelwe ukubiza lo msebenzi.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // UKUPHEPHA: sidlulisa izimfuneko zale misebenzi kumuntu oshayayo
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // UKUPHEPHA: bona umqondo ku-`new` ukuthi kungani lokhu kusebenzisa okuhlukile okungaphephile
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Idala i-`NonNull` elengayo, kepha eqondaniswe kahle ngalolu Hlelo.
    ///
    /// Qaphela ukuthi inani lesikhombi lingamela isikhombisi esivumelekile, okusho ukuthi lokhu akumele kusetshenziswe njengenani le-"not yet initialized" sentinel.
    /// Izinhlobo ezabiwa ngobuvila kufanele zilandelele ukuqaliswa ngezinye izindlela.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // UKUPHEPHA: ukuqondanisa kuqinisekisiwe ukuthi akuyona i-zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Kwakha isakhiwo esichaza irekhodi elingabamba inani lesakhiwo esifanayo ne-`self`, kepha lokho futhi kuqondaniswe nokuqondanisa i-`align` (kukalwa ngamabhayithi).
    ///
    ///
    /// Uma i-`self` isivele ihlangabezana nokuqondiswa okunqunyiwe, bese ibuyisa i-`self`.
    ///
    /// Qaphela ukuthi le ndlela ayifaki noma yikuphi ukuphahlwa ngosayizi ophelele, noma ngabe isakhiwo esibuyisiwe sinokulungiswa okuhlukile.
    /// Ngamanye amagama, uma i-`K` inosayizi 16, i-`K.align_to(32)` izobe * isenosayizi 16.
    ///
    /// Ibuyisa iphutha uma inhlanganisela ye-`self.size()` ne-`align` enikeziwe yephula imibandela efakwe ku-[`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ibuyisa inani lokunamathisela okufanele silifake ngemuva kwe-`self` ukuqinisekisa ukuthi ikheli elilandelayo lizokwanelisa i-`align` (kulinganiswa ngamabhayithi).
    ///
    /// isb., uma i-`self.size()` ingu-9, khona-ke i-`self.padding_needed_for(4)` ibuyisa u-3, ngoba lelo inani elincane lama-byte we-padding adingekayo ukuthola ikheli eliqondaniswe no-4 (kucatshangwa ukuthi ibhulokhi yememori ehambisanayo iqala kukheli eliqondaniswe no-4).
    ///
    ///
    /// Inani lokubuyisa lalo msebenzi alinayo incazelo uma i-`align` kungewona amandla amabili.
    ///
    /// Qaphela ukuthi ukusetshenziswa kwenani elibuyisiwe kudinga ukuthi i-`align` ibe ngaphansi noma ilingane nokuqondaniswa kwekheli lokuqala lebhulokhi yonke eyabiwe yememori.Enye indlela yokwanelisa lesi simiso ukuqinisekisa i-`align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Inani elihlanganisiwe ngu:
        //   len_rounded_up=(len + qondanisa, 1)&! (qondanisa, 1);
        // bese sibuyisa umehluko we-padding: `len_rounded_up - len`.
        //
        // Sisebenzisa i-modular arithmetic kuyo yonke:
        //
        // 1. ukuqondanisa kuqinisekisiwe ukuthi kube> 0, ngakho-ke qondanisa, 1 kusebenza njalo.
        //
        // 2.
        // `len + align - 1` ingachichima okungenani i-`align - 1`, ngakho-ke i-&-mask ene-`!(align - 1)` izoqinisekisa ukuthi esimweni sokuchichima, i-`len_rounded_up` ngokwayo izoba ngu-0.
        //
        //    Ngakho-ke i-padding ebuyisiwe, lapho ingezwe ku-`len`, iveza u-0, okwanelisa kancane ukuqondanisa i `align`.
        //
        // (Vele, imizamo yokwaba amabhulokhi enkumbulo osayizi bawo kanye ne-padding echichima ngale ndlela engenhla kufanele kubangele umabi ukuthi avele iphutha noma kunjalo.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Kwakha isakhiwo ngokuzungeza usayizi walesi sakhiwo kuze kube kokuqondaniswa kwesakhiwo okuningi.
    ///
    ///
    /// Lokhu kulingana nokungeza umphumela we-`padding_needed_for` kusayizi wamanje wesakhiwo.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Lokhu akukwazi ukugcwala.Ukucaphuna kokungenzeki kwe-Layout:
        // > `size`, lapho iqoqelwa kokuphindwe kaningi kwe-`align`,
        // > akufanele ichichime (isb., inani elihlanganisiwe kufanele libe ngaphansi kuka-
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Kwakha ukwakheka okuchaza irekhodi lezimo ze-`n` ze-`self`, ngenani elifanele lokugoqa phakathi ngakunye ukuze kuqinisekiswe ukuthi isenzakalo ngasinye sinikezwa ubukhulu nosayizi oceliwe.
    /// Empumelelweni, ibuyisa i-`(k, offs)` lapho i-`k` kungukuhlelwa kwamalungu afanayo futhi i-`offs` ibanga eliphakathi kokuqala kwento ngayinye kumalungu afanayo.
    ///
    /// Ekuchichimeni kwezibalo, kubuyisa i-`LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Lokhu akukwazi ukugcwala.Ukucaphuna kokungenzeki kwe-Layout:
        // > `size`, lapho iqoqelwa kokuphindwe kaningi kwe-`align`,
        // > akufanele ichichime (isb., inani elihlanganisiwe kufanele libe ngaphansi kuka-
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // UKUPHEPHA: I-self.align isivele yaziwa ukuthi isebenza futhi i-alloc_size ibikade ikhona
        // sekugxilwe kakade.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Kwakha isakhiwo esichaza irekhodi le-`self` elilandelwa yi-`next`, kufaka phakathi noma yikuphi ukupakisha okudingekayo ukuqinisekisa ukuthi i-`next` izohanjiswa kahle, kepha *akukho ukugoqa okulandelanayo*.
    ///
    /// Ukuze uqondanise ukwakheka kokumelwa kwe-C `repr(C)`, kufanele ushayele i-`pad_to_align` ngemuva kokwelula isakhiwo nazo zonke izinkambu.
    /// (Ayikho indlela yokufanisa ukwakheka kokumelwa kwe-Rust okuzenzakalelayo `repr(Rust)`, as it is unspecified.)
    ///
    /// Qaphela ukuthi ukuqondaniswa kokuhlelwa okuzoba yisilinganiso esiphezulu kwalezo ze-`self` ne-`next`, ukuze kuqinisekiswe ukuqondaniswa kwezingxenye zombili.
    ///
    /// Ibuyisa i-`Ok((k, offset))`, lapho i-`k` ingukuhlelwa kwerekhodi elihlanganisiwe futhi i-`offset` iyindawo ehlobene, kuma-byte, ekuqaleni kwe-`next` efakwe ngaphakathi kwerekhodi eliqinisekisiwe (kucatshangwa ukuthi irekhodi ngokwalo liqala nge-offset 0).
    ///
    ///
    /// Ekuchichimeni kwezibalo, kubuyisa i-`LayoutError`.
    ///
    /// # Examples
    ///
    /// Ukubala ukwakheka kwesakhiwo se-`#[repr(C)]` nokukhishwa kwezinkambu kusuka kuzakhiwo zayo zemikhakha:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Khumbula ukuqedela nge-`pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // hlola ukuthi kuyasebenza yini
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Idala ukwakheka okuchaza irekhodi lezimo ze-`n` ze-`self`, ngaphandle kokunamathisela phakathi kwesimo ngasinye.
    ///
    /// Qaphela ukuthi, ngokungafani ne-`repeat`, i-`repeat_packed` ayiqinisekisi ukuthi izimo eziphindaphindwayo ze-`self` zizoqondaniswa kahle, noma ngabe isibonelo esinikeziwe se-`self` siqondaniswe kahle.
    /// Ngamanye amagama, uma ukwakheka okubuyiswe yi-`repeat_packed` kusetshenziselwa ukwaba uhlu, akuqinisekisiwe ukuthi zonke izinto ezikulolu hlu zizoqondaniswa kahle.
    ///
    /// Ekuchichimeni kwezibalo, kubuyisa i-`LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Kwakha isakhiwo esichaza irekhodi le-`self` elilandelwa yi-`next` ngaphandle kokunamathisela okungeziwe phakathi kwalokhu okubili.
    /// Njengoba kungafakwa i-padding, ukuqondaniswa kwe-`next` akubalulekile, futhi akufakiwe * nhlobo kusakhiwo esivelayo.
    ///
    ///
    /// Ekuchichimeni kwezibalo, kubuyisa i-`LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Kwakha isakhiwo esichaza irekhodi le-`[T; n]`.
    ///
    /// Ekuchichimeni kwezibalo, kubuyisa i-`LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Amapharamitha anikezwe i `Layout::from_size_align` noma omunye umakhi we `Layout` awanelisi izingqinamba zawo ezibhalwe phansi.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (sikudinga lokhu ukuthola okungaphansi kwe trait Iphutha)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}