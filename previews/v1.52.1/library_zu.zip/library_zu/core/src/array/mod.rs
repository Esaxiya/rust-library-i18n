//! Ukuqaliswa kwezinto ezifana ne-`Eq` ngobude obulinganiselwe obufinyelela kubude obuthile.
//! Ekugcineni, kufanele sikwazi ukujwayela bonke ubude.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// Iguqula ireferensi ibe yi-`T` iye kusethenjwa kumalungu afanayo obude 1 (ngaphandle kokukopisha).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // UKUPHEPHA: Ukuguqula i-`&T` kuye ku-`&[T; 1]` kunomsindo.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Iguqula ireferensi eguqukayo ibe yi-`T` iye kusethenjwa esiguquguqukayo kubude obude 1 (ngaphandle kokukopisha).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // UKUPHEPHA: Ukuguqula i-`&mut T` kuye ku-`&mut [T; 1]` kunomsindo.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// I-Utility trait isetshenziswe kuphela kumalungu afanayo osayizi ongaguquki
///
/// Le trait ingasetshenziselwa ukusebenzisa ezinye i-traits kumalungu afanayo osayizi abalinganayo ngaphandle kokubangela ukuqunjelwa kwemethadatha okuningi.
///
/// I-trait imakwe njengengaphephile ukuze ikhawulele abaqalisi ukuthi bafinyelele kusayizi olinganiselwe.
/// Umsebenzisi wale trait angacabanga ukuthi abaqalisi banesakhiwo esiqondile kwimemori yamalungu afanayo osayizi (ngokwesibonelo, ukuqaliswa okungaphephile).
///
///
/// Qaphela ukuthi i-traits [`AsRef`] ne-[`AsMut`] zinikela ngezindlela ezifanayo zezinhlobo ezingase zingabi ukuhlelwa kosayizi ongaguquki.
/// Abasebenza kufanele bakhethe lezo traits esikhundleni salokho.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Iguqula uhlu lube lucezu olungaphenduki
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Iguqula uhlu lube kwisilayidi esiguquguqukayo
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Uhlobo lwephutha lubuyile lapho ukuguqulwa kusuka kusilayidi kuya kumalungu afanayo kwehluleka.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // UKUPHEPHA: kulungile ngoba sibheke nje ukuthi ubude buyalingana
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // UKUPHEPHA: kulungile ngoba sibheke nje ukuthi ubude buyalingana
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: amanye ama-impls angabalulekile kakhulu ayashiywa ukunciphisa ukuqhuma kwekhodi
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// Iqhathanisa ukuqhathaniswa kwamalungu afanayo [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Ukufakwa okuzenzakalelayo akukwazi ukwenziwa ngemithi ejwayelekile ngoba i `[T; 0]` ayidingi ukuthi iDifolthi isetshenziswe, futhi ukuba namabhulokhi e-impl ahlukene wezinombolo ezahlukahlukene akusekelwa okwamanje.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// Ibuyisa uhlu olunosayizi ofanayo no-`self`, nomsebenzi `f` usetshenziswe entweni ngayinye ngokulandelana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // UKUPHEPHA: siyazi ngokuqinisekile ukuthi le iterator izokhipha i `N` ncamashi
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zip up' ukuhlelwa okubili kuhlu olulodwa ngazimbili.
    ///
    /// `zip()` ibuyisa uhlu olusha lapho yonke into iyiTuple lapho into yokuqala ivela kuhlu lokuqala, bese into yesibili ivela kumalungu afanayo wesibili.
    ///
    /// Ngamanye amagama, i-zips ukuhlelwa okumbili ndawonye, kube okukodwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // UKUPHEPHA: siyazi ngokuqinisekile ukuthi le iterator izokhipha i `N` ncamashi
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Ibuyisa isilayidi esiqukethe wonke amalungu afanayo.Ilingana ne-`&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Ibuyisa isilayidi esiguquguqukayo esiqukethe wonke amalungu afanayo.
    /// Ilingana ne-`&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Uboleka into ngayinye bese ubuyisa uhlu oluningi lwezethenjwa ngosayizi ofanayo no-`self`.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Le ndlela ilusizo ikakhulukazi uma ihlanganiswe nezinye izindlela, njenge-[`map`](#method.map).
    /// Ngale ndlela, ungakugwema ukuhambisa uhlu lwangempela uma izinto zalo zingezona i `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // Sisengakwazi ukufinyelela uhlu lokuqala: alususiwe.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // UKUPHEPHA: siyazi ngokuqinisekile ukuthi le iterator izokhipha i `N` ncamashi
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Iboleka into ngayinye ngokuguqukayo futhi ibuyise uhlu lwezethenjwa ezingaguquguquka ezinosayizi ofanayo no-`self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // UKUPHEPHA: siyazi ngokuqinisekile ukuthi le iterator izokhipha i `N` ncamashi
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// Hudula izinto ze-`N` kusuka ku-`iter` bese uzibuyisela njengamalungu afanayo.
/// Uma i-iterator ikhiqiza izinto ezingaphansi kwezingu-`N`, lo msebenzi ukhombisa ukusebenza okungachazwanga.
///
///
/// Bona i [`collect_into_array`] ukuthola eminye imininingwane.
///
/// # Safety
///
/// Kusezandleni zoshayayo ukuqinisekisa ukuthi i-`iter` ikhiqiza okungenani izinto ze-`N`.
/// Ukwephula lesi simo kubangela isimilo esingachazeki.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: I-`TrustedLen` nansi yokuhlola okuthile.Lokhu nje
    // Umsebenzi wangaphakathi, ngakho-ke zizwe ukhululekile ukususa uma lokhu kubopha kuvela kungumbono omubi.
    // Uma kunjalo, khumbula ukususa futhi i-`debug_assert!` eboshwe ngezansi ngezansi!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // UKUPHEPHA: kumbozwe yinkontileka yomsebenzi.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// Kudonswa izinto ze-`N` kusuka ku-`iter` bese kuzibuyisela njengamalungu afanayo.Uma i-iterator ikhiqiza izinto ezingaphansi kwezingu-`N`, i-`None` iyabuyiselwa futhi zonke izinto esezikhishiwe seziyekiwe.
///
/// Njengoba i-iterator idluliswa njengesethenjwa esiguquguqukayo futhi lo msebenzi ubiza i-`next` ezikhathini eziningi ze-`N`, i-iterator isengasetshenziswa ngemuva kwalokho ukuthola izinto ezisele.
///
///
/// Uma i-`iter.next()` itatazela, zonke izinto esezivele zikhishwe yi-iterator ziyadedelwa.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // UKUPHEPHA: Amalungu afanayo angenalutho ahlala njalo futhi awanakho okufikayo okusemthethweni.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // UKUPHEPHA: lesi silayidi esiluhlaza sizoqukatha izinto eziqaliwe kuphela.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // UKUPHEPHA: I-`guard.initialized` iqala ngo-0, inyuswa ngoyedwa kufayela le-
        // iluphu futhi iluphu likhanseliwe uma selifinyelele ku-N (okuyi-`array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Bheka ukuthi ngabe uhlu lonke lwaqalwa yini.
        if guard.initialized == N {
            mem::forget(guard);

            // UKUPHEPHA: isimo esingenhla sifakazela ukuthi zonke izinto zikhona
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Lokhu kufinyelelwa kuphela uma i-iterator ikhathele ngaphambi kokuthi i-`guard.initialized` ifinyelele ku-`N`.
    //
    // Futhi qaphela ukuthi i `guard` ilahliwe lapha, ilahla zonke izinto eseziqalisiwe.
    None
}