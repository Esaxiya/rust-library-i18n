//! Ichaza i-iterator ye-`IntoIter` yama-arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// I-iterator ye-X-X yenani.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Nayi uhlu esisebenza ngalo ngaphezulu.
    ///
    /// Izinto ezinenkomba `i` lapho i-`alive.start <= i < alive.end` ingakakhishwa khona okwamanje futhi ingukungena okuvumelekile kwamalungu afanayo.
    /// Izinto ezinama-indices i-`i < alive.start` noma i-`i >= alive.end` seziveziwe vele futhi akumele ziphinde zitholakale!Lezo zinto ezifile kungenzeka zisesimweni esingaqanjwanga ngokuphelele!
    ///
    ///
    /// Ngakho-ke abangenayo yile:
    /// - `data[alive]` uyaphila (isb. uqukethe izinto ezivumelekile)
    /// - `data[..alive.start]` futhi i-`data[alive.end..]` ifile (okusho ukuthi izinto zazivele zifundwa futhi akumele ziphinde zithintwe!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Izinto ezise-`data` ezingakakhishwa okwamanje.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Kwakha i-iterator entsha ngaphezulu kwe-`array` enikeziwe.
    ///
    /// *Qaphela*: le ndlela ingahle yehliswe ku-future, ngemuva kwe [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Uhlobo lwe `value` luyi `i32` lapha, esikhundleni se `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // UKUPHEPHA: Isiguquli lapha empeleni siphephile.Amadokhumenti e-`MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` kuqinisekisiwe ukuthi ngosayizi ofanayo nokuqondaniswa
        // > njengo-`T`.
        //
        // Amadokhumenti akhombisa nokudluliswa kusuka kumalungu afanayo we-`MaybeUninit<T>` kuya kuhlu lwe-`T`.
        //
        //
        // Ngalokho, lokhu kuqalwa kuyanelisa okungangenisi.

        // FIXME(LukasKalbertodt): empeleni sebenzisa i `mem::transmute` lapha, uma nje isebenza nama-const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Kuze kube yileso sikhathi, singasebenzisa i-`mem::transmute_copy` ukwenza ikhophi elincanyana njengohlobo oluhlukile, bese sikhohlwa i-`array` ukuze ingadonswa.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Ibuyisa isilayidi esingaguquguquki sazo zonke izinto ezingakakhishwa okwamanje.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // UKUPHEPHA: Siyazi ukuthi zonke izinto ezingaphakathi kwe `alive` ziqaliswe kahle.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Ibuyisa isilayidi esiguquguqukayo sezinto zonke ezingakakhishwa okwamanje.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // UKUPHEPHA: Siyazi ukuthi zonke izinto ezingaphakathi kwe `alive` ziqaliswe kahle.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Thola inkomba elandelayo ngaphambili.
        //
        // Ukwandisa i-`alive.start` nge-1 kugcina okungahleliwe maqondana ne `alive`.
        // Kodwa-ke, ngenxa yalolu shintsho, okwesikhashana, indawo ephilayo ayisiyona i-`data[alive]`, kepha i-`data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Funda into kusuka kumalungu afanayo.
            // UKUPHEPHA: I-`idx` iyinkomba esifundeni sangaphambili se-"alive" se-
            // uhlu.Ukufunda le nto kusho ukuthi i-`data[idx]` ithathwa njengefile manje (okungukuthi ungathinti).
            // Njengoba i `idx` bekungukuqala kwendawo ephilayo, indawo ephilayo manje seyi `data[alive]` futhi, ibuyisa bonke abangenayo.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Thola inkomba elandelayo ngemuva.
        //
        // Ukwehla kwe-`alive.end` ngo-1 kugcina okungaguquki maqondana ne `alive`.
        // Kodwa-ke, ngenxa yalolu shintsho, okwesikhashana, indawo ephilayo ayisiyona i-`data[alive]`, kepha i-`data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Funda into kusuka kumalungu afanayo.
            // UKUPHEPHA: I-`idx` iyinkomba esifundeni sangaphambili se-"alive" se-
            // uhlu.Ukufunda le nto kusho ukuthi i-`data[idx]` ithathwa njengefile manje (okungukuthi ungathinti).
            // Njengoba i `idx` bekuwukuphela kwendawo ephilayo, indawo ephilayo manje sekuyi-`data[alive]` futhi, ibuyisa bonke abangenayo.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // UKUPHEPHA: Lokhu kuphephile: I-`as_mut_slice` ibuyisa ngqo ucezu olungaphansi
        // wezinto ezingakakhishelwa ngaphandle okusasele ukuthi zilahlwe.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Awusoze wachichima ngenxa yokungenayo `ephilayo.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterator ibika impela ubude obufanele.
// Inani lezinto ze-"alive" (ezisazokhishwa) ubude bebanga le-`alive`.
// Leli banga lehliswa ngobude ku-`next` noma ku-`next_back`.
// Kuhlala kwehliswa ngu-1 kulezo zindlela, kepha kuphela uma i-`Some(_)` ibuyisiwe.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Qaphela, asidingi ngempela ukufanisa uhla oluphilayo olufanayo, ngakho-ke singamane silingane ne-offset 0 kungakhathalekile ukuthi ikuphi i `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Hlanganisa zonke izinto eziphilayo.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Bhala i-clone kuhlu olusha, bese ubuyekeza ububanzi bayo obuphilayo.
            // Uma i-cloning panics, sizolahla kahle izinto zangaphambilini.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Phrinta kuphela izinto ebezingakakhishwa okwamanje: asisakwazi ukufinyelela izinto ezitheliwe.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}