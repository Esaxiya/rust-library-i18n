//! Le module yangaphakathi esetshenziswa yi-ifmt!isikhathi sokusebenza.Lezi zakhiwo zikhishwa kumalungu afanayo we-static ukuhlanganisa izintambo zefomethi ngaphambi kwesikhathi.
//!
//! Lezi zincazelo ziyafana nokufana kwazo kwe-`ct`, kepha ziyehluka ngokuthi lezi zingabiwa ngokwezibalo futhi zenzelwe kancane isikhathi sokusebenza
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ukuqondanisa okungenzeka kungacelwa njengengxenye yomyalo wokufometha.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Inkomba yokuthi okuqukethwe kufanele kuqondaniswe kwesobunxele.
    Left,
    /// Inkomba yokuthi okuqukethwe kufanele kuqondaniswe kahle.
    Right,
    /// Inkomba yokuthi okuqukethwe kufanele kuqondaniswe maphakathi.
    Center,
    /// Akukho ukuqondanisa okuceliwe.
    Unknown,
}

/// Isetshenziswe yi-[width](https://doc.rust-lang.org/std/fmt/#width) ne-[precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Okucacisiwe ngenombolo yangempela, kugcina inani
    Is(usize),
    /// Icacisiwe kusetshenziswa i-`$` ne-`*` syntaxes, igcina inkomba ku-`args`
    Param(usize),
    /// Akucacisiwe
    Implied,
}