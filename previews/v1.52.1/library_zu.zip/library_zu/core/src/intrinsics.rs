//! Ukuhlanganiswa kwangaphakathi.
//!
//! Izincazelo ezihambisanayo ziku-`compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ukusetshenziswa okuhambisanayo kwe-const kuku-`compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # UConst intrinsics
//!
//! Note: noma yiziphi izinguquko kubunzulu be-intrinsics kufanele zixoxwe nethimba lolimi.
//! Lokhu kufaka phakathi izinguquko ekuzinzileni kobumbano.
//!
//! Ukuze wenze ukusebenziseka kwangaphakathi ngesikhathi sokuhlanganiswa, umuntu adinga ukukopisha ukusetshenziswa kusuka ku-<https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> kuye ku-`compiler/rustc_mir/src/interpret/intrinsics.rs` bese engeza i-`#[rustc_const_unstable(feature = "foo", issue = "01234")]` ku-intrinsic.
//!
//!
//! Uma i-intrinsic kufanele isetshenziswe kusuka ku-`const fn` enesibaluli se-`rustc_const_stable`, imfanelo yangaphakathi kufanele ibe yi-`rustc_const_stable`, nayo.
//! Ushintsho olunjalo akumele lwenziwe ngaphandle kokubonisana ne-T-lang, ngoba kubhaka isici olimini olungenakuphindaphindwa kwikhodi yomsebenzisi ngaphandle kokuxhaswa kwabahlanganisi.
//!
//! # Volatiles
//!
//! I-intrinsics eguquguqukayo ihlinzeka ngemisebenzi ehlose ukwenza kwimemori ye-I/O, eqinisekisiwe ukuthi ayizukuhlelwa kabusha ngumhlanganisi kwamanye ama-intrinsics aqinile.Bona imibhalo ye-LLVM ku-[[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! I-intrinsics ye-athomu inikezela ngokusebenza okuvamile kwe-athomu kumagama omshini, ngokuhleleka okuningi kwememori.Balalela ama-semantics afanayo ne-C++ 11.Bona imibhalo ye-LLVM ku-[[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Ukuvuselelwa okusheshayo koku-oda imemori:
//!
//! * Zuza, umgoqo wokuthola ingidi.Ukufunda nokubhala okulandelayo kwenzeka ngemuva kwesithiyo.
//! * Ukukhululwa, isithiyo sokukhulula ukukhiya.Ukufunda nokubhala kwangaphambilini kwenzeka ngaphambi kwesithiyo.
//! * Ukusebenza ngokulandelana okulandelanayo, imisebenzi elandelana ngokulandelana iqinisekisiwe ukuthi yenzeke ngokulandelana.Le yimodi ejwayelekile yokusebenza nezinhlobo ze-athomu futhi ilingana ne-Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Lokhu kungeniswa kusetshenziselwa ukwenza lula izixhumanisi ze-intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // UKUPHEPHA: bheka i `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, lawa ma-intrinsics athatha izikhombisi ezingavuthiwe ngoba aguqula imemori engafani, engavumelekile ku-`&` noma ku-`&mut`.
    //

    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::SeqCst`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::Acquire`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::Release`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::AcqRel`] njenge-`success` ne-[`Ordering::Acquire`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::Relaxed`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::SeqCst`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::SeqCst`] njenge-`success` ne-[`Ordering::Acquire`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::Acquire`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange` ngokudlula i-[`Ordering::AcqRel`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::SeqCst`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::Acquire`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::Release`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::AcqRel`] njenge-`success` ne-[`Ordering::Acquire`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::Relaxed`] njengamapharamitha we-`success` ne-`failure`.
    ///
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::SeqCst`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::SeqCst`] njenge-`success` ne-[`Ordering::Acquire`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::Acquire`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Igcina inani uma inani lamanje lifana nenani le-`old`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`compare_exchange_weak` ngokudlula i-[`Ordering::AcqRel`] njenge-`success` ne-[`Ordering::Relaxed`] njengamapharamitha we-`failure`.
    /// Ngokwesibonelo, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ukulayisha inani lamanje lesikhombi.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`load` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ukulayisha inani lamanje lesikhombi.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`load` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ukulayisha inani lamanje lesikhombi.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`load` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Igcina inani endaweni yememori ecacisiwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`store` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Igcina inani endaweni yememori ecacisiwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`store` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Igcina inani endaweni yememori ecacisiwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`store` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Igcina inani endaweni yememori ecacisiwe, ibuyisa inani elidala.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`swap` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina inani endaweni yememori ecacisiwe, ibuyisa inani elidala.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`swap` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina inani endaweni yememori ecacisiwe, ibuyisa inani elidala.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`swap` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina inani endaweni yememori ecacisiwe, ibuyisa inani elidala.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`swap` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Igcina inani endaweni yememori ecacisiwe, ibuyisa inani elidala.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`swap` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ingeza kunani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_add` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ingeza kunani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_add` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ingeza kunani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_add` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ingeza kunani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_add` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ingeza kunani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_add` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Susa kunani lamanje, ubuyise inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_sub` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Susa kunani lamanje, ubuyise inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_sub` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Susa kunani lamanje, ubuyise inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_sub` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Susa kunani lamanje, ubuyise inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_sub` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Susa kunani lamanje, ubuyise inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_sub` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kancane kancane nenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_and` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane nenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_and` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane nenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_and` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane nenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_and` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane nenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_and` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// I-Bitwise nand nenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwalesi sici luyatholakala kuhlobo lwe-[`AtomicBool`] ngendlela ye-`fetch_nand` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand nenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwalesi sici luyatholakala kuhlobo lwe-[`AtomicBool`] ngendlela ye-`fetch_nand` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand nenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala kuhlobo lwe-[`AtomicBool`] ngendlela ye-`fetch_nand` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand nenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwalesi sici luyatholakala kuhlobo lwe-[`AtomicBool`] ngendlela ye-`fetch_nand` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise nand nenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwalesi sici luyatholakala kuhlobo lwe-[`AtomicBool`] ngendlela ye-`fetch_nand` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Kancane kancane noma ngenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_or` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane noma ngenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_or` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane noma ngenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_or` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane noma ngenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_or` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Kancane kancane noma ngenani lamanje, kubuyiselwa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_or` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// I-Bitwise xor ngenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_xor` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise xor ngenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_xor` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise xor ngenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_xor` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise xor ngenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_xor` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// I-Bitwise xor ngenani lamanje, ibuyisa inani langaphambilini.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ngendlela ye-`fetch_xor` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_max` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_max` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_max` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_max` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_max` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_min` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_min` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_min` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_min` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okusayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni eziphelele ezisayiniwe ze-[`atomic`] ngendlela ye-`fetch_min` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_min` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_min` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_min` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_min` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubuncane benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_min` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_max` ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_max` ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_max` ngokudlula i-[`Ordering::Release`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_max` ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ubukhulu benani lamanje kusetshenziswa ukuqhathanisa okungasayiniwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ezinhlotsheni ze-[`atomic`] ezingasayiniwe ngenombolo ye-`fetch_max` ngokudlula i-[`Ordering::Relaxed`] njenge-`order`.
    /// Ngokwesibonelo, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Okungaphakathi kwe `prefetch` kuwuphawu kukhiqizi wekhodi ukufaka umyalo wokulandela kuqala uma usekelwa;ngaphandle kwalokho, akuyona i-no-op.
    /// Ukulanda kuqala akunamthelela ekuziphatheni kohlelo kepha kungashintsha izici zalo zokusebenza.
    ///
    /// Impikiswano ye-`locality` kufanele ibe yinombolo engaguquguquki futhi iyisihlonzi sendawo yesikhashana esukela ku-(0), akukho ndawo, kuya ku-(3), ukugcina okwendawo ngokweqile.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Okungaphakathi kwe `prefetch` kuwuphawu kukhiqizi wekhodi ukufaka umyalo wokulandela kuqala uma usekelwa;ngaphandle kwalokho, akuyona i-no-op.
    /// Ukulanda kuqala akunamthelela ekuziphatheni kohlelo kepha kungashintsha izici zalo zokusebenza.
    ///
    /// Impikiswano ye-`locality` kufanele ibe yinombolo engaguquguquki futhi iyisihlonzi sendawo yesikhashana esukela ku-(0), akukho ndawo, kuya ku-(3), ukugcina okwendawo ngokweqile.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Okungaphakathi kwe `prefetch` kuwuphawu kukhiqizi wekhodi ukufaka umyalo wokulandela kuqala uma usekelwa;ngaphandle kwalokho, akuyona i-no-op.
    /// Ukulanda kuqala akunamthelela ekuziphatheni kohlelo kepha kungashintsha izici zalo zokusebenza.
    ///
    /// Impikiswano ye-`locality` kufanele ibe yinombolo engaguquguquki futhi iyisihlonzi sendawo yesikhashana esukela ku-(0), akukho ndawo, kuya ku-(3), ukugcina okwendawo ngokweqile.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Okungaphakathi kwe `prefetch` kuwuphawu kukhiqizi wekhodi ukufaka umyalo wokulandela kuqala uma usekelwa;ngaphandle kwalokho, akuyona i-no-op.
    /// Ukulanda kuqala akunamthelela ekuziphatheni kohlelo kepha kungashintsha izici zalo zokusebenza.
    ///
    /// Impikiswano ye-`locality` kufanele ibe yinombolo engaguquguquki futhi iyisihlonzi sendawo yesikhashana esukela ku-(0), akukho ndawo, kuya ku-(3), ukugcina okwendawo ngokweqile.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ucingo lwe-athomu.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::fence`] ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ucingo lwe-athomu.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::fence`] ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ucingo lwe-athomu.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::fence`] ngokudlula i-[`Ordering::Release`] njenge-`order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ucingo lwe-athomu.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::fence`] ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Isithiyo sememori esihlanganisa kuphela.
    ///
    /// Ukufinyelela kwememori akusoze kwahlelwa kabusha ngalesi sithiyo ngumhlanganisi, kepha ayikho imiyalo ezokhishelwa yona.
    /// Lokhu kufanelekile ekusebenzeni ngentambo efanayo engase ikhululwe, njengalapho uxhumana nabaphathi besiginali.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::compiler_fence`] ngokudlula i-[`Ordering::SeqCst`] njenge-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Isithiyo sememori esihlanganisa kuphela.
    ///
    /// Ukufinyelela kwememori akusoze kwahlelwa kabusha ngalesi sithiyo ngumhlanganisi, kepha ayikho imiyalo ezokhishelwa yona.
    /// Lokhu kufanelekile ekusebenzeni ngentambo efanayo engase ikhululwe, njengalapho uxhumana nabaphathi besiginali.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::compiler_fence`] ngokudlula i-[`Ordering::Acquire`] njenge-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Isithiyo sememori esihlanganisa kuphela.
    ///
    /// Ukufinyelela kwememori akusoze kwahlelwa kabusha ngalesi sithiyo ngumhlanganisi, kepha ayikho imiyalo ezokhishelwa yona.
    /// Lokhu kufanelekile ekusebenzeni ngentambo efanayo engase ikhululwe, njengalapho uxhumana nabaphathi besiginali.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::compiler_fence`] ngokudlula i-[`Ordering::Release`] njenge-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Isithiyo sememori esihlanganisa kuphela.
    ///
    /// Ukufinyelela kwememori akusoze kwahlelwa kabusha ngalesi sithiyo ngumhlanganisi, kepha ayikho imiyalo ezokhishelwa yona.
    /// Lokhu kufanelekile ekusebenzeni ngentambo efanayo engase ikhululwe, njengalapho uxhumana nabaphathi besiginali.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi luyatholakala ku-[`atomic::compiler_fence`] ngokudlula i-[`Ordering::AcqRel`] njenge-`order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Okungaphakathi komlingo okuthola incazelo yaso kusuka kuzimpawu ezinamathiselwe emsebenzini.
    ///
    /// Isibonelo, ukugeleza kwedatha kusebenzisa lokhu ukufaka ukuqinisekiswa oku-static ukuze i-`rustc_peek(potentially_uninitialized)` ibhekane nokuhlola kabili ukuthi ukugeleza kwedatha kukhombise ukuthi akuqalisiwe ngaleso sikhathi ekuhambeni kokulawula.
    ///
    ///
    /// Lokhu okungaphakathi akufanele kusetshenziswe ngaphandle komhlanganisi.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Ihambisa ukukhishwa kwenqubo.
    ///
    /// Uhlobo olusebenziseka kalula futhi oluzinzile lwalokhu kusebenza yi-[`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Yazisa i-optimizer ukuthi leli phuzu lekhodi alifinyeleleki, inika amandla ukwandiswa okwengeziwe.
    ///
    /// I-NB, lokhu kwehluke kakhulu kwi-`unreachable!()` macro: Ngokungafani ne-macro, okuyi-panics lapho isenziwa, kungukuziphatha okungachazwanga * ukufinyelela ikhodi ebhalwe ngalo msebenzi.
    ///
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Yazisa i-optimizer ukuthi isimo sihlala siyiqiniso.
    /// Uma isimo sinamanga, isimilo asichazeki.
    ///
    /// Ayikho ikhodi ekhiqizelwa le intrinsic, kepha i-optimizer izozama ukuyigcina (nesimo sayo) phakathi kwamaphasi, okungaphazamisa ukwenziwa kwekhodi ezungezile futhi kunciphise ukusebenza.
    /// Akufanele isetshenziswe uma i-invariant ingatholwa i-optimizer iyodwa, noma uma ingavumeli noma ikuphi ukulungiselelwa okuphawulekayo.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Ukusikisela kumhlanganisi ukuthi isimo se-branch kungenzeka sibe yiqiniso.
    /// Ibuyisa inani elidluliselwe kulo.
    ///
    /// Noma ikuphi ukusetshenziswa ngaphandle kwezitatimende ze-`if` kungenzeka kungabi nomthelela.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Ukusikisela kumhlanganisi ukuthi isimo se-branch kungenzeka sibe ngamanga.
    /// Ibuyisa inani elidluliselwe kulo.
    ///
    /// Noma ikuphi ukusetshenziswa ngaphandle kwezitatimende ze-`if` kungenzeka kungabi nomthelela.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Yenza isicupho se-breakpoint, ukuze ihlolwe yi-debugger.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn breakpoint();

    /// Usayizi wohlobo lwama-byte.
    ///
    /// Ngokuqondile, lokhu kungukususwa kwama-byte phakathi kwezinto ezilandelanayo zohlobo olufanayo, kufaka phakathi ukugoqwa kokuqondanisa.
    ///
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ukuqondanisa okuncane kohlobo.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Ukuqondanisa okuncanyelwayo kohlobo.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Usayizi wevelu ebaluliwe kuma-byte.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ukuqondanisa okudingekayo kwenani elibaluliwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ithola isigaxa sentambo esimile esiqukethe igama lohlobo.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ithola okokuhlonza okwehlukile emhlabeni wonke ngohlobo olucacisiwe.
    /// Lo msebenzi uzobuyisa inani elifanayo lohlobo kungakhathalekile ukuthi iyiphi i-crate efakwe kuyo.
    ///
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Unogada wemisebenzi engaphephile engeke yenziwa uma i-`T` ingahlali muntu:
    /// Lokhu ngokweqile kungaba yi-panic, noma kungenzi lutho.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Unogada wemisebenzi engaphephile engakwazi ukwenziwa uma i-`T` ingavumeli ukuqaliswa kwe-zero: Lokhu ngokweqile kungaba yi-panic, noma kungenzi lutho.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn assert_zero_valid<T>();

    /// Unogada wemisebenzi engaphephile engakwazi ukwenziwa uma i-`T` inamaphethini amancane angavumelekile: Lokhu ngokweqile kungaba yi panic, noma kungenzi lutho.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn assert_uninit_valid<T>();

    /// Ithola ireferensi ku-static `Location` ekhombisa ukuthi yabizelwa kuphi.
    ///
    /// Cabanga ukusebenzisa i-[`core::panic::Location::caller`](crate::panic::Location::caller) esikhundleni salokho.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Ihambisa inani ngaphandle kwesilinganiselo ngaphandle kokusebenzisa i-drop glue.
    ///
    /// Lokhu kutholakala nge-[`mem::forget_unsized`] kuphela;i-`forget` ejwayelekile isebenzisa i-`ManuallyDrop` esikhundleni.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Kutolika kabusha izingcezu zenani lohlobo oluthile njengezenye izinhlobo.
    ///
    /// Zombili lezi zinhlobo kumele zibe nosayizi ofanayo.
    /// Noma okwangempela, noma umphumela, kungenzeka kungabi yi-[invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ifana ngokomqondo nokunyakaza okuncane kohlobo oluthile kuya kolunye.Ikopisha izingcezwana ezisuka kunani lomthombo ziye kunani lokuya khona, bese ikhohlwa okwangempela.
    /// Ilingana ne-C's `memcpy` ngaphansi kwe-hood, njenge-`transmute_copy`.
    ///
    /// Ngoba i `transmute` ingumsebenzi owenziwa ngenani, ukuqondaniswa kwamanani *adlulisiwe ngokwawo* akuyona inkinga.
    /// Njenganoma yimuphi omunye umsebenzi, umhlanganisi usevele uqinisekisa ukuthi zombili i-`T` ne-`U` ziqondaniswe kahle.
    /// Kodwa-ke, lapho kudluliselwa amanani *akhomba kwenye indawo*(njengezikhombi, izinkomba, amabhokisi…), ofonayo kufanele aqinisekise ukuqondanisa okufanele kwamanani akhonjisiwe.
    ///
    /// `transmute` akuphephile ngendlela emangalisayo **.Kunezindlela eziningi kakhulu zokubangela i-[undefined behavior][ub] ngalo msebenzi.I `transmute` kufanele ibe yisinqumo sokugcina ngokuphelele.
    ///
    /// I [nomicon](../../nomicon/transmutes.html) inemibhalo eyengeziwe.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Kunezinto ezimbalwa i-`transmute` esebenziseka kuzo ngempela.
    ///
    /// Ukuguqula isikhombi sibe yisikhombi somsebenzi.Lokhu * akuphathekeki emishinini lapho izikhombi zomsebenzi nezikhombi zedatha zinosayizi abahlukahlukene.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Ukunweba impilo yonke, noma ukunciphisa impilo engaguquguquki.Lokhu kuthuthukile, akuphephile kakhulu i Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ungalahli ithemba: ukusetshenziswa okuningi kwe `transmute` kungatholakala ngezinye izindlela.
    /// Ngezansi kunezicelo ezijwayelekile ze-`transmute` ezingashintshwa ngokwakhiwa okuphephile.
    ///
    /// Ukuguqula i-bytes(`&[u8]`) eluhlaza iye ku-`u32`, `f64`, njll.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // sebenzisa i-`u32::from_ne_bytes` esikhundleni salokho
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // noma usebenzise i-`u32::from_le_bytes` noma i-`u32::from_be_bytes` ukucacisa ukuphela
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Ukuguqula isikhombi sibe yi-`usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Sebenzisa i-`as` cast esikhundleni
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Ukuguqula i-`*mut T` ibe yi-`&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Sebenzisa imali ebolekiwe esikhundleni salokho
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Ukuguqula i-`&mut T` ibe yi-`&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Manje, hlanganisa i-`as` bese uboleka kabusha, qaphela ukuthi ukuboshwa kwe-`as` `as` akuhambisani
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Ukuguqula i-`&str` ibe yi-`&[u8]`:
    ///
    /// ```
    /// // lena akuyona indlela enhle yokwenza lokhu.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ungasebenzisa i-`str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Noma, vele usebenzise intambo ye-byte, uma ukwazi ukulawula intambo ngokoqobo
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Ukuguqula i-`Vec<&T>` ibe yi-`Vec<Option<&T>>`.
    ///
    /// Ukudlulisa uhlobo lwangaphakathi lokuqukethwe kwesiqukathi, kufanele uqiniseke ukuthi awuphuli noma yikuphi ukungena kwesiqukathi.
    /// Okwe-`Vec`, lokhu kusho ukuthi kokubili usayizi *nokuqondaniswa* kwezinhlobo zangaphakathi kufanele kufane.
    /// Ezinye iziqukathi zingaxhomeka ngosayizi wohlobo, ukuqondanisa, noma i-`TypeId`, lapho kwenzeka ukuthi ukuhanjiswa kungenzeki nhlobo ngaphandle kokwephula okungenayo kweziqukathi.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // hlanganisa i-vector njengoba sizozisebenzisa kabusha ngokuhamba kwesikhathi
    /// let v_clone = v_orig.clone();
    ///
    /// // Kusetshenziswa i-transmute: lokhu kuncika ekuhlelweni kwedatha okungachazwanga kwe-`Vec`, okuwumbono omubi futhi ongadala Ukuziphatha Okungachazwanga.
    /////
    /// // Noma kunjalo, akuyona ikhophi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Le yindlela ephakanyisiwe, ephephile.
    /// // Iyakopisha yonke i-vector, kodwa, ibe kuhlu olusha.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Le akuyona ikhophi efanele, indlela engaphephile ye "transmuting" i `Vec`, ngaphandle kokuncika ekubekweni kwedatha.
    /// // Esikhundleni sokubiza ngokoqobo i-`transmute`, senza i-pointer cast, kepha maqondana nokuguqula uhlobo lwangaphakathi lwangempela i-(`&i32`) lube olusha lwe-(`Option<&i32>`), lokhu kunemigede efanayo.
    /////
    /// // Ngaphandle kwemininingwane enikezwe ngenhla, futhi thinta imibhalo ye [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Vuselela lokhu lapho i-vec_into_raw_parts izinzile.
    ///     // Qinisekisa ukuthi i-vector yoqobo ayilahliwe.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Kusetshenziswa i `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Kunezindlela eziningi zokwenza lokhu, futhi kunezinkinga eziningi ngale ndlela ye (transmute) elandelayo.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // okokuqala: ukuthunyelwa akulona uhlobo oluphephile;konke okuhlolwayo ukuthi uT no
    ///         // U usayizi ofanayo.
    ///         // Okwesibili, khona lapha, unezinkomba ezimbili eziguqukayo ezikhomba kwimemori efanayo.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Lokhu kususa izinkinga zokuphepha zohlobo;I-`&mut *` izokunikeza kuphela i-`&mut T` kusuka ku-`&mut T` noma i-`* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // noma kunjalo, usenezikhombo ezimbili eziguqukayo ezikhomba kwimemori efanayo.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Le yindlela owenza ngayo umtapo wezincwadi ojwayelekile.
    /// // Le yindlela enhle kunazo zonke, uma udinga ukwenza into enjengale
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Lokhu manje kunezinkomba ezintathu eziguqukayo ezikhomba kwimemori efanayo.I-`slice`, i-rvalue ret.0, ne-rvalue ret.1.
    ///         // `slice` ayikaze isetshenziswe ngemuva kwe `let ptr = ...`, ngakho-ke umuntu angayiphatha njenge-"dead", ngakho-ke, unezicucu ezimbili zangempela ezingaguquguquka.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ngenkathi lokhu kwenza i-intrinsic const izinze, sinekhodi ethile yangokwezifiso ku-const fn
    // amasheke avimbela ukusetshenziswa kwawo ngaphakathi kwe `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Ibuyisa i-`true` uma uhlobo lwangempela olunikezwe njenge-`T` ludinga i-glue;ibuyisa i-`false` uma uhlobo lwangempela luhlinzekelwe ukusetshenziswa kwe-`T` `Copy`.
    ///
    ///
    /// Uma uhlobo lwangempela aludingi ukulahla i-glue noma lusebenzise i-`Copy`, khona-ke inani lokubuyisa lalo msebenzi alicacisiwe.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ibala isamba kusuka kusikhombi.
    ///
    /// Lokhu kwenziwa njengengaphakathi ukugwema ukuguqulela kwinani eliphelele, ngoba ukuguqulwa kuzolahla imininingwane yokuqanjwa.
    ///
    /// # Safety
    ///
    /// Kokubili isikhombisi sokuqala nokuholelekayo kufanele kube semikhawulweni noma nge-byte eyodwa kudlule ukuphela kwento eyabiwe.
    /// Uma noma isiphi isikhombi singaphandle kwemingcele noma ukugcwala kwe-arithmetic kwenzeka lapho ukusetshenziswa okuqhubekayo kwenani elibuyisiwe kuzoholela ekuziphatheni okungachazwanga.
    ///
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ibala isamba kusuka kusikhombi, okungahle kusongelwe.
    ///
    /// Lokhu kwenziwa njengengaphakathi ukugwema ukuguqulela kwinani eliphelele, ngoba ukuguqulwa kuvimbela ukwenziwa okuthile okuthile.
    ///
    /// # Safety
    ///
    /// Ngokungafani ne-`offset` intrinsic, le intrinsic ayigcini isikhombisi esivelayo sikhombe ku-noma nge-byte eyodwa kudlule ukuphela kwento eyabiwe, futhi isongwa nge-complement ye-arithmetic emibili.
    /// Inani eliholelwayo alivumelekile ukuthi lisetshenziselwe ukufinyelela imemori.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Iyalingana nengaphakathi le-`llvm.memcpy.p0i8.0i8.*` elifanele, ngosayizi we-`count`*`size_of::<T>()` nokulungiswa kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ipharamitha eguquguqukayo isethelwe ku-`true`, ngakho-ke ngeke ithuthukiswe ngaphandle kokuthi usayizi ulingana no-zero.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Iyalingana nengaphakathi le-`llvm.memmove.p0i8.0i8.*` elifanele, ngosayizi we-`count* size_of::<T>()` nokulungiswa kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Ipharamitha eguquguqukayo isethelwe ku-`true`, ngakho-ke ngeke ithuthukiswe ngaphandle kokuthi usayizi ulingana no-zero.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Iyalingana nengaphakathi le-`llvm.memset.p0i8.*` elifanele, ngosayizi we-`count* size_of::<T>()` nokulungiswa kwe-`min_align_of::<T>()`.
    ///
    ///
    /// Ipharamitha eguquguqukayo isethelwe ku-`true`, ngakho-ke ngeke ithuthukiswe ngaphandle kokuthi usayizi ulingana no-zero.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Yenza umthwalo oguquguqukayo kusuka kusikhombi se `src`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Yenza isitolo esintantayo kusikhombi se `dst`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Yenza umthwalo oguquguqukayo kusuka kusikhombi se-`src` Isikhombi asidingi ukuqondaniswa.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Yenza isitolo esintantayo kusikhombi se `dst`.
    /// Isikhombi asidingi ukuqondaniswa.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Ibuyisa impande eyisikwele ye-`f32`
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Ibuyisa impande eyisikwele ye-`f64`
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Kukhulisa i-`f32` kumandla aphelele.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Kukhulisa i-`f64` kumandla aphelele.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Ibuyisa i-sine ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Ibuyisa i-sine ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Ibuyisa i-cosine ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Ibuyisa i-cosine ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Iphakamisa i `f32` ibe namandla we `f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Iphakamisa i `f64` ibe namandla we `f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Ibuyisa ukuchazeka kwe-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Ibuyisa ukuchazeka kwe-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Ibuyisa okungu-2 okuphakanyiswe emandleni we-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Ibuyisa okungu-2 okuphakanyiswe emandleni we-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Ibuyisa i-logarithm yemvelo ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Ibuyisa i-logarithm yemvelo ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Ibuyisa i-base 10 logarithm ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Ibuyisa i-base 10 logarithm ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Ibuyisa i-base 2 logarithm ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Ibuyisa i-base 2 logarithm ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Ibuyisa i-`a * b + c` ngamanani we-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Ibuyisa i-`a * b + c` ngamanani we-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Ibuyisa inani eliphelele le-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Ibuyisa inani eliphelele le-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Ibuyisa ubuncane bamanani amabili we-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Ibuyisa ubuncane bamanani amabili we-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Ibuyisa umkhawulo wamanani amabili we-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Ibuyisa umkhawulo wamanani amabili we-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Ikopisha uphawu kusuka ku-`y` kuye ku-`x` ngamanani we-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Ikopisha uphawu kusuka ku-`y` kuye ku-`x` ngamanani we-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Ibuyisa inani elikhulu kunawo wonke elingaphansi noma elilingana ne-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Ibuyisa inani elikhulu kunawo wonke elingaphansi noma elilingana ne-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Ibuyisa inani elincane kakhulu ukwedlula noma lilingane ne-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Ibuyisa inani elincane kakhulu ukwedlula noma lilingane ne-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Ibuyisa ingxenye ephelele ye-`f32`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Ibuyisa ingxenye ephelele ye-`f64`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Ibuyisa inani eliseduze kakhulu ku-`f32`.
    /// Ingakhuphula i-inexact ezintantayo-iphuzu uma impikiswano kungeyona inombolo ephelele.
    pub fn rintf32(x: f32) -> f32;
    /// Ibuyisa inani eliseduzane ku-`f64`.
    /// Ingakhuphula i-inexact ezintantayo-iphuzu uma impikiswano kungeyona inombolo ephelele.
    pub fn rintf64(x: f64) -> f64;

    /// Ibuyisa inani eliseduze kakhulu ku-`f32`.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Ibuyisa inani eliseduzane ku-`f64`.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Ibuyisa inani eliseduze kakhulu ku-`f32`.Ifinyeza amacala okuya phakathi nendawo ukusuka kuziro.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Ibuyisa inani eliseduze kakhulu ku-`f64`.Ifinyeza amacala okuya phakathi nendawo ukusuka kuziro.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi ngu
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Ukungezwa kokuntanta okuvumela ukusebenziseka okususelwa kwimithetho ye-algebraic.
    /// Singacabanga ukuthi okokufaka kuphelile.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Ukukhipha iflat okuvumela ukusebenziseka okususelwa kwimithetho ye-algebraic.
    /// Singacabanga ukuthi okokufaka kuphelile.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Ukuphindaphindwa kokuntanta okuvumela ukusebenziseka okususelwa kumithetho ye-algebraic.
    /// Singacabanga ukuthi okokufaka kuphelile.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ukwahlukaniswa kweFlat okuvumela ukusebenziseka okususelwa kwimithetho ye-algebraic.
    /// Singacabanga ukuthi okokufaka kuphelile.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Okusele okuseleyo okuvumela ukusebenziseka okususelwa kwimithetho ye-algebraic.
    /// Singacabanga ukuthi okokufaka kuphelile.
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Guqula nge-LLVM's fptoui/fptosi, engahle ibuyise i-undef yamanani aphume ebangeni
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Izinzile njenge-[`f32::to_int_unchecked`] ne-[`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Ibuyisa inani lamabhithi asethwe ngohlobo oluphelele `T`
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`count_ones`.
    /// Ngokwesibonelo,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Ibuyisa inani lamabhithi angahleliwe angahleliwe (zeroes) ngohlobo lwe-integer `T`.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`leading_zeros`.
    /// Ngokwesibonelo,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// I-`x` enenani le-`0` izobuyisa ububanzi be-`T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Njenge-`ctlz`, kepha engaphephile ngokwengeziwe njengoba ibuyisa i-`undef` lapho inikezwa i-`x` ngenani le-`0`.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Ibuyisa inani lamabhithi angasethiwe alandelanayo (zeroes) ngohlobo oluphelele lwe-`T`.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`trailing_zeros`.
    /// Ngokwesibonelo,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// I-`x` enenani `0` izobuyisa ububanzi be-`T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Njenge-`cttz`, kepha engaphephile ngokwengeziwe njengoba ibuyisa i-`undef` lapho inikezwa i-`x` ngenani le-`0`.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Ibuyisa amabhayithi ngohlobo oluphelele lwe-`T`.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`swap_bytes`.
    /// Ngokwesibonelo,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Ibuyisa izingcezu ngohlobo oluphelele lwe-`T`.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`reverse_bits`.
    /// Ngokwesibonelo,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Yenza ukungezwa okuphelele okuhloliwe.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`overflowing_add`.
    /// Ngokwesibonelo,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza ukukhishwa okuphelele okuhloliwe
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`overflowing_sub`.
    /// Ngokwesibonelo,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza ukubuyabuyelela kwenombolo ehloliwe
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`overflowing_mul`.
    /// Ngokwesibonelo,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Yenza ukwahlukana okuqondile, okuholela ekuziphatheni okungachazwanga lapho i-`x % y != 0` noma i-`y == 0` noma i-`x == T::MIN && y == -1`
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukuhlukaniswa okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`y == 0` noma i-`x == T::MIN && y == -1`
    ///
    ///
    /// Izisongelo eziphephile zalokhu okungaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`checked_div`.
    /// Ngokwesibonelo,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Ibuyisa okusele kokuhlukaniswa okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`y == 0` noma i-`x == T::MIN && y == -1`
    ///
    ///
    /// Izisongelo eziphephile zalokhu okungaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`checked_rem`.
    /// Ngokwesibonelo,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukushintshwa kwesokunxele okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`y < 0` noma i-`y >= N`, lapho i-N ingububanzi be-T kumabhithi.
    ///
    ///
    /// Izisongelo eziphephile zalokhu okungaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`checked_shl`.
    /// Ngokwesibonelo,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Yenza ushintsho lwangakwesokudla olungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`y < 0` noma i-`y >= N`, lapho i-N ingububanzi be-T kumabhithi.
    ///
    ///
    /// Izisongelo eziphephile zalokhu okungaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`checked_shr`.
    /// Ngokwesibonelo,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa imiphumela yokungeza okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`x + y > T::MAX` noma i-`x + y < T::MIN`.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa imiphumela yokukhipha okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`x - y > T::MAX` noma i-`x - y < T::MIN`.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Ibuyisa umphumela wokuphindaphindwa okungamakiwe, okuholela ekuziphatheni okungachazwanga lapho i-`x *y > T::MAX` noma i-`x* y < T::MIN`.
    ///
    ///
    /// Lokhu okungaphakathi akunaye uzakwabo ozinzile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukuzungezisa kwesokunxele.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`rotate_left`.
    /// Ngokwesibonelo,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Yenza ukuzungezisa kwesokudla.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`rotate_right`.
    /// Ngokwesibonelo,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returns (a + b) mod 2 <sup>N</sup>, lapho u-N ububanzi be-T kuma-bits.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`wrapping_add`.
    /// Ngokwesibonelo,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returns (a, b) mod 2 <sup>N</sup>, lapho u-N ububanzi be-T kuma-bits.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`wrapping_sub`.
    /// Ngokwesibonelo,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returns (a * b) mod 2 <sup>N</sup>, lapho u-N ububanzi be-T kuma-bits.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`wrapping_mul`.
    /// Ngokwesibonelo,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ibala i-`a + b`, igcwele emingceleni yezinombolo.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`saturating_add`.
    /// Ngokwesibonelo,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ibala i-`a - b`, igcwele emingceleni yezinombolo.
    ///
    /// Izinhlobo ezizinzile zale nto yangaphakathi ziyatholakala kuma-primitives aphelele ngendlela ye-`saturating_sub`.
    /// Ngokwesibonelo,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Ibuyisa inani lobandlululo ngokuhlukile ku-'v';
    /// uma i-`T` ingenabandlululo, ibuyisa i-`0`.
    ///
    /// Uhlobo oluzinzile lwale nto yangaphakathi yi-[`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Ibuyisa inani lokwahlukahluka kohlobo olungu-`T` olwenziwe ku-`usize`;
    /// uma i-`T` ingenakho okuhlukile, ibuyisa i-`0`.Ukwahluka okungahlali muntu kuzobalwa.
    ///
    /// Uhlobo oluzoqiniswa lwale nto yangaphakathi yi-[`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Ukwakhiwa kwe-Rust's "try catch" okucela isikhombisi somsebenzi `try_fn` ngesikhombi sedatha `data`.
    ///
    /// Ukuphikisana kwesithathu kungumsebenzi obizwa uma kwenzeka ukuthi i panic.
    /// Lo msebenzi uthatha i-pointer yedatha kanye nesikhombi sento eqondiswe ngqo kwithagethi ebanjiwe.
    ///
    /// Ngemininingwane engaphezulu bona umthombo womhlanganisi kanye nokuqaliswa kokubanjwa kwe-std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Ikhipha isitolo se `!nontemporal` ngokuya nge-LLVM (bona amadokhumenti abo).
    /// Mhlawumbe awusoze wazinza.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Bona imibhalo ye `<*const T>::offset_from` ngemininingwane.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Bona imibhalo ye `<*const T>::guaranteed_eq` ngemininingwane.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Bona imibhalo ye `<*const T>::guaranteed_ne` ngemininingwane.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Nika ngesikhathi sokuhlanganisa.Akufanele kubizwe ngesikhathi sokusebenza.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Eminye imisebenzi ichazwe lapha ngoba ngephutha yenziwe yatholakala kule mojuli esitebeleni.
// Bona i <https://github.com/rust-lang/rust/issues/15702>.
// (I-`transmute` nayo iwela kulesi sigaba, kepha ayikwazi ukusongwa ngenxa yesheke lokuthi i `T` ne `U` zinosayizi ofanayo.)
//

/// Ihlola ukuthi i-`ptr` iqondaniswe kahle yini maqondana ne-`align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Amakhophi we-`count *size_of::<T>()` byte kusuka ku-`src` kuye ku-`dst`.Umthombo nendawo okuyiwa kuyo akumele* igqagqane.
///
/// Ezifundeni zememori ezingadlula, sebenzisa i-[`copy`] esikhundleni salokho.
///
/// `copy_nonoverlapping` ilingana ngokomqondo ne-C's [`memcpy`], kepha nge-oda lokuphikisana lishintshiwe.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `src` kufanele kube yi-[valid] ngokufundwa kwama-byte ayi-`count * size_of::<T>()`.
///
/// * `dst` kumele kube yi-[valid] yokubhala ngama-`count * size_of::<T>()` byte.
///
/// * Kokubili i-`src` ne-`dst` kumele kuqondaniswe kahle.
///
/// * Isifunda sememori esiqala ku-`src` ngosayizi we `count *
///   usayizi_of: :<T>() `bytes akumele * igqagqene nesifunda sememori esiqala ku-`dst` ngosayizi ofanayo.
///
/// Njengo-[`read`], i-`copy_nonoverlapping` idala ikhophi elincanyana le-`T`, noma ngabe i-`T` iyi-[`Copy`].
/// Uma i-`T` kungeyona i-[`Copy`], kusetshenziswa *kokubili* amanani esifundeni aqala ku-`*src` futhi isifunda esiqala ku-`* dst` singaba yi-[violate memory safety][read-ownership].
///
///
/// Qaphela ukuthi noma ngabe usayizi okopishwe ngempumelelo (`count * size_of: :<T>()`) ngu-`0`, izikhombisi kumele zingabi ze-NULL futhi ziqondaniswe kahle.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Sebenzisa mathupha i [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Ihambisa zonke izinto ze-`src` ziye ku-`dst`, ishiya i-`src` ingenalutho.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Qiniseka ukuthi i `dst` inomthamo owanele wokubamba yonke i `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Ukubizelwa ku-offset kuhlala kuphephile ngoba i-`Vec` ayisoze yabela ngaphezu kwama-byte ayi-`isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Nciphisa i `src` ngaphandle kokulahla okuqukethwe kwayo.
///         // Lokhu sikwenza kuqala, ukugwema izinkinga uma kwenzeka kukhona okuqhubekayo phansi kwe panics.
///         src.set_len(0);
///
///         // Lezi zifunda zombili azikwazi ukugqagqana ngoba izinkomba eziguqukayo aziwona ama-alias, futhi i vectors ezimbili ezihlukile azikwazi ukuba nememori efanayo.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Yazisa i `dst` ukuthi manje iphethe okuqukethwe kwe `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yenza lokhu kuhlolwa kuphela ngesikhathi sokuqalisa
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ukungatatazeli ukugcina umthelela we-codegen uncane.
        abort();
    }*/

    // UKUPHEPHA: inkontileka yezokuphepha ye `copy_nonoverlapping` kumele ibe njalo
    // kugcinwa ofonayo.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Amakhophi we-`count * size_of::<T>()` byte kusuka ku-`src` kuye ku-`dst`.Umthombo nendawo oya kuyo ingagqagqana.
///
/// Uma umthombo nendawo oya kuyo * kungasoze kwagqagqana, i-[`copy_nonoverlapping`] ingasetshenziswa esikhundleni salokho.
///
/// `copy` ilingana ngokomqondo ne-C's [`memmove`], kepha nge-oda lokuphikisana lishintshiwe.
/// Ukukopisha kwenzeka sengathi ama-byte akopishwe kusuka ku-`src` kuya kumalungu afanayo esikhashana bese ekopishwa kusuka kumalungu afanayo kuya ku-`dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `src` kufanele kube yi-[valid] ngokufundwa kwama-byte ayi-`count * size_of::<T>()`.
///
/// * `dst` kumele kube yi-[valid] yokubhala ngama-`count * size_of::<T>()` byte.
///
/// * Kokubili i-`src` ne-`dst` kumele kuqondaniswe kahle.
///
/// Njengo-[`read`], i-`copy` idala ikhophi elincanyana le-`T`, noma ngabe i-`T` iyi-[`Copy`].
/// Uma i-`T` kungeyona i-[`Copy`], kusetshenziswa womabili amanani esifundeni aqala ku-`*src` futhi isifunda esiqala ku-`* dst` singaba yi-[violate memory safety][read-ownership].
///
///
/// Qaphela ukuthi noma ngabe usayizi okopishwe ngempumelelo (`count * size_of: :<T>()`) ngu-`0`, izikhombisi kumele zingabi ze-NULL futhi ziqondaniswe kahle.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Dala kahle i-Rust vector kusuka kubhafa engaphephile:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` kufanele iqondaniswe kahle ngohlobo lwayo nokungabi uziro.
/// /// * `ptr` kufanele ivunyelwe ukufundwa kwezinto ezi-`elts` ezihlanganayo zohlobo `T`.
/// /// * Lezo zinto akufanele zisetshenziswe ngemuva kokubiza lo msebenzi ngaphandle kokuthi i-`T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // UKUPHEPHA: Umbandela wethu uqinisekisa ukuthi umthombo uqondaniswe futhi usebenza,
///     // futhi i `Vec::with_capacity` iqinisekisa ukuthi sinesikhala esisebenzisekayo sokuzibhala.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // UKUPHEPHA: Sikudale ngalomthamo ongaka phambilini,
///     // futhi i `copy` eyedlule iqalise lezi zinto.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Yenza lokhu kuhlolwa kuphela ngesikhathi sokuqalisa
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ukungatatazeli ukugcina umthelela we-codegen uncane.
        abort();
    }*/

    // UKUPHEPHA: inkontileka yokuphepha ye `copy` kufanele igcinwe yilowo ofonayo.
    unsafe { copy(src, dst, count) }
}

/// Isetha imemori engu-`count * size_of::<T>()` yememori eqala ku-`dst` kuye ku-`val`.
///
/// `write_bytes` iyafana ne-C's [`memset`], kepha isetha ama-`count * size_of::<T>()` byte ku-`val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Ukuziphatha akuchazwa uma ngabe kukhona kwalezi zimo ezilandelayo ezephulwa:
///
/// * `dst` kumele kube yi-[valid] yokubhala ngama-`count * size_of::<T>()` byte.
///
/// * `dst` kumele iqondaniswe kahle.
///
/// Ngokwengeziwe, ofonayo kufanele aqinisekise ukuthi ukubhala ama-byte ayi-`count * size_of::<T>()` esifundeni esinikeziwe sememori kuphumela kunani elivumelekile le-`T`.
/// Kusetshenziswa indawo yememori ethayiphiwe njenge-`T` equkethe inani elingavumelekile le-`T` ukuziphatha okungachazwanga.
///
/// Qaphela ukuthi noma ngabe usayizi okopishwe ngempumelelo (`count * size_of: :<T>()`) ngu-`0`, isikhombisi kufanele singabi yi-NULL futhi siqondaniswe kahle.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ukwakha inani elingavumelekile:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Kuvuza inani ebelibanjwe ngaphambilini ngokubhala ngaphezulu i-`Box<T>` ngesikhombi esiyize.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Ngalesi sikhathi, ukusebenzisa noma ukulahla imiphumela ye-`v` ekuziphatheni okungachazwanga.
/// // drop(v); // ERROR
///
/// // Ngisho ivuza i `v` "uses" it, yingakho kungaziphathi kahle.
/// // mem::forget(v); // ERROR
///
/// // Eqinisweni, i-`v` ayivumelekile ngokuya ngezifakeli eziyisisekelo zohlobo lohlobo, ngakho-ke *noma yikuphi* ukusebenza okukuthinta kungukuziphatha okungachazwanga.
/////
/// // ake i v2 =v;//IPHUTHA
///
/// unsafe {
///     // Esikhundleni salokho ake sibeke inani elifanele
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Manje ibhokisi selilungile
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // UKUPHEPHA: inkontileka yokuphepha ye `write_bytes` kufanele igcinwe yilowo ofonayo.
    unsafe { write_bytes(dst, val, count) }
}