//! I-Traits yokuguqulwa phakathi kwezinhlobo.
//!
//! I-traits kule module inikezela indlela yokuguqula isuke kolunye uhlobo iye kolunye uhlobo.
//! I-trait ngayinye isebenza ngenhloso ehlukile:
//!
//! - Sebenzisa i-[`AsRef`] trait yokuguqulwa okushibhile okusetshenziselwa ukubhekisa kusethenjwa
//! - Sebenzisa i [`AsMut`] trait yezinguquko ezishibhile ezingaguquleka
//! - Sebenzisa i-[`From`] trait ngokusebenzisa ukuguqulwa kwenani ukuya kunani
//! - Sebenzisa i-[`Into`] trait ngokusebenzisa ukuguqulwa kwenani ukuya kunani kuzinhlobo ezingaphandle kwe-crate yamanje
//! - I [`TryFrom`] ne [`TryInto`] traits ziziphatha njenge [`From`] ne [`Into`], kepha kufanele zisetshenziswe lapho ukuguqulwa kungahluleka.
//!
//! Ama-traits akule mojule avame ukusetshenziswa njenge-trait bound yemisebenzi ejwayelekile efana nokuthi izimpikiswano zezinhlobo eziningi ziyasekelwa.Bona imibhalo ye trait ngayinye ngezibonelo.
//!
//! Njengombhali welabhulali, kufanele uhlale ukhetha ukusebenzisa i-[`From<T>`][`From`] noma i-[`TryFrom<T>`][`TryFrom`] kune-[`Into<U>`][`Into`] noma i-[`TryInto<U>`][`TryInto`], njengoba i-[`From`] ne-[`TryFrom`] zinikeza ukuguquguquka okukhulu futhi zinikeze ukusetshenziswa okulingana kwe-[`Into`] noma kwe-[`TryInto`] mahhala, ngenxa yokuqaliswa kwengubo kumtapo wezincwadi ojwayelekile.
//! Lapho ukhomba inguqulo ngaphambi kwe-Rust 1.41, kungahle kudingeke ukuthi usebenzise i-[`Into`] noma i-[`TryInto`] ngqo lapho uguqulela ohlotsheni olungaphandle kwe-crate yamanje.
//!
//! # Ukusetshenziswa Okujwayelekile
//!
//! - [`AsRef`] kanye ne-[`AsMut`] auto-dereference uma uhlobo lwangaphakathi luyireferensi
//! - [`Kusuka`]`<U>ngo-T` kusho ukuthi [`Into"] `</u><T><U>ye-U`</u>
//! - [`TryFrom`]`<U>for T` means [`TryInto`]`</u><T><U>ye-U`</u>
//! - [`From`] futhi i-[`Into`] ayicabangi, okusho ukuthi zonke izinhlobo zingazi-`into` ngokwazo kanye ne-`from` uqobo
//!
//! Bona i-trait ngayinye ngezibonelo zokusetshenziswa.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Umsebenzi wobunikazi.
///
/// Zimbili izinto ezibalulekile okumele wazi ngalo msebenzi:
///
/// - Akuhlali kufana nokuvalwa okufana ne-`|x| x`, ngoba ukuvalwa kungaphoqa i-`x` ibe uhlobo oluhlukile.
///
/// - Ihambisa okokufaka i-`x` kudluliselwe emsebenzini.
///
/// Yize kungahle kubonakale kungajwayelekile ukuba nomsebenzi ovele ubuyise okokufaka, kukhona okunye ukusetshenziswa okuthokozisayo.
///
///
/// # Examples
///
/// Usebenzisa i `identity` ungenzi lutho ngokulandelana kweminye, imisebenzi ethokozisayo:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Masenze sengathi ukungeza okukodwa kungumsebenzi othokozisayo.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Usebenzisa i-`identity` njenge-"do nothing" base case ngaphansi kwemibandela:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Yenza izinto ezithokozisayo ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Usebenzisa i-`identity` ukugcina okwehlukile kwe-`Some` kwe-iterator ye-`Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Kusetshenziselwe ukwenza ukuguqulwa okushibhile okusetshenziselwa ukubhekisela kusethenjwa.
///
/// Le trait ifana ne [`AsMut`] esetshenziselwa ukuguqula phakathi kwezethenjwa eziguqukayo.
/// Uma udinga ukwenza ukuguqulwa okubizayo kungcono ukusebenzisa i-[`From`] ngohlobo `&T` noma ukubhala umsebenzi wangokwezifiso.
///
/// `AsRef` inesiginesha efanayo ne [`Borrow`], kepha i [`Borrow`] yehlukile ezicini ezimbalwa:
///
/// - Ngokungafani ne-`AsRef`, i-[`Borrow`] ine-blanket impl yanoma iyiphi i-`T`, futhi ingasetshenziselwa ukwamukela noma ireferensi noma inani.
/// - [`Borrow`] futhi kudinga ukuthi i-[`Hash`], i-[`Eq`] ne-[`Ord`] yenani elibolekiwe zilingana nalezo zenani eliphethwe.
/// Ngalesi sizathu, uma ufuna ukuboleka inkambu eyodwa kuphela yesakhiwo ungasebenzisa i-`AsRef`, kepha hhayi i-[`Borrow`].
///
/// **Note: Le trait akumele yehluleke **.Uma ukuguqulwa kungaphumeleli, sebenzisa indlela ezinikele ebuyisa i-[`Option<T>`] noma i-[`Result<T, E>`].
///
/// # Ukusetshenziswa Okujwayelekile
///
/// - `AsRef` okuzenzekelayo uma uhlobo lwangaphakathi luyireferensi noma ireferensi engaguquguqukayo (isb: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ngokusebenzisa i-trait bounds singamukela izimpikiswano zezinhlobo ezahlukahlukene inqobo nje uma zingaguqulwa zibe uhlobo olucacisiwe `T`.
///
/// Isibonelo: Ngokwakha umsebenzi ojwayelekile othatha i-`AsRef<str>` siveza ukuthi sifuna ukwamukela zonke izinkomba ezingaguqulelwa ku-[`&str`] njengengxabano.
/// Njengoba zombili i [`String`] ne [`&str`] zisebenzisa i `AsRef<str>` singazamukela zombili njengengxabano yokufaka.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Yenza ukuguqulwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Kusetshenziselwe ukwenza ukuguqulwa kwesethenjwa okungaguquguquki okungaguquguquki.
///
/// Le trait ifana ne [`AsRef`] kepha isetshenziselwa ukuguqula phakathi kwezethenjwa eziguqukayo.
/// Uma udinga ukwenza ukuguqulwa okubizayo kungcono ukusebenzisa i-[`From`] ngohlobo `&mut T` noma ukubhala umsebenzi wangokwezifiso.
///
/// **Note: Le trait akumele yehluleke **.Uma ukuguqulwa kungaphumeleli, sebenzisa indlela ezinikele ebuyisa i-[`Option<T>`] noma i-[`Result<T, E>`].
///
/// # Ukusetshenziswa Okujwayelekile
///
/// - `AsMut` Ukuzikhethela okuzenzakalelayo uma uhlobo lwangaphakathi luyisithenjwa esiguquguqukayo (isb. `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Sisebenzisa i-`AsMut` njenge-trait bound ngomsebenzi ojwayelekile singamukela zonke izinkomba eziguqukayo ezingaguqulelwa ku-`&mut T`.
/// Ngoba i-[`Box<T>`] isebenzisa i-`AsMut<T>` singabhala umsebenzi `add_one` othatha zonke izimpikiswano ezingaguqulelwa ku-`&mut u64`.
/// Ngoba i [`Box<T>`] isebenzisa i `AsMut<T>`, i `add_one` yamukela izimpikiswano zohlobo `&mut Box<u64>` futhi:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Yenza ukuguqulwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Ukuguqulwa kwenani kuya kunani elisebenzisa inani lokufaka.Okuphambene ne [`From`].
///
/// Umuntu kufanele agweme ukusebenzisa i-[`Into`] bese esebenzisa i-[`From`] esikhundleni salokho.
/// Ukuqalisa i-[`From`] kunikeza umuntu ngokuzenzakalela ukuqaliswa kwe-[`Into`] ngenxa yokusetshenziswa kwengubo kumtapo wezincwadi ojwayelekile.
///
/// Uncamela ukusebenzisa i-[`Into`] ngaphezulu kwe-[`From`] lapho ucacisa i-trait bounds emsebenzini ojwayelekile ukuqinisekisa ukuthi izinhlobo ezisebenzisa kuphela i-[`Into`] nazo zingasetshenziswa.
///
/// **Note: Le trait akumele yehluleke **.Uma ukuguqulwa kungaphumeleli, sebenzisa i [`TryInto`].
///
/// # Ukusetshenziswa Okujwayelekile
///
/// - [`Kusuka`]`<T>ye-U` isho ukuthi i-`Into<U> for T`
/// - [`Into`] kuyabukeka, okusho ukuthi i-`Into<T> for T` iyasetshenziswa
///
/// # Kusetshenziswa i-[`Into`] yokuguqulwa kwezinhlobo zangaphandle kuzinguqulo ezindala ze-Rust
///
/// Ngaphambi kwe-Rust 1.41, uma uhlobo lwendawo okuyiwa kuyo belungeyona ingxenye ye-crate yamanje ubungeke usebenzise i-[`From`] ngqo.
/// Isibonelo, thatha le khodi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Lokhu kuzohluleka ukuhlanganiswa ezinhlotsheni ezindala zolimi ngoba imithetho ye Rust yezintandane yayijwayele ukuqina kakhulu.
/// Ukweqa lokhu, ungasebenzisa i-[`Into`] ngqo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Kubalulekile ukuqonda ukuthi i-[`Into`] ayinikezeli ukusetshenziswa kwe-[`From`] (njengoba i-[`From`] yenza nge-[`Into`]).
/// Ngakho-ke, kufanele uhlale uzama ukusebenzisa i-[`From`] bese ubuyela emuva ku-[`Into`] uma i-[`From`] ingenakusetshenziswa.
///
/// # Examples
///
/// [`String`] implements [`Into`]`<`[`Vec`] `<` [`u8`]` >> >>:
///
/// Ukuze siveze ukuthi sifuna umsebenzi ojwayelekile uthathe zonke izimpikiswano ezingaguqulelwa kuhlobo olucacisiwe `T`, singasebenzisa i-trait bound ye-[`Into`]`<T>`.
///
/// Isibonelo: Umsebenzi `is_hello` uthatha zonke izimpikiswano ezingaguqulelwa ku-[`Vec`]`<<[[u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Yenza ukuguqulwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Kusetshenziselwe ukwenza ukuguqulwa kwenani lenani ngenkathi kudliwa inani lokufaka.Kungukuphindaphinda kwe [`Into`].
///
/// Umuntu kufanele ngaso sonke isikhathi akhethe ukusebenzisa i-`From` ngaphezu kwe-[`Into`] ngoba ukusebenzisa i-`From` kunikeza umuntu ngokuzenzakalela ukuqaliswa kwe-[`Into`] ngenxa yokuqaliswa kwengubo kumtapo wezincwadi ojwayelekile.
///
///
/// Sebenzisa kuphela i-[`Into`] lapho ukhomba inguqulo ngaphambi kwe-Rust 1.41 futhi uguqulela ohlotsheni olungaphandle kwe-crate yamanje.
/// `From` akakwazanga ukwenza lezi zinhlobo zokuguqulwa ezinhlotsheni zangaphambili ngenxa yemithetho yezintandane ye Rust.
/// Bona i [`Into`] ukuthola eminye imininingwane.
///
/// Uncamela ukusebenzisa i-[`Into`] ngaphezulu kokusebenzisa i-`From` lapho ucacisa i-trait bounds emsebenzini ojwayelekile.
/// Ngale ndlela, izinhlobo ezisebenzisa ngqo i-[`Into`] nazo zingasetshenziswa njengezimpikiswano.
///
/// I `From` futhi iyasiza kakhulu lapho kwenziwa ukuphatha iphutha.Lapho kwakhiwa umsebenzi okwazi ukwehluleka, uhlobo lokubuyisa ngokuvamile luzoba yifomu `Result<T, E>`.
/// I `From` trait yenza kube lula ukuphatha amaphutha ngokuvumela umsebenzi ukuthi ubuyisele uhlobo olulodwa lwephutha oluhlanganisa izinhlobo zamaphutha amaningi.Bona isigaba se "Examples" ne [the book][book] ukuthola eminye imininingwane.
///
/// **Note: Le trait akumele yehluleke **.Uma ukuguqulwa kungaphumeleli, sebenzisa i [`TryFrom`].
///
/// # Ukusetshenziswa Okujwayelekile
///
/// - `From<T> for U` kusho ukuthi [`Into`] <U>ye-T`</u>
/// - `From` kuyabukeka, okusho ukuthi i-`From<T> for T` iyasetshenziswa
///
/// # Examples
///
/// [`String`] isebenzisa i `From<&str>`:
///
/// Ukuguqulwa okusobala kusuka ku-`&str` kuye ku-String kwenziwa kanjena:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ngenkathi wenza iphutha ekuphatheni kuvame ukuba lusizo ukusebenzisa i-`From` ngohlobo lwakho lwephutha.
/// Ngokuguqula izinhlobo zamaphutha ayisisekelo ziye ohlotsheni lwethu lwephutha langokwezifiso olufaka uhlobo lwamaphutha ayisisekelo, singabuyisa uhlobo olulodwa lwephutha ngaphandle kokulahlekelwa yimininingwane ngesizathu esiyimbangela.
/// I-'?' opharetha iguqula ngokuzenzakalela uhlobo lwephutha oluyisisekelo lube luhlobo lwethu lwephutha langokwezifiso ngokubiza i-`Into<CliError>::into` enikezwa ngokuzenzakalela lapho kusetshenziswa i `From`.
/// Umhlanganisi ube esefaka ukuthi yikuphi ukusetshenziswa kwe-`Into` okufanele kusetshenziswe.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Yenza ukuguqulwa.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Ukuguqulwa kokuzama okudla i-`self`, okungabiza noma kungabizi.
///
/// Ababhali Bomtapo Wezincwadi akumele basebenzise le trait ngqo, kepha kufanele bakhethe ukusebenzisa i [`TryFrom`] trait, enikeza ukuguquguquka okukhulu futhi inikeze ukusetshenziswa okulingana kwe `TryInto` mahhala, ngenxa yokuqaliswa kwengubo kumtapo wezincwadi ojwayelekile.
/// Ngeminye imininingwane ngalokhu, bona imibhalo ye [`Into`].
///
/// # Kusetshenziswa i `TryInto`
///
/// Lokhu kuhlangabezana nemikhawulo efanayo nokucabanga njengokusebenzisa i-[`Into`], bheka lapho ukuthola imininingwane.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Uhlobo lubuyiselwe esimweni lapho kube nephutha lokuguqula.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yenza ukuguqulwa.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Ukuguqulwa kohlobo olulula futhi oluphephile olungase lwehluleke ngendlela elawulwayo ngaphansi kwezimo ezithile.Kungukuphindaphinda kwe [`TryInto`].
///
/// Lokhu kuyasiza uma wenza ukuguqulwa kohlobo olungaphumelela kancane kepha kungadinga nokuphathwa okukhethekile.
/// Isibonelo, ayikho indlela yokuguqula i-[`i64`] ibe yi-[`i32`] usebenzisa i-[`From`] trait, ngoba i-[`i64`] ingaqukatha inani i-[`i32`] engakwazi ukulimela ngakho-ke ukuguqulwa kuzolahla idatha.
///
/// Lokhu kungaphathwa ngokunciphisa i-[`i64`] ibe yi-[`i32`] (empeleni kunikezwa inani le-[`i64`] modulo [`i32::MAX`]) noma ngokumane kubuyiswe i-[`i32::MAX`], noma ngenye indlela.
/// I [`From`] trait yenzelwe ukuguqulwa okuphelele, ngakho-ke i `TryFrom` trait yazisa umqambi lapho ukuguqulwa kohlobo kungaba kubi futhi kubenze banqume ukuthi bazokuphatha kanjani.
///
/// # Ukusetshenziswa Okujwayelekile
///
/// - `TryFrom<T> for U` kusho ukuthi [`ZamaInto`]`<U>nge-T`</u>
/// - [`try_from`] kuyabukeka, okusho ukuthi i-`TryFrom<T> for T` iyasetshenziswa futhi ayikwazi ukwehluleka-uhlobo lwe-`Error` oluhambisanayo lokushayela i-`T::try_from()` ngenani lohlobo `T` ngu-[`Infallible`].
/// Lapho uhlobo lwe [`!`] luzinzile i-[`Infallible`] ne-[`!`] izolingana.
///
/// `TryFrom<T>` kungenziwa ngale ndlela elandelayo:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Njengoba kuchaziwe, i-[`i32`] isebenzisa `i-TryFrom <` [``i64`] `>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Ukuthula kuthule i-`big_number`, kudinga ukutholwa nokuphathwa kwe-truncation ngemuva kweqiniso.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Ibuyisa iphutha ngoba i-`big_number` inkulu kakhulu ukuthi ingalingana ku-`i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Ibuyisa i `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Uhlobo lubuyiselwe esimweni lapho kube nephutha lokuguqula.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Yenza ukuguqulwa.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS EJwayelekile
////////////////////////////////////////////////////////////////////////////////

// Njengoba uphakamisa ngaphezulu&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Njengokuphakamisa ngaphezulu kwe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// I-FIXME (#45742): buyisela okufakiwe okungenhla kwe&/&mut kokulandelayo okujwayelekile:
// // Njengoba iphakamisa iDeref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>ye-D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// I-AsMut iphakamisa ngaphezulu kwe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// I-FIXME (#45742): buyisela okufakwa ngenhla kwe-&mut ngale elandelayo ejwayelekile:
// // I-AsMut iphakamisa iDerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>ye-D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Kusuka kokuqonde ku
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Kusuka (futhi ngaleyo ndlela ku-Into) kuyazwakala
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Inothi lokuzinza:** Lokhu kufaka akukabikho, kepha siyi-"reserving space" ukuyifaka ku-future.
/// Bona i [rust-lang/rust#64715][#64715] ngemininingwane.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): yenza ukulungiswa okunemigomo esikhundleni salokho.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// I-TryFrom isho ukuthi i-TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Ukuguqulwa okungenaphutha kufana ngokwasemthethweni nokuguqulwa okungenaphutha nohlobo lwephutha elingahlali muntu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMCRSE IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// UHLOBO OLUNGENALO IPHUTHA
////////////////////////////////////////////////////////////////////////////////

/// Uhlobo lwephutha lwamaphutha olungasoze lwenzeka.
///
/// Njengoba le enum ingenakho okuhlukile, inani lolu hlobo alusoze lwaba khona empeleni.
/// Lokhu kungasiza kuma-API ejwayelekile asebenzisa i-[`Result`] futhi enze ipharamitha yohlobo lwephutha, ukukhombisa ukuthi umphumela uhlala uyi-[`Ok`].
///
/// Isibonelo, i-[`TryFrom`] trait (ukuguqulwa okubuyisa i-[`Result`]) inokusetshenziswa kwengubo yazo zonke izinhlobo lapho kukhona khona ukuqaliswa kwe-[`Into`] okuphambene.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Ukuhambisana kwe-Future
///
/// Le enum inendima efanayo ne [the `!`“never”type][never], engazinzile kule nguqulo ye Rust.
/// Lapho i-`!` izinzile, sihlela ukwenza i-`Infallible` ibe ngohlobo lwayo:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Futhi ekugcineni yehlise i `Infallible`.
///
/// Kodwa-ke kunecala elilodwa lapho i-`!` syntax ingasetshenziswa ngaphambi kokuthi i-`!` iqiniswe njengohlobo oluphelele: esimweni sohlobo lokubuya lomsebenzi.
/// Ngokuqondile, kungenzeka ukwenziwa kwezinhlobo ezimbili ezihlukile zesikhombi somsebenzi:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Njengoba i-`Infallible` iyi-enum, le khodi isebenza.
/// Kodwa-ke lapho i-`Infallible` iba isibizo se-never type, ama-`impl`s amabili azoqala ukugqagqana ngakho-ke azovunyelwa yimithetho yokuhlangana kwe-trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}