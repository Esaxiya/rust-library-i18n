//! Ukufakwa kwenombolo ngokokuziphikisa kwe-(bignum) ngokwezifiso.
//!
//! Lokhu kuklanyelwe ukugwema ukwabiwa kwenqwaba ngemali yezitaki zememori.
//! Uhlobo lwe-bignum olusetshenziswa kakhulu, i-`Big32x40`, lukhawulwe ngamabhithi angama-32 × 40=1,280 futhi luzothatha okungenani ama-byte ayi-160 wememori eyisitaki.
//! Lokhu kungaphezu kokwanela ukuzungeza wonke amanani we-`f64` angenamkhawulo.
//!
//! Ngokomthetho kungenzeka ukuthi ube nezinhlobo eziningi ze-bignum kokufaka okuhlukile, kepha asikwenzi lokho ukugwema ukuqunjelwa kwekhodi.
//!
//! I-bignum ngayinye isalandelelwa ukusetshenziswa kwangempela, ngakho-ke ngokuvamile akunandaba.
//!

// Le mojule yenzelwe kuphela i-dec2flt ne-flt2dec, futhi isesidlangalaleni kuphela ngenxa yama-coretest.
// Akuhloselwe ukuthi kuhlale kuqiniswa.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Ukusebenza kwe-Arithmetic okudingeka ngama-bignums.
pub trait FullOps: Sized {
    /// Ibuyisa i-`(carry', v')` njengokuthi i-`carry' * 2^W + v' = self + other + carry`, lapho i-`W` iyinombolo yamabhithi ku-`Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Ibuyisa i-`(carry', v')` njengokuthi i-`carry'*2^W + v' = self* other + carry`, lapho i-`W` iyinombolo yamabhithi ku-`Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Ibuyisa i-`(carry', v')` njengokuthi i-`carry'*2^W + v' = self* other + other2 + carry`, lapho i-`W` iyinombolo yamabhithi ku-`Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Ibuyisa i-`(quo, rem)` njengokuthi i-`borrow *2^W + self = quo* other + rem` ne-`0 <= rem < other`, lapho i-`W` iyinombolo yamabhithi ku-`Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // Lokhu akukwazi ukugcwala;okukhiphayo kuphakathi kwe-`0` ne-`2 * 2^nbits - 1`.
                    // FIXME: Ngabe i-LLVM izokukhulisa lokhu ibe yi-ADC noma okufanayo?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // Lokhu akukwazi ukugcwala;
                    // okukhiphayo kuphakathi kwe-`0` ne-`2^nbits * (2^nbits - 1)`.
                    // FIXME: Ngabe i-LLVM izokukhulisa lokhu ibe yi-ADC noma okufanayo?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // Lokhu akukwazi ukugcwala;
                    // okukhiphayo kuphakathi kwe-`0` ne-`2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // Lokhu akukwazi ukugcwala;okukhiphayo kuphakathi kwe-`0` ne-`other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Bona i-RFC #521 ukuze unike amandla lokhu.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Ithebula lamandla ayi-5 abonakala ngamadijithi.Ngokuqondile, inani elikhulu le-{u8, u16, u32} elingamandla amahlanu, kanye ne-eksponenti ehambisanayo.
/// Isetshenziswe ku-`mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Ukunemba kwesitaki kunikezwe ngokungacabangi (kuze kufike kumkhawulo othile) inani eliphelele.
        ///
        /// Lokhu kusekelwa uhlu lwasayizi ongaguquki wohlobo olunikezwe i ("digit").
        /// Ngenkathi i-array ingeyona enkulu kakhulu (imvamisa ama-byte angamakhulu athile), ukuyikopisha ngokunganaki kungahle kuholele ekushayweni kokusebenza.
        ///
        /// Ngakho-ke lokhu akuyona ngamabomu i `Copy`.
        ///
        /// Yonke imisebenzi etholakalayo kuma-bignums panic uma kwenzeka kuchichima.
        /// Oshaya ucingo unesibopho sokusebenzisa izinhlobo ezinkulu ze-bignum.
        pub struct $name {
            /// I-One plus offset eya ku-"digit" ephezulu esetshenziswayo.
            /// Lokhu akwehli, ngakho-ke qaphela i-oda lokubala.
            /// `base[size..]` kufanele kube uziro.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` imele i-`a + b *2^W + c* 2^(2W) + ...` lapho i-`W` iyinombolo yamabhithi ohlobo lwedijithi.
            base: [$ty; $n],
        }

        impl $name {
            /// Yenza ibignum kusuka kwidijithi eyodwa.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Yenza ibignum kusuka kunani le-`u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Ibuyisa amadijithi angaphakathi njengocezu `[a, b, c, ...]` njengokuthi inani lenombolo lingu-`a + b *2^W + c* 2^(2W) + ...` lapho i-`W` kuyinombolo yamabhithi ohlobo lwedijithi.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Ibuyisa i `i`-th bit lapho i-bit engu-0 ibaluleke kakhulu.
            /// Ngamanye amagama, into enesisindo `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Ibuyisa i-`true` uma ibignum ingu-zero.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Ibuyisa inani lamabhithi adingekayo ukumela leli nani.
            /// Qaphela ukuthi zero ithathwa njengedinga ama-0 bits.
            pub fn bit_length(&self) -> usize {
                // Yeqa amadijithi abaluleke kakhulu angama-zero.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Awekho amadijithi angewona awuziro, okungukuthi, inombolo ingu-zero.
                    return 0;
                }
                // Lokhu kungathuthukiswa nge-leading_zeros() kanye nokushintshwa okuncane, kepha lokho akukufanele neze ubunzima.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Yengeza i-`other` kuyo futhi ibuyisele isethenjwa sayo esiguquguqukayo.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Isusa i-`other` kusuka kuyo futhi ibuyisele isithenjwa sayo esiguquguqukayo.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Iyaziphindaphinda nge-`other` enezinombolo bese ibuyisa ireferensi yayo engaguquleka.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Iyaziphindaphinda ngo-`2^bits` bese ibuyisa ireferensi yayo engaguquguqukayo.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // shintsha ngamabhithi we-`digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // shintsha ngamabhithi we-`bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // i-self.base [.. amadijithi] ayiziro, asikho isidingo sokushintsha
                }

                self.size = sz;
                self
            }

            /// Iyaziphindaphinda ngo-`5^e` bese ibuyisa ireferensi yayo engaguquguqukayo.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Kunama-n trailing ner ncamashi ku-2 ^ n, futhi osayizi bamadijithi abafanele kuphela amandla alandelanayo amabili, ngakho-ke le yinkomba efanele itafula.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Phindaphinda ngamandla amakhulu kunawo wonke enedijithi eyodwa ngangokunokwenzeka ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... bese uqedela okusele.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Iyaziphindaphinda ngenombolo echazwe yi-`other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (lapho i-`W` iyinombolo yamabhithi ohlobo lwedijithi) bese ibuyisa ireferensi yayo engaguquguqukayo.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // inqubo yangaphakathi.isebenza kangcono lapho i-aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Izahlukanisa nge-`other` enezinombolo bese ibuyisa ireferensi yayo engaguquguqukayo *kanye* nensali.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Hlukanisa isiqu sakho ngenye ibignum, ubhale ngaphezulu i-`q` nge-quotient ne-`r` ngensalela.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Isiphukuphuku esihamba kancane se-base-2 sithathwe kusuka ku-
                // https://en.wikipedia.org/wiki/Division_algorithm
                // I-FIXME isebenzisa isisekelo esikhulu se-($ty) wokwahlukanisa okude.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Setha i-`i` kancane ye-q kuye ku-1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Uhlobo lwedijithi lwe-`Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// lena isetshenziselwa ukuhlolwa kuphela.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}