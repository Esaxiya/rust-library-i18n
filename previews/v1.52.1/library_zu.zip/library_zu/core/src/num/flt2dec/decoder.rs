//! Imisa inani lephoyinti elintantayo liye ezingxenyeni ezithile nangamabanga wephutha.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Inani eliphelele elingasayiniwe elingasayiniwe, elifana nokuthi:
///
/// - Inani langempela lilingana no-`mant * 2^exp`.
///
/// - Noma iyiphi inombolo kusuka ku-`(mant - minus)*2^exp` kuye ku-`(mant + plus)* 2^exp` izofinyelela kunani langempela.
/// Ububanzi bufaka kuphela uma i-`inclusive` ingu-`true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// I-mantissa enesikali.
    pub mant: u64,
    /// Ububanzi bephutha eliphansi.
    pub minus: u64,
    /// Ububanzi bephutha eliphezulu.
    pub plus: u64,
    /// Isichazi esabiwe kusisekelo 2.
    pub exp: i16,
    /// Kuyiqiniso lapho uhla lwamaphutha lufaka phakathi.
    ///
    /// Ku-IEEE 754, lokhu kuyiqiniso lapho imantissa yokuqala yayilingana.
    pub inclusive: bool,
}

/// Inani elingasayiniwe elinekhodi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Okungapheli, kungaba okuhle noma okungalungile.
    Infinite,
    /// Uziro, kungaba okuhle noma okungalungile.
    Zero,
    /// Izinombolo eziphelile ezinemikhakha eminye enekhodi.
    Finite(Decoded),
}

/// Uhlobo lwamaphoyinti entantayo olungaba `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Ubuncane benani elijwayelekile elejwayelekile.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Ibuyisa uphawu (kuyiqiniso uma limbi) nenani le-`FullDecoded` kusuka kunombolo yephoyinti entantayo enikeziwe.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // omakhelwane: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ihlala igcina i-exponent, ngakho-ke i-mantissa ikalwa ngokungajwayelekile.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // omakhelwane: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // lapho maxmant=okungajwayelekile * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // omakhelwane: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}