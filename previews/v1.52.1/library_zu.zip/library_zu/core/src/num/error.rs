//! Izinhlobo zephutha lokuguqulela kuzinhlobo ezihlanganisiwe.

use crate::convert::Infallible;
use crate::fmt;

/// Uhlobo lwephutha lubuyile lapho ukuguqulwa kohlobo oluhlanganisiwe kuhlulekile.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Qondanisa kunokuphoqa ukuze uqiniseke ukuthi ikhodi efana ne-`From<Infallible> for TryFromIntError` ngenhla izogcina isebenza lapho i-`Infallible` iba isibizo se-`!`.
        //
        //
        match never {}
    }
}

/// Iphutha elingabuyiselwa lapho kudluliswa inani eliphelele.
///
/// Leli phutha lisetshenziswa njengohlobo lwephutha lwemisebenzi ye-`from_str_radix()` ezinhlotsheni zenombolo zokuqala, njenge-[`i8::from_str_radix`].
///
/// # Izimbangela ezingaba khona
///
/// Phakathi kwezinye izimbangela, i-`ParseIntError` ingaphonswa ngenxa yendawo emhlophe eholayo noma elandelwayo ngentambo isb., Lapho itholakala kokufakwayo okujwayelekile.
///
/// Kusetshenziswa indlela ye [`str::trim()`] kuqinisekisa ukuthi ayikho indawo emhlophe esele ngaphambi kokuhlwaya.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// I-Enum ukugcina izinhlobo ezahlukahlukene zamaphutha ezingadala ukuthi ukwehlukanisa inani kuhluleke.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Inani elidlulisiwe alinalutho.
    ///
    /// Phakathi kwezinye izimbangela, lokhu okuhlukile kuzokwakhiwa lapho kuhlukaniswa intambo engenalutho.
    Empty,
    /// Iqukethe idijithi engavumelekile kumongo wayo.
    ///
    /// Phakathi kwezinye izimbangela, lokhu okuhlukile kuzokwakhiwa lapho kuhlukaniswa intambo equkethe i-non-ASCII char.
    ///
    /// Lokhu kwahluka futhi kwakhiwa lapho i-`+` noma i-`-` ibekwe endaweni engafanele ngaphakathi kwentambo yodwa noma maphakathi nenombolo.
    ///
    ///
    InvalidDigit,
    /// I-integer inkulu kakhulu ukuthi ingagcinwa kuhlobo lwenombolo ehlosiwe.
    PosOverflow,
    /// I-integer incane kakhulu ukuthi ingagcinwa kuhlobo lwenombolo ehlosiwe.
    NegOverflow,
    /// Inani kwakunguZero
    ///
    /// Lokhu okuhlukile kuzokhishwa lapho intambo yokuhlukanisa inenani lika-zero, okungahle kube semthethweni ngezinhlobo ezingezona zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Ikhipha imbangela enemininingwane yokwehlukanisa inani elihlulekayo.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}