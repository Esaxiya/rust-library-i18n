//! Izakhi zohlobo lwenamba engu-16-bit engabhalisiwe.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Ikhodi entsha kufanele isebenzise izakhi ezihambisanayo ngqo kuhlobo lwakudala.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }