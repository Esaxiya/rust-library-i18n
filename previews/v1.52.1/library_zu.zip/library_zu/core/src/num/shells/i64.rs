//! Izakhi zohlobo lwe-integer ezisayiniwe ezingama-64-bit.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Ikhodi entsha kufanele isebenzise izakhi ezihambisanayo ngqo kuhlobo lwakudala.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }