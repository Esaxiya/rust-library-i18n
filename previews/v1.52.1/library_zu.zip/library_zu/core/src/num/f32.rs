//! Izakhi eziqonde ngqo kuhlobo lwephuzu elintantayo le-`f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Izinombolo ezibalulekile zezibalo zinikezwa ku-`consts` sub-module.
//!
//! Okokuqina okuchazwe ngqo kule mojuli (njengoba kwehlukile kunalokho okuchazwe kumodyuli engaphansi ye `consts`), ikhodi entsha kufanele esikhundleni sayo isebenzise izingqinamba ezihambisanayo ezichazwe ngqo kuhlobo lwe `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// I-radix noma isisekelo sesethulo sangaphakathi se-`f32`.
/// Sebenzisa i-[`f32::RADIX`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // indlela ehlosiwe
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Inani lamadijithi abalulekile kusisekelo 2.
/// Sebenzisa i-[`f32::MANTISSA_DIGITS`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // indlela ehlosiwe
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Inani elilinganisiwe lamadijithi abalulekile kusisekelo 10.
/// Sebenzisa i-[`f32::DIGITS`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // indlela ehlosiwe
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] inani le-`f32`.
/// Sebenzisa i-[`f32::EPSILON`] esikhundleni salokho.
///
/// Lo ngumehluko phakathi kwe `1.0` nenombolo elandelayo enkulu ebonakalekayo.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // indlela ehlosiwe
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Inani elincane kakhulu elilinganiselwe le-`f32`.
/// Sebenzisa i-[`f32::MIN`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // indlela ehlosiwe
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Inani elincane kakhulu elijwayelekile le-`f32`.
/// Sebenzisa i-[`f32::MIN_POSITIVE`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // indlela ehlosiwe
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Inani elilinganiselwe kakhulu le-`f32`.
/// Sebenzisa i-[`f32::MAX`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // indlela ehlosiwe
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Okukhulu kunamandla amancane ejwayelekile akhona we-2 exponent.
/// Sebenzisa i-[`f32::MIN_EXP`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // indlela ehlosiwe
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Amandla amakhulu we-2 exponent.
/// Sebenzisa i-[`f32::MAX_EXP`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // indlela ehlosiwe
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Ubuncane bamandla ajwayelekile we-10 exponent.
/// Sebenzisa i-[`f32::MIN_10_EXP`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // indlela ehlosiwe
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Amandla amakhulu we-10 exponent.
/// Sebenzisa i-[`f32::MAX_10_EXP`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // indlela ehlosiwe
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Hhayi inombolo (NaN).
/// Sebenzisa i-[`f32::NAN`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // indlela ehlosiwe
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// I-Infinity (∞).
/// Sebenzisa i-[`f32::INFINITY`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // indlela ehlosiwe
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// I-infinity engalungile i-(−∞).
/// Sebenzisa i-[`f32::NEG_INFINITY`] esikhundleni salokho.
///
/// # Examples
///
/// ```rust
/// // indlela eyehlisiwe
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // indlela ehlosiwe
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Izikhathi eziyisisekelo zezibalo.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: buyisela okungaguquki kwezibalo kusuka ku-cmath.

    /// I-(π) ehlala njalo ka-Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Umbuthano ogcwele we (τ) njalo
    ///
    /// Ilingana no-2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Inombolo ka-Euler engu-(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// I-radix noma isisekelo sesethulo sangaphakathi se-`f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Inani lamadijithi abalulekile kusisekelo 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Inani elilinganisiwe lamadijithi abalulekile kusisekelo 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] inani le-`f32`.
    ///
    /// Lo ngumehluko phakathi kwe `1.0` nenombolo elandelayo enkulu ebonakalekayo.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Inani elincane kakhulu elilinganiselwe le-`f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Inani elincane kakhulu elijwayelekile le-`f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Inani elilinganiselwe kakhulu le-`f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Okukhulu kunamandla amancane ejwayelekile akhona we-2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Amandla amakhulu we-2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Ubuncane bamandla ajwayelekile we-10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Amandla amakhulu we-10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Hhayi inombolo (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// I-Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// I-infinity engalungile i-(−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Ibuyisa i-`true` uma leli nani lingu-`NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): I-`abs` ayitholakali esidlangalaleni nge-libcore ngenxa yokukhathazeka ngokuphatheka, ngakho-ke lokhu kusetshenziswa kungokusetshenziswa kwangasese ngaphakathi.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Ibuyisa i-`true` uma leli nani lingukungena okuvumayo noma okungapheli okungu-negative, bese kuthi i-`false` kungenjalo
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Ibuyisa i-`true` uma le nombolo ingapheli futhi i-`NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Akunasidingo sokuphatha i-NaN ngokwehlukile: uma i-self iyi-NaN, ukuqhathanisa akulona iqiniso, njengoba nje bekufiswa.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Ibuyisa i-`true` uma inombolo ingu-[subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Amanani aphakathi kwe `0` ne `min` ahlukile.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Ibuyisa i-`true` uma inombolo ingeyona iqanda, ingapheli, i-[subnormal], noma i-`NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Amanani aphakathi kwe `0` ne `min` ahlukile.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Ibuyisa isigaba samaphoyinti entantayo enombolo.
    /// Uma kuzohlolwa impahla eyodwa kuphela, kushesha kakhulu ukusebenzisa isilandiso esithile esikhundleni salokho.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Ibuyisa i-`true` uma i-`self` inophawu oluvumayo, kufaka phakathi i-`+0.0`, `NaN`s enesibonakaliso esisheshayo sesibonakaliso nokungapheli okuhle.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Ibuyisa i-`true` uma i-`self` inophawu olungelona, kufaka phakathi i-`-0.0`, `NaN`s enesibonakaliso esinegama elingelinhle nokungapheli okungalungile.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 ithi: I-isSignMinus(x) iyiqiniso uma ngabe kuphela uma u-x enophawu olungelona iqiniso.
        // i-isSignMinus isebenza nakuma-zeros nama-NaNs.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Ithatha ukuphindaphinda kwe-(inverse) yenombolo, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Iguqula ama-radians abe ama-degree.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Sebenzisa okuqhubekayo ngokunemba okungcono.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Iguqula amadigri abe ama-radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Ibuyisa ubukhulu bezinombolo ezimbili.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Uma enye yezimpikiswano ingu-NaN, enye impikiswano iyabuyiselwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Ibuyisa ubuncane bezinombolo ezimbili.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Uma enye yezimpikiswano ingu-NaN, enye impikiswano iyabuyiselwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Ifinyelela kuziro bese iguqulela kunoma yiluphi uhlobo lwenamba yokuqala, kucatshangwa ukuthi inani liphelile futhi lilingana nalolo hlobo.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Inani kumele:
    ///
    /// * Ungabi yi `NaN`
    /// * Hhayi okungenamkhawulo
    /// * Bonakala ngohlobo lokubuyisa i-`Int`, ngemuva kokunciphisa ingxenye yalo engxenyeni ethile
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // UKUPHEPHA: umuntu ofonayo kufanele agcine inkontileka yezokuphepha ye `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Ukudluliselwa okuluhlaza ku-`u32`.
    ///
    /// Lokhu njengamanje kufana ne `transmute::<f32, u32>(self)` kuwo wonke amapulatifomu.
    ///
    /// Bona i `from_bits` ukuthola ingxoxo ethile ngokuthwala kwalokhu kusebenza (cishe akukho zinkinga).
    ///
    /// Qaphela ukuthi lo msebenzi wehlukile ekusakazweni kwe-`as`, okuzama ukugcina inani *lezinombolo*, hhayi inani le-bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ayilahli!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // UKUPHEPHA: I-`u32` iwuhlobo lwedatha oludala olusobala ukuze sikwazi ukuluhambisa njalo
        unsafe { mem::transmute(self) }
    }

    /// Ukudluliselwa okuluhlaza kusuka ku `u32`.
    ///
    /// Lokhu njengamanje kufana ne `transmute::<u32, f32>(v)` kuwo wonke amapulatifomu.
    /// Kuvela ukuthi lokhu kuyaphatheka ngokumangazayo, ngenxa yezizathu ezimbili:
    ///
    /// * Ama-Floats nama-Int anokuqina okufanayo kuwo wonke amapulatifomu asekelwayo.
    /// * IEEE-754 icacisa ngokunembile ukwakheka okuncane kokuntanta.
    ///
    /// Kodwa-ke kukhona i-caveat eyodwa: ngaphambi kwenguqulo ka-2008 ye-IEEE-754, ukuthi ungayichaza kanjani i-NaN signaling bit ayichazwanga empeleni.
    /// Amapulatifomu amaningi (ikakhulukazi i-x86 ne-ARM) akhethe ukuhumusha okwakumiswe ekugcineni ngo-2008, kepha amanye awazange (ikakhulukazi ama-MIP).
    /// Ngenxa yalokho, wonke ama-NaN asayina ku-MIPS angama-NaN athule ku-x86, nangokuphambene nalokho.
    ///
    /// Esikhundleni sokuzama ukugcina i-signaling-ness cross-platform, lokhu kuqaliswa kuthanda ukugcina izingcezwana ngqo.
    /// Lokhu kusho ukuthi noma yikuphi ukulayishwa okukhokhwa okufakwe kumaNaNs kuzogcinwa noma ngabe umphumela wale ndlela uthunyelwa ngenethiwekhi kusuka kumshini we x86 uye ku MIPS owodwa.
    ///
    ///
    /// Uma imiphumela yale ndlela ilawulwa ubuciko obufanayo obukhiqizile, lapho-ke akukho ukukhathazeka okuphathekayo.
    ///
    /// Uma okokufaka kungeyona i-NaN, ngakho-ke akukho ukukhathazeka okuphathekayo.
    ///
    /// Uma ungakhathaleli ukusayinda (kungenzeka kakhulu), lapho-ke akukho ukukhathazeka okuphathekayo.
    ///
    /// Qaphela ukuthi lo msebenzi wehlukile ekusakazweni kwe-`as`, okuzama ukugcina inani *lezinombolo*, hhayi inani le-bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // UKUPHEPHA: I-`u32` iwuhlobo lwedatha oludala olusobala ukuze sikwazi njalo ukudlulisa kusuka kulo
        // Kuvela ukuthi izingqinamba zokuphepha nge-sNaN bezigcwele ngokweqile!Halala!
        unsafe { mem::transmute(v) }
    }

    /// Buyisela isethulo sememori sale nombolo yamaphoyinti entantayo njengohlu lwe-byte ku-oda le-big-endian (network) byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Buyisela isethulo sememori sale nombolo yamaphoyinti entantayo njengohlu lwe-byte ku-oda elincane le-endian byte.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Buyisela isethulo sememori sale nombolo yephoyinti elintantayo njengamalungu we-byte ngokulandelana kwe-byte yendabuko.
    ///
    /// Njengoba ukusetshenziswa kwendabuko yesikhulumi sethagethi kusetshenziswa, ikhodi ephathekayo kufanele isebenzise i-[`to_be_bytes`] noma i-[`to_le_bytes`], njengokufanele, esikhundleni salokho.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Buyisela isethulo sememori sale nombolo yephoyinti elintantayo njengamalungu we-byte ngokulandelana kwe-byte yendabuko.
    ///
    ///
    /// [`to_ne_bytes`] kufanele kukhethwe ngaphezu kwalokhu lapho kungenzeka.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // UKUPHEPHA: I-`f32` iwuhlobo lwedatha oludala olusobala ukuze sikwazi ukuluhambisa njalo
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Dala inani lephoyinti elintantayo kusuka ekumelweni kwalo njengohlu lwe-byte ku-endian enkulu.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Dala inani lephoyinti elintantayo kusuka ekumelweni kwalo njenge-Byte array ku-endian encane.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Dala inani lephoyinti elintantayo kusuka ekumelweni kwalo njengohlu lwe-byte ku-endian yendabuko.
    ///
    /// Njengoba ukusetshenziswa kwendabuko yesikhulumi sethagethi kusetshenziswa, ikhodi ephathekayo kungenzeka ifuna ukusebenzisa i-[`from_be_bytes`] noma i-[`from_le_bytes`], njengokufanelekile esikhundleni salokho.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Ibuyisa ukuhleleka phakathi kwamanani wedwa namanye.
    /// Ngokungafani nokuqhathanisa okujwayelekile okuyingxenye phakathi kwezinombolo zamaphoyinti entantayo, lokhu kuqhathanisa kuhlala kuveza uku-oda ngokuya ngesilandiso se-totOrder njengoba kuchaziwe ku-IEEE 754 (2008 revision) iphuzu elintantayo.
    /// Amanani ayalwe ngokulandelana okulandelayo:
    /// - I-NaN ethulile
    /// - Ukusayina okungekuhle NaN
    /// - Ukungapheli okungekuhle
    /// - Izinombolo ezingezinhle
    /// - Izinombolo ezingezansi ezingejwayelekile
    /// - Uziro ongemuhle
    /// - Uziro oqondile
    /// - Izinombolo ezivumayo ezivumayo
    /// - Izinombolo ezikahle
    /// - Ukungapheli okuvumayo
    /// - Ukusayina okuhle NaN
    /// - U-NaN othulile
    ///
    /// Qaphela ukuthi lo msebenzi awuhambisani ngaso sonke isikhathi nokusetshenziswa kwe-[`PartialOrd`] ne-[`PartialEq`] kwe-`f32`.Ikakhulu, babheka u-zero ongemuhle novumayo njengolinganayo, kuyilapho i-`total_cmp` ingenjalo.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Uma kwenzeka kunezinto ezimbi, flip zonke izingcezwana ngaphandle kwesibonakaliso ukufeza ukwakheka okufanayo njengamanani wokugcwalisa amabili
        //
        // Kungani lokhu kusebenza?Ukuntanta kwe-IEEE 754 kunezinkambu ezintathu:
        // Isayina kancane, i-exponent ne-mantissa.Iqoqo lezinkambu ze-exponent kanye ne-mantissa zizonke zinempahla i-oda lazo elincane elilingana nobukhulu bezinombolo lapho ubukhulu buchazwa khona.
        // Ubukhulu abuchazwa ngokujwayelekile kumanani we-NaN, kepha i-IEEE 754 totalOrder ichaza amanani we-NaN futhi ukulandela ukuhleleka okuncane.Lokhu kuholela ekuhlelweni okuchazwe kumazwana we-doc.
        // Kodwa-ke, ukumelwa kobukhulu kuyafana ngezinombolo ezingezinhle neziphikisayo-kuphela uphawu lwesiginali oluhlukile.
        // Ukuqhathanisa kalula ukuntanta njengezinombolo ezisayiniwe, sidinga ukufiphaza ama-exponent nama-mantissa bits uma kunezinombolo ezingezinhle.
        // Siguqulela izinombolo ngempumelelo kwifomu le-"two's complement".
        //
        // Ukwenza ukuphenya, sakha imaski ne-XOR ngokumelene nayo.
        // Sibala ngaphandle kwegatsha imaski ye-"all-ones except for the sign bit" kusuka kumanani asayiniwe okungekho emthethweni: uphawu lokushintsha kwesokudla ludlulisa inani eliphelele, ngakho-ke thina si-"fill" imaski enezimpawu zezimpawu, bese siguqulela kokungasayiniwe ukuze sicindezele u-zero kancane.
        //
        // Kumanani amahle, imaski ingawo wonke ama-zero, ngakho-ke ayi-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Khawulela inani kusikhawu esithile ngaphandle kokuthi kuyi-NaN.
    ///
    /// Ibuyisa i-`max` uma i-`self` inkulu kune-`max`, ne-`min` uma i-`self` ingaphansi kuka-`min`.
    /// Ngaphandle kwalokho lokhu kubuyisa i `self`.
    ///
    /// Qaphela ukuthi lo msebenzi ubuyisa i-NaN uma inani lokuqala bekuyi-NaN futhi.
    ///
    /// # Panics
    ///
    /// I-Panics uma i-`min > max`, i-`min` ingu-NaN, noma i-`max` ingu-NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}