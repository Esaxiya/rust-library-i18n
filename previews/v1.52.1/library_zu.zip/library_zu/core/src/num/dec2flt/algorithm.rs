//! Ama-algorithm ahlukahlukene avela ephepheni.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Inombolo yamabhithi abalulekile ku-Fp
const P: u32 = 64;

// Simane sigcine isilinganiso esihle kakhulu sezichasiso ze *all*, ngakho-ke i-"h" eguquguqukayo nezimo ezihambisanayo zingashiywa.
// Lokhu kuhweba ngokusebenza kwama-kilobytes ambalwa wesikhala.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Ezakhiweni eziningi, imisebenzi yamaphoyinti entantayo inosayizi omncane ocacile, ngakho-ke ukunemba kwekhompiyutha kunqunywa ngokwesisekelo sokusebenza ngakunye.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Ku-x86, i x87 FPU isetshenziselwa ukusebenza kwe-float uma izandiso ze-SSE/SSE2 zingatholakali.
// I-x87 FPU isebenza ngamabhithi angama-80 ngokunemba ngokuzenzakalela, okusho ukuthi ukusebenza kuzofinyelela kumabhithi angama-80 okwenza ukuthi ukujikeleza okuphindwe kabili kwenzeke lapho amanani ekugcineni emelelwa njenge
//
// 32/64 amanani entanta.Ukunqoba lokhu, igama lokulawula le-FPU lingasethwa ukuze izibalo zenziwe ngokunemba okufunwayo.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Isakhiwo esisetshenziselwa ukugcina inani langempela legama lokulawula le-FPU, ukuze likwazi ukubuyiselwa lapho isakhiwo sehliswa.
    ///
    ///
    /// I x87 FPU yirejista engama-16-bits onemikhakha yayo elandelayo:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Imibhalo yazo zonke izinkambu iyatholakala kwi-IA-32 Architectures Software Developer's Manual (Umqulu 1).
    ///
    /// Inkambu okuyiyo kuphela efanele ikhodi elandelayo i-PC, Precision Control.
    /// Le nkambu inquma ukunemba kokusebenza okwenziwa yi-FPU.
    /// Ingasethelwa ku:
    ///  - 0b00, ukucacisa okukodwa okungukuthi, ama-32-bits
    ///  - 0b10, ukunemba okuphindwe kabili okungukuthi, ama-bits angama-64
    ///  - 0b11, ukucacisa okunwetshiwe okuphindwe kabili okungukuthi, ama-80-bits (isimo esizenzakalelayo) Inani le-0b01 ligciniwe futhi akufanele lisetshenziswe.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // UKUPHEPHA: imiyalo ye-`fldcw` ihlolwe ukuze ikwazi ukusebenza kahle ngayo
        // noma iyiphi i `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Sisebenzisa i-syntax ye-ATT ukusekela i-LLVM 8 ne-LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Isetha inkambu yokunemba ye-FPU ibe yi-`T` bese ibuyisa i-`FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Bala inani lenkundla ye-Precision Control efanele i-`T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 izingcezu
            8 => 0x0200, // Ama-bits angama-64
            _ => 0x0300, // okuzenzakalelayo, ama-bits angama-80
        };

        // Thola inani loqobo legama elilawulayo ukuze ulibuyisele emuva kwesikhathi, lapho isakhiwo se `FPUControlWord` sesilahliwe UKUPHEPHA: umyalo we-`fnstcw` uhloliwe ukuze ukwazi ukusebenza kahle nganoma iyiphi i-`u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Sisebenzisa i-syntax ye-ATT ukusekela i-LLVM 8 ne-LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Setha igama lokulawula ngokunemba okufunwayo.
        // Lokhu kutholakala ngokufihla ukunemba okudala (ama-bits 8 no-9, i-0x300) bese bekufaka esikhundleni sefulegi elinembile elibalwe ngaphezulu.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Indlela esheshayo yeBellerophon isebenzisa amanani alinganiswe ngomshini nokuntanta.
///
/// Lokhu kukhishwa kungenziwa umsebenzi ohlukile ukuze kuzanywe ngaphambi kokwakha i-bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Siqhathanisa inani eliqondile ne-MAX_SIG eduze kokuphela, lokhu nje kuyinqaba esheshayo, eshibhile (futhi kukhulula yonke enye ikhodi ekukhathazekeni ngokugeleza).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Indlela esheshayo ixhomeke ekubaleni kwe-arithmetic kwinani elifanele lamabhithi ngaphandle kokuqoqwa okuphakathi.
    // Ku-x86 (ngaphandle kwe-SSE noma i-SSE2) lokhu kudinga ukunemba kwesitaki se-x87 FPU ukuze kuguqulwe ukuze kuzungeze ngqo ku-64/32 bit.
    // Umsebenzi we `set_precision` unakekela ukusetha ngokunemba ekwakhiweni kwezakhiwo okudinga ukukusetha ngokushintsha isimo somhlaba jikelele (njengegama lokulawula le x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Icala e <0 alikwazi ukugoqelwa kwelinye i-branch.
    // Amandla amabi aholela engxenyeni ephindaphindekayo yenxenye kanambambili, eyindilinga, edala amaphutha angempela (futhi ngezikhathi ezithile abaluleke impela!) Kumphumela wokugcina.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// I-Algorithm Bellerophon yikhodi engasho lutho elungiselelwa ngokuhlaziywa kwezinombolo okungezona okuncane.
///
/// Izungeza `` f '' ku-float enezingqinamba ezingama-64 futhi iyiphindaphinde ngokusondela okuhle kwe-`10^e` (ngefomethi efanayo yephoyinti elintantayo).Lokhu kuvame ngokwanele ukuthola imiphumela efanele.
/// Kodwa-ke, lapho umphumela useduze nohhafu phakathi kokuntanta okubili kwe (ordinary), iphutha elihlanganayo lokuphindaphinda ukusondelana okumbili lisho ukuthi umphumela ungavalwa ngamabhithi ambalwa.
/// Uma lokhu kwenzeka, i-Algorithm R ephindaphindayo ilungisa izinto.
///
/// I-hand-wavy "close to halfway" yenziwa yanemba ngokuhlaziywa kwezinombolo ephepheni.
/// Ngamazwi kaClinger:
///
/// > I-Slop, evezwe ngamayunithi encanyana ebaluleke kakhulu, iyisibopho esihlanganisiwe sephutha
/// > kunqwabelene ngesikhathi sokubalwa kwephoyinti lokuntanta lokusondela ku-f * 10 ^ e.(I-Slop ingukuthi
/// > hhayi ukubophezeleka kwephutha leqiniso, kepha kukhawula umehluko phakathi kokuqagela z no
/// > ukuqagela okungcono kakhulu okusebenzisa ama-p bits wencazelo.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Amacala abs(e) <log5(2^N) aku-fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ingabe i-slop inkulu ngokwanele ukwenza umehluko lapho usondelana n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// I-algorithm ye-iterative ethuthukisa ukulinganiselwa kwephoyinti elintantayo le-`f * 10^e`.
///
/// I-iteration ngayinye ithola iyunithi eyodwa endaweni yokugcina isondele, okuthatha isikhathi eside kabi ukuhlangana uma i `z0` icishe kancane.
/// Ngenhlanhla, lapho isetshenziswa njenge-backback ye-Bellerophon, ukulinganisa kokuqala kuvaliwe okungenani nge-ULP eyodwa.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Thola izinombolo eziphusile ezingu-`x`, `y` ngendlela yokuthi i-`x / y` iyi-`(f *10^e) / (m* 2^k)` ncamashi.
        // Lokhu akugcini nje ngokugwema ukubhekana nezimpawu ze-`e` ne-`k`, futhi siqeda amandla wezinto ezimbili ezijwayelekile ku-`10^e` naku-`2^k` ukwenza izinombolo zibe zincane.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Lokhu kubhalwe ngokungaqondakali ngoba ama-bignums ethu awazisekeli izinombolo ezingezinhle, ngakho-ke sisebenzisa imininingwane ephelele + yezimpawu.
        // Ukuphindaphindwa ngama-m_digits akukwazi ukugcwala.
        // Uma i-`x` noma i-`y` inkulu ngokwanele ukuthi sidinga ukukhathazeka ngokuchichima, khona-ke zikhulu ngokwanele ukuthi i-`make_ratio` inciphise ingxenyenamba ngesilinganiso esingu-2 ^ 64 noma ngaphezulu.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Awudingi x futhi, gcina i clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Usadinga y, yenza ikhophi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Njengoba kunikezwe i-`x = f` ne-`y = m` lapho i-`f` imelela amadijithi wokufaka njengenjwayelo futhi i-`m` ingukubaluleka kokulinganiselwa kwephoyinti elintantayo, yenza isilinganiso esingu-`x / y` silingane no-`(f *10^e) / (m* 2^k)`, okungenzeka sincishiswe ngamandla womabili afana ngawo.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ngaphandle kokuthi sinciphisa ingxenyenamba ngamandla athile amabili.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Lokhu akukwazi ukugcwala ngoba kudinga i-`e` ne-`k` engemihle, engenzeka kuphela ngamanani asondele kakhulu ku-1, okusho ukuthi i-`e` ne-`k` izoba ncanyana ngokuqhathaniswa.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Lokhu nakho ngeke kuchichime nakho, bheka ngenhla.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), iphinde inciphise ngamandla afanayo amabili.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Ngokomqondo, i-Algorithm M iyindlela elula yokuguqula idesimali ibe iflothi.
///
/// Sakha isilinganiso esilingana ne-`f * 10^e`, bese siphonsa amandla amabili size sinikeze ukubaluleka okuyintanta okusebenzayo.
/// I-exponent kanambambili i-`k` inombolo yezikhathi lapho siphindaphinde khona i-numerator noma i-denominator ngababili, okungukuthi, ngaso sonke isikhathi i-`f *10^e` ilingana ne-`(u / v)* 2^k`.
/// Lapho sesikutholile ukubaluleka, sidinga kuphela ukujikeleza ngokuhlola okusele kwesigaba, okwenziwa emisebenzini yabasizi ngokuqhubekayo ngezansi.
///
///
/// Le algorithm ihamba kancane kakhulu, ngisho nokwenza kahle okuchazwe ku-`quick_start()`.
/// Kodwa-ke, ama-algorithm alula kakhulu ukuvumelanisa nokuchichima, ukugcwala, kanye nemiphumela engajwayelekile.
/// Lokhu kuqaliswa kuthatha isikhathi lapho iBellerophon ne-Algorithm R zikhungathekile.
/// Ukuthola ukugeleza okuchichimayo nokuchichima kulula: Isilinganiso namanje akusona isibonakaliso sangaphakathi kwebanga, kepha i-minimum/maximum ekhululiwe isifinyelelwe.
/// Endabeni yokuchichima, simane sibuyise okungapheli.
///
/// Ukuphatha ukugeleza nokuningi okungajwayelekile kunzima kakhulu.
/// Inkinga eyodwa enkulu ukuthi, ngesikhombi esincane, isilinganiso singahle sibe sikhulu kakhulu ekuchazeni okuthile.
/// Bona i underflow() ngemininingwane.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Ukulungiselela okungenzeka kwe-FIXME: yenza i-big_to_fp ukuze sikwazi ukwenza okulingana ne-fp_to_float(big_to_fp(u)) lapha, kuphela ngaphandle kokuhlanganisa kabili.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Kufanele sime esikalini esincane, uma silinda kuze kube yi-`k < T::MIN_EXP_INT`, lapho-ke sizobe sesicishiwe ngesici ezimbili.
            // Ngeshwa lokhu kusho ukuthi kufanele sibeke izinombolo ezikhethekile ezinesilinganiso esincane.
            // I-FIXME ithola ukwakheka okuhle kakhulu, kepha sebenzisa ukuhlolwa kwe `tiny-pow10` ukuze uqiniseke ukuthi ilungile ngempela!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Yeqa ngaphezulu kokuphindaphindwayo kwe-Algorithm M ngokuhlola ubude bayo.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Ubude obuncane ukulinganiselwa kwe-base logarithm, ne-log(u / v) = log(u), log(v).
    // Isilinganiso sicishiwe okungenani ngo-1, kepha ngaso sonke isikhathi isilinganiso esilinganiselwe, ngakho-ke iphutha ku-log(u) naku-log(v) lingophawu olufanayo futhi liyakhanselwa (uma womabili emakhulu).
    // Ngakho-ke iphutha le-log(u / v) likhulu kakhulu futhi.
    // Isilinganiso sokukhonjwa sinye lapho i-u/v ikukubaluleka okuphakathi nobubanzi.Ngakho-ke isimo sethu sokunqanyulwa yi-log2(u / v) okuyizinto ezibalulekile, i-plus/minus eyodwa.
    // I-FIXME Ukubheka kancane kwesibili kungathuthukisa isilinganiso futhi kugweme ukwahlukana okunye.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Ukugeleza okungaphansi noma okungajwayelekile.Yiyekele ekusebenzeni okuyinhloko.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Ukuchichima.Yiyekele ekusebenzeni okuyinhloko.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ukulinganiswa akuyona into esezingeni eliphakathi ne-eksponenti encane, ngakho-ke sidinga ukuhlanganisa izingcezu ezeqile futhi silungise i-exponent ngokufanele.
    // Inani langempela manje libukeka kanjena:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q kuncanyana.(emelwe yi-rem)
    //
    // Ngakho-ke, lapho izingcezu ezihlanganisiwe zikhona!= 0.5 ULP, banquma ukuzungeza ngokwabo.
    // Lapho zilingana futhi okusele kungezona zero, inani lisadinga ukuqoqwa.
    // Kuphela lapho izingcezu ezihlanganisiwe ziyi-1/2 futhi okusele kungu-zero, lapho sinesimo sokuya kohlangothini.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ukujikeleza okuzungezile kuze kube ngisho nokulinganiswa, kuthintwe ngokujikeleza ngokuya ngengxenye esele yesigaba.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}