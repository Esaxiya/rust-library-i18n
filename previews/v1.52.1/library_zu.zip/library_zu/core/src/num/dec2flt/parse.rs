//! Ukuqinisekisa nokubola kwentambo yedesimali yefomu:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ngamanye amagama, i-syntax ejwayelekile yokuntanta, ngaphandle kokuhlukile: Alukho uphawu, futhi akukho ukuphathwa kwe "inf" ne "NaN".Lokhu kusingathwa umsebenzi womshayeli (super::dec2flt).
//!
//! Yize ukubona okokufaka okuvumelekile kulula kakhulu, le mojule nayo kufanele yenqabe ukuhluka okungenakubalwa okungavumelekile, ingalokothi ibe yi-panic, futhi yenze amasheke amaningi amanye amamojula athembele kuwo hhayi i-panic (noma ukugcwala).
//!
//! Ukwenza izinto zibe zimbi kakhulu, konke lokho kwenzeka ngokudlula okukodwa kokufaka.
//! Ngakho-ke, qaphela lapho uguqula noma yini, bese ubheka kabili namanye amamojula.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Izingxenye ezithokozisayo zentambo yedesimali.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Isikhombi sedesimali, siqinisekisiwe ukuba namadijithi angaphansi kuka-18.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Ihlola ukuthi ngabe umucu wokufaka uyinombolo yephoyinti elintantayo elivumelekile futhi uma kunjalo, thola ingxenye ebalulekile, ingxenye yeqhezu, kanye ne-eksponenti ekulo.
/// Ayiphathi izimpawu.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Awekho amadijithi ngaphambi kwe 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Sidinga okungenani idijithi eyodwa ngaphambi noma ngemuva kwephoyinti.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // I-trailing junk ngemuva kwengxenye ye-fractional
            }
        }
        _ => Invalid, // I-trailing junk ngemuva kwentambo yamadijithi yokuqala
    }
}

/// Iqamba amadijithi wedesimali aze afike kuzinhlamvu zokuqala ezingezona izinombolo
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Ukukhishwa kwe-Exponent nokuhlola iphutha.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // I-trailing junk ngemuva kwe-eksponenti
    }
    if number.is_empty() {
        return Invalid; // Ukukhipha okungenalutho
    }
    // Kuleli qophelo, ngokuqinisekile sinentambo evumelekile yamadijithi.Kungaba yinde kakhulu ukufaka ku-`i64`, kepha uma kukhulu kangako, okokufaka ngokuqinisekile akulutho noma kungapheli.
    // Njengoba u-zero ngamunye kumadijithi wedesimali alungisa kuphela i-eksponenti ngu +/-1, ku-exp=10 ^ 18 okokufaka kuzodingeka kube yi-exabyte (!) engu-17 yamazero ukusondela kude ukudlula nokuba kube ukuphela.
    //
    // Leli akulona icala lokusebenzisa esidinga ukulinakekela ngqo.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}