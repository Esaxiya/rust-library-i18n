//! Imisebenzi yokusetshenziswa kwama-bignums angenzi mqondo kakhulu ukuba iphenduke izindlela.

// I-FIXME Igama lale mojuli liyishwa elincane, ngoba amanye amamojula nawo angenisa i `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Hlola ukuthi ukuncishiswa kwawo wonke amabhithi akubaluleki kangako kune-`ones_place` kungenisa iphutha elihlobene elingaphansi, elilinganayo, noma elikhulu kune-0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Uma onke ama-bits asele engunothi, yi-= 0.5 ULP, ngaphandle kwalokho> 0.5 Uma kungasekho izingcezu (half_bit==0), okungezansi kubuye kubuye ngokulingana i-Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Iguqula intambo ye-ASCII equkethe amadijithi wedesimali kuphela ibe yi-`u64`.
///
/// Ayenzi amasheke okuchichima noma izinhlamvu ezingavumelekile, ngakho-ke uma umuntu ofonayo engaqapheli, umphumela uyimbumbulu futhi uyakwazi i panic (yize kungeke kube yi `unsafe`).
/// Ngokwengeziwe, izintambo ezingenalutho ziphathwa njengeqanda.
/// Lo msebenzi ukhona ngoba
///
/// 1. ukusebenzisa i-`FromStr` ku-`&[u8]` kudinga i-`from_utf8_unchecked`, okuyinto embi, futhi
/// 2. ukuhlanganisa imiphumela ye-`integral.parse()` ne-`fractional.parse()` kuyinkimbinkimbi ukwedlula wonke lo msebenzi.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Iguqula umucu wamadijithi we-ASCII ube yi-bignum.
///
/// Njengo-`from_str_unchecked`, lo msebenzi uncike kumbhali ukukhipha okungewona amadijithi.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Isonga i-bignum ibe yinamba engu-64 bit.I-Panics uma inombolo inkulu kakhulu.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Ikhipha uhla lwamabhithi.

/// Inkomba 0 yinto ebaluleke kakhulu futhi ububanzi buvuleke uhhafu njengenjwayelo.
/// I-Panics uma iceliwe ukukhipha ama-bits amaningi kunokulingana kuhlobo lokubuyisa.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}