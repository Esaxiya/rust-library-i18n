//! Iguqula izintambo zedesimali zibe izinombolo zamaphoyinti ezintantayo kanambambili we-IEEE 754.
//!
//! # Isitatimende senkinga
//!
//! Sinikezwa intambo yedesimali efana ne `12.34e56`.
//! Le ntambo inezingxenye ezihlangene ze-(`12`), i-fractional (`34`), kanye nezingxenye ze-(`56`) ezichazayo.Zonke izingxenye ziyakhethwa futhi zihunyushwa njengeqanda uma zilahlekile.
//!
//! Sifuna inombolo yephoyinti le-IEEE 754 eliseduze kakhulu nenani eliqondile lentambo yedesimali.
//! Kuyaziwa ukuthi izintambo eziningi zedesimali azinakho ukunqanyulwa kokumiswa kusisekelo sesibili, ngakho-ke sizungeza amayunithi we-0.5 endaweni yokugcina (ngamanye amagama, futhi ngangokunokwenzeka).
//! Izibopho, amanani wedesimali ncamashi okuhamba phakathi kokuntanta okubili okulandelanayo, kuxazululwa ngecebo lokuya ngasentshonalanga, elaziwa nangokuthi ukugoqwa kwebhange.
//!
//! Akunasidingo sokusho, lokhu kunzima impela, maqondana nobunzima bokuqalisa nangokuya ngemijikelezo ye-CPU ethathiwe.
//!
//! # Implementation
//!
//! Okokuqala, asizinaki izimpawu.Noma kunalokho, siyisusa ekuqaleni kwenqubo yokuguqula bese siyifaka kabusha ekugcineni.
//! Lokhu kulungile kuwo wonke amacala we-edge kusukela ukuntanta kwe-IEEE kulinganiswe nxazonke, kunganakwa okukodwa kumane kuphenye okuncane kuqala.
//!
//! Ngemuva kwalokho sisusa iphuzu ledesimali ngokulungisa i-eksponenti: Ngokuqondakalayo, i-`12.34e56` iphenduka ibe yi-`1234e54`, esiyichaza ngenombolo enhle engu-`f = 1234` kanye nenamba engu-`e = 54`.
//! Isethulo se-`(f, e)` sisetshenziswa cishe yonke ikhodi edlule isigaba sokuhlaziya.
//!
//! Sibe sesizama uchungechunge olude lwamacala akhethekile ajwayelekile futhi abizayo asebenzisa izinombolo ezisayizi yomshini nezinombolo zamaphoyinti amancane, ezinamanani amisiwe (i-`f32`/`f64` yokuqala, bese kuba uhlobo olunama-64 bit habo, `Fp`).
//!
//! Lapho konke lokhu kwehluleka, siluma inhlamvu bese sisebenzisa i-algorithm elula kepha ehamba kancane ebandakanya ukufaka ikhompiyutha i-`f * 10^e` ngokuphelele nokwenza usesho oluphindaphindwayo lokulinganisa okuhle kakhulu.
//!
//! Ngokuyinhloko, le mojule nezingane zayo zisebenzisa ama-algorithms achazwe ku:
//! "How to Read Floating Point Numbers Accurately" nguWilliam D.
//! Clinger, iyatholakala ku-inthanethi: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Ngaphezu kwalokho, kunemisebenzi eminingi yokusiza esetshenziswe ephepheni kepha ayitholakali ku-Rust (noma okungenani kumongo).
//! Uhlobo lwethu luyinkimbinkimbi ngokwengeziwe yisidingo sokuphatha ukuchichima nokuchichima kanye nesifiso sokuphatha izinombolo ezingejwayelekile.
//! I-Bellerophon ne-Algorithm R inenkinga yokuchichima, okungajwayelekile, nokuchichima.
//! Ngokuguqukayo sishintshela ku-Algorithm M (ngokuguqulwa okuchazwe esigabeni 8 sephepha) ngaphambi kokuthi okokufaka kungene esifundeni esibucayi.
//!
//! Esinye isici esidinga ukunakwa yi-`` RawFloat '' trait lapho cishe yonke imisebenzi ifakwa khona.Umuntu angacabanga ukuthi kwanele ukudlulisa ku-`f64` bese usakaza umphumela ku-`f32`.
//! Ngeshwa akuwona umhlaba esihlala kuwo, futhi lokhu akuhlangene nokusebenzisa isisekelo se-base ezimbili noma isigamu-to-even.
//!
//! Cabanga ngokwesibonelo izinhlobo ezimbili i-`d2` ne-`d4` ezimele uhlobo lwedesimali olunamadijithi amabili wamadesimali namadijithi amane wedesimali ngalunye bese uthatha i-"0.01499" njengokufaka.Masisebenzise ukugoqa uhhafu.
//! Ukuya ngqo kumadijithi amabili wedesimali kunikeza i-`0.01`, kepha uma siqala sifinyelele kumadijithi amane kuqala, sithola i-`0.0150`, ebese iqoqelwe ku-`0.02`.
//! Umgomo ofanayo uyasebenza nakweminye imisebenzi futhi, uma ufuna ukunemba kwe 0.5 ULP udinga ukwenza *konke* ngokunemba okuphelele nxazonke *kanye kanye, ekugcineni*, ngokubheka zonke izingcezu ezisikiwe ngasikhathi sinye.
//!
//! FIXME: Yize ukuphindwa kwekhodi ethile kudingekile, mhlawumbe izingxenye ezithile zekhodi zingashushumbiswa ukuze kukhishwe ikhodi encane.
//! Izingxenye ezinkulu zama-algorithms azimele ngohlobo lwe-float ukuze lukhishwe, noma zidinga ukufinyelela kuphela kuma-constants ambalwa, angadluliswa njengamapharamitha.
//!
//! # Other
//!
//! Ukuguqulwa akufanele *kube* panic.
//! Kukhona okuqinisekisiwe ne-panics okusobala kukhodi, kepha akufanele neze kuqhutshwe futhi kusebenze njengokuhlolwa kwempilo yangaphakathi kuphela.Noma iyiphi i-panics kufanele ibhekwe njengesiphazamisi.
//!
//! Kunezivivinyo zamayunithi kepha azanele ngokwanele ekuqinisekiseni ukunemba, zimboza kuphela amaphesenti amancane amaphutha.
//! Ukuhlolwa okubanzi kakhulu kutholakala enkombeni `src/etc/test-float-parse` njengombhalo we-Python.
//!
//! Inothi ekuchichimeni okuphelele: Izingxenye eziningi zaleli fayela zenza izibalo nge-exponent `e`.
//! Ngokuyinhloko, sigudluza iphuzu ledesimali sizungeze: Ngaphambi kwedijithi yedesimali yokuqala, ngemuva kwedijithi yokugcina yedesimali, njalonjalo.Lokhu kungachichima uma kwenziwa ngokunganaki.
//! Sithembele kwisinqandamathe esincishisiwe ukukhipha kuphela izinciphisi ezanele ngokwanele, lapho i "sufficient" isho i "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Izamukeli ezinkulu ziyamukelwa, kepha asenzi izibalo ngazo, ziguqulwa ngokushesha zibe yi-{positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Laba bobabili banezivivinyo zabo.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Iguqula intambo kusisekelo se-10 iye ku-float.
            /// Yamukela i-exponent ekhethiwe yokuzikhethela.
            ///
            /// Lo msebenzi wamukela izintambo ezifana ne-
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', noma ngokufanayo, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', noma, ngokufanayo, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// Imhlophe futhi ehola futhi elandelayo imele iphutha.
            ///
            /// # Grammar
            ///
            /// Zonke izintambo ezihambisana nohlelo lolimi lwe-[EBNF] zizoholela ekubuyisweni kwe-[`Ok`]:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Izimbungulu ezaziwayo
            ///
            /// Kwezinye izimo, ezinye izintambo okufanele zenze iflat evumelekile esikhundleni sokubuyisa iphutha.
            /// Bona i [issue #31407] ngemininingwane.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, Intambo
            ///
            /// # Buyisela inani
            ///
            /// `Err(ParseFloatError)` uma intambo ibingamele inombolo evumelekile.
            /// Ngaphandle kwalokho, i-`Ok(n)` lapho i-`n` iyinombolo yamaphoyinti entantayo amelwe yi-`src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Iphutha elingabuyiselwa lapho kudluliswa iflothi.
///
/// Leli phutha lisetshenziswa njengohlobo lwephutha ekusetshenzisweni kwe-[`FromStr`] kwe-[`f32`] ne-[`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Ihlukanisa intambo yedesimali ibe uphawu kanye nokunye, ngaphandle kokuhlola noma ukuqinisekisa okusele.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Uma intambo ingavumelekile, asilokothi sisebenzise uphawu, ngakho-ke asidingi ukuqinisekisa lapha.
        _ => (Sign::Positive, s),
    }
}

/// Iguqula intambo yedesimali ibe inombolo yephoyinti elintantayo.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Umsebenzi omkhulu wokuguqulwa kwedesimali-ukuntanta: Hlela konke okwenziwayo ngaphambili bese uthola ukuthi iyiphi i-algorithm okufanele yenze ukuguqulwa kwangempela.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ukhiphe iphoyinti ledesimali.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // IBig32x40 inqunyelwe kumabhithi ayi-1280, ahumusha afinyelela kumadijithi angama-385 wedesimali.
    // Uma sidlula lokhu, sizoshayeka, ngakho-ke senza iphutha ngaphambi kokusondela kakhulu (kungakapheli i-10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Manje i-eksponenti ngokuqinisekile ingena ku-16 bit, esetshenziswa kuwo wonke ama-algorithms amakhulu.
    let e = e as i16;
    // I-FIXME Le mingcele ilondolozeka ngokweqile.
    // Ukuhlaziywa ngokucophelela kwezindlela zokwehluleka kweBellerophon kungavumela ukuyisebenzisa ezimeni eziningi ukusheshisa okukhulu.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Njengoba kubhaliwe, lokhu kulungiselela kahle (bona i #27130, noma kubhekiswa kunguqulo endala yekhodi).
// `inline(always)` kuyindlela yokusebenza yalokho.
// Zimbili kuphela izingosi zezingcingo futhi azenzi usayizi wekhodi ube mubi kakhulu.

/// Ama-Strip zeros lapho kungenzeka khona, noma ngabe lokhu kudinga ukuguqula okokukhipha
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // Ukusika la maziro akushintshi lutho kepha kungavumela indlela esheshayo (<amadijithi ayi-15).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Yenza lula izinombolo zefomu u-0.0 ... x no-x ... 0.0, ulungise i-exponent ngokufanele.
    // Lokhu kungahle kungabi yi-win ngaso sonke isikhathi (mhlawumbe kusunduza izinombolo ezithile endleleni esheshayo), kepha kwenza ezinye izingxenye zibe lula kakhulu (ikakhulukazi, kulinganiselwa ubukhulu bevelu).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Ibuyisa umkhawulo ophakeme ongcolile ongasayizi ngosayizi (log10) wenani elikhulu kunawo wonke i-Algorithm R ne-Algorithm M ezowenza ngenkathi isebenza kudesimali enikeziwe.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // Akudingeki sikhathazeke kakhulu ngokuchichima lapha ngenxa ye trivial_cases() ne-parser, ehlunga okokufaka okwedlulele kakhulu kithina.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Endabeni e>=0, womabili ama-algorithm ahlanganisa cishe i-`f * 10^e`.
        // I-Algorithm R iyaqhubeka nokwenza izibalo ezithile eziyinkimbinkimbi ngalokhu kepha singakushaya indiva lokho kokubopha okuphezulu ngoba futhi kunciphisa ingxenyenamba ngaphambili, ngakho-ke sinezinto eziningi lapho.
        //
        f_len + (e as u64)
    } else {
        // Uma e <0, I-Algorithm R yenza cishe into efanayo, kepha i-Algorithm M iyahluka:
        // Izama ukuthola inombolo enhle k efana nokuthi i-`f << k / 10^e` ingukubaluleka okuphakathi nobubanzi.
        // Lokhu kuzoholela cishe ku-`2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Okokufaka okukodwa okubangela lokhu kungu-0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Ibona ukuchichima okusobala nokuchichima ngaphandle kokubheka ngisho namadijithi wedesimali.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Ayekhona amaqanda kodwa akhunyulwa yi simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Lokhu ukulinganiselwa okungafanele kwe-ceil(log10(the real value)).
    // Akudingeki sikhathazeke kakhulu ngokuchichima lapha ngoba ubude bokufaka bumncane (okungenani buqhathaniswa no-2 ^ 64) futhi i-parser isivele iphatha izichasiselo ezinani lazo eliphelele likhulu kune-10 ^ 18 (okusafushane ngo-10 ^ 19 kufushane ka 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}