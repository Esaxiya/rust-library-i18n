use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// I-interface yokubhekana nama-itynator asynchronous.
///
/// Lokhu ukusakaza okuyinhloko i trait.
/// Ukuthola okuningi ngomqondo wemifudlana ngokuvamile, sicela ubone i [module-level documentation].
/// Ikakhulu, ungahle ufune ukwazi ukuthi ungayenza kanjani i [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Uhlobo lwezinto ezinikezwe ukusakaza.
    type Item;

    /// Zama ukukhipha inani elilandelayo lalokhu kusakaza, kubhaliswa umsebenzi wamanje wokuvuka uma inani lingakatholakali, nokubuyisa i-`None` uma ukusakaza kuphelile.
    ///
    /// # Buyisela inani
    ///
    /// Kunamanani amaningana wokubuya, ngalinye likhombisa isimo sokusakaza esihlukile:
    ///
    /// - `Poll::Pending` kusho ukuthi inani elilandelayo lokusakazwa alikakalungi okwamanje.Ukuqaliswa kuzoqinisekisa ukuthi umsebenzi wamanje uzokwaziswa lapho inani elilandelayo lingalunga.
    ///
    /// - `Poll::Ready(Some(val))` kusho ukuthi ukusakaza kukhiqize ngempumelelo inani, i-`val`, futhi kungahle kukhiqize amanani amanye kumakholi we-`poll_next` alandelayo.
    ///
    /// - `Poll::Ready(None)` kusho ukuthi ukusakaza kunqanyuliwe, futhi i-`poll_next` akufanele iphinde icelwe.
    ///
    /// # Panics
    ///
    /// Lapho ukusakaza sekuqedile (kubuyiselwe i-`Ready(None)` from `poll_next`), kubiza indlela yayo ye-`poll_next` futhi kungenzeka ukuthi i panic, ivimbe unomphela, noma ibangele ezinye izinhlobo zezinkinga; i-`Stream` trait ayibeki izidingo ngemiphumela yocingo olunjalo.
    ///
    /// Kodwa-ke, njengoba indlela ye `poll_next` ingamakiwe i `unsafe`, imithetho ejwayelekile ye Rust iyasebenza: izingcingo akufanele neze zibangele ukungachazeki (inkohlakalo yenkumbulo, ukusetshenziswa okungalungile kwemisebenzi ye-`unsafe`, noma okunye okunjalo), ngaphandle kwesimo sokusakaza.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Ibuyisa imingcele ebangeni elisele lokusakaza.
    ///
    /// Ngokuqondile, i-`size_hint()` ibuyisa isiHlathi lapho into yokuqala ingumkhawulo ophansi, futhi into yesibili ingukuboshwa okuphezulu.
    ///
    /// Ingxenye yesibili yeTuple ebuyisiwe ithi [`Option`]`<`[usize`]`> `.
    /// I-[`None`] lapha isho ukuthi noma kungekho mkhawulo owaziwayo ongaphezulu, noma isibopho esingaphezulu sikhulu kune-[`usize`].
    ///
    /// # Amanothi wokuqalisa
    ///
    /// Akuphoqelelwa ukuthi ukusetshenziswa kokusakazwa kuveza inani lezinto ezimenyezelwe.Ukusakaza kwekalishi kungakhipha ngaphansi kwesibopho esiphansi noma ngaphezulu kwesibopho esiphezulu sezinto.
    ///
    /// `size_hint()` ihloselwe ikakhulukazi ukusetshenziselwa ukulungiselelwa okufana nokubekisa isikhala sezinto zokusakaza, kepha akumele kuthenjwe isib., yekela ukubalwa kwemingcele kukhodi engaphephile.
    /// Ukusetshenziswa okungalungile kwe-`size_hint()` akufanele kuholele ekuphulweni kwememori yokuphepha.
    ///
    /// Lokho kusho ukuthi ukuqaliswa kufanele kunikeze isilinganiso esifanele, ngoba uma kungenjalo kungaba ukwephula umthetho olandelwayo we-trait.
    ///
    /// Ukusebenza okuzenzakalelayo kubuyisa `(0,` [`None`]`)`okulungile kunoma yikuphi ukusakaza.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}