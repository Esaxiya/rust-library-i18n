//! Ukuqanjwa kwe-asynchronous composable.
//!
//! Uma i-futures ingamanani we-asynchronous, khona-ke ukusakaza kungama-itynator we-asynchronous.
//! Uma uzithole uneqoqo le-asynchronous lohlobo oluthile, futhi ubudinga ukwenza umsebenzi kuzakhi zeqoqo elishiwoyo, uzongena ngokushesha ku 'streams'.
//! Imifudlana isetshenziswa kakhulu kukhodi ye-idiomatic asynchronous Rust, ngakho-ke kufanele ujwayelane nayo.
//!
//! Ngaphambi kokuchaza okuningi, ake sikhulume ngokuthi le module ihlelwe kanjani:
//!
//! # Organization
//!
//! Le mojula ihlelwe kakhulu ngohlobo:
//!
//! * [Traits] yingxenye eyinhloko: lawa ma-traits achaza ukuthi hlobo luni lwemifudlana ekhona nokuthi yini ongayenza ngayo.Izindlela zalezi traits kufanelekile ukufaka isikhathi esengeziwe sokufunda.
//! * Imisebenzi inikeza izindlela ezithile eziwusizo zokwenza eminye imifudlana eyisisekelo.
//! * Ama-Structs imvamisa kuyizinhlobo ezibuyayo zezindlela ezahlukahlukene kule traits yale module.Imvamisa uzofuna ukubheka indlela edala i `struct`, kune-`struct` uqobo.
//! Ngemininingwane eminingi yokuthi kungani, bona '[Implementing Stream](#implementation-stream)'.
//!
//! [Traits]: #traits
//!
//! Yilokho kuphela!Ake simbe emifudlaneni.
//!
//! # Stream
//!
//! Inhliziyo nomphefumulo walesi sigaba yi [`Stream`] trait.Umnyombo we [`Stream`] ubukeka kanjena:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ngokungafani ne-`Iterator`, i-`Stream` yenza umehluko phakathi kwendlela ye-[`poll_next`] esetshenziswa lapho kwenziwa i-`Stream`, kanye nendlela ye-(to-be-implemented) `next` esetshenziswa lapho kudla umfudlana.
//!
//! Abathengi be `Stream` badinga kuphela ukubheka i-`next`, okuthi uma ibizwa, ibuyise i-future ekhipha i-`Option<Stream::Item>`.
//!
//! I-future ebuyiswe yi-`next` izokhiqiza i-`Some(Item)` inqobo nje uma kukhona izinto, futhi uma seziphelile zonke, izokhipha i-`None` ukukhombisa ukuthi i-iteration isiqediwe.
//! Uma silinde okuthile okungaxazululeki ukuxazululwa, i-future izolinda kuze kube yilapho ukusakaza sekukulungele ukuphinda kuveze futhi.
//!
//! Ukusakaza ngakunye kungakhetha ukuqala kabusha i-iteration, ngakho-ke ukubiza i-`next` futhi kungahle noma kungaphinde kuveze i-`Some(Item)` futhi ngesinye isikhathi.
//!
//! Incazelo ephelele ye-"`Stream`] ifaka nezinye izindlela eziningi, kepha ziyizindlela ezizenzakalelayo, ezakhiwe ngaphezulu kwe [`poll_next`], ngakho-ke uzithola mahhala.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Kusetshenziswa Ukusakaza
//!
//! Ukwakha ukusakazwa kwakho kufaka izinyathelo ezimbili: ukudala i-`struct` ukubamba isimo sokusakaza, bese usebenzisa i-[`Stream`] yaleyo `struct`.
//!
//! Masenze ukusakaza okuqanjwe nge-`Counter` okubalwa kusuka ku-`1` kuye ku-`5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Okokuqala, isakhiwo:
//!
//! /// Umfudlana obala usuka kokunye kuye kwemihlanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sifuna ukuthi ukubala kwethu kuqale ngasikhathi sinye, ngakho-ke ake sengeze indlela ye new() yokusiza.
//! // Lokhu akudingeki ngokuqinile, kepha kulula.
//! // Qaphela ukuthi siqala i-`count` ku-zero, sizobona ukuthi kungani kusetshenziswa i-`poll_next()`'s ngezansi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ngemuva kwalokho, sisebenzisa i-`Stream` ye-`Counter` yethu:
//!
//! impl Stream for Counter {
//!     // sizobe sibala nosize
//!     type Item = usize;
//!
//!     // poll_next() ukuphela kwendlela edingekayo
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Khulisa ukubalwa kwethu.Yingakho siqale ngo-zero.
//!         self.count += 1;
//!
//!         // Hlola ukubona ukuthi siqedile ukubala noma cha.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Imifudlana *iyavilapha*.Lokhu kusho ukuthi ukudala nje ukusakaza akusho ukuthi yi-_do_ ngokuphelele.Akukho okwenzeka ngempela uze ushayele i-`next`.
//! Lokhu kwesinye isikhathi kungumthombo wokudideka lapho kwenziwa ukusakaza kuphela kwemiphumela yaso emibi.
//! Umhlanganisi uzosixwayisa ngalolu hlobo lokuziphatha:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;