#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Iqukethe izincazelo zesakhiwo sokuhlelwa kwezinhlobo ezakhelwe ngaphakathi zomhlanganisi.
//!
//! Zingasetshenziswa njengezinjongo zokuhanjiswa kwekhodi engaphephile ukuphatha izethulo eziluhlaza ngqo.
//!
//!
//! Incazelo yabo kufanele ihlale ifana ne-ABI echazwe ku-`rustc_middle::ty::layout`.
//!

/// Ukumelwa kwento engu-trait efana ne `&dyn SomeTrait`.
///
/// Lesi sakhiwo sinokuhlelwa okufanayo nezinhlobo ezinjenge-`&dyn SomeTrait` ne-`Box<dyn AnotherTrait>`.
///
/// `TraitObject` kuqinisekisiwe ukufanisa izakhiwo, kepha akusilo uhlobo lwezinto ze-trait (isb., izinkambu azitholakali ngqo ku-`&dyn SomeTrait`) futhi ayilawuli leyo ndlela (ukushintsha incazelo ngeke kushintshe ukwakheka kwe-`&dyn SomeTrait`).
///
/// Yenzelwe kuphela ukusetshenziswa yikhodi engaphephile edinga ukukhohlisa imininingwane esezingeni eliphansi.
///
/// Ayikho indlela yokubhekisa kuzo zonke izinto ze-trait ngokujwayelekile, ngakho-ke ukuphela kwendlela yokwakha amanani walolu hlobo kunemisebenzi efana ne-[`std::mem::transmute`][transmute].
/// Ngokufanayo, okuwukuphela kwendlela yokwakha into eyiqiniso ye trait kusuka kunani le-`TraitObject` nge-`transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Ukuhlanganisa into engu-trait ngezinhlobo ezingafani kahle - lapho i-vtable ingahambisani nohlobo lwenani i-pointer yedatha ekhomba kulo - kungenzeka iholele ekuziphatheni okungachazwanga.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // isibonelo trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // vumela umhlanganisi enze into engu-trait
/// let object: &dyn Foo = &value;
///
/// // bheka ukumelwa okuluhlaza
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // isikhombi sedatha ikheli le-`value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // yakha into entsha, ekhomba ku-`i32` ehlukile, uqaphele ukusebenzisa i-`i32` vtable kusuka ku-`object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // kufanele isebenze ngokungathi sakha into eyi-trait nge-`other_value` ngqo
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}