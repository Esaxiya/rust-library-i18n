#![stable(feature = "futures_api", since = "1.36.0")]

//! Amanani we-Asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Lolu hlobo luyadingeka ngoba:
///
/// a) Ama-generator awakwazi ukusebenzisa i-`for<'a, 'b> Generator<&'a mut Context<'b>>`, ngakho-ke sidinga ukudlulisa isikhombisi esiluhlaza (bona i <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Izikhombisi ezi-Raw ne-`NonNull` akuyona i-`Send` noma i-`Sync`, ngakho-ke lokho kungenza yonke i-future non-Send/Sync eyodwa futhi, futhi asikufuni lokho.
///
/// Iphinde yenze lula ukwehliswa kwe-HIR kwe `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Songa i-generator ku-future.
///
/// Lo msebenzi ubuyisa i-`GenFuture` ngaphansi, kepha uyifihle ku-`impl Trait` ukuze unikeze imilayezo yephutha elingcono (i-`impl Future` kune-`GenFuture<[closure.....]>`).
///
// Le yi-`const` ukugwema amaphutha angeziwe ngemuva kokululama ku-`const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Sithembele eqinisweni lokuthi i-async/await futures ayigudluki ukuze kudaleke izikweletu eziziqondisayo ku-generator engaphansi.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // UKUPHEPHA: Kuphephile ngoba siyi-!Unpin + !Drop, futhi lokhu kumane nje kungukuqagela kwensimu.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Qalisa kabusha i-generator, uguqule i-`&mut Context` ibe yisikhombi esiluhlaza se-`NonNull`.
            // Ukwehliswa kwe `.await` kuzokubuyisela emuva ngokuphepha ku-`&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`cx.0` iyisikhombi esivumelekile
    // lokho kugcwalisa zonke izidingo zesethenjwa esiguquguqukayo.
    unsafe { &mut *cx.0.as_ptr().cast() }
}