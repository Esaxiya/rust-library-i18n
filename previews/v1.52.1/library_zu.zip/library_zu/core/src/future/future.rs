#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// I-future imele ukubalwa kwe-asynchronous.
///
/// I-future yinani okungenzeka alikaze liqede ikhompyutha okwamanje.
/// Lolu hlobo lwe "asynchronous value" lwenza ukuthi intambo iqhubeke nokwenza umsebenzi owusizo ngenkathi ilinde inani ukuthi litholakale.
///
///
/// # Indlela ye `poll`
///
/// Indlela eyinhloko ye-future, `poll`,*izama* ukuxazulula i-future ibe inani lokugcina.
/// Le ndlela ayivimbi uma inani lingakalungi.
/// Esikhundleni salokho, umsebenzi wamanje uhlelelwe ukuvuswa lapho kungenzeka khona ukuthuthuka okuqhubekayo ngokuthi `ukuvotela futhi.
/// I `context` edluliselwe kundlela ye `poll` ingahlinzeka nge [`Waker`], okuyisibambo sokuvusa umsebenzi wamanje.
///
/// Uma usebenzisa i-future, ngokuvamile ngeke ushayele i-`poll` ngqo, kepha esikhundleni salokho i-`.await` inani.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Uhlobo lwenani elikhiqizwe lapho kuqedwa.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Ukuzama ukuxazulula i-future kunani lokugcina, kubhaliswa umsebenzi wamanje wokuvuka uma inani lingakatholakali.
    ///
    /// # Buyisela inani
    ///
    /// Lo msebenzi uyabuya:
    ///
    /// - [`Poll::Pending`] uma i-future ingakalungi okwamanje
    /// - [`Poll::Ready(val)`] ngomphumela `val` wale future uma uqede ngempumelelo.
    ///
    /// Lapho nje i-future isiqedile, amaklayenti akufanele ayiphinde i-`poll`.
    ///
    /// Lapho i-future ingakalungeli okwamanje, i-`poll` ibuyisa i-`Poll::Pending` bese igcina i-clone ye-[`Waker`] ekopishwe kusuka ku-[`Context`] yamanje.
    /// Le [`Waker`] bese ivuswa uma i future ingenza inqubekela phambili.
    /// Isibonelo, i-future elinde isokhethi ukuze ifundeke ibiza i-`.clone()` ku-[`Waker`] bese iyigcina.
    /// Lapho isiginali ifika kwenye indawo ekhombisa ukuthi isokhethi liyafundeka, kubizwa i [`Waker::wake`] bese umsebenzi wesokhethi future uyavuswa.
    /// Lapho umsebenzi uvuswe, kufanele uzame uku `poll` i future futhi, engahle ikhiqize noma ingakhiphi inani lokugcina.
    ///
    /// Qaphela ukuthi kumakholi amaningi aya ku-`poll`, yi-[`Waker`] kuphela evela ku-[`Context`] edluliselwe ocingweni lwakamuva kakhulu okufanele ihlelelwe ukuthola ukuvuka.
    ///
    /// # Izici zesikhathi sokusebenza
    ///
    /// I-Futures iyodwa i-*inert*;kumele *bavotelwe* ngenkuthalo ukuze bathuthuke, okusho ukuthi isikhathi ngasinye lapho kuvuswa umsebenzi wamanje, kufanele iphinde iphindeke `ivotele` kusalindwe i-futures ukuthi isenayo intshisekelo kuyo.
    ///
    /// Umsebenzi we-`poll` awubizwanga kaninginingi ku-loop eqinile-esikhundleni salokho, kufanele ubizwe kuphela lapho i-future ikhombisa ukuthi ikulungele ukwenza inqubekela phambili (ngokushayela i-`wake()`).
    /// Uma ujwayele i-`poll(2)` noma i-`select(2)` syscalls ku-Unix kubalulekile ukuthi wazi ukuthi i-futures imvamisa ayenzi *izinkinga* ezifanayo ze-"all wakeups must poll all events";zifana kakhulu ne `epoll(4)`.
    ///
    /// Ukuqaliswa kwe `poll` kufanele kulwele ukubuya ngokushesha, futhi akufanele kuvimbe.Ukubuyela ngokushesha kuvimbela ukuvaleka imicu noma izihibe zomcimbi ngokungadingekile.
    /// Uma kwaziwa ngaphambi kwesikhathi ukuthi ukushayelwa i-`poll` kungagcina kuthathe isikhashana, umsebenzi kufanele wehliselwe echibini lentambo (noma into efanayo) ukuqinisekisa ukuthi i `poll` ingabuya ngokushesha.
    ///
    /// # Panics
    ///
    /// Uma nje i future isiqedile (ibuyise i `Ready` kusuka ku `poll`), ibiza indlela yayo ye `poll` futhi kungenzeka i panic, ivimbe unomphela, noma ibangele ezinye izinhlobo zezinkinga;i `Future` trait ayibeki izidingo ngemiphumela yocingo olunjalo.
    /// Kodwa-ke, njengoba indlela ye `poll` ingamakiwe i `unsafe`, imithetho ejwayelekile ye Rust iyasebenza: izingcingo akumele zenze isimilo esingachazwanga (inkohlakalo yenkumbulo, ukusetshenziswa okungalungile kwemisebenzi ye `unsafe`, noma okunye okunjalo), ngaphandle kwesimo se future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}