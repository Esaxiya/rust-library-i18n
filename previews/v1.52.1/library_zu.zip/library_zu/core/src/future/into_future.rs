use crate::future::Future;

/// Ukuguqulwa kube yi-`Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Umphumela ozokhiqizwa yi-future lapho uqeda.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Yiluphi uhlobo lwe-future esikuguqula kube lokhu?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Idala i-future kusuka kunani.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}