use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Isisongeli sokuvimbela umhlanganisi ekubizeni ngokuzenzakalela umbhubhisi ka-``T`.
/// Lokhu kusonga kuyizindleko ezi-0.
///
/// `ManuallyDrop<T>` ingaphansi kokulungiswa okufanayo kokuhlelwa njenge-`T`.
/// Ngenxa yalokho, ayinamphumela * ekucatshangweni okwenziwa umhlanganisi ngokuqukethwe kwakho.
/// Isibonelo, ukuqala i-`ManuallyDrop<&mut T>` nge-[`mem::zeroed`] kungukuziphatha okungachazwanga.
/// Uma udinga ukuphatha idatha engaqaliwe, sebenzisa i-[`MaybeUninit<T>`] esikhundleni salokho.
///
/// Qaphela ukuthi ukufinyelela inani ngaphakathi kwe `ManuallyDrop<T>` kuphephile.
/// Lokhu kusho ukuthi i-`ManuallyDrop<T>` okuqukethwe kwayo okuyekisiwe akumele kuvezwe nge-API ephephile yomphakathi.
/// Ngokunjalo, i `ManuallyDrop::drop` ayiphephile.
///
/// # `ManuallyDrop` bese ulahla ukuhleleka.
///
/// I-Rust ine-[drop order] echazwe kahle yamanani.
/// Ukuze uqiniseke ukuthi izinkambu noma abantu bendawo baphonswa ku-oda elithile, hlela kabusha izimemezelo zokuthi i-oda elilahliwe elifanele lifanele.
///
/// Kungenzeka usebenzise i-`ManuallyDrop` ukulawula i-drop order, kepha lokhu kudinga ikhodi engaphephile futhi kunzima ukukwenza kahle lapho kukhona ukuqaqa.
///
///
/// Isibonelo, uma ufuna ukuqiniseka ukuthi inkambu ethile yehlisiwe ngemuva kwezinye, yenze inkambu yokugcina yesakhiwo:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` izokwehliswa ngemuva kwe `children`.
///     // I-Rust iqinisekisa ukuthi izinkambu ziyekwe ngokulandelana kwesimemezelo.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Songa inani elizokwehliswa ngesandla.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Usengasebenza ngokuphepha kunani
    /// assert_eq!(*x, "Hello");
    /// // Kepha i `Drop` ngeke isetshenziswe lapha
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Ikhipha inani kusiqukathi se-`ManuallyDrop`.
    ///
    /// Lokhu kuvumela ukuthi inani liphinde lehliswe futhi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Lokhu kwehlisa i `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Kuthatha inani elivela esitsheni se-`ManuallyDrop<T>`.
    ///
    /// Le ndlela yenzelwe ikakhulukazi ukukhipha amanani kudrophu.
    /// Esikhundleni sokusebenzisa i-[`ManuallyDrop::drop`] ukulahla inani ngesandla, ungasebenzisa le ndlela ukuthatha inani futhi ulisebenzise ngendlela othanda ngayo.
    ///
    /// Noma kunini lapho kunokwenzeka khona, kungcono ukusebenzisa i-[`into_inner`][`ManuallyDrop::into_inner`] esikhundleni, evimbela ukuphinda okuqukethwe kwe-`ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi ukhipha inani eliqukethwe ngaphandle kokuvimbela ukusetshenziswa okuqhubekayo, kushiya isimo salesi sitsha singashintshiwe.
    /// Kungumsebenzi wakho ukuqinisekisa ukuthi le `ManuallyDrop` ayisetshenziswa futhi.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // UKUPHEPHA: sifunda kusuka kusethenjwa, okuqinisekisiwe
        // ukuze kuvunyelwe ukufundwa.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Izandla zehla inani eliqukethwe.Lokhu kulingana ncamashi nokubiza i-[`ptr::drop_in_place`] ngesikhombi kunani eliqukethwe.
    /// Njengalokhu, ngaphandle kokuthi inani eliqukethwe liyisakhiwo esigcwele, umbhubhisi uzobizwa endaweni ngaphandle kokuhambisa inani, futhi ngaleyo ndlela angasetshenziswa ukulahla idatha ye-[pinned] ngokuphepha.
    ///
    /// Uma ungumnikazi wenani, ungasebenzisa i-[`ManuallyDrop::into_inner`] esikhundleni salokho.
    ///
    /// # Safety
    ///
    /// Lo msebenzi uqhuba umchithi wenani eliqukethwe.
    /// Ngaphandle kwezinguquko ezenziwe ngumbhubhisi uqobo, imemori ishiywa ingashintshiwe, futhi kuze kufike lapho umhlanganisi akhathazekile usaphethe iphethini elisebenza ngohlobo lwe `T`.
    ///
    ///
    /// Noma kunjalo, leli nani le-"zombie" akufanele livezwe kukhodi ephephile, futhi lo msebenzi akufanele ubizwe kaningi.
    /// Ukuze usebenzise inani ngemuva kokulahlwa, noma ukulahla inani kaningi, kungadala Ukuziphatha Okungachazwanga (kuya ngokuthi i `drop` yenzani).
    /// Lokhu kuvame ukuvinjelwa uhlobo lohlelo, kepha abasebenzisi be `ManuallyDrop` kumele bagcine lezo ziqinisekiso ngaphandle kosizo oluvela kumhlanganisi.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // UKUPHEPHA: sishiya inani elikhonjwe yisethenjwa esiguquguqukayo
        // okuqinisekisiwe ukuthi kuvumelekile ekubhaleni.
        // Kukulo oshayayo ukuqinisekisa ukuthi i-`slot` ayiphinde yehliswe.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}