use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Uhlobo lwe-wrapper lokwakha izimo ezingakaqalwa ze-`T`.
///
/// # Okungenayo kokuqalisa
///
/// Umhlanganisi, ngokuvamile, uthatha ukuthi okuguquguqukayo kuqalwa kahle ngokuya ngezidingo zohlobo lokuguquguqukayo.Isibonelo, ukuguquguquka kohlobo lwesethenjwa kufanele kuqondaniswe futhi kungabi yi-NULL.
/// Lokhu kungaguquguquki okufanele *kugcinwe* njalo, noma kunekhodi engaphephile.
/// Njengomphumela, ukuqalisa ukuqanda okuguqukayo kohlobo lwesethenjwa kubangela i-[undefined behavior][ub] esheshayo, noma ngabe leyo referensi isetshenziswa yini ukufinyelela kwimemori:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhodi efanayo ne-`MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
///
/// Lokhu kuxhashazwa ngumhlanganisi ngokulungiselelwa okuhlukahlukene, njengokubalekela ukuhlolwa kwesikhathi sokusebenza nokwenza ngcono ukwakheka kwe `enum`.
///
/// Ngokufanayo, inkumbulo engaqaliwe ngokuphelele ingaba nokuqukethwe, kuyilapho i-`bool` kufanele ihlale iyi-`true` noma i-`false`.Ngakho-ke, ukudala i-`bool` engaqaliwe kungukuziphatha okungachazwanga:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhodi efanayo ne-`MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
///
/// Ngaphezu kwalokho, inkumbulo engaqalisiwe ikhethekile ngoba ayinanani elinqunyelwe (i-"fixed" okusho ukuthi i-"it won't change without being written to").Ukufunda i-byte efanayo engaqaliwe izikhathi eziningi kunganikeza imiphumela ehlukile.
/// Lokhu kwenza kube ukungazichazi ukuthi unedatha engaqaliwe ngokuguquguqukayo noma ngabe lokho kuguquka kunohlobo lwezinombolo, okungahle kubambe noma iyiphi iphethini le-*fixed* bit:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // Ukuziphatha okungachazwanga!.️
/// // Ikhodi efanayo ne-`MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // Ukuziphatha okungachazwanga!.️
/// ```
/// (Qaphela ukuthi imithetho emayelana nezinamba ezingakaqalwa ayikaphothulwa okwamanje, kepha kuze kube yilapho iphela, kuyalulekwa ukuyigwema.)
///
/// Ngaphezu kwalokho, khumbula ukuthi izinhlobo eziningi zinokungenayo okungeziwe ngaphezu kokucatshangelwa ukuthi kuqalwe ezingeni lohlobo.
/// Isibonelo, i-1`-initialized [`Vec<T>`] ibhekwa njengeqalisiwe (ngaphansi kokuqaliswa kwamanje; lokhu akusona isiqinisekiso esizinzile) ngoba ukuphela kwento edingekayo umhlanganisi ngayo ukuthi isikhombisi sedatha akumele singasebenzi.
/// Ukwakha i-`Vec<T>` enjalo akubangeli *ukusebenza* okungachazwanga ngokushesha, kepha kuzodala isimilo esingachazwanga ngemisebenzi ephephe kakhulu (kufaka phakathi ukuyilahla).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` isebenza ukunika amandla ikhodi engaphephile ukubhekana nedatha engaqaliwe.
/// Kuyisiginali kumhlanganisi ekhombisa ukuthi idatha lapha kungenzeka *inga* qalwa:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Dala ireferensi engaqaliwe ngokusobala.
/// // Umhlanganisi uyazi ukuthi idatha engaphakathi kwe `MaybeUninit<T>` ingahle ingasebenzi, yingakho lokhu kungeyona i-UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Isethe kunani elivumelekile.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Khipha idatha eqalisiwe-lokhu kuvunyelwe kuphela *ngemuva* kokuqalisa kahle i `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Umhlanganisi ube esazi ukuthi angenzi noma yikuphi ukucabanga okungalungile noma ukulungiselelwa kule khodi.
///
/// Ungacabanga nge `MaybeUninit<T>` njengokucishe kufane ne `Option<T>` kepha ngaphandle kokulandela umkhondo wesikhathi sokusebenza futhi ngaphandle kokuhlolwa kokuphepha.
///
/// ## out-pointers
///
/// Ungasebenzisa i-`MaybeUninit<T>` ukusebenzisa i-"out-pointers": esikhundleni sokubuyisa idatha evela emsebenzini, yidlulise njengesikhombi kwimemori ethile ye-(uninitialized) ukufaka umphumela kuwo.
/// Lokhu kungaba wusizo lapho kubalulekile ukuthi ofonile alawule ukuthi imemori umphumela ogcinwe kuyo inikezwa kanjani, futhi ufuna ukugwema ukuhamba okungadingekile.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ayilahli okuqukethwe okudala, okubalulekile.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Manje siyazi ukuthi i `v` iqalisiwe!Lokhu futhi kuqinisekisa ukuthi i vector yehla ngokufanele.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Ukuqalisa i-element element-by-element
///
/// `MaybeUninit<T>` ingasetshenziselwa ukuqala into enkulu yamalungu afanayo:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Dala uhlu olungenakuqalwa lwe-`MaybeUninit`.
///     // I-`assume_init` iphephile ngoba uhlobo esisho ukuthi siluqalisile lapha luyisigejane se-`MaybeUninit`s, esingadingi ukuqalwa.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Ukulahla i `MaybeUninit` akwenzi lutho.
///     // Ngakho-ke ukusebenzisa ukunikezwa kwesikhombi esiluhlaza esikhundleni se-`ptr::write` akubangeli ukuthi inani elidala elingaqalisiwe lehle.
/////
///     // Futhi uma kune panic ngalesi sikhathi, sinokuvuza kwenkumbulo, kepha akukho nkinga yokuphepha kwememori.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Konke kuyaqalwa.
///     // Shintsha uhlu lube luhlobo oluqalisiwe.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ungasebenza futhi ngamalungu afanayo aqale ngokwengxenye, angatholakala ezinqolobaneni zemininingwane esezingeni eliphansi.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Dala uhlu olungenakuqalwa lwe-`MaybeUninit`.
/// // I-`assume_init` iphephile ngoba uhlobo esisho ukuthi siluqalisile lapha luyisigejane se-`MaybeUninit`s, esingadingi ukuqalwa.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Bala inani lama-elementi esiwabele wona.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Entweni ngayinye ekuluhlu, yehla uma ngabe sikunikeze.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Iqalisa inkambu yensimu nge-field
///
/// Ungasebenzisa i-`MaybeUninit<T>`, ne-[`std::ptr::addr_of_mut`] macro, ukuqala insimu yezinhlaka ngenkambu:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Iqalisa inkambu ye `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ukuqalisa inkambu ye `list` Uma kune panic lapha, khona-ke i `String` enkanjini ye `name` iyavuza.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Zonke izinkambu ziyaqalwa, ngakho-ke sibiza i-`assume_init` ukuthola i-Foo eqalisiwe.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` kuqinisekisiwe ukuthi ngosayizi ofanayo, ukuqondaniswa, kanye ne-ABI njenge `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Kodwa-ke khumbula ukuthi uhlobo *oluqukethe* i-`MaybeUninit<T>` akulona isakhiwo esifanayo;I-Rust ayiqinisekisi ngokujwayelekile ukuthi izinkambu ze-`Foo<T>` zine-oda elifanayo ne-`Foo<U>` noma ngabe i-`T` ne-`U` zinosayizi ofanayo nokuqondaniswa.
///
/// Ngaphezu kwalokho ngoba noma yiliphi inani elincane livumelekile ku-`MaybeUninit<T>` umhlanganisi akakwazi ukusebenzisa ukwenziwa kwe-non-zero/niche-filling, okungahle kube nomphumela wosayizi omkhulu:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Uma i-`T` iphephe nge-FFI, kunjalo ne `MaybeUninit<T>`.
///
/// Ngenkathi i-`MaybeUninit` iyi-`#[repr(transparent)]` (ekhombisa ukuthi iqinisekisa usayizi ofanayo, ukuqondanisa, kanye ne-ABI njenge-`T`), lokhu * akushintshi noma yimaphi ama-caveats wangaphambilini.
/// `Option<T>` futhi i-`Option<MaybeUninit<T>>` isengaba nosayizi abehlukene, futhi izinhlobo eziqukethe inkambu yohlobo `T` zingabekwa (futhi zilinganiselwe) ngokuhlukile kunokuthi ngabe leyo nsimu bekuyi-`MaybeUninit<T>`.
/// `MaybeUninit` uhlobo lwenyunyana, kanti i-`#[repr(transparent)]` kuzinyunyana ayizinzile (bona i [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Ngokuhamba kwesikhathi, iziqiniseko eziqondile ze-`#[repr(transparent)]` kuzinyunyana zingashintsha, futhi i-`MaybeUninit` ingahlala i-`#[repr(transparent)]` noma ingahlali.
/// Lokho kusho, i-`MaybeUninit<T>` izohlala * iqinisekisa ukuthi inosayizi ofanayo, ukuqondanisa, ne-ABI njenge-`T`;kungenxa nje yokuthi i-`MaybeUninit` isebenzisa lokho kuqinisekisa kungashintsha.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang ukuze sikwazi ukugoqa ezinye izinhlobo kuyo.Lokhu kuyasiza kuma-generator.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ungabizi i `T::clone()`, asikwazi ukwazi ukuthi siqaliswe ngokwanele yini ngalokho.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Idala i-`MaybeUninit<T>` entsha eqalwe ngenani elinikeziwe.
    /// Kuphephile ukubiza i-[`assume_init`] kunani lokubuyisa lalo msebenzi.
    ///
    /// Qaphela ukuthi ukulahla i-`MaybeUninit<T>` ngeke kuze kubize ikhodi yokwehla ka-``T`.
    /// Kungumsebenzi wakho ukuqinisekisa ukuthi i-`T` iyehla uma iqaliswa.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Idala i-`MaybeUninit<T>` entsha esimweni esingaqalisiwe.
    ///
    /// Qaphela ukuthi ukulahla i-`MaybeUninit<T>` ngeke kuze kubize ikhodi yokwehla ka-``T`.
    /// Kungumsebenzi wakho ukuqinisekisa ukuthi i-`T` iyehla uma iqaliswa.
    ///
    /// Bona i [type-level documentation][MaybeUninit] ngezibonelo ezithile.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Dala uhlu olusha lwezinto ze-`MaybeUninit<T>`, esimweni esingaqalisiwe.
    ///
    /// Note: enguqulweni ye future Rust le ndlela ingahle ingadingeki lapho i-syntax yangempela ivumela i-[repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Isibonelo esingezansi singasebenzisa i-`let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Ibuyisa ucezu lwedatha (mhlawumbe oluncane) olungafundwa empeleni
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // UKUPHEPHA: I-`[MaybeUninit<_>; LEN]` engaqalisiwe isebenza.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Idala i-`MaybeUninit<T>` entsha esimweni esingaqalisiwe, imemori igcwaliswa ngamabhayithi we-`0`.Kuya nge-`T` ukuthi ngabe lokho sekwenzelwe ukuqaliswa okufanele.
    ///
    /// Isibonelo, i-`MaybeUninit<usize>::zeroed()` iyaqalwa, kepha i-`MaybeUninit<&'static i32>::zeroed()` ayenziwa ngoba izinkomba akumele zingasebenzi.
    ///
    /// Qaphela ukuthi ukulahla i-`MaybeUninit<T>` ngeke kuze kubize ikhodi yokwehla ka-``T`.
    /// Kungumsebenzi wakho ukuqinisekisa ukuthi i-`T` iyehla uma iqaliswa.
    ///
    /// # Example
    ///
    /// Ukusetshenziswa okulungile kwalo msebenzi: ukuqala ukwakheka nge-zero, lapho zonke izinkambu ze-struct zingabamba khona iphethini engu-0 njengenani elivumelekile.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// Ukusetshenziswa okungalungile * kwalo msebenzi: ukubiza i-`x.zeroed().assume_init()` lapho i-`0` kungelona iphethini elifanele lohlobo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ngaphakathi kwepheya, sakha i `NotZero` engenabandlululo olusemthethweni.
    /// // Lokhu kungukuziphatha okungachazwanga..️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // UKUPHEPHA: `u.as_mut_ptr()` amaphoyinti kwimemori eyabiwe.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Isetha inani le-`MaybeUninit<T>`.
    /// Lokhu kubhala ngaphezulu kwanoma iliphi inani langaphambilini ngaphandle kokulahla, ngakho-ke qaphela ukuthi ungakusebenzisi lokhu kabili ngaphandle kokuthi ufuna ukweqa ukusebenzisa umbhubhisi.
    ///
    /// Ukuze kube lula kuwe, lokhu kubuye kubuyisele ireferensi engaguquguquki kokuqukethwe (manje okuqaliswe ngokuphepha) kwe `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // UKUPHEPHA: Sisanda kuqala leli nani.
        unsafe { self.assume_init_mut() }
    }

    /// Ithola isikhombi kunani eliqukethwe.
    /// Ukufunda kulesi sikhombi noma ukusiguqula kube yisethenjwa kungukuziphatha okungachazwanga ngaphandle kokuthi kuqaliswe i `MaybeUninit<T>`.
    /// Ukubhalela kwimemori ukuthi lesi sikhombi i-(non-transitively) sikhomba kukuziphatha okungachazwanga (ngaphandle kwangaphakathi kwe-`UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Dala ireferensi ku-`MaybeUninit<T>`.Lokhu kulungile ngoba sikuqalisile.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Senze ireferensi ku-vector engaqalisiwe!Lokhu kungukuziphatha okungachazwanga..️
    /// ```
    ///
    /// (Qaphela ukuthi imithetho emayelana nezinkomba zedatha engaqaliwe ayikaqedwa, kepha kuze kube yilapho kwenziwa, kuyalulekwa ukuyigwema.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` futhi i-`ManuallyDrop` zombili zingu-`repr(transparent)` ukuze sikwazi ukusakaza isikhombi.
        self as *const _ as *const T
    }

    /// Ithola isikhombisi esiguquguqukayo kunani eliqukethwe.
    /// Ukufunda kulesi sikhombi noma ukusiguqula kube yisethenjwa kungukuziphatha okungachazwanga ngaphandle kokuthi kuqaliswe i `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Dala ireferensi ku-`MaybeUninit<Vec<u32>>`.
    /// // Lokhu kulungile ngoba sikuqalisile.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Senze ireferensi ku-vector engaqalisiwe!Lokhu kungukuziphatha okungachazwanga..️
    /// ```
    ///
    /// (Qaphela ukuthi imithetho emayelana nezinkomba zedatha engaqaliwe ayikaqedwa, kepha kuze kube yilapho kwenziwa, kuyalulekwa ukuyigwema.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` futhi i-`ManuallyDrop` zombili zingu-`repr(transparent)` ukuze sikwazi ukusakaza isikhombi.
        self as *mut _ as *mut T
    }

    /// Ikhipha inani kusiqukathi se-`MaybeUninit<T>`.Le yindlela enhle yokuqinisekisa ukuthi idatha izokwehliswa, ngoba umphumela we-`T` ungaphansi kokuphathwa okujwayelekile kokudonsa.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi i-`MaybeUninit<T>` isesimweni sokuqala.Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingaqondakali ngokushesha.
    /// I-[type-level documentation][inv] iqukethe imininingwane eminingi ngalesi sihla sokuqalisa.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Ngaphezu kwalokho, khumbula ukuthi izinhlobo eziningi zinokungenayo okungeziwe ngaphezu kokucatshangelwa ukuthi kuqalwe ezingeni lohlobo.
    /// Isibonelo, i-1`-initialized [`Vec<T>`] ibhekwa njengeqalisiwe (ngaphansi kokuqaliswa kwamanje; lokhu akusona isiqinisekiso esizinzile) ngoba ukuphela kwento edingekayo umhlanganisi ngayo ukuthi isikhombisi sedatha akumele singasebenzi.
    ///
    /// Ukwakha i-`Vec<T>` enjalo akubangeli *ukusebenza* okungachazwanga ngokushesha, kepha kuzodala isimilo esingachazwanga ngemisebenzi ephephe kakhulu (kufaka phakathi ukuyilahla).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ibingakaqalwa, ngakho-ke lo mugqa wokugcina udale ukungachazeki..️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` iyaqaliswa.
        // Lokhu kusho nokuthi i `self` kufanele ibe ngukuhluka kwe `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Ifunda inani kusuka esitsheni se `MaybeUninit<T>`.I-`T` evelayo ingaphansi kokuphathwa okujwayelekile kokudonsa.
    ///
    /// Noma kunini lapho kunokwenzeka khona, kungcono ukusebenzisa i-[`assume_init`] esikhundleni, evimbela ukuphinda okuqukethwe kwe-`MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi i-`MaybeUninit<T>` isesimweni sokuqala.Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingachazwanga.
    /// I-[type-level documentation][inv] iqukethe imininingwane eminingi ngalesi sihla sokuqalisa.
    ///
    /// Ngaphezu kwalokho, lokhu kushiya ikhophi ledatha efanayo ngemuva ku-`MaybeUninit<T>`.
    /// Lapho usebenzisa amakhophi amaningi edatha (ngokushayela u-`assume_init_read` amahlandla amaningi, noma kuqala ngokushayela u-`assume_init_read` bese u-[`assume_init`]), kungumsebenzi wakho ukuqinisekisa ukuthi leyo datha ingaphindwa kabili.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ngu-`Copy`, ngakho-ke singafunda kaningi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Ukuphinda inani le-`None` kulungile, ngakho-ke singafunda kaningi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Manje sesidale amakhophi amabili e vector efanayo, okuholela ku-free free️ lapho bobabili behla!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` iyaqaliswa.
        // Ukufunda kusuka ku-`self.as_ptr()` kuphephile ngoba i-`self` kufanele iqaliswe.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Yehlisa inani eliqukethwe endaweni.
    ///
    /// Uma ungumnikazi we `MaybeUninit`, ungasebenzisa i [`assume_init`] esikhundleni salokho.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi i-`MaybeUninit<T>` isesimweni sokuqala.Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingachazwanga.
    ///
    /// Ngaphezu kwalokho, bonke abangenayo abengeziwe bohlobo `T` kumele baneliseke, njengoba ukusetshenziswa kwe `Drop` kwe `T` (noma amalungu ayo) kungancika kulokhu.
    /// Isibonelo, i-1`-initialized [`Vec<T>`] ibhekwa njengeqalisiwe (ngaphansi kokuqaliswa kwamanje; lokhu akusona isiqinisekiso esizinzile) ngoba ukuphela kwento edingekayo umhlanganisi ngayo ukuthi isikhombisi sedatha akumele singasebenzi.
    ///
    /// Ukulahla i-`Vec<T>` enjalo kuzodala ukusebenza okungachazwanga.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` iyaqalwa futhi
        // yanelisa bonke abangenayo be `T`.
        // Ukulahla inani endaweni kuphephile uma kunjalo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ithola ireferensi eyabiwe kunani eliqukethwe.
    ///
    /// Lokhu kungaba wusizo lapho sifuna ukufinyelela i-`MaybeUninit` eqalisiwe kepha engenabunikazi be `MaybeUninit` (evimbela ukusetshenziswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela ukungazichazi: kukwafonayo ukuqinisekisa ukuthi i-`MaybeUninit<T>` isesimweni sokuqala.
    ///
    ///
    /// # Examples
    ///
    /// ### Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Qalisa i-`x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Manje njengoba i-`MaybeUninit<_>` yethu yaziwa ukuthi iqalisiwe, kulungile ukudala ireferensi eyabiwe kuyo:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // UKUPHEPHA: I-`x` isiqaliwe.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Senze ireferensi ku-vector engaqalisiwe!Lokhu kungukuziphatha okungachazwanga..️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Qalisa i `MaybeUninit` usebenzisa i `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Isethenjwa se `Cell<bool>` engaqaliwe: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` iyaqaliswa.
        // Lokhu kusho nokuthi i `self` kufanele ibe ngukuhluka kwe `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ithola ireferensi eguquguqukayo ye-(unique) kunani eliqukethwe.
    ///
    /// Lokhu kungaba wusizo lapho sifuna ukufinyelela i-`MaybeUninit` eqalisiwe kepha engenabunikazi be `MaybeUninit` (evimbela ukusetshenziswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela ukungazichazi: kukwafonayo ukuqinisekisa ukuthi i-`MaybeUninit<T>` isesimweni sokuqala.
    /// Isibonelo, i-`.assume_init_mut()` ayinakusetshenziselwa ukuqalisa i-`MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Ukusetshenziswa okulungile kwale ndlela:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Iqala * wonke ama-byte we-buffer yokufaka.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Qalisa i-`buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Manje siyazi ukuthi i-`buf` iqalisiwe, ngakho-ke singayi `.assume_init()`.
    /// // Kodwa-ke, ukusebenzisa i-`.assume_init()` kungadala i-`memcpy` yama-2048 byte.
    /// // Ukuqinisekisa ukuthi i-buffer yethu iqalisiwe ngaphandle kokuyikopisha, sithuthukisa i-`&mut MaybeUninit<[u8; 2048]>` ibe yi-`&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // UKUPHEPHA: I-`buf` isiqaliwe.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Manje sesizosebenzisa i `buf` njengocezu olujwayelekile:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Ukusetshenziswa okungalungile * kwale ndlela:
    ///
    /// Awukwazi ukusebenzisa i-`.assume_init_mut()` ukuqala inani:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Senze ireferensi ye-(mutable) ku-`bool` engaqalisiwe!
    ///     // Lokhu kungukuziphatha okungachazwanga..️
    /// }
    /// ```
    ///
    /// Isibonelo, awukwazi [`Read`] ungene kubhafa engaqaliwe:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ireferensi kwimemori engaqalisiwe!
    ///                             // Lokhu kungukuziphatha okungachazwanga.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Futhi awunakusebenzisa ukufinyelela okuqondile kwenkambu ukwenza ukuqalwa kwensimu nensimu kancane kancane:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ireferensi kwimemori engaqalisiwe!
    ///                  // Lokhu kungukuziphatha okungachazwanga.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ireferensi kwimemori engaqalisiwe!
    ///                  // Lokhu kungukuziphatha okungachazwanga.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Njengamanje sithembele kokungenhla ukuthi akulungile, okusho ukuthi, sinezinkomba zemininingwane engaqalisiwe (isb., Ku-`libcore/fmt/float.rs`).
    // Kufanele senze isinqumo sokugcina mayelana nemithetho ngaphambi kokuqiniswa.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi i-`self` iyaqaliswa.
        // Lokhu kusho nokuthi i `self` kufanele ibe ngukuhluka kwe `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Kukhishwa amanani kusuka kuhlu lweziqukathi ze-`MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi zonke izinto zamalungu afanayo zisesimweni sokuqala.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // UKUPHEPHA: Manje kuphephile njengoba siqale zonke izinto
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Oshaya ucingo uqinisekisa ukuthi zonke izinto zamalungu afanayo ziyaqalwa
        // * `MaybeUninit<T>` futhi T kuqinisekisiwe ukuthi zinokuhlelwa okufanayo
        // * I-MaybeUnint ayilahli, ngakho-ke akukho kukhululeka okuphindwe kabili Futhi-ke ukuguqulwa kuphephile
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Uma ucabanga ukuthi zonke izinto ziyaqalwa, thola ucezu kuzo.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi izinto ze-`MaybeUninit<T>` zisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingachazwanga.
    ///
    /// Bona i [`assume_init_ref`] ukuthola eminye imininingwane nezibonelo.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // UKUPHEPHA: ukuphonsa ucezu ku-`*const [T]` kuphephile ngoba oshayayo ukukuqinisekisa lokho
        // `slice` iyaqaliswa, futhi`MaybeUninit` iqinisekisiwe ukuthi inokwakheka okufanayo ne `T`.
        // Isikhombi esitholakele sisebenza ngoba sibhekisa kwimemori ephethwe yi-`slice` eyisethenjwa futhi ngaleyo ndlela iqinisekiswe ukuthi isebenza ekufundweni.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Uma ucabanga ukuthi zonke izinto ziyaqalwa, thola ucezu olungaguquguquka kubo.
    ///
    /// # Safety
    ///
    /// Kusezandleni zoshayayo ukuqinisekisa ukuthi izinto ze-`MaybeUninit<T>` zisesimweni sokuqala.
    ///
    /// Ukushayela lokhu lapho okuqukethwe kungakaqalwa ngokuphelele kubangela isimilo esingachazwanga.
    ///
    /// Bona i [`assume_init_mut`] ukuthola eminye imininingwane nezibonelo.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // UKUPHEPHA: kufana namanothi okuphepha we `slice_get_ref`, kepha sinefayela le-
        // isethenjwa esiguquguqukayo esiqinisekisiwe ukuthi sizosebenza ekubhaleni.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ithola isikhombi entweni yokuqala yamalungu afanayo.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ithola isikhombisi esiguquguqukayo entweni yokuqala yamalungu afanayo.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ikopisha izinto ezisuka ku-`src` ziye ku-`this`, ibuyisa ireferensi engaguquleka kokuqukethwe okungakhulelwe manje kwe-`this`.
    ///
    /// Uma i-`T` ingasebenzisi i-`Copy`, sebenzisa i-[`write_slice_cloned`]
    ///
    /// Lokhu kufana ne [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzoba yi-panic uma izingcezu ezimbili zinobude obuhlukile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // UKUPHEPHA: sisanda kukopisha zonke izinto ze-len kumthamo wokugcina
    /// // izakhi zokuqala ze-src.len() ze-vec ziyasebenza manje.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // UKUPHEPHA: &[T] futhi&[MaybeUninit<T>] babe nesakhiwo esifanayo
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // UKUPHEPHA: Izinto ezivumelekile zisanda kukopishelwa ku-`this` ngakho-ke ayikhuthazwa
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// I-Clones izinto ezisuka ku-`src` ziye ku-`this`, zibuyisa ireferensi engaguquguqukayo kokuqukethwe okungakhulelwe manje kwe-`this`.
    /// Noma iziphi izinto esezivele zikhulelwe ngeke zilahlwe.
    ///
    /// Uma i-`T` isebenzisa i-`Copy`, sebenzisa i-[`write_slice`]
    ///
    /// Lokhu kufana ne-[`slice::clone_from_slice`] kepha akushiyi izinto ezikhona.
    ///
    /// # Panics
    ///
    /// Lo msebenzi uzokwenza i-panic uma lezi zingcezu ezimbili zinobude obuhlukile, noma uma ukusetshenziswa kwe-`Clone` panics.
    ///
    /// Uma kune-panic, izinto esezivele zakhiwe zizokwehliswa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // UKUPHEPHA: sisanda kubumba zonke izakhi ze-len zibe namandla okusindisa
    /// // izakhi zokuqala ze-src.len() ze-vec ziyasebenza manje.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ngokungafani ne-copy_from_slice lokhu akubizi i-clone_from_slice kucezu lokhu kungenxa yokuthi i-`MaybeUninit<T: Clone>` ayisebenzisi i-Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // UKUPHEPHA: lesi silayidi esiluhlaza sizoqukatha izinto eziqaliwe kuphela
                // yingakho, kuvunyelwe ukuyilahla.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Sidinga ukuzisika ngokusobala ngobude obufanayo
        // ukubheka imingcele ukuthi kunqotshwe, futhi i-optimizer izokhiqiza i-memcpy yamacala alula (ngokwesibonelo T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // unogada uyadingeka i-b/c panic kungenzeka ngesikhathi se-clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // UKUPHEPHA: Izinto ezivumelekile zisanda kubhalwa ku-`this` ngakho-ke ayifakwanga
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}