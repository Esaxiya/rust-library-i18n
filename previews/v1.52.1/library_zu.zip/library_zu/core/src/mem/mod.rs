//! Imisebenzi eyisisekelo yokubhekana nenkumbulo.
//!
//! Le mojula iqukethe imisebenzi yokubuza usayizi nokuqondaniswa kwezinhlobo, ukuqala nokukhohlisa inkumbulo.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Kuthatha ubunikazi ne-"forgets" mayelana nenani **ngaphandle kokusebenzisa umbhubhisi wayo**.
///
/// Noma yiziphi izinsizakusebenza inani elizilawulayo, njengememori yenqwaba noma isibambo sefayela, zizohlala unomphela esimweni esingafinyeleleki.Kodwa-ke, akuqinisekisi ukuthi izikhombisi zale nkumbulo zizohlala zisebenza.
///
/// * Uma ufuna ukuvuza inkumbulo, bona i [`Box::leak`].
/// * Uma ufuna ukuthola isikhombi esiluhlaza kwimemori, bona i [`Box::into_raw`].
/// * Uma ufuna ukulahla inani ngokufanele, usebenzisa umbhubhisi walo, bona i [`mem::drop`].
///
/// # Safety
///
/// `forget` akumakiwe njenge-`unsafe`, ngoba iziqinisekiso zokuphepha ze-Rust azibandakanyi isiqinisekiso sokuthi ababhubhisi bazohlala basebenza.
/// Isibonelo, uhlelo lungakha umjikelezo wesethenjwa kusetshenziswa i-[`Rc`][rc], noma lushayele i-[`process::exit`][exit] ukuphuma ngaphandle kokusebenzisa ababhubhisi.
/// Ngakho-ke, ukuvumela i-`mem::forget` kusuka kukhodi ephephile akuguquki ngokuyisisekelo iziqinisekiso zokuphepha ze-Rust.
///
/// Lokho kusho, ukuvuza izinsiza ezifana nenkumbulo noma izinto ze-I/O kuvame ukungathandeki.
/// Isidingo sivela kwezinye izimo ezikhethekile zokusebenzisa i-FFI noma ikhodi engaphephile, kepha noma kunjalo, i-[`ManuallyDrop`] iyathandwa ngokujwayelekile.
///
/// Ngoba ukukhohlwa inani kuvunyelwe, noma iyiphi ikhodi ye-`unsafe` oyibhalayo kufanele ivumele lokhu kungenzeka.Awukwazi ukubuyisa inani futhi ulindele ukuthi ofonayo uzosebenzisa umchithi wenani.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Ukusetshenziswa okuphephile kwe-`mem::forget` kwe-canon ukuvimbela umchithi wenani owenziwe yi-`Drop` trait.Isibonelo, lokhu kuzovuza i-`File`, isb
/// funa isikhala esithathwe okuguquguqukayo kepha ungalokothi uvale isisetshenziswa sohlelo olungaphansi:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Lokhu kuyasiza lapho ubunikazi besisetshenziswa esiyisisekelo ngaphambili budluliselwe kukhodi engaphandle kwe-Rust, ngokwesibonelo ngokudlulisa isichasisi sefayela eluhlaza kukhodi ye-C.
///
/// # Ubudlelwano ne `ManuallyDrop`
///
/// Ngenkathi i-`mem::forget` nayo ingasetshenziselwa ukudlulisa *ubunikazi bememori*, ukwenza njalo kuhambisana nephutha.
/// [`ManuallyDrop`] kufanele isetshenziswe esikhundleni salokho.Cabanga, isibonelo, le khodi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Yakha i `String` usebenzisa okuqukethwe kwe `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // vula i-`v` ngoba imemori yayo manje iphethwe yi-`s`
/// mem::forget(v);  // IPHUTHA, v alivumelekile futhi akumele lidluliselwe kumsebenzi
/// assert_eq!(s, "Az");
/// // `s` ilahlwe ngokuphelele futhi inkumbulo yayo yahanjiswa.
/// ```
///
/// Kunezinkinga ezimbili ngesibonelo esingenhla:
///
/// * Uma ngabe kungezwa enye ikhodi phakathi kokwakhiwa kwe-`String` nokunxuswa kwe-`mem::forget()`, i-panic ngaphakathi kwayo ingadala ukukhululeka okuphindwe kabili ngoba imemori efanayo iphathwa yi-`v` ne-`s`.
/// * Ngemuva kokubiza i-`v.as_mut_ptr()` nokudlulisa ubunikazi bedatha ku-`s`, inani le-`v` alivumelekile.
/// Noma inani lisuswa ku-`mem::forget` (okungeke likuhlole), ezinye izinhlobo zinezidingo eziqinile kumanani wazo azenza zingavumelekile lapho zilenga noma zingasenazo.
/// Kusetshenziswa amanani angavumelekile nganoma iyiphi indlela, kufaka phakathi ukuwadlulisa noma ukuwabuyisela kusuka emisebenzini, kwakha isimilo esingachazwanga futhi kungahle kuphule ukucabanga okwenziwe ngumhlanganisi.
///
/// Ukushintshela ku-`ManuallyDrop` kugwema zombili izingqinamba:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Ngaphambi kokuthi sihlukanise i `v` ezingxenyeni zayo eziluhlaza, qiniseka ukuthi ayilahli!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Manje hlukanisa i `v`.Le misebenzi ayikwazi i-panic, ngakho-ke akunakubakho ukuvuza.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Ekugcineni, yakha i `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ilahlwe ngokuphelele futhi inkumbulo yayo yahanjiswa.
/// ```
///
/// `ManuallyDrop` ngokuqinile ivimbela ukukhululeka kabili ngoba sikhubaza umbhubhisi we-`v` ngaphambi kokwenza noma yini enye.
/// `mem::forget()` ayikuvumeli lokhu ngoba kudla impikiswano yayo, kusiphoqa ukuthi sikubize kuphela ngemuva kokukhipha noma yini esiyidingayo ku `v`.
/// Noma ngabe kwethulwe i-panic phakathi kokwakhiwa kwe `ManuallyDrop` nokwakhiwa kwentambo (engeke kwenzeke kukhodi njengoba kukhonjisiwe), kungaholela ekuvuzeni hhayi kokuphindwe kabili.
/// Ngamanye amagama, i-`ManuallyDrop` yenza amaphutha ohlangothini lokuvuza esikhundleni sokwenza iphutha ohlangothini loku (kabili-) kokuwa.
///
/// Futhi, i-`ManuallyDrop` isivimbela ukuthi sibe ne-"touch" `v` ngemuva kokudlulisela ubunikazi ku-`s`-isinyathelo sokugcina sokusebenzisana ne-`v` ukuyilahla ngaphandle kokusebenzisa umbhubhisi wayo sigwenywe ngokuphelele.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Njengo-[`forget`], kepha futhi wamukela amanani angenasayizi.
///
/// Lo msebenzi uyi-shim nje ehlose ukususwa lapho isici se-`unsized_locals` siqiniswa.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Ibuyisa usayizi wohlobo lwama-byte.
///
/// Ngokuqondile, lokhu kungukususwa kwama-byte phakathi kwezinto ezilandelanayo ngokulandelana nalolo hlobo lwento kufaka phakathi ukugoqwa kokuqondanisa.
///
/// Ngakho-ke, nganoma yiluphi uhlobo i-`T` nobude be-`n`, i-`[T; n]` inosayizi we-`n * size_of::<T>()`.
///
/// Ngokuvamile, ubukhulu bohlobo abuzinzile kukho konke ukuhlanganiswa, kepha izinhlobo ezithile ezinjengezokuqala.
///
/// Ithebula elilandelayo linikeza usayizi wama-primitives.
///
/// Thayipha |usayizi_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |I-8 char |4
///
/// Ngaphezu kwalokho, i-`usize` ne-`isize` zinosayizi ofanayo.
///
/// Izinhlobo `*const T`, `&T`, `Box<T>`, `Option<&T>`, ne `Option<Box<T>>` zonke zinosayizi ofanayo.
/// Uma i-`T` isayizi, zonke lezo zinhlobo zinosayizi ofanayo ne-`usize`.
///
/// Ukuguquguquka kwesikhombi akubuguquli ubukhulu baso.Kanjalo, i `&T` ne `&mut T` zinosayizi ofanayo.
/// Kanjalo ne `*const T` ne `* mut T`.
///
/// # Usayizi wezinto ze-`#[repr(C)]`
///
/// Isethulo se-`C` sezinto sinesakhiwo esichaziwe.
/// Ngalesi sakhiwo, usayizi wezinto ubuye uzinze uma nje zonke izinkambu zinosayizi ozinzile.
///
/// ## Usayizi Wezakhiwo
///
/// Nge-`structs`, usayizi unqunywa yi-algorithm elandelayo.
///
/// Ngenkambu ngayinye esakhiweni esi-elwe ngokomyalo wesimemezelo:
///
/// 1. Faka usayizi wenkambu.
/// 2. Zungeza usayizi wamanje uye kokuphindaphinda okuningana kwenkambu elandelayo ye [alignment].
///
/// Ekugcineni, uzungeze usayizi wesakhiwo uye kokuphindaphinda okuseduze kwe-[alignment] yayo.
/// Ukuqondaniswa kwesakhiwo imvamisa ukuqondanisa okukhulu kunayo yonke imikhakha yaso;lokhu kungashintshwa ngokusetshenziswa kwe `repr(align(N))`.
///
/// Ngokungafani ne-`C`, ama-structs alinganiselwa ku-zero aqoqelwe ku-byte eyodwa ngosayizi.
///
/// ## Usayizi wama-Enum
///
/// Ama-Enum angenayo enye idatha ngaphandle kokubandlulula anosayizi ofanayo nowe-C enumsungulweni ahlelelwe wona.
///
/// ## Usayizi Wezinyunyana
///
/// Ubungako benyunyana ngubukhulu benkambu yayo enkulu.
///
/// Ngokungafani ne-`C`, izinyunyana ezilingana no-zero azilinganiswanga ngosayizi owodwa.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Amanye ama-primitives
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Amanye amalungu afanayo
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Ukulingana kosayizi wesikhombi
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Usebenzisa i `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Usayizi wenkambu yokuqala ngu-1, ngakho-ke engeza u-1 kusayizi.Usayizi ngu-1.
/// // Ukuqondaniswa kwensimu yesibili kungu-2, ngakho-ke engeza u-1 ngosayizi wokugoqa.Usayizi ngu-2.
/// // Usayizi wenkambu yesibili ngu-2, ngakho-ke engeza u-2 ngosayizi.Usayizi ungu-4.
/// // Ukuqondaniswa kwenkambu yesithathu kungu-1, ngakho-ke engeza u-0 kusayizi wokugoqa.Usayizi ungu-4.
/// // Usayizi wenkambu yesithathu ngu-1, ngakho-ke engeza u-1 kusayizi.Usayizi ungu-5.
/// // Ekugcineni, ukuqondaniswa kwesakhiwo kungu-2 (ngoba ukuqondanisa okukhulu kunakho konke phakathi kwezinkambu zalo kungu-2), ngakho-ke engeza u-1 kusayizi wokugoqwa.
/// // Usayizi ungu-6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // AbakwaTuple balandela imithetho efanayo.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Qaphela ukuthi ukuhlela kabusha izinkambu kungehlisa usayizi.
/// // Singasusa womabili ama-padding byte ngokubeka i-`third` ngaphambi kwe `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Usayizi we-Union ubukhulu benkambu enkulu kunazo zonke.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Ibuyisa usayizi wevelu ekhonjwe kuma-byte.
///
/// Lokhu kuvame ukufana ne `size_of::<T>()`.
/// Kodwa-ke, lapho i-`T` * ingenasayizi owaziwa ngokwezibalo, isb. Ucezu [`[T]`][slice] noma i-[trait object], khona-ke i-`size_of_val` ingasetshenziselwa ukuthola usayizi owaziwa ngokuguquguqukayo.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // UKUPHEPHA: I-`val` iyinkomba, ngakho-ke yisikhombi esiluhlaza esivumelekile
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibuyisa usayizi wevelu ekhonjwe kuma-byte.
///
/// Lokhu kuvame ukufana ne `size_of::<T>()`.Kodwa-ke, lapho i-`T` * ingenasayizi owaziwa ngokwezibalo, isb. Ucezu [`[T]`][slice] noma i-[trait object], khona-ke i-`size_of_val_raw` ingasetshenziswa ukuthola usayizi owaziwa ngokuguquguqukayo.
///
/// # Safety
///
/// Lo msebenzi uphephile ukubizwa uma izimo ezilandelayo zibamba:
///
/// - Uma i-`T` iyi-`Sized`, lo msebenzi uhlala uphephile ukuwubiza.
/// - Uma umsila ongalinganiselwe we `T` uthi:
///     - i-[slice], khona-ke ubude bomsila wocezu kufanele bube yinamba eqalisiwe, futhi usayizi wenani *lonke*(amandla omsila onamandla + isiqalo esilinganiselwe ngokwezibalo) kufanele ilingane ku-`isize`.
///     - i-[trait object], khona-ke ingxenye ekhombayo yesikhombi kufanele ikhombe ku-vtable evumelekile etholwe ngokucindezela okunganciphisi, nosayizi wenani *eliphelele*(ubude bomsila obunamandla + isiqalo esilinganiselwe ngokwezibalo) kufanele ilingane ku-`isize`.
///
///     - i (unstable) [extern type], khona-ke lo msebenzi uhlala uphephile ukuwushayela, kepha kwangathi i panic noma ngenye indlela ingabuyisa inani elingalungile, njengoba ukwakheka kohlobo lwangaphandle kungaziwa.
///     Lokhu kuziphatha okufanayo ne [`size_of_val`] kusethenjwa sohlobo olunomsila wohlobo lwangaphandle.
///     - ngaphandle kwalokho, ngokuvunyelwe akuvunyelwe ukubiza lo msebenzi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // UKUPHEPHA: ofonayo kufanele anikeze isikhombisi esingavumelekile esivumelekile
    unsafe { intrinsics::size_of_val(val) }
}

/// Ibuyisa ukuqondanisa okuncane okudingekayo kwe-[ABI].
///
/// Konke okukhulunywa ngakho kunani lohlobo `T` kufanele kube ukuphindaphinda kwale nombolo.
///
/// Lokhu ukuqondanisa okusetshenziselwa izinkambu zokwakhiwa.Kungaba kuncane kunokuqondanisa okuncanyelwayo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibuyisa ukuqondanisa okuncane okudingekayo kwe-[ABI] kohlobo lwenani i-`val` ekhomba kulo.
///
/// Konke okukhulunywa ngakho kunani lohlobo `T` kufanele kube ukuphindaphinda kwale nombolo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // UKUPHEPHA: i-val yisethenjwa, ngakho-ke yisikhombi esiluhlaza esivumelekile
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisa ukuqondanisa okuncane okudingekayo kwe-[ABI].
///
/// Konke okukhulunywa ngakho kunani lohlobo `T` kufanele kube ukuphindaphinda kwale nombolo.
///
/// Lokhu ukuqondanisa okusetshenziselwa izinkambu zokwakhiwa.Kungaba kuncane kunokuqondanisa okuncanyelwayo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ibuyisa ukuqondanisa okuncane okudingekayo kwe-[ABI] kohlobo lwenani i-`val` ekhomba kulo.
///
/// Konke okukhulunywa ngakho kunani lohlobo `T` kufanele kube ukuphindaphinda kwale nombolo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // UKUPHEPHA: i-val yisethenjwa, ngakho-ke yisikhombi esiluhlaza esivumelekile
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisa ukuqondanisa okuncane okudingekayo kwe-[ABI] kohlobo lwenani i-`val` ekhomba kulo.
///
/// Konke okukhulunywa ngakho kunani lohlobo `T` kufanele kube ukuphindaphinda kwale nombolo.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Lo msebenzi uphephile ukubizwa uma izimo ezilandelayo zibamba:
///
/// - Uma i-`T` iyi-`Sized`, lo msebenzi uhlala uphephile ukuwubiza.
/// - Uma umsila ongalinganiselwe we `T` uthi:
///     - i-[slice], khona-ke ubude bomsila wocezu kufanele bube yinamba eqalisiwe, futhi usayizi wenani *lonke*(amandla omsila onamandla + isiqalo esilinganiselwe ngokwezibalo) kufanele ilingane ku-`isize`.
///     - i-[trait object], khona-ke ingxenye ekhombayo yesikhombi kufanele ikhombe ku-vtable evumelekile etholwe ngokucindezela okunganciphisi, nosayizi wenani *eliphelele*(ubude bomsila obunamandla + isiqalo esilinganiselwe ngokwezibalo) kufanele ilingane ku-`isize`.
///
///     - i (unstable) [extern type], khona-ke lo msebenzi uhlala uphephile ukuwushayela, kepha kwangathi i panic noma ngenye indlela ingabuyisa inani elingalungile, njengoba ukwakheka kohlobo lwangaphandle kungaziwa.
///     Lokhu kuziphatha okufanayo ne [`align_of_val`] kusethenjwa sohlobo olunomsila wohlobo lwangaphandle.
///     - ngaphandle kwalokho, ngokuvunyelwe akuvunyelwe ukubiza lo msebenzi.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // UKUPHEPHA: ofonayo kufanele anikeze isikhombisi esingavumelekile esivumelekile
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ibuyisa i-`true` uma kwehliswa amanani wezinto zohlobo `T`.
///
/// Lokhu kungukusikisela kokusebenzisa kahle, futhi kungenziwa ngendlela efanele:
/// ingahle ibuyise i-`true` ngezinhlobo ezingadingi ukuthi zilahlwe empeleni.
/// Njengalokhu kuhlala kubuya i `true` kungaba ukusetshenziswa okuvumelekile kwalo msebenzi.Kodwa-ke uma lo msebenzi ubuyisa i-`false`, ungaqiniseka ukuthi ukulahla i-`T` akunamphumela ohlangothini.
///
/// Ukuqaliswa kwezinga eliphansi lezinto ezinjengamaqoqo, okudingeka zilahle idatha yazo ngesandla, kufanele zisebenzise lo msebenzi ukugwema ukuzama ngokungadingekile ukulahla konke okuqukethwe kwazo lapho konakaliswa.
///
/// Lokhu kungahle kungenzi mehluko ekwakhiweni kokukhishwa (lapho iluphu engenayo imiphumela emibi itholwa kalula futhi isuswe), kepha imvamisa iba yimpumelelo enkulu yokwakhiwa kwamaphutha.
///
/// Qaphela ukuthi i [`drop_in_place`] isivele iyakwenza lokhu kuhlolwa, ngakho-ke uma umthwalo wakho wehliswa uye kwinombolo encane yezingcingo ze-[`drop_in_place`], ukusebenzisa lokhu akudingekile.
/// Ikakhulukazi qaphela ukuthi unga [`drop_in_place`] ucezu, futhi lokho kuzokwenza ukubheka okukodwa kwe-need_drop kuwo wonke amanani.
///
/// Izinhlobo ezinjenge-Vec ngakho-ke nje i-`drop_in_place(&mut self[..])` ngaphandle kokusebenzisa i-`needs_drop` ngokusobala.
/// Izinhlobo ezinjenge-[`HashMap`], ngakolunye uhlangothi, kufanele zilahle amanani ngasikhathi sinye futhi kufanele zisebenzise le API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Nasi isibonelo sendlela iqoqo elingayisebenzisa ngayo i `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // lahla idatha
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Ibuyisa inani lohlobo `T` elimele iphethini ye-all-zero byte.
///
/// Lokhu kusho ukuthi, ngokwesibonelo, i-padding byte ku-`(u8, u16)` ayenziwa zeroed.
///
/// Akunasiqinisekiso sokuthi iphethini ye-all-zero byte imele inani elivumelekile lohlobo oluthile lwe-`T`.
/// Isibonelo, iphethini ye-all-zero byte ayilona inani elivumelekile lezinhlobo zezethenjwa (`&T`, `&mut T`) nezikhombi zemisebenzi.
/// Sebenzisa i-`zeroed` ezinhlotsheni ezinjalo kubangela i-[undefined behavior][ub] esheshayo ngoba i-[the Rust compiler assumes][inv] ukuthi kuhlala kunenani elivumelekile kokuguquguqukayo elikubheka njengeqalisiwe.
///
///
/// Lokhu kunomphumela ofanayo ne-[`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Kuyasiza ku-FFI kwesinye isikhathi, kepha kufanele kugwenywe ngokuvamile.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ukusetshenziswa okulungile kwalo msebenzi: ukuqala inani eliphelele elino-zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Ukusetshenziswa okungalungile* kwalo msebenzi: ukuqalisa ireferensi enoziro.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Ukuziphatha okungachazwanga!
/// let _y: fn() = unsafe { mem::zeroed() }; // Futhi futhi!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi inani elingu-zero lonke lisebenza ku-`T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Ama-Bypasses Rust's memory-initialization checks ngokuzenza sengathi akhiqiza inani lohlobo `T`, kanti angenzi lutho nhlobo.
///
/// **Lo msebenzi wehlisiwe.** Sebenzisa i-[`MaybeUninit<T>`] esikhundleni salokho.
///
/// Isizathu sokwehliswa ukuthi umsebenzi ngokuyisisekelo awunakusetshenziswa kahle: unomphumela ofanayo nowe-[`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Njengoba i-[`assume_init` documentation][assume_init] ichaza, i-[the Rust compiler assumes][inv] ukuthi amanani aqaliswa kahle.
/// Njengomphumela, ukubiza isib
/// `mem::uninitialized::<bool>()` kubangela isimilo esingachazwanga ngokushesha sokubuyisa i-`bool` engeyona i-`true` noma i-`false`.
/// Okubi kakhulu, inkumbulo engaqaliwe ngempela efana nokuthi yini ebuyiswa lapha ikhethekile ngoba umhlanganisi uyazi ukuthi ayinanani elinqunyelwe.
/// Lokhu kwenza kube ukungazichazi ukuthi unedatha engaqaliwe ngokuguquguqukayo noma ngabe lokho kuguquka kunohlobo oluphelele.
/// (Qaphela ukuthi imithetho emayelana nezinamba ezingakaqalwa ayikaphothulwa okwamanje, kepha kuze kube yilapho iphela, kuyalulekwa ukuyigwema.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // UKUPHEPHA: ofonayo kufanele aqinisekise ukuthi inani elingaqalisiwe lisebenza ku-`T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ishintsha amanani wezindawo ezindaweni ezimbili eziguqukayo, ngaphandle kokukhipha eyodwa.
///
/// * Uma ufuna ukushintshana ngenani elizenzakalelayo noma le-dummy, bona i [`take`].
/// * Uma ufuna ukushintshana ngenani elidlulisiwe, ubuyisa inani lakudala, bona i [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // UKUPHEPHA: izikhombisi ezingavuthiwe zenziwe zivela kwizethenjwa eziphephile ezingaguquguquka ezinelisa konke
    // izingqinamba ku-`ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Ifaka esikhundleni se-`dest` ngenani elizenzakalelayo le-`T`, ibuyisa inani langaphambilini le-`dest`.
///
/// * Uma ufuna ukufaka esikhundleni samanani okuhlukahluka okubili, bona i [`swap`].
/// * Uma ufuna ukufaka esikhundleni senani elidlulisiwe esikhundleni senani elizenzakalelayo, bona i [`replace`].
///
/// # Examples
///
/// Isibonelo esilula:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ivumela ukuthatha ubunikazi bensimu eyakhiwe ngokufaka esikhundleni senani le-"empty".
/// Ngaphandle kwe `take` ungangena ezinkingeni ezinjengalezi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Qaphela ukuthi i-`T` ayisebenzisi i-[`Clone`], ngakho-ke ayikwazi ngisho nokuhlangana futhi isethe kabusha i `self.buf`.
/// Kepha i-`take` ingasetshenziselwa ukuhlukanisa inani langempela le-`self.buf` kusuka ku-`self`, ivumele ukuthi ibuyiswe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Ihambisa i-`src` ku-`dest` ebaluliwe, ibuyisa inani langaphambilini le-`dest`.
///
/// Alikho inani elilahliwe.
///
/// * Uma ufuna ukufaka esikhundleni samanani okuhlukahluka okubili, bona i [`swap`].
/// * Uma ufuna ukufaka esikhundleni senani elizenzakalelayo, bona i [`take`].
///
/// # Examples
///
/// Isibonelo esilula:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ivumela ukusetshenziswa kwensimu yokwakhiwa ngokufaka esikhundleni sayo elinye inani.
/// Ngaphandle kwe `replace` ungangena ezinkingeni ezinjengalezi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Qaphela ukuthi i-`T` ayisebenzisi i-[`Clone`], ngakho-ke asikwazi ngisho nokuhlanganisa i-`self.buf[i]` ukugwema ukuhamba.
/// Kepha i-`replace` ingasetshenziselwa ukuhlukanisa inani langempela kuleyo nkomba kusuka ku-`self`, ivumele ukuthi ibuyiswe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // UKUPHEPHA: Sifunda kusuka ku `dest` kepha sibhala ngqo i `src` kuyo ngemuva kwalokho,
    // okufana nokuthi inani elidala aliphindiwe.
    // Akukho lutho oluyehlisiwe futhi akukho lutho lapha olukwazi i panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Kulahlwa kwenani.
///
/// Lokhu kwenza lokhu ngokubiza ukuqaliswa kwengxabano kwe [`Drop`][drop].
///
/// Lokhu ngempumelelo akwenzi lutho ngezinhlobo ezisebenzisa i-`Copy`, isb
/// integers.
/// Amanani anjalo ayakopishwa futhi i-_then_ yahanjiswa yasebenza, ngakho-ke inani liyaqhubeka ngemuva kwale kholi yomsebenzi.
///
///
/// Lo msebenzi akuwona umlingo;ichazwa ngokoqobo ngokuthi
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ngoba i `_x` idluliselwe emsebenzini, yehla ngokuzenzakalela ngaphambi kokuba umsebenzi ubuye.
///
/// [drop]: Drop
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // yehla ngokusobala i vector
/// ```
///
/// Njengoba i-[`RefCell`] iphoqelela imithetho yokuboleka ngesikhathi sokusebenza, i-`drop` ingakhipha i-[`RefCell`] ebolekayo:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // dela ukubolekwa okuguqukayo kulesi slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Ama-integer nezinye izinhlobo ezisebenzisa i-[`Copy`] azithinteki yi-`drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ikhophi ye `x` iyasuswa bese ilahlwa
/// drop(y); // ikhophi ye `y` iyasuswa bese ilahlwa
///
/// println!("x: {}, y: {}", x, y.0); // isatholakala
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Ihumusha i-`src` njengohlobo lwe-`&U`, bese ifunda i-`src` ngaphandle kokuhambisa inani eliqukethwe.
///
/// Lo msebenzi uzothatha ngokungaphephile ukuthi i-pointer `src` isebenza kuma-byte angu-[`size_of::<U>`][size_of] ngokudlulisa i-`&T` iye ku-`&U` bese ifunda i-`&U` (ngaphandle kokuthi lokhu kwenziwa ngendlela eyiyo noma ngabe i-`&U` yenza izidingo zokuqondanisa eziqinile kune-`&T`).
/// Futhi kuzodala ngokungaphephile ikhophi levelu eliqukethwe esikhundleni sokuphuma ku-`src`.
///
/// Akusilo iphutha lesikhathi sokuhlanganiswa uma i-`T` ne-`U` zinosayizi abehlukene, kepha kuyakhuthazwa kakhulu ukuthi kwenziwe lo msebenzi kuphela lapho i-`T` ne-`U` zinosayizi ofanayo.Lo msebenzi udala i-[undefined behavior][ub] uma i-`U` inkulu kune-`T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopisha idatha kusuka ku-'foo_array' bese uyiphatha njenge-'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Shintsha idatha ekopishiwe
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Okuqukethwe kwe-'foo_array' bekungafanele kushintshe
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Uma i-U inesidingo sokuqondanisa okuphezulu, i-src ingahle iqondaniswe kahle.
    if align_of::<U>() > align_of::<T>() {
        // UKUPHEPHA: I-`src` yisethenjwa esiqinisekisiwe ukuthi sivumelekile ekufundweni.
        // Oshaya ucingo kufanele aqinisekise ukuthi ukushintshwa kwangempela kuphephile.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // UKUPHEPHA: I-`src` yisethenjwa esiqinisekisiwe ukuthi sivumelekile ekufundweni.
        // Simane nje sabheka ukuthi i `src as *const U` iqondaniswe kahle yini.
        // Oshaya ucingo kufanele aqinisekise ukuthi ukushintshwa kwangempela kuphephile.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Uhlobo lwe-Opaque olumele ukubandlulula kwe-enum.
///
/// Bona umsebenzi we [`discriminant`] kule module ukuthola eminye imininingwane.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Lokhu kuqaliswa kwe-trait akukwazi ukutholwa ngoba asifuni mingcele ku-T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Ibuyisa inani elikhomba ngokuhlukile okuhlukile kwe-enum ku-`v`.
///
/// Uma i-`T` kungeyona i-enum, ukubiza lo msebenzi ngeke kuholele ekuziphatheni okungachazwanga, kepha inani lokubuyisa alichazwanga.
///
///
/// # Stability
///
/// Ukubandlulula kokuhlukile kwe-enum kungashintsha uma incazelo ye-enum ishintsha.
/// Ukubandlululwa kokuhlukile ngeke kushintshe phakathi kokuhlanganiswa nomhlanganisi ofanayo.
///
/// # Examples
///
/// Lokhu kungasetshenziswa ukuqhathanisa ama-enum aphethe idatha, ngenkathi kunganakwa imininingwane yangempela:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Ibuyisa inani lokwahlukahluka kuhlobo lwe-enum `T`.
///
/// Uma i-`T` kungeyona i-enum, ukubiza lo msebenzi ngeke kuholele ekuziphatheni okungachazwanga, kepha inani lokubuyisa alichazwanga.
/// Ngokulinganayo, uma i-`T` iyi-enum enokuhlukahluka okuningi kune-`usize::MAX` inani lokubuyisa alicacisiwe.
/// Ukwahluka okungahlali muntu kuzobalwa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}