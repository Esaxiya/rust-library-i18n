#![stable(feature = "core_hint", since = "1.27.0")]

//! Amacebo wokuhlanganisa athinta ukuthi ikhodi kufanele ikhishwe kanjani noma yenziwe ngcono kanjani.
//! Amacebo angaba isikhathi sokuhlanganisa noma isikhathi sokusebenza.

use crate::intrinsics;

/// Yazisa umhlanganisi ukuthi leli phuzu lekhodi alifinyeleleki, linika amandla ukwenza okunye ukusebenza.
///
/// # Safety
///
/// Ukufinyelela lo msebenzi ngokuphelele *ukungachazeki kokuziphatha*(UB).Ikakhulu, umhlanganisi uthatha ukuthi yonke i-UB akumele yenzeke, ngakho-ke izosusa wonke amagatsha afinyelela ocingweni oluya ku-`unreachable_unchecked()`.
///
/// Njengazo zonke izimo ze-UB, uma lokhu kucabanga kuvela ukuthi akulungile, okungukuthi, ucingo lwe `unreachable_unchecked()` empeleni lungafinyeleleka phakathi kwakho konke ukugeleza kokulawula okungenzeka, umhlanganisi uzosebenzisa isu lokusebenzisa okungalungile, futhi kwesinye isikhathi angahle akhohlakele nekhodi ebonakala ingahlobene, okwenza kube nzima izinkinga zokususa iphutha.
///
///
/// Sebenzisa lo msebenzi kuphela lapho ungafakazela ukuthi ikhodi ngeke ize iyibize.
/// Ngaphandle kwalokho, cabanga ukusebenzisa i-[`unreachable!`] macro, engavumeli ukwenziwa kube lula kepha izokwenza i-panic uma isenziwa.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` ihlala i-positive (hhayi zero), yingakho i-`checked_div` ingeke ibuye i-`None`.
/////
///     // Ngakho-ke, enye i-branch ayitholakali.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // UKUPHEPHA: inkontileka yezokuphepha ye `intrinsics::unreachable` kumele
    // gcinwa yilowo ofonayo.
    unsafe { intrinsics::unreachable() }
}

/// Ikhipha umyalo womshini ukukhombisa iprosesa ukuthi isebenza ku-spin-loop ematasa yokulinda ("spin lock").
///
/// Lapho ithola isignali ye-spin-loop iprosesa ingalungiselela ukusebenza kwayo, ngokwesibonelo, yokonga amandla noma ngokushintsha imicu ye-hyper.
///
/// Lo msebenzi wehlukile ku-[`thread::yield_now`] oveza ngqo isheduli yesistimu, kanti i-`spin_loop` ayihlangani nohlelo lokusebenza.
///
/// Icala lokusetshenziswa elijwayelekile le-`spin_loop` lisebenzisa ukuphotha okunamandla okuboshelwe ku-loop ye-CAS kuzindawo zokuqala zokuvumelanisa.
/// Ukugwema izinkinga ezinjenge-inversion ehamba phambili, kunconywa ngokuqinile ukuthi i-spin loop inqanyulwe ngemuva kwenani elilinganiselwe lokuphindwaphindwa futhi kwenziwe i-syscall efanelekile yokuvimba.
///
///
/// **Qaphela**: Kuzingxenyekazi ezingakusekeli ukuthola izeluleko ze-spin-loop lo msebenzi awenzi lutho nhlobo.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Inani elabiwe le-athomu elizoqedwa imicu ukuxhumanisa
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Kumucu ongemuva ekugcineni sizosetha inani
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Yenza umsebenzi othile, bese wenza inani libe bukhoma
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Emuva ngentambo yethu yamanje, silinda ukuthi inani lisethwe
/// while !live.load(Ordering::Acquire) {
///     // I-spin loop isikisela ku-CPU esiyilindile, kepha mhlawumbe hhayi isikhathi eside
/////
///     hint::spin_loop();
/// }
///
/// // Inani manje selisethiwe
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // UKUPHEPHA: i-`cfg` attr iqinisekisa ukuthi lokhu sikwenza kuphela kuzinhloso ze-x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // UKUPHEPHA: i-`cfg` attr iqinisekisa ukuthi lokhu sikwenza kuphela kuzinhloso ze-x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // UKUPHEPHA: i-`cfg` attr iqinisekisa ukuthi lokhu sikwenza kuphela kuzinhloso ze-aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // UKUPHEPHA: i-`cfg` attr iqinisekisa ukuthi lokhu sikwenza kuphela ezinhlosweni zengalo
            // ngokusekelwa kwesici se-v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Umsebenzi wobunikazi othi *__ ukhomba __* kumhlanganisi ukuze abe nethemba elikhulu ngalokho okungenziwa yi `black_box`.
///
/// Ngokungafani ne-[`std::convert::identity`], umhlanganisi we-Rust uyakhuthazwa ukuthi acabange ukuthi i-`black_box` ingasebenzisa i-`dummy` nganoma iyiphi indlela evumelekile ikhodi ye Rust evunyelwe kuyo ngaphandle kokwethula isimilo esingachazwanga kukhodi yokushaya.
///
/// Le mpahla yenza i `black_box` ibe wusizo ekubhaleni ikhodi lapho ukulungiselelwa okuthile kungafuneki khona, njengamabhentshi.
///
/// Qaphela kepha, ukuthi i `black_box` inikezwa kuphela (futhi inganikezwa kuphela) ngesisekelo se "best-effort".Izinga elingavimba ukulungiselelwa lingahluka ngokuya ngeplathifomu ne-code-gen backend esetshenzisiwe.
/// Izinhlelo azikwazi ukuthembela ku-`black_box` ukuthola *ukunemba* nganoma iyiphi indlela.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Sidinga i-"use" impikiswano ngandlela thile i-LLVM engakwazi ukucubungula, futhi kuzinhloso eziyisekelayo singakwazi ukusebenzisa umhlangano osemgqeni ukwenza lokhu.
    // Ukuchazwa kwe-LLVM yomhlangano we-inline ukuthi, kulungile, ibhokisi elimnyama.
    // Lokhu akukhona ukuqaliswa okukhulu kunakho konke ngoba kungenzeka kukhulule amandla ngaphezu kokufunayo, kepha kukude kakhulu ngokwanele.
    //
    //

    #[cfg(not(miri))] // Lokhu nje ukusikisela, ngakho-ke kuhle ukweqa eMiri.
    // UKUPHEPHA: umhlangano osemgqeni awukho op.
    unsafe {
        // FIXME: Ayikwazi ukusebenzisa i-`asm!` ngoba ayisekeli i-MIPS namanye ama-architectures.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}