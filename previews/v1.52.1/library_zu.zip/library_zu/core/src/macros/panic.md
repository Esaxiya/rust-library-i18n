I-Panics intambo yamanje.

Lokhu kuvumela uhlelo ukuthi lunqamule ngokushesha futhi lunikeze impendulo kulowo ofonayo wohlelo.
`panic!` kufanele isetshenziswe lapho uhlelo lufinyelela esimweni esingatholakali.

Le macro yindlela ephelele yokuqinisekisa izimo ngekhodi yesibonelo nakuzivivinyo.
`panic!` iboshelwe eduze nendlela ye `unwrap` yazo zombili izinombolo ze-[`Option`][ounwrap] ne-[`Result`][runwrap].
Kokubili ukuqaliswa kubiza i-`panic!` lapho kusethwe kokuhlukile kwe-[`None`] noma kwe-[`Err`].

Uma usebenzisa i-`panic!()` ungacacisa ukulayishwa kwentambo, okwakhiwe kusetshenziswa i-syntax ye-[`format!`].
Lokho kulayishwa kusetshenziswa lapho kufakwa i-panic ocingweni lwe-Rust, okwenza intambo ibe yi-panic ngokuphelele.

Ukuziphatha kwe-`std` hook ezenzakalelayo, okungukuthi
ikhodi egijima ngqo ngemuva kokucelwa i-panic, ukuphrinta ukulayishwa komlayezo ku-`stderr` kanye nemininingwane ye-file/line/column yocingo lwe-`panic!()`.

Ungabhala ngaphezulu i-panic hook usebenzisa i-[`std::panic::set_hook()`].
Ngaphakathi kwe-hook i-panic ingafinyelelwa njenge-`&dyn Any + Send`, equkethe i-`&str` noma i-`String` yokuncenga okuvamile kwe-`panic!()`.
Ku-panic ngenani lolunye uhlobo, i-[`panic_any`] ingasetshenziswa.

[`Result`] I-enum imvamisa iyisixazululo esingcono sokululama emaphutheni kunokusebenzisa i-`panic!` macro.
Le macro kufanele isetshenziselwe ukugwema ukuqhubeka usebenzisa amanani angalungile, njengokuvela emithonjeni yangaphandle.
Imininingwane enemininingwane ngokusingathwa kwephutha itholakala ku [book].

Bona futhi i-macro [`compile_error!`], yokukhulisa amaphutha ngesikhathi sokuhlanganiswa.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Ukuqaliswa kwamanje

Uma intambo enkulu i panics izonqamula yonke imicu yakho bese iqeda uhlelo lwakho ngekhodi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





