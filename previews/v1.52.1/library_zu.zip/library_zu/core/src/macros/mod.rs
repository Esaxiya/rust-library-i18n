#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Inwebeka kuye ku-`$crate::panic::panic_2015` noma ku-`$crate::panic::panic_2021` ngokuya ngohlobo lwekholi.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Yengeza ukuthi izinkulumo ezimbili ziyalingana (zisebenzisa i-[`PartialEq`]).
///
/// Ku-panic, le macro izophrinta amanani ezinkulumo ngezethulo zazo zokususa amaphutha.
///
///
/// Njenge-[`assert!`], le macro inefomu lesibili, lapho kunganikezwa khona umyalezo we-panic wangokwezifiso.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ukubuyiselwa okungezansi kungenhloso.
                    // Ngaphandle kwabo, istaki slot sokubolekwa siqaliswa ngisho nangaphambi kokuba amanani aqhathaniswe, okuholela ekwehliseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ukubuyiselwa okungezansi kungenhloso.
                    // Ngaphandle kwabo, istaki slot sokubolekwa siqaliswa ngisho nangaphambi kokuba amanani aqhathaniswe, okuholela ekwehliseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yengeza ukuthi izinkulumo ezimbili azilingani (zisebenzisa i-[`PartialEq`]).
///
/// Ku-panic, le macro izophrinta amanani ezinkulumo ngezethulo zazo zokususa amaphutha.
///
///
/// Njenge-[`assert!`], le macro inefomu lesibili, lapho kunganikezwa khona umyalezo we-panic wangokwezifiso.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ukubuyiselwa okungezansi kungenhloso.
                    // Ngaphandle kwabo, istaki slot sokubolekwa siqaliswa ngisho nangaphambi kokuba amanani aqhathaniswe, okuholela ekwehliseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ukubuyiselwa okungezansi kungenhloso.
                    // Ngaphandle kwabo, istaki slot sokubolekwa siqaliswa ngisho nangaphambi kokuba amanani aqhathaniswe, okuholela ekwehliseni okubonakalayo.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Yazisa ukuthi isisho se-boolean sithi `true` ngesikhathi sokusebenza.
///
/// Lokhu kuzonxenxa i-[`panic!`] macro uma isisho esinikeziwe singeke sabuyekezelwa ku-`true` ngesikhathi sokusebenza.
///
/// Njenge-[`assert!`], le macro nayo inenguqulo yesibili, lapho kunganikezwa khona umyalezo wangokwezifiso we-panic.
///
/// # Uses
///
/// Ngokungafani ne-[`assert!`], izitatimende ze-`debug_assert!` zinikwa amandla kuphela ekwakhiweni okungalungiselelwe ngokuzenzakalela.
/// Ukwakhiwa okulungiselelwe ngeke kusebenze izitatimende ze-`debug_assert!` ngaphandle kokuthi i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Lokhu kwenza i-`debug_assert!` ibe wusizo kumasheke abiza kakhulu ukuba khona ekwakhiweni kokukhishwa kepha angasiza ngesikhathi sokuthuthuka.
/// Umphumela wokunweba i-`debug_assert!` uhlala uhlolwe uhlobo.
///
/// Ukugomela okungamakiwe kuvumela uhlelo olusesimweni esingahambelani ukuthi luqhubeke nokusebenza, okungaba nemiphumela engalindelekile kepha kungalethi ukuphepha inqobo nje uma lokhu kwenzeka ngekhodi ephephile.
///
/// Izindleko zokusebenza kokuqinisekisiwe, noma kunjalo, azilinganiseki ngokujwayelekile.
/// Ukufaka okunye esikhundleni se-[`assert!`] nge-`debug_assert!` ngakho-ke kukhuthazwa kuphela ngemuva kokuphrinta ngokuphelele, futhi okubaluleke kakhulu, kukhodi ephephile kuphela!
///
/// # Examples
///
/// ```
/// // umlayezo we-panic walezi ziqinisekiso inani elihlanganisiwe lenkulumo enikeziwe.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // umsebenzi olula kakhulu
/// debug_assert!(some_expensive_computation());
///
/// // gomela ngomlayezo wangokwezifiso
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Ifaka ukuthi izinkulumo ezimbili ziyalingana.
///
/// Ku-panic, le macro izophrinta amanani ezinkulumo ngezethulo zazo zokususa amaphutha.
///
/// Ngokungafani ne-[`assert_eq!`], izitatimende ze-`debug_assert_eq!` zinikwa amandla kuphela ekwakhiweni okungalungiselelwe ngokuzenzakalela.
/// Ukwakhiwa okulungiselelwe ngeke kusebenze izitatimende ze-`debug_assert_eq!` ngaphandle kokuthi i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Lokhu kwenza i-`debug_assert_eq!` ibe wusizo kumasheke abiza kakhulu ukuba khona ekwakhiweni kokukhishwa kepha angasiza ngesikhathi sokuthuthuka.
///
/// Umphumela wokunweba i-`debug_assert_eq!` uhlala uhlolwe uhlobo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Ifaka ukuthi izinkulumo ezimbili azilingani.
///
/// Ku-panic, le macro izophrinta amanani ezinkulumo ngezethulo zazo zokususa amaphutha.
///
/// Ngokungafani ne-[`assert_ne!`], izitatimende ze-`debug_assert_ne!` zinikwa amandla kuphela ekwakhiweni okungalungiselelwe ngokuzenzakalela.
/// Ukwakhiwa okulungiselelwe ngeke kusebenze izitatimende ze-`debug_assert_ne!` ngaphandle kokuthi i-`-C debug-assertions` idluliselwe kumhlanganisi.
/// Lokhu kwenza i-`debug_assert_ne!` ibe wusizo kumasheke abiza kakhulu ukuba khona ekwakhiweni kokukhishwa kepha angasiza ngesikhathi sokuthuthuka.
///
/// Umphumela wokunweba i-`debug_assert_ne!` uhlala uhlolwe uhlobo.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Ibuyisa ukuthi ingabe isisho esinikeziwe siyafana nanoma yimaphi amaphethini anikeziwe.
///
/// Njengesisho se-`match`, iphethini ingalandelwa ngokuzikhethela yi-`if` nesisho sokuqapha esinokufinyelela kwamagama aboshwe iphethini.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Isonga imiphumela noma isakaze iphutha layo.
///
/// I-`?` opharetha ingezwe ukufaka esikhundleni se-`try!` futhi kufanele isetshenziswe esikhundleni sayo.
/// Ngaphezu kwalokho, i-`try` yigama eligodliwe ku-Rust 2018, ngakho-ke uma kufanele ulisebenzise, uzodinga ukusebenzisa i [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ifana ne [`Result`] enikeziwe.Uma kwenzeka okuhlukile kwe-`Ok`, isisho sinenani levelu elisongelwe.
///
/// Uma kwenzeka i-`Err` ehlukile, ibuyisa iphutha langaphakathi.I-`try!` bese yenza ukuguqulwa isebenzisa i-`From`.
/// Lokhu kunikeza ukuguqulwa okuzenzakalelayo phakathi kwamaphutha akhethekile namanye ajwayelekile.
/// Iphutha eliholelwayo libuyiselwa ngokushesha.
///
/// Ngenxa yokubuyela kwangaphambi kwesikhathi, i-`try!` ingasetshenziswa kuphela kwimisebenzi ebuyisa i-[`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Indlela encanyelwayo yokubuyisa amaphutha ngokushesha
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Indlela edlule yokubuyisa amaphutha ngokushesha
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Lokhu kulingana nokuthi:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Ubhala idatha efomathiwe kusiphazamisi.
///
/// Le macro yamukela i-'writer', umucu wefomethi, nohlu lwezimpikiswano.
/// Izimpikiswano zizofomethwa ngokuya ngentambo yefomethi ebekiwe futhi umphumela uzodluliselwa kumbhali.
/// Umbhali angaba yinoma iyiphi indlela enendlela ye `write_fmt`;imvamisa lokhu kuvela ekusetshenzisweni kwe-[`fmt::Write`] noma i-[`io::Write`] trait.
/// Imacro ibuyisa noma yini ebuyayo ngendlela ye `write_fmt`;imvamisa i-[`fmt::Result`], noma i-[`io::Result`].
///
/// Bona i [`std::fmt`] ukuthola eminye imininingwane kusakhiwo sentambo syntax.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Imodyuli ingangenisa zombili i-`std::fmt::Write` ne-`std::io::Write` bese ibiza i-`write!` ezintweni ezisebenzisa noma, njengoba izinto zingakwenzi bobabili.
///
/// Kodwa-ke, imodyuli kufanele ingenise i traits efanelekile ukuze amagama abo angangqubuzani:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // isebenzisa i fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // isebenzisa i io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Le macro ingasetshenziswa kuma-setups e-`no_std`.
/// Ekusetheni i-`no_std` unesibopho semininingwane yokuqalisa yezinto.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Bhala idatha efomathiwe kubhafa, kufakwe i-newline line.
///
/// Kuwo wonke amapulatifomu, i-newline iyinhlamvu ye-LINE FEED (`\n`/`U+000A`) iyodwa (akukho CARRIAGE RETURN (`\r`/`U+000D`) eyengeziwe.
///
/// Ngemininingwane engaphezulu, bheka i [`write!`].Ngemininingwane nge-syntax yochungechunge lwefomethi, bona i [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Imodyuli ingangenisa zombili i-`std::fmt::Write` ne-`std::io::Write` bese ibiza i-`write!` ezintweni ezisebenzisa noma, njengoba izinto zingakwenzi bobabili.
/// Kodwa-ke, imodyuli kufanele ingenise i traits efanelekile ukuze amagama abo angangqubuzani:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // isebenzisa i fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // isebenzisa i io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Ikhombisa ikhodi engatholakali.
///
/// Lokhu kuyasiza noma nini lapho umhlanganisi engakwazi ukunquma ukuthi ikhodi ethile ayinakufinyeleleka.Ngokwesibonelo:
///
/// * Qondanisa izingalo nemibandela yokuqapha.
/// * Amaluphu aqeda ngamandla.
/// * Ama-terter aqeda ngamandla.
///
/// Uma ukuzimisela kokuthi ikhodi ingafinyeleleki kufakazela ukuthi akulona iqiniso, uhlelo luyeka ngokushesha nge-[`panic!`].
///
/// Uzakwethu ongaphephile wale macro ngumsebenzi we [`unreachable_unchecked`], ozodala isimilo esingachazeki uma ikhodi ifinyelelwa.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Lokhu kuzohlala kuyi-[`panic!`].
///
/// # Examples
///
/// Qondanisa izingalo:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // hlanganisa iphutha uma kuphawuliwe
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // okunye ukusetshenziswa okumpofu kakhulu kwe x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Ikhombisa ikhodi engasetshenziswanga ngokushaywa ngumlayezo we-"not implemented".
///
/// Lokhu kuvumela ikhodi yakho ukuthayipha-hlola, okuwusizo uma wenza prototyping noma usebenzisa i-trait edinga izindlela eziningi ongahlelile ukuzisebenzisa zonke.
///
/// Umehluko phakathi kwe-`unimplemented!` ne-[`todo!`] ngukuthi ngenkathi i-`todo!` idlulisa inhloso yokusebenzisa ukusebenza kamuva futhi umlayezo ngu-"not yet implemented", i-`unimplemented!` ayizenzi izimangalo ezinjalo.
/// Umlayezo wayo ngu "not implemented".
/// Futhi amanye ama-IDE azomaka `todo!` S.
///
/// # Panics
///
/// Lokhu kuzohlala kungu-[`panic!`] ngoba i-`unimplemented!` imane iyisifinyezo se-`panic!` ngomyalezo ohleliwe, othize.
///
/// Njenge-`panic!`, le macro inefomu lesibili lokubonisa amanani wangokwezifiso.
///
/// # Examples
///
/// Ithi sine-trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Sifuna ukusebenzisa i-`Foo` ye-'MyStruct', kepha ngasizathu simbe kunengqondo ukwenza umsebenzi we-`bar()`.
/// `baz()` futhi i-`qux()` kusazodingeka ichazwe ekusetshenzisweni kwethu kwe-`Foo`, kepha singasebenzisa i-`unimplemented!` encazelweni yabo ukuvumela ikhodi yethu ukuba ihlanganiswe.
///
/// Sisafuna ukuthi uhlelo lwethu luyeke ukusebenza uma izindlela ezingasetshenziswanga zifinyelelwa.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Akunangqondo ukuthi i-`baz` ibe yi-`MyStruct`, ngakho-ke asinawo umqondo lapha.
/////
///         // Lokhu kuzokhombisa i "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Sinomqondo othile lapha, Singangeza umyalezo kokungasetshenziswanga!ukukhombisa ukushiyeka kwethu.
///         // Lokhu kuzobonisa: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Ikhombisa ikhodi engakaqedwa.
///
/// Lokhu kungaba wusizo uma wenza prototyping futhi ubheke nje ukuba nekhodi yakho typecheck.
///
/// Umehluko phakathi kwe-[`unimplemented!`] ne-`todo!` ngukuthi ngenkathi i-`todo!` idlulisa inhloso yokusebenzisa ukusebenza kamuva futhi umlayezo ngu-"not yet implemented", i-`unimplemented!` ayizenzi izimangalo ezinjalo.
/// Umlayezo wayo ngu "not implemented".
/// Futhi amanye ama-IDE azomaka `todo!` S.
///
/// # Panics
///
/// Lokhu kuzohlala kuyi-[`panic!`].
///
/// # Examples
///
/// Nasi isibonelo senye ikhodi eqhubekayo.Sine-trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Sifuna ukusebenzisa i-`Foo` kolunye lwezinhlobo zethu, kepha futhi sifuna ukusebenza ku-`bar()` kuqala.Ukuze ikhodi yethu ihlanganiswe, sidinga ukusebenzisa i-`baz()`, ukuze sikwazi ukusebenzisa i-`todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ukuqaliswa kuya lapha
///     }
///
///     fn baz(&self) {
///         // masingakhathazeki ngokusebenzisa i-baz() okwamanje
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // asisebenzisi i baz(), ngakho-ke kulungile.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Izincazelo zama-macros akhelwe ngaphakathi.
///
/// Iningi lezakhiwo ze-macro (ukuzinza, ukubonakala, njll.) Zithathwe kukhodi yomthombo lapha, ngaphandle kwemisebenzi yokwandisa eguqula okokufaka okukhulu kube yimiphumela, leyo misebenzi inikezwa ngumhlanganisi.
///
///
pub(crate) mod builtin {

    /// Ibangela ukuhlanganiswa kwehluleke ngomyalezo wephutha onikeziwe lapho uhlangabezana nawo.
    ///
    /// Le macro kufanele isetshenziswe lapho i crate isebenzisa isu lokuhlanganisa elinemibandela ukuhlinzeka ngemiyalezo yamaphutha engcono yezimo ezinamaphutha.
    ///
    /// Yifomu lezinga lomhlanganisi le-[`panic!`], kepha likhipha iphutha phakathi *kokuhlanganiswa* hhayi *ngesikhathi sokusebenza*.
    ///
    /// # Examples
    ///
    /// Izibonelo ezimbili ezinje ngamamakhro nezindawo ze-`#[cfg]`.
    ///
    /// Khipha iphutha lokuhlanganisa elingcono uma imakhro idluliswa ngamanani angavumelekile.
    /// Ngaphandle kwe-branch yokugcina, umhlanganisi usazokhipha iphutha, kepha umlayezo wephutha ubungeke usho amanani amabili avumelekile.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Khipha iphutha lokuhlanganisa uma enye yezici ezimbalwa ingatholakali.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yakha amapharamitha wamanye ama-macro wokufomatha izintambo.
    ///
    /// Le misebenzi emikhulu ngokuthatha intambo yokufomatha ngokoqobo equkethe i-`{}` yengxabano ngayinye eyengeziwe edlulisiwe.
    /// `format_args!` ilungisa amapharamitha angeziwe ukuqinisekisa ukuthi okukhishwayo kungahunyushwa njengeyunithi yezinhlamvu futhi iqondise izimpikiswano ngohlobo olulodwa.
    /// Noma yiliphi inani elisebenzisa i-[`Display`] trait lingadluliselwa ku-`format_args!`, njengoba kungenza noma yikuphi ukuqaliswa kwe-[`Debug`] kudluliselwe ku-`{:?}` ngaphakathi kwentambo yokufomatha.
    ///
    ///
    /// Le macro ikhiqiza inani lohlobo [`fmt::Arguments`].Leli nani lingadluliselwa kuma-macros angaphakathi kwe-[`std::fmt`] ngokwenza ukuqondisa kabusha okuwusizo.
    /// Onke amanye ama-macro wokufomatha ([`format!`], [`write!`], [`println!`], njll) amelwe ngalokhu.
    /// `format_args!`, ngokungafani nama-macros akhishwe, igwema ukwabiwa kwenqwaba.
    ///
    /// Ungasebenzisa inani le-[`fmt::Arguments`] elibuyiselwa i-`format_args!` kuzimo ze-`Debug` ne-`Display` njengoba kuboniswe ngezansi.
    /// Isibonelo sikhombisa nokuthi ifomethi ye-`Debug` ne-`Display` entweni efanayo: intambo yefomethi ehlanganisiwe ku-`format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Ngeminye imininingwane, bona imibhalo ku-[`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Kuyafana ne `format_args`, kepha kungeza umugqa omusha ekugcineni.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ihlola ukuguquguquka kwemvelo ngesikhathi sokuhlanganiswa.
    ///
    /// Le macro izokwenabela kunani lokuguquguquka kwemvelo ngegama ngesikhathi sokuhlanganiswa, kuveze ukubonakaliswa kohlobo `&'static str`.
    ///
    ///
    /// Uma ukuguquguquka kwemvelo kungachaziwe, kuzokhishwa iphutha lokuhlanganiswa.
    /// Ukuze ungakhiphi iphutha lokuhlanganisa, sebenzisa i-[`option_env!`] macro esikhundleni salokho.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ungenza ngendlela oyifisayo umlayezo wephutha ngokudlulisa intambo njengepharamitha yesibili:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Uma ukuguquguquka kwemvelo kwe `documentation` kungachaziwe, uzothola iphutha elilandelayo:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ngokuzithandela ihlola ukuguquguquka kwemvelo ngesikhathi sokuhlanganiswa.
    ///
    /// Uma ukuguquguquka kwemvelo okunamagama kukhona ngesikhathi sokuhlanganiswa, lokhu kuzokwanda kube isichasiso sohlobo `Option<&'static str>` inani laso lingu-`Some` lenani lokuhlukahluka kwemvelo.
    /// Uma ukuguquguquka kwemvelo kungekho, khona-ke lokhu kuzonabela ku-`None`.
    /// Bona i [`Option<T>`][Option] ukuthola eminye imininingwane ngalolu hlobo.
    ///
    /// Iphutha lesikhathi sokuhlanganiswa alikaze likhishwe lapho usebenzisa le macro kungakhathalekile ukuthi ukuguquguquka kwemvelo kukhona noma cha.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Iqinisa izikhombi zibe okokuhlonza okukodwa.
    ///
    /// Le macro ithatha noma iyiphi inombolo okokuhlonza okwehlukaniswe ngamakhoma, futhi iyazihlanganisa zonke zibe munye, iveza isisho esisihlonzi esisha.
    /// Qaphela ukuthi inhlanzeko yenza ukuthi le macro ingakwazi ukuthwebula okuguqukayo kwasendaweni.
    /// Futhi, njengomthetho ojwayelekile, ama-macros avunyelwe kuphela entweni, esitatimendeni noma endaweni yokubonisa.
    /// Lokho kusho ukuthi ngenkathi ungasebenzisa le macro ukubhekisa kokuguqukayo okukhona, imisebenzi noma amamojula njll, awukwazi ukuchaza okusha ngayo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (okusha, kumnandi, igama) i { }//ayisebenziseki ngale ndlela!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ihlanganisa imibhalo ibe ngocezu lwentambo olungama ndawonye.
    ///
    /// Le macro ithatha noma yiliphi inani lezincwadi ezihlukaniswe ngokhefana, kuveza ukubonakaliswa kohlobo `&'static str` olumele zonke izincwadi ezibhalwe ngasesandleni sokudla kuye kwesokudla.
    ///
    ///
    /// Amanani wezinombolo eziphelele nezintantayo ahlanganisiwe ukuze ahlanganiswe.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inwebeka kunombolo yomugqa lapho ibizwe khona.
    ///
    /// Nge-[`column!`] ne-[`file!`], lawa ma-macros anikezela ngemininingwane yokulungisa iphutha konjiniyela ngendawo engaphakathi komthombo.
    ///
    /// Isisho esandisiwe sinohlobo `u32` futhi sisuselwe ku-1, ngakho-ke umugqa wokuqala kufayela ngalinye uhlola u-1, owesibili kuye ku-2, njll.
    /// Lokhu kuyahambisana nemiyalezo yamaphutha ngabahlanganisi abajwayelekile noma abahleli abadumile.
    /// Ulayini obuyisiwe *awuwona neze* umugqa wokucela we-`line!` uqobo, kepha kunalokho ukunxusa kokuqala okukhulu okuholela ekunxenxweni kwe-`line!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Inwebeka kunombolo yekholomu lapho ibizwe khona.
    ///
    /// Nge-[`line!`] ne-[`file!`], lawa ma-macros anikezela ngemininingwane yokulungisa iphutha konjiniyela ngendawo engaphakathi komthombo.
    ///
    /// Isisho esandisiwe sinohlobo `u32` futhi sisuselwe ku-1, ngakho-ke ikholomu yokuqala kulayini ngamunye ihlola ibe ngu-1, eyesibili iye ku-2, njll.
    /// Lokhu kuyahambisana nemiyalezo yamaphutha ngabahlanganisi abajwayelekile noma abahleli abadumile.
    /// Ikholomu ebuyisiwe *akusho ukuthi* umugqa wokucela kwe-`column!` uqobo, kepha kunalokho ukunxusa kokuqala okukhulu okuholela ekunxenxweni kwe-`column!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Inwebela egameni lefayela lapho lifakwe khona.
    ///
    /// Nge-[`line!`] ne-[`column!`], lawa ma-macros anikezela ngemininingwane yokulungisa iphutha konjiniyela ngendawo engaphakathi komthombo.
    ///
    /// Isisho esandisiwe sinohlobo lwe-`&'static str`, futhi ifayela elibuyisiwe akulona ukunxenxa i-`file!` macro uqobo, kepha kunalokho ukunxusa kokuqala okukhulu okuholela ekunxenxeni i-`file!` macro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Iqinisa izimpikiswano zayo.
    ///
    /// Le macro izokhipha isisho sohlobo `&'static str` okuwukuhlanganiswa kwazo zonke i tokens ezidluliselwe kumakhro.
    /// Akukho mikhawulo ebekwayo ku-syntax yokuncenga okukhulu uqobo.
    ///
    /// Qaphela ukuthi imiphumela enwetshiwe yokufaka i-tokens ingashintsha ku-future.Kufanele uqaphele uma uncika kokukhiphayo.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kufaka phakathi i-UTF-8 file encoded as a string.
    ///
    /// Ifayela litholakala ngokuhlobene nefayela lamanje (ngokufana nokuthi amamojula atholakala kanjani).
    /// Indlela enikeziwe ihunyushwa ngendlela eqondene nengxenyekazi ngesikhathi sokuhlanganiswa.
    /// Ngakho-ke, ngokwesibonelo, ukunxusa okunendlela engu-Windows equkethe i-backslashes `\` ngeke kuhlanganiswe kahle ku-Unix.
    ///
    ///
    /// Le macro izokhipha isisho sohlobo `&'static str` okungukuqukethwe kwefayela.
    ///
    /// # Examples
    ///
    /// Thatha ukuthi kunamafayela amabili enkombeni efanayo anokuqukethwe okulandelayo:
    ///
    /// Ifayela le-'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ifayela le-'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Ukuhlanganisa i-'main.rs' nokusebenzisa kanambambili okuvelayo kuzophrinta i-"adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Kufaka phakathi ifayili njengesethenjwa kumalungu afanayo we-Byte.
    ///
    /// Ifayela litholakala ngokuhlobene nefayela lamanje (ngokufana nokuthi amamojula atholakala kanjani).
    /// Indlela enikeziwe ihunyushwa ngendlela eqondene nengxenyekazi ngesikhathi sokuhlanganiswa.
    /// Ngakho-ke, ngokwesibonelo, ukunxusa okunendlela engu-Windows equkethe i-backslashes `\` ngeke kuhlanganiswe kahle ku-Unix.
    ///
    ///
    /// Le macro izokhipha isisho sohlobo `&'static [u8; N]` okungukuqukethwe kwefayela.
    ///
    /// # Examples
    ///
    /// Thatha ukuthi kunamafayela amabili enkombeni efanayo anokuqukethwe okulandelayo:
    ///
    /// Ifayela le-'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Ifayela le-'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Ukuhlanganisa i-'main.rs' nokusebenzisa kanambambili okuvelayo kuzophrinta i-"adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inwebela ngentambo emele indlela yamanje yamamojula.
    ///
    /// Indlela yamanje yamamojula ingacatshangwa njengobukhosi bamamojula aholela emuva ku-crate root.
    /// Ingxenye yokuqala yendlela ebuyisiwe igama le-crate okwamanje ehlanganiswayo.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Ihlaziya inhlanganisela yama-boolean amafulegi wokumisa ngesikhathi sokuhlanganisa.
    ///
    /// Ngokungeziwe kusichasiso se-`#[cfg]`, le macro inikezwe ukuvumela ukuhlolwa kwe-boolean expression yamafulegi wokumisa.
    /// Lokhu kuvame ukuholela kukhodi ephindwe kabili.
    ///
    /// I-syntax enikezwe le macro iyisi syntax esifanayo nesichasiso se-[`cfg`].
    ///
    /// `cfg!`, ngokungafani ne-`#[cfg]`, ayisusi noma iyiphi ikhodi futhi ihlola kuphela kube yiqiniso noma amanga.
    /// Isibonelo, wonke amabhulokhi kusisho se-if/else adinga ukusebenza uma i-`cfg!` isetshenziselwa isimo, noma ngabe i-`cfg!` ihlola ini.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Ihambisa ifayili njengesisho noma into ngokuya ngomongo.
    ///
    /// Ifayela litholakala ngokuhlobene nefayela lamanje (ngokufana nokuthi amamojula atholakala kanjani).Indlela enikeziwe ihunyushwa ngendlela eqondene nengxenyekazi ngesikhathi sokuhlanganiswa.
    /// Ngakho-ke, ngokwesibonelo, ukunxusa okunendlela engu-Windows equkethe i-backslashes `\` ngeke kuhlanganiswe kahle ku-Unix.
    ///
    /// Kusetshenziswa le macro kaningi kuwumqondo omubi, ngoba uma ifayili lidwetshwe njengesisho, lizobekwa kukhodi ezungezile ngaphandle kokuhlanzeka.
    /// Lokhu kungaholela kokuguquguqukayo noma imisebenzi yehluke kulokho okulindelwe yifayela uma kukhona okuguqukayo noma imisebenzi enegama elifanayo kufayela lamanje.
    ///
    ///
    /// # Examples
    ///
    /// Thatha ukuthi kunamafayela amabili enkombeni efanayo anokuqukethwe okulandelayo:
    ///
    /// Ifayela le-'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Ifayela le-'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Ukuhlanganisa i-'main.rs' nokusebenzisa kanambambili okuvelayo kuzophrinta i-"🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Yazisa ukuthi isisho se-boolean sithi `true` ngesikhathi sokusebenza.
    ///
    /// Lokhu kuzonxenxa i-[`panic!`] macro uma isisho esinikeziwe singeke sabuyekezelwa ku-`true` ngesikhathi sokusebenza.
    ///
    /// # Uses
    ///
    /// Ukuqinisekiswa kuhlala kuhlolwe kukho kokubili ukulungisa iphutha nokukhululwa kwakhiwe, futhi akukwazi ukukhutshazwa.
    /// Bona i-[`debug_assert!`] ukuthola okuqinisekisiwe okungavunyelwe ekukhululweni kwakhiwe ngokuzenzakalela.
    ///
    /// Ikhodi engaphephile ingathembela ku-`assert!` ukuphoqelela abagibeli besikhathi sokusebenza okuthi, uma bephuliwe kungaholela ekuphepheni.
    ///
    /// Amanye amacala wokusebenzisa we-`assert!` afaka ukuhlolwa nokuphoqelelwa kokungenayo kwesikhathi sokusebenza ngekhodi ephephile (ukwephulwa kwayo okungeke kuholele ekuphepheni).
    ///
    ///
    /// # Imilayezo yangokwezifiso
    ///
    /// Le macro inefomu lesibili, lapho kunganikezwa khona umyalezo wangokwezifiso we-panic noma ngaphandle kwezimpikiswano zokufomatha.
    /// Bona i [`std::fmt`] ukuthola syntax yaleli fomu.
    /// Izichasiso ezisetshenziswe njengezimpikiswano zefomethi zizohlolwa kuphela uma ukugomela kwehluleka.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // umlayezo we-panic walezi ziqinisekiso inani elihlanganisiwe lenkulumo enikeziwe.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // umsebenzi olula kakhulu
    ///
    /// assert!(some_computation());
    ///
    /// // gomela ngomlayezo wangokwezifiso
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline Assembly.
    ///
    /// Funda i [unstable book] ngokusetshenziswa.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Umhlangano osemgqeni wesitayela se-LLVM.
    ///
    /// Funda i [unstable book] ngokusetshenziswa.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Umhlangano osemugqeni osezingeni lemodyuli.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Ukuphrinta kudlulise i-tokens kokukhipha okujwayelekile.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inika amandla noma ikhubaza ukulandelela ukusebenza okusetshenziselwe ukulungisa iphutha kwamanye ama-macros.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Faka imacro esetshenzisiwe ukufaka ama-derive macros.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Faka imacro esetshenziswe kumsebenzi ukuyiguqula ibe yiyunithi lokuhlola.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Faka imacro esetshenziswe kumsebenzi ukuyiguqula ibe yisilinganiso sokuhlola.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Imininingwane yokuqalisa yama-`#[test]` ne-`#[bench]` macros.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Faka i-macro efakwe ku-static ukuyibhalisa njengokwabiwa komhlaba wonke.
    ///
    /// Bheka futhi i [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Igcina into efakwe kuyo uma indlela edlulisiwe ifinyeleleka, futhi iyisuse ngenye indlela.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Inwebisa zonke izimfanelo ze-`#[cfg]` ne-`#[cfg_attr]` kwisiqeshana sekhodi esisetshenziswe kuso.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Imininingwane yokuqalisa engazinzile yomhlanganisi we `rustc`, ungasebenzisi.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Imininingwane yokuqalisa engazinzile yomhlanganisi we `rustc`, ungasebenzisi.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}