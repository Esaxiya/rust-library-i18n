//! faka i-char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Iphuzu lekhodi elivumeleke kakhulu i-`char` engaba nalo.
    ///
    /// I-`char` iyi-[Unicode Scalar Value], okusho ukuthi iyi-[Code Point], kodwa kuphela ebangeni elithile.
    /// `MAX` iphuzu lekhodi elivumeleke kakhulu elingu-[Unicode Scalar Value] elivumelekile.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` I-() isetshenziswa ku-Unicode ukumela iphutha lokukhipha ikhodi.
    ///
    /// Kungenzeka, ngokwesibonelo, lapho unikeza ama-UTF-8 byte abhalwe kabi ku-[`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Uhlobo lwe [Unicode](http://www.unicode.org/) izingxenye ze-Unicode zezindlela ze `char` ne `str` lususelwe kulo.
    ///
    /// Izinhlobo ezintsha ze-Unicode zikhishwa njalo futhi ngemuva kwalokho zonke izindlela kumtapo wezincwadi ojwayelekile kuya nge-Unicode ziyavuselelwa.
    /// Ngakho-ke ukusebenza kwezinye izindlela ze-`char` ne-`str` nenani lalezi zinguquko eziqhubekayo ngokuhamba kwesikhathi.
    /// Lokhu * akuthathwa njengoshintsho olukhulu.
    ///
    /// Uhlelo lokubala izinombolo luchazwe ku [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Idala i-iterator ngaphezulu kwamaphoyinti wekhodi we-UTF-16 afakiwe ku-`iter`, ibuyisa ama-surrogate angabhadalwa njenge-`Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// I-decoder elahlekile ingatholwa ngokufaka esikhundleni semiphumela ye-`Err` ngomlingiswa ozongena esikhundleni:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Iguqula i-`u32` ibe yi-`char`.
    ///
    /// Qaphela ukuthi wonke ama-``ch` are valid [`u32`] s, futhi angaphonswa koyedwa nge
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Kodwa-ke, ukuhlanekezela akulona iqiniso: akuwona wonke ama-[`u32`] avumelekile angama-`char`s.
    /// `from_u32()` izobuyisa i-`None` uma okokufaka kungelona inani elivumelekile le-`char`.
    ///
    /// Ukuze uthole inguqulo engaphephile yalo msebenzi engakunaki lokhu kuhlolwa, bheka i-[`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Ukubuyisa i-`None` lapho okokufaka akuyona i-`char` evumelekile:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Iguqula i-`u32` ibe yi-`char`, izibe ukufaneleka.
    ///
    /// Qaphela ukuthi wonke ama-``ch` are valid [`u32`] s, futhi angaphonswa koyedwa nge
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Kodwa-ke, ukuhlanekezela akulona iqiniso: akuwona wonke ama-[`u32`] avumelekile angama-`char`s.
    /// `from_u32_unchecked()` bazokushaya indiva lokhu, bese baphonsa ngokungaboni ku-`char`, okungenzeka kudale okungavumelekile.
    ///
    ///
    /// # Safety
    ///
    /// Lo msebenzi awuphephile, ngoba ungakha amanani we-`char` angavumelekile.
    ///
    /// Ukuze uthole inguqulo ephephile yalo msebenzi, bona umsebenzi we-[`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // UKUPHEPHA: inkontileka yezokuphepha kumele igcinwe yilowo ofonayo.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Iguqula idijithi ku-radix enikeziwe ibe yi-`char`.
    ///
    /// I-'radix' lapha kwesinye isikhathi ibizwa nangokuthi yi-'base'.
    /// I-radix emibili ikhombisa inombolo kanambambili, i-radix eyishumi, idesimali, ne-radix eyishumi nesithupha, i-hexadecimal, ukunikeza amanani afanayo.
    ///
    /// Ama-radices angenasisekelo asekelwa.
    ///
    /// `from_digit()` izobuyisa i-`None` uma okokufaka kungesilo idijithi ku-radix enikeziwe.
    ///
    /// # Panics
    ///
    /// I-Panics uma inikezwe i-radix enkulu kuno-36.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Idesimali eli-11 yidijithi eyodwa kusisekelo 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Ukubuyisa i-`None` lapho okokufaka kungesilo idijithi:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Ukudlulisa i-radix enkulu, okubangela i-panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Ihlola ukuthi ngabe i-`char` iyinombolo yini ku-radix enikeziwe.
    ///
    /// I-'radix' lapha kwesinye isikhathi ibizwa nangokuthi yi-'base'.
    /// I-radix emibili ikhombisa inombolo kanambambili, i-radix eyishumi, idesimali, ne-radix eyishumi nesithupha, i-hexadecimal, ukunikeza amanani afanayo.
    ///
    /// Ama-radices angenasisekelo asekelwa.
    ///
    /// Uma kuqhathaniswa ne-[`is_numeric()`], lo msebenzi ubona kuphela izinhlamvu `0-9`, `a-z` ne-`A-Z`.
    ///
    /// 'Digit' ichazwa njengabalingiswa abalandelayo kuphela:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Ukuqonda okuphelele kwe 'digit', bona i [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// I-Panics uma inikezwe i-radix enkulu kuno-36.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Ukudlulisa i-radix enkulu, okubangela i-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Iguqula i-`char` ibe yidijithi ku-radix enikeziwe.
    ///
    /// I-'radix' lapha kwesinye isikhathi ibizwa nangokuthi yi-'base'.
    /// I-radix emibili ikhombisa inombolo kanambambili, i-radix eyishumi, idesimali, ne-radix eyishumi nesithupha, i-hexadecimal, ukunikeza amanani afanayo.
    ///
    /// Ama-radices angenasisekelo asekelwa.
    ///
    /// 'Digit' ichazwa njengabalingiswa abalandelayo kuphela:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Ibuyisa i-`None` uma i-`char` ingabhekiseli kwidijithi ku-radix enikeziwe.
    ///
    /// # Panics
    ///
    /// I-Panics uma inikezwe i-radix enkulu kuno-36.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Ukudlulisa imiphumela engeyona enamanani ukwehluleka:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Ukudlulisa i-radix enkulu, okubangela i-panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ikhodi ihlukaniswe lapha ukwenza ngcono isivinini sokwenza amacala lapho i `radix` ingaguquguquki futhi iyi-10 noma incane
        //
        let val = if likely(radix <= 10) {
            // Uma kungenjalo idijithi, inombolo enkulu kune-radix izokwakhiwa.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Ibuyisa i-iterator ekhipha ukuphunyuka kwe-hexadecimal Unicode kohlamvu njengo `char`s.
    ///
    /// Lokhu kuzophunyuka izinhlamvu nge-syntax ye Rust yefomu `\u{NNNNNN}` lapho i-`NNNNNN` ingukubonakaliswa kwe-hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// Njenge-iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Kokubili kuyalingana no:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Usebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // noma ukufaka u-1 kuqinisekisa ukuthi nge-c==0 ikhodi ihlanganisa ukuthi idijithi eyodwa kufanele iphrintwe futhi (okufanayo) igwema ukugeleza kwe-(31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // inkomba yedijithi ye-hex ebaluleke kakhulu
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Inguqulo enwetshiwe ye `escape_debug` evumela ngokuzithandela ukweqa amakhodi wamakhodi weGrapheme Anwetshiwe.
    /// Lokhu kusivumela ukufometha izinhlamvu ezinjengamamaki angaqhamuki kangcono lapho esekuqaleni kwentambo.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Ibuyisa i-iterator ekhipha ikhodi yoqobo yokuphunyuka yohlamvu njengo `char`s.
    ///
    /// Lokhu kuzobalekela izinhlamvu ezifana nokuqaliswa kwe `Debug` kwe `str` noma `char`.
    ///
    ///
    /// # Examples
    ///
    /// Njenge-iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Kokubili kuyalingana no:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Usebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Ibuyisa i-iterator ekhipha ikhodi yoqobo yokuphunyuka yohlamvu njengo `char`s.
    ///
    /// Okuzenzakalelayo kukhethwa ngokuchema ekukhiqizeni imibhalo esemthethweni ngezilimi ezahlukahlukene, kufaka phakathi i-C++ 11 nezilimi ezifanayo ze-C-zomndeni.
    /// Imithetho ngqo yile:
    ///
    /// * Ithebhu iphunyukile njenge-`\t`.
    /// * Ukubuya kwenqola kweqe njenge `\r`.
    /// * Ulayini womugqa uphunyukile njengo-`\n`.
    /// * Isilinganiso esisodwa siphunyukile njenge-`\'`.
    /// * Ukucaphuna kabili kuphunyukile njenge-`\"`.
    /// * Ukubuyela emuva kweqa njenge-`\\`.
    /// * Noma yimuphi umlingisi kububanzi 'obuphrintekayo be-ASCII' `0x20` .. I-`0x7e` ebandakanya ayibalekwanga.
    /// * Zonke ezinye izinhlamvu zinikezwa ukuphunyuka kwe-hexadecimal Unicode;bona i [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Njenge-iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Kokubili kuyalingana no:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Usebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Ibuyisa inani lamabhayithi le `char` elizodinga uma lifakwe ku-UTF-8.
    ///
    /// Lelo nani lama-byte lihlala liphakathi kuka-1 no-4, lifakiwe.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Uhlobo lwe-`&str` luqinisekisa ukuthi okuqukethwe kwalo kuyi-UTF-8, ngakho-ke singakwazi ukuqhathanisa ubude obuzothatha uma iphuzu ngalinye lekhodi limelwe njenge-`char` vs ku-`&str` uqobo:
    ///
    ///
    /// ```
    /// // njengezinqola
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // womabili angamelwa njengama-byte amathathu
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // njenge-&str, laba bobabili bafakwe ku-UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // siyabona ukuthi bathatha amabhayithi ayisithupha ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... njenge &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Ibuyisa inani lamayunithi ekhodi angama-16-bit le `char` ezowadinga uma ifakwe ku-UTF-16.
    ///
    ///
    /// Bona imibhalo ye-[`len_utf8()`] ukuthola eminye imininingwane yalo mqondo.
    /// Lo msebenzi uyisibuko, kepha nge-UTF-16 esikhundleni se-UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ifaka lo mlingiswa njengo-UTF-8 kusidikibha se-byte esinikeziwe, bese ibuyisa okufakwayo kwesiphawuli okuqukethe uhlamvu olufakiwe.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma ibhafa ayinkulu ngokwanele.
    /// I-buffer yobude besine inkulu ngokwanele ukufaka ikhodi kunoma iyiphi i-`char`.
    ///
    /// # Examples
    ///
    /// Kuzo zombili lezi zibonelo, i-'ß' ithatha ama-byte amabili ukufaka ikhodi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// I-buffer encane kakhulu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // UKUPHEPHA: I-`char` akuyona i-surrogate, ngakho-ke lokhu kuyi-UTF-8 evumelekile.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ifaka lo mlingiswa njengo-UTF-16 kusixhumi se-`u16` esihlinzekiwe, bese ibuyisa okufakwayo kwesiphepha esiqukethe uhlamvu olufakiwe.
    ///
    ///
    /// # Panics
    ///
    /// I-Panics uma ibhafa ayinkulu ngokwanele.
    /// I-buffer yobude 2 inkulu ngokwanele ukufaka ikhodi kunoma iyiphi i-`char`.
    ///
    /// # Examples
    ///
    /// Kuzo zombili lezi zibonelo, i-'𝕊' ithatha ama-`e16 amabili ukufaka ikhodi.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// I-buffer encane kakhulu:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Ibuyisa i `true` uma le `char` inempahla ye `Alphabetic`.
    ///
    /// `Alphabetic` kuchazwe eSahlukweni 4 (Izici Zobuntu) ze-[Unicode Standard] futhi kuchazwe ku-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // uthando luyizinto eziningi, kepha aluhambisani nezinhlamvu zamagama
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Ibuyisa i `true` uma le `char` inempahla ye `Lowercase`.
    ///
    /// `Lowercase` kuchazwe eSahlukweni 4 (Izici Zobuntu) ze-[Unicode Standard] futhi kuchazwe ku-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Izikripthi ezahlukahlukene zamaShayina nezimpawu zokubhala azinacala, ngakho-ke:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Ibuyisa i `true` uma le `char` inempahla ye `Uppercase`.
    ///
    /// `Uppercase` kuchazwe eSahlukweni 4 (Izici Zobuntu) ze-[Unicode Standard] futhi kuchazwe ku-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Izikripthi ezahlukahlukene zamaShayina nezimpawu zokubhala azinacala, ngakho-ke:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Ibuyisa i `true` uma le `char` inempahla ye `White_Space`.
    ///
    /// `White_Space` icacisiwe ku-[Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // indawo engaphuli
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Ibuyisa i-`true` uma le `char` yanelisa i-[`is_alphabetic()`] noma i-[`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Ibuyisa i-`true` uma le `char` inesigaba esijwayelekile samakhodi wokulawula.
    ///
    /// Amakhodi wokulawula (amaphoyinti ekhodi anesigaba esijwayelekile se-`Cc`) achazwe eSahlukweni 4 (Izici Zobuntu) ze-[Unicode Standard] futhi acaciswe ku-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Ibuyisa i `true` uma le `char` inempahla ye `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ichazwe ku-[Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] futhi icacisiwe ku-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Ibuyisa i-`true` uma ngabe le `char` inesinye sezigaba ezijwayelekile zezinombolo.
    ///
    /// Izigaba ezijwayelekile zezinombolo (i-`Nd` yamadijithi wedesimali, i-`Nl` yezinhlamvu ezinjengezinhlamvu, ne-`No` yezinye izinhlamvu zezinombolo) zicacisiwe ku-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Ibuyisa i-iterator ekhipha imephu engaphansi yale `char` njengeyodwa noma ngaphezulu
    /// `char`s.
    ///
    /// Uma le `char` ingenamephu engaphansi, i-iterator ikhiqiza i-`char` efanayo.
    ///
    /// Uma le `char` inemephu engaphansi kokukodwa enikezwe i [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ikhiqiza leyo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Uma ngabe le `char` idinga ukucatshangelwa okukhethekile (isb. Ama-``ch`` amaningi) iterator ikhiqiza `char` (s) enikezwe yi-[`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Lo msebenzi wenza imephu engenamibandela ngaphandle kokuthungwa.Lokho wukuthi, ukuguqulwa kuzimele kokuqukethwe nolimi.
    ///
    /// Ku-[Unicode Standard], Isahluko 4 (Izici Zobuntu) sixoxa ngamamephu wamacala ngokujwayelekile futhi Isahluko 3 (Conformance) sixoxa nge-algorithm ezenzakalelayo yokuguqulwa kwamacala.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Njenge-iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Kokubili kuyalingana no:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Usebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Kwesinye isikhathi umphumela uba ngaphezu kwenhlamvu eyodwa:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Izinhlamvu ezingenazo zombili izinhlamvu zosonhlamvukazi nezinhlamvu ezincane ziguqula zona uqobo.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Ibuyisa i-iterator ekhipha imephu engaphezulu yale `char` njengeyodwa noma ngaphezulu
    /// `char`s.
    ///
    /// Uma le `char` ingenayo imephu engusonhlamvukazi, i-iterator ikhiqiza i-`char` efanayo.
    ///
    /// Uma le `char` inemephu yosayizi ngamunye iye enikwe yi [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator ikhiqiza leyo `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Uma ngabe le `char` idinga ukucatshangelwa okukhethekile (isb. Ama-``ch`` amaningi) iterator ikhiqiza `char` (s) enikezwe yi-[`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Lo msebenzi wenza imephu engenamibandela ngaphandle kokuthungwa.Lokho wukuthi, ukuguqulwa kuzimele kokuqukethwe nolimi.
    ///
    /// Ku-[Unicode Standard], Isahluko 4 (Izici Zobuntu) sixoxa ngamamephu wamacala ngokujwayelekile futhi Isahluko 3 (Conformance) sixoxa nge-algorithm ezenzakalelayo yokuguqulwa kwamacala.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Njenge-iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Usebenzisa i `println!` ngqo:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Kokubili kuyalingana no:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Usebenzisa i `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Kwesinye isikhathi umphumela uba ngaphezu kwenhlamvu eyodwa:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Izinhlamvu ezingenazo zombili izinhlamvu zosonhlamvukazi nezinhlamvu ezincane ziguqula zona uqobo.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Inothi kusifunda
    ///
    /// NgesiTurkey, okulingana ne 'i' ngesiLatin kunezinhlobo ezinhlanu esikhundleni sezimbili:
    ///
    /// * 'Dotless': I/ı, kwesinye isikhathi kuyabhalwa ï
    /// * 'Dotted': İ/i
    ///
    /// Qaphela ukuthi usonhlamvukazi onamachashazi we 'i' uyafana nesiLatini.Ngakho-ke:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Inani le-`upper_i` lapha lithembele olimini lombhalo: uma siku-`en-US`, kufanele kube yi-`"I"`, kepha uma siku-`tr_TR`, kufanele kube yi-`"İ"`.
    /// `to_uppercase()` akubheki lokhu, ngakho-ke:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ibamba ngezilimi zonke.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Ihlola ukuthi ingabe inani lingaphakathi kwebanga le-ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Yenza ikhophi yenani elilingana ne-ASCII ephezulu.
    ///
    /// Izinhlamvu ze-ASCII 'a' kuya ku-'z' zimakwe ku-'A' kuye ku-'Z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukuze usebenzise inani elikhulu endaweni, sebenzisa i-[`make_ascii_uppercase()`].
    ///
    /// Ukuze usebenzise izinhlamvu ezinkulu ze-ASCII ngokungeziwe kuzinhlamvu ezingezona eze-ASCII, sebenzisa i-[`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Yenza ikhophi yenani elilinganayo le-ASCII.
    ///
    /// Izinhlamvu ze-ASCII 'A' kuya ku-'Z' zimakwe ku-'a' kuye ku-'z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukwehlisa inani endaweni, sebenzisa i-[`make_ascii_lowercase()`].
    ///
    /// Ukwehlisa izinhlamvu ze-ASCII ngaphezu kwezinhlamvu ezingezona eze-ASCII, sebenzisa i [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Ihlola ukuthi amanani amabili afana nomdlalo we-ASCII ongazweli.
    ///
    /// Ilingana ne-`to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Iguqula lolu hlobo luye endaweni yalo elilinganayo le-ASCII.
    ///
    /// Izinhlamvu ze-ASCII 'a' kuya ku-'z' zimakwe ku-'A' kuye ku-'Z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukubuyisa inani elisha eliphezulu ngaphandle kokushintsha elikhona, sebenzisa i-[`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Iguqula lolu hlobo luye endaweni yalo elilinganayo le-ASCII.
    ///
    /// Izinhlamvu ze-ASCII 'A' kuya ku-'Z' zimakwe ku-'a' kuye ku-'z', kepha izinhlamvu ezingezona eze-ASCII azishintshiwe.
    ///
    /// Ukubuyisa inani elisha elincishisiwe ngaphandle kokushintsha elikhona, sebenzisa i-[`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Ihlola ukuthi ingabe inani liyinhlamvu yohlamvu lwe-ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', noma
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Ihlola ukuthi inani liyinhlamvu ephezulu ye-ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Ihlola ukuthi ingabe inani liyizinhlamvu ezincane ze-ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Ihlola ukuthi ingabe inani liwuhlamvu lwe-ASCII alphanumeric:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', noma
    /// - U + 0061 'a' ..=U + 007A 'z', noma
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Ihlola ukuthi ingabe inani liyidijithi ledesimali le-ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Ihlola ukuthi ingabe inani liyi-ASCII hexadecimal digit:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', noma
    /// - U + 0041 'A' ..=U + 0046 'F', noma
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Ihlola ukuthi ingabe inani liyinhlamvu yezimpawu zokubhala ye-ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, noma
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, noma
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, noma
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Ihlola ukuthi ingabe inani liyinhlamvu yesithombe ye-ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Ihlola ukuthi ingabe inani liyinhlamvu yomhlophe ye-ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, noma U + 000D CARRIAGE RETURN.
    ///
    /// I-Rust isebenzisa i-[definition of ASCII whitespace][infra-aw] ye-WhatWG Infra Standard.Kunezinye izincazelo eziningi ezisetshenziswa kabanzi.
    /// Isibonelo, i-[the POSIX locale][pct] ifaka phakathi u-U + 000B VERTICAL TAB kanye nazo zonke izinhlamvu ezingenhla, kepha-kuvela kokucacisiwe okufanayo- [umthetho omisiwe we-"field splitting" ku-Bourne shell][bfs] ubheka *kuphela* ISIKHALA, IHORIZONTAL TAB, kanye I-LINE FEED njengendawo emhlophe.
    ///
    ///
    /// Uma ubhala uhlelo oluzocubungula ifomethi yefayela ekhona, hlola ukuthi iyini incazelo yaleyo fomethi ye-whitespace ngaphambi kokusebenzisa lo msebenzi.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Ihlola ukuthi ingabe inani liyinhlamvu yokulawula ye-ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, noma U + 007F DELETE.
    /// Qaphela ukuthi izinhlamvu eziningi zabamhlophe be-ASCII izinhlamvu zokulawula, kepha i-SPACE ayiyona.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Ifaka inani elingu-u32 eliluhlaza njenge-UTF-8 kusidluliseli se-byte esinikeziwe, bese ibuyisa okufakwayo kwebhafa okuqukethe uhlamvu olufakiwe.
///
///
/// Ngokungafani ne-`char::encode_utf8`, le ndlela ibuye iphathe ama-codepoints kububanzi besivumelwano.
/// (Ukwakha i-`char` kububanzi besivumelwano yi-UB.) Umphumela uba yi-[generalized UTF-8] evumelekile kepha ayivumelekile i-UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// I-Panics uma ibhafa ayinkulu ngokwanele.
/// I-buffer yobude besine inkulu ngokwanele ukufaka ikhodi kunoma iyiphi i-`char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Imisa inani eliluhlaza le-u32 njenge-UTF-16 kusixhumi se-`u16` esinikeziwe, bese ibuyisa okufakwayo kwebhafa okuqukethe uhlamvu olufakiwe.
///
///
/// Ngokungafani ne-`char::encode_utf16`, le ndlela ibuye iphathe ama-codepoints kububanzi besivumelwano.
/// (Ukwakha i-`char` ebangeni lobunikazi yi-UB.)
///
/// # Panics
///
/// I-Panics uma ibhafa ayinkulu ngokwanele.
/// I-buffer yobude 2 inkulu ngokwanele ukufaka ikhodi kunoma iyiphi i-`char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // UKUPHEPHA: ingalo ngayinye ihlola ukuthi kukhona yini izingcezu ezanele zokubhalela
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // I-BMP iyawela
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Izindiza ezengeziwe zigqekeza ama-surrogate.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}