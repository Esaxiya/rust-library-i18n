//! I-libcore prelude
//!
//! Le mojule yenzelwe abasebenzisi be-libcore abangaxhumanisi ne-libstd.
//! Le mojula ingeniswa ngokuzenzakalela lapho i `#![no_std]` isetshenziswa ngendlela efanayo ne prelude yelabhulali ejwayelekile.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Uhlobo lwango-2015 lwe-core prelude.
///
/// Bona i [module-level documentation](self) ukuthola okuningi.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Uhlobo lwango-2018 lwe-core prelude.
///
/// Bona i [module-level documentation](self) ukuthola okuningi.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Uhlobo lwango-2021 lwe-core prelude.
///
/// Bona i [module-level documentation](self) ukuthola okuningi.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Faka izinto eziningi.
}