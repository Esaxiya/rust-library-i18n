//! Le mojula isebenzisa i `Any` trait, enika amandla ukuthayipha okunamandla kwanoma yiluphi uhlobo lwe `'static` ngokubonisa isikhathi sokusebenza.
//!
//! `Any` uqobo ingasetshenziselwa ukuthola i-`TypeId`, futhi inezici eziningi lapho isetshenziswa njengezinto ze-trait.
//! Njengo-`&dyn Any` (into ebolekwe i trait), inezindlela ze-`is` ne-`downcast_ref`, ukuhlola ukuthi inani eliqukethwe elolohlobo olunikeziwe, nokuthola ireferensi kunani langaphakathi njengohlobo.
//! Njengo-`&mut dyn Any`, kukhona futhi indlela ye-`downcast_mut`, yokuthola ireferensi engaguquguquki kunani langaphakathi.
//! `Box<dyn Any>` ingeza indlela ye `downcast`, ezama ukuguqulela ku-`Box<T>`.
//! Bona imibhalo ye [`Box`] ngemininingwane ephelele.
//!
//! Qaphela ukuthi i-`&dyn Any` ikhawulelwe ekuhloleni ukuthi ingabe inani lolohlobo lukakhonkolo olucacisiwe, futhi alikwazi ukusetshenziselwa ukuhlola ukuthi ngabe uhlobo lusebenzisa i-trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Izikhombisi ze-Smart ne-`dyn Any`
//!
//! Into eyodwa yokuziphatha okufanele uyikhumbule lapho usebenzisa i-`Any` njengento ye trait, ikakhulukazi ngezinhlobo ezinjenge-`Box<dyn Any>` noma i-`Arc<dyn Any>`, ukuthi ukumane ubize i-`.type_id()` ngenani kuzokhiqiza i-`TypeId` yesitsha *, hhayi into eyisisekelo ye trait.
//!
//! Lokhu kungagwenywa ngokuguqula i-smart pointer ibe yi-`&dyn Any` esikhundleni salokho, okuzobuyisa i-`TypeId` yento.
//! Ngokwesibonelo:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Kungenzeka ukuthi ufuna lokhu:
//! let actual_id = (&*boxed).type_id();
//! // ... kunalokhu:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Cabanga ngesimo lapho sifuna ukukhipha inani elidluliselwe emsebenzini.
//! Siyalazi inani esisebenza kulo ukusebenzisa i-Debug, kepha asazi uhlobo lwalo lukakhonkolo.Sifuna ukunikeza ukwelashwa okukhethekile ezinhlotsheni ezithile: kulokhu ukuphrinta ubude bamanani we-String ngaphambi kwenani lawo.
//! Asilwazi uhlobo lukakhonkolo wenani lethu ngesikhathi esihlanganiswayo, ngakho-ke kudingeka sisebenzise ukuboniswa kwesikhathi sokusebenza.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Umsebenzi weLogger wanoma yiluphi uhlobo osebenzisa i-Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Zama ukuguqula inani lethu libe yi-`String`.
//!     // Uma kuphumelele, sifuna ukukhipha ubude be-String` kanye nenani layo.
//!     // Uma kungenjalo, luhlobo oluhlukile: vele uliphrinte ngaphandle kokuhlobisa.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Lo msebenzi ufuna ukukhipha ipharamitha yawo ngaphambi kokwenza umsebenzi ngawo.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... yenza omunye umsebenzi
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Noma iyiphi i-trait
///////////////////////////////////////////////////////////////////////////////

/// I-trait yokulingisa ukuthayipha okunamandla.
///
/// Izinhlobo eziningi zisebenzisa i-`Any`.Kodwa-ke, noma yiluphi uhlobo oluqukethe ireferensi ye-non-``static` alwenzi.
/// Bona i [module-level documentation][mod] ukuthola eminye imininingwane.
///
/// [mod]: crate::any
// Le trait ayiphephile, kepha sithembele kokucacile komsebenzi we-sole impl's `type_id` ngekhodi engaphephile (isb., `downcast`).Imvamisa lokho kungaba yinkinga, kepha ngoba ukuphela kwe-`Any` ukuqaliswa kwengubo, ayikho enye ikhodi engasebenzisa i-`Any`.
//
// Singaqiniseka ukuthi le trait ingaphephi-ngeke ibangele ukwehlukana, ngoba silawula konke ukuqaliswa-kepha sikhetha ukungakwenzi lokho njengoba kungadingekile ngempela futhi kungadida abasebenzisi ngokuhlukaniswa kwe-traits nezindlela ezingaphephile (okungukuthi, I `type_id` isazophepha ukuyishayela, kepha kungenzeka ukuthi sifuna ukukhombisa kanjalo kumadokhumenti).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ithola i `TypeId` ye `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Izindlela zesandiso sanoma yiziphi izinto ze-trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Qinisekisa ukuthi umphumela wesb., Ukujoyina intambo kungaphrintwa ngakho-ke kusetshenziswe i-`unwrap`.
// Ekugcineni kungenzeka ukuthi akusadingeki uma ukuthunyelwa kusebenza nge-upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Ibuyisa i-`true` uma uhlobo lwebhokisi lufana ne-`T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Thola i-`TypeId` yohlobo lo msebenzi olwenziwe ngalo.
        let t = TypeId::of::<T>();

        // Thola i-`TypeId` yohlobo entweni ye trait (`self`).
        let concrete = self.type_id();

        // Qhathanisa ama-TypeId`s womabili ngokulingana.
        t == concrete
    }

    /// Ibuyisa ireferensi ethile kunani elifakwe ebhokisini uma ingelohlobo `T`, noma i-`None` uma kungesilo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // UKUPHEPHA: vele ubheke ukuthi ngabe sikhomba uhlobo olufanele, futhi singathembela kuye
            // lokho kuhlola ukuphepha kwememori ngoba sisebenzise Noma yiziphi izinhlobo zonke;awekho amanye ama-impls angaba khona njengoba ezophikisana ne-impl yethu.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Ibuyisa ireferensi ethile engaguquguqukayo kunani lebhokisi uma lolohlobo `T`, noma i-`None` uma kungenjalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // UKUPHEPHA: vele ubheke ukuthi ngabe sikhomba uhlobo olufanele, futhi singathembela kuye
            // lokho kuhlola ukuphepha kwememori ngoba sisebenzise Noma yiziphi izinhlobo zonke;awekho amanye ama-impls angaba khona njengoba ezophikisana ne-impl yethu.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Dlulisela phambili endleleni echazwe kuhlobo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// I-TypeID nezindlela zayo
///////////////////////////////////////////////////////////////////////////////

/// I-`TypeId` imele isikhombi esihlukile somhlaba wonke sohlobo.
///
/// I-`TypeId` ngayinye iyinto evulekile engavumeli ukuhlolwa kokungaphakathi kepha evumela ukusebenza okuyisisekelo njengokuhlanganisa, ukuqhathanisa, ukuphrinta, nokubonisa.
///
///
/// I-`TypeId` okwamanje itholakala kuphela ezinhlotsheni ezinikeza i-`'static`, kepha lo mkhawulo ungasuswa ku-future.
///
/// Ngenkathi i-`TypeId` isebenzisa i-`Hash`, i-`PartialOrd`, ne-`Ord`, kubalulekile ukuthi wazi ukuthi ama-hashes noku-oda kuzohluka phakathi kokukhishwa kwe-Rust.
/// Qaphela ukuthembela kuzo ngaphakathi kwekhodi yakho!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Ibuyisa i-`TypeId` yohlobo lo msebenzi ojwayelekile oqiniswe ngalo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Ibuyisa igama lohlobo njengocezu lwentambo.
///
/// # Note
///
/// Lokhu kwenzelwe ukusetshenziswa kokuxilonga.
/// Okuqukethwe ngqo nefomethi yochungechunge olubuyisiwe ayicacisiwe, ngaphandle kokuba yincazelo yomzamo omuhle wohlobo.
/// Isibonelo, phakathi kwezintambo ezingabuyiselwa i-`type_name::<Option<String>>()` kukhona i-`"Option<String>"` ne-`"std::option::Option<std::string::String>"`.
///
///
/// Iyunithi yezinhlamvu ebuyisiwe akumele ibhekwe njengesikhombi esihlukile sohlobo njengoba izinhlobo eziningi zingahle zibalaze igama lohlobo olufanayo.
/// Ngokufanayo, asikho isiqinisekiso sokuthi zonke izingxenye zohlobo zizovela entanjeni ebuyisiwe: isibonelo, izichasisi zesikhathi sokuphila okwamanje azifakiwe.
/// Ngaphezu kwalokho, okukhiphayo kungashintsha phakathi kwezinguqulo zomhlanganisi.
///
/// Ukuqaliswa kwamanje kusebenzisa ingqalasizinda efanayo ne-compiler diagnostics ne-debuginfo, kepha lokhu akuqinisekisiwe.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Ibuyisa igama lohlobo lwenani elikhonjwe njengocezu lwentambo.
/// Lokhu kuyefana ne `type_name::<T>()`, kepha kungasetshenziswa lapho uhlobo lokuguquguqukayo lungatholakali kalula.
///
/// # Note
///
/// Lokhu kwenzelwe ukusetshenziswa kokuxilonga.Okuqukethwe ngqo nefomethi yochungechunge ayicacisiwe, ngaphandle kokuba yincazelo yomzamo omuhle wohlobo.
/// Isibonelo, i-`type_name_of_val::<Option<String>>(None)` ingabuyisa i-`"Option<String>"` noma i-`"std::option::Option<std::string::String>"`, kepha hhayi i-`"foobar"`.
///
/// Ngaphezu kwalokho, okukhiphayo kungashintsha phakathi kwezinguqulo zomhlanganisi.
///
/// Lo msebenzi awuzixazululi izinto ze-trait, okusho ukuthi i-`type_name_of_val(&7u32 as &dyn Debug)` ingabuyisa i-`"dyn Debug"`, kepha hhayi i-`"u32"`.
///
/// Igama lohlobo akufanele lithathwe njengesikhombi esihlukile sohlobo;
/// izinhlobo eziningi zingabelana ngegama lohlobo olufanayo.
///
/// Ukuqaliswa kwamanje kusebenzisa ingqalasizinda efanayo ne-compiler diagnostics ne-debuginfo, kepha lokhu akuqinisekisiwe.
///
/// # Examples
///
/// Iphrinta izinhlobo eziphelele zenombolo nezintantayo.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}