//! I `Clone` trait yezinhlobo ezingakwazi 'ukukopishwa ngokuphelele'.
//!
//! Ku-Rust, ezinye izinhlobo ezilula yi-"implicitly copyable" futhi uma uzabela noma uziphasisa njengezimpikiswano, umamukeli uzothola ikhophi, ashiye inani langempela lisendaweni.
//! Lezi zinhlobo azidingi ukwabiwa ukuze zikopishwe futhi azinabaqedeli (okungukuthi, aziqukethe amabhokisi angabanikazi noma zisebenzisa i-[`Drop`]), ngakho-ke umhlanganisi uzithatha njengezishibhile futhi ziphephile ukuzikopisha.
//!
//! Kwezinye izinhlobo amakhophi kufanele enziwe ngokusobala, ngokwenziwa komhlangano i-[`Clone`] trait nokubiza indlela ye [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Isibonelo sokusetshenziswa esiyisisekelo:
//!
//! ```
//! let s = String::new(); // Uhlobo lwentambo lusebenzisa i-Clone
//! let copy = s.clone(); // ukuze sikwazi ukuyihlanganisa
//! ```
//!
//! Ukuze usebenzise i-Clone trait kalula, ungasebenzisa futhi i-`#[derive(Clone)]`.Isibonelo:
//!
//! ```
//! #[derive(Clone)] // sengeza i-Clone trait ku-Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // futhi manje sesingayihlanganisa!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// I-trait ejwayelekile yekhono lokuphinda ngokusobala into.
///
/// Kwehluka ku-[`Copy`] kuleyo [`Copy`] kucacile futhi kushibhile ngokweqile, kuyilapho i-`Clone` ihlala icacile futhi ingahle noma ingabizi.
/// Ukuze uphoqelele lezi zici, i-Rust ayikuvumeli ukuthi uphinde usebenzise i-[`Copy`], kepha ungaphinda ufake i-`Clone` bese usebenzisa ikhodi engqubuzanayo.
///
/// Njengoba i-`Clone` ijwayelekile kakhulu kune-[`Copy`], ungenza ngokuzenzakalela noma yini i-[`Copy`] ibe yi-`Clone`.
///
/// ## Derivable
///
/// Le trait ingasetshenziswa ne `#[derive]` uma yonke imikhakha iyi-`Clone`.Ukuqaliswa kwe-`derive`d kwe [`Clone`] kubiza i-[`clone`] kunkambu ngayinye.
///
/// [`clone`]: Clone::clone
///
/// Ngokwesakhiwo esijwayelekile, i-`#[derive]` isebenzisa i-`Clone` ngombandela ngokungeza i-`Clone` eboshiwe kumapharamitha ejwayelekile.
///
/// ```
/// // `derive` isebenzisa i-Clone for Reading<T>lapho uT Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ngingayisebenzisa kanjani i `Clone`?
///
/// Izinhlobo ezi-[`Copy`] kufanele zisebenzise kancane i-`Clone`.Ngokuhlelekile ngokwengeziwe:
/// uma i-`T: Copy`, i-`x: T`, ne-`y: &T`, khona-ke i-`let x = y.clone();` ilingana ne-`let x = *y;`.
/// Ukwenziwa mathupha kufanele kuqaphele ukuxhasa lokhu okungahleliwe;noma kunjalo, ikhodi engaphephile akumele ithembele kuyo ukuqinisekisa ukuphepha kwememori.
///
/// Isibonelo ukwakhiwa okujwayelekile okuphethe isikhombi somsebenzi.Kulokhu, ukusetshenziswa kwe-`Clone` akukwazi ukuthi `derive`d, kepha kungenziwa njengo:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Abaqalisi abengeziwe
///
/// Ngaphezu kwe-[implementors listed below][impls], izinhlobo ezilandelayo nazo zisebenzisa i-`Clone`:
///
/// * Izinhlobo zezinto zomsebenzi (okungukuthi, izinhlobo ezihlukile ezichazwe ngomsebenzi ngamunye)
/// * Izinhlobo zesikhombi somsebenzi (isb. `fn() -> i32`)
/// * Izinhlobo ze-Array, zawo wonke amasayizi, uma uhlobo lwento nalo lusebenzisa i-`Clone` (isb., `[i32; 123456]`)
/// * Izinhlobo zeTuple, uma into ngayinye nayo isebenzisa i `Clone` (isb., `()`, `(i32, bool)`)
/// * Izinhlobo zokuvalwa, uma zingabambi inani emvelweni noma uma wonke amanani anjalo atholakele esebenzisa i `Clone` uqobo.
///   Qaphela ukuthi okuguquguqukayo okufakwe kusethenjwa okwabiwe ngaso sonke isikhathi kusebenzisa i-`Clone` (noma ngabe okuqondiswayo kungakwenzi), kuyilapho okuguquguqukayo okuthathwe yisethenjwa esiguquguqukayo kungasebenzisi i `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Ibuyisa ikhophi yenani.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str isebenzisa uClone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Yenza isabelo sokukopisha kusuka ku `source`.
    ///
    /// `a.clone_from(&b)` ilingana ne-`a = b.clone()` ekusebenzeni, kepha ingabhalwa ngaphezulu ukuze isetshenziswe kabusha izinsiza ze-`a` ukugwema ukwabiwa okungadingekile.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// IDerive macro edala ukufakwa kwe trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): lezi zinhlaka zisetshenziswa kuphela ngu-#[derive] ukufakazela ukuthi zonke izingxenye zohlobo zisebenzisa i-Clone noma i-Copy.
//
//
// Lezi zakhiwo akufanele zivele kwikhodi yomsebenzisi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Ukuqaliswa kwe `Clone` yezinhlobo zasendulo.
///
/// Ukusebenza okungeke kuchazwe ku-Rust kwenziwa ku-`traits::SelectionContext::copy_clone_conditions()` ku-`rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Izinkomba ezabiwe zingakhiwa, kepha izinkomba eziguqukayo *azikwazi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Izinkomba ezabiwe zingakhiwa, kepha izinkomba eziguqukayo *azikwazi*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}