use crate::iter::{FusedIterator, TrustedLen};

/// Kwakha i-iterator entsha ephinda izinto zohlobo `A` ngokungapheli ngokusebenzisa ukuvalwa okunikeziwe, okuphindayo, `F: FnMut() -> A`.
///
/// Umsebenzi we `repeat_with()` ubiza ophindayo kaninginingi.
///
/// Ama-iterator angenasiphelo afana ne-`repeat_with()` ajwayele ukusetshenziswa ngama-adapters afana ne [`Iterator::take()`], ukuze abenze baphele.
///
/// Uma uhlobo lwento ye-iterator oludingayo lusebenzisa i-[`Clone`], futhi KULUNGILE ukugcina into yomthombo kwimemori, kufanele usebenzise umsebenzi we-[`repeat()`].
///
///
/// I-iterator ekhiqizwe yi-`repeat_with()` akuyona i-[`DoubleEndedIterator`].
/// Uma udinga i-`repeat_with()` ukubuyisa i-[`DoubleEndedIterator`], sicela uvule inkinga ye-GitHub echaza icala lakho lokusebenzisa.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::iter;
///
/// // ake sicabange ukuthi sinenani elithile lohlobo olungeyona i `Clone` noma elingafuni ukuba nalo kwimemori okwamanje ngoba kuyabiza:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // inani elithile kuze kube phakade:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Kusetshenziswa ukuguquka kwesimo nokuhamba kuphela:
///
/// ```rust
/// use std::iter;
///
/// // Kusukela ku-zeroth kuya emandleni wesithathu amabili:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... futhi manje sesiqedile
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// I-iterator ephinda izinto zohlobo `A` ngokungapheli ngokusebenzisa ukuvalwa okunikeziwe i `F: FnMut() -> A`.
///
///
/// Le `struct` idalwe umsebenzi we-[`repeat_with()`].
/// Bona imibhalo yayo ukuthola okuningi.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}