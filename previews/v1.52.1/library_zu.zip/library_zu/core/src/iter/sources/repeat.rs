use crate::iter::{FusedIterator, TrustedLen};

/// Kwakha i-iterator entsha ephinda into eyodwa ngokungapheli.
///
/// Umsebenzi we-`repeat()` uphinda inani elilodwa kaninginingi.
///
/// Ama-iterator angenasiphelo afana ne-`repeat()` ajwayele ukusetshenziswa ngama-adapters afana ne [`Iterator::take()`], ukuze abenze baphele.
///
/// Uma uhlobo lwento ye-iterator oyidingayo ingasebenzisi i-`Clone`, noma uma ungafuni ukugcina into ephindaphindwayo kwimemori, esikhundleni salokho ungasebenzisa umsebenzi we-[`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::iter;
///
/// // inombolo yesine 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, namanje bane
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Ukuhamba kuphela nge [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // leso sibonelo sokugcina besiningi kakhulu kane.Masibe nezine kuphela.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... futhi manje sesiqedile
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// I-iterator ephinda into ngokungapheli.
///
/// Le `struct` idalwe umsebenzi we-[`repeat()`].Bona imibhalo yayo ukuthola okuningi.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}