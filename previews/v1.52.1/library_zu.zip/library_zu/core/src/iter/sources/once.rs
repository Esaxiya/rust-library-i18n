use crate::iter::{FusedIterator, TrustedLen};

/// Kwakha i-iterator ekhipha into kanye kanye.
///
/// Lokhu kuvame ukusetshenziselwa ukuguqulela inani elilodwa ku-[`chain()`] yezinye izinhlobo ze-iteration.
/// Mhlawumbe une-iterator ehlanganisa cishe yonke into, kepha udinga elinye icala elikhethekile.
/// Mhlawumbe unomsebenzi osebenza kuma-iterator, kepha udinga kuphela ukucubungula inani elilodwa.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::iter;
///
/// // eyodwa inombolo eyedwa
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // eyodwa kuphela, yilokho kuphela esikutholayo
/// assert_eq!(None, one.next());
/// ```
///
/// Ukuhlanganiswa ngamaketanga ndawonye nenye iterator.
/// Masithi sifuna ukukweqa ngaphezulu kwefayela ngalinye lesikhombi se-`.foo`, kepha futhi nefayela lokumisa,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // sidinga ukuguqula sisuka ku-iterator ye-DirEntry-s siye ku-iterator yePathBufs, ngakho-ke sisebenzisa imephu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // manje, iterator yethu ifayela lethu lokumisa nje
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ketani ama-iterator amabili ndawonye abe iterator eyodwa enkulu
/// let files = dirs.chain(config);
///
/// // lokhu kuzosinika wonke amafayela aku-.foo kanye ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// I-iterator ekhipha into kanye kanye.
///
/// Le `struct` idalwe umsebenzi we-[`once()`].Bona imibhalo yayo ukuthola okuningi.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}