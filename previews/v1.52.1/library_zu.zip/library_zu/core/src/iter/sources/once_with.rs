use crate::iter::{FusedIterator, TrustedLen};

/// Kwakha i-iterator ekhiqiza ngobuvila inani kanye kanye ngokucela ukuvalwa okunikeziwe.
///
/// Lokhu kuvame ukusetshenziselwa ukuguquguqula i-value value generator eyodwa ibe yi-[`chain()`] yezinye izinhlobo ze-iteration.
/// Mhlawumbe une-iterator ehlanganisa cishe yonke into, kepha udinga elinye icala elikhethekile.
/// Mhlawumbe unomsebenzi osebenza kuma-iterator, kepha udinga kuphela ukucubungula inani elilodwa.
///
/// Ngokungafani ne-[`once()`], lo msebenzi uzokhiqiza ngobuvila inani eliceliwe.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// use std::iter;
///
/// // eyodwa inombolo eyedwa
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // eyodwa kuphela, yilokho kuphela esikutholayo
/// assert_eq!(None, one.next());
/// ```
///
/// Ukuhlanganiswa ngamaketanga ndawonye nenye iterator.
/// Masithi sifuna ukukweqa ngaphezulu kwefayela ngalinye lesikhombi se-`.foo`, kepha futhi nefayela lokumisa,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // sidinga ukuguqula sisuka ku-iterator ye-DirEntry-s siye ku-iterator yePathBufs, ngakho-ke sisebenzisa imephu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // manje, iterator yethu ifayela lethu lokumisa nje
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ketani ama-iterator amabili ndawonye abe iterator eyodwa enkulu
/// let files = dirs.chain(config);
///
/// // lokhu kuzosinika wonke amafayela aku-.foo kanye ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// I-iterator ekhipha into eyodwa yohlobo `A` ngokusebenzisa ukuvalwa okunikeziwe i `F: FnOnce() -> A`.
///
///
/// Le `struct` idalwe umsebenzi we-[`once_with()`].
/// Bona imibhalo yayo ukuthola okuningi.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}