/// I-iterator ebazi ubude bayo ngqo.
///
/// Abaningi [`Iterator`] abazi ukuthi bazophinda kangaki, kepha abanye bayazi.
/// Uma i-iterator yazi ukuthi ingakhula kangaki, ukuhlinzeka ukufinyelela kulolo lwazi kungasiza.
/// Isibonelo, uma ufuna ukubuyela emuva emuva, isiqalo esihle ukwazi ukuthi ukuphela kukuphi.
///
/// Lapho usebenzisa i-`ExactSizeIterator`, kufanele futhi usebenzise i-[`Iterator`].
/// Lapho wenza kanjalo, ukusetshenziswa kwe-[`Iterator::size_hint`]*kufanele* kubuyise usayizi ngqo we-iterator.
///
/// Indlela ye [`len`] inokuqaliswa okuzenzakalelayo, ngakho-ke imvamisa akufanele uyisebenzise.
/// Kodwa-ke, ungakwazi ukuhlinzeka ukuqaliswa kokusebenza okwedlula okwakhona, ngakho-ke ukukubeka ngaphezulu kulokhu kunengqondo.
///
///
/// Qaphela ukuthi le trait iyi-trait ephephile futhi ngenxa yalokho ayinayo *futhi* ayikwazi * ukuqinisekisa ukuthi ubude obubuyisiwe bulungile.
/// Lokhu kusho ukuthi ikhodi ye-`unsafe`**akumele** ithembele ekulungeni kwe [`Iterator::size_hint`].
/// I-[`TrustedLen`](super::marker::TrustedLen) trait engazinzile futhi engaphephile inika lesi siqinisekiso esengeziwe.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Ukusetshenziswa okuyisisekelo:
///
/// ```
/// // ibanga elilinganiselwe lazi kahle kamhlophe ukuthi lizokwenyuka kangaki
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Ku-[module-level docs], sisebenzise i-[`Iterator`], `Counter`.
/// Masisebenzise i-`ExactSizeIterator` nayo:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Singabala kalula inani elisele lama-iterations.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Futhi manje sesingayisebenzisa!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Ibuyisa ubude obuqondile be-iterator.
    ///
    /// Ukuqaliswa kuqinisekisa ukuthi i-iterator izobuya ncamashi izikhathi eziyi-`len()` ngenani le-[`Some(T)`], ngaphambi kokubuyisa i-[`None`].
    ///
    /// Le ndlela inokuqaliswa okuzenzakalelayo, ngakho-ke imvamisa akufanele uyisebenzise ngqo.
    /// Kodwa-ke, uma unganikezela ngokusetshenziswa okuthe xaxa, ungakwenza lokho.
    /// Bona amadokhumenti e-[trait-level] njengesibonelo.
    ///
    /// Lo msebenzi uneziqinisekiso zokuphepha ezifanayo nomsebenzi we [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // ibanga elilinganiselwe lazi kahle kamhlophe ukuthi lizokwenyuka kangaki
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Lokhu kugomela kuvikela ngokweqile, kepha kubheka okungahleliwe
        // kuqinisekiswe yi-trait.
        // Ukube le trait ibiyi-rust-yangaphakathi, besingasebenzisa i-debug_assert !;fakazela_eq!izobheka konke ukusetshenziswa komsebenzisi kwe-Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Ibuyisa i-`true` uma i-iterator ingenalutho.
    ///
    /// Le ndlela inokusetshenziswa okuzenzakalelayo kusetshenziswa i-[`ExactSizeIterator::len()`], ngakho-ke awudingi ukuyisebenzisa ngokwakho.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}