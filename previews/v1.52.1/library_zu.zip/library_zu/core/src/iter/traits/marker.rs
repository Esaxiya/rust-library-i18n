/// I-iterator ehlala iqhubeka nokukhiqiza i-`None` lapho isikhathele.
///
/// Ukushayela ngokulandelayo i-iterator exhunyiwe ebuyise i-`None` kanye kuqinisekisiwe ukuthi izobuyisa i-[`None`] futhi.
/// Le trait kufanele isetshenziswe yiwo wonke ama-iterator aziphatha ngale ndlela ngoba ivumela ukwenziwa kahle kwe [`Iterator::fuse()`].
///
///
/// Note: Ngokuvamile, akufanele usebenzise i-`FusedIterator` emikhawulweni ejwayelekile uma udinga iterator efakiwe.
/// Esikhundleni salokho, kufanele umane ushayele i-[`Iterator::fuse()`] ku-iterator.
/// Uma i-iterator isivele ifakiwe, i-[`Fuse`] wrapper eyengeziwe izoba yi-no-op engenanhlawulo yokusebenza.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// I-iterator ebika ubude obuqondile kusetshenziswa i-size_hint.
///
/// I-iterator ibika ukusikisela kosayizi lapho iqonde ngqo (isibopho esiphansi silingana nesibopho esingenhla), noma isibopho esiphezulu siyi-[`None`].
///
/// Umngcele ongaphezulu kufanele ube yi-[`None`] kuphela uma ubude bangempela be-iterator bukhulu kune-[`usize::MAX`].
/// Kuleso simo, ukubopha okuphansi kufanele kube yi-[`usize::MAX`], okuholela ku-[`Iterator::size_hint()`] ka-`(usize::MAX, None)`.
///
/// I-iterator kufanele ikhiqize inani elifanele lezinto elizibikile noma ezahlukahluka ngaphambi kokufika ekugcineni.
///
/// # Safety
///
/// Le trait kumele isetshenziswe kuphela lapho isivumelwano sigcinwa.
/// Abasebenzisi bale trait kumele bahlole i-[`Iterator::size_hint()`]’s ephezulu.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// I-iterator yokuthi lapho kuvezwa into izobe ithathe okungenani into eyodwa kusuka ku-[`SourceIter`] yayo engaphansi.
///
/// Ukushayela noma iyiphi indlela eqhubekisela phambili i-iterator, isb
/// [`next()`] noma i-[`try_fold()`], iqinisekisa ukuthi esinyathelweni ngasinye okungenani inani elilodwa lomthombo oyinhloko we-iterator likhishiwe futhi umphumela weketanga le-iterator ungafakwa endaweni yawo, kucatshangelwa ukuthi izingqinamba zokwakheka komthombo zivumela lokho kufakwa.
///
/// Ngamanye amagama le trait ikhombisa ukuthi ipayipi le-iterator lingaqoqwa lisendaweni.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}