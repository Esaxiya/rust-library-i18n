// ignore-tidy-filelength Leli fayela cishe liqukethe kuphela incazelo ye-`Iterator`.
// Asikwazi ukukuhlukanisa lokho kube amafayela amaningi.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// I-interface yokubhekana nama-iterators.
///
/// Le yi-iterator enkulu i trait.
/// Ukuthola okuningi ngomqondo wama-iterators ngokuvamile, sicela ubheke i [module-level documentation].
/// Ikakhulu, ungahle ufune ukwazi ukuthi ungayenza kanjani i [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Uhlobo lwezinto ezishaywayo ngaphezulu.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Iqhubekisela phambili i-iterator bese ibuyisa inani elilandelayo.
    ///
    /// Ibuyisa i-[`None`] lapho ukuqeda kuqediwe.
    /// Ukuqaliswa komuntu ngamunye kungakhetha ukuqala kabusha, ngakho-ke ukushayela i-`next()` futhi kungahle kungagcini kuqala ukubuyisa i-[`Some(Item)`] futhi ngesinye isikhathi.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Ucingo oluya ku next() lubuyisa inani elilandelayo ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... bese kuthi None uma kuphela.
    /// assert_eq!(None, iter.next());
    ///
    /// // Ezinye izingcingo zingabuyisa noma zingabuyisi i `None`.Lapha, bazohlala njalo.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Ibuyisa imingcele kubude obisele be-iterator.
    ///
    /// Ngokuqondile, i-`size_hint()` ibuyisa isiHlathi lapho into yokuqala ingumkhawulo ophansi, futhi into yesibili ingukuboshwa okuphezulu.
    ///
    /// Ingxenye yesibili yeTuple ebuyisiwe ithi [`Option`]`<`[usize`]`> `.
    /// I-[`None`] lapha isho ukuthi noma kungekho mkhawulo owaziwayo ongaphezulu, noma isibopho esingaphezulu sikhulu kune-[`usize`].
    ///
    /// # Amanothi wokuqalisa
    ///
    /// Akuphoqelelwa ukuthi ukusetshenziswa kwe-iterator kuveza inani lezinto ezimenyezelwe.I-iterator ye-buggy ingaveza ngaphansi kwesibopho esiphansi noma ngaphezulu kwesibopho esiphezulu sezinto.
    ///
    /// `size_hint()` kuhloswe kakhulu ukuthi isetshenziselwe ukwenziwa okuhle njengokugcina isikhala sezinto ze-iterator, kepha akumele ithenjwe isib., yeka ukubhekwa kwemingcele kukhodi engaphephile.
    /// Ukusetshenziswa okungalungile kwe-`size_hint()` akufanele kuholele ekuphulweni kwememori yokuphepha.
    ///
    /// Lokho kusho ukuthi ukuqaliswa kufanele kunikeze isilinganiso esifanele, ngoba uma kungenjalo kungaba ukwephula umthetho olandelwayo we-trait.
    ///
    /// Ukuqaliswa kokuzenzakalelayo kubuyisa `(0,` [`None`]`)`okulungile kunoma iyiphi i-iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Isibonelo esiyinkimbinkimbi:
    ///
    /// ```
    /// // Izinombolo ezilinganayo ezisuka kuziro ziye eshumini.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Singahle sikhuphuke kusuka kuziro kuye ezikhathini eziyishumi.
    /// // Ukwazi ukuthi kunhlanu impela bekungeke kwenzeke ngaphandle kokwenza i filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Masengeze ezinye izinombolo ezinhlanu nge chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // manje yomibili imingcele inyuswe ngamahlanu
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Ukubuyisa i-`None` ngomkhawulo ongaphezulu:
    ///
    /// ```
    /// // i-iterator engenamkhawulo ayinaso isibopho esiphezulu kanye nesilinganiso esiphakeme kakhulu esingaphansi
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Isebenzisa i-iterator, ibala inani leziphindaphindwayo bese iyibuyisela.
    ///
    /// Le ndlela izoshayela i-[`next`] kaninginingi kuze kuhlangatshezwane ne-[`None`], ibuyisa inani lezikhathi eyabona ngazo i-[`Some`].
    /// Qaphela ukuthi i [`next`] kufanele ibizwe okungenani kanye noma ngabe i-iterator ingenazo izinto.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Ukuziphatha Okuchichimayo
    ///
    /// Le ndlela ayikugadi ngokuchichima, ngakho-ke ukubalwa kwezinto ze-iterator ezinezinto ezingaphezu kwe-[`usize::MAX`] kukhiqiza umphumela ongalungile noma i-panics.
    ///
    /// Uma ukuqinisekiswa kwamaphutha kunikwe amandla, i-panic iqinisekisiwe.
    ///
    /// # Panics
    ///
    /// Lo msebenzi ungahle ube yi-panic uma i-iterator inezinto ezingaphezu kwe-[`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Isebenzisa i-iterator, ibuyisa into yokugcina.
    ///
    /// Le ndlela izohlola i-iterator ize ibuyise i-[`None`].
    /// Ngenkathi yenza njalo, kugcina umkhondo wento yamanje.
    /// Ngemuva kokuthi i-[`None`] ibuyisiwe, i-`last()` izobe isibuyisa into yokugcina eyayibonile.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Iqhubekisela phambili i-iterator ngezinto ze-`n`.
    ///
    /// Le ndlela izokweqa ngokulangazela izinto ze-`n` ngokushayela i-[`next`] kuze kube izikhathi eziyi-`n` kuze kuhlangatshezwane ne [`None`].
    ///
    /// `advance_by(n)` izobuyisa i [`Ok(())`][Ok] uma i-iterator iqhubekela phambili ngempumelelo ngezinto ze-`n`, noma i-[`Err(k)`][Err] uma i-[`None`] ihlangatshezwa kuyo, lapho i-`k` iyinombolo yezinto i-iterator ethuthuke ngazo ngaphambi kokuphelelwa yizinto (isb.
    /// ubude be-iterator).
    /// Qaphela ukuthi i `k` ihlala ingaphansi kwe `n`.
    ///
    /// Ukushayela i-`advance_by(0)` akudli noma iziphi izinto futhi kubuyisa njalo i-[`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // i `&4` kuphela eyeqiwe
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Ibuyisa into ethi `n`th ye-iterator.
    ///
    /// Njengokusebenza okuningi kokukhomba, ukubala kuqala kusuka kuziro, ngakho-ke i-`nth(0)` ibuyisa inani lokuqala, i-`nth(1)` eyesibili, njalonjalo.
    ///
    /// Qaphela ukuthi zonke izinto ezandulele, kanye nento ebuyisiwe, kuzodliwa kusuka ku-iterator.
    /// Lokho kusho ukuthi izinto ezandulele zizolahlwa, futhi nokuthi ukubiza i-`nth(0)` kaninginingi ku-iterator efanayo kuzobuyisa izinto ezihlukile.
    ///
    ///
    /// `nth()` izobuyisa i-[`None`] uma i-`n` inkulu noma ilingana nobude be-iterator.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Ukushayela i-`nth()` amahlandla amaningi akubuyiseli emuva i-iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Ukubuyisa i `None` uma kunezinto ezingaphansi kwezingu-`n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Kwakha i-iterator eqala endaweni efanayo, kepha inyathela ngenani elinikeziwe ku-iteration ngayinye.
    ///
    /// Qaphela 1: Into yokuqala ye-iterator izohlala ibuyiselwa, kungakhathalekile ukuthi yisiphi isinyathelo esinikeziwe.
    ///
    /// Qaphela 2: Isikhathi lapho izinto ezinganakwa zidonswa khona asilungisiwe.
    /// `StepBy` iziphatha njengokulandelana kwe `next(), nth(step-1), nth(step-1),…`, kepha futhi ikhululekile ukuthi iziphathe njengokulandelana
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Iyiphi indlela esetshenziswayo engashintsha kwabanye ama-iterator ngezizathu zokusebenza.
    /// Indlela yesibili izothuthukisa i-iterator ngaphambili futhi ingahle idle izinto eziningi.
    ///
    /// `advance_n_and_return_first` kulingana nokuthi:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Indlela izokwenza i-panic uma isinyathelo esinikeziwe kungu-`0`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Ithatha ama-iterator amabili futhi idale i-iterator entsha ngaphezulu kokubili ngokulandelana.
    ///
    /// `chain()` izobuyisa i-iterator entsha ezoqala ihlaziye ngaphezulu kwamanani kusuka ku-iterator yokuqala bese ibuyisa amanani avela ku-iterator yesibili.
    ///
    /// Ngamanye amagama, ixhumanisa ama-iterator amabili ndawonye, ngeketanga.🔗
    ///
    /// [`once`] ijwayele ukusetshenziselwa ukuvumelanisa inani elilodwa kuxhaxha lwezinye izinhlobo ze-iteration.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njengoba impikiswano eya ku-`chain()` isebenzisa i-[`IntoIterator`], singadlulisa noma yini engaguqulwa ibe yi-[`Iterator`], hhayi i-[`Iterator`] uqobo.
    /// Isibonelo, izingcezu ze-(`&[T]`) zisebenzisa i-[`IntoIterator`], ngakho-ke zingadluliselwa ku-`chain()` ngqo:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Uma usebenza ne-Windows API, ungahle ufise ukuguqula i-[`OsStr`] ibe yi-`Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip up' ama-iterator amabili abe iterator eyodwa yamabili.
    ///
    /// `zip()` ibuyisa iterator entsha ezokwenyusa ngaphezulu kwama-iterator amabili, ibuyise iTuple lapho into yokuqala ivela ku-iterator yokuqala, bese into yesibili ivela ku-iterator yesibili.
    ///
    ///
    /// Ngamanye amagama, ifaka ama-iterator amabili ndawonye, abe okukodwa.
    ///
    /// Uma ngabe i-iterator ibuyisa i-[`None`], i-[`next`] kusuka ku-iterator efakiwe izobuyisa i-[`None`].
    /// Uma i-iterator yokuqala ibuyisa i-[`None`], i-`zip` izohamba okwesikhashana futhi i-`next` ngeke ibizwe ku-iterator yesibili.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Njengoba impikiswano eya ku-`zip()` isebenzisa i-[`IntoIterator`], singadlulisa noma yini engaguqulwa ibe yi-[`Iterator`], hhayi i-[`Iterator`] uqobo.
    /// Isibonelo, izingcezu ze-(`&[T]`) zisebenzisa i-[`IntoIterator`], ngakho-ke zingadluliselwa ku-`zip()` ngqo:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` kuvame ukusetshenziselwa ukufaka i-iterator engapheli kokukodwa.
    /// Lokhu kusebenza ngoba iterator enqunyelwe ekugcineni izobuyisa i [`None`], iqede uziphu.Ukuzipha nge-`(0..)` kungabukeka kakhulu njenge-[`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Kwakha i-iterator entsha ebeka ikhophi ye-`separator` phakathi kwezinto eziseduze ne-iterator yoqobo.
    ///
    /// Uma kwenzeka i-`separator` ingasebenzisi i-[`Clone`] noma idinga ukubalwa njalo, sebenzisa i-[`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Into yokuqala evela ku `a`.
    /// assert_eq!(a.next(), Some(&100)); // Isihlukanisi.
    /// assert_eq!(a.next(), Some(&1));   // Into elandelayo evela ku-`a`.
    /// assert_eq!(a.next(), Some(&100)); // Isihlukanisi.
    /// assert_eq!(a.next(), Some(&2));   // Into yokugcina evela ku `a`.
    /// assert_eq!(a.next(), None);       // I-iterator isiqediwe.
    /// ```
    ///
    /// `intersperse` kungasiza kakhulu ukujoyina izinto ze-iterator usebenzisa into ejwayelekile:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Kwakha i-iterator entsha ebeka into eyenziwe yi-`separator` phakathi kwezinto eziseduze kwe-iterator yoqobo.
    ///
    /// Ukuvalwa kuzobizwa kanye kanye ngaso sonke isikhathi lapho into ibekwa phakathi kwezinto ezimbili ezincikene ne-iterator engaphansi;
    /// ikakhulukazi, ukuvalwa akubizwa uma i-iterator engaphansi ikhiqiza izinto ezingaphansi kwezimbili nangemva kokukhishwa kwento yokugcina.
    ///
    ///
    /// Uma into ye-iterator isebenzisa i-[`Clone`], kungaba lula ukuyisebenzisa i-[`intersperse`].
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Into yokuqala evela ku `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Isihlukanisi.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Into elandelayo evela ku-`v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Isihlukanisi.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Into yokugcina evela ku-`v`.
    /// assert_eq!(it.next(), None);               // I-iterator isiqediwe.
    /// ```
    ///
    /// `intersperse_with` ingasetshenziswa ezimeni lapho isihlukanisi sidinga ukubalwa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Ukuvalwa kuboleka ngokuguqukayo umongo wayo ukuze kukhiqizwe into.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Kuthatha ukuvalwa bese kwakhiwa i-iterator ebiza lokho kuvalwa entweni ngayinye.
    ///
    /// `map()` siguqula i-iterator eyodwa iye kwenye, ngokusebenzisa impikiswano yayo:
    /// okuthile okusebenzisa i-[`FnMut`].Ikhiqiza i-iterator entsha ebiza lokhu kuvalwa entweni ngayinye ye-iterator yoqobo.
    ///
    /// Uma ukwazi ukucabanga ngezinhlobo, ungacabanga nge `map()` kanjena:
    /// Uma une-iterator ekunika izinto zohlobo oluthile lwe-`A`, futhi ufuna i-iterator yolunye uhlobo i-`B`, ungasebenzisa i-`map()`, udlulisa ukuvalwa okuthatha i-`A` bese kubuyisa i-`B`.
    ///
    ///
    /// `map()` ifana ngokomqondo ne-[`for`] loop.Kodwa-ke, njengoba i `map()` ivila, isetshenziswa kangcono uma usuvele usebenza namanye ama-iterator.
    /// Uma wenza uhlobo oluthile lokubhida ngomphumela ohlangothini, kubhekwa njenge-idiomatic ukusebenzisa i-[`for`] kune-`map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Uma wenza uhlobo oluthile lomthelela oseceleni, khetha i-[`for`] kuye ku-`map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ungenzi lokhu:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ngeke ikhiphe, njengoba ivila.I-Rust izokuxwayisa ngalokhu.
    ///
    /// // Esikhundleni salokho, sebenzisa:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Ishayela ukuvalwa entweni ngayinye ye-iterator.
    ///
    /// Lokhu kulingana nokusebenzisa i-[`for`] loop ku-iterator, noma i-`break` ne-`continue` zingenzeki kusukela ekuvalweni.
    /// Imvamisa kuyindlela yokusebenzisa i-`for` loop, kepha i-`for_each` kungenzeka ifundeke kakhudlwana lapho icubungula izinto ekugcineni kwamaketanga amade ama-iterator.
    ///
    /// Kwezinye izimo i-`for_each` nayo ingahle isheshe kune-loop, ngoba izosebenzisa i-iteration yangaphakathi kuma-adapters afana ne-`Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Kuleso sibonelo esincane, iluphu ye-`for` ingahlanzeka, kepha i-`for_each` ingahle ikhethe ukugcina isitayela esisebenzayo ngama-iterator amade:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Kwakha i-iterator esebenzisa ukuvalwa ukuthola ukuthi ngabe into ethile kufanele ivezwe yini.
    ///
    /// Njengoba kunikezwe into ukuvalwa kufanele kubuyise i-`true` noma i-`false`.I-iterator ebuyisiwe izokhipha kuphela izinto okubuyiselwe kuzo iqiniso.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngoba ukuvalwa okudluliselwe ku-`filter()` kuthatha ireferensi, futhi ama-iterator amaningi ayalingana nezinkomba, lokhu kuholela esimweni esingahle sidideke, lapho uhlobo lokuvalwa luyireferensi ephindwe kabili:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ngidinga ama * s amabili!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kuvamile ukuthi esikhundleni salokho usebenzise ukwakhiwa empikiswaneni ukuze uhlubule eyodwa:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // Kokubili&*
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// noma zombili:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ama &s amabili
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// yalezi zingqimba.
    ///
    /// Qaphela ukuthi i-`iter.filter(f).next()` ilingana ne-`iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Idala i-iterator ehlunga kanye namamephu.
    ///
    /// I-iterator ebuyisiwe ikhiqiza kuphela `amanani` lapho ukuvalwa okuhlinzekiwe kubuyisa i-`Some(value)`.
    ///
    /// `filter_map` ingasetshenziselwa ukwenza amaketanga we-[`filter`] ne-[`map`] afushane kakhudlwana.
    /// Isibonelo esingezansi sikhombisa ukuthi i-`map().filter().map()` ingafinyezwa kanjani kufoni eyodwa eya ku-`filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nasi isibonelo esifanayo, kepha nge-[`filter`] ne-[`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Kwakha i-iterator enikeza ukubalwa kwamanje kwe-iteration kanye nenani elilandelayo.
    ///
    /// I-iterator ibuyise isivuno semikhiqizo ngazimbili i-`(i, val)`, lapho i-`i` iyinkomba yamanje ye-iteration ne-`val` inani elibuyiswe yi-iterator.
    ///
    ///
    /// `enumerate()` igcina ukubalwa kwayo njenge-[`usize`].
    /// Uma ufuna ukubala ngosayizi ohlukile ohlukile, umsebenzi we-[`zip`] uhlinzeka ngokusebenza okufanayo.
    ///
    /// # Ukuziphatha Okuchichimayo
    ///
    /// Le ndlela ayikugadi ngokuchichima, ngakho-ke ukubala izinto ezingaphezu kwezingu-[`usize::MAX`] kukhiqiza umphumela ongalungile noma i panics.
    /// Uma ukuqinisekiswa kwamaphutha kunikwe amandla, i-panic iqinisekisiwe.
    ///
    /// # Panics
    ///
    /// I-iterator ebuyisiwe ingahle ibe yi-panic uma inkomba ezobuyiselwa ingagcwala i-[`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Kwakha i-iterator engasebenzisa i-[`peek`] ukubheka into elandelayo ye-iterator ngaphandle kokuyidla.
    ///
    /// Ingeza indlela ye-[`peek`] ku-iterator.Bona imibhalo yayo ukuthola eminye imininingwane.
    ///
    /// Qaphela ukuthi i-iterator engaphansi isathuthuka lapho i-[`peek`] ibizwa okokuqala: Ukuze kutholakale into elandelayo, i-[`next`] ibizwa ku-iterator engaphansi, yingakho noma yimiphi imiphumela emibi (isb.
    ///
    /// noma yini enye ngaphandle kokulanda inani elilandelayo) lendlela ye [`next`] izokwenzeka.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() masibone ku future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // singakwazi i-peek() kaninginingi, i-iterator ngeke iqhubekele phambili
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ngemuva kokuthi i-iterator isiqediwe, kanjalo ne peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Idala i-iterator ethi [`skip`] izinto ezisuselwa kumenziwa.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` kuthatha ukuvalwa njengengxabano.Izobiza lokhu kuvalwa entweni ngayinye ye-iterator, bese izibe izinto ize ibuyise i-`false`.
    ///
    /// Ngemuva kokuthi i-`false` ibuyisiwe, umsebenzi we-`skip_while()`'s usuphelile, futhi zonke ezinye izinto ziyakhishwa.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngoba ukuvalwa okudluliselwe ku-`skip_while()` kuthatha ireferensi, futhi ama-iterator amaningi ayalingana nezinkomba, lokhu kuholela esimweni esididayo, lapho uhlobo lwempikiswano yokuvalwa luyireferensi ephindwe kabili:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ngidinga ama * s amabili!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ukuma ngemuva kwe-`false` yokuqala:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ngenkathi lokhu bekungaba ngamanga, ngoba sesivele sinamanga, i skip_while() ayisasetshenziswa futhi
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Kwakha i-iterator ekhipha izinto ngokuya ngesilandiso.
    ///
    /// `take_while()` kuthatha ukuvalwa njengengxabano.Izobiza lokhu kuvalwa entweni ngayinye ye-iterator, bese ikhiqiza izinto ngenkathi ibuyisa i-`true`.
    ///
    /// Ngemuva kokuthi i-`false` ibuyisiwe, umsebenzi we-`take_while()`'s usuphelile, futhi zonke ezinye izinto azinakwa.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngoba ukuvalwa okudluliselwe ku-`take_while()` kuthatha ireferensi, futhi ama-iterator amaningi ayalingana nezinkomba, lokhu kuholela esimweni esingahle sidideke, lapho uhlobo lokuvalwa luyireferensi ephindwe kabili:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ngidinga ama * s amabili!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ukuma ngemuva kwe-`false` yokuqala:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Sinezinto eziningi ezingaphansi kuka-zero, kepha njengoba sesivele sinamanga, i-take_while() ayisasetshenziswa futhi
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ngoba i `take_while()` idinga ukubheka inani ukuze ibone ukuthi kufanele ifakwe yini noma cha, abaqambi bayo abazobona ukuthi isusiwe:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// I `3` ayisekho lapho, ngoba idliwe ngenhloso yokubona ukuthi i-iteration kufanele ime, kepha ayibuyiswanga ku-iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Kwakha i-iterator ekhipha izinto zombili ngokuya ngesilandiso namamephu.
    ///
    /// `map_while()` kuthatha ukuvalwa njengengxabano.
    /// Izobiza lokhu kuvalwa entweni ngayinye ye-iterator, bese ikhiqiza izinto ngenkathi ibuyisa i-[`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nasi isibonelo esifanayo, kepha nge-[`take_while`] ne-[`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ukuma ngemuva kwe-[`None`] yokuqala:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Sinezinto eziningi ezingalingana ku-u32 (4, 5), kepha i-`map_while` ibuyise i-`None` ye-`-3` (njengoba i-`predicate` ibuyise i-`None`) kanye nokuma kwe-`collect` ku-`None` yokuqala okuhlangatshezwane nayo.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Ngoba i `map_while()` idinga ukubheka inani ukuze ibone ukuthi kufanele ifakwe yini noma cha, abaqambi bayo abazobona ukuthi isusiwe:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// I `-3` ayisekho lapho, ngoba idliwe ngenhloso yokubona ukuthi i-iteration kufanele ime, kepha ayibuyiswanga ku-iterator.
    ///
    /// Qaphela ukuthi ngokungafani ne [`take_while`] le iterator **ayi** fused.
    /// Akucacisiwe nokuthi le iterator ibuyisa ini ngemuva kokubuyiselwa kwe [`None`] yokuqala.
    /// Uma udinga i-iterator efakiwe, sebenzisa i-[`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Idala i-iterator eyeqa izakhi zokuqala ze-`n`.
    ///
    /// Ngemuva kokuthi zidliwe, ezinye izakhi ziyakhishwa.
    /// Esikhundleni sokweqa le ndlela ngqo, esikhundleni sokukhipha indlela ye `nth`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Idala i-iterator ekhipha izinto zayo zokuqala ze-`n`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ivame ukusetshenziswa nge-iterator engapheli, ukuyenza iphele:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Uma kutholakala izinto ezingaphansi kuka-`n`, i-`take` izokhawulela ngosayizi we-iterator engaphansi:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// I-adaptha ye-iterator efana ne [`fold`] ephethe isimo sangaphakathi futhi ikhiqize i-iterator entsha.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` kuthatha izimpikiswano ezimbili: inani lokuqala elihlwanyela isimo sangaphakathi, nokuvalwa ngezimpikiswano ezimbili, okokuqala kuyireferensi engaguquguqukayo yesimo sangaphakathi bese kuthi okwesibili kube yinto ye-iterator.
    ///
    /// Ukuvalwa kungabela isimo sangaphakathi ukuthi sabelane ngombuso phakathi kokuphindaphindwa.
    ///
    /// Ku-iteration, ukuvalwa kuzosetshenziswa entweni ngayinye ye-iterator futhi inani lokubuyisa kusuka ekuvalweni, i-[`Option`], likhishwa yi-iterator.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // iteration ngayinye, sizokwandisa umbuso ngento
    ///     *state = *state * x;
    ///
    ///     // lapho-ke, sizokhipha ukuphika kombuso
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Idala i-iterator esebenza njengemephu, kepha iflethi isakhiwo esakhiwe.
    ///
    /// I-adaptha ye-[`map`] iyasiza kakhulu, kepha kuphela uma impikiswano yokuvala ikhiqiza amanani.
    /// Uma ikhiqiza i-iterator esikhundleni salokho, kukhona ungqimba owengeziwe wokuqondiswa.
    /// `flat_map()` izosusa lo ungqimba owengeziwe uwedwa.
    ///
    /// Ungacabanga nge-`flat_map(f)` njengokulingana kwe-semantic kwe-[`map`] ping, bese u-[`flatten`] njengaku-`map(f).flatten()`.
    ///
    /// Enye indlela yokucabanga nge-`flat_map()`: Ukuvalwa kwe-[`map`] kubuyisa into eyodwa entweni ngayinye, futhi ukuvalwa kwe `flat_map()`'s kubuyisa i-iterator yento ngayinye.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ibuyisa iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Kwakha i-iterator ebhebhethekisa isakhiwo esidleke.
    ///
    /// Lokhu kuyasiza uma une-iterator yama-iterator noma i-iterator yezinto ezingaguqulwa zibe ama-iterator futhi ufuna ukususa ileveli eyodwa yokuqondiswa.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Ukwenza imephu bese uthopha:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ibuyisa iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ungakubhala futhi lokhu ngokuya nge-[`flat_map()`], okunconywayo kulokhu ngoba kuveza inhloso ngokucacile:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ibuyisa iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ukuthanjiswa kususa kuphela ileveli eyodwa yokwakha izidleke ngasikhathi:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Lapha sibona ukuthi i `flatten()` ayenzi i-"deep" flatten.
    /// Esikhundleni salokho, kususwa ileveli eyodwa kuphela yokwakha izidleke.Okusho ukuthi, uma u-`flatten()` uhla olunamacala amathathu, umphumela uzoba ngakubili futhi kungabi bukhulu.
    /// Ukuze uthole ukwakheka okukodwa, kufanele uphinde ube yi-`flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Idala i-iterator ephela ngemuva kwe-[`None`] yokuqala.
    ///
    /// Ngemuva kokuthi i-iterator ibuyise i-[`None`], izingcingo ze-future zingahle zingaphinde zikhiqize i-[`Some(T)`] futhi.
    /// `fuse()` ivumelanisa i-iterator, iqinisekisa ukuthi ngemuva kokuthi i-[`None`] inikezwe, izohlala ibuyisa i-[`None`] unomphela.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// // iterator eshintshana phakathi kwe-Some ne-None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // uma kunjalo, i-Some(i32), enye i-None
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // siyabona ukuthi iterator yethu iya emuva naphambili
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // noma kunjalo, uma sesiyifakile ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // izobuya njalo i `None` ngemuva kokuqala.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Yenza okuthile ngento ngayinye ye-iterator, idlulisa inani ku.
    ///
    /// Uma usebenzisa ama-iterator, uvame ukuhlanganisa amaningi awo ndawonye.
    /// Ngenkathi usebenza kukhodi enjalo, ungahle uthande ukubheka ukuthi kwenzekani ezingxenyeni ezahlukahlukene zepayipi.Ukuze wenze lokho, faka ikholi ku-`inspect()`.
    ///
    /// Kujwayelekile kakhulu ukuthi i `inspect()` isetshenziswe njengethuluzi lokulungisa iphutha kunokutholakala kwikhodi yakho yokugcina, kepha izinhlelo zokusebenza zingakuthola kuwusizo ezimweni ezithile lapho amaphutha adinga ukungena ngaphambi kokulahlwa.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // lokhu kulandelana kwe-iterator kuyinkimbinkimbi.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ake sifake ezinye izingcingo ze-inspect() ukuphenya ukuthi kwenzekani
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Lokhu kuzophrinta:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Amaphutha wokungena ngaphambi kokuwalahla:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Lokhu kuzophrinta:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Uboleka i-iterator, kunokuyidla.
    ///
    /// Lokhu kuyasiza ukuvumela ukusebenzisa ama-adaptha we-iterator ngenkathi ugcina ubunikazi be-iterator yoqobo.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // uma sizama ukusebenzisa i-iter futhi, ngeke isebenze.
    /// // Ulayini olandelayo unikeza "iphutha: ukusetshenziswa kwenani elihanjisiwe: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ake sizame lokho futhi
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // esikhundleni salokho, sifaka ku-.by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // manje lokhu kulungile:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Iguqula i-iterator ibe iqoqo.
    ///
    /// `collect()` ingathatha noma yini ephindaphindekayo, futhi iyenze iqoqo elifanele.
    /// Le ngenye yezindlela ezinamandla ngokwengeziwe kumtapo wezincwadi ojwayelekile, osetshenziswa ezimeni ezahlukahlukene.
    ///
    /// Iphethini eyisisekelo lapho i-`collect()` isetshenziswa khona ukuguqula iqoqo elilodwa libe elinye.
    /// Uthatha iqoqo, ushayele i-[`iter`] kulo, wenze inqwaba yezinguquko, bese u-`collect()` ekugcineni.
    ///
    /// `collect()` futhi kungadala izimo zezinhlobo ezingewona amaqoqo ajwayelekile.
    /// Isibonelo, i-[`String`] ingakhiwa kusuka ku-[`char`] s, futhi i-iterator yezinto ze-[`Result<T, E>`][`Result`] ingaqoqelwa ku-`Result<Collection<T>, E>`.
    ///
    /// Bona izibonelo ezingezansi ukuthola okuningi.
    ///
    /// Ngoba i `collect()` ibanzi kakhulu, ingadala izinkinga ngokuthayipha kohlobo.
    /// Kanjalo, i `collect()` ingesinye sezikhathi ezimbalwa lapho uzobona i-syntax eyaziwa ngothando njenge 'turbofish': `::<>`.
    /// Lokhu kusiza i-inference algorithm ukuthi iqonde ngqo ukuthi yiliphi iqoqo ozama ukuliqoqela kulo.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Qaphela ukuthi besidinga i `: Vec<i32>` ngakwesokunxele.Lokhu kungenxa yokuthi singakwazi ukuqoqa, ngokwesibonelo, i-[`VecDeque<T>`] esikhundleni salokho:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Usebenzisa i 'turbofish' esikhundleni sokuchaza i `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ngoba i-`collect()` inaka kuphela lokho oqoqela kukho, usengasebenzisa ukusikisela kohlobo oluthile, i-`_`, nge-turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Usebenzisa i `collect()` ukwenza i [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Uma unohlu lwe-[`Result<T, E>`][`Umphumela`], ungasebenzisa i-`collect()` ukubona ukuthi ngabe kukhona okuhlulekile:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // isinikeza iphutha lokuqala
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // isinikeza uhlu lwezimpendulo
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Isebenzisa i-iterator, idala amaqoqo amabili kuyo.
    ///
    /// Isilandiso esidluliselwe ku-`partition()` singabuyisa i-`true`, noma i-`false`.
    /// `partition()` ibuyisa ipheya, zonke izinto ezibuyisele kuzo i-`true`, nazo zonke izinto ezibuyisele i-`false` kuzo.
    ///
    ///
    /// Bheka futhi i [`is_partitioned()`] ne [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Ishintsha kabusha izinto zale iterator *in-place* ngokuya ngesilandiso esinikeziwe, ukuze bonke labo ababuyisa i-`true` bandulele bonke labo ababuyisa i-`false`.
    ///
    /// Ibuyisa inani lezinto ze-`true` ezitholakele.
    ///
    /// I-oda elilinganisiwe lezinto ezihlukanisiwe aligcinwa.
    ///
    /// Bheka futhi i [`is_partitioned()`] ne [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Ukwahlukanisa okukhona phakathi kokulingana nobunzima
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: kufanele sikhathazeke ngokubala okuchichimayo?Okuwukuphela kwendlela yokuba nokuningi kwe-
        // `usize::MAX` Izinkomba eziguqukayo zinama-ZST, angasebenzisani nokwehlukanisa ...

        // Le misebenzi yokuvalwa kwe-"factory" ikhona ukugwema ukufana ku-`Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Ngokuphindaphindiwe thola i-`false` yokuqala bese uyishintsha nge-`true` yokugcina.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Ihlola ukuthi ngabe izinto zale iterator zihlukaniswe ngokwesilandiso esinikeziwe, ukuze bonke labo ababuyisa i-`true` bandulele bonke labo ababuyisa i-`false`.
    ///
    ///
    /// Bheka futhi i [`partition()`] ne [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Noma ngabe zonke izinto zihlola i-`true`, noma isigatshana sokuqala sima ku-`false` bese sibheka ukuthi azisekho izinto ze-`true` ngemuva kwalokho.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Indlela ye-iterator esebenza umsebenzi inqobo nje uma ibuya ngempumelelo, ikhiqiza inani elilodwa, lokugcina.
    ///
    /// `try_fold()` kuthatha izimpikiswano ezimbili: inani lokuqala, nokuvalwa ngezimpikiswano ezimbili: i 'accumulator', nento.
    /// Ukuvalwa kungabuya ngempumelelo, ngenani okufanele libe nalo i-accumulator ye-iteration elandelayo, noma ibuyisa ukwehluleka, ngenani lephutha elisatshalaliswa libuyele kofonayo ngokushesha i-(short-circuiting).
    ///
    ///
    /// Inani lokuqala inani i-accumulator ezoba nalo ocingweni lokuqala.Uma ukusebenzisa ukuvalwa kuphumelele ekulweni nayo yonke into ye-iterator, i-`try_fold()` ibuyisa i-accumulator yokugcina njengempumelelo.
    ///
    /// Ukusonga kuyasiza noma nini lapho uneqoqo lokuthize, futhi ufuna ukukhiqiza inani elilodwa kulo.
    ///
    /// # Inothi eya ku-Implementors
    ///
    /// Izindlela eziningi ze-(forward) zinokusetshenziswa okuzenzakalelayo ngokuya ngalena, ngakho-ke zama ukusebenzisa lokhu ngokusobala uma ingenza okuthile okungcono kunokuqaliswa kwe-loop okuzenzakalelayo kwe-`for`.
    ///
    /// Ikakhulu, zama ukuba nale kholi i-`try_fold()` ezingxenyeni zangaphakathi lapho le iterator yakhiwa khona.
    /// Uma kudingeka izingcingo eziningi, i-`?` opharetha ingahle ikulungele ukufaka iketanga inani le-accumulator kanye, kepha qaphela noma yiziphi izinto ezingenayo ezidinga ukubekwa ngaphambi kwalezo zimbuyiselo zakuqala.
    /// Le ndlela i-`&mut self`, ngakho-ke i-iteration idinga ukuphinda iqale kabusha ngemuva kokushaya iphutha lapha.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // isamba esihloliwe sazo zonke izinto zamalungu afanayo
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Lesi samba siyachichima lapho kufakwa into engu-100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ngoba izungezwe isikhashana, izinto ezisele zisatholakala nge-iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Indlela ye-iterator esebenza ngokungahambi kahle entweni ngayinye ku-iterator, ime ngephutha lokuqala bese ibuyisa lelo phutha.
    ///
    ///
    /// Lokhu kungacatshangwa futhi njengefomathi ye-[`for_each()`] noma njengenguqulo engenakubalwa ye [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Isizungeza isikhashana, ngakho-ke izinto ezisele zisaku-iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Isonga yonke into kusihlanganisi ngokusebenzisa ukusebenza, ibuyisa umphumela wokugcina.
    ///
    /// `fold()` kuthatha izimpikiswano ezimbili: inani lokuqala, nokuvalwa ngezimpikiswano ezimbili: i 'accumulator', nento.
    /// Ukuvalwa kubuyisa inani okufanele libe nalo i-accumulator nge-iteration elandelayo.
    ///
    /// Inani lokuqala inani i-accumulator ezoba nalo ocingweni lokuqala.
    ///
    /// Ngemuva kokufaka lokhu kuvalwa kuzo zonke izinto ze-iterator, i-`fold()` ibuyisa i-accumulator.
    ///
    /// Lo msebenzi kwesinye isikhathi ubizwa nge-'reduce' noma i-'inject'.
    ///
    /// Ukusonga kuyasiza noma nini lapho uneqoqo lokuthize, futhi ufuna ukukhiqiza inani elilodwa kulo.
    ///
    /// Note: I-`fold()`, nezindlela ezifanayo ezinqamula yonke iterator, kungenzeka zinganqamuli ama-iterator angenamkhawulo, ngisho naku-traits umphumela wawo onganqunywa ngesikhathi esilinganiselwe.
    ///
    /// Note: I-[`reduce()`] ingasetshenziselwa ukusebenzisa into yokuqala njengenani lokuqala, uma uhlobo lwe-accumulator nohlobo lwento lunye.
    ///
    /// # Inothi eya ku-Implementors
    ///
    /// Izindlela eziningi ze-(forward) zinokusetshenziswa okuzenzakalelayo ngokuya ngalena, ngakho-ke zama ukusebenzisa lokhu ngokusobala uma ingenza okuthile okungcono kunokuqaliswa kwe-loop okuzenzakalelayo kwe-`for`.
    ///
    ///
    /// Ikakhulu, zama ukuba nale kholi i-`fold()` ezingxenyeni zangaphakathi lapho le iterator yakhiwa khona.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // isamba sazo zonke izinto zamalungu afanayo
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ake sihambe ngesinyathelo ngasinye se-iteration lapha:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Futhi-ke, umphumela wethu wokugcina, `6`.
    ///
    /// Kujwayelekile kubantu abangasebenzisi ama-iterator kakhulu ukusebenzisa i-`for` loop enoluhlu lwezinto zokwakha umphumela.Lokho kungaguqulwa kube yi-`fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // iluphu:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // bayefana
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Yehlisa izakhi kokukodwa, ngokusebenzisa kaninginingi umsebenzi wokunciphisa.
    ///
    /// Uma i-iterator ingenalutho, ibuyisa i-[`None`];ngaphandle kwalokho, kubuyisa imiphumela yokwehliswa.
    ///
    /// Kuma-iterator anokungenani into eyodwa, lokhu kuyafana ne-[`fold()`] ngento yokuqala ye-iterator njengenani lokuqala, isonga yonke into elandelayo kuyo.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Thola inani eliphakeme:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Ukuhlolwa ukuthi ngabe yonke into ye-iterator ifana nesilandiso.
    ///
    /// `all()` kuthatha ukuvalwa okubuyisa i-`true` noma i-`false`.Kusebenza lokhu kuvalwa entweni ngayinye ye-iterator, futhi uma bonke bebuyisa i-`true`, kunjalo-ke ne `all()`.
    /// Uma omunye wabo ebuyisa i-`false`, ibuyisa i-`false`.
    ///
    /// `all()` ukujikeleza okufishane;ngamanye amagama, izomisa ukucubungula ngokushesha nje lapho ithola i-`false`, ngenxa yokuthi noma ngabe yini enye eyenzekayo, umphumela uzoba yi-`false`.
    ///
    ///
    /// I-iterator engenalutho ibuyisa i-`true`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ukuma ku-`false` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // sisengasebenzisa i-`iter`, njengoba kunezinto eziningi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Ukuhlolwa uma ngabe kukhona into ye-iterator efana nesilandiso.
    ///
    /// `any()` kuthatha ukuvalwa okubuyisa i-`true` noma i-`false`.Kusebenza lokhu kuvalwa entweni ngayinye ye-iterator, futhi uma kukhona kubo ababuyisa i-`true`, kunjalo nange-`any()`.
    /// Uma bonke bebuyisa i-`false`, ibuyisa i-`false`.
    ///
    /// `any()` ukujikeleza okufishane;ngamanye amagama, izomisa ukucubungula ngokushesha nje lapho ithola i-`true`, ngenxa yokuthi noma ngabe yini enye eyenzekayo, umphumela uzoba yi-`true`.
    ///
    ///
    /// I-iterator engenalutho ibuyisa i-`false`.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ukuma ku-`true` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // sisengasebenzisa i-`iter`, njengoba kunezinto eziningi.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Isesha into ye-iterator eyanelisa isilandiso.
    ///
    /// `find()` kuthatha ukuvalwa okubuyisa i-`true` noma i-`false`.
    /// Kusebenza lokhu kuvalwa entweni ngayinye ye-iterator, futhi uma kukhona kubo ababuyisa i-`true`, khona-ke i-`find()` ibuyisa i-[`Some(element)`].
    /// Uma bonke bebuyisa i-`false`, ibuyisa i-[`None`].
    ///
    /// `find()` ukujikeleza okufishane;ngamanye amagama, izomisa ukucubungula ngokushesha nje lapho ukuvalwa kubuyisa i `true`.
    ///
    /// Ngoba i `find()` ithatha ireferensi, futhi ama-iterator amaningi ayalingana nezinkomba, lokhu kuholela esimweni esididayo lapho impikiswano iyisithenjwa esiphindwe kabili.
    ///
    /// Ungawubona lo mphumela ezibonelweni ezingezansi, nge-`&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ukuma ku-`true` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // sisengasebenzisa i-`iter`, njengoba kunezinto eziningi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Qaphela ukuthi i-`iter.find(f)` ilingana ne-`iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Isebenza ukusebenza kuzakhi ze-iterator bese ibuyisa umphumela wokuqala ongeyona noyedwa.
    ///
    ///
    /// `iter.find_map(f)` ilingana ne `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Kusebenza ukusebenza kuzakhi ze-iterator bese kubuyisa umphumela wokuqala weqiniso noma iphutha lokuqala.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Isesha into ku-iterator, ibuyisa inkomba yayo.
    ///
    /// `position()` kuthatha ukuvalwa okubuyisa i-`true` noma i-`false`.
    /// Kusebenza lokhu kuvalwa entweni ngayinye ye-iterator, futhi uma omunye wabo ebuyisa i-`true`, khona-ke i-`position()` ibuyisa i-[`Some(index)`].
    /// Uma bonke bebuyisa i-`false`, ibuyisa i-[`None`].
    ///
    /// `position()` ukujikeleza okufishane;ngamanye amagama, izomisa ukucubungula ngokushesha nje lapho ithola i `true`.
    ///
    /// # Ukuziphatha Okuchichimayo
    ///
    /// Le ndlela ayikugadi ngokuchichima, ngakho-ke uma kunezinto ezingaphezu kwe-[`usize::MAX`] ezingahambisani, ikhiqiza umphumela ongalungile noma i-panics.
    ///
    /// Uma ukuqinisekiswa kwamaphutha kunikwe amandla, i-panic iqinisekisiwe.
    ///
    /// # Panics
    ///
    /// Lo msebenzi ungahle ube yi-panic uma i-iterator inezinto ezingaphezu kwe-`usize::MAX` ezingahambisani.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ukuma ku-`true` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // sisengasebenzisa i-`iter`, njengoba kunezinto eziningi.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Inkomba ebuyisiwe incike esimweni se-iterator
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Isesha into ku-iterator kusuka kwesokudla, ibuyisa inkomba yayo.
    ///
    /// `rposition()` kuthatha ukuvalwa okubuyisa i-`true` noma i-`false`.
    /// Kusebenza lokhu kuvalwa entweni ngayinye ye-iterator, kusukela ekugcineni, futhi uma omunye wabo ebuyisa i-`true`, khona-ke i-`rposition()` ibuyisa i-[`Some(index)`].
    ///
    /// Uma bonke bebuyisa i-`false`, ibuyisa i-[`None`].
    ///
    /// `rposition()` ukujikeleza okufishane;ngamanye amagama, izomisa ukucubungula ngokushesha nje lapho ithola i `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ukuma ku-`true` yokuqala:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // sisengasebenzisa i-`iter`, njengoba kunezinto eziningi.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Akunasidingo sesheke lokuchichima lapha, ngoba i-`ExactSizeIterator` isho ukuthi inani lezinto lingena ku-`usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Ibuyisa into ephezulu ye-iterator.
    ///
    /// Uma izinto eziningana zikhulu ngokulinganayo, into yokugcina iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Ibuyisa into ephansi ye-iterator.
    ///
    /// Uma izinto eziningana zilinganiselwe ngokulinganayo, into yokuqala iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Ibuyisa into enikeza inani eliphakeme kakhulu kusuka kumsebenzi ocacisiwe.
    ///
    ///
    /// Uma izinto eziningana zikhulu ngokulinganayo, into yokugcina iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Ibuyisa into enikeza inani eliphakeme maqondana nomsebenzi wokuqhathanisa ocacisiwe.
    ///
    ///
    /// Uma izinto eziningana zikhulu ngokulinganayo, into yokugcina iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ibuyisa into enikeza inani eliphansi kusuka kumsebenzi ocacisiwe.
    ///
    ///
    /// Uma izinto eziningana zilinganiselwe ngokulinganayo, into yokuqala iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Ibuyisa into enikeza inani eliphansi maqondana nomsebenzi wokuqhathanisa ocacisiwe.
    ///
    ///
    /// Uma izinto eziningana zilinganiselwe ngokulinganayo, into yokuqala iyabuyiselwa.
    /// Uma i-iterator ingenalutho, i-[`None`] iyabuyiselwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ibuyisa inkomba ye-iterator.
    ///
    /// Imvamisa, ama-iterator ayalingana ukusuka kwesobunxele kuye kwesokudla.
    /// Ngemuva kokusebenzisa i-`rev()`, i-iterator esikhundleni sayo izokwenyuka ukusuka kwesokudla kuye kwesobunxele.
    ///
    /// Lokhu kungenzeka kuphela uma i-iterator inesiphetho, ngakho-ke i-`rev()` isebenza kuphela ku-[`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Iguqula i-iterator yamabili ibe yiziqukathi.
    ///
    /// `unzip()` isebenzisa i-iterator ephelele yamabili, ikhiqize amaqoqo amabili: eyodwa ivela ezintweni ezingakwesobunxele zamabili, kanti enye ivela ezintweni ezifanele.
    ///
    ///
    /// Lo msebenzi, ngandlela thile, uphikisana ne [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Idala i-iterator ekopisha zonke izinto zayo.
    ///
    /// Lokhu kuyasiza uma une-iterator ngaphezulu kwe-`&T`, kepha udinga iterator ngaphezulu kwe `T`.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kukopishwe kuyafana ne .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Idala i-iterator [`clone`] yazo zonke izinto zayo.
    ///
    /// Lokhu kuyasiza uma une-iterator ngaphezulu kwe-`&T`, kepha udinga iterator ngaphezulu kwe `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // i-cloned iyafana ne-.map(|&x| x), yama-integer
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Iphinda i-iterator ngokungapheli.
    ///
    /// Esikhundleni sokuma ku-[`None`], i-iterator esikhundleni sayo izoqala futhi, kusukela ekuqaleni.Ngemuva kokuphindaphinda, kuzoqala ekuqaleni futhi.Futhi futhi.
    /// Futhi futhi.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Ifingqa izinto ze-iterator.
    ///
    /// Ithatha into ngayinye, iyangeze ndawonye, bese ibuyisa umphumela.
    ///
    /// I-iterator engenalutho ibuyisa inani le-zero lohlobo.
    ///
    /// # Panics
    ///
    /// Lapho kufonelwa i-`sum()` nohlobo lwenamba yokuqala luyabuyiselwa, le ndlela izokwenza i-panic uma ukugcwalisa kwekhompiyutha kuchichima nokuqinisekiswa kwamaphutha kunikwe amandla.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates phezu kwayo yonke i-iterator, iphindaphinda zonke izinto
    ///
    /// I-iterator engenalutho ibuyisa inani elilodwa lohlobo.
    ///
    /// # Panics
    ///
    /// Lapho kubizwa i-`product()` nohlobo lwenamba yokuqala luyabuyiselwa, indlela izokwenza i-panic uma ukugcwaliswa kwekhompiyutha kuchichima nokuqinisekiswa kwamaphutha kunikwe amandla.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) iqhathanisa izakhi zale [`Iterator`] nalezi zenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) iqhathanisa izakhi zale [`Iterator`] nalezi zenye ngokuphathelene nomsebenzi wokuqhathanisa ocacisiwe.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) iqhathanisa izakhi zale [`Iterator`] nalezi zenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) iqhathanisa izakhi zale [`Iterator`] nalezi zenye ngokuphathelene nomsebenzi wokuqhathanisa ocacisiwe.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] ziyalingana yini nezinye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] ziyalingana nalezo ngokuya ngomunye umsebenzi wokulingana ocacisiwe.
    ///
    ///
    /// # Examples
    ///
    /// Ukusetshenziswa okuyisisekelo:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Inquma ukuthi ngabe izakhi zale [`Iterator`] azilingani nalezo zenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] zingaphansi kuka-[lexicographically](Ord#lexicographical-comparison) kunezinye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] zingaphansi kuka-[lexicographically](Ord#lexicographical-comparison) noma zilingana nalezo zenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] zingu-[lexicographically](Ord#lexicographical-comparison) ezinkulu kunezinye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Inquma ukuthi ngabe izinto zale [`Iterator`] zingu-[lexicographically](Ord#lexicographical-comparison) zinkulu noma zilingana nalezo zenye.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Ihlola ukuthi ngabe izinto zalesi iterator zihleliwe yini.
    ///
    /// Lokho wukuthi, into ngayinye i-`a` nento elandelayo `b`, i-`a <= b` kufanele ibambe.Uma i-iterator ikhipha u-zero noma into eyodwa, i-`true` iyabuyiselwa.
    ///
    /// Qaphela ukuthi uma i-`Self::Item` ingu-`PartialOrd` kuphela, kepha hhayi i-`Ord`, incazelo engenhla isho ukuthi lo msebenzi ubuyisa i-`false` uma ngabe kukhona izinto ezimbili ezilandelanayo ezingalingani.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Ihlola ukuthi ngabe izinto zalesi iterator zihlelwe kusetshenziswa umsebenzi onikeziwe wokuqhathanisa.
    ///
    /// Esikhundleni sokusebenzisa i-`PartialOrd::partial_cmp`, lo msebenzi usebenzisa umsebenzi owunikiwe we-`compare` ukuthola ukuhleleka kwezinto ezimbili.
    /// Ngaphandle kwalokho, ilingana ne [`is_sorted`];bona imibhalo yayo ukuthola eminye imininingwane.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Ihlola ukuthi ngabe izinto zalesi iterator zihlungwe kusetshenziswa umsebenzi wokukhipha ukhiye onikeziwe.
    ///
    /// Esikhundleni sokuqhathanisa izinto ze-iterator ngqo, lo msebenzi uqhathanisa okhiye bezinto, njengoba kunqunywe yi-`f`.
    /// Ngaphandle kwalokho, ilingana ne [`is_sorted`];bona imibhalo yayo ukuthola eminye imininingwane.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Bona i [TrustedRandomAccess]
    // Igama elingajwayelekile ukugwema ukushayisana kwamagama ekuxazululeni indlela bona i #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}