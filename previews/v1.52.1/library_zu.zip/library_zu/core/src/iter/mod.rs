//! Ukuphindaphindwa kwangaphandle okuhlanganiswayo.
//!
//! Uma uzithole uneqoqo lohlobo oluthile, futhi ubudinga ukwenza umsebenzi kuzakhi zeqoqo elishiwoyo, uzongena ngokushesha ku 'iterators'.
//! Ama-Iterator asetshenziswa kakhulu kukhodi ye-idiomatic Rust, ngakho-ke kufanelekile ukujwayelana nawo.
//!
//! Ngaphambi kokuchaza okuningi, ake sikhulume ngokuthi le module ihlelwe kanjani:
//!
//! # Organization
//!
//! Le mojula ihlelwe kakhulu ngohlobo:
//!
//! * [Traits] yingxenye eyinhloko: lawa ma-traits achaza ukuthi hlobo luni lwama-iterator akhona nokuthi ungenzani ngawo.Izindlela zalezi traits kufanelekile ukufaka isikhathi esengeziwe sokufunda.
//! * [Functions] nikeza ezinye izindlela eziwusizo zokwenza ama-iterator ayisisekelo.
//! * [Structs] imvamisa kuyizinhlobo zokubuyisa zezindlela ezahlukahlukene kule traits yale module.Imvamisa uzofuna ukubheka indlela edala i `struct`, kune-`struct` uqobo.
//! Ngemininingwane eminingi yokuthi kungani, bona '[Implementing Iterator](#implementing-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Yilokho kuphela!Ake simbe kuma-iterator.
//!
//! # Iterator
//!
//! Inhliziyo nomphefumulo walesi sigaba yi [`Iterator`] trait.Umnyombo we [`Iterator`] ubukeka kanjena:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! I-iterator inendlela, i-[`next`], okuthi uma ibizwa, ibuyise [`Inketho`]`<Item>`.
//! [`next`] izobuyisa i [`Some(Item)`] inqobo nje uma kukhona izinto, futhi uma seziphelile zonke, izobuyisa i `None` ukukhombisa ukuthi i-iteration isiqediwe.
//! Ama-iterator ngamanye angakhetha ukuqala kabusha i-iteration, ngakho-ke ukubiza i-[`next`] futhi kungenzeka noma ekugcineni kungaqali ukubuyisa i-[`Some(Item)`] futhi ngesikhathi esithile (ngokwesibonelo, bona i-[`TryIter`]).
//!
//!
//! Incazelo ephelele ka-[`Iterator`] ifaka nezinye izindlela eziningi, kepha ziyizindlela ezizenzakalelayo, ezakhiwe ngaphezulu kwe [`next`], ngakho-ke uzithola mahhala.
//!
//! Ama-Iterator nawo ahlanganisiwe, futhi kujwayelekile ukuwahlanganisa ngamaketanga ukwenza izinhlobo eziyinkimbinkimbi zokucubungula.Bona isigaba se [Adapters](#adapters) ngezansi ukuthola eminye imininingwane.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Izinhlobo ezintathu ze-iteration
//!
//! Kunezindlela ezintathu ezijwayelekile ezingadala ama-iterator kusuka eqoqweni:
//!
//! * `iter()`, esebenza ngaphezulu kwe `&T`.
//! * `iter_mut()`, esebenza ngaphezulu kwe `&mut T`.
//! * `into_iter()`, esebenza ngaphezulu kwe `T`.
//!
//! Izinto ezahlukahlukene kumtapo wezincwadi ojwayelekile zingasebenzisa okukodwa noma ngaphezulu kokuthathu, lapho kufanele khona.
//!
//! # Kusetshenziswa Iterator
//!
//! Ukuzakhela i-iterator yakho kufaka izinyathelo ezimbili: ukudala i-`struct` ukubamba isimo se-iterator, bese usebenzisa i-[`Iterator`] yaleyo `struct`.
//! Kungakho kunama-``s``` amaningi kule module: kunesinye se-iterator ne-adapter ye-iterator ngayinye.
//!
//! Masenze i-iterator enegama le-`Counter` ebala ukusuka ku-`1` kuye ku-`5`:
//!
//! ```
//! // Okokuqala, isakhiwo:
//!
//! /// I-iterator ebala ukusuka kokukodwa kuye kokuhlanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // sifuna ukuthi ukubala kwethu kuqale ngasikhathi sinye, ngakho-ke ake sengeze indlela ye new() yokusiza.
//! // Lokhu akudingeki ngokuqinile, kepha kulula.
//! // Qaphela ukuthi siqala i-`count` ku-zero, sizobona ukuthi kungani kusetshenziswa i-`next()`'s ngezansi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ngemuva kwalokho, sisebenzisa i-`Iterator` ye-`Counter` yethu:
//!
//! impl Iterator for Counter {
//!     // sizobe sibala nosize
//!     type Item = usize;
//!
//!     // next() ukuphela kwendlela edingekayo
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Khulisa ukubalwa kwethu.Yingakho siqale ngo-zero.
//!         self.count += 1;
//!
//!         // Hlola ukubona ukuthi siqedile ukubala noma cha.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Futhi manje sesingayisebenzisa!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Ukushayela i-[`next`] ngale ndlela kuphindaphindwa.I-Rust inokwakhiwa okungashayela i-[`next`] ku-iterator yakho, ize ifike ku-`None`.Ake sidlule kulokho okulandelayo.
//!
//! Futhi qaphela ukuthi i-`Iterator` inikeza ukusetshenziswa okuzenzakalelayo kwezindlela ezinjenge-`nth` ne-`fold` ezibiza i-`next` ngaphakathi.
//! Kodwa-ke, kuyenzeka futhi ukuthi ubhale ukwenziwa ngokwezifiso kwezindlela ezinjenge-`nth` ne-`fold` uma i-iterator ingazibala kahle ngaphandle kokubiza i-`next`.
//!
//! # `for` izihibe ne-`IntoIterator`
//!
//! I-`for` loop syntax ye Rust empeleni ingushukela wama-iterator ayo.Nasi isibonelo esiyisisekelo se `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Lokhu kuzophrinta izinombolo eyodwa kuye kweziyisihlanu, ngayinye kulayini wayo.Kepha uzobona okuthile lapha: asikaze sibize lutho ku-vector yethu ukukhiqiza iterator.Yini enikezayo?
//!
//! Kukhona i trait kumtapo wezincwadi ojwayelekile wokuguqula okuthile kube iterator: [`IntoIterator`].
//! Le trait inendlela eyodwa, i [`into_iter`], eguqula into esebenzisa i [`IntoIterator`] ibe iterator.
//! Ake sibheke leyo loop ye `for` futhi, nokuthi umhlanganisi uyiguqula ibe yini:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! I-Rust isusa lokhu ku:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Okokuqala, sibiza i-`into_iter()` ngenani.Ngemuva kwalokho, siyamesha ku-iterator ebuyayo, ishayela i-[`next`] kaninginingi size sibone i-`None`.
//! Ngaleso sikhathi, thina siyi-`break`, futhi sesiqedile ukuyishaya.
//!
//! Kukhona okucashile okuthe xaxa lapha: umtapo wezincwadi ojwayelekile uqukethe ukwenziwa okuthokozisayo kwe [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ngamanye amagama, konke [`Iterator`] kusebenzisa i [`IntoIterator`], ngokumane bazibuyisele.Lokhu kusho izinto ezimbili:
//!
//! 1. Uma ubhala i [`Iterator`], ungayisebenzisa nge-`for` loop.
//! 2. Uma udala iqoqo, ukusebenzisa i-[`IntoIterator`] kuzovumela iqoqo lakho ukuthi lisetshenziswe nge-`for` loop.
//!
//! # Ukushintsha ngesethenjwa
//!
//! Njengoba i-[`into_iter()`] ithatha i-`self` ngenani, kusetshenziswa i-`for` loop ukukala ngaphezulu kweqoqo kudla lelo qoqo.Imvamisa, ungahle uthande ukunciphisa iqoqo ngaphandle kokulisebenzisa.
//! Amaqoqo amaningi anikela ngezindlela ezinikezela ama-iterator ngaphezulu kwezinkomba, ezibizwa ngokujwayelekile i-`iter()` ne-`iter_mut()` ngokulandelana:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` isengumnikazi walo msebenzi.
//! ```
//!
//! Uma uhlobo lweqoqo i-`C` luhlinzeka nge-`iter()`, imvamisa lisebenzisa i-`IntoIterator` ye-`&C`, ngokuqalisa okuvele kubize i-`iter()`.
//! Ngokufanayo, iqoqo le-`C` elihlinzeka nge-`iter_mut()` ngokuvamile lisebenzisa i-`IntoIterator` ye-`&mut C` ngokudlulisela ku-`iter_mut()`.Lokhu kunika amandla i-shorthand elula:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // kufana ne `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // kufana ne `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ngenkathi amaqoqo amaningi enikela nge-`iter()`, akuwona wonke anikela nge-`iter_mut()`.
//! Isibonelo, ukuguqula okhiye be-[`HashSet<T>`] noma i-[`HashMap<K, V>`] kungabeka iqoqo esimweni esingahambelani uma ukhiye hashes ushintsha, ngakho-ke la maqoqo anikela nge-`iter()` kuphela.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Imisebenzi ethatha i-[`Iterator`] bese ibuyisa enye i-[`Iterator`] ivame ukubizwa ngokuthi 'i-iterator adapters', njengoba iyindlela ye-'adapter '
//! pattern'.
//!
//! Ama-adaptha ajwayelekile we-iterator afaka i-[`map`], [`take`], ne-[`filter`].
//! Ukuthola okuningi, bona imibhalo yabo.
//!
//! Uma i-adapter ye-iterator i-panics, i-iterator izoba sesimweni esingacacisiwe (kodwa siphephile kwimemori).
//! Lesi sifundazwe futhi asiqinisekisiwe ukuthi sizohlala ngokufana kuzo zonke izinhlobo ze-Rust, ngakho-ke kufanele ugweme ukuthembela kumanani ngqo abuyiswe yi-iterator ethukile.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Ama-Iterator (kanye ne-iterator [adapters](#adapters))*avilapha*. Lokhu kusho ukuthi ukudala i-iterator akuyona i-_do_ ngokuphelele. Akukho okwenzeka ngempela uze ushayele i-[`next`].
//! Lokhu kwesinye isikhathi kungumthombo wokudideka lapho kwenziwa i-iterator kuphela ngemiphumela yayo emibi.
//! Isibonelo, indlela ye [`map`] ibiza ukuvalwa entweni ngayinye ehamba ngaphezulu:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Lokhu ngeke kuprinte noma yimaphi amanani, njengoba sakha i-iterator kuphela, kunokuyisebenzisa.Umhlanganisi uzosixwayisa ngalolu hlobo lokuziphatha:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Indlela ye-idiomatic yokubhala i-[`map`] ngemiphumela yayo emibi ukusebenzisa i-`for` loop noma ukushayela indlela ye-[`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Enye indlela ejwayelekile yokuhlola i-iterator ukusebenzisa indlela ye-[`collect`] ukukhiqiza iqoqo elisha.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ama-Iterator akudingeki ukuthi aphele.Njengesibonelo, uhla oluvulekile luyi-iterator engapheli:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Kujwayelekile ukusebenzisa i-[`take`] iterator adaptha ukuvula i-iterator engapheli ibe eyokugcina:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Lokhu kuzophrinta izinombolo `0` kuye ku-`4`, ngayinye kulayini wayo.
//!
//! Khumbula ukuthi izindlela kuma-iterators angenamkhawulo, ngisho nalezo umphumela onganqunywa ngezibalo ngesikhathi esilinganiselwe, kungenzeka zinganqamuki.
//! Ngokuqondile, izindlela ezinjenge-[`min`], ezimweni ezijwayelekile ezidinga ukweqa yonke into ku-iterator, kungenzeka zingabuyeli ngempumelelo kunoma iziphi iziqu ezingapheli.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Hhayi bo!I-loop engapheli!
//! // `ones.min()` kubangela i-loop engapheli, ngakho-ke ngeke sifinyelele kuleli qophelo!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;