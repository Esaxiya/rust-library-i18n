use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Le trait inikeza ukufinyelela okuguqukayo esigabeni somthombo kupayipi le-interator-adapter ngaphansi kwezimo
/// * umthombo we-iterator `S` uqobo usebenzisa i `SourceIter<Source = S>`
/// * kunokuqaliswa kokuthunyelwa kwale trait kwe-adaptha ngayinye epayipini eliphakathi komthombo nomthengi wepayipi.
///
/// Lapho umthombo uyi-iterator struct (ejwayele ukubizwa nge-`IntoIter`) lapho-ke lokhu kungasiza ekwenzeni ubuchwepheshe be-[`FromIterator`] noma ukuthola izinto ezisele ngemuva kokuthi i-iterator isikhathale kancane.
///
///
/// Qaphela ukuthi ukusetshenziswa akudingeki ukuthi kunikeze ukufinyelela komthombo ongaphakathi kakhulu wepayipi.I-adapter ephakathi emaphakathi ingase ihlole ngentshiseko ingxenye yepayipi futhi iveze ukugcinwa kwayo kwangaphakathi njengomthombo.
///
/// I-trait ayiphephile ngoba abaqalisi kumele baxhase izakhiwo zokuphepha ezengeziwe.
/// Bona i [`as_inner`] ngemininingwane.
///
/// # Examples
///
/// Ukubuyisa umthombo osetshenziswe kancane:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Isigaba somthombo epayipini le-iterator.
    type Source: Iterator;

    /// Buyisa umthombo wepayipi le-iterator.
    ///
    /// # Safety
    ///
    /// Ukusebenza kufanele kubuyisele ireferensi efanayo engaguquguqukayo empilweni yabo yonke, ngaphandle kwalapho kufakwe oshaye ucingo esikhundleni.
    /// Abafonayo bangafaka esikhundleni sesethenjwa kuphela lapho bekumise ukuphindaphindwa bese belahla ipayipi le-iterator ngemuva kokukhipha umthombo.
    ///
    /// Lokhu kusho ukuthi ama-adaptha we-iterator angancika emthonjeni ongashintshi ngenkathi kwenziwa iteration kodwa awakwazi ukuthembela kuwo ekusebenzeni kwawo kweDrop.
    ///
    /// Ukusebenzisa le ndlela kusho ukuthi ama-adaptha akhipha ukufinyelela okuyimfihlo kuphela emithonjeni yabo futhi angancika kuphela eziqinisekisweni ezenziwe ngokususelwa ezinhlotsheni zendlela yokwamukela.
    /// Ukuntuleka kokufinyelela okunomkhawulo kudinga nokuthi ama-adaptha kumele axhase i-API yomphakathi yomthombo noma ngabe bakwazi ukufinyelela abangaphakathi.
    ///
    /// Abafonayo nabo kufanele balindele ukuthi umthombo ube kunoma yisiphi isimo esihambisana ne-API yaso yomphakathi ngoba ama-adapters ahleli phakathi kwawo nomthombo anokufinyelela okufanayo.
    /// Ikakhulukazi i-adaptha kungenzeka ukuthi idle izinto eziningi kunesidingo.
    ///
    /// Inhloso ephelele yalezi zidingo ukuvumela umthengi wepayipi ukuthi asebenzise
    /// * noma yini esala emthonjeni ngemuva kokumiswa kwe-iteration
    /// * inkumbulo engasetshenziswanga ngokuqhubekisela phambili iterator edlayo
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// I-adaptha ye-iterator ekhiqiza okukhishwayo inqobo nje uma i-iterator engaphansi ikhiqiza amanani we-`Result::Ok`.
///
///
/// Uma kuhlangatshezwana nephutha, i-iterator iyama bese iphutha liyagcinwa.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Cubungula i-iterator enikeziwe kube sengathi iveze i-`T` esikhundleni se-`Result<T, _>`.
/// Noma yimaphi amaphutha azomisa i-iterator yangaphakathi futhi umphumela uwonke uzoba yiphutha.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}