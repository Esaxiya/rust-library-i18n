# Il `rustc-std-workspace-std` crate

Vedere la documentazione per `rustc-std-workspace-core` crate.