//! Implementazione di Rust panics tramite interruzioni del processo
//!
//! Rispetto all'implementazione tramite lo svolgimento, questo crate è *molto* più semplice!Detto questo, non è così versatile, ma ecco qua!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" il carico utile e lo spessore per l'interruzione pertinente sulla piattaforma in questione.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // chiama std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Su Windows, utilizza il meccanismo __fastfail specifico del processore.In Windows 8 e versioni successive, il processo terminerà immediatamente senza eseguire alcun gestore di eccezioni in-process.
            // Nelle versioni precedenti di Windows, questa sequenza di istruzioni verrà trattata come una violazione di accesso, terminando il processo ma senza necessariamente bypassare tutti i gestori di eccezioni.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: questa è la stessa implementazione di `abort_internal` di libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Questa ... è un po 'una stranezza.Il tl; dr;è che questo è necessario per collegare correttamente, la spiegazione più lunga è di seguito.
//
// In questo momento i binari di libcore/libstd che spediamo sono tutti compilati con `-C panic=unwind`.Questo viene fatto per garantire che i binari siano compatibili al massimo con il maggior numero di situazioni possibile.
// Il compilatore, tuttavia, richiede un "personality function" per tutte le funzioni compilate con `-C panic=unwind`.Questa funzione di personalità è codificata con il simbolo `rust_eh_personality` ed è definita dall'elemento lang `eh_personality`.
//
// So...
// perché non definire semplicemente quell'elemento lang qui?Buona domanda!Il modo in cui i runtime panic sono collegati è in realtà un po 'sottile in quanto sono "sort of" nell'archivio crate del compilatore, ma effettivamente collegati solo se un altro non è effettivamente collegato.
//
// Questo finisce per significare che sia questo crate che panic_unwind crate possono apparire nell'archivio crate del compilatore, e se entrambi definiscono l'elemento `eh_personality` lang allora si verificherà un errore.
//
// Per gestire questo, il compilatore richiede solo che `eh_personality` sia definito se il runtime panic a cui si sta collegando è il runtime di svolgimento, e altrimenti non è necessario che sia definito (giustamente).
// In questo caso, tuttavia, questa libreria definisce solo questo simbolo, quindi c'è almeno una personalità da qualche parte.
//
// Essenzialmente questo simbolo è definito solo per essere cablato su binari libcore/libstd, ma non dovrebbe mai essere chiamato poiché non ci colleghiamo affatto in un runtime di svolgimento.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Su x86_64-pc-windows-gnu usiamo la nostra funzione di personalità che deve restituire `ExceptionContinueSearch` mentre passiamo su tutti i nostri frame.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Simile a sopra, questo corrisponde all'elemento lang `eh_catch_typeinfo` attualmente utilizzato solo su Emscripten.
    //
    // Poiché panics non genera eccezioni e le eccezioni esterne sono attualmente UB con -C panic=abort (sebbene questo possa essere soggetto a modifiche), qualsiasi chiamata catch_unwind non utilizzerà mai questo typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Questi due sono chiamati dai nostri oggetti di avvio su i686-pc-windows-gnu, ma non hanno bisogno di fare nulla, quindi i corpi sono nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}