# Il `rustc-std-workspace-core` crate

Questo crate è uno shim e uno crate vuoto che dipende semplicemente da `libcore` e riesporta tutti i suoi contenuti.
crate è il punto cruciale per consentire alla libreria standard di dipendere da crates da crates.io

Crates su crates.io da cui dipende la libreria standard deve dipendere da `rustc-std-workspace-core` crate da crates.io, che è vuoto.

Usiamo `[patch]` per sovrascriverlo a questo crate in questo repository.
Di conseguenza, crates su crates.io disegnerà una dipendenza da edge a `libcore`, la versione definita in questo repository.
Questo dovrebbe disegnare tutti i margini di dipendenza per garantire che Cargo compili crates con successo!

Nota che crates su crates.io deve dipendere da questo crate con il nome `core` affinché tutto funzioni correttamente.Per farlo possono utilizzare:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Attraverso l'uso del tasto `package`, crate viene rinominato in `core`, il che significa che apparirà come

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

quando Cargo invoca il compilatore, soddisfacendo la direttiva `extern crate core` implicita iniettata dal compilatore.




