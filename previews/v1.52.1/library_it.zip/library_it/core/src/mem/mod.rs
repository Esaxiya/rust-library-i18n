//! Funzioni di base per gestire la memoria.
//!
//! Questo modulo contiene funzioni per interrogare la dimensione e l'allineamento dei tipi, inizializzare e manipolare la memoria.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Prende la proprietà e "forgets" sul valore **senza eseguire il suo distruttore**.
///
/// Tutte le risorse gestite dal valore, come la memoria heap o un handle di file, rimarranno per sempre in uno stato non raggiungibile.Tuttavia, non garantisce che i puntatori a questa memoria rimarranno validi.
///
/// * Se vuoi perdere memoria, vedi [`Box::leak`].
/// * Se vuoi ottenere un puntatore grezzo alla memoria, vedi [`Box::into_raw`].
/// * Se vuoi eliminare correttamente un valore, eseguendo il suo distruttore, vedi [`mem::drop`].
///
/// # Safety
///
/// `forget` non è contrassegnato come `unsafe`, perché le garanzie di sicurezza di Rust non includono una garanzia che i distruttori funzioneranno sempre.
/// Ad esempio, un programma può creare un ciclo di riferimento utilizzando [`Rc`][rc] o chiamare [`process::exit`][exit] per uscire senza eseguire distruttori.
/// Pertanto, consentire a `mem::forget` di accedere al codice sicuro non modifica fondamentalmente le garanzie di sicurezza di Rust.
///
/// Detto questo, la perdita di risorse come la memoria o gli oggetti I/O è solitamente indesiderabile.
/// La necessità si presenta in alcuni casi d'uso specializzati per FFI o codice non sicuro, ma anche in questo caso, [`ManuallyDrop`] è in genere preferito.
///
/// Poiché è consentito dimenticare un valore, qualsiasi codice `unsafe` che scrivi deve consentire questa possibilità.Non è possibile restituire un valore e aspettarsi che il chiamante eseguirà necessariamente il distruttore del valore.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// L'uso canonico sicuro di `mem::forget` è quello di aggirare il distruttore di un valore implementato dall `Drop` trait.Ad esempio, questo perderà un `File`, ie
/// recuperare lo spazio occupato dalla variabile ma non chiudere mai la risorsa di sistema sottostante:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ciò è utile quando la proprietà della risorsa sottostante è stata precedentemente trasferita a codice esterno a Rust, ad esempio trasmettendo il descrittore di file non elaborato al codice C.
///
/// # Relazione con `ManuallyDrop`
///
/// Sebbene `mem::forget` possa essere utilizzato anche per trasferire la proprietà della *memoria*, ciò è soggetto a errori.
/// [`ManuallyDrop`] dovrebbe essere usato invece.Considera, ad esempio, questo codice:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Costruisci un `String` utilizzando i contenuti di `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // perdita `v` perché la sua memoria è ora gestita da `s`
/// mem::forget(v);  // ERRORE, v non è valido e non deve essere passato a una funzione
/// assert_eq!(s, "Az");
/// // `s` viene implicitamente eliminato e la sua memoria viene deallocata.
/// ```
///
/// Ci sono due problemi con l'esempio precedente:
///
/// * Se più codice venisse aggiunto tra la costruzione di `String` e l'invocazione di `mem::forget()`, uno panic al suo interno causerebbe un doppio libero perché la stessa memoria è gestita sia da `v` che da `s`.
/// * Dopo aver chiamato `v.as_mut_ptr()` e trasmesso la proprietà dei dati a `s`, il valore `v` non è valido.
/// Anche quando un valore viene appena spostato su `mem::forget` (che non lo ispeziona), alcuni tipi hanno requisiti rigidi sui loro valori che li rendono non validi quando penzoloni o non più di proprietà.
/// L'utilizzo di valori non validi in qualsiasi modo, incluso il passarli o restituirli dalle funzioni, costituisce un comportamento indefinito e può rompere le ipotesi fatte dal compilatore.
///
/// Il passaggio a `ManuallyDrop` evita entrambi i problemi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Prima di smontare l `v` nelle sue parti grezze, assicurati che non venga lasciato cadere!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Ora smonta `v`.Queste operazioni non possono essere panic, quindi non può esserci una perdita.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Infine, costruisci un `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` viene implicitamente eliminato e la sua memoria viene deallocata.
/// ```
///
/// `ManuallyDrop` previene efficacemente il double-free perché disabilitiamo il distruttore di `v` prima di fare qualsiasi altra cosa.
/// `mem::forget()` non lo consente perché consuma il suo argomento, costringendoci a chiamarlo solo dopo aver estratto tutto ciò di cui abbiamo bisogno da `v`.
/// Anche se uno panic fosse introdotto tra la costruzione di `ManuallyDrop` e la costruzione della stringa (cosa che non può accadere nel codice come mostrato), si otterrebbe una perdita e non un doppio libero.
/// In altre parole, `ManuallyDrop` sbaglia sul lato della perdita invece di sbagliare sul lato della (doppia) caduta.
///
/// Inoltre, `ManuallyDrop` ci impedisce di dover "touch" `v` dopo aver trasferito la proprietà a `s`: il passaggio finale dell'interazione con `v` per eliminarlo senza eseguire il suo distruttore è completamente evitato.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Come [`forget`], ma accetta anche valori non dimensionati.
///
/// Questa funzione è solo uno spessore che deve essere rimosso quando la funzione `unsized_locals` viene stabilizzata.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Restituisce la dimensione di un tipo in byte.
///
/// Più specificamente, questo è l'offset in byte tra gli elementi successivi in un array con quel tipo di elemento incluso il riempimento dell'allineamento.
///
/// Pertanto, per qualsiasi tipo `T` e lunghezza `n`, `[T; n]` ha una dimensione di `n * size_of::<T>()`.
///
/// In generale, la dimensione di un tipo non è stabile tra le compilazioni, ma i tipi specifici come le primitive lo sono.
///
/// La tabella seguente fornisce la dimensione per le primitive.
///
/// Tipo |taglia di: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 caratteri |4
///
/// Inoltre, `usize` e `isize` hanno le stesse dimensioni.
///
/// I tipi `*const T`, `&T`, `Box<T>`, `Option<&T>` e `Option<Box<T>>` hanno tutti la stessa dimensione.
/// Se `T` è Sized, tutti questi tipi hanno la stessa dimensione di `usize`.
///
/// La mutevolezza di un puntatore non cambia la sua dimensione.In quanto tali, `&T` e `&mut T` hanno le stesse dimensioni.
/// Allo stesso modo per `*const T` e `* mut T`.
///
/// # Dimensioni degli articoli `#[repr(C)]`
///
/// La rappresentazione `C` per gli elementi ha un layout definito.
/// Con questo layout, anche la dimensione degli elementi è stabile fintanto che tutti i campi hanno una dimensione stabile.
///
/// ## Dimensioni delle strutture
///
/// Per `structs`, la dimensione è determinata dal seguente algoritmo.
///
/// Per ogni campo nella struttura ordinata per ordine di dichiarazione:
///
/// 1. Aggiungi la dimensione del campo.
/// 2. Arrotonda la dimensione corrente al multiplo più vicino dell [alignment] del campo successivo.
///
/// Infine, arrotondare la dimensione della struttura al multiplo più vicino del suo [alignment].
/// L'allineamento della struttura è solitamente il più grande allineamento di tutti i suoi campi;questo può essere modificato con l'uso di `repr(align(N))`.
///
/// A differenza di `C`, gli struct di dimensione zero non vengono arrotondati a una dimensione di un byte.
///
/// ## Dimensioni di enumerazioni
///
/// Gli enum che non contengono dati diversi dal discriminante hanno le stesse dimensioni degli enum C sulla piattaforma per cui sono stati compilati.
///
/// ## Dimensione dei sindacati
///
/// La dimensione di un'unione è la dimensione del suo campo più grande.
///
/// A differenza di `C`, le unioni di dimensione zero non vengono arrotondate a una dimensione di un byte.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Alcuni primitivi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Alcuni array
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Uguaglianza delle dimensioni del puntatore
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Utilizzando `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // La dimensione del primo campo è 1, quindi aggiungi 1 alla dimensione.La dimensione è 1.
/// // L'allineamento del secondo campo è 2, quindi aggiungi 1 alla dimensione per il riempimento.La dimensione è 2.
/// // La dimensione del secondo campo è 2, quindi aggiungi 2 alla dimensione.La dimensione è 4.
/// // L'allineamento del terzo campo è 1, quindi aggiungi 0 alla dimensione per il riempimento.La dimensione è 4.
/// // La dimensione del terzo campo è 1, quindi aggiungi 1 alla dimensione.La dimensione è 5.
/// // Infine, l'allineamento della struttura è 2 (perché l'allineamento più grande tra i suoi campi è 2), quindi aggiungi 1 alla dimensione per il riempimento.
/// // La dimensione è 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Le strutture tuple seguono le stesse regole.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Notare che il riordino dei campi può ridurre la dimensione.
/// // Possiamo rimuovere entrambi i byte di riempimento inserendo `third` prima di `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // La dimensione dell'unione è la dimensione del campo più grande.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Restituisce la dimensione del valore puntato in byte.
///
/// Di solito è lo stesso di `size_of::<T>()`.
/// Tuttavia, quando `T`*non ha* dimensioni note staticamente, ad esempio uno slice [`[T]`][slice] o [trait object], è possibile utilizzare `size_of_val` per ottenere la dimensione nota dinamicamente.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: `val` è un riferimento, quindi è un puntatore grezzo valido
    unsafe { intrinsics::size_of_val(val) }
}

/// Restituisce la dimensione del valore puntato in byte.
///
/// Di solito è lo stesso di `size_of::<T>()`.Tuttavia, quando `T`*non ha* dimensioni note staticamente, ad esempio uno slice [`[T]`][slice] o [trait object], è possibile utilizzare `size_of_val_raw` per ottenere le dimensioni note dinamicamente.
///
/// # Safety
///
/// Questa funzione può essere chiamata in sicurezza solo se sussistono le seguenti condizioni:
///
/// - Se `T` è `Sized`, questa funzione è sempre sicura da chiamare.
/// - Se la coda non dimensionata di `T` è:
///     - a [slice], la lunghezza della coda della sezione deve essere un numero intero inizializzato e la dimensione del *valore intero*(lunghezza della coda dinamica + prefisso dimensionato staticamente) deve essere contenuta in `isize`.
///     - a [trait object], la parte vtable del puntatore deve puntare a una tabella v valida acquisita da una coercizione senza ridimensionamento e la dimensione dell '*intero valore*(lunghezza della coda dinamica + prefisso dimensionato staticamente) deve rientrare in `isize`.
///
///     - un (unstable) [extern type], allora questa funzione è sempre sicura da chiamare, ma può panic o altrimenti restituire il valore sbagliato, poiché il layout del tipo esterno non è noto.
///     Questo è lo stesso comportamento di [`size_of_val`] su un riferimento a un tipo con una coda di tipo esterna.
///     - in caso contrario, non è prudentemente consentito chiamare questa funzione.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICUREZZA: il chiamante deve fornire un puntatore grezzo valido
    unsafe { intrinsics::size_of_val(val) }
}

/// Restituisce l'allineamento minimo [ABI] richiesto di un tipo.
///
/// Ogni riferimento a un valore del tipo `T` deve essere un multiplo di questo numero.
///
/// Questo è l'allineamento utilizzato per i campi struct.Potrebbe essere più piccolo dell'allineamento preferito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Restituisce l'allineamento minimo [ABI] richiesto del tipo di valore a cui punta `val`.
///
/// Ogni riferimento a un valore del tipo `T` deve essere un multiplo di questo numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: val è un riferimento, quindi è un puntatore grezzo valido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce l'allineamento minimo [ABI] richiesto di un tipo.
///
/// Ogni riferimento a un valore del tipo `T` deve essere un multiplo di questo numero.
///
/// Questo è l'allineamento utilizzato per i campi struct.Potrebbe essere più piccolo dell'allineamento preferito.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Restituisce l'allineamento minimo [ABI] richiesto del tipo di valore a cui punta `val`.
///
/// Ogni riferimento a un valore del tipo `T` deve essere un multiplo di questo numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SICUREZZA: val è un riferimento, quindi è un puntatore grezzo valido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce l'allineamento minimo [ABI] richiesto del tipo di valore a cui punta `val`.
///
/// Ogni riferimento a un valore del tipo `T` deve essere un multiplo di questo numero.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Questa funzione può essere chiamata in sicurezza solo se sussistono le seguenti condizioni:
///
/// - Se `T` è `Sized`, questa funzione è sempre sicura da chiamare.
/// - Se la coda non dimensionata di `T` è:
///     - a [slice], la lunghezza della coda della sezione deve essere un numero intero inizializzato e la dimensione del *valore intero*(lunghezza della coda dinamica + prefisso dimensionato staticamente) deve essere contenuta in `isize`.
///     - a [trait object], la parte vtable del puntatore deve puntare a una tabella v valida acquisita da una coercizione senza ridimensionamento e la dimensione dell '*intero valore*(lunghezza della coda dinamica + prefisso dimensionato staticamente) deve rientrare in `isize`.
///
///     - un (unstable) [extern type], allora questa funzione è sempre sicura da chiamare, ma può panic o altrimenti restituire il valore sbagliato, poiché il layout del tipo esterno non è noto.
///     Questo è lo stesso comportamento di [`align_of_val`] su un riferimento a un tipo con una coda di tipo esterna.
///     - in caso contrario, non è prudentemente consentito chiamare questa funzione.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SICUREZZA: il chiamante deve fornire un puntatore grezzo valido
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Restituisce `true` se l'eliminazione dei valori di tipo `T` è importante.
///
/// Questo è puramente un suggerimento per l'ottimizzazione e può essere implementato in modo conservativo:
/// può restituire `true` per i tipi che in realtà non devono essere eliminati.
/// In quanto tale, restituire sempre `true` sarebbe un'implementazione valida di questa funzione.Tuttavia, se questa funzione restituisce effettivamente `false`, puoi essere certo che l'eliminazione di `T` non ha alcun effetto collaterale.
///
/// Le implementazioni di basso livello di cose come le raccolte, che devono eliminare manualmente i propri dati, dovrebbero utilizzare questa funzione per evitare di tentare inutilmente di eliminare tutti i loro contenuti quando vengono distrutti.
///
/// Questo potrebbe non fare la differenza nelle build di rilascio (dove un ciclo che non ha effetti collaterali viene facilmente rilevato ed eliminato), ma spesso è una grande vittoria per le build di debug.
///
/// Si noti che [`drop_in_place`] esegue già questo controllo, quindi se il carico di lavoro può essere ridotto a un numero limitato di chiamate [`drop_in_place`], non è necessario utilizzarlo.
/// In particolare, nota che puoi [`drop_in_place`] uno slice, e questo farà un singolo controllo needs_drop per tutti i valori.
///
/// Tipi come Vec quindi solo `drop_in_place(&mut self[..])` senza utilizzare `needs_drop` esplicitamente.
/// Tipi come [`HashMap`], d'altra parte, devono eliminare i valori uno alla volta e dovrebbero utilizzare questa API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ecco un esempio di come una raccolta potrebbe utilizzare `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // rilascia i dati
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Restituisce il valore di tipo `T` rappresentato dal modello di byte tutto zero.
///
/// Ciò significa che, ad esempio, il byte di riempimento in `(u8, u16)` non è necessariamente azzerato.
///
/// Non vi è alcuna garanzia che un modello di byte tutto zero rappresenti un valore valido di qualche tipo `T`.
/// Ad esempio, il modello di byte tutto zero non è un valore valido per i tipi di riferimento (`&T`, `&mut T`) e i puntatori a funzioni.
/// L'utilizzo di `zeroed` su tali tipi causa [undefined behavior][ub] immediato perché [the Rust compiler assumes][inv] che c'è sempre un valore valido in una variabile che considera inizializzata.
///
///
/// Questo ha lo stesso effetto di [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// A volte è utile per FFI, ma generalmente dovrebbe essere evitato.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Uso corretto di questa funzione: inizializzazione di un numero intero con zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Uso errato* di questa funzione: inizializzazione di un riferimento con zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Comportamento indefinito!
/// let _y: fn() = unsafe { mem::zeroed() }; // E di nuovo!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SICUREZZA: il chiamante deve garantire che un valore tutto zero sia valido per `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypassa i normali controlli di inizializzazione della memoria di Rust fingendo di produrre un valore di tipo `T`, senza fare nulla.
///
/// **Questa funzione è deprecata.** Utilizza invece [`MaybeUninit<T>`].
///
/// Il motivo della deprecazione è che la funzione fondamentalmente non può essere utilizzata correttamente: ha lo stesso effetto di [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Come spiega [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] quei valori sono inizializzati correttamente.
/// Di conseguenza, chiamando ad es
/// `mem::uninitialized::<bool>()` provoca un comportamento indefinito immediato per la restituzione di un `bool` che non è sicuramente `true` o `false`.
/// Peggio ancora, la memoria veramente non inizializzata come quella che viene restituita qui è speciale in quanto il compilatore sa che non ha un valore fisso.
/// Questo rende un comportamento indefinito avere dati non inizializzati in una variabile anche se quella variabile ha un tipo intero.
/// (Si noti che le regole sugli interi non inizializzati non sono ancora state finalizzate, ma fino a quando non lo sono, è consigliabile evitarle.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SICUREZZA: il chiamante deve garantire che un valore unitializzato sia valido per `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Scambia i valori in due posizioni mutabili, senza deinizializzare nessuna delle due.
///
/// * Se vuoi scambiare con un valore predefinito o fittizio, vedi [`take`].
/// * Se vuoi scambiare con un valore passato, restituendo il vecchio valore, vedi [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SICUREZZA: i puntatori grezzi sono stati creati da riferimenti mutabili sicuri soddisfacendo tutti i
    // vincoli su `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Sostituisce `dest` con il valore predefinito di `T`, restituendo il valore `dest` precedente.
///
/// * Se vuoi sostituire i valori di due variabili, vedi [`swap`].
/// * Se si desidera sostituire con un valore passato invece del valore predefinito, vedere [`replace`].
///
/// # Examples
///
/// Un semplice esempio:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` consente di assumere la proprietà di un campo struct sostituendolo con un valore "empty".
/// Senza `take` puoi incorrere in problemi come questi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Nota che `T` non implementa necessariamente [`Clone`], quindi non può nemmeno clonare e resettare `self.buf`.
/// Ma `take` può essere utilizzato per dissociare il valore originale di `self.buf` da `self`, consentendone la restituzione:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Sposta `src` nell `dest` di riferimento, restituendo il valore `dest` precedente.
///
/// Nessuno dei due valori viene eliminato.
///
/// * Se vuoi sostituire i valori di due variabili, vedi [`swap`].
/// * Se si desidera sostituire con un valore predefinito, vedere [`take`].
///
/// # Examples
///
/// Un semplice esempio:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` consente il consumo di un campo struct sostituendolo con un altro valore.
/// Senza `replace` puoi incorrere in problemi come questi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Nota che `T` non implementa necessariamente [`Clone`], quindi non possiamo nemmeno clonare `self.buf[i]` per evitare lo spostamento.
/// Ma `replace` può essere utilizzato per dissociare il valore originale a quell'indice da `self`, consentendone la restituzione:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SICUREZZA: leggiamo da `dest` ma in seguito vi scriviamo direttamente `src`,
    // in modo tale che il vecchio valore non venga duplicato.
    // Niente viene lasciato cadere e niente qui può panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Dispone di un valore.
///
/// Ciò avviene chiamando l'implementazione dell'argomento di [`Drop`][drop].
///
/// Questo in effetti non fa nulla per i tipi che implementano `Copy`, ad es
/// integers.
/// Tali valori vengono copiati e _then_ spostato nella funzione, quindi il valore persiste dopo questa chiamata di funzione.
///
///
/// Questa funzione non è magica;è letteralmente definito come
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Poiché `_x` viene spostato nella funzione, viene automaticamente rilasciato prima che la funzione ritorni.
///
/// [drop]: Drop
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // rilasciare esplicitamente vector
/// ```
///
/// Poiché [`RefCell`] applica le regole di prestito in fase di esecuzione, `drop` può rilasciare un prestito [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // rinuncia al prestito mutevole su questo slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// I numeri interi e altri tipi che implementano [`Copy`] non sono influenzati da `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // una copia di `x` viene spostata e rilasciata
/// drop(y); // una copia di `y` viene spostata e rilasciata
///
/// println!("x: {}, y: {}", x, y.0); // ancora disponibile
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreta `src` come di tipo `&U`, quindi legge `src` senza spostare il valore contenuto.
///
/// Questa funzione presumerà in modo non sicuro che il puntatore `src` sia valido per i byte [`size_of::<U>`][size_of] trasmettendo `&T` a `&U` e quindi leggendo `&U` (tranne per il fatto che ciò viene fatto in un modo corretto anche quando `&U` rende requisiti di allineamento più severi di `&T`).
/// Inoltre creerà in modo non sicuro una copia del valore contenuto invece di spostarsi da `src`.
///
/// Non è un errore in fase di compilazione se `T` e `U` hanno dimensioni diverse, ma è altamente consigliato invocare questa funzione solo dove `T` e `U` hanno la stessa dimensione.Questa funzione attiva [undefined behavior][ub] se `U` è maggiore di `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Copia i dati da 'foo_array' e trattali come 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifica i dati copiati
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Il contenuto di 'foo_array' non dovrebbe essere cambiato
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Se U ha requisiti di allineamento più elevati, src potrebbe non essere allineato adeguatamente.
    if align_of::<U>() > align_of::<T>() {
        // SICUREZZA: `src` è un riferimento che è garantito per essere valido per le letture.
        // Il chiamante deve garantire che la trasmutazione effettiva sia sicura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SICUREZZA: `src` è un riferimento che è garantito per essere valido per le letture.
        // Abbiamo appena verificato che `src as *const U` fosse allineato correttamente.
        // Il chiamante deve garantire che la trasmutazione effettiva sia sicura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tipo opaco che rappresenta il discriminante di un enum.
///
/// Vedere la funzione [`discriminant`] in questo modulo per ulteriori informazioni.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Queste implementazioni trait non possono essere derivate perché non vogliamo alcun limite su T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Restituisce un valore che identifica in modo univoco la variante enum in `v`.
///
/// Se `T` non è un'enumerazione, la chiamata a questa funzione non produrrà un comportamento indefinito, ma il valore restituito non è specificato.
///
///
/// # Stability
///
/// Il discriminante di una variante dell'enumerazione può cambiare se la definizione dell'enumerazione cambia.
/// Un discriminante di qualche variante non cambierà tra le compilazioni con lo stesso compilatore.
///
/// # Examples
///
/// Questo può essere usato per confrontare enumerazioni che trasportano dati, ignorando i dati effettivi:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Restituisce il numero di varianti nel tipo di enumerazione `T`.
///
/// Se `T` non è un'enumerazione, la chiamata a questa funzione non produrrà un comportamento indefinito, ma il valore restituito non è specificato.
/// Allo stesso modo, se `T` è un'enumerazione con più varianti di `usize::MAX`, il valore restituito non è specificato.
/// Verranno conteggiate le varianti disabitate.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}