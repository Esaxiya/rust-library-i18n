use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Un tipo wrapper per costruire istanze non inizializzate di `T`.
///
/// # Inizializzazione invariante
///
/// Il compilatore, in generale, presuppone che una variabile sia inizializzata correttamente in base ai requisiti del tipo di variabile.Ad esempio, una variabile di tipo riferimento deve essere allineata e non NULL.
/// Questo è un invariante che deve *sempre* essere mantenuto, anche in codice non sicuro.
/// Di conseguenza, l'inizializzazione zero di una variabile di tipo riferimento causa [undefined behavior][ub] istantaneo, indipendentemente dal fatto che quel riferimento venga mai utilizzato per accedere alla memoria:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // comportamento indefinito!⚠️
/// // Il codice equivalente con `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // comportamento indefinito!⚠️
/// ```
///
/// Questo viene sfruttato dal compilatore per varie ottimizzazioni, come l'eliminazione dei controlli in fase di esecuzione e l'ottimizzazione del layout `enum`.
///
/// Allo stesso modo, la memoria completamente non inizializzata può avere qualsiasi contenuto, mentre un `bool` deve essere sempre `true` o `false`.Quindi, la creazione di un `bool` non inizializzato è un comportamento indefinito:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // comportamento indefinito!⚠️
/// // Il codice equivalente con `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinito!⚠️
/// ```
///
/// Inoltre, la memoria non inizializzata è speciale in quanto non ha un valore fisso ("fixed" significa "it won't change without being written to").La lettura più volte dello stesso byte non inizializzato può dare risultati diversi.
/// Questo rende un comportamento indefinito avere dati non inizializzati in una variabile anche se quella variabile ha un tipo intero, che altrimenti può contenere qualsiasi schema di bit *fisso*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // comportamento indefinito!⚠️
/// // Il codice equivalente con `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // comportamento indefinito!⚠️
/// ```
/// (Si noti che le regole sugli interi non inizializzati non sono ancora state finalizzate, ma fino a quando non lo sono, è consigliabile evitarle.)
///
/// Inoltre, ricorda che la maggior parte dei tipi ha invarianti aggiuntive oltre a essere semplicemente considerata inizializzata a livello di tipo.
/// Ad esempio, un [`Vec<T>`] inizializzato con "1" è considerato inizializzato (sotto l'implementazione corrente; questo non costituisce una garanzia stabile) perché l'unico requisito che il compilatore conosce è che il puntatore ai dati deve essere non nullo.
/// La creazione di un tale `Vec<T>` non causa un comportamento *immediato* indefinito, ma causerà un comportamento indefinito con la maggior parte delle operazioni sicure (incluso il rilascio).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` serve per abilitare il codice non sicuro per gestire i dati non inizializzati.
/// È un segnale al compilatore che indica che i dati qui potrebbero *non* essere inizializzati:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Crea un riferimento esplicitamente non inizializzato.
/// // Il compilatore sa che i dati all'interno di un `MaybeUninit<T>` potrebbero non essere validi, e quindi questo non è UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Impostalo su un valore valido.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Estrai i dati inizializzati-questo è consentito solo *dopo* aver inizializzato correttamente `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Il compilatore sa quindi di non fare ipotesi o ottimizzazioni errate su questo codice.
///
/// Puoi pensare a `MaybeUninit<T>` come un po 'come `Option<T>` ma senza alcun monitoraggio del tempo di esecuzione e senza alcun controllo di sicurezza.
///
/// ## out-pointers
///
/// Puoi usare `MaybeUninit<T>` per implementare "out-pointers": invece di restituire dati da una funzione, passagli un puntatore a una memoria (uninitialized) in cui inserire il risultato.
/// Ciò può essere utile quando è importante per il chiamante controllare come viene allocata la memoria in cui è archiviato il risultato e si desidera evitare spostamenti non necessari.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` non rilascia i vecchi contenuti, il che è importante.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ora sappiamo che `v` è inizializzato!Questo assicura anche che vector venga lasciato cadere correttamente.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inizializzazione di un array elemento per elemento
///
/// `MaybeUninit<T>` può essere utilizzato per inizializzare un grande array elemento per elemento:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Crea un array non inizializzato di `MaybeUninit`.
///     // L `assume_init` è sicuro perché il tipo che stiamo affermando di aver inizializzato qui è un mucchio di "ForseUninit", che non richiedono inizializzazione.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Far cadere un `MaybeUninit` non fa nulla.
///     // Pertanto, l'utilizzo dell'assegnazione del puntatore non elaborato al posto di `ptr::write` non causa l'eliminazione del vecchio valore non inizializzato.
/////
///     // Inoltre, se c'è un panic durante questo ciclo, abbiamo una perdita di memoria, ma non ci sono problemi di sicurezza della memoria.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Tutto è inizializzato.
///     // Trasmuta l'array nel tipo inizializzato.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// È inoltre possibile lavorare con array parzialmente inizializzati, che potrebbero essere trovati in strutture dati di basso livello.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Crea un array non inizializzato di `MaybeUninit`.
/// // L `assume_init` è sicuro perché il tipo che stiamo affermando di aver inizializzato qui è un mucchio di "ForseUninit", che non richiedono inizializzazione.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Conta il numero di elementi che abbiamo assegnato.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Per ogni elemento nell'array, rilascia se lo abbiamo allocato.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inizializzazione di una struttura campo per campo
///
/// È possibile utilizzare `MaybeUninit<T>` e la macro [`std::ptr::addr_of_mut`] per inizializzare le strutture campo per campo:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inizializzazione del campo `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inizializzazione del campo `list` Se qui è presente uno panic, l `String` nel campo `name` perde.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Tutti i campi sono inizializzati, quindi chiamiamo `assume_init` per ottenere un Foo inizializzato.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` è garantito che abbia le stesse dimensioni, allineamento e ABI di `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tuttavia, ricorda che un tipo *contenente* un `MaybeUninit<T>` non è necessariamente lo stesso layout;Rust non garantisce in generale che i campi di un `Foo<T>` abbiano lo stesso ordine di un `Foo<U>` anche se `T` e `U` hanno la stessa dimensione e allineamento.
///
/// Inoltre, poiché qualsiasi valore di bit è valido per un `MaybeUninit<T>`, il compilatore non può applicare ottimizzazioni non-zero/niche-filling, risultando potenzialmente in una dimensione maggiore:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Se `T` è FFI-safe, lo è anche `MaybeUninit<T>`.
///
/// Sebbene `MaybeUninit` sia `#[repr(transparent)]` (indicando che garantisce le stesse dimensioni, allineamento e ABI di `T`), ciò *non* modifica nessuno dei precedenti avvertimenti.
/// `Option<T>` e `Option<MaybeUninit<T>>` possono ancora avere dimensioni diverse e i tipi contenenti un campo di tipo `T` possono essere disposti (e dimensionati) in modo diverso rispetto a se quel campo fosse `MaybeUninit<T>`.
/// `MaybeUninit` è un tipo di unione e `#[repr(transparent)]` su unioni è instabile (vedere [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Nel tempo, le garanzie esatte di `#[repr(transparent)]` sui sindacati possono evolversi e `MaybeUninit` può o meno rimanere `#[repr(transparent)]`.
/// Detto questo, `MaybeUninit<T>` garantirà *sempre* di avere le stesse dimensioni, allineamento e ABI di `T`;è solo che il modo in cui `MaybeUninit` implementa quella garanzia può evolversi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Oggetto Lang in modo che possiamo avvolgere altri tipi in esso.Questo è utile per i generatori.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Non chiamando `T::clone()`, non possiamo sapere se siamo abbastanza inizializzati per questo.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Crea un nuovo `MaybeUninit<T>` inizializzato con il valore dato.
    /// È sicuro chiamare [`assume_init`] sul valore di ritorno di questa funzione.
    ///
    /// Nota che il rilascio di un `MaybeUninit<T>` non chiamerà mai il codice di rilascio di `T`.
    /// È tua responsabilità assicurarti che `T` venga eliminato se è stato inizializzato.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Crea un nuovo `MaybeUninit<T>` in uno stato non inizializzato.
    ///
    /// Nota che il rilascio di un `MaybeUninit<T>` non chiamerà mai il codice di rilascio di `T`.
    /// È tua responsabilità assicurarti che `T` venga eliminato se è stato inizializzato.
    ///
    /// Vedi l [type-level documentation][MaybeUninit] per alcuni esempi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Crea un nuovo array di elementi `MaybeUninit<T>`, in uno stato non inizializzato.
    ///
    /// Note: in una versione future Rust questo metodo potrebbe diventare non necessario quando la sintassi letterale dell'array consente [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// L'esempio seguente potrebbe quindi utilizzare `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Restituisce una porzione di dati (possibilmente più piccola) che è stata effettivamente letta
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SICUREZZA: è valido un `[MaybeUninit<_>; LEN]` non inizializzato.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Crea un nuovo `MaybeUninit<T>` in uno stato non inizializzato, con la memoria riempita con byte `0`.Dipende da `T` se questo fa già per una corretta inizializzazione.
    ///
    /// Ad esempio, `MaybeUninit<usize>::zeroed()` è inizializzato, ma `MaybeUninit<&'static i32>::zeroed()` non lo è perché i riferimenti non devono essere nulli.
    ///
    /// Nota che il rilascio di un `MaybeUninit<T>` non chiamerà mai il codice di rilascio di `T`.
    /// È tua responsabilità assicurarti che `T` venga eliminato se è stato inizializzato.
    ///
    /// # Example
    ///
    /// Uso corretto di questa funzione: inizializzazione di una struttura con zero, dove tutti i campi della struttura possono contenere il modello di bit 0 come valore valido.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Uso errato* di questa funzione: chiamare `x.zeroed().assume_init()` quando `0` non è un modello di bit valido per il tipo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // All'interno di una coppia, creiamo un `NotZero` che non ha un discriminante valido.
    /// // Questo è un comportamento indefinito.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SICUREZZA: `u.as_mut_ptr()` punta alla memoria allocata.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Imposta il valore di `MaybeUninit<T>`.
    /// Questo sovrascrive qualsiasi valore precedente senza rilasciarlo, quindi fai attenzione a non usarlo due volte a meno che tu non voglia saltare l'esecuzione del distruttore.
    ///
    /// Per comodità, questo restituisce anche un riferimento modificabile al contenuto (ora inizializzato in modo sicuro) di `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SICUREZZA: abbiamo appena inizializzato questo valore.
        unsafe { self.assume_init_mut() }
    }

    /// Ottiene un puntatore al valore contenuto.
    /// Leggere da questo puntatore o trasformarlo in un riferimento è un comportamento indefinito a meno che l `MaybeUninit<T>` non sia inizializzato.
    /// Scrivere in memoria a cui punta questo puntatore (non-transitively) è un comportamento indefinito (tranne all'interno di un `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea un riferimento nell `MaybeUninit<T>`.Va bene perché lo abbiamo inizializzato.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Utilizzo errato* di questo metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Abbiamo creato un riferimento a un vector non inizializzato!Questo è un comportamento indefinito.⚠️
    /// ```
    ///
    /// (Si noti che le regole sui riferimenti a dati non inizializzati non sono ancora state finalizzate, ma fino a quando non lo sono, è consigliabile evitarle.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` e `ManuallyDrop` sono entrambi `repr(transparent)` quindi possiamo lanciare il puntatore.
        self as *const _ as *const T
    }

    /// Ottiene un puntatore modificabile al valore contenuto.
    /// Leggere da questo puntatore o trasformarlo in un riferimento è un comportamento indefinito a meno che l `MaybeUninit<T>` non sia inizializzato.
    ///
    /// # Examples
    ///
    /// Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Crea un riferimento nell `MaybeUninit<Vec<u32>>`.
    /// // Va bene perché lo abbiamo inizializzato.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Utilizzo errato* di questo metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Abbiamo creato un riferimento a un vector non inizializzato!Questo è un comportamento indefinito.⚠️
    /// ```
    ///
    /// (Si noti che le regole sui riferimenti a dati non inizializzati non sono ancora state finalizzate, ma fino a quando non lo sono, è consigliabile evitarle.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` e `ManuallyDrop` sono entrambi `repr(transparent)` quindi possiamo lanciare il puntatore.
        self as *mut _ as *mut T
    }

    /// Estrae il valore dal contenitore `MaybeUninit<T>`.Questo è un ottimo modo per garantire che i dati vengano eliminati, poiché l `T` risultante è soggetto alla normale gestione delle cadute.
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che l `MaybeUninit<T>` sia realmente in uno stato inizializzato.Chiamarlo quando il contenuto non è ancora completamente inizializzato causa un comportamento immediato non definito.
    /// L [type-level documentation][inv] contiene ulteriori informazioni su questa invariante di inizializzazione.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Inoltre, ricorda che la maggior parte dei tipi ha invarianti aggiuntive oltre a essere semplicemente considerata inizializzata a livello di tipo.
    /// Ad esempio, un [`Vec<T>`] inizializzato con "1" è considerato inizializzato (sotto l'implementazione corrente; questo non costituisce una garanzia stabile) perché l'unico requisito che il compilatore conosce è che il puntatore ai dati deve essere non nullo.
    ///
    /// La creazione di un tale `Vec<T>` non causa un comportamento *immediato* indefinito, ma causerà un comportamento indefinito con la maggior parte delle operazioni sicure (incluso il rilascio).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Utilizzo errato* di questo metodo:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` non era stato ancora inizializzato, quindi quest'ultima riga ha causato un comportamento indefinito.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SICUREZZA: il chiamante deve garantire che `self` sia inizializzato.
        // Ciò significa anche che `self` deve essere una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Legge il valore dal contenitore `MaybeUninit<T>`.L `T` risultante è soggetto alla normale gestione delle cadute.
    ///
    /// Quando possibile, è preferibile utilizzare invece [`assume_init`], che impedisce la duplicazione del contenuto di `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che l `MaybeUninit<T>` sia realmente in uno stato inizializzato.Chiamarlo quando il contenuto non è ancora completamente inizializzato causa un comportamento indefinito.
    /// L [type-level documentation][inv] contiene ulteriori informazioni su questa invariante di inizializzazione.
    ///
    /// Inoltre, questo lascia una copia degli stessi dati nell `MaybeUninit<T>`.
    /// Quando si utilizzano più copie dei dati (chiamando `assume_init_read` più volte o chiamando prima `assume_init_read` e poi [`assume_init`]), è tua responsabilità assicurarti che tali dati possano essere effettivamente duplicati.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` è `Copy`, quindi possiamo leggere più volte.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // La duplicazione di un valore `None` va bene, quindi possiamo leggere più volte.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Utilizzo errato* di questo metodo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ora abbiamo creato due copie dello stesso vector, portando a un doppio ⚠️ quando vengono rilasciati entrambi!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SICUREZZA: il chiamante deve garantire che `self` sia inizializzato.
        // La lettura da `self.as_ptr()` è sicura poiché `self` dovrebbe essere inizializzato.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Elimina il valore contenuto in posizione.
    ///
    /// Se sei proprietario di `MaybeUninit`, puoi invece utilizzare [`assume_init`].
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che l `MaybeUninit<T>` sia realmente in uno stato inizializzato.Chiamarlo quando il contenuto non è ancora completamente inizializzato causa un comportamento indefinito.
    ///
    /// Inoltre, tutti gli invarianti aggiuntivi del tipo `T` devono essere soddisfatti, poiché l'implementazione `Drop` di `T` (o dei suoi membri) può fare affidamento su questo.
    /// Ad esempio, un [`Vec<T>`] inizializzato con "1" è considerato inizializzato (sotto l'implementazione corrente; questo non costituisce una garanzia stabile) perché l'unico requisito che il compilatore conosce è che il puntatore ai dati deve essere non nullo.
    ///
    /// Tuttavia, abbandonare un `Vec<T>` di questo tipo causerà un comportamento indefinito.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SICUREZZA: il chiamante deve garantire che `self` sia inizializzato e
        // soddisfa tutte le invarianti di `T`.
        // Eliminare il valore in posizione è sicuro se questo è il caso.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Ottiene un riferimento condiviso al valore contenuto.
    ///
    /// Questo può essere utile quando vogliamo accedere a un `MaybeUninit` che è stato inizializzato ma non ha la proprietà dell `MaybeUninit` (impedendo l'uso di `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento indefinito: spetta al chiamante garantire che l `MaybeUninit<T>` sia realmente in uno stato inizializzato.
    ///
    ///
    /// # Examples
    ///
    /// ### Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inizializza `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ora che il nostro `MaybeUninit<_>` è noto per essere inizializzato, va bene creare un riferimento condiviso ad esso:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SICUREZZA: `x` è stato inizializzato.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Usi errati* di questo metodo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Abbiamo creato un riferimento a un vector non inizializzato!Questo è un comportamento indefinito.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inizializza `MaybeUninit` utilizzando `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Riferimento a un `Cell<bool>` non inizializzato: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SICUREZZA: il chiamante deve garantire che `self` sia inizializzato.
        // Ciò significa anche che `self` deve essere una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Ottiene un riferimento (unique) modificabile al valore contenuto.
    ///
    /// Questo può essere utile quando vogliamo accedere a un `MaybeUninit` che è stato inizializzato ma non ha la proprietà dell `MaybeUninit` (impedendo l'uso di `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento indefinito: spetta al chiamante garantire che l `MaybeUninit<T>` sia realmente in uno stato inizializzato.
    /// Ad esempio, `.assume_init_mut()` non può essere utilizzato per inizializzare un `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Utilizzo corretto di questo metodo:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inizializza *tutti* i byte del buffer di input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inizializza `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Ora sappiamo che `buf` è stato inizializzato, quindi potremmo `.assume_init()` esso.
    /// // Tuttavia, l'utilizzo di `.assume_init()` può attivare un `memcpy` di 2048 byte.
    /// // Per affermare che il nostro buffer è stato inizializzato senza copiarlo, aggiorniamo l `&mut MaybeUninit<[u8; 2048]>` a un `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SICUREZZA: `buf` è stato inizializzato.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Ora possiamo usare `buf` come uno slice normale:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Usi errati* di questo metodo:
    ///
    /// Non è possibile utilizzare `.assume_init_mut()` per inizializzare un valore:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Abbiamo creato un riferimento (mutable) a un `bool` non inizializzato!
    ///     // Questo è un comportamento indefinito.⚠️
    /// }
    /// ```
    ///
    /// Ad esempio, non puoi [`Read`] in un buffer non inizializzato:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) riferimento alla memoria non inizializzata!
    ///                             // Questo è un comportamento indefinito.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Né è possibile utilizzare l'accesso diretto al campo per eseguire l'inizializzazione graduale campo per campo:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) riferimento alla memoria non inizializzata!
    ///                  // Questo è un comportamento indefinito.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) riferimento alla memoria non inizializzata!
    ///                  // Questo è un comportamento indefinito.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Al momento ci basiamo sul fatto che quanto sopra sia errato, cioè abbiamo riferimenti a dati non inizializzati (ad esempio, in `libcore/fmt/float.rs`).
    // Dovremmo prendere una decisione finale sulle regole prima della stabilizzazione.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SICUREZZA: il chiamante deve garantire che `self` sia inizializzato.
        // Ciò significa anche che `self` deve essere una variante `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Estrae i valori da una matrice di contenitori `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che tutti gli elementi dell'array siano in uno stato inizializzato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SICUREZZA: ora al sicuro poiché abbiamo inizializzato tutti gli elementi
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Il chiamante garantisce che tutti gli elementi dell'array siano inizializzati
        // * `MaybeUninit<T>` e T hanno la garanzia di avere lo stesso layout
        // * ForseUnint non scende, quindi non ci sono doppi liberi E quindi la conversione è sicura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Supponendo che tutti gli elementi siano inizializzati, ottenere una sezione di essi.
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che gli elementi `MaybeUninit<T>` siano realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato causa un comportamento indefinito.
    ///
    /// Vedi [`assume_init_ref`] per maggiori dettagli ed esempi.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SICUREZZA: il casting di slice su `*const [T]` è sicuro poiché il chiamante lo garantisce
        // `slice` è inizializzato, e`MaybeUninit` è garantito per avere lo stesso layout di `T`.
        // Il puntatore ottenuto è valido in quanto si riferisce alla memoria di proprietà di `slice` che è un riferimento e quindi garantito essere valido per le letture.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Supponendo che tutti gli elementi siano inizializzati, ottieni una sezione modificabile per loro.
    ///
    /// # Safety
    ///
    /// Spetta al chiamante garantire che gli elementi `MaybeUninit<T>` siano realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato causa un comportamento indefinito.
    ///
    /// Vedi [`assume_init_mut`] per maggiori dettagli ed esempi.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SICUREZZA: simile alle note sulla sicurezza per `slice_get_ref`, ma abbiamo un file
        // riferimento mutabile che è anche garantito per essere valido per le scritture.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ottiene un puntatore al primo elemento della matrice.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ottiene un puntatore modificabile al primo elemento della matrice.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Copia gli elementi da `src` a `this`, restituendo un riferimento modificabile al contenuto ora inizializzato di `this`.
    ///
    /// Se `T` non implementa `Copy`, utilizzare [`write_slice_cloned`]
    ///
    /// Questo è simile a [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Questa funzione panic se le due fette hanno lunghezze diverse.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICUREZZA: abbiamo appena copiato tutti gli elementi di len nella capacità di riserva
    /// // i primi elementi src.len() del vec sono ora validi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SICUREZZA: &[T] e&[MaybeUninit<T>] hanno lo stesso layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SICUREZZA: gli elementi validi sono stati appena copiati in `this`, quindi è stato inizializzato
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clona gli elementi da `src` a `this`, restituendo un riferimento mutabile ai contenuti ora inizializzati di `this`.
    /// Eventuali elementi già inizializzati non verranno eliminati.
    ///
    /// Se `T` implementa `Copy`, utilizzare [`write_slice`]
    ///
    /// È simile a [`slice::clone_from_slice`] ma non elimina gli elementi esistenti.
    ///
    /// # Panics
    ///
    /// Questa funzione sarà panic se le due fette hanno lunghezze diverse, o se l'implementazione di `Clone` panics.
    ///
    /// Se è presente uno panic, gli elementi già clonati verranno eliminati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SICUREZZA: abbiamo appena clonato tutti gli elementi di len nella capacità di riserva
    /// // i primi elementi src.len() del vec sono ora validi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // a differenza di copy_from_slice, questo non chiama clone_from_slice sulla slice, questo perché `MaybeUninit<T: Clone>` non implementa Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SICUREZZA: questa fetta grezza conterrà solo oggetti inizializzati
                // ecco perché è permesso lasciarlo cadere.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Dobbiamo tagliarli esplicitamente alla stessa lunghezza
        // per eliminare il controllo dei limiti, l'ottimizzatore genererà memcpy per casi semplici (ad esempio T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // è necessario guard b/c panic potrebbe accadere durante un clone
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SICUREZZA: gli elementi validi sono stati appena scritti in `this`, quindi è stato inizializzato
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}