use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Un wrapper per impedire al compilatore di chiamare automaticamente il distruttore di `T`.
/// Questo wrapper è a costo zero.
///
/// `ManuallyDrop<T>` è soggetto alle stesse ottimizzazioni del layout di `T`.
/// Di conseguenza,*non ha effetto* sulle ipotesi che il compilatore fa sui suoi contenuti.
/// Ad esempio, l'inizializzazione di un `ManuallyDrop<&mut T>` con [`mem::zeroed`] è un comportamento indefinito.
/// Se è necessario gestire dati non inizializzati, utilizzare invece [`MaybeUninit<T>`].
///
/// Notare che l'accesso al valore all'interno di un `ManuallyDrop<T>` è sicuro.
/// Ciò significa che un `ManuallyDrop<T>` il cui contenuto è stato eliminato non deve essere esposto tramite un'API pubblica sicura.
/// Di conseguenza, `ManuallyDrop::drop` non è sicuro.
///
/// # `ManuallyDrop` e ordine di rilascio.
///
/// Rust ha un [drop order] ben definito di valori.
/// Per assicurarsi che i campi o le variabili locali vengano rilasciati in un ordine specifico, riordinare le dichiarazioni in modo che l'ordine di rilascio implicito sia quello corretto.
///
/// È possibile utilizzare `ManuallyDrop` per controllare l'ordine di rilascio, ma ciò richiede un codice non sicuro ed è difficile da eseguire correttamente in presenza di svolgimento.
///
///
/// Ad esempio, se vuoi assicurarti che un campo specifico venga rilasciato dopo gli altri, rendilo l'ultimo campo di una struttura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` verrà eliminato dopo `children`.
///     // Rust garantisce che i campi vengano eliminati nell'ordine di dichiarazione.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Avvolgi un valore da eliminare manualmente.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // È ancora possibile operare in sicurezza sul valore
    /// assert_eq!(*x, "Hello");
    /// // Ma `Drop` non verrà eseguito qui
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Estrae il valore dal contenitore `ManuallyDrop`.
    ///
    /// Ciò consente di eliminare nuovamente il valore.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Questo fa cadere l `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Prende il valore dal contenitore `ManuallyDrop<T>`.
    ///
    /// Questo metodo è principalmente inteso per spostare i valori in calo.
    /// Invece di utilizzare [`ManuallyDrop::drop`] per eliminare manualmente il valore, è possibile utilizzare questo metodo per prendere il valore e utilizzarlo come desiderato.
    ///
    /// Quando possibile, è preferibile utilizzare invece [`into_inner`][`ManuallyDrop::into_inner`], che impedisce la duplicazione del contenuto di `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Questa funzione sposta semanticamente il valore contenuto senza impedire un ulteriore utilizzo, lasciando invariato lo stato di questo contenitore.
    /// È tua responsabilità assicurarti che questo `ManuallyDrop` non venga riutilizzato.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SICUREZZA: stiamo leggendo da una referenza, che è garantita
        // per essere valido per le letture.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Elimina manualmente il valore contenuto.Ciò equivale esattamente a chiamare [`ptr::drop_in_place`] con un puntatore al valore contenuto.
    /// In quanto tale, a meno che il valore contenuto non sia uno struct compresso, il distruttore verrà chiamato sul posto senza spostare il valore e quindi può essere utilizzato per eliminare in modo sicuro i dati [pinned].
    ///
    /// Se hai la proprietà del valore, puoi invece utilizzare [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Questa funzione esegue il distruttore del valore contenuto.
    /// A parte le modifiche apportate dal distruttore stesso, la memoria rimane invariata, e quindi per quanto riguarda il compilatore conserva ancora un pattern di bit valido per il tipo `T`.
    ///
    ///
    /// Tuttavia, questo valore "zombie" non dovrebbe essere esposto a codice sicuro e questa funzione non dovrebbe essere chiamata più di una volta.
    /// Utilizzare un valore dopo che è stato eliminato o eliminare un valore più volte può causare un comportamento indefinito (a seconda di ciò che fa `drop`).
    /// Ciò è normalmente impedito dal sistema di tipi, ma gli utenti di `ManuallyDrop` devono mantenere tali garanzie senza l'assistenza del compilatore.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SICUREZZA: stiamo eliminando il valore indicato da un riferimento mutabile
        // che è garantito per essere valido per le scritture.
        // Spetta al chiamante assicurarsi che `slot` non venga nuovamente rilasciato.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}