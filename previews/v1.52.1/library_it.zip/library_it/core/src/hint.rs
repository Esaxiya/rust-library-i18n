#![stable(feature = "core_hint", since = "1.27.0")]

//! Suggerimenti per il compilatore che influiscono sul modo in cui il codice deve essere emesso o ottimizzato.
//! I suggerimenti possono essere in fase di compilazione o runtime.

use crate::intrinsics;

/// Informa il compilatore che questo punto del codice non è raggiungibile, consentendo ulteriori ottimizzazioni.
///
/// # Safety
///
/// Raggiungere questa funzione è un comportamento completamente *indefinito*(UB).In particolare, il compilatore presume che tutti gli UB non debbano mai accadere e quindi eliminerà tutti i rami che raggiungono una chiamata a `unreachable_unchecked()`.
///
/// Come tutte le istanze di UB, se questa ipotesi si rivela sbagliata, cioè, la chiamata `unreachable_unchecked()` è effettivamente raggiungibile tra tutti i possibili flussi di controllo, il compilatore applicherà la strategia di ottimizzazione sbagliata e talvolta potrebbe anche corrompere codice apparentemente non correlato, problemi di debug.
///
///
/// Usa questa funzione solo quando puoi provare che il codice non lo chiamerà mai.
/// Altrimenti, considera l'utilizzo della macro [`unreachable!`], che non consente ottimizzazioni ma panic una volta eseguita.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` è sempre positivo (non zero), quindi `checked_div` non restituirà mai `None`.
/////
///     // Pertanto, l'altro branch è irraggiungibile.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SICUREZZA: il contratto di sicurezza per `intrinsics::unreachable` deve
    // essere accolti dal chiamante.
    unsafe { intrinsics::unreachable() }
}

/// Emette un'istruzione macchina per segnalare al processore che è in esecuzione in un ciclo di rotazione di attesa occupata ("blocco di rotazione").
///
/// Dopo aver ricevuto il segnale di spin-loop, il processore può ottimizzare il suo comportamento, ad esempio, risparmiando energia o cambiando i thread hyper.
///
/// Questa funzione è diversa da [`thread::yield_now`] che cede direttamente allo scheduler del sistema, mentre `spin_loop` non interagisce con il sistema operativo.
///
/// Un caso d'uso comune per `spin_loop` è l'implementazione della rotazione ottimistica limitata in un ciclo CAS nelle primitive di sincronizzazione.
/// Per evitare problemi come l'inversione di priorità, si consiglia vivamente di terminare lo spin loop dopo un numero finito di iterazioni e dopo aver eseguito un'appropriata syscall di blocco.
///
///
/// **Nota**: sulle piattaforme che non supportano la ricezione di suggerimenti di spin-loop, questa funzione non ha alcun effetto.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Un valore atomico condiviso che i thread useranno per coordinare
/// let live = Arc::new(AtomicBool::new(false));
///
/// // In un thread in background, alla fine imposteremo il valore
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Fai un po 'di lavoro, quindi rendi vivo il valore
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tornando al thread corrente, aspettiamo che il valore venga impostato
/// while !live.load(Ordering::Acquire) {
///     // Lo spin loop è un suggerimento per la CPU che stiamo aspettando, ma probabilmente non per molto tempo
/////
///     hint::spin_loop();
/// }
///
/// // Il valore è ora impostato
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SICUREZZA: l'attr `cfg` garantisce di eseguirlo solo sui target x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SICUREZZA: l'attr `cfg` garantisce che lo eseguiamo solo sui target x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SICUREZZA: l'attr `cfg` garantisce che lo eseguiamo solo sui target aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SICUREZZA: l `cfg` attr garantisce che eseguiamo questa operazione solo sui bersagli del braccio
            // con supporto per la funzione v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Una funzione di identità che *__ suggerisce __* al compilatore di essere al massimo pessimista su ciò che `black_box` potrebbe fare.
///
/// A differenza di [`std::convert::identity`], un compilatore Rust è incoraggiato a presumere che `black_box` possa utilizzare `dummy` in ogni possibile modo valido consentito al codice Rust senza introdurre comportamenti indefiniti nel codice chiamante.
///
/// Questa proprietà rende `black_box` utile per scrivere codice in cui alcune ottimizzazioni non sono desiderate, come i benchmark.
///
/// Si noti tuttavia che `black_box` è fornito solo (e può essere) fornito solo su base "best-effort".La misura in cui può bloccare le ottimizzazioni può variare a seconda della piattaforma e del backend code-gen utilizzato.
/// I programmi non possono fare affidamento su `black_box` per la *correttezza* in alcun modo.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Abbiamo bisogno di "use" l'argomento in qualche modo LLVM non può introspettare, e sulle destinazioni che lo supportano possiamo tipicamente sfruttare l'assemblaggio in linea per farlo.
    // L'interpretazione di LLVM dell'assemblaggio in linea è che è, beh, una scatola nera.
    // Questa non è la migliore implementazione poiché probabilmente deottimizza più di quanto desideriamo, ma finora è abbastanza buona.
    //
    //

    #[cfg(not(miri))] // Questo è solo un suggerimento, quindi va bene saltare in Miri.
    // SICUREZZA: l'assemblaggio in linea è un no-op.
    unsafe {
        // FIXME: Non è possibile utilizzare `asm!` perché non supporta MIPS e altre architetture.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}