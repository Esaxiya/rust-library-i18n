//! Contenitori modificabili condivisibili.
//!
//! La sicurezza della memoria Rust si basa su questa regola: dato un oggetto `T`, è possibile avere solo uno dei seguenti:
//!
//! - Avere diversi riferimenti immutabili (`&T`) all'oggetto (noto anche come **aliasing**).
//! - Avere un riferimento mutabile (`&mut T`) all'oggetto (noto anche come **mutabilità**).
//!
//! Questo viene applicato dal compilatore Rust.Tuttavia, ci sono situazioni in cui questa regola non è abbastanza flessibile.A volte è necessario avere più riferimenti a un oggetto e tuttavia modificarlo.
//!
//! Esistono contenitori modificabili condivisibili per consentire la mutabilità in modo controllato, anche in presenza di aliasing.Sia [`Cell<T>`] che [`RefCell<T>`] consentono di farlo in un modo a thread singolo.
//! Tuttavia, né `Cell<T>` né `RefCell<T>` sono thread-safe (non implementano [`Sync`]).
//! Se è necessario eseguire l'aliasing e la mutazione tra più thread, è possibile utilizzare i tipi [`Mutex<T>`], [`RwLock<T>`] o [`atomic`].
//!
//! I valori dei tipi `Cell<T>` e `RefCell<T>` possono essere modificati tramite riferimenti condivisi (es
//! il tipo `&T` comune), mentre la maggior parte dei tipi Rust può essere modificata solo tramite riferimenti univoci (`&mut T`).
//! Diciamo che `Cell<T>` e `RefCell<T>` forniscono "mutabilità interna", in contrasto con i tipici tipi Rust che mostrano "mutabilità ereditata".
//!
//! I tipi di cellule sono disponibili in due gusti: `Cell<T>` e `RefCell<T>`.`Cell<T>` implementa la mutabilità interna spostando i valori dentro e fuori dall `Cell<T>`.
//! Per utilizzare i riferimenti al posto dei valori, è necessario utilizzare il tipo `RefCell<T>`, acquisendo un blocco di scrittura prima della mutazione.`Cell<T>` fornisce metodi per recuperare e modificare il valore interno corrente:
//!
//!  - Per i tipi che implementano [`Copy`], il metodo [`get`](Cell::get) recupera il valore interno corrente.
//!  - Per i tipi che implementano [`Default`], il metodo [`take`](Cell::take) sostituisce il valore interno corrente con [`Default::default()`] e restituisce il valore sostituito.
//!  - Per tutti i tipi, il metodo [`replace`](Cell::replace) sostituisce il valore interno corrente e restituisce il valore sostituito, mentre il metodo [`into_inner`](Cell::into_inner) consuma `Cell<T>` e restituisce il valore interno.
//!  Inoltre, il metodo [`set`](Cell::set) sostituisce il valore interno, eliminando il valore sostituito.
//!
//! `RefCell<T>` utilizza la durata di vita di Rust per implementare il "prestito dinamico", un processo in base al quale si può rivendicare un accesso temporaneo, esclusivo e mutevole al valore interiore.
//! Prende in prestito per `RefCell<T>`vengono tracciati 'in fase di esecuzione', a differenza dei tipi di riferimento nativi di Rust che sono interamente tracciati staticamente, in fase di compilazione.
//! Poiché i prestiti `RefCell<T>` sono dinamici, è possibile tentare di prendere in prestito un valore che è già mutuamente preso in prestito;quando ciò accade, si ottiene il thread panic.
//!
//! # Quando scegliere la mutevolezza interiore
//!
//! La mutabilità ereditata più comune, in cui si deve avere un accesso univoco per mutare un valore, è uno degli elementi chiave del linguaggio che consente a Rust di ragionare fortemente sull'aliasing del puntatore, prevenendo staticamente i bug di crash.
//! Per questo motivo, la mutabilità ereditata è preferita e la mutabilità interiore è l'ultima risorsa.
//! Poiché i tipi di cellule consentono la mutazione laddove altrimenti sarebbe vietata, ci sono occasioni in cui la mutabilità interna potrebbe essere appropriata, o anche *deve* essere usata, ad es.
//!
//! * Presentazione della mutabilità 'inside' di qualcosa di immutabile
//! * Dettagli di implementazione di metodi logicamente immutabili.
//! * Implementazioni mutanti di [`Clone`].
//!
//! ## Presentazione della mutabilità 'inside' di qualcosa di immutabile
//!
//! Molti tipi di puntatori intelligenti condivisi, inclusi [`Rc<T>`] e [`Arc<T>`], forniscono contenitori che possono essere clonati e condivisi tra più parti.
//! Poiché i valori contenuti possono essere alias multipli, possono essere presi in prestito solo con `&`, non con `&mut`.
//! Senza le celle sarebbe impossibile mutare i dati all'interno di questi puntatori intelligenti.
//!
//! È molto comune quindi inserire un `RefCell<T>` all'interno di tipi di puntatori condivisi per reintrodurre la mutabilità:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Crea un nuovo blocco per limitare l'ambito del prestito dinamico
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Si noti che se non avessimo lasciato che il prestito precedente della cache esulasse dall'ambito, il prestito successivo causerebbe un thread dinamico panic.
//!     //
//!     // Questo è il principale rischio dell'utilizzo di `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Notare che questo esempio utilizza `Rc<T>` e non `Arc<T>`.`RefCell<T>`s sono per scenari a thread singolo.Prendi in considerazione l'utilizzo di [`RwLock<T>`] o [`Mutex<T>`] se hai bisogno di mutabilità condivisa in una situazione multi-thread.
//!
//! ## Dettagli di implementazione di metodi logicamente immutabili
//!
//! Occasionalmente può essere desiderabile non esporre in un'API che sta avvenendo una mutazione "under the hood".
//! Ciò può essere dovuto al fatto che logicamente l'operazione è immutabile, ma ad esempio, la memorizzazione nella cache forza l'implementazione a eseguire la mutazione;o perché è necessario utilizzare la mutazione per implementare un metodo trait originariamente definito per accettare `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Il calcolo costoso va qui
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implementazioni mutanti di `Clone`
//!
//! Questo è semplicemente un caso speciale, ma comune, del precedente: nascondere la mutabilità per operazioni che sembrano essere immutabili.
//! Si prevede che il metodo [`clone`](Clone::clone) non modifichi il valore di origine e viene dichiarato che accetta `&self`, non `&mut self`.
//! Pertanto, qualsiasi mutazione che si verifica nel metodo `clone` deve utilizzare i tipi di cellule.
//! Ad esempio, [`Rc<T>`] mantiene i suoi conteggi di riferimento all'interno di un `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Una posizione di memoria mutevole.
///
/// # Examples
///
/// In questo esempio, puoi vedere che `Cell<T>` abilita la mutazione all'interno di una struttura immutabile.
/// In altre parole, abilita "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERRORE: `my_struct` non è modificabile
/// // my_struct.regular_field =new_value;
///
/// // FUNZIONA: sebbene `my_struct` sia immutabile, `special_field` è un `Cell`,
/// // che può sempre essere mutato
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Vedi l [module-level documentation](self) per ulteriori informazioni.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Crea un `Cell<T>`, con il valore `Default` per T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Crea un nuovo `Cell` contenente il valore specificato.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Imposta il valore contenuto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Scambia i valori di due celle.
    /// La differenza con `std::mem::swap` è che questa funzione non richiede il riferimento `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SICUREZZA: questo può essere rischioso se chiamato da thread separati, ma `Cell`
        // è `!Sync` quindi questo non accadrà.
        // Anche questo non invaliderà alcun puntatore poiché `Cell` si assicura che nient'altro punti a nessuna di queste celle.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Sostituisce il valore contenuto con `val` e restituisce il vecchio valore contenuto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SICUREZZA: questo può causare gare di dati se chiamato da un thread separato,
        // ma `Cell` è `!Sync` quindi questo non accadrà.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Scarta il valore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Restituisce una copia del valore contenuto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SICUREZZA: questo può causare gare di dati se chiamato da un thread separato,
        // ma `Cell` è `!Sync` quindi questo non accadrà.
        unsafe { *self.value.get() }
    }

    /// Aggiorna il valore contenuto utilizzando una funzione e restituisce il nuovo valore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Restituisce un puntatore non elaborato ai dati sottostanti in questa cella.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Restituisce un riferimento modificabile ai dati sottostanti.
    ///
    /// Questa chiamata prende in prestito `Cell` in modo mutevole (in fase di compilazione), il che garantisce di possedere l'unico riferimento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Restituisce un `&Cell<T>` da un `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SICUREZZA: `&mut` garantisce un accesso unico.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Prende il valore della cella, lasciando `Default::default()` al suo posto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Restituisce un `&[Cell<T>]` da un `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SICUREZZA: `Cell<T>` ha lo stesso layout di memoria di `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Una posizione di memoria mutevole con regole di prestito controllate dinamicamente
///
/// Vedi l [module-level documentation](self) per ulteriori informazioni.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Un errore restituito da [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Un errore restituito da [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// I valori positivi rappresentano il numero di `Ref` attivi.I valori negativi rappresentano il numero di `RefMut` attivi.
// Più `RefMut` possono essere attivi contemporaneamente solo se si riferiscono a componenti distinti e non sovrapposti di un `RefCell` (ad esempio, intervalli diversi di uno slice).
//
// `Ref` e `RefMut` hanno entrambe le dimensioni di due parole, quindi probabilmente non ci saranno mai abbastanza `Ref`s o`RefMut`s esistenti per superare la metà dell'intervallo `usize`.
// Pertanto, un `BorrowFlag` probabilmente non andrà mai in overflow o underflow.
// Tuttavia, questa non è una garanzia, poiché un programma patologico potrebbe creare ripetutamente e quindi mem::forget `Ref`s o`RefMut`s.
// Pertanto, tutto il codice deve controllare esplicitamente l'overflow e l'underflow per evitare unsafety, o almeno comportarsi correttamente nel caso in cui si verifichi un overflow o un underflow (ad esempio, vedere BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Crea un nuovo `RefCell` contenente `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Consuma `RefCell`, restituendo il valore avvolto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Poiché questa funzione accetta `self` (`RefCell`) per valore, il compilatore verifica staticamente che non sia attualmente preso in prestito.
        //
        self.value.into_inner()
    }

    /// Sostituisce il valore avvolto con uno nuovo, restituendo il vecchio valore, senza deinizializzare nessuno dei due.
    ///
    ///
    /// Questa funzione corrisponde a [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics se il valore è attualmente preso in prestito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Sostituisce il valore avvolto con uno nuovo calcolato da `f`, restituendo il vecchio valore, senza deinizializzare nessuno dei due.
    ///
    ///
    /// # Panics
    ///
    /// Panics se il valore è attualmente preso in prestito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Scambia il valore avvolto di `self` con il valore avvolto di `other`, senza deinizializzare nessuno dei due.
    ///
    ///
    /// Questa funzione corrisponde a [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Immutabilmente prende in prestito il valore impacchettato.
    ///
    /// Il prestito dura fino a quando l `Ref` restituito non esce dall'ambito.
    /// È possibile contrarre più prestiti immutabili contemporaneamente.
    ///
    /// # Panics
    ///
    /// Panics se il valore è attualmente mutuamente preso in prestito.
    /// Per una variante senza panico, usa [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Un esempio di panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Prende in prestito immutabilmente il valore avvolto, restituendo un errore se il valore è attualmente mutuamente preso in prestito.
    ///
    ///
    /// Il prestito dura fino a quando l `Ref` restituito non esce dall'ambito.
    /// È possibile contrarre più prestiti immutabili contemporaneamente.
    ///
    /// Questa è la variante senza panico di [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SICUREZZA: `BorrowRef` garantisce che ci sia solo un accesso immutabile
            // al valore durante il prestito.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutuamente prende in prestito il valore impacchettato.
    ///
    /// Il prestito dura fino a quando l `RefMut` restituito o tutti i `RefMut` derivati da esso escono dall'ambito.
    ///
    /// Il valore non può essere preso in prestito mentre questo prestito è attivo.
    ///
    /// # Panics
    ///
    /// Panics se il valore è attualmente preso in prestito.
    /// Per una variante senza panico, usa [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Un esempio di panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Mutuamente prende in prestito il valore avvolto, restituendo un errore se il valore è attualmente preso in prestito.
    ///
    ///
    /// Il prestito dura fino a quando l `RefMut` restituito o tutti i `RefMut` derivati da esso escono dall'ambito.
    /// Il valore non può essere preso in prestito mentre questo prestito è attivo.
    ///
    /// Questa è la variante senza panico di [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SICUREZZA: `BorrowRef` garantisce un accesso unico.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Restituisce un puntatore non elaborato ai dati sottostanti in questa cella.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Restituisce un riferimento modificabile ai dati sottostanti.
    ///
    /// Questa chiamata prende in prestito `RefCell` in modo mutevole (in fase di compilazione) quindi non c'è bisogno di controlli dinamici.
    ///
    /// Tuttavia sii cauto: questo metodo prevede che `self` sia mutabile, il che generalmente non è il caso quando si utilizza un `RefCell`.
    ///
    /// Dai un'occhiata al metodo [`borrow_mut`] invece se `self` non è modificabile.
    ///
    /// Inoltre, tieni presente che questo metodo è solo per circostanze speciali e di solito non è quello che desideri.
    /// In caso di dubbio, usa invece [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Annulla l'effetto delle guardie trapelate sullo stato di prestito dell `RefCell`.
    ///
    /// Questa chiamata è simile a [`get_mut`] ma più specializzata.
    /// Prende in prestito `RefCell` in modo mutevole per garantire che non esistano prestiti e quindi ripristina lo stato che tiene traccia dei prestiti condivisi.
    /// Ciò è rilevante se alcuni prestiti `Ref` o `RefMut` sono trapelati.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Prende in prestito immutabilmente il valore avvolto, restituendo un errore se il valore è attualmente mutuamente preso in prestito.
    ///
    /// # Safety
    ///
    /// A differenza di `RefCell::borrow`, questo metodo non è sicuro perché non restituisce un `Ref`, lasciando così intatto il flag di prestito.
    /// Prendere mutuamente in prestito l `RefCell` mentre il riferimento restituito da questo metodo è attivo è un comportamento indefinito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SICUREZZA: Controlliamo che nessuno stia scrivendo attivamente ora, ma lo è
            // la responsabilità del chiamante di assicurarsi che nessuno scriva fino a quando il riferimento restituito non è più in uso.
            // Inoltre, `self.value.get()` si riferisce al valore posseduto da `self` ed è quindi garantito che sarà valido per la durata di `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Prende il valore avvolto, lasciando `Default::default()` al suo posto.
    ///
    /// # Panics
    ///
    /// Panics se il valore è attualmente preso in prestito.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics se il valore è attualmente mutuamente preso in prestito.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Crea un `RefCell<T>`, con il valore `Default` per T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics se il valore in `RefCell` è attualmente preso in prestito.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // L'aumento del prestito può comportare un valore non di lettura (<=0) in questi casi:
            // 1. Era <0, ovvero ci sono prestiti in scrittura, quindi non possiamo consentire un prestito in lettura a causa delle regole di alias di riferimento di Rust
            // 2.
            // Era isize::MAX (la quantità massima di prestiti in lettura) ed è andato in overflow in isize::MIN (l'importo massimo di prestiti in scrittura) quindi non possiamo consentire un prestito in lettura aggiuntivo perché isize non può rappresentare così tanti prestiti in lettura (questo può accadere solo se si mem::forget più di una piccola quantità costante di `Ref`, che non è una buona pratica)
            //
            //
            //
            //
            None
        } else {
            // L'aumento del prestito può comportare un valore di lettura (> 0) in questi casi:
            // 1. Era=0, cioè non è stato preso in prestito e stiamo prendendo il primo prestito di lettura
            // 2. Era> 0 e <isize::MAX, cioè
            // ci sono stati prestiti in lettura e isize è abbastanza grande da rappresentare l'avere un prestito in più in lettura
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Poiché questo riferimento esiste, sappiamo che il flag di prestito è un prestito di lettura.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Impedire che il contatore dei prestiti trabocchi in un prestito scritto.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Avvolge un riferimento preso in prestito a un valore in una scatola `RefCell`.
/// Un tipo di wrapper per un valore preso in prestito immutabilmente da un `RefCell<T>`.
///
/// Vedi l [module-level documentation](self) per ulteriori informazioni.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Copia un `Ref`.
    ///
    /// L `RefCell` è già immutabilmente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `Ref::clone(...)`.
    /// Un'implementazione o un metodo `Clone` interferirebbe con l'uso diffuso di `r.borrow().clone()` per clonare il contenuto di un `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Crea un nuovo `Ref` per un componente dei dati presi in prestito.
    ///
    /// L `RefCell` è già immutabilmente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `Ref::map(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Crea un nuovo `Ref` per un componente opzionale dei dati presi in prestito.
    /// La protezione originale viene restituita come `Err(..)` se la chiusura restituisce `None`.
    ///
    /// L `RefCell` è già immutabilmente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `Ref::filter_map(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Divide un `Ref` in più `Ref` per diversi componenti dei dati presi in prestito.
    ///
    /// L `RefCell` è già immutabilmente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `Ref::map_split(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Converti in un riferimento ai dati sottostanti.
    ///
    /// L `RefCell` sottostante non potrà mai essere mutuamente preso in prestito di nuovo e apparirà sempre già immutabilmente preso in prestito.
    ///
    /// Non è una buona idea trapelare più di un numero costante di riferimenti.
    /// L `RefCell` può essere nuovamente preso in prestito in modo immutabile se si è verificato solo un numero inferiore di perdite in totale.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `Ref::leak(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Dimenticando questo riferimento, ci assicuriamo che il contatore dei prestiti in RefCell non possa tornare a NON UTILIZZATO entro la durata `'b`.
        // La reimpostazione dello stato di rilevamento dei riferimenti richiederebbe un riferimento univoco al RefCell preso in prestito.
        // Non è possibile creare ulteriori riferimenti modificabili dalla cella originale.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Crea un nuovo `RefMut` per un componente dei dati presi in prestito, ad esempio una variante enum.
    ///
    /// L `RefCell` è già mutuamente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `RefMut::map(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): fissare il controllo del prestito
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Crea un nuovo `RefMut` per un componente opzionale dei dati presi in prestito.
    /// La protezione originale viene restituita come `Err(..)` se la chiusura restituisce `None`.
    ///
    /// L `RefCell` è già mutuamente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `RefMut::filter_map(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): fissare il controllo del prestito
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SICUREZZA: la funzione mantiene un riferimento esclusivo per la durata
        // della sua chiamata tramite `orig` e il puntatore viene de-referenziato solo all'interno della chiamata di funzione, non consentendo mai al riferimento esclusivo di sfuggire.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SICUREZZA: come sopra.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Divide un `RefMut` in più `RefMut` per diversi componenti dei dati presi in prestito.
    ///
    /// L `RefCell` sottostante rimarrà mutuamente preso in prestito fino a quando entrambi i `RefMut` restituiti non usciranno dall'ambito.
    ///
    /// L `RefCell` è già mutuamente preso in prestito, quindi non può fallire.
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `RefMut::map_split(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Converti in un riferimento modificabile ai dati sottostanti.
    ///
    /// L `RefCell` sottostante non potrà essere nuovamente preso in prestito e apparirà sempre mutuamente mutuamente mutuato, rendendo l'unico riferimento all'interno restituito.
    ///
    ///
    /// Questa è una funzione associata che deve essere utilizzata come `RefMut::leak(...)`.
    /// Un metodo interferirebbe con metodi con lo stesso nome sul contenuto di un `RefCell` utilizzato tramite `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Dimenticando questo BorrowRefMut ci assicuriamo che il contatore dei prestiti in RefCell non possa tornare a NON UTILIZZATO entro la durata `'b`.
        // La reimpostazione dello stato di rilevamento dei riferimenti richiederebbe un riferimento univoco al RefCell preso in prestito.
        // Non è possibile creare ulteriori riferimenti dalla cella originale entro quella durata, rendendo il prestito corrente l'unico riferimento per la durata rimanente.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: A differenza di BorrowRefMut::clone, new viene chiamato per creare l'iniziale
        // riferimento mutabile, quindi al momento non devono esserci riferimenti esistenti.
        // Quindi, mentre clone incrementa il refcount mutabile, qui consentiamo esplicitamente solo di passare da UNUSED a UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Clona un `BorrowRefMut`.
    //
    // Ciò è valido solo se ogni `BorrowRefMut` viene utilizzato per tenere traccia di un riferimento modificabile a un intervallo distinto e non sovrapposto dell'oggetto originale.
    //
    // Questo non è in un clone impl, quindi il codice non lo chiama implicitamente.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Evita che il contatore dei prestiti sia insufficiente.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Un tipo di wrapper per un valore mutuamente preso in prestito da un `RefCell<T>`.
///
/// Vedi l [module-level documentation](self) per ulteriori informazioni.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// La primitiva principale per la mutabilità interna in Rust.
///
/// Se si dispone di un riferimento `&T`, normalmente in Rust il compilatore esegue ottimizzazioni in base alla consapevolezza che `&T` punta a dati immutabili.La modifica di tali dati, ad esempio tramite un alias o trasmutando un `&T` in un `&mut T`, è considerato un comportamento indefinito.
/// `UnsafeCell<T>` disattiva la garanzia di immutabilità per `&T`: un riferimento condiviso `&UnsafeCell<T>` può puntare a dati che vengono mutati.Questo si chiama "interior mutability".
///
/// Tutti gli altri tipi che consentono la mutabilità interna, come `Cell<T>` e `RefCell<T>`, utilizzano internamente `UnsafeCell` per racchiudere i propri dati.
///
/// Notare che solo la garanzia di immutabilità per i riferimenti condivisi è influenzata da `UnsafeCell`.La garanzia di unicità per i riferimenti modificabili rimane inalterata.Non esiste *alcun* modo legale per ottenere l'aliasing `&mut`, nemmeno con `UnsafeCell<T>`.
///
/// La stessa API `UnsafeCell` è tecnicamente molto semplice: [`.get()`] ti fornisce un puntatore grezzo `*mut T` al suo contenuto.Spetta a _you_ come progettista di astrazioni usare correttamente quel puntatore grezzo.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Le precise regole di aliasing Rust sono in qualche modo mutate, ma i punti principali non sono controversi:
///
/// - Se crei un riferimento sicuro con `'a` a vita (un riferimento `&T` o `&mut T`) accessibile tramite codice sicuro (ad esempio, perché lo hai restituito), non devi accedere ai dati in alcun modo che contraddica quel riferimento per il resto di `'a`.
/// Ad esempio, questo significa che se si prende l `*mut T` da un `UnsafeCell<T>` e lo si trasmette a un `&T`, i dati in `T` devono rimanere immutabili (modulo qualsiasi dato `UnsafeCell` trovato all'interno di `T`, ovviamente) fino alla scadenza della durata di quel riferimento.
/// Allo stesso modo, se crei un riferimento `&mut T` che viene rilasciato al codice sicuro, non devi accedere ai dati all'interno di `UnsafeCell` fino alla scadenza del riferimento.
///
/// - In ogni momento, è necessario evitare gare di dati.Se più thread hanno accesso allo stesso `UnsafeCell`, tutte le scritture devono avere una corretta relazione accade prima di tutti gli altri accessi (o utilizzare atomici).
///
/// Per facilitare la progettazione corretta, i seguenti scenari sono dichiarati esplicitamente legali per il codice a thread singolo:
///
/// 1. Un riferimento `&T` può essere rilasciato a codice sicuro e lì può coesistere con altri riferimenti `&T`, ma non con un `&mut T`
///
/// 2. Un riferimento `&mut T` può essere rilasciato al codice sicuro a condizione che non coesistano altri `&mut T` o `&T` con esso.Un `&mut T` deve essere sempre unico.
///
/// Si noti che mentre si modifica il contenuto di un `&UnsafeCell<T>` (anche mentre altri `&UnsafeCell<T>` fanno riferimento alias della cella) è ok (a condizione di applicare le invarianti di cui sopra in qualche altro modo), è ancora un comportamento indefinito avere più alias `&mut UnsafeCell<T>`.
/// Ovvero, `UnsafeCell` è un wrapper progettato per avere una speciale interazione con _shared_ accesses (_i.e._, tramite un riferimento `&UnsafeCell<_>`);non c'è nessuna magia quando si ha a che fare con _exclusive_ accesses (_e.g._, tramite un `&mut UnsafeCell<_>`): né la cella né il valore avvolto possono essere alias per la durata di quel prestito `&mut`.
///
/// Questo è mostrato dall'accessor [`.get_mut()`], che è un _safe_ getter che produce un `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Ecco un esempio che mostra come modificare in modo corretto il contenuto di un `UnsafeCell<_>` nonostante siano presenti più riferimenti alias della cella:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ottieni riferimenti multipli/condivisi allo stesso `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SICUREZZA: in questo ambito non ci sono altri riferimenti ai contenuti di `x`,
///     // quindi il nostro è effettivamente unico.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- prendere in prestito-+
///     *p1_exclusive += 27; // |
/// } // <---------- non può andare oltre questo punto -------------------+
///
/// unsafe {
///     // SICUREZZA: in questo ambito nessuno si aspetta di avere accesso esclusivo ai contenuti di `x`,
///     // così possiamo avere più accessi condivisi contemporaneamente.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Il seguente esempio mostra il fatto che l'accesso esclusivo a un `UnsafeCell<T>` implica l'accesso esclusivo al suo `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // con accessi esclusivi,
///                         // `UnsafeCell` è un wrapper no-op trasparente, quindi non c'è bisogno di `unsafe` qui.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Ottieni un riferimento univoco controllato in fase di compilazione a `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Con un riferimento esclusivo, possiamo modificare i contenuti gratuitamente.
/// *p_unique.get_mut() = 0;
/// // Oppure, equivalentemente:
/// x = UnsafeCell::new(0);
///
/// // Quando possediamo il valore, possiamo estrarre il contenuto gratuitamente.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Costruisce una nuova istanza di `UnsafeCell` che avvolgerà il valore specificato.
    ///
    ///
    /// Tutti gli accessi al valore interno tramite i metodi sono `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Scarta il valore.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Ottiene un puntatore modificabile al valore avvolto.
    ///
    /// Questo può essere lanciato a un puntatore di qualsiasi tipo.
    /// Assicurati che l'accesso sia univoco (nessun riferimento attivo, modificabile o meno) quando esegui il casting su `&mut T` e assicurati che non ci siano mutazioni o alias modificabili in corso durante il casting su `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Possiamo semplicemente lanciare il puntatore da `UnsafeCell<T>` a `T` a causa di #[repr(transparent)].
        // Questo sfrutta lo stato speciale di libstd, non c'è garanzia per il codice utente che funzioni nelle versioni future del compilatore!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Restituisce un riferimento modificabile ai dati sottostanti.
    ///
    /// Questa chiamata prende in prestito l `UnsafeCell` in modo mutevole (in fase di compilazione), il che garantisce di possedere l'unico riferimento.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Ottiene un puntatore modificabile al valore avvolto.
    /// La differenza con [`get`] è che questa funzione accetta un puntatore grezzo, utile per evitare la creazione di riferimenti temporanei.
    ///
    /// Il risultato può essere lanciato a un puntatore di qualsiasi tipo.
    /// Assicurati che l'accesso sia univoco (nessun riferimento attivo, modificabile o meno) quando esegui il casting su `&mut T` e assicurati che non ci siano mutazioni o alias modificabili in corso durante il casting su `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// L'inizializzazione graduale di un `UnsafeCell` richiede `raw_get`, poiché la chiamata a `get` richiederebbe la creazione di un riferimento a dati non inizializzati:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Possiamo semplicemente lanciare il puntatore da `UnsafeCell<T>` a `T` a causa di #[repr(transparent)].
        // Questo sfrutta lo stato speciale di libstd, non c'è garanzia per il codice utente che funzioni nelle versioni future del compilatore!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Crea un `UnsafeCell`, con il valore `Default` per T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}