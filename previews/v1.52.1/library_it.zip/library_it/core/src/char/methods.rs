//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Il punto di codice valido più alto che un `char` può avere.
    ///
    /// Un `char` è un [Unicode Scalar Value], il che significa che è un [Code Point], ma solo quelli entro un certo intervallo.
    /// `MAX` è il punto di codice valido più alto che è un [Unicode Scalar Value] valido.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () viene utilizzato in Unicode per rappresentare un errore di decodifica.
    ///
    /// Può verificarsi, ad esempio, quando si forniscono byte UTF-8 mal formati a [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// La versione di [Unicode](http://www.unicode.org/) su cui si basano le parti Unicode dei metodi `char` e `str`.
    ///
    /// Nuove versioni di Unicode vengono rilasciate regolarmente e successivamente tutti i metodi nella libreria standard che dipendono da Unicode vengono aggiornati.
    /// Pertanto il comportamento di alcuni metodi `char` e `str` e il valore di questa costante cambia nel tempo.
    /// Questo *non* è considerato un cambiamento radicale.
    ///
    /// Lo schema di numerazione delle versioni è spiegato in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Crea un iteratore sui punti di codice codificati UTF-16 in `iter`, restituendo surrogati non accoppiati come `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Un decodificatore con perdita può essere ottenuto sostituendo i risultati `Err` con il carattere di sostituzione:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Converte un `u32` in un `char`.
    ///
    /// Nota che tutti i caratteri sono validi [`u32`] e possono essere convertiti in uno con
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuttavia, non è vero il contrario: non tutti i [`u32`] validi sono validi`char`s.
    /// `from_u32()` restituirà `None` se l'input non è un valore valido per `char`.
    ///
    /// Per una versione non sicura di questa funzione che ignora questi controlli, vedere [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Restituzione di `None` quando l'input non è un `char` valido:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Converte un `u32` in un `char`, ignorando la validità.
    ///
    /// Nota che tutti i caratteri sono validi [`u32`] e possono essere convertiti in uno con
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tuttavia, non è vero il contrario: non tutti i [`u32`] validi sono validi`char`s.
    /// `from_u32_unchecked()` lo ignorerà e farà il cast ciecamente a `char`, possibilmente creandone uno non valido.
    ///
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura, poiché potrebbe creare valori `char` non validi.
    ///
    /// Per una versione sicura di questa funzione, vedere la funzione [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SICUREZZA: il contratto di sicurezza deve essere mantenuto dal chiamante.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Converte una cifra nella radice data in un `char`.
    ///
    /// Un 'radix' qui a volte è anche chiamato 'base'.
    /// Una radice di due indica un numero binario, una radice di dieci, decimale e una radice di sedici, esadecimale, per fornire alcuni valori comuni.
    ///
    /// Le radici arbitrarie sono supportate.
    ///
    /// `from_digit()` restituirà `None` se l'input non è una cifra nella radice data.
    ///
    /// # Panics
    ///
    /// Panics se data una radice maggiore di 36.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Il decimale 11 è una singola cifra in base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Restituzione di `None` quando l'input non è una cifra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Passando un grande radix, provocando un panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Controlla se un `char` è una cifra nella radice data.
    ///
    /// Un 'radix' qui a volte è anche chiamato 'base'.
    /// Una radice di due indica un numero binario, una radice di dieci, decimale e una radice di sedici, esadecimale, per fornire alcuni valori comuni.
    ///
    /// Le radici arbitrarie sono supportate.
    ///
    /// Rispetto a [`is_numeric()`], questa funzione riconosce solo i caratteri `0-9`, `a-z` e `A-Z`.
    ///
    /// 'Digit' è definito per essere solo i seguenti caratteri:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Per una comprensione più completa di 'digit', vedere [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics se data una radice maggiore di 36.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Passando un grande radix, provocando un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Converte un `char` in una cifra nella radice data.
    ///
    /// Un 'radix' qui a volte è anche chiamato 'base'.
    /// Una radice di due indica un numero binario, una radice di dieci, decimale e una radice di sedici, esadecimale, per fornire alcuni valori comuni.
    ///
    /// Le radici arbitrarie sono supportate.
    ///
    /// 'Digit' è definito per essere solo i seguenti caratteri:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Restituisce `None` se `char` non fa riferimento a una cifra nella radice data.
    ///
    /// # Panics
    ///
    /// Panics se data una radice maggiore di 36.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Il passaggio di una cifra diversa da una cifra non riesce:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Passando un grande radix, provocando un panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // il codice è suddiviso qui per migliorare la velocità di esecuzione per i casi in cui `radix` è costante e 10 o inferiore
        //
        let val = if likely(radix <= 10) {
            // Se non è una cifra, verrà creato un numero maggiore della radice.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Restituisce un iteratore che restituisce l'escape Unicode esadecimale di un carattere come "char`s.
    ///
    /// Questo evaderà i caratteri con la sintassi Rust della forma `\u{NNNNNN}` dove `NNNNNN` è una rappresentazione esadecimale.
    ///
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 assicura che per c==0 il codice calcola che una cifra deve essere stampata e (che è la stessa) evita l'underflow (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // l'indice della cifra esadecimale più significativa
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Una versione estesa di `escape_debug` che consente, facoltativamente, di sfuggire ai punti di codice Extended Grapheme.
    /// Questo ci consente di formattare meglio caratteri come segni non spaziali quando sono all'inizio di una stringa.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Restituisce un iteratore che restituisce il codice di escape letterale di un carattere come `char`s.
    ///
    /// Questo evaderà i caratteri simili alle implementazioni `Debug` di `str` o `char`.
    ///
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Restituisce un iteratore che restituisce il codice di escape letterale di un carattere come `char`s.
    ///
    /// L'impostazione predefinita viene scelta con una preferenza verso la produzione di letterali legali in una varietà di linguaggi, inclusi C++ 11 e linguaggi della famiglia C simili.
    /// Le regole esatte sono:
    ///
    /// * Tab è sottoposto a escape come `\t`.
    /// * Il ritorno a capo è sottoposto a escape come `\r`.
    /// * L'avanzamento riga è sottoposto a escape come `\n`.
    /// * Le virgolette singole vengono sottoposte a escape come `\'`.
    /// * Le virgolette doppie vengono salvate come `\"`.
    /// * La barra rovesciata è sottoposta a escape come `\\`.
    /// * Qualsiasi carattere nell'intervallo "ASCII stampabile" `0x20` .. `0x7e` incluso non è sottoposto a escape.
    /// * A tutti gli altri caratteri vengono forniti escape Unicode esadecimali;vedi [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Restituisce il numero di byte necessari a questo `char` se codificato in UTF-8.
    ///
    /// Quel numero di byte è sempre compreso tra 1 e 4, inclusi.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Il tipo `&str` garantisce che i suoi contenuti siano UTF-8, quindi possiamo confrontare la lunghezza che impiegherebbe se ogni punto di codice fosse rappresentato come `char` rispetto allo stesso `&str`:
    ///
    ///
    /// ```
    /// // come caratteri
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // entrambi possono essere rappresentati come tre byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // come &str, questi due sono codificati in UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // possiamo vedere che prendono sei byte in totale ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... proprio come l &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Restituisce il numero di unità di codice a 16 bit che questo `char` avrebbe bisogno se codificato in UTF-16.
    ///
    ///
    /// Vedere la documentazione di [`len_utf8()`] per ulteriori spiegazioni su questo concetto.
    /// Questa funzione è un mirror, ma per UTF-16 invece di UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Codifica questo carattere come UTF-8 nel buffer di byte fornito, quindi restituisce la sottosezione del buffer che contiene il carattere codificato.
    ///
    ///
    /// # Panics
    ///
    /// Panics se il buffer non è abbastanza grande.
    /// Un buffer di lunghezza quattro è abbastanza grande da codificare qualsiasi `char`.
    ///
    /// # Examples
    ///
    /// In entrambi questi esempi, 'ß' richiede due byte per la codifica.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer troppo piccolo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SICUREZZA: `char` non è un surrogato, quindi questo è UTF-8 valido.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Codifica questo carattere come UTF-16 nel buffer `u16` fornito, quindi restituisce la sottosezione del buffer che contiene il carattere codificato.
    ///
    ///
    /// # Panics
    ///
    /// Panics se il buffer non è abbastanza grande.
    /// Un buffer di lunghezza 2 è abbastanza grande da codificare qualsiasi `char`.
    ///
    /// # Examples
    ///
    /// In entrambi questi esempi, '𝕊' richiede due `u16` per codificare.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Un buffer troppo piccolo:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Restituisce `true` se questo `char` ha la proprietà `Alphabetic`.
    ///
    /// `Alphabetic` è descritto nel Capitolo 4 (Proprietà dei caratteri) dell [Unicode Standard] e specificato nell [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // l'amore è molte cose, ma non è alfabetico
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Restituisce `true` se questo `char` ha la proprietà `Lowercase`.
    ///
    /// `Lowercase` è descritto nel Capitolo 4 (Proprietà dei caratteri) dell [Unicode Standard] e specificato nell [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // I vari caratteri cinesi e la punteggiatura non hanno maiuscole e minuscole, quindi:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Restituisce `true` se questo `char` ha la proprietà `Uppercase`.
    ///
    /// `Uppercase` è descritto nel Capitolo 4 (Proprietà dei caratteri) dell [Unicode Standard] e specificato nell [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // I vari caratteri cinesi e la punteggiatura non hanno maiuscole e minuscole, quindi:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Restituisce `true` se questo `char` ha la proprietà `White_Space`.
    ///
    /// `White_Space` è specificato in [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // uno spazio univoco
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Restituisce `true` se questo `char` soddisfa [`is_alphabetic()`] o [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Restituisce `true` se questo `char` ha la categoria generale per i codici di controllo.
    ///
    /// I codici di controllo (punti di codice con la categoria generale di `Cc`) sono descritti nel Capitolo 4 (Proprietà dei caratteri) di [Unicode Standard] e specificati in [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // U + 009C, TERMINATORE DI STRINGA
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Restituisce `true` se questo `char` ha la proprietà `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` è descritto in [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] e specificato in [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Restituisce `true` se questo `char` ha una delle categorie generali per i numeri.
    ///
    /// Le categorie generali per i numeri (`Nd` per cifre decimali, `Nl` per caratteri numerici simili a lettere e `No` per altri caratteri numerici) sono specificate in [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Restituisce un iteratore che restituisce la mappatura minuscola di questo `char` come uno o più
    /// `char`s.
    ///
    /// Se questo `char` non ha una mappatura minuscola, l'iteratore restituisce lo stesso `char`.
    ///
    /// Se questo `char` ha una mappatura minuscola uno-a-uno data dall [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iteratore restituisce quell `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se questo `char` richiede considerazioni speciali (es. Più "char"), l'iteratore restituisce i "char" dati da [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Questa operazione esegue una mappatura incondizionata senza personalizzazione.Cioè, la conversione è indipendente dal contesto e dalla lingua.
    ///
    /// In [Unicode Standard], il Capitolo 4 (Proprietà dei caratteri) discute la mappatura dei casi in generale e il Capitolo 3 (Conformance) discute l'algoritmo predefinito per la conversione dei casi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // A volte il risultato è più di un carattere:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // I caratteri che non hanno sia maiuscolo che minuscolo si convertono in se stessi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Restituisce un iteratore che restituisce la mappatura maiuscola di questo `char` come uno o più
    /// `char`s.
    ///
    /// Se questo `char` non ha una mappatura maiuscola, l'iteratore restituisce lo stesso `char`.
    ///
    /// Se questo `char` ha una mappatura uno-a-uno maiuscola data dall [Unicode Character Database][ucd] [`UnicodeData.txt`], l'iteratore restituisce quell `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Se questo `char` richiede considerazioni speciali (es. Più "char"), l'iteratore restituisce i "char" dati da [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Questa operazione esegue una mappatura incondizionata senza personalizzazione.Cioè, la conversione è indipendente dal contesto e dalla lingua.
    ///
    /// In [Unicode Standard], il Capitolo 4 (Proprietà dei caratteri) discute la mappatura dei casi in generale e il Capitolo 3 (Conformance) discute l'algoritmo predefinito per la conversione dei casi.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // A volte il risultato è più di un carattere:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // I caratteri che non hanno sia maiuscolo che minuscolo si convertono in se stessi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nota sulla localizzazione
    ///
    /// In turco, l'equivalente di 'i' in latino ha cinque forme invece di due:
    ///
    /// * 'Dotless': I/ı, a volte scritto ï
    /// * 'Dotted': İ/i
    ///
    /// Notare che l 'i' punteggiato in minuscolo è lo stesso del latino.Perciò:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Il valore di `upper_i` qui si basa sulla lingua del testo: se siamo in `en-US`, dovrebbe essere `"I"`, ma se siamo in `tr_TR`, dovrebbe essere `"İ"`.
    /// `to_uppercase()` non ne tiene conto, quindi:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// vale in tutte le lingue.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Controlla se il valore è compreso nell'intervallo ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Crea una copia del valore nel suo equivalente in maiuscolo ASCII.
    ///
    /// Le lettere ASCII da 'a' a 'z' vengono mappate da 'A' a 'Z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per inserire il valore in lettere maiuscole, utilizzare [`make_ascii_uppercase()`].
    ///
    /// Per i caratteri ASCII maiuscoli oltre ai caratteri non ASCII, utilizzare [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Crea una copia del valore nell'equivalente ASCII minuscolo.
    ///
    /// Le lettere ASCII da 'A' a 'Z' vengono mappate da 'a' a 'z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per minuscolo il valore sul posto, utilizzare [`make_ascii_lowercase()`].
    ///
    /// Per i caratteri ASCII minuscoli oltre ai caratteri non ASCII, utilizzare [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Verifica che due valori siano una corrispondenza ASCII senza distinzione tra maiuscole e minuscole.
    ///
    /// Equivalente a `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Converte questo tipo nel suo equivalente in maiuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'a' a 'z' vengono mappate da 'A' a 'Z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore maiuscolo senza modificare quello esistente, utilizzare [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Converte questo tipo nel suo equivalente in minuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'A' a 'Z' vengono mappate da 'a' a 'z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore minuscolo senza modificare quello esistente, utilizzare [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Controlla se il valore è un carattere alfabetico ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' o
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Controlla se il valore è un carattere ASCII maiuscolo:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Controlla se il valore è un carattere minuscolo ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Verifica se il valore è un carattere alfanumerico ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' o
    /// - U + 0061 'a' ..=U + 007A 'z' o
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Controlla se il valore è una cifra decimale ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Controlla se il valore è una cifra esadecimale ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' o
    /// - U + 0041 'A' ..=U + 0046 'F' o
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Controlla se il valore è un carattere di punteggiatura ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` o
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` o
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` o
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Verifica se il valore è un carattere grafico ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Controlla se il valore è un carattere di spazio vuoto ASCII:
    /// U + 0020 SPACE, U + 0009 TAB ORIZZONTALE, U + 000A LINE FEED, U + 000C FORM FEED o U + 000D CARRIAGE RETURN.
    ///
    /// Rust utilizza [definition of ASCII whitespace][infra-aw] di WhatWG Infra Standard.Ci sono molte altre definizioni ampiamente utilizzate.
    /// Ad esempio, [the POSIX locale][pct] include U + 000B TAB VERTICALE così come tutti i caratteri di cui sopra, ma, dalla stessa specifica, [la regola predefinita per "field splitting" in Bourne shell][bfs] considera *solo* SPAZIO, TABELLA ORIZZONTALE e LINE FEED come spazio bianco.
    ///
    ///
    /// Se stai scrivendo un programma che elaborerà un formato di file esistente, controlla qual è la definizione di spazi vuoti di quel formato prima di utilizzare questa funzione.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Verifica se il valore è un carattere di controllo ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR o U + 007F DELETE.
    /// Notare che la maggior parte dei caratteri di spazio ASCII sono caratteri di controllo, ma SPACE non lo è.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Codifica un valore u32 non elaborato come UTF-8 nel buffer di byte fornito, quindi restituisce la sottosezione del buffer che contiene il carattere codificato.
///
///
/// A differenza di `char::encode_utf8`, questo metodo gestisce anche i punti di codice nell'intervallo dei surrogati.
/// (La creazione di un `char` nell'intervallo surrogato è UB.) Il risultato è [generalized UTF-8] valido ma non UTF-8 valido.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics se il buffer non è abbastanza grande.
/// Un buffer di lunghezza quattro è abbastanza grande da codificare qualsiasi `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Codifica un valore u32 non elaborato come UTF-16 nel buffer `u16` fornito, quindi restituisce la sottosezione del buffer che contiene il carattere codificato.
///
///
/// A differenza di `char::encode_utf16`, questo metodo gestisce anche i punti di codice nell'intervallo dei surrogati.
/// (La creazione di un `char` nell'intervallo surrogato è UB.)
///
/// # Panics
///
/// Panics se il buffer non è abbastanza grande.
/// Un buffer di lunghezza 2 è abbastanza grande da codificare qualsiasi `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SICUREZZA: ogni braccio controlla se ci sono abbastanza bit su cui scrivere
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Il BMP fallisce
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Gli aerei supplementari si rompono in surrogati.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}