//! Conversioni di caratteri.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Converte un `u32` in un `char`.
///
/// Nota che tutti i [`char`] sono validi [`u32`] e possono essere convertiti in uno con
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tuttavia, non è vero il contrario: non tutti i [`u32`] validi sono [`char`] validi.
/// `from_u32()` restituirà `None` se l'input non è un valore valido per [`char`].
///
/// Per una versione non sicura di questa funzione che ignora questi controlli, vedere [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Restituzione di `None` quando l'input non è un [`char`] valido:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Converte un `u32` in un `char`, ignorando la validità.
///
/// Nota che tutti i [`char`] sono validi [`u32`] e possono essere convertiti in uno con
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Tuttavia, non è vero il contrario: non tutti i [`u32`] validi sono [`char`] validi.
/// `from_u32_unchecked()` lo ignorerà e farà il cast ciecamente a [`char`], possibilmente creandone uno non valido.
///
///
/// # Safety
///
/// Questa funzione non è sicura, poiché potrebbe creare valori `char` non validi.
///
/// Per una versione sicura di questa funzione, vedere la funzione [`from_u32`].
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SICUREZZA: il chiamante deve garantire che `i` sia un valore char valido.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Converte un [`char`] in un [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Converte un [`char`] in un [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Il carattere viene convertito al valore del punto di codice, quindi esteso a zero a 64 bit.
        // Vedi [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Converte un [`char`] in un [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Il carattere viene convertito al valore del punto di codice, quindi esteso per zero a 128 bit.
        // Vedi [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mappa un byte in 0x00 ..=0xFF a un `char` il cui punto di codice ha lo stesso valore, in U + 0000 ..=U + 00FF.
///
/// Unicode è progettato in modo tale che decodifichi efficacemente i byte con la codifica dei caratteri che IANA chiama ISO-8859-1.
/// Questa codifica è compatibile con ASCII.
///
/// Nota che questo è diverso da ISO/IEC 8859-1 aka
/// ISO 8859-1 (con un trattino in meno), che lascia alcuni valori di byte "blanks" che non sono assegnati a nessun carattere.
/// ISO-8859-1 (quello IANA) li assegna ai codici di controllo C0 e C1.
///
/// Nota che questo è *anche* diverso da Windows-1252 aka
/// code page 1252, che è un superset ISO/IEC 8859-1 che assegna alcuni (non tutti!) spazi vuoti alla punteggiatura e vari caratteri latini.
///
/// Per confondere ulteriormente le cose, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` e `windows-1252` sono tutti alias per un superset di Windows-1252 che riempie gli spazi rimanenti con i codici di controllo C0 e C1 corrispondenti.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Converte un [`u8`] in un [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Un errore che può essere restituito durante l'analisi di un char.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SICUREZZA: verificato che sia un valore Unicode legale
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Il tipo di errore restituito quando una conversione da u32 a char non riesce.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Converte una cifra nella radice data in un `char`.
///
/// Un 'radix' qui a volte è anche chiamato 'base'.
/// Una radice di due indica un numero binario, una radice di dieci, decimale e una radice di sedici, esadecimale, per fornire alcuni valori comuni.
///
/// Le radici arbitrarie sono supportate.
///
/// `from_digit()` restituirà `None` se l'input non è una cifra nella radice data.
///
/// # Panics
///
/// Panics se data una radice maggiore di 36.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Il decimale 11 è una singola cifra in base 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Restituzione di `None` quando l'input non è una cifra:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Passando un grande radix, provocando un panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}