//! Supporto Panic per libcore
//!
//! La libreria principale non può definire panico, ma *dichiara* panico.
//! Ciò significa che le funzioni all'interno di libcore sono consentite a panic, ma per essere utile un crate upstream deve definire il panicking per libcore da utilizzare.
//! L'attuale interfaccia per farsi prendere dal panico è:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Questa definizione consente di farsi prendere dal panico con qualsiasi messaggio generale, ma non consente di fallire con un valore `Box<Any>`.
//! (`PanicInfo` contiene solo un `&(dyn Any + Send)`, per il quale inseriamo un valore fittizio in `PanicInfo: : internal_constructor`.) La ragione di ciò è che libcore non può allocare.
//!
//!
//! Questo modulo contiene alcune altre funzioni di panico, ma questi sono solo gli elementi lang necessari per il compilatore.Tutti gli panics sono incanalati attraverso questa funzione.
//! Il simbolo effettivo viene dichiarato tramite l'attributo `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// L'implementazione sottostante della macro `panic!` di libcore quando non viene utilizzata alcuna formattazione.
#[cold]
// mai in linea a meno che non panic_immediate_abort per evitare il più possibile il blocco del codice nei siti di chiamata
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // richiesto da codegen per panic su overflow e altri terminatori MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Usa Arguments::new_v1 invece di format_args! ("{}", Expr) per ridurre potenzialmente le dimensioni.
    // Il format_args!la macro utilizza Display trait di str per scrivere expr, che chiama Formatter::pad, che deve contenere il troncamento e il riempimento delle stringhe (anche se qui non viene utilizzato nessuno).
    //
    // L'uso di Arguments::new_v1 può consentire al compilatore di omettere Formatter::pad dal binario di output, risparmiando fino a pochi kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // necessario per panics con valutazione const
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // richiesto da codegen per panic sull'accesso OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// L'implementazione sottostante della macro `panic!` di libcore quando viene utilizzata la formattazione.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Questa funzione non supera mai il confine FFI;è una chiamata da Rust a Rust che viene risolta nella funzione `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SICUREZZA: `panic_impl` è definito nel codice sicuro Rust e quindi è sicuro da chiamare.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funzione interna per macro `assert_eq!` e `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}