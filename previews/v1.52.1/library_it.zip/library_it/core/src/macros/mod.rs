#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Si espande in `$crate::panic::panic_2015` o `$crate::panic::panic_2021` a seconda dell'edizione del chiamante.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Asserisce che due espressioni sono uguali tra loro (utilizzando [`PartialEq`]).
///
/// Su panic, questa macro stamperà i valori delle espressioni con le loro rappresentazioni di debug.
///
///
/// Come [`assert!`], questa macro ha una seconda forma, in cui può essere fornito un messaggio panic personalizzato.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // I reborrows di seguito sono intenzionali.
                    // Senza di essi, lo stack slot per il prestito viene inizializzato anche prima che i valori vengano confrontati, determinando un notevole rallentamento.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // I reborrows di seguito sono intenzionali.
                    // Senza di essi, lo stack slot per il prestito viene inizializzato anche prima che i valori vengano confrontati, determinando un notevole rallentamento.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Afferma che due espressioni non sono uguali tra loro (utilizzando [`PartialEq`]).
///
/// Su panic, questa macro stamperà i valori delle espressioni con le loro rappresentazioni di debug.
///
///
/// Come [`assert!`], questa macro ha una seconda forma, in cui può essere fornito un messaggio panic personalizzato.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // I reborrows di seguito sono intenzionali.
                    // Senza di essi, lo stack slot per il prestito viene inizializzato anche prima che i valori vengano confrontati, determinando un notevole rallentamento.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // I reborrows di seguito sono intenzionali.
                    // Senza di essi, lo stack slot per il prestito viene inizializzato anche prima che i valori vengano confrontati, determinando un notevole rallentamento.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Asserisce che un'espressione booleana è `true` in fase di esecuzione.
///
/// Questo richiamerà la macro [`panic!`] se l'espressione fornita non può essere valutata in `true` in fase di runtime.
///
/// Come [`assert!`], questa macro ha anche una seconda versione, in cui può essere fornito un messaggio panic personalizzato.
///
/// # Uses
///
/// A differenza di [`assert!`], le istruzioni `debug_assert!` sono abilitate solo nelle build non ottimizzate per impostazione predefinita.
/// Una build ottimizzata non eseguirà le istruzioni `debug_assert!` a meno che `-C debug-assertions` non venga passato al compilatore.
/// Questo rende `debug_assert!` utile per i controlli che sono troppo costosi per essere presenti in una build di rilascio ma possono essere utili durante lo sviluppo.
/// Il risultato dell'espansione di `debug_assert!` è sempre il tipo controllato.
///
/// Un'asserzione non controllata consente a un programma in uno stato incoerente di continuare a funzionare, il che potrebbe avere conseguenze impreviste ma non introduce insicurezza purché ciò avvenga solo in codice sicuro.
///
/// Il costo di performance delle asserzioni, tuttavia, non è misurabile in generale.
/// La sostituzione di [`assert!`] con `debug_assert!` è quindi incoraggiata solo dopo un'accurata profilazione e, cosa più importante, solo in codice sicuro!
///
/// # Examples
///
/// ```
/// // il messaggio panic per queste asserzioni è il valore stringa dell'espressione fornita.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // una funzione molto semplice
/// debug_assert!(some_expensive_computation());
///
/// // affermare con un messaggio personalizzato
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Afferma che due espressioni sono uguali tra loro.
///
/// Su panic, questa macro stamperà i valori delle espressioni con le loro rappresentazioni di debug.
///
/// A differenza di [`assert_eq!`], le istruzioni `debug_assert_eq!` sono abilitate solo nelle build non ottimizzate per impostazione predefinita.
/// Una build ottimizzata non eseguirà le istruzioni `debug_assert_eq!` a meno che `-C debug-assertions` non venga passato al compilatore.
/// Questo rende `debug_assert_eq!` utile per i controlli che sono troppo costosi per essere presenti in una build di rilascio ma possono essere utili durante lo sviluppo.
///
/// Il risultato dell'espansione di `debug_assert_eq!` è sempre il tipo controllato.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Afferma che due espressioni non sono uguali tra loro.
///
/// Su panic, questa macro stamperà i valori delle espressioni con le loro rappresentazioni di debug.
///
/// A differenza di [`assert_ne!`], le istruzioni `debug_assert_ne!` sono abilitate solo nelle build non ottimizzate per impostazione predefinita.
/// Una build ottimizzata non eseguirà le istruzioni `debug_assert_ne!` a meno che `-C debug-assertions` non venga passato al compilatore.
/// Questo rende `debug_assert_ne!` utile per i controlli che sono troppo costosi per essere presenti in una build di rilascio ma possono essere utili durante lo sviluppo.
///
/// Il risultato dell'espansione di `debug_assert_ne!` è sempre il tipo controllato.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Restituisce se l'espressione data corrisponde a uno qualsiasi dei modelli dati.
///
/// Come in un'espressione `match`, il pattern può essere facoltativamente seguito da `if` e da un'espressione guard che ha accesso ai nomi vincolati dal pattern.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Annulla il wrapping di un risultato o propaga il suo errore.
///
/// L'operatore `?` è stato aggiunto per sostituire `try!` e dovrebbe essere utilizzato al suo posto.
/// Inoltre, `try` è una parola riservata in Rust 2018, quindi se devi usarla, dovrai usare [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` corrisponde al dato [`Result`].Nel caso della variante `Ok`, l'espressione ha il valore del valore avvolto.
///
/// Nel caso della variante `Err`, recupera l'errore interno.`try!` esegue quindi la conversione utilizzando `From`.
/// Ciò fornisce la conversione automatica tra errori specializzati e errori più generali.
/// L'errore risultante viene quindi immediatamente restituito.
///
/// A causa del ritorno anticipato, `try!` può essere utilizzato solo nelle funzioni che restituiscono [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Il metodo preferito per restituire rapidamente gli errori
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Il metodo precedente per restituire rapidamente gli errori
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Questo è equivalente a:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Scrive i dati formattati in un buffer.
///
/// Questa macro accetta un 'writer', una stringa di formato e un elenco di argomenti.
/// Gli argomenti verranno formattati in base alla stringa di formato specificata e il risultato verrà passato al writer.
/// Il writer può essere qualsiasi valore con un metodo `write_fmt`;generalmente questo deriva da un'implementazione di [`fmt::Write`] o [`io::Write`] trait.
/// La macro restituisce tutto ciò che restituisce il metodo `write_fmt`;comunemente un [`fmt::Result`] o un [`io::Result`].
///
/// Vedere [`std::fmt`] per ulteriori informazioni sulla sintassi della stringa di formato.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Un modulo può importare sia `std::fmt::Write` che `std::io::Write` e chiamare `write!` su oggetti che li implementano, poiché gli oggetti in genere non implementano entrambi.
///
/// Tuttavia, il modulo deve importare i traits qualificati in modo che i loro nomi non siano in conflitto:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // utilizza fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // utilizza io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Questa macro può essere utilizzata anche nelle configurazioni `no_std`.
/// In una configurazione `no_std` sei responsabile dei dettagli di implementazione dei componenti.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Scrivi i dati formattati in un buffer, con l'aggiunta di una nuova riga.
///
/// Su tutte le piattaforme, la nuova riga è solo il carattere LINE FEED (`\n`/`U+000A`) (nessun CARRIAGE RETURN (`\r`/`U+000D`) aggiuntivo.
///
/// Per ulteriori informazioni, vedere [`write!`].Per informazioni sulla sintassi della stringa di formato, vedere [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Un modulo può importare sia `std::fmt::Write` che `std::io::Write` e chiamare `write!` su oggetti che li implementano, poiché gli oggetti in genere non implementano entrambi.
/// Tuttavia, il modulo deve importare i traits qualificati in modo che i loro nomi non siano in conflitto:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // utilizza fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // utilizza io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Indica codice non raggiungibile.
///
/// Ciò è utile ogni volta che il compilatore non è in grado di determinare che del codice non è raggiungibile.Per esempio:
///
/// * Abbina le armi alle condizioni di guardia.
/// * Cicli che terminano dinamicamente.
/// * Iteratori che terminano dinamicamente.
///
/// Se la determinazione che il codice è irraggiungibile si rivela errata, il programma termina immediatamente con un [`panic!`].
///
/// La controparte non sicura di questa macro è la funzione [`unreachable_unchecked`], che causerà un comportamento indefinito se viene raggiunto il codice.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Questo sarà sempre [`panic!`].
///
/// # Examples
///
/// Abbina le braccia:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // errore di compilazione se commentato
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // una delle implementazioni più scadenti di x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indica codice non implementato in preda al panico con un messaggio di "not implemented".
///
/// Ciò consente al tuo codice di eseguire il controllo del tipo, il che è utile se stai prototipando o implementando uno trait che richiede più metodi che non prevedi di utilizzare tutti.
///
/// La differenza tra `unimplemented!` e [`todo!`] è che mentre `todo!` esprime l'intento di implementare la funzionalità in un secondo momento e il messaggio è "not yet implemented", `unimplemented!` non fa tali affermazioni.
/// Il suo messaggio è "not implemented".
/// Inoltre alcuni IDE contrassegneranno "todo!" S.
///
/// # Panics
///
/// Sarà sempre [`panic!`] perché `unimplemented!` è solo una scorciatoia per `panic!` con un messaggio fisso e specifico.
///
/// Come `panic!`, questa macro ha un secondo modulo per la visualizzazione dei valori personalizzati.
///
/// # Examples
///
/// Supponiamo di avere uno trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vogliamo implementare `Foo` per 'MyStruct', ma per qualche motivo ha senso implementare solo la funzione `bar()`.
/// `baz()` e `qux()` dovranno ancora essere definiti nella nostra implementazione di `Foo`, ma possiamo usare `unimplemented!` nelle loro definizioni per consentire la compilazione del nostro codice.
///
/// Vogliamo comunque che il nostro programma venga interrotto se vengono raggiunti i metodi non implementati.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Non ha senso per `baz` un `MyStruct`, quindi non abbiamo alcuna logica qui.
/////
///         // Questo visualizzerà "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Abbiamo una logica qui, possiamo aggiungere un messaggio a non implementato!per mostrare la nostra omissione.
///         // Questo mostrerà: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Indica un codice non finito.
///
/// Questo può essere utile se stai prototipando e stai solo cercando di controllare il tipo di codice.
///
/// La differenza tra [`unimplemented!`] e `todo!` è che mentre `todo!` esprime l'intento di implementare la funzionalità in un secondo momento e il messaggio è "not yet implemented", `unimplemented!` non fa tali affermazioni.
/// Il suo messaggio è "not implemented".
/// Inoltre alcuni IDE contrassegneranno "todo!" S.
///
/// # Panics
///
/// Questo sarà sempre [`panic!`].
///
/// # Examples
///
/// Ecco un esempio di codice in corso.Abbiamo uno trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vogliamo implementare `Foo` su uno dei nostri tipi, ma prima vogliamo anche lavorare solo su `bar()`.Affinché il nostro codice possa essere compilato, dobbiamo implementare `baz()`, quindi possiamo usare `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // l'implementazione va qui
///     }
///
///     fn baz(&self) {
///         // non preoccupiamoci di implementare baz() per ora
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // non stiamo nemmeno usando baz(), quindi va bene.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definizioni di macro incorporate.
///
/// La maggior parte delle proprietà delle macro (stabilità, visibilità, ecc.) Sono prese dal codice sorgente qui, ad eccezione delle funzioni di espansione che trasformano gli input delle macro in output, queste funzioni sono fornite dal compilatore.
///
///
pub(crate) mod builtin {

    /// Fa sì che la compilazione non riesca con il messaggio di errore fornito quando viene rilevato.
    ///
    /// Questa macro dovrebbe essere utilizzata quando un crate utilizza una strategia di compilazione condizionale per fornire messaggi di errore migliori per condizioni errate.
    ///
    /// È il formato a livello di compilatore di [`panic!`], ma genera un errore durante la *compilazione* anziché in *runtime*.
    ///
    /// # Examples
    ///
    /// Due di questi esempi sono le macro e gli ambienti `#[cfg]`.
    ///
    /// Emette un errore del compilatore migliore se a una macro vengono passati valori non validi.
    /// Senza lo branch finale, il compilatore emetterebbe comunque un errore, ma il messaggio dell'errore non menzionerebbe i due valori validi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emette un errore del compilatore se una delle numerose funzionalità non è disponibile.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Costruisce i parametri per le altre macro di formattazione delle stringhe.
    ///
    /// Questa macro funziona prendendo una stringa di formattazione letterale contenente `{}` per ogni argomento aggiuntivo passato.
    /// `format_args!` prepara i parametri aggiuntivi per garantire che l'output possa essere interpretato come una stringa e canonicalizza gli argomenti in un unico tipo.
    /// Qualsiasi valore che implementa [`Display`] trait può essere passato a `format_args!`, così come qualsiasi implementazione [`Debug`] può essere passata a `{:?}` all'interno della stringa di formattazione.
    ///
    ///
    /// Questa macro produce un valore di tipo [`fmt::Arguments`].Questo valore può essere passato alle macro all'interno di [`std::fmt`] per eseguire utili reindirizzamenti.
    /// Tutte le altre macro di formattazione ([`format!`], [`write!`], [`println!`], ecc.) Vengono trasmesse tramite proxy attraverso questa.
    /// `format_args!`, a differenza delle sue macro derivate, evita le allocazioni di heap.
    ///
    /// È possibile utilizzare il valore [`fmt::Arguments`] restituito da `format_args!` nei contesti `Debug` e `Display` come mostrato di seguito.
    /// L'esempio mostra anche che i formati `Debug` e `Display` hanno la stessa cosa: la stringa di formato interpolata in `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Per ulteriori informazioni, vedere la documentazione in [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Come `format_args`, ma alla fine aggiunge una nuova riga.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ispeziona una variabile di ambiente in fase di compilazione.
    ///
    /// Questa macro si espanderà al valore della variabile di ambiente denominata in fase di compilazione, producendo un'espressione di tipo `&'static str`.
    ///
    ///
    /// Se la variabile d'ambiente non è definita, verrà emesso un errore di compilazione.
    /// Per non generare un errore di compilazione, utilizzare invece la macro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// È possibile personalizzare il messaggio di errore passando una stringa come secondo parametro:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Se la variabile d'ambiente `documentation` non è definita, riceverai il seguente errore:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Facoltativamente, ispeziona una variabile di ambiente in fase di compilazione.
    ///
    /// Se la variabile di ambiente denominata è presente in fase di compilazione, questa si espanderà in un'espressione di tipo `Option<&'static str>` il cui valore è `Some` del valore della variabile di ambiente.
    /// Se la variabile di ambiente non è presente, verrà espansa in `None`.
    /// Vedere [`Option<T>`][Option] per ulteriori informazioni su questo tipo.
    ///
    /// Un errore in fase di compilazione non viene mai generato quando si utilizza questa macro indipendentemente dal fatto che la variabile di ambiente sia presente o meno.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena gli identificatori in un identificatore.
    ///
    /// Questa macro accetta un numero qualsiasi di identificatori separati da virgole e li concatena tutti in uno, producendo un'espressione che è un nuovo identificatore.
    /// Notare che l'igiene fa in modo che questa macro non possa acquisire variabili locali.
    /// Inoltre, come regola generale, le macro sono consentite solo nella posizione dell'elemento, dell'istruzione o dell'espressione.
    /// Ciò significa che mentre è possibile utilizzare questa macro per fare riferimento a variabili, funzioni o moduli esistenti, ecc., Non è possibile definirne uno nuovo con essa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (new, fun, name) { }//non utilizzabile in questo modo!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatena i valori letterali in una sezione di stringa statica.
    ///
    /// Questa macro accetta un numero qualsiasi di valori letterali separati da virgole, producendo un'espressione di tipo `&'static str` che rappresenta tutti i letterali concatenati da sinistra a destra.
    ///
    ///
    /// I valori letterali interi e in virgola mobile sono stringa per essere concatenati.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Si espande nel numero di riga su cui è stato richiamato.
    ///
    /// Con [`column!`] e [`file!`], queste macro forniscono informazioni di debug per gli sviluppatori sulla posizione all'interno dell'origine.
    ///
    /// L'espressione espansa è di tipo `u32` ed è basata su 1, quindi la prima riga in ogni file restituisce 1, la seconda su 2 e così via.
    /// Ciò è coerente con i messaggi di errore di compilatori comuni o editor popolari.
    /// La riga restituita *non è necessariamente* la riga della chiamata `line!` stessa, ma piuttosto la prima chiamata della macro che porta alla chiamata della macro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Si espande nel numero di colonna in cui è stato richiamato.
    ///
    /// Con [`line!`] e [`file!`], queste macro forniscono informazioni di debug per gli sviluppatori sulla posizione all'interno dell'origine.
    ///
    /// L'espressione espansa è di tipo `u32` ed è basata su 1, quindi la prima colonna di ogni riga restituisce 1, la seconda su 2 e così via.
    /// Ciò è coerente con i messaggi di errore di compilatori comuni o editor popolari.
    /// La colonna restituita *non è necessariamente* la riga della chiamata `column!` stessa, ma piuttosto la prima chiamata della macro che porta alla chiamata della macro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Si espande nel nome del file in cui è stato richiamato.
    ///
    /// Con [`line!`] e [`column!`], queste macro forniscono informazioni di debug per gli sviluppatori sulla posizione all'interno dell'origine.
    ///
    /// L'espressione espansa è di tipo `&'static str` e il file restituito non è il richiamo della macro `file!` stessa, ma piuttosto il primo richiamo della macro che porta al richiamo della macro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringa i suoi argomenti.
    ///
    /// Questa macro produrrà un'espressione di tipo `&'static str` che è la stringa di tutti gli tokens passati alla macro.
    /// Nessuna restrizione viene posta sulla sintassi della chiamata della macro stessa.
    ///
    /// Si noti che i risultati espansi dell'input tokens possono cambiare in future.Dovresti stare attento se ti affidi all'output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Include un file codificato UTF-8 come stringa.
    ///
    /// Il file si trova rispetto al file corrente (in modo simile a come vengono trovati i moduli).
    /// Il percorso fornito viene interpretato in un modo specifico della piattaforma in fase di compilazione.
    /// Quindi, ad esempio, un'invocazione con un percorso Windows contenente barre rovesciate `\` non si compilerebbe correttamente su Unix.
    ///
    ///
    /// Questa macro produrrà un'espressione di tipo `&'static str` che è il contenuto del file.
    ///
    /// # Examples
    ///
    /// Supponiamo che ci siano due file nella stessa directory con i seguenti contenuti:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// La compilazione di 'main.rs' e l'esecuzione del binario risultante stamperà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Include un file come riferimento a una matrice di byte.
    ///
    /// Il file si trova rispetto al file corrente (in modo simile a come vengono trovati i moduli).
    /// Il percorso fornito viene interpretato in un modo specifico della piattaforma in fase di compilazione.
    /// Quindi, ad esempio, un'invocazione con un percorso Windows contenente barre rovesciate `\` non si compilerebbe correttamente su Unix.
    ///
    ///
    /// Questa macro produrrà un'espressione di tipo `&'static [u8; N]` che è il contenuto del file.
    ///
    /// # Examples
    ///
    /// Supponiamo che ci siano due file nella stessa directory con i seguenti contenuti:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// La compilazione di 'main.rs' e l'esecuzione del binario risultante stamperà "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Si espande in una stringa che rappresenta il percorso del modulo corrente.
    ///
    /// Il percorso del modulo corrente può essere pensato come la gerarchia dei moduli che riconducono a crate root.
    /// Il primo componente del percorso restituito è il nome dello crate attualmente in fase di compilazione.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Valuta le combinazioni booleane dei flag di configurazione in fase di compilazione.
    ///
    /// Oltre all'attributo `#[cfg]`, questa macro viene fornita per consentire la valutazione dell'espressione booleana dei flag di configurazione.
    /// Questo spesso porta a un codice meno duplicato.
    ///
    /// La sintassi data a questa macro è la stessa sintassi dell'attributo [`cfg`].
    ///
    /// `cfg!`, a differenza di `#[cfg]`, non rimuove alcun codice e restituisce solo vero o falso.
    /// Ad esempio, tutti i blocchi in un'espressione if/else devono essere validi quando `cfg!` viene utilizzato per la condizione, indipendentemente da ciò che `cfg!` sta valutando.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizza un file come un'espressione o un elemento in base al contesto.
    ///
    /// Il file si trova rispetto al file corrente (in modo simile a come vengono trovati i moduli).Il percorso fornito viene interpretato in un modo specifico della piattaforma in fase di compilazione.
    /// Quindi, ad esempio, un'invocazione con un percorso Windows contenente barre rovesciate `\` non si compilerebbe correttamente su Unix.
    ///
    /// Usare questa macro è spesso una cattiva idea, perché se il file viene analizzato come un'espressione, verrà inserito nel codice circostante in modo antigienico.
    /// Ciò potrebbe comportare variabili o funzioni diverse da ciò che il file si aspettava se ci sono variabili o funzioni che hanno lo stesso nome nel file corrente.
    ///
    ///
    /// # Examples
    ///
    /// Supponiamo che ci siano due file nella stessa directory con i seguenti contenuti:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// La compilazione di 'main.rs' e l'esecuzione del binario risultante stamperà "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Asserisce che un'espressione booleana è `true` in fase di esecuzione.
    ///
    /// Questo richiamerà la macro [`panic!`] se l'espressione fornita non può essere valutata in `true` in fase di runtime.
    ///
    /// # Uses
    ///
    /// Le asserzioni vengono sempre controllate sia nelle build di debug che in quelle di rilascio e non possono essere disabilitate.
    /// Vedere [`debug_assert!`] per le asserzioni che non sono abilitate nelle build di rilascio per impostazione predefinita.
    ///
    /// Il codice non sicuro può fare affidamento su `assert!` per applicare invarianti di runtime che, se violate, potrebbero portare a problemi di sicurezza.
    ///
    /// Altri casi d'uso di `assert!` includono il test e l'applicazione di invarianti di runtime nel codice sicuro (la cui violazione non può comportare non sicurezza).
    ///
    ///
    /// # Messaggi personalizzati
    ///
    /// Questa macro ha una seconda forma, in cui un messaggio panic personalizzato può essere fornito con o senza argomenti per la formattazione.
    /// Vedere [`std::fmt`] per la sintassi di questo modulo.
    /// Le espressioni utilizzate come argomenti di formato verranno valutate solo se l'asserzione fallisce.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // il messaggio panic per queste asserzioni è il valore stringa dell'espressione fornita.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // una funzione molto semplice
    ///
    /// assert!(some_computation());
    ///
    /// // affermare con un messaggio personalizzato
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Assemblaggio in linea.
    ///
    /// Leggi l [unstable book] per l'utilizzo.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Assemblaggio in linea in stile LLVM.
    ///
    /// Leggi l [unstable book] per l'utilizzo.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Assemblaggio in linea a livello di modulo.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Le stampe hanno passato tokens nello standard output.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Abilita o disabilita la funzionalità di traccia utilizzata per il debug di altre macro.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Macro di attributi utilizzata per applicare le macro di derivazione.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Macro di attributi applicata a una funzione per trasformarla in uno unit test.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Macro di attributi applicata a una funzione per trasformarla in un test di benchmark.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Un dettaglio di implementazione delle macro `#[test]` e `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Macro di attributi applicata a una statica per registrarla come allocatore globale.
    ///
    /// Vedi anche [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mantiene l'elemento a cui è applicato se il percorso passato è accessibile e lo rimuove in caso contrario.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Espande tutti gli attributi `#[cfg]` e `#[cfg_attr]` nel frammento di codice a cui è applicato.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Dettagli di implementazione instabili del compilatore `rustc`, non utilizzare.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Dettagli di implementazione instabili del compilatore `rustc`, non utilizzare.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}