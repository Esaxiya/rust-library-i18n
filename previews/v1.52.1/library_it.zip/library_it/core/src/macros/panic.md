Panics il thread corrente.

Ciò consente a un programma di terminare immediatamente e fornire un feedback al chiamante del programma.
`panic!` dovrebbe essere usato quando un programma raggiunge uno stato irrecuperabile.

Questa macro è il modo perfetto per affermare le condizioni nel codice di esempio e nei test.
`panic!` è strettamente legato al metodo `unwrap` delle enumerazioni [`Option`][ounwrap] e [`Result`][runwrap].
Entrambe le implementazioni chiamano `panic!` quando sono impostate sulle varianti [`None`] o [`Err`].

Quando si utilizza `panic!()` è possibile specificare un payload di stringa, che viene creato utilizzando la sintassi [`format!`].
Quel payload viene utilizzato quando si inserisce panic nel thread Rust chiamante, facendo sì che il thread venga interamente panic.

Il comportamento dell `std` hook predefinito, ovvero
il codice che viene eseguito direttamente dopo che è stato richiamato panic, è quello di stampare il payload del messaggio su `stderr` insieme alle informazioni file/line/column della chiamata `panic!()`.

È possibile sostituire panic hook utilizzando [`std::panic::set_hook()`].
All'interno di hook è possibile accedere a panic come `&dyn Any + Send`, che contiene un `&str` o `String` per le normali chiamate `panic!()`.
Per panic con un valore di un altro altro tipo, è possibile utilizzare [`panic_any`].

[`Result`] enum è spesso una soluzione migliore per il ripristino dagli errori rispetto all'utilizzo della macro `panic!`.
Questa macro deve essere utilizzata per evitare di procedere utilizzando valori errati, ad esempio da fonti esterne.
Informazioni dettagliate sulla gestione degli errori si trovano in [book].

Vedi anche la macro [`compile_error!`], per la generazione di errori durante la compilazione.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Attuale implementazione

Se il thread principale panics terminerà tutti i thread e terminerà il programma con il codice `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





