//! Operatori sovraccaricabili.
//!
//! L'implementazione di questi traits consente di sovraccaricare determinati operatori.
//!
//! Alcuni di questi traits vengono importati da prelude, quindi sono disponibili in ogni programma Rust.Solo gli operatori supportati da traits possono essere sovraccaricati.
//! Ad esempio, l'operatore di addizione (`+`) può essere sovraccaricato tramite [`Add`] trait, ma poiché l'operatore di assegnazione (`=`) non ha il supporto trait, non c'è modo di sovraccaricare la sua semantica.
//! Inoltre, questo modulo non fornisce alcun meccanismo per creare nuovi operatori.
//! Se sono richiesti sovraccarico senza tratto o operatori personalizzati, dovresti guardare verso macro o plug-in del compilatore per estendere la sintassi di Rust.
//!
//! Le implementazioni dell'operatore traits non dovrebbero sorprendere nei rispettivi contesti, tenendo presente i loro significati abituali e [operator precedence].
//! Ad esempio, quando si implementa [`Mul`], l'operazione dovrebbe avere una certa somiglianza con la moltiplicazione (e condividere le proprietà previste come l'associatività).
//!
//! Notare che gli operatori `&&` e `||` vanno in cortocircuito, cioè valutano il loro secondo operando solo se contribuisce al risultato.Poiché questo comportamento non è applicabile da traits, `&&` e `||` non sono supportati come operatori sovraccaricabili.
//!
//! Molti degli operatori prendono i loro operandi in base al valore.In contesti non generici che coinvolgono tipi incorporati, questo di solito non è un problema.
//! Tuttavia, l'utilizzo di questi operatori in codice generico richiede una certa attenzione se i valori devono essere riutilizzati invece di lasciare che gli operatori li consumino.Un'opzione è usare occasionalmente [`clone`].
//! Un'altra opzione è fare affidamento sui tipi coinvolti fornendo ulteriori implementazioni dell'operatore per i riferimenti.
//! Ad esempio, per un tipo `T` definito dall'utente che dovrebbe supportare l'aggiunta, è probabilmente una buona idea che sia `T` che `&T` implementino traits [`Add<T>`][`Add`] e [`Add<&T>`][`Add`] in modo che il codice generico possa essere scritto senza clonazioni non necessarie.
//!
//!
//! # Examples
//!
//! Questo esempio crea una struttura `Point` che implementa [`Add`] e [`Sub`], quindi mostra l'aggiunta e la sottrazione di due `Point`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Vedere la documentazione per ogni trait per un'implementazione di esempio.
//!
//! [`Fn`], [`FnMut`] e [`FnOnce`] traits sono implementati da tipi che possono essere richiamati come funzioni.Nota che [`Fn`] prende `&self`, [`FnMut`] prende `&mut self` e [`FnOnce`] prende `self`.
//! Questi corrispondono ai tre tipi di metodi che possono essere richiamati su un'istanza: chiamata per riferimento, chiamata per riferimento modificabile e chiamata per valore.
//! L'utilizzo più comune di questi traits è quello di agire come limiti a funzioni di livello superiore che accettano funzioni o chiusure come argomenti.
//!
//! Prendendo un [`Fn`] come parametro:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Prendendo un [`FnMut`] come parametro:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Prendendo un [`FnOnce`] come parametro:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` consuma le sue variabili catturate, quindi non può essere eseguito più di una volta
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Il tentativo di richiamare nuovamente `func()` genererà un errore `use of moved value` per `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` non può più essere invocato a questo punto
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;