/// Codice personalizzato all'interno del distruttore.
///
/// Quando un valore non è più necessario, Rust eseguirà un "destructor" su quel valore.
/// Il modo più comune in cui un valore non è più necessario è quando esce dall'ambito.I distruttori possono ancora funzionare in altre circostanze, ma qui ci concentreremo sull'ambito degli esempi.
/// Per conoscere alcuni di questi altri casi, vedere la sezione [the reference] sui distruttori.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Questo distruttore è costituito da due componenti:
/// - Una chiamata a `Drop::drop` per quel valore, se questo speciale `Drop` trait è implementato per il suo tipo.
/// - L "drop glue" generato automaticamente che chiama ricorsivamente i distruttori di tutti i campi di questo valore.
///
/// Poiché Rust chiama automaticamente i distruttori di tutti i campi contenuti, nella maggior parte dei casi non è necessario implementare `Drop`.
/// Ma ci sono alcuni casi in cui è utile, ad esempio per i tipi che gestiscono direttamente una risorsa.
/// Quella risorsa potrebbe essere la memoria, potrebbe essere un descrittore di file, potrebbe essere un socket di rete.
/// Una volta che un valore di quel tipo non verrà più utilizzato, dovrebbe "clean up" la sua risorsa liberando la memoria o chiudendo il file o il socket.
/// Questo è il lavoro di un distruttore, e quindi il lavoro di `Drop::drop`.
///
/// ## Examples
///
/// Per vedere i distruttori in azione, diamo un'occhiata al seguente programma:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust chiamerà prima `Drop::drop` per `_x` e poi sia per `_x.one` che per `_x.two`, il che significa che eseguendolo verrà stampato
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Anche se rimuoviamo l'implementazione di `Drop` per `HasTwoDrop`, i distruttori dei suoi campi vengono comunque chiamati.
/// Ciò risulterebbe in
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Non puoi chiamare `Drop::drop` da solo
///
/// Poiché `Drop::drop` viene utilizzato per ripulire un valore, potrebbe essere pericoloso utilizzare questo valore dopo che il metodo è stato chiamato.
/// Poiché `Drop::drop` non si assume la proprietà del suo input, Rust impedisce l'uso improprio non consentendo di chiamare direttamente `Drop::drop`.
///
/// In altre parole, se si tentasse di chiamare esplicitamente `Drop::drop` nell'esempio precedente, si otterrebbe un errore del compilatore.
///
/// Se desideri chiamare esplicitamente il distruttore di un valore, puoi utilizzare [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Ordine di consegna
///
/// Quale dei nostri due `HasDrop` esce per primo, però?Per le strutture, è lo stesso ordine in cui sono dichiarate: prima `one`, poi `two`.
/// Se desideri provare tu stesso, puoi modificare `HasDrop` sopra per contenere alcuni dati, come un numero intero, e quindi usarlo nell `println!` all'interno di `Drop`.
/// Questo comportamento è garantito dalla lingua.
///
/// A differenza delle strutture, le variabili locali vengono eliminate in ordine inverso:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Questo stamperà
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Si prega di consultare [the reference] per le regole complete.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` e `Drop` sono esclusivi
///
/// Non è possibile implementare sia [`Copy`] che `Drop` sullo stesso tipo.I tipi che sono `Copy` vengono implicitamente duplicati dal compilatore, rendendo molto difficile prevedere quando e con quale frequenza verranno eseguiti i distruttori.
///
/// In quanto tali, questi tipi non possono avere distruttori.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Esegue il distruttore per questo tipo.
    ///
    /// Questo metodo viene chiamato implicitamente quando il valore esce dall'ambito e non può essere chiamato esplicitamente (questo è l'errore del compilatore [E0040]).
    /// Tuttavia, la funzione [`mem::drop`] in prelude può essere utilizzata per chiamare l'implementazione `Drop` dell'argomento.
    ///
    /// Quando questo metodo è stato chiamato, `self` non è stato ancora deallocato.
    /// Ciò accade solo dopo che il metodo è finito.
    /// Se non fosse così, `self` sarebbe un riferimento penzolante.
    ///
    /// # Panics
    ///
    /// Dato che un [`panic!`] chiamerà `drop` mentre si svolge, qualsiasi [`panic!`] in un'implementazione `drop` probabilmente si interromperà.
    ///
    /// Notare che anche se questo panics, il valore è considerato scartato;
    /// non devi fare in modo che `drop` venga richiamato di nuovo.
    /// Questo viene normalmente gestito automaticamente dal compilatore, ma quando si utilizza codice non sicuro, a volte può verificarsi involontariamente, in particolare quando si utilizza [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}