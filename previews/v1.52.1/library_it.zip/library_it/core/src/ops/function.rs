/// La versione dell'operatore di chiamata che accetta un ricevitore immutabile.
///
/// Le istanze di `Fn` possono essere chiamate ripetutamente senza mutare lo stato.
///
/// *Questo trait (`Fn`) non deve essere confuso con [function pointers] (`fn`).*
///
/// `Fn` viene implementato automaticamente da chiusure che accettano solo riferimenti immutabili alle variabili catturate o non catturano nulla, così come (safe) [function pointers] (con alcuni avvertimenti, vedere la loro documentazione per maggiori dettagli).
///
/// Inoltre, per qualsiasi tipo `F` che implementa `Fn`, `&F` implementa anche `Fn`.
///
/// Poiché sia [`FnMut`] che [`FnOnce`] sono supertratt di `Fn`, qualsiasi istanza di `Fn` può essere utilizzata come parametro in cui è previsto un [`FnMut`] o [`FnOnce`].
///
/// Usa `Fn` come limite quando vuoi accettare un parametro di tipo funzionale e devi chiamarlo ripetutamente e senza mutare lo stato (ad esempio, quando lo chiami contemporaneamente).
/// Se non sono necessari requisiti così rigidi, utilizzare [`FnMut`] o [`FnOnce`] come limiti.
///
/// Vedere [chapter on closures in *The Rust Programming Language*][book] per ulteriori informazioni su questo argomento.
///
/// Da notare anche la sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Chi è interessato ai dettagli tecnici di questo può fare riferimento a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chiamare una chiusura
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Utilizzando un parametro `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // in modo che regex possa fare affidamento su `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Esegue l'operazione di chiamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// La versione dell'operatore di chiamata che accetta un ricevitore mutabile.
///
/// Le istanze di `FnMut` possono essere chiamate ripetutamente e possono mutare lo stato.
///
/// `FnMut` è implementato automaticamente da chiusure che accettano riferimenti mutabili a variabili catturate, così come tutti i tipi che implementano [`Fn`], ad esempio (safe) [function pointers] (poiché `FnMut` è un supertrait di [`Fn`]).
/// Inoltre, per qualsiasi tipo `F` che implementa `FnMut`, `&mut F` implementa anche `FnMut`.
///
/// Poiché [`FnOnce`] è un supertrait di `FnMut`, qualsiasi istanza di `FnMut` può essere utilizzata dove è previsto un [`FnOnce`] e poiché [`Fn`] è un sottoritratto di `FnMut`, qualsiasi istanza di [`Fn`] può essere utilizzata dove è previsto `FnMut`.
///
/// Usa `FnMut` come limite quando vuoi accettare un parametro di tipo funzionale e devi chiamarlo ripetutamente, permettendogli di mutare lo stato.
/// Se non vuoi che il parametro muti lo stato, usa [`Fn`] come limite;se non hai bisogno di chiamarlo ripetutamente, usa [`FnOnce`].
///
/// Vedere [chapter on closures in *The Rust Programming Language*][book] per ulteriori informazioni su questo argomento.
///
/// Da notare anche la sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Chi è interessato ai dettagli tecnici di questo può fare riferimento a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Chiamare una chiusura mutevole che cattura
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Utilizzando un parametro `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // in modo che regex possa fare affidamento su `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Esegue l'operazione di chiamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// La versione dell'operatore di chiamata che accetta un ricevitore per valore.
///
/// Le istanze di `FnOnce` possono essere chiamate, ma potrebbero non essere richiamabili più volte.Per questo motivo, se l'unica cosa nota su un tipo è che implementa `FnOnce`, può essere richiamato solo una volta.
///
/// `FnOnce` viene implementato automaticamente da chiusure che potrebbero consumare variabili catturate, così come tutti i tipi che implementano [`FnMut`], ad esempio (safe) [function pointers] (poiché `FnOnce` è un supertrait di [`FnMut`]).
///
///
/// Poiché sia [`Fn`] che [`FnMut`] sono subtraits di `FnOnce`, qualsiasi istanza di [`Fn`] o [`FnMut`] può essere utilizzata laddove è previsto un `FnOnce`.
///
/// Usa `FnOnce` come limite quando vuoi accettare un parametro di tipo funzionale e devi chiamarlo solo una volta.
/// Se è necessario chiamare ripetutamente il parametro, utilizzare [`FnMut`] come limite;se ne hai bisogno anche per non mutare lo stato, usa [`Fn`].
///
/// Vedere [chapter on closures in *The Rust Programming Language*][book] per ulteriori informazioni su questo argomento.
///
/// Da notare anche la sintassi speciale per `Fn` traits (es
/// `Fn(usize, bool) -> usize`).Chi è interessato ai dettagli tecnici di questo può fare riferimento a [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Utilizzando un parametro `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` consuma le sue variabili catturate, quindi non può essere eseguito più di una volta.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Il tentativo di richiamare nuovamente `func()` genererà un errore `use of moved value` per `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` non può più essere invocato a questo punto
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // in modo che regex possa fare affidamento su `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Il tipo restituito dopo l'utilizzo dell'operatore di chiamata.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Esegue l'operazione di chiamata.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}