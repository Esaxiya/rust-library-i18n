/// Utilizzato per operazioni di dereferenziazione immutabili, come `*v`.
///
/// Oltre ad essere utilizzato per operazioni di dereferenziazione esplicite con l'operatore (unary) `*` in contesti immutabili, `Deref` viene anche utilizzato implicitamente dal compilatore in molte circostanze.
/// Questo meccanismo è chiamato ['`Deref` coercion'][more].
/// In contesti modificabili, viene utilizzato [`DerefMut`].
///
/// L'implementazione di `Deref` per i puntatori intelligenti rende comodo l'accesso ai dati sottostanti, motivo per cui implementano `Deref`.
/// D'altra parte, le regole riguardanti `Deref` e [`DerefMut`] sono state progettate specificamente per accogliere i puntatori intelligenti.
/// Per questo motivo,**`Deref` dovrebbe essere implementato solo per puntatori intelligenti** per evitare confusione.
///
/// Per ragioni simili,**questo trait non dovrebbe mai fallire**.Un errore durante la dereferenziazione può creare confusione quando `Deref` viene richiamato in modo implicito.
///
/// # Altro sulla coercizione `Deref`
///
/// Se `T` implementa `Deref<Target = U>` e `x` è un valore di tipo `T`, allora:
///
/// * In contesti immutabili, `*x` (dove `T` non è né un riferimento né un puntatore grezzo) è equivalente a `* Deref::deref(&x)`.
/// * I valori di tipo `&T` vengono convertiti in valori di tipo `&U`
/// * `T` implementa implicitamente tutti i metodi (immutable) del tipo `U`.
///
/// Per maggiori dettagli, visita [the chapter in *The Rust Programming Language*][book] e le sezioni di riferimento su [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una struttura con un singolo campo accessibile dereferenziando la struttura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Il tipo risultante dopo la dereferenziazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dereferenzia il valore.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Utilizzato per operazioni di dereferenziazione modificabili, come in `*v = 1;`.
///
/// Oltre ad essere utilizzato per operazioni di dereferenziazione esplicite con l'operatore (unary) `*` in contesti mutabili, `DerefMut` viene anche utilizzato implicitamente dal compilatore in molte circostanze.
/// Questo meccanismo è chiamato ['`Deref` coercion'][more].
/// In contesti immutabili, viene utilizzato [`Deref`].
///
/// L'implementazione di `DerefMut` per i puntatori intelligenti rende conveniente la modifica dei dati dietro di essi, motivo per cui implementano `DerefMut`.
/// D'altra parte, le regole riguardanti [`Deref`] e `DerefMut` sono state progettate specificamente per accogliere i puntatori intelligenti.
/// Per questo motivo,**`DerefMut` dovrebbe essere implementato solo per i puntatori intelligenti** per evitare confusione.
///
/// Per ragioni simili,**questo trait non dovrebbe mai fallire**.Un errore durante la dereferenziazione può creare confusione quando `DerefMut` viene richiamato implicitamente.
///
/// # Altro sulla coercizione `Deref`
///
/// Se `T` implementa `DerefMut<Target = U>` e `x` è un valore di tipo `T`, allora:
///
/// * In contesti mutabili, `*x` (dove `T` non è né un riferimento né un puntatore grezzo) è equivalente a `* DerefMut::deref_mut(&mut x)`.
/// * I valori di tipo `&mut T` vengono convertiti in valori di tipo `&mut U`
/// * `T` implementa implicitamente tutti i metodi (mutable) del tipo `U`.
///
/// Per maggiori dettagli, visita [the chapter in *The Rust Programming Language*][book] e le sezioni di riferimento su [the dereference operator][ref-deref-op], [method resolution] e [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Una struttura con un singolo campo che è modificabile dereferenziando la struttura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Dereferenzia reciprocamente il valore.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Indica che una struttura può essere utilizzata come ricevitore del metodo, senza la funzionalità `arbitrary_self_types`.
///
/// Questo è implementato dai tipi di puntatore stdlib come `Box<T>`, `Rc<T>`, `&T` e `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}