use crate::marker::Unsize;

/// Trait che indica che questo è un puntatore o un wrapper per uno, in cui è possibile eseguire il ridimensionamento sulle punte.
///
/// Vedere [DST coercion RFC][dst-coerce] e [the nomicon entry on coercion][nomicon-coerce] per maggiori dettagli.
///
/// Per i tipi di puntatori incorporati, i puntatori a `T` si convertiranno in puntatori a `U` se `T: Unsize<U>` convertendo da un puntatore sottile a un puntatore grasso.
///
/// Per i tipi personalizzati, la coercizione qui funziona forzando `Foo<T>` a `Foo<U>` a condizione che esista un impl di `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Tale impl può essere scritto solo se `Foo<T>` ha solo un singolo campo di dati non fantasma che coinvolge `T`.
/// Se il tipo di quel campo è `Bar<T>`, deve esistere un'implementazione di `CoerceUnsized<Bar<U>> for Bar<T>`.
/// La coercizione funzionerà forzando il campo `Bar<T>` in `Bar<U>` e riempiendo il resto dei campi da `Foo<T>` per creare un `Foo<U>`.
/// Questo eseguirà efficacemente il drill-down in un campo di puntatore e lo forzerà.
///
/// Generalmente, per i puntatori intelligenti implementerai `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, con un `?Sized` opzionale associato a `T` stesso.
/// Per i tipi di wrapper che incorporano direttamente `T` come `Cell<T>` e `RefCell<T>`, puoi implementare direttamente `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Ciò consentirà alle coercizioni di tipi come `Cell<Box<T>>` di funzionare.
///
/// [`Unsize`][unsize] viene utilizzato per contrassegnare i tipi che possono essere forzati a DST se dietro ai puntatori.Viene implementato automaticamente dal compilatore.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Viene utilizzato per la sicurezza degli oggetti, per verificare che il tipo di ricevitore di un metodo possa essere inviato.
///
/// Un esempio di implementazione di trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}