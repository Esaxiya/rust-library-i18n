use crate::marker::Unpin;
use crate::pin::Pin;

/// Il risultato di una ripresa del generatore.
///
/// Questo enum viene restituito dal metodo `Generator::resume` e indica i possibili valori di ritorno di un generatore.
/// Attualmente ciò corrisponde a un punto di sospensione (`Yielded`) o a un punto di terminazione (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Il generatore sospeso con un valore.
    ///
    /// Questo stato indica che un generatore è stato sospeso e in genere corrisponde a un'istruzione `yield`.
    /// Il valore fornito in questa variante corrisponde all'espressione passata a `yield` e consente ai generatori di fornire un valore ogni volta che cedono.
    ///
    ///
    Yielded(Y),

    /// Il generatore è stato completato con un valore di ritorno.
    ///
    /// Questo stato indica che un generatore ha terminato l'esecuzione con il valore fornito.
    /// Una volta che un generatore ha restituito `Complete`, è considerato un errore del programmatore chiamare di nuovo `resume`.
    ///
    Complete(R),
}

/// Lo trait implementato dai tipi di generatore incorporato.
///
/// I generatori, comunemente indicati anche come coroutine, sono attualmente una funzionalità linguistica sperimentale in Rust.
/// Aggiunti in [RFC 2033], i generatori sono attualmente destinati a fornire principalmente un elemento costitutivo per la sintassi async/await, ma probabilmente si estenderanno anche a fornire una definizione ergonomica per iteratori e altre primitive.
///
///
/// La sintassi e la semantica per i generatori è instabile e richiederà un'ulteriore RFC per la stabilizzazione.In questo momento, tuttavia, la sintassi è simile alla chiusura:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Ulteriore documentazione sui generatori può essere trovata nel libro unstable.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Il tipo di valore che questo generatore produce.
    ///
    /// Questo tipo associato corrisponde all'espressione `yield` e ai valori che possono essere restituiti ogni volta che un generatore cede.
    ///
    /// Ad esempio, un iteratore come generatore avrebbe probabilmente questo tipo come `T`, il tipo su cui viene ripetuto.
    ///
    type Yield;

    /// Il tipo di valore restituito da questo generatore.
    ///
    /// Corrisponde al tipo restituito da un generatore con un'istruzione `return` o implicitamente come ultima espressione di un generatore letterale.
    /// Ad esempio futures lo userebbe come `Result<T, E>` poiché rappresenta uno future completato.
    ///
    ///
    type Return;

    /// Riprende l'esecuzione di questo generatore.
    ///
    /// Questa funzione riprenderà l'esecuzione del generatore o inizierà l'esecuzione se non lo ha già fatto.
    /// Questa chiamata tornerà nell'ultimo punto di sospensione del generatore, riprendendo l'esecuzione dall'ultimo `yield`.
    /// Il generatore continuerà l'esecuzione fino a quando non cede o ritorna, a quel punto questa funzione tornerà.
    ///
    /// # Valore di ritorno
    ///
    /// L'enumerazione `GeneratorState` restituita da questa funzione indica in quale stato si trova il generatore al ritorno.
    /// Se viene restituita la variante `Yielded`, il generatore ha raggiunto un punto di sospensione ed è stato ceduto un valore.
    /// I generatori in questo stato sono disponibili per la ripresa in un secondo momento.
    ///
    /// Se viene restituito `Complete`, il generatore ha terminato completamente con il valore fornito.Non è valido il ripristino del generatore.
    ///
    /// # Panics
    ///
    /// Questa funzione può panic se viene richiamata dopo che la variante `Complete` è stata restituita in precedenza.
    /// Sebbene i letterali generatori nella lingua siano garantiti a panic alla ripresa dopo `Complete`, ciò non è garantito per tutte le implementazioni di `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}