/// Un trait per personalizzare il comportamento dell'operatore `?`.
///
/// Un tipo che implementa `Try` è uno che ha un modo canonico di visualizzarlo in termini di dicotomia success/failure.
/// Questo trait consente sia di estrarre quei valori di successo o fallimento da un'istanza esistente sia di creare una nuova istanza da un valore di successo o fallimento.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Il tipo di questo valore se visto come riuscito.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Il tipo di questo valore se visualizzato come non riuscito.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Applica l'operatore "?".Un ritorno di `Ok(t)` significa che l'esecuzione dovrebbe continuare normalmente e il risultato di `?` è il valore `t`.
    /// Un ritorno di `Err(e)` significa che l'esecuzione dovrebbe branch all `catch` che lo racchiude più interno, o tornare dalla funzione.
    ///
    /// Se viene restituito un risultato `Err(e)`, il valore `e` sarà "wrapped" nel tipo restituito dell'ambito di inclusione (che deve implementare `Try`).
    ///
    /// In particolare, viene restituito il valore `X::from_error(From::from(e))`, dove `X` è il tipo restituito della funzione che lo racchiude.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Avvolgi un valore di errore per costruire il risultato composito.
    /// Ad esempio, `Result::Err(x)` e `Result::from_error(x)` sono equivalenti.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Avvolgi un valore OK per costruire il risultato composito.
    /// Ad esempio, `Result::Ok(x)` e `Result::from_ok(x)` sono equivalenti.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}