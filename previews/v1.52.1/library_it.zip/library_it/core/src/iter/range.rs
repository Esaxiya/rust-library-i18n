use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Oggetti che hanno una nozione di operazioni *successore* e *predecessore*.
///
/// L'operazione *successore* si sposta verso valori con un confronto maggiore.
/// L'operazione *predecessore* si sposta verso valori che confrontano minori.
///
/// # Safety
///
/// Questo trait è `unsafe` perché la sua implementazione deve essere corretta per la sicurezza delle implementazioni `unsafe trait TrustedLen`, ei risultati dell'utilizzo di questo trait possono altrimenti essere considerati attendibili dal codice `unsafe` per essere corretti e adempiere agli obblighi elencati.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Restituisce il numero di passaggi *successori* necessari per passare da `start` a `end`.
    ///
    /// Restituisce `None` se il numero di passaggi supera `usize` (o è infinito o se `end` non viene mai raggiunto).
    ///
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`, `b` e `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` se e solo se `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` se e solo se `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` solo se `a <= b`
    ///   * Corollario: `steps_between(&a, &b) == Some(0)` se e solo se `a == b`
    ///   * Notare che `a <= b` _not_ implica `steps_between(&a, &b) != None`;
    ///     questo è il caso in cui sarebbero necessari più di passaggi `usize::MAX` per arrivare a `b`
    /// * `steps_between(&a, &b) == None` se `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Restituisce il valore che si otterrebbe prendendo il *successore* di `self` `count` volte.
    ///
    /// Se questo superasse l'intervallo di valori supportato da `Self`, restituisce `None`.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`, `n` e `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Per qualsiasi `a`, `n` e `m` in cui `n + m` non va in overflow:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Per qualsiasi `a` e `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Restituisce il valore che si otterrebbe prendendo il *successore* di `self` `count` volte.
    ///
    /// Se questo superasse l'intervallo di valori supportato da `Self`, questa funzione è consentita a panic, avvolgere o saturare.
    ///
    /// Il comportamento suggerito è quello di panic quando le asserzioni di debug sono abilitate e di avvolgere o saturare altrimenti.
    ///
    /// Il codice non sicuro non dovrebbe fare affidamento sulla correttezza del comportamento dopo l'overflow.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`, `n` e `m`, dove non si verifica overflow:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Per qualsiasi `a` e `n`, dove non si verifica overflow:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Restituisce il valore che si otterrebbe prendendo il *successore* di `self` `count` volte.
    ///
    /// # Safety
    ///
    /// È un comportamento indefinito per questa operazione superare l'intervallo di valori supportato da `Self`.
    /// Se non puoi garantire che questo non trabocchi, usa invece `forward` o `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`:
    ///
    /// * se esiste `b` tale che `b > a`, è sicuro chiamare `Step::forward_unchecked(a, 1)`
    /// * se esiste `b`, `n` tale che `steps_between(&a, &b) == Some(n)`, è sicuro chiamare `Step::forward_unchecked(a, m)` per qualsiasi `m <= n`.
    ///
    ///
    /// Per qualsiasi `a` e `n`, dove non si verifica overflow:
    ///
    /// * `Step::forward_unchecked(a, n)` è equivalente a `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Restituisce il valore che si otterrebbe prendendo il *predecessore* di `self` `count` volte.
    ///
    /// Se questo superasse l'intervallo di valori supportato da `Self`, restituisce `None`.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`, `n` e `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Per qualsiasi `a` e `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Restituisce il valore che si otterrebbe prendendo il *predecessore* di `self` `count` volte.
    ///
    /// Se questo superasse l'intervallo di valori supportato da `Self`, questa funzione è consentita a panic, avvolgere o saturare.
    ///
    /// Il comportamento suggerito è quello di panic quando le asserzioni di debug sono abilitate e di avvolgere o saturare altrimenti.
    ///
    /// Il codice non sicuro non dovrebbe fare affidamento sulla correttezza del comportamento dopo l'overflow.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`, `n` e `m`, dove non si verifica overflow:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Per qualsiasi `a` e `n`, dove non si verifica overflow:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Restituisce il valore che si otterrebbe prendendo il *predecessore* di `self` `count` volte.
    ///
    /// # Safety
    ///
    /// È un comportamento indefinito per questa operazione superare l'intervallo di valori supportato da `Self`.
    /// Se non puoi garantire che questo non trabocchi, usa invece `backward` o `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Per qualsiasi `a`:
    ///
    /// * se esiste `b` tale che `b < a`, è sicuro chiamare `Step::backward_unchecked(a, 1)`
    /// * se esiste `b`, `n` tale che `steps_between(&b, &a) == Some(n)`, è sicuro chiamare `Step::backward_unchecked(a, m)` per qualsiasi `m <= n`.
    ///
    ///
    /// Per qualsiasi `a` e `n`, dove non si verifica overflow:
    ///
    /// * `Step::backward_unchecked(a, n)` è equivalente a `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Questi sono ancora generati da macro perché i valori letterali interi vengono risolti in tipi diversi.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SICUREZZA: il chiamante deve garantire che `start + n` non trabocchi.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SICUREZZA: il chiamante deve garantire che `start - n` non trabocchi.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Nelle build di debug, attiva panic in caso di overflow.
            // Questo dovrebbe essere ottimizzato completamente nelle build di rilascio.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Fai la matematica di wrapping per consentire ad es `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Nelle build di debug, attiva panic in caso di overflow.
            // Questo dovrebbe essere ottimizzato completamente nelle build di rilascio.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Fai la matematica di wrapping per consentire ad es `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Questo si basa su $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // se n è fuori intervallo, anche `unsigned_start + n` lo è
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // se n è fuori intervallo, anche `unsigned_start - n` lo è
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Questo si basa su $i_narrower <=usize
                        //
                        // La fusione a isize estende la larghezza ma preserva il segno.
                        // Usa wrapping_sub in isize space e cast to usize per calcolare la differenza che potrebbe non rientrare nell'intervallo di isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Il wrapping gestisce casi come `Step::forward(-120_i8, 200) == Some(80_i8)`, anche se 200 è fuori portata per i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // L'aggiunta traboccò
                            }
                        }
                        // Se n è fuori dalla gamma di es
                        // u8, quindi è più grande dell'intera gamma per i8, quindi `any_i8 + n` supera necessariamente i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Il wrapping gestisce casi come `Step::forward(-120_i8, 200) == Some(80_i8)`, anche se 200 è fuori portata per i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // La sottrazione traboccava
                            }
                        }
                        // Se n è fuori dalla gamma di es
                        // u8, quindi è più grande dell'intera gamma per i8, quindi `any_i8 - n` supera necessariamente i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Se la differenza è troppo grande per es
                            // i128, sarà anche troppo grande per essere utilizzato con meno bit.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SICUREZZA: res è uno scalare unicode valido
            // (sotto 0x110000 e non in 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SICUREZZA: res è uno scalare unicode valido
        // (sotto 0x110000 e non in 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SICUREZZA: il chiamante deve garantire che questo non trabocchi
        // l'intervallo di valori per un carattere.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SICUREZZA: il chiamante deve garantire che questo non trabocchi
            // l'intervallo di valori per un carattere.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SICUREZZA: a causa del contratto precedente, questa è garantita
        // dal chiamante per essere un carattere valido.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SICUREZZA: il chiamante deve garantire che questo non trabocchi
        // l'intervallo di valori per un carattere.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SICUREZZA: il chiamante deve garantire che questo non trabocchi
            // l'intervallo di valori per un carattere.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SICUREZZA: a causa del contratto precedente, questa è garantita
        // dal chiamante per essere un carattere valido.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SICUREZZA: precondizione appena verificata
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SICUREZZA: precondizione appena verificata
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Queste macro generano gli impl `ExactSizeIterator` per vari tipi di intervallo.
//
// * `ExactSizeIterator::len` è necessario per restituire sempre un `usize` esatto, quindi nessun intervallo può essere più lungo di `usize::MAX`.
//
// * Per i tipi interi in `Range<_>` questo è il caso per i tipi più stretti o larghi come `usize`.
//   Per i tipi interi in `RangeInclusive<_>` questo è il caso dei tipi *strettamente più stretti* di `usize` poiché ad es
//   `(0..=u64::MAX).len()` sarebbe `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Questi sono errati secondo il ragionamento sopra, ma rimuoverli sarebbe un cambiamento radicale poiché sono stati stabilizzati in Rust 1.0.0.
    // Quindi ad es
    // `(0..66_000_u32).len()` ad esempio si compilerà senza errori o avvisi su piattaforme a 16 bit, ma continuerà a dare un risultato sbagliato.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Questi sono errati secondo il ragionamento sopra, ma rimuoverli sarebbe un cambiamento radicale poiché sono stati stabilizzati in Rust 1.26.0.
    // Quindi ad es
    // `(0..=u16::MAX).len()` ad esempio si compilerà senza errori o avvisi su piattaforme a 16 bit, ma continuerà a dare un risultato sbagliato.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SICUREZZA: precondizione appena verificata
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SICUREZZA: precondizione appena verificata
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SICUREZZA: precondizione appena verificata
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SICUREZZA: precondizione appena verificata
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SICUREZZA: precondizione appena verificata
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SICUREZZA: precondizione appena verificata
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}