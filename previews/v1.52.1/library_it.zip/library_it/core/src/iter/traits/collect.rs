/// Conversione da un [`Iterator`].
///
/// Implementando `FromIterator` per un tipo, definisci come verrà creato da un iteratore.
/// Questo è comune per i tipi che descrivono una raccolta di qualche tipo.
///
/// [`FromIterator::from_iter()`] raramente viene chiamato esplicitamente e viene invece utilizzato tramite il metodo [`Iterator::collect()`].
///
/// Vedere la documentazione di [`Iterator::collect()`]'s per ulteriori esempi.
///
/// Guarda anche: [`IntoIterator`].
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Utilizzo di [`Iterator::collect()`] per utilizzare implicitamente `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementazione di `FromIterator` per il tuo tipo:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Una raccolta di campioni, che è solo un involucro su Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Diamo alcuni metodi in modo che possiamo crearne uno e aggiungere cose ad esso.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e implementeremo FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ora possiamo creare un nuovo iteratore ...
/// let iter = (0..5).into_iter();
///
/// // ... e creane una MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // colleziona anche opere!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Crea un valore da un iteratore.
    ///
    /// Vedi l [module-level documentation] per ulteriori informazioni.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Conversione in un [`Iterator`].
///
/// Implementando `IntoIterator` per un tipo, definisci come verrà convertito in un iteratore.
/// Questo è comune per i tipi che descrivono una raccolta di qualche tipo.
///
/// Un vantaggio dell'implementazione di `IntoIterator` è che il tuo tipo sarà [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Guarda anche: [`FromIterator`].
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementazione di `IntoIterator` per il tuo tipo:
///
/// ```
/// // Una raccolta di campioni, che è solo un involucro su Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Diamo alcuni metodi in modo che possiamo crearne uno e aggiungere cose ad esso.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // e implementeremo IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ora possiamo creare una nuova collezione ...
/// let mut c = MyCollection::new();
///
/// // ... aggiungi un po 'di cose ad esso ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... e poi trasformalo in un Iteratore:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// È comune utilizzare `IntoIterator` come trait bound.Ciò consente di modificare il tipo di raccolta di input, purché sia ancora un iteratore.
/// È possibile specificare limiti aggiuntivi limitando l'attivazione
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Il tipo di elementi su cui eseguire l'iterazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// In che tipo di iteratore lo stiamo trasformando?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Crea un iteratore da un valore.
    ///
    /// Vedi l [module-level documentation] per ulteriori informazioni.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Estende una raccolta con il contenuto di un iteratore.
///
/// Gli iteratori producono una serie di valori e le raccolte possono anche essere pensate come una serie di valori.
/// `Extend` trait colma questa lacuna, consentendoti di estendere una raccolta includendo i contenuti di quell'iteratore.
/// Quando si estende una collezione con una chiave già esistente, quella voce viene aggiornata o, nel caso di collezioni che consentono più voci con chiavi uguali, quella voce viene inserita.
///
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// // Puoi estendere una stringa con alcuni caratteri:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementazione di `Extend`:
///
/// ```
/// // Una raccolta di campioni, che è solo un involucro su Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Diamo alcuni metodi in modo che possiamo crearne uno e aggiungere cose ad esso.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // poiché MyCollection ha un elenco di i32, implementiamo Extend per i32
/// impl Extend<i32> for MyCollection {
///
///     // Questo è un po 'più semplice con la firma del tipo concreto: possiamo chiamare extended su qualsiasi cosa che possa essere trasformata in un Iterator che ci dà i32s.
///     // Perché abbiamo bisogno di i32s da inserire in MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // L'implementazione è molto semplice: scorrere l'iteratore e add() ogni elemento a noi stessi.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // estendiamo la nostra collezione con altri tre numeri
/// c.extend(vec![1, 2, 3]);
///
/// // abbiamo aggiunto questi elementi alla fine
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Estende una raccolta con il contenuto di un iteratore.
    ///
    /// Poiché questo è l'unico metodo richiesto per questo trait, i documenti [trait-level] contengono maggiori dettagli.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // Puoi estendere una stringa con alcuni caratteri:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Estende una collezione con esattamente un elemento.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Riserva la capacità in una raccolta per il numero specificato di elementi aggiuntivi.
    ///
    /// L'implementazione predefinita non fa nulla.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}