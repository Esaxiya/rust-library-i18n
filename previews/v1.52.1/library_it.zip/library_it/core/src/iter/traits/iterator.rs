// ignore-tidy-filelength Questo file consiste quasi esclusivamente nella definizione di `Iterator`.
// Non possiamo dividerlo in più file.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Un'interfaccia per gestire gli iteratori.
///
/// Questo è l'iteratore principale trait.
/// Per ulteriori informazioni sul concetto di iteratori in generale, vedere [module-level documentation].
/// In particolare, potresti voler sapere come fare [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Il tipo di elementi su cui eseguire l'iterazione.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Fa avanzare l'iteratore e restituisce il valore successivo.
    ///
    /// Restituisce [`None`] al termine dell'iterazione.
    /// Le implementazioni di singoli iteratori possono scegliere di riprendere l'iterazione, quindi chiamare di nuovo `next()` potrebbe o meno iniziare a restituire [`Some(Item)`] di nuovo ad un certo punto.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Una chiamata a next() restituisce il valore successivo ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... e poi Nessuno una volta che è finito.
    /// assert_eq!(None, iter.next());
    ///
    /// // Più chiamate possono o non possono restituire `None`.Qui lo faranno sempre.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Restituisce i limiti sulla lunghezza rimanente dell'iteratore.
    ///
    /// In particolare, `size_hint()` restituisce una tupla in cui il primo elemento è il limite inferiore e il secondo elemento è il limite superiore.
    ///
    /// La seconda metà della tupla restituita è un [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] qui significa che non esiste un limite superiore noto o che il limite superiore è maggiore di [`usize`].
    ///
    /// # Note di implementazione
    ///
    /// Non è imposto che un'implementazione iteratore produca il numero dichiarato di elementi.Un iteratore con errori può produrre meno del limite inferiore o più del limite superiore degli elementi.
    ///
    /// `size_hint()` è concepito principalmente per essere utilizzato per ottimizzazioni come la prenotazione di spazio per gli elementi dell'iteratore, ma non deve essere considerato attendibile, ad esempio, per omettere i controlli dei limiti in codice non sicuro.
    /// Un'implementazione errata di `size_hint()` non dovrebbe portare a violazioni della sicurezza della memoria.
    ///
    /// Detto questo, l'implementazione dovrebbe fornire una stima corretta, perché altrimenti sarebbe una violazione del protocollo trait.
    ///
    /// L'implementazione predefinita restituisce `(0,` [`None`]`)`che è corretta per qualsiasi iteratore.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Un esempio più complesso:
    ///
    /// ```
    /// // I numeri pari da zero a dieci.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Potremmo iterare da zero a dieci volte.
    /// // Sapere che sono esattamente cinque non sarebbe possibile senza eseguire filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Aggiungiamo altri cinque numeri con chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ora entrambi i limiti sono aumentati di cinque
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Restituzione di `None` per un limite superiore:
    ///
    /// ```
    /// // un iteratore infinito non ha limite superiore e il limite inferiore massimo possibile
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Consuma l'iteratore, contando il numero di iterazioni e restituendolo.
    ///
    /// Questo metodo chiamerà [`next`] ripetutamente fino a quando non incontra [`None`], restituendo il numero di volte in cui ha visto [`Some`].
    /// Nota che [`next`] deve essere chiamato almeno una volta anche se l'iteratore non ha elementi.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Comportamento di overflow
    ///
    /// Il metodo non protegge dagli overflow, quindi il conteggio degli elementi di un iteratore con più di [`usize::MAX`] elementi produce il risultato sbagliato o panics.
    ///
    /// Se le asserzioni di debug sono abilitate, è garantito uno panic.
    ///
    /// # Panics
    ///
    /// Questa funzione potrebbe panic se l'iteratore ha più di elementi [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Consuma l'iteratore, restituendo l'ultimo elemento.
    ///
    /// Questo metodo valuterà l'iteratore fino a quando non restituirà [`None`].
    /// Mentre lo fa, tiene traccia dell'elemento corrente.
    /// Dopo che [`None`] è stato restituito, `last()` restituirà l'ultimo elemento che ha visto.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Fa avanzare l'iteratore di elementi `n`.
    ///
    /// Questo metodo salterà con entusiasmo gli elementi `n` chiamando [`next`] fino a `n` volte fino a quando non viene incontrato [`None`].
    ///
    /// `advance_by(n)` restituirà [`Ok(())`][Ok] se l'iteratore avanza con successo di elementi `n`, o [`Err(k)`][Err] se viene incontrato [`None`], dove `k` è il numero di elementi di cui l'iteratore è avanzato prima di esaurire gli elementi (es.
    /// la lunghezza dell'iteratore).
    /// Nota che `k` è sempre minore di `n`.
    ///
    /// La chiamata a `advance_by(0)` non consuma alcun elemento e restituisce sempre [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // solo `&4` è stato ignorato
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Restituisce l'elemento "n" dell'iteratore.
    ///
    /// Come la maggior parte delle operazioni di indicizzazione, il conteggio inizia da zero, quindi `nth(0)` restituisce il primo valore, `nth(1)` il secondo e così via.
    ///
    /// Nota che tutti gli elementi precedenti, così come l'elemento restituito, verranno consumati dall'iteratore.
    /// Ciò significa che gli elementi precedenti verranno scartati e anche che chiamare `nth(0)` più volte sullo stesso iteratore restituirà elementi diversi.
    ///
    ///
    /// `nth()` restituirà [`None`] se `n` è maggiore o uguale alla lunghezza dell'iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Chiamare `nth()` più volte non riavvolge l'iteratore:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Restituzione di `None` se sono presenti meno di `n + 1` elementi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Crea un iteratore che parte dallo stesso punto, ma aumenta della quantità data a ogni iterazione.
    ///
    /// Nota 1: il primo elemento dell'iteratore verrà sempre restituito, indipendentemente dal passaggio fornito.
    ///
    /// Nota 2: l'ora in cui vengono estratti gli elementi ignorati non è fissa.
    /// `StepBy` si comporta come la sequenza `next(), nth(step-1), nth(step-1),…`, ma è anche libera di comportarsi come la sequenza
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Il modo in cui viene utilizzato può cambiare per alcuni iteratori per motivi di prestazioni.
    /// Il secondo modo farà avanzare l'iteratore prima e potrebbe consumare più elementi.
    ///
    /// `advance_n_and_return_first` è l'equivalente di:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Il metodo sarà panic se il passaggio specificato è `0`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Prende due iteratori e crea un nuovo iteratore su entrambi in sequenza.
    ///
    /// `chain()` restituirà un nuovo iteratore che itererà prima sui valori del primo iteratore e poi sui valori del secondo iteratore.
    ///
    /// In altre parole, collega due iteratori insieme, in una catena.🔗
    ///
    /// [`once`] è comunemente usato per adattare un singolo valore in una catena di altri tipi di iterazione.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché l'argomento di `chain()` utilizza [`IntoIterator`], possiamo passare qualsiasi cosa che possa essere convertita in [`Iterator`], non solo un [`Iterator`] stesso.
    /// Ad esempio, le slice (`&[T]`) implementano [`IntoIterator`] e quindi possono essere passate direttamente a `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se lavori con l'API Windows, potresti voler convertire [`OsStr`] in `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "Comprime" due iteratori in un unico iteratore di coppie.
    ///
    /// `zip()` restituisce un nuovo iteratore che itererà su altri due iteratori, restituendo una tupla in cui il primo elemento proviene dal primo iteratore e il secondo elemento proviene dal secondo iteratore.
    ///
    ///
    /// In altre parole, unisce due iteratori in uno solo.
    ///
    /// Se uno degli iteratori restituisce [`None`], [`next`] dall'iteratore zippato restituirà [`None`].
    /// Se il primo iteratore restituisce [`None`], `zip` andrà in cortocircuito e `next` non verrà chiamato sul secondo iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché l'argomento di `zip()` utilizza [`IntoIterator`], possiamo passare qualsiasi cosa che possa essere convertita in [`Iterator`], non solo un [`Iterator`] stesso.
    /// Ad esempio, le slice (`&[T]`) implementano [`IntoIterator`] e quindi possono essere passate direttamente a `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` viene spesso utilizzato per comprimere un iteratore infinito in uno finito.
    /// Questo funziona perché l'iteratore finito alla fine restituirà [`None`], terminando la chiusura lampo.Lo zippare con `(0..)` può assomigliare molto a [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Crea un nuovo iteratore che inserisce una copia di `separator` tra gli elementi adiacenti dell'iteratore originale.
    ///
    /// Nel caso in cui `separator` non implementa [`Clone`] o deve essere calcolato ogni volta, utilizzare [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Il primo elemento di `a`.
    /// assert_eq!(a.next(), Some(&100)); // Il separatore.
    /// assert_eq!(a.next(), Some(&1));   // Il prossimo elemento di `a`.
    /// assert_eq!(a.next(), Some(&100)); // Il separatore.
    /// assert_eq!(a.next(), Some(&2));   // L'ultimo elemento di `a`.
    /// assert_eq!(a.next(), None);       // L'iteratore è terminato.
    /// ```
    ///
    /// `intersperse` può essere molto utile per unire gli elementi di un iteratore utilizzando un elemento comune:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Crea un nuovo iteratore che posiziona un elemento generato da `separator` tra elementi adiacenti dell'iteratore originale.
    ///
    /// La chiusura verrà chiamata esattamente una volta ogni volta che un elemento viene posizionato tra due elementi adiacenti dall'iteratore sottostante;
    /// in particolare, la chiusura non viene chiamata se l'iteratore sottostante restituisce meno di due elementi e dopo che l'ultimo elemento è stato restituito.
    ///
    ///
    /// Se l'elemento dell'iteratore implementa [`Clone`], potrebbe essere più semplice utilizzare [`intersperse`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Il primo elemento di `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Il separatore.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Il prossimo elemento di `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Il separatore.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // L'ultimo elemento di `v`.
    /// assert_eq!(it.next(), None);               // L'iteratore è terminato.
    /// ```
    ///
    /// `intersperse_with` può essere utilizzato in situazioni in cui è necessario calcolare il separatore:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // La chiusura mutuamente prende in prestito il suo contesto per generare un elemento.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Prende una chiusura e crea un iteratore che chiama quella chiusura su ogni elemento.
    ///
    /// `map()` trasforma un iteratore in un altro, tramite il suo argomento:
    /// qualcosa che implementa [`FnMut`].Produce un nuovo iteratore che chiama questa chiusura su ogni elemento dell'iteratore originale.
    ///
    /// Se sei bravo a pensare per tipi, puoi pensare a `map()` in questo modo:
    /// Se hai un iteratore che ti dà elementi di qualche tipo `A`, e vuoi un iteratore di qualche altro tipo `B`, puoi usare `map()`, passando una chiusura che prende un `A` e restituisce un `B`.
    ///
    ///
    /// `map()` è concettualmente simile a un ciclo [`for`].Tuttavia, poiché `map()` è pigro, è meglio usarlo quando stai già lavorando con altri iteratori.
    /// Se stai eseguendo una sorta di loop per un effetto collaterale, è considerato più idiomatico usare [`for`] rispetto a `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se stai facendo una sorta di effetto collaterale, preferisci [`for`] a `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // non farlo:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // non verrà nemmeno eseguito, poiché è pigro.Rust ti avviserà di questo.
    ///
    /// // Utilizzare invece per:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Richiama una chiusura su ogni elemento di un iteratore.
    ///
    /// Ciò equivale a utilizzare un ciclo [`for`] sull'iteratore, sebbene `break` e `continue` non siano possibili da una chiusura.
    /// In genere è più idiomatico utilizzare un ciclo `for`, ma `for_each` potrebbe essere più leggibile durante l'elaborazione di elementi alla fine di catene di iteratori più lunghe.
    ///
    /// In alcuni casi `for_each` può anche essere più veloce di un loop, perché utilizzerà l'iterazione interna su adattatori come `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Per un esempio così piccolo, un ciclo `for` potrebbe essere più pulito, ma `for_each` potrebbe essere preferibile per mantenere uno stile funzionale con iteratori più lunghi:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Crea un iteratore che utilizza una chiusura per determinare se un elemento deve essere restituito.
    ///
    /// Dato un elemento la chiusura deve restituire `true` o `false`.L'iteratore restituito restituirà solo gli elementi per i quali la chiusura restituisce true.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché la chiusura passata a `filter()` prende un riferimento e molti iteratori ripetono i riferimenti, questo porta a una situazione potenzialmente confusa, in cui il tipo di chiusura è un doppio riferimento:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // servono due * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// È comune invece utilizzare la destrutturazione sull'argomento per rimuoverne uno:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // entrambi e *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// o entrambi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // due &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// di questi strati.
    ///
    /// Notare che `iter.filter(f).next()` è equivalente a `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Crea un iteratore che filtra e mappa.
    ///
    /// L'iteratore restituito restituisce solo il "valore" per il quale la chiusura fornita restituisce `Some(value)`.
    ///
    /// `filter_map` può essere utilizzato per rendere più concise le catene di [`filter`] e [`map`].
    /// L'esempio seguente mostra come un `map().filter().map()` può essere abbreviato in una singola chiamata a `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ecco lo stesso esempio, ma con [`filter`] e [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Crea un iteratore che fornisce il conteggio dell'iterazione corrente e il valore successivo.
    ///
    /// L'iteratore restituito produce coppie `(i, val)`, dove `i` è l'indice di iterazione corrente e `val` è il valore restituito dall'iteratore.
    ///
    ///
    /// `enumerate()` mantiene il suo conteggio come [`usize`].
    /// Se si desidera contare con un numero intero di dimensioni diverse, la funzione [`zip`] fornisce funzionalità simili.
    ///
    /// # Comportamento di overflow
    ///
    /// Il metodo non protegge dagli overflow, quindi l'enumerazione di più di elementi [`usize::MAX`] produce il risultato sbagliato o panics.
    /// Se le asserzioni di debug sono abilitate, è garantito uno panic.
    ///
    /// # Panics
    ///
    /// L'iteratore restituito potrebbe panic se l'indice da restituire superasse un [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Crea un iteratore che può utilizzare [`peek`] per esaminare l'elemento successivo dell'iteratore senza consumarlo.
    ///
    /// Aggiunge un metodo [`peek`] a un iteratore.Vedere la relativa documentazione per ulteriori informazioni.
    ///
    /// Si noti che l'iteratore sottostante è ancora avanzato quando [`peek`] viene chiamato per la prima volta: per recuperare l'elemento successivo, [`next`] viene richiamato sull'iteratore sottostante, quindi qualsiasi effetto collaterale (ad es.
    ///
    /// si verificherà qualcosa di diverso dal recupero del valore successivo) del metodo [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ci permette di vedere nello future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // possiamo peek() più volte, l'iteratore non avanzerà
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // dopo che l'iteratore è terminato, lo è anche peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Crea un iteratore che [`skip`] s elementi basati su un predicato.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` accetta una chiusura come argomento.Chiamerà questa chiusura su ogni elemento dell'iteratore e ignorerà gli elementi finché non restituirà `false`.
    ///
    /// Dopo che `false` è stato restituito, il lavoro `skip_while()`'s è terminato e gli altri elementi vengono ceduti.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché la chiusura passata a `skip_while()` accetta un riferimento e molti iteratori ripetono i riferimenti, questo porta a una situazione potenzialmente confusa, in cui il tipo dell'argomento di chiusura è un doppio riferimento:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // servono due * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arresto dopo un `false` iniziale:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // mentre questo sarebbe stato falso, dato che abbiamo già un falso, skip_while() non viene più utilizzato
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Crea un iteratore che produce elementi basati su un predicato.
    ///
    /// `take_while()` accetta una chiusura come argomento.Chiamerà questa chiusura su ogni elemento dell'iteratore e restituirà elementi mentre restituisce `true`.
    ///
    /// Dopo la restituzione di `false`, il lavoro `take_while()`'s è terminato e gli altri elementi vengono ignorati.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché la chiusura passata a `take_while()` prende un riferimento e molti iteratori ripetono i riferimenti, questo porta a una situazione potenzialmente confusa, in cui il tipo di chiusura è un doppio riferimento:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // servono due * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arresto dopo un `false` iniziale:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Abbiamo più elementi inferiori a zero, ma poiché abbiamo già un falso, take_while() non viene più utilizzato
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Poiché `take_while()` ha bisogno di guardare il valore per vedere se dovrebbe essere incluso o meno, consumando iteratori vedrà che è stato rimosso:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// L `3` non è più lì, perché è stato consumato per vedere se l'iterazione doveva fermarsi, ma non è stato reinserito nell'iteratore.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Crea un iteratore che produce entrambi elementi basati su un predicato e mappe.
    ///
    /// `map_while()` accetta una chiusura come argomento.
    /// Chiamerà questa chiusura su ogni elemento dell'iteratore e restituirà elementi mentre restituisce [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ecco lo stesso esempio, ma con [`take_while`] e [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Arresto dopo un [`None`] iniziale:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Abbiamo più elementi che potrebbero essere contenuti in u32 (4, 5), ma `map_while` ha restituito `None` per `-3` (poiché `predicate` ha restituito `None`) e `collect` si ferma al primo `None` incontrato.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Poiché `map_while()` ha bisogno di guardare il valore per vedere se dovrebbe essere incluso o meno, consumando iteratori vedrà che è stato rimosso:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// L `-3` non è più lì, perché è stato consumato per vedere se l'iterazione doveva fermarsi, ma non è stato reinserito nell'iteratore.
    ///
    /// Nota che a differenza di [`take_while`] questo iteratore **non** è fuso.
    /// Inoltre, non viene specificato cosa restituisce questo iteratore dopo la restituzione del primo [`None`].
    /// Se hai bisogno di un iteratore fuso, usa [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Crea un iteratore che salta i primi elementi `n`.
    ///
    /// Dopo che sono stati consumati, il resto degli elementi viene ceduto.
    /// Invece di sovrascrivere direttamente questo metodo, sovrascrivi invece il metodo `nth`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Crea un iteratore che produce i suoi primi elementi `n`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` viene spesso utilizzato con un iteratore infinito, per renderlo finito:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Se sono disponibili meno di `n` elementi, `take` si limiterà alla dimensione dell'iteratore sottostante:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Un adattatore iteratore simile a [`fold`] che mantiene lo stato interno e produce un nuovo iteratore.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` accetta due argomenti: un valore iniziale che semina lo stato interno e una chiusura con due argomenti, il primo è un riferimento mutabile allo stato interno e il secondo un elemento iteratore.
    ///
    /// La chiusura può essere assegnata allo stato interno per condividere lo stato tra le iterazioni.
    ///
    /// Durante l'iterazione, la chiusura verrà applicata a ciascun elemento dell'iteratore e il valore restituito dalla chiusura, un [`Option`], viene restituito dall'iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ogni iterazione, moltiplicheremo lo stato per l'elemento
    ///     *state = *state * x;
    ///
    ///     // quindi, cederemo la negazione dello stato
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Crea un iteratore che funziona come map, ma appiattisce la struttura nidificata.
    ///
    /// L'adattatore [`map`] è molto utile, ma solo quando l'argomento di chiusura produce valori.
    /// Se invece produce un iteratore, c'è un ulteriore livello di riferimento indiretto.
    /// `flat_map()` rimuoverà questo livello aggiuntivo da solo.
    ///
    /// Puoi pensare a `flat_map(f)` come l'equivalente semantico di [`map`] ping, e quindi [`flatten`] come in `map(f).flatten()`.
    ///
    /// Un altro modo di pensare a `flat_map()`: la chiusura di [`map`] restituisce un elemento per ogni elemento, e la chiusura di `flat_map()`'s restituisce un iteratore per ogni elemento.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() restituisce un iteratore
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Crea un iteratore che appiattisce la struttura nidificata.
    ///
    /// Ciò è utile quando si dispone di un iteratore di iteratori o di un iteratore di cose che possono essere trasformate in iteratori e si desidera rimuovere un livello di riferimento indiretto.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mappatura e quindi appiattimento:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() restituisce un iteratore
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Puoi anche riscriverlo in termini di [`flat_map()`], che è preferibile in questo caso poiché trasmette l'intento in modo più chiaro:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() restituisce un iteratore
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// L'appiattimento rimuove solo un livello di nidificazione alla volta:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Qui vediamo che `flatten()` non esegue un appiattimento "deep".
    /// Viene invece rimosso solo un livello di nidificazione.Cioè, se `flatten()` è un array tridimensionale, il risultato sarà bidimensionale e non unidimensionale.
    /// Per ottenere una struttura unidimensionale, devi di nuovo `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Crea un iteratore che termina dopo il primo [`None`].
    ///
    /// Dopo che un iteratore ha restituito [`None`], le chiamate future possono o meno restituire [`Some(T)`].
    /// `fuse()` adatta un iteratore, assicurando che dopo che è stato fornito un [`None`], restituirà sempre [`None`] per sempre.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // un iteratore che alterna tra Some e None
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // se è pari, Some(i32), altrimenti Nessuno
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // possiamo vedere il nostro iteratore andare avanti e indietro
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tuttavia, una volta che lo fondiamo ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // restituirà sempre `None` dopo la prima volta.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Fa qualcosa con ogni elemento di un iteratore, trasferendo il valore.
    ///
    /// Quando si usano gli iteratori, spesso ne concatenate diversi insieme.
    /// Mentre lavori su tale codice, potresti voler controllare cosa sta succedendo in varie parti della pipeline.Per farlo, inserisci una chiamata a `inspect()`.
    ///
    /// È più comune che `inspect()` venga utilizzato come strumento di debug piuttosto che esistere nel codice finale, ma le applicazioni potrebbero trovarlo utile in determinate situazioni in cui è necessario registrare gli errori prima di essere eliminati.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // questa sequenza di iteratori è complessa.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // aggiungiamo alcune chiamate inspect() per indagare su cosa sta succedendo
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Questo stamperà:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Registrazione degli errori prima di eliminarli:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Questo stamperà:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Prende in prestito un iteratore, invece di consumarlo.
    ///
    /// Ciò è utile per consentire l'applicazione di adattatori iteratori pur mantenendo la proprietà dell'iteratore originale.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // se proviamo a usare di nuovo l'iter, non funzionerà.
    /// // La riga seguente restituisce "errore: utilizzo del valore spostato: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // proviamolo di nuovo
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // invece, aggiungiamo un .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ora va bene così:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Trasforma un iteratore in una raccolta.
    ///
    /// `collect()` può prendere qualsiasi cosa iterabile e trasformarla in una raccolta pertinente.
    /// Questo è uno dei metodi più potenti nella libreria standard, utilizzato in una varietà di contesti.
    ///
    /// Il modello più semplice in cui viene utilizzato `collect()` è trasformare una raccolta in un'altra.
    /// Prendi una raccolta, chiama [`iter`] su di essa, esegui un mucchio di trasformazioni e poi `collect()` alla fine.
    ///
    /// `collect()` può anche creare istanze di tipi che non sono raccolte tipiche.
    /// Ad esempio, un [`String`] può essere costruito da [`char`] se un iteratore di elementi [`Result<T, E>`][`Result`] può essere raccolto in `Result<Collection<T>, E>`.
    ///
    /// Vedere gli esempi di seguito per ulteriori informazioni.
    ///
    /// Poiché `collect()` è così generale, può causare problemi con l'inferenza del tipo.
    /// In quanto tale, `collect()` è una delle poche volte in cui vedrai la sintassi affettuosamente nota come 'turbofish': `::<>`.
    /// Questo aiuta l'algoritmo di inferenza a capire specificamente in quale raccolta stai cercando di raccogliere.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Nota che avevamo bisogno dell `: Vec<i32>` sul lato sinistro.Questo perché potremmo raccogliere, ad esempio, un [`VecDeque<T>`] invece:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Utilizzando 'turbofish' invece di annotare `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Poiché `collect()` si preoccupa solo di ciò che stai raccogliendo, puoi comunque utilizzare un suggerimento di tipo parziale, `_`, con il turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Utilizzo di `collect()` per creare un [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Se hai un elenco di [`Result<T, E>`][`Result`] s, puoi usare `collect()` per vedere se qualcuno di loro ha fallito:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ci dà il primo errore
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ci fornisce l'elenco delle risposte
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Utilizza un iteratore, creando due raccolte da esso.
    ///
    /// Il predicato passato a `partition()` può restituire `true` o `false`.
    /// `partition()` restituisce una coppia, tutti gli elementi per i quali ha restituito `true` e tutti gli elementi per i quali ha restituito `false`.
    ///
    ///
    /// Vedi anche [`is_partitioned()`] e [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Riordina gli elementi di questo iteratore *sul posto* in base al predicato dato, in modo tale che tutti quelli che restituiscono `true` precedano tutti quelli che restituiscono `false`.
    ///
    /// Restituisce il numero di elementi `true` trovati.
    ///
    /// L'ordine relativo degli elementi partizionati non viene mantenuto.
    ///
    /// Vedi anche [`is_partitioned()`] e [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Partizione sul posto tra pari e dispari
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: dovremmo preoccuparci del conteggio traboccante?L'unico modo per avere più di
        // `usize::MAX` i riferimenti mutabili sono con ZST, che non sono utili per partizionare ...

        // Queste funzioni di chiusura "factory" esistono per evitare la genericità in `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Trova ripetutamente il primo `false` e scambialo con l'ultimo `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Controlla se gli elementi di questo iteratore sono partizionati in base al predicato dato, in modo tale che tutti quelli che restituiscono `true` precedano tutti quelli che restituiscono `false`.
    ///
    ///
    /// Vedi anche [`partition()`] e [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // O tutti gli elementi testano `true` o la prima clausola si ferma a `false` e controlliamo che non ci siano più elementi `true` dopo.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Un metodo iteratore che applica una funzione fintanto che viene restituita correttamente, producendo un singolo valore finale.
    ///
    /// `try_fold()` accetta due argomenti: un valore iniziale e una chiusura con due argomenti: un 'accumulator' e un elemento.
    /// La chiusura ritorna correttamente, con il valore che l'accumulatore dovrebbe avere per l'iterazione successiva, oppure restituisce un errore, con un valore di errore che viene propagato immediatamente al chiamante (short-circuiting).
    ///
    ///
    /// Il valore iniziale è il valore che l'accumulatore avrà alla prima chiamata.Se l'applicazione della chiusura è riuscita su ogni elemento dell'iteratore, `try_fold()` restituisce l'accumulatore finale come successo.
    ///
    /// La piegatura è utile ogni volta che hai una raccolta di qualcosa e vuoi produrre un singolo valore da essa.
    ///
    /// # Nota per gli implementatori
    ///
    /// Molti degli altri metodi (forward) hanno implementazioni predefinite in termini di questo, quindi prova a implementarlo esplicitamente se può fare qualcosa di meglio dell'implementazione del ciclo `for` predefinita.
    ///
    /// In particolare, prova ad avere questa chiamata `try_fold()` sulle parti interne da cui è composto questo iteratore.
    /// Se sono necessarie più chiamate, l'operatore `?` può essere conveniente per concatenare il valore dell'accumulatore, ma attenzione a qualsiasi invariante che deve essere confermato prima di quei primi ritorni.
    /// Questo è un metodo `&mut self`, quindi l'iterazione deve essere ripristinata dopo aver riscontrato un errore qui.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la somma controllata di tutti gli elementi dell'array
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Questa somma trabocca quando si aggiunge l'elemento 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Poiché è andato in cortocircuito, gli elementi rimanenti sono ancora disponibili tramite l'iteratore.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un metodo iteratore che applica una funzione fallibile a ogni elemento nell'iteratore, fermandosi al primo errore e restituendo quell'errore.
    ///
    ///
    /// Questo può anche essere pensato come la forma fallibile di [`for_each()`] o come la versione senza stato di [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // È andato in cortocircuito, quindi gli elementi rimanenti sono ancora nell'iteratore:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Piega ogni elemento in un accumulatore applicando un'operazione, restituendo il risultato finale.
    ///
    /// `fold()` accetta due argomenti: un valore iniziale e una chiusura con due argomenti: un 'accumulator' e un elemento.
    /// La chiusura restituisce il valore che l'accumulatore dovrebbe avere per l'iterazione successiva.
    ///
    /// Il valore iniziale è il valore che l'accumulatore avrà alla prima chiamata.
    ///
    /// Dopo aver applicato questa chiusura a ogni elemento dell'iteratore, `fold()` restituisce l'accumulatore.
    ///
    /// Questa operazione è talvolta chiamata 'reduce' o 'inject'.
    ///
    /// La piegatura è utile ogni volta che hai una raccolta di qualcosa e vuoi produrre un singolo valore da essa.
    ///
    /// Note: `fold()`, e metodi simili che attraversano l'intero iteratore, non possono terminare per infiniti iteratori, anche su traits per cui un risultato è determinabile in tempo finito.
    ///
    /// Note: [`reduce()`] può essere utilizzato per utilizzare il primo elemento come valore iniziale, se il tipo di accumulatore e il tipo di elemento sono gli stessi.
    ///
    /// # Nota per gli implementatori
    ///
    /// Molti degli altri metodi (forward) hanno implementazioni predefinite in termini di questo, quindi prova a implementarlo esplicitamente se può fare qualcosa di meglio dell'implementazione del ciclo `for` predefinita.
    ///
    ///
    /// In particolare, prova ad avere questa chiamata `fold()` sulle parti interne da cui è composto questo iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la somma di tutti gli elementi dell'array
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Esaminiamo qui ogni passaggio dell'iterazione:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// E così, il nostro risultato finale, `6`.
    ///
    /// È comune per le persone che non hanno usato molto gli iteratori usare un ciclo `for` con un elenco di cose per costruire un risultato.Questi possono essere trasformati in `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // per loop:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // sono la stessa cosa
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Riduce gli elementi ad uno solo, applicando ripetutamente un'operazione di riduzione.
    ///
    /// Se l'iteratore è vuoto, restituisce [`None`];in caso contrario, restituisce il risultato della riduzione.
    ///
    /// Per gli iteratori con almeno un elemento, questo è lo stesso di [`fold()`] con il primo elemento dell'iteratore come valore iniziale, ripiegando ogni elemento successivo in esso.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Trova il valore massimo:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Verifica se ogni elemento dell'iteratore corrisponde a un predicato.
    ///
    /// `all()` prende una chiusura che restituisce `true` o `false`.Applica questa chiusura a ogni elemento dell'iteratore e, se restituiscono tutti `true`, lo fa anche `all()`.
    /// Se qualcuno di loro restituisce `false`, restituisce `false`.
    ///
    /// `all()` è in corto circuito;in altre parole, interromperà l'elaborazione non appena troverà un `false`, dato che qualunque cosa accada, anche il risultato sarà `false`.
    ///
    ///
    /// Un iteratore vuoto restituisce `true`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Fermarsi al primo `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Verifica se qualsiasi elemento dell'iteratore corrisponde a un predicato.
    ///
    /// `any()` prende una chiusura che restituisce `true` o `false`.Applica questa chiusura a ogni elemento dell'iteratore e, se qualcuno di essi restituisce `true`, lo fa anche `any()`.
    /// Se restituiscono tutti `false`, restituisce `false`.
    ///
    /// `any()` è in cortocircuito;in altre parole, interromperà l'elaborazione non appena troverà un `true`, dato che qualunque cosa accada, anche il risultato sarà `true`.
    ///
    ///
    /// Un iteratore vuoto restituisce `false`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Fermarsi al primo `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Cerca un elemento di un iteratore che soddisfi un predicato.
    ///
    /// `find()` prende una chiusura che restituisce `true` o `false`.
    /// Applica questa chiusura a ogni elemento dell'iteratore e se qualcuno di essi restituisce `true`, `find()` restituisce [`Some(element)`].
    /// Se restituiscono tutti `false`, restituisce [`None`].
    ///
    /// `find()` è in corto circuito;in altre parole, interromperà l'elaborazione non appena la chiusura restituirà `true`.
    ///
    /// Poiché `find()` accetta un riferimento e molti iteratori ripetono i riferimenti, ciò porta a una situazione potenzialmente confusa in cui l'argomento è un doppio riferimento.
    ///
    /// Puoi vedere questo effetto negli esempi seguenti, con `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Fermarsi al primo `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Notare che `iter.find(f)` è equivalente a `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Applica la funzione agli elementi dell'iteratore e restituisce il primo risultato diverso da nessuno.
    ///
    ///
    /// `iter.find_map(f)` è equivalente a `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Applica la funzione agli elementi dell'iteratore e restituisce il primo risultato vero o il primo errore.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Cerca un elemento in un iteratore, restituendone l'indice.
    ///
    /// `position()` prende una chiusura che restituisce `true` o `false`.
    /// Applica questa chiusura a ogni elemento dell'iteratore e se uno di essi restituisce `true`, `position()` restituisce [`Some(index)`].
    /// Se tutti restituiscono `false`, restituisce [`None`].
    ///
    /// `position()` è in corto circuito;in altre parole, interromperà l'elaborazione non appena troverà un `true`.
    ///
    /// # Comportamento di overflow
    ///
    /// Il metodo non protegge dagli overflow, quindi se ci sono più di [`usize::MAX`] elementi non corrispondenti, produce il risultato sbagliato o panics.
    ///
    /// Se le asserzioni di debug sono abilitate, è garantito uno panic.
    ///
    /// # Panics
    ///
    /// Questa funzione potrebbe panic se l'iteratore ha più di `usize::MAX` elementi non corrispondenti.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Fermarsi al primo `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // L'indice restituito dipende dallo stato dell'iteratore
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Cerca un elemento in un iteratore da destra, restituendone l'indice.
    ///
    /// `rposition()` prende una chiusura che restituisce `true` o `false`.
    /// Applica questa chiusura a ogni elemento dell'iteratore, a partire dalla fine, e se uno di essi restituisce `true`, `rposition()` restituisce [`Some(index)`].
    ///
    /// Se tutti restituiscono `false`, restituisce [`None`].
    ///
    /// `rposition()` è in corto circuito;in altre parole, interromperà l'elaborazione non appena troverà un `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Fermarsi al primo `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Non è necessario un controllo dell'overflow qui, perché `ExactSizeIterator` implica che il numero di elementi si adatta a un `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Restituisce l'elemento massimo di un iteratore.
    ///
    /// Se più elementi sono ugualmente massimi, viene restituito l'ultimo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Restituisce l'elemento minimo di un iteratore.
    ///
    /// Se più elementi sono ugualmente minimi, viene restituito il primo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Restituisce l'elemento che fornisce il valore massimo dalla funzione specificata.
    ///
    ///
    /// Se più elementi sono ugualmente massimi, viene restituito l'ultimo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Restituisce l'elemento che fornisce il valore massimo rispetto alla funzione di confronto specificata.
    ///
    ///
    /// Se più elementi sono ugualmente massimi, viene restituito l'ultimo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Restituisce l'elemento che fornisce il valore minimo dalla funzione specificata.
    ///
    ///
    /// Se più elementi sono ugualmente minimi, viene restituito il primo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Restituisce l'elemento che fornisce il valore minimo rispetto alla funzione di confronto specificata.
    ///
    ///
    /// Se più elementi sono ugualmente minimi, viene restituito il primo elemento.
    /// Se l'iteratore è vuoto, viene restituito [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inverte la direzione di un iteratore.
    ///
    /// Di solito, gli iteratori eseguono l'iterazione da sinistra a destra.
    /// Dopo aver utilizzato `rev()`, un iteratore itererà invece da destra a sinistra.
    ///
    /// Questo è possibile solo se l'iteratore ha una fine, quindi `rev()` funziona solo su [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Converte un iteratore di coppie in una coppia di contenitori.
    ///
    /// `unzip()` consuma un intero iteratore di coppie, producendo due raccolte: una dagli elementi di sinistra delle coppie e una dagli elementi di destra.
    ///
    ///
    /// Questa funzione è, in un certo senso, l'opposto di [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Crea un iteratore che copia tutti i suoi elementi.
    ///
    /// Questo è utile quando hai un iteratore su `&T`, ma hai bisogno di un iteratore su `T`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // copiato è lo stesso di .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Crea un iteratore che [`clone`] s tutti i suoi elementi.
    ///
    /// Questo è utile quando hai un iteratore su `&T`, ma hai bisogno di un iteratore su `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned è uguale a .map(|&x| x), per i numeri interi
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ripete un iteratore all'infinito.
    ///
    /// Invece di fermarsi a [`None`], l'iteratore ricomincerà invece dall'inizio.Dopo l'iterazione di nuovo, ricomincerà dall'inizio.E di nuovo.
    /// E di nuovo.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Somma gli elementi di un iteratore.
    ///
    /// Prende ogni elemento, li somma e restituisce il risultato.
    ///
    /// Un iteratore vuoto restituisce il valore zero del tipo.
    ///
    /// # Panics
    ///
    /// Quando si chiama `sum()` e viene restituito un tipo intero primitivo, questo metodo panic se il calcolo è in overflow e le asserzioni di debug sono abilitate.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itera sull'intero iteratore, moltiplicando tutti gli elementi
    ///
    /// Un iteratore vuoto restituisce l'unico valore del tipo.
    ///
    /// # Panics
    ///
    /// Quando si chiama `product()` e viene restituito un tipo intero primitivo, il metodo panic se il calcolo è in overflow e le asserzioni di debug sono abilitate.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta gli elementi di questo [`Iterator`] con quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta gli elementi di questo [`Iterator`] con quelli di un altro rispetto alla funzione di confronto specificata.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta gli elementi di questo [`Iterator`] con quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) confronta gli elementi di questo [`Iterator`] con quelli di un altro rispetto alla funzione di confronto specificata.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Determina se gli elementi di questo [`Iterator`] sono uguali a quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Determina se gli elementi di questo [`Iterator`] sono uguali a quelli di un altro rispetto alla funzione di uguaglianza specificata.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Determina se gli elementi di questo [`Iterator`] sono diversi da quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Determina se gli elementi di questo [`Iterator`] sono [lexicographically](Ord#lexicographical-comparison) inferiori a quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Determina se gli elementi di questo [`Iterator`] sono [lexicographically](Ord#lexicographical-comparison) inferiori o uguali a quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Determina se gli elementi di questo [`Iterator`] sono [lexicographically](Ord#lexicographical-comparison) maggiori di quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Determina se gli elementi di questo [`Iterator`] sono [lexicographically](Ord#lexicographical-comparison) maggiori o uguali a quelli di un altro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Controlla se gli elementi di questo iteratore sono ordinati.
    ///
    /// Cioè, per ogni elemento `a` e il suo elemento successivo `b`, `a <= b` deve contenere.Se l'iteratore restituisce esattamente zero o un elemento, viene restituito `true`.
    ///
    /// Si noti che se `Self::Item` è solo `PartialOrd`, ma non `Ord`, la definizione precedente implica che questa funzione restituisca `false` se due elementi consecutivi non sono confrontabili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Controlla se gli elementi di questo iteratore sono ordinati utilizzando la funzione di confronto data.
    ///
    /// Invece di usare `PartialOrd::partial_cmp`, questa funzione usa la funzione `compare` data per determinare l'ordinamento di due elementi.
    /// A parte questo, è equivalente a [`is_sorted`];vedere la sua documentazione per maggiori informazioni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Controlla se gli elementi di questo iteratore sono ordinati utilizzando la funzione di estrazione della chiave specificata.
    ///
    /// Invece di confrontare direttamente gli elementi dell'iteratore, questa funzione confronta le chiavi degli elementi, come determinato da `f`.
    /// A parte questo, è equivalente a [`is_sorted`];vedere la sua documentazione per maggiori informazioni.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Vedi [TrustedRandomAccess]
    // Il nome insolito è quello di evitare conflitti di nome nella risoluzione del metodo, vedere #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}