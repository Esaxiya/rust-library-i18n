/// Un iteratore che continua sempre a produrre `None` quando è esaurito.
///
/// La chiamata successiva su un iteratore fuso che ha restituito `None` una volta è garantito per restituire nuovamente [`None`].
/// Questo trait dovrebbe essere implementato da tutti gli iteratori che si comportano in questo modo perché permette di ottimizzare [`Iterator::fuse()`].
///
///
/// Note: In generale, non dovresti usare `FusedIterator` in limiti generici se hai bisogno di un iteratore fuso.
/// Invece, dovresti semplicemente chiamare [`Iterator::fuse()`] sull'iteratore.
/// Se l'iteratore è già fuso, il wrapper [`Fuse`] aggiuntivo sarà un no-op senza alcuna penalizzazione delle prestazioni.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Un iteratore che riporta una lunghezza accurata utilizzando size_hint.
///
/// L'iteratore riporta un suggerimento sulla dimensione in cui è esatto (il limite inferiore è uguale al limite superiore) o il limite superiore è [`None`].
///
/// Il limite superiore deve essere [`None`] solo se la lunghezza effettiva dell'iteratore è maggiore di [`usize::MAX`].
/// In tal caso, il limite inferiore deve essere [`usize::MAX`], risultando in un [`Iterator::size_hint()`] di `(usize::MAX, None)`.
///
/// L'iteratore deve produrre esattamente il numero di elementi che ha riportato o divergere prima di raggiungere la fine.
///
/// # Safety
///
/// Questo trait deve essere implementato solo quando il contratto è confermato.
/// I consumatori di questo trait devono ispezionare il limite superiore [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Un iteratore che durante la resa di un elemento avrà preso almeno un elemento dal suo [`SourceIter`] sottostante.
///
/// Chiamando qualsiasi metodo che avanza l'iteratore, ad es
/// [`next()`] o [`try_fold()`], garantisce che per ogni passo almeno un valore della sorgente sottostante dell'iteratore è stato spostato e il risultato della catena dell'iteratore potrebbe essere inserito al suo posto, supponendo che i vincoli strutturali della sorgente consentano tale inserimento.
///
/// In altre parole, questo trait indica che una pipeline iteratore può essere raccolta sul posto.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}