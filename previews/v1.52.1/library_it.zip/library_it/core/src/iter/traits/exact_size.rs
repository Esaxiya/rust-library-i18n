/// Un iteratore che conosce la sua lunghezza esatta.
///
/// Molti [`Iteratori`] non sanno quante volte itereranno, ma alcuni sì.
/// Se un iteratore sa quante volte può iterare, può essere utile fornire l'accesso a tali informazioni.
/// Ad esempio, se vuoi iterare all'indietro, un buon inizio è sapere dove si trova la fine.
///
/// Quando si implementa un `ExactSizeIterator`, è necessario implementare anche [`Iterator`].
/// In tal caso, l'implementazione di [`Iterator::size_hint`]*deve* restituire la dimensione esatta dell'iteratore.
///
/// Il metodo [`len`] ha un'implementazione predefinita, quindi di solito non dovresti implementarlo.
/// Tuttavia, potresti essere in grado di fornire un'implementazione più performante rispetto all'impostazione predefinita, quindi sovrascriverla in questo caso ha senso.
///
///
/// Nota che questo trait è uno trait sicuro e come tale *non* e *non può* garantire che la lunghezza restituita sia corretta.
/// Ciò significa che il codice `unsafe`**non deve** fare affidamento sulla correttezza di [`Iterator::size_hint`].
/// L'instabile e pericoloso [`TrustedLen`](super::marker::TrustedLen) trait offre questa garanzia aggiuntiva.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// // un intervallo finito sa esattamente quante volte itererà
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Nell [module-level docs], abbiamo implementato un [`Iterator`], `Counter`.
/// Implementiamo `ExactSizeIterator` anche per questo:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Possiamo facilmente calcolare il numero rimanente di iterazioni.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // E ora possiamo usarlo!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Restituisce la lunghezza esatta dell'iteratore.
    ///
    /// L'implementazione garantisce che l'iteratore restituisca esattamente `len()` più volte un valore [`Some(T)`], prima di restituire [`None`].
    ///
    /// Questo metodo ha un'implementazione predefinita, quindi di solito non dovresti implementarlo direttamente.
    /// Tuttavia, se puoi fornire un'implementazione più efficiente, puoi farlo.
    /// Vedere i documenti [trait-level] per un esempio.
    ///
    /// Questa funzione ha le stesse garanzie di sicurezza della funzione [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // un intervallo finito sa esattamente quante volte itererà
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Questa affermazione è eccessivamente difensiva, ma controlla l'invariante
        // garantito dallo trait.
        // Se questo trait fosse rust-interno, potremmo usare debug_assert !;assert_eq!controllerà anche tutte le implementazioni utente di Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Restituisce `true` se l'iteratore è vuoto.
    ///
    /// Questo metodo ha un'implementazione predefinita che utilizza [`ExactSizeIterator::len()`], quindi non è necessario implementarlo da soli.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}