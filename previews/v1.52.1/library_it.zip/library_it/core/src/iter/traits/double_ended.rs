use crate::ops::{ControlFlow, Try};

/// Un iteratore in grado di produrre elementi da entrambe le estremità.
///
/// Qualcosa che implementa `DoubleEndedIterator` ha una capacità in più rispetto a qualcosa che implementa [`Iterator`]: la capacità di prendere anche `Item`s dal retro, oltre che dalla parte anteriore.
///
///
/// È importante notare che entrambi i movimenti avanti e indietro lavorano sullo stesso intervallo e non si incrociano: l'iterazione termina quando si incontrano a metà.
///
/// In modo simile al protocollo [`Iterator`], una volta che un `DoubleEndedIterator` restituisce [`None`] da un [`next_back()`], richiamarlo di nuovo potrebbe o meno restituire [`Some`].
/// [`next()`] e [`next_back()`] sono intercambiabili per questo scopo.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Rimuove e restituisce un elemento dalla fine dell'iteratore.
    ///
    /// Restituisce `None` quando non ci sono più elementi.
    ///
    /// I documenti di [trait-level] contengono maggiori dettagli.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Gli elementi prodotti dai metodi di `DoubleEndedIterator` possono differire da quelli forniti dai metodi di [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Fa avanzare l'iteratore dal retro di elementi `n`.
    ///
    /// `advance_back_by` è la versione inversa di [`advance_by`].Questo metodo salterà con entusiasmo gli elementi `n` a partire dal retro chiamando [`next_back`] fino a `n` volte fino a quando non viene incontrato [`None`].
    ///
    /// `advance_back_by(n)` restituirà [`Ok(())`] se l'iteratore avanza con successo di elementi `n`, o [`Err(k)`] se viene incontrato [`None`], dove `k` è il numero di elementi di cui l'iteratore è avanzato prima di esaurire gli elementi (es.
    /// la lunghezza dell'iteratore).
    /// Nota che `k` è sempre minore di `n`.
    ///
    /// La chiamata a `advance_back_by(0)` non consuma alcun elemento e restituisce sempre [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // solo `&3` è stato ignorato
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Restituisce l'elemento "n" dalla fine dell'iteratore.
    ///
    /// Questa è essenzialmente la versione invertita di [`Iterator::nth()`].
    /// Sebbene come la maggior parte delle operazioni di indicizzazione, il conteggio inizia da zero, quindi `nth_back(0)` restituisce il primo valore dalla fine, `nth_back(1)` il secondo e così via.
    ///
    ///
    /// Nota che tutti gli elementi tra la fine e l'elemento restituito verranno consumati, incluso l'elemento restituito.
    /// Ciò significa anche che chiamare `nth_back(0)` più volte sullo stesso iteratore restituirà elementi diversi.
    ///
    /// `nth_back()` restituirà [`None`] se `n` è maggiore o uguale alla lunghezza dell'iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Chiamare `nth_back()` più volte non riavvolge l'iteratore:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Restituzione di `None` se sono presenti meno di `n + 1` elementi:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Questa è la versione inversa di [`Iterator::try_fold()`]: prende elementi a partire dal retro dell'iteratore.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Poiché è andato in cortocircuito, gli elementi rimanenti sono ancora disponibili tramite l'iteratore.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Un metodo iteratore che riduce gli elementi dell'iteratore a un unico valore finale, partendo dal retro.
    ///
    /// Questa è la versione inversa di [`Iterator::fold()`]: prende elementi a partire dal retro dell'iteratore.
    ///
    /// `rfold()` accetta due argomenti: un valore iniziale e una chiusura con due argomenti: un 'accumulator' e un elemento.
    /// La chiusura restituisce il valore che l'accumulatore dovrebbe avere per l'iterazione successiva.
    ///
    /// Il valore iniziale è il valore che l'accumulatore avrà alla prima chiamata.
    ///
    /// Dopo aver applicato questa chiusura a ogni elemento dell'iteratore, `rfold()` restituisce l'accumulatore.
    ///
    /// Questa operazione è talvolta chiamata 'reduce' o 'inject'.
    ///
    /// La piegatura è utile ogni volta che hai una raccolta di qualcosa e vuoi produrre un singolo valore da essa.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // la somma di tutti gli elementi di a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Questo esempio costruisce una stringa, iniziando con un valore iniziale e continuando con ogni elemento dal retro fino al davanti:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Cerca un elemento di un iteratore dal retro che soddisfi un predicato.
    ///
    /// `rfind()` prende una chiusura che restituisce `true` o `false`.
    /// Applica questa chiusura a ogni elemento dell'iteratore, a partire dalla fine, e se qualcuno di essi restituisce `true`, `rfind()` restituisce [`Some(element)`].
    /// Se restituiscono tutti `false`, restituisce [`None`].
    ///
    /// `rfind()` è in corto circuito;in altre parole, interromperà l'elaborazione non appena la chiusura restituirà `true`.
    ///
    /// Poiché `rfind()` accetta un riferimento e molti iteratori ripetono i riferimenti, ciò porta a una situazione potenzialmente confusa in cui l'argomento è un doppio riferimento.
    ///
    /// Puoi vedere questo effetto negli esempi seguenti, con `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Fermarsi al primo `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // possiamo ancora usare `iter`, poiché ci sono più elementi.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}