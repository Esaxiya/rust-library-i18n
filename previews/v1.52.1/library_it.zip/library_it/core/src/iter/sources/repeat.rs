use crate::iter::{FusedIterator, TrustedLen};

/// Crea un nuovo iteratore che ripete all'infinito un singolo elemento.
///
/// La funzione `repeat()` ripete un singolo valore più e più volte.
///
/// Gli iteratori infiniti come `repeat()` sono spesso usati con adattatori come [`Iterator::take()`], per renderli finiti.
///
/// Se il tipo di elemento dell'iteratore di cui hai bisogno non implementa `Clone`, o se non vuoi mantenere l'elemento ripetuto in memoria, puoi invece utilizzare la funzione [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::iter;
///
/// // il numero quattro 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // sì, ancora quattro
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Finito con [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // quell'ultimo esempio era di troppi quattro.Facciamo solo quattro quattro.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... e ora abbiamo finito
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Un iteratore che ripete un elemento all'infinito.
///
/// Questo `struct` viene creato dalla funzione [`repeat()`].Vedere la sua documentazione per ulteriori informazioni.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}