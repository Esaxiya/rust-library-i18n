use crate::fmt;

/// Crea un nuovo iteratore in cui ogni iterazione chiama la chiusura fornita `F: FnMut() -> Option<T>`.
///
/// Ciò consente di creare un iteratore personalizzato con qualsiasi comportamento senza utilizzare la sintassi più dettagliata di creare un tipo dedicato e implementare [`Iterator`] trait per esso.
///
/// Si noti che l'iteratore `FromFn` non fa supposizioni sul comportamento della chiusura, e quindi in modo conservativo non implementa [`FusedIterator`], né sovrascrive [`Iterator::size_hint()`] dal suo `(0, None)` predefinito.
///
///
/// La chiusura può usare le acquisizioni e il suo ambiente per tenere traccia dello stato attraverso le iterazioni.A seconda di come viene utilizzato l'iteratore, potrebbe essere necessario specificare la parola chiave [`move`] sulla chiusura.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Reimplementiamo l'iteratore del contatore da [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Aumenta il nostro conteggio.Questo è il motivo per cui siamo partiti da zero.
///     count += 1;
///
///     // Controlla se abbiamo finito di contare o meno.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Un iteratore in cui ogni iterazione chiama la chiusura fornita `F: FnMut() -> Option<T>`.
///
/// Questo `struct` viene creato dalla funzione [`iter::from_fn()`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}