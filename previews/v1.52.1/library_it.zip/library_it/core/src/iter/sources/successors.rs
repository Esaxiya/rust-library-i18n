use crate::{fmt, iter::FusedIterator};

/// Crea un nuovo iteratore in cui ogni elemento successivo viene calcolato in base a quello precedente.
///
/// L'iteratore inizia con il primo elemento specificato (se presente) e chiama la chiusura `FnMut(&T) -> Option<T>` specificata per calcolare il successore di ogni elemento.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Se questa funzione restituisce `impl Iterator<Item=T>`, potrebbe essere basata su `unfold` e non necessita di un tipo dedicato.
    //
    // Tuttavia, avere un tipo `Successors<T, F>` denominato consente di essere `Clone` quando `T` e `F` lo sono.
    Successors { next: first, succ }
}

/// Un nuovo iteratore in cui ogni elemento successivo viene calcolato in base a quello precedente.
///
/// Questo `struct` viene creato dalla funzione [`iter::successors()`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}