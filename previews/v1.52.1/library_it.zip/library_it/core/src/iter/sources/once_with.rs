use crate::iter::{FusedIterator, TrustedLen};

/// Crea un iteratore che genera pigramente un valore esattamente una volta richiamando la chiusura fornita.
///
/// Questo è comunemente usato per adattare un singolo generatore di valore in un [`chain()`] di altri tipi di iterazione.
/// Forse hai un iteratore che copre quasi tutto, ma hai bisogno di un caso speciale in più.
/// Forse hai una funzione che funziona sugli iteratori, ma devi solo elaborare un valore.
///
/// A differenza di [`once()`], questa funzione genererà pigramente il valore su richiesta.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::iter;
///
/// // uno è il numero più solitario
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // solo uno, questo è tutto ciò che otteniamo
/// assert_eq!(None, one.next());
/// ```
///
/// Concatenamento con un altro iteratore.
/// Diciamo che vogliamo iterare su ogni file della directory `.foo`, ma anche su un file di configurazione,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // dobbiamo convertire da un iteratore di DirEntry-s a un iteratore di PathBufs, quindi usiamo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ora, il nostro iteratore solo per il nostro file di configurazione
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // concatenare i due iteratori insieme in un unico grande iteratore
/// let files = dirs.chain(config);
///
/// // questo ci darà tutti i file in .foo e in .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Un iteratore che produce un singolo elemento di tipo `A` applicando la chiusura fornita `F: FnOnce() -> A`.
///
///
/// Questo `struct` viene creato dalla funzione [`once_with()`].
/// Vedere la sua documentazione per ulteriori informazioni.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}