use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Questo trait fornisce l'accesso transitivo allo stadio sorgente in una pipeline adattatore interatore nelle condizioni che
/// * la sorgente dell'iteratore `S` stessa implementa `SourceIter<Source = S>`
/// * c'è un'implementazione di delega di questo trait per ogni adattatore nella pipeline tra l'origine e il consumatore della pipeline.
///
/// Quando la sorgente è una struttura iteratore proprietaria (comunemente chiamata `IntoIter`), questo può essere utile per specializzare implementazioni [`FromIterator`] o recuperare gli elementi rimanenti dopo che un iteratore è stato parzialmente esaurito.
///
///
/// Si noti che le implementazioni non devono necessariamente fornire l'accesso all'origine più interna di una pipeline.Un adattatore intermedio con stato potrebbe valutare con impazienza una parte della pipeline ed esporre la sua memoria interna come origine.
///
/// Lo trait non è sicuro perché gli implementatori devono mantenere proprietà di sicurezza aggiuntive.
/// Vedere [`as_inner`] per i dettagli.
///
/// # Examples
///
/// Recupero di una fonte parzialmente consumata:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Una fase di origine in una pipeline iteratore.
    type Source: Iterator;

    /// Recupera l'origine di una pipeline iteratore.
    ///
    /// # Safety
    ///
    /// Le implementazioni di devono restituire lo stesso riferimento modificabile per la loro durata, a meno che non vengano sostituite da un chiamante.
    /// I chiamanti possono sostituire il riferimento solo quando hanno interrotto l'iterazione e rilasciare la pipeline dell'iteratore dopo aver estratto l'origine.
    ///
    /// Ciò significa che gli adattatori iteratori possono fare affidamento sul fatto che la sorgente non cambia durante l'iterazione, ma non possono fare affidamento su di essa nelle loro implementazioni Drop.
    ///
    /// L'implementazione di questo metodo significa che gli adattatori rinunciano all'accesso solo privato alla loro origine e possono fare affidamento solo sulle garanzie fornite in base ai tipi di ricevitori del metodo.
    /// La mancanza di accesso limitato richiede anche che gli adattatori debbano sostenere l'API pubblica della sorgente anche quando hanno accesso ai suoi interni.
    ///
    /// I chiamanti a loro volta devono aspettarsi che l'origine si trovi in uno stato coerente con la sua API pubblica poiché gli adattatori che si trovano tra essa e l'origine hanno lo stesso accesso.
    /// In particolare, un adattatore potrebbe aver consumato più elementi di quanto strettamente necessario.
    ///
    /// L'obiettivo generale di questi requisiti è consentire l'utilizzo da parte del consumatore di una pipeline
    /// * tutto ciò che rimane nella sorgente dopo che l'iterazione è stata interrotta
    /// * la memoria che è diventata inutilizzata facendo avanzare un iteratore consumante
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Un adattatore iteratore che produce output fintanto che l'iteratore sottostante produce valori `Result::Ok`.
///
///
/// Se si verifica un errore, l'iteratore si interrompe e l'errore viene memorizzato.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Elabora l'iteratore dato come se restituisse un `T` invece di un `Result<T, _>`.
/// Eventuali errori interromperanno l'iteratore interno e il risultato complessivo sarà un errore.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}