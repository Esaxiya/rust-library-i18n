//! Iterazione esterna componibile.
//!
//! Se ti sei trovato con una raccolta di qualche tipo e hai bisogno di eseguire un'operazione sugli elementi di detta raccolta, ti imbatterai rapidamente in 'iterators'.
//! Gli iteratori sono ampiamente utilizzati nel codice idiomatico Rust, quindi vale la pena familiarizzarsi con loro.
//!
//! Prima di spiegare di più, parliamo di come è strutturato questo modulo:
//!
//! # Organization
//!
//! Questo modulo è in gran parte organizzato per tipo:
//!
//! * [Traits] sono la parte fondamentale: questi traits definiscono che tipo di iteratori esistono e cosa puoi fare con essi.Vale la pena dedicare del tempo extra allo studio sui metodi di questi traits.
//! * [Functions] fornire alcuni modi utili per creare alcuni iteratori di base.
//! * [Structs] sono spesso i tipi di ritorno dei vari metodi su traits di questo modulo.Di solito vorrai guardare il metodo che crea l `struct`, piuttosto che l `struct` stesso.
//! Per maggiori dettagli sul motivo, vedere "[Implementing Iterator](#implementation-iterator)".
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Questo è tutto!Analizziamo gli iteratori.
//!
//! # Iterator
//!
//! Il cuore e l'anima di questo modulo è l [`Iterator`] trait.Il nucleo di [`Iterator`] si presenta così:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Un iteratore ha un metodo, [`next`], che quando chiamato, restituisce un [`Option`]`<Item>".
//! [`next`] restituirà [`Some(Item)`] fintanto che ci sono elementi e, una volta che sono stati tutti esauriti, restituirà `None` per indicare che l'iterazione è terminata.
//! I singoli iteratori possono scegliere di riprendere l'iterazione, quindi chiamare di nuovo [`next`] potrebbe o non potrebbe ricominciare a restituire [`Some(Item)`] ad un certo punto (ad esempio, vedere [`TryIter`]).
//!
//!
//! La definizione completa di [`Iterator`] include anche una serie di altri metodi, ma sono metodi predefiniti, costruiti sopra [`next`], e quindi li ottieni gratuitamente.
//!
//! Gli iteratori sono anche componibili ed è comune concatenarli insieme per eseguire forme di elaborazione più complesse.Vedere la sezione [Adapters](#adapters) di seguito per maggiori dettagli.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Le tre forme di iterazione
//!
//! Esistono tre metodi comuni che possono creare iteratori da una raccolta:
//!
//! * `iter()`, che itera su `&T`.
//! * `iter_mut()`, che itera su `&mut T`.
//! * `into_iter()`, che itera su `T`.
//!
//! Diverse cose nella libreria standard possono implementare uno o più dei tre, dove appropriato.
//!
//! # Implementazione di Iterator
//!
//! La creazione di un iteratore personalizzato comporta due passaggi: la creazione di un `struct` per mantenere lo stato dell'iteratore e quindi l'implementazione di [`Iterator`] per tale `struct`.
//! Questo è il motivo per cui ci sono così tante `struct` in questo modulo: ce n'è una per ogni iteratore e adattatore iteratore.
//!
//! Creiamo un iteratore chiamato `Counter` che conta da `1` a `5`:
//!
//! ```
//! // Innanzitutto, la struttura:
//!
//! /// Un iteratore che conta da uno a cinque
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vogliamo che il nostro conteggio inizi da uno, quindi aggiungiamo un metodo new() per aiutare.
//! // Questo non è strettamente necessario, ma è conveniente.
//! // Nota che iniziamo `count` da zero, vedremo perché nell'implementazione di `next()`'s di seguito.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Quindi, implementiamo `Iterator` per il nostro `Counter`:
//!
//! impl Iterator for Counter {
//!     // conteremo con usize
//!     type Item = usize;
//!
//!     // next() è l'unico metodo richiesto
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Aumenta il nostro conteggio.Questo è il motivo per cui siamo partiti da zero.
//!         self.count += 1;
//!
//!         // Controlla se abbiamo finito di contare o meno.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // E ora possiamo usarlo!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Chiamare [`next`] in questo modo diventa ripetitivo.Rust ha un costrutto che può chiamare [`next`] sul tuo iteratore, finché non raggiunge `None`.Andiamo su quello dopo.
//!
//! Si noti inoltre che `Iterator` fornisce un'implementazione predefinita di metodi come `nth` e `fold` che chiamano `next` internamente.
//! Tuttavia, è anche possibile scrivere un'implementazione personalizzata di metodi come `nth` e `fold` se un iteratore può calcolarli in modo più efficiente senza chiamare `next`.
//!
//! # `for` loop e `IntoIterator`
//!
//! La sintassi del ciclo `for` di Rust è in realtà zucchero per gli iteratori.Ecco un esempio di base di `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Questo stamperà i numeri da uno a cinque, ciascuno sulla propria riga.Ma noterai qualcosa qui: non abbiamo mai chiamato nulla sul nostro vector per produrre un iteratore.Cosa succede?
//!
//! C'è uno trait nella libreria standard per convertire qualcosa in un iteratore: [`IntoIterator`].
//! Questo trait ha un metodo, [`into_iter`], che converte la cosa che implementa [`IntoIterator`] in un iteratore.
//! Diamo nuovamente un'occhiata a quel ciclo `for` e in cosa lo converte il compilatore:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-zuccheri questo in:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Innanzitutto, chiamiamo `into_iter()` sul valore.Quindi, abbiniamo l'iteratore che ritorna, chiamando [`next`] più e più volte finché non vediamo un `None`.
//! A quel punto, abbiamo `break` fuori dal giro e abbiamo finito di iterare.
//!
//! C'è un altro tocco sottile qui: la libreria standard contiene un'interessante implementazione di [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! In altre parole, tutti gli [`Iterator`] implementano [`IntoIterator`], restituendo semplicemente se stessi.Ciò significa due cose:
//!
//! 1. Se stai scrivendo un [`Iterator`], puoi usarlo con un ciclo `for`.
//! 2. Se stai creando una raccolta, l'implementazione di [`IntoIterator`] consentirà alla tua raccolta di essere utilizzata con il ciclo `for`.
//!
//! # Iterazione per riferimento
//!
//! Poiché [`into_iter()`] prende `self` per valore, l'utilizzo di un ciclo `for` per iterare su una raccolta consuma quella raccolta.Spesso, potresti voler iterare su una raccolta senza consumarla.
//! Molte raccolte offrono metodi che forniscono iteratori sui riferimenti, convenzionalmente chiamati rispettivamente `iter()` e `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` è ancora di proprietà di questa funzione.
//! ```
//!
//! Se un tipo di raccolta `C` fornisce `iter()`, di solito implementa anche `IntoIterator` per `&C`, con un'implementazione che chiama solo `iter()`.
//! Allo stesso modo, una raccolta `C` che fornisce `iter_mut()` generalmente implementa `IntoIterator` per `&mut C` delegando a `iter_mut()`.Ciò consente una comoda scorciatoia:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // uguale a `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // uguale a `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Sebbene molte collezioni offrano `iter()`, non tutte offrono `iter_mut()`.
//! Ad esempio, la modifica delle chiavi di un [`HashSet<T>`] o [`HashMap<K, V>`] potrebbe mettere la raccolta in uno stato incoerente se gli hash delle chiavi cambiano, quindi queste raccolte offrono solo `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Le funzioni che accettano un [`Iterator`] e restituiscono un altro [`Iterator`] sono spesso chiamate "adattatori iteratori", poiché sono una forma dell '"adattatore
//! pattern'.
//!
//! Gli adattatori iteratori comuni includono [`map`], [`take`] e [`filter`].
//! Per ulteriori informazioni, vedere la loro documentazione.
//!
//! Se un adattatore iteratore panics, l'iteratore si troverà in uno stato non specificato (ma sicuro per la memoria).
//! Inoltre, non è garantito che questo stato rimanga lo stesso nelle versioni di Rust, quindi dovresti evitare di fare affidamento sui valori esatti restituiti da un iteratore in preda al panico.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Gli iteratori (e l'iteratore [adapters](#adapters)) sono *pigri*. Ciò significa che la semplice creazione di un iteratore non fa _do_ molto. Non succede nulla finché non chiami [`next`].
//! Questo a volte è fonte di confusione quando si crea un iteratore esclusivamente per i suoi effetti collaterali.
//! Ad esempio, il metodo [`map`] chiama una chiusura su ogni elemento su cui itera:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Questo non stamperà alcun valore, poiché abbiamo solo creato un iteratore, invece di usarlo.Il compilatore ci avviserà di questo tipo di comportamento:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Il modo idiomatico per scrivere un [`map`] per i suoi effetti collaterali è usare un ciclo `for` o chiamare il metodo [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Un altro modo comune per valutare un iteratore è utilizzare il metodo [`collect`] per produrre una nuova raccolta.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Gli iteratori non devono essere finiti.Ad esempio, un intervallo aperto è un iteratore infinito:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! È comune utilizzare l'adattatore iteratore [`take`] per trasformare un iteratore infinito in uno finito:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Questo stamperà i numeri da `0` a `4`, ciascuno sulla propria riga.
//!
//! Tieni presente che i metodi su iteratori infiniti, anche quelli per i quali un risultato può essere determinato matematicamente in un tempo finito, potrebbero non terminare.
//! In particolare, è probabile che metodi come [`min`], che nel caso generale richiedono l'attraversamento di ogni elemento nell'iteratore, non vengano restituiti correttamente per qualsiasi iteratore infinito.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh no!Un ciclo infinito!
//! // `ones.min()` provoca un ciclo infinito, quindi non raggiungeremo questo punto!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;