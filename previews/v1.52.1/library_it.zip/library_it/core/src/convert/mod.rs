//! Traits per le conversioni tra i tipi.
//!
//! traits in questo modulo fornisce un modo per convertire da un tipo a un altro tipo.
//! Ogni trait ha uno scopo diverso:
//!
//! - Implementa [`AsRef`] trait per conversioni economiche da riferimento a riferimento
//! - Implementa [`AsMut`] trait per conversioni economiche mutabili in mutabili
//! - Implementa [`From`] trait per consumare conversioni da valore a valore
//! - Implementa [`Into`] trait per consumare conversioni valore-valore in tipi al di fuori dell'attuale crate
//! - [`TryFrom`] e [`TryInto`] traits si comportano come [`From`] e [`Into`], ma dovrebbero essere implementati quando la conversione può fallire.
//!
//! Gli traits in questo modulo sono spesso usati come trait bounds per funzioni generiche tali da supportare argomenti di più tipi.Vedere la documentazione di ogni trait per esempi.
//!
//! Come autore di librerie, dovresti sempre preferire implementare [`From<T>`][`From`] o [`TryFrom<T>`][`TryFrom`] piuttosto che [`Into<U>`][`Into`] o [`TryInto<U>`][`TryInto`], poiché [`From`] e [`TryFrom`] forniscono una maggiore flessibilità e offrono implementazioni [`Into`] o [`TryInto`] equivalenti gratuitamente, grazie a un'implementazione generale nella libreria standard.
//! Quando si sceglie come target una versione precedente a Rust 1.41, potrebbe essere necessario implementare [`Into`] o [`TryInto`] direttamente durante la conversione in un tipo esterno a crate corrente.
//!
//! # Implementazioni generiche
//!
//! - [`AsRef`] e Dereferenziazione automatica [`AsMut`] se il tipo interno è un riferimento
//! - [`From`]`<U>for T` implica [`Into`]`</u><T><U>per U`</u>
//! - [`TryFrom`]`<U>for T` implica [`TryInto`]`</u><T><U>per U`</u>
//! - [`From`] e [`Into`] sono riflessivi, il che significa che tutti i tipi possono `into` stessi e `from` stesso
//!
//! Vedi ogni trait per esempi di utilizzo.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// La funzione identità.
///
/// Due cose sono importanti da notare su questa funzione:
///
/// - Non è sempre equivalente a una chiusura come `|x| x`, poiché la chiusura può costringere `x` a un tipo diverso.
///
/// - Sposta l'ingresso `x` passato alla funzione.
///
/// Sebbene possa sembrare strano avere una funzione che restituisce solo l'input, ci sono alcuni usi interessanti.
///
///
/// # Examples
///
/// Usare `identity` per non fare nulla in una sequenza di altre, interessanti, funzioni:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Facciamo finta che aggiungerne uno sia una funzione interessante.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Utilizzo di `identity` come caso base "do nothing" in un condizionale:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Fai cose più interessanti ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Utilizzo di `identity` per mantenere le varianti `Some` di un iteratore di `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Utilizzato per eseguire una conversione da riferimento a riferimento a buon mercato.
///
/// Questo trait è simile a [`AsMut`] che viene utilizzato per la conversione tra riferimenti mutabili.
/// Se è necessario eseguire una conversione costosa è meglio implementare [`From`] con il tipo `&T` o scrivere una funzione personalizzata.
///
/// `AsRef` ha la stessa firma di [`Borrow`], ma [`Borrow`] è diverso in alcuni aspetti:
///
/// - A differenza di `AsRef`, [`Borrow`] ha un blanket impl per qualsiasi `T` e può essere utilizzato per accettare un riferimento o un valore.
/// - [`Borrow`] richiede inoltre che [`Hash`], [`Eq`] e [`Ord`] per il valore preso in prestito siano equivalenti a quelli del valore posseduto.
/// Per questo motivo, se vuoi prendere in prestito solo un singolo campo di una struttura puoi implementare `AsRef`, ma non [`Borrow`].
///
/// **Note: Questo trait non deve fallire **.Se la conversione può fallire, utilizzare un metodo dedicato che restituisce un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementazioni generiche
///
/// - `AsRef` auto-dereferenze se il tipo interno è un riferimento o un riferimento modificabile (es: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Utilizzando trait bounds possiamo accettare argomenti di diversi tipi purché possano essere convertiti nel tipo specificato `T`.
///
/// Ad esempio: creando una funzione generica che accetta un `AsRef<str>` esprimiamo che vogliamo accettare tutti i riferimenti che possono essere convertiti in [`&str`] come argomento.
/// Poiché sia [`String`] che [`&str`] implementano `AsRef<str>`, possiamo accettarli entrambi come argomento di input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Esegue la conversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Utilizzato per eseguire una conversione di riferimento mutabile in modificabile a buon mercato.
///
/// Questo trait è simile a [`AsRef`] ma utilizzato per la conversione tra riferimenti mutabili.
/// Se hai bisogno di fare una conversione costosa è meglio implementare [`From`] con il tipo `&mut T` o scrivere una funzione personalizzata.
///
/// **Note: Questo trait non deve fallire **.Se la conversione può fallire, utilizzare un metodo dedicato che restituisce un [`Option<T>`] o un [`Result<T, E>`].
///
/// # Implementazioni generiche
///
/// - `AsMut` auto-dereferenze se il tipo interno è un riferimento mutabile (es: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Usando `AsMut` come trait bound per una funzione generica possiamo accettare tutti i riferimenti mutabili che possono essere convertiti nel tipo `&mut T`.
/// Poiché [`Box<T>`] implementa `AsMut<T>`, possiamo scrivere una funzione `add_one` che accetta tutti gli argomenti che possono essere convertiti in `&mut u64`.
/// Poiché [`Box<T>`] implementa `AsMut<T>`, `add_one` accetta anche argomenti di tipo `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Esegue la conversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Una conversione da valore a valore che consuma il valore di input.L'opposto di [`From`].
///
/// Si dovrebbe evitare di implementare [`Into`] e implementare invece [`From`].
/// L'implementazione di [`From`] fornisce automaticamente un'implementazione di [`Into`] grazie all'implementazione blanket nella libreria standard.
///
/// Preferire l'utilizzo di [`Into`] rispetto a [`From`] quando si specifica trait bounds su una funzione generica per garantire che anche i tipi che implementano [`Into`] possano essere utilizzati.
///
/// **Note: Questo trait non deve fallire **.Se la conversione può fallire, usa [`TryInto`].
///
/// # Implementazioni generiche
///
/// - [`Da`]`<T>per U` implica `Into<U> for T`
/// - [`Into`] è riflessivo, il che significa che `Into<T> for T` è implementato
///
/// # Implementazione di [`Into`] per conversioni a tipi esterni nelle vecchie versioni di Rust
///
/// Prima di Rust 1.41, se il tipo di destinazione non faceva parte dell'attuale crate, non era possibile implementare [`From`] direttamente.
/// Ad esempio, prendi questo codice:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Questo non verrà compilato nelle versioni precedenti del linguaggio perché le regole orfane di Rust erano un po 'più rigide.
/// Per aggirare questo problema, puoi implementare [`Into`] direttamente:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// È importante capire che [`Into`] non fornisce un'implementazione [`From`] (come [`From`] fa con [`Into`]).
/// Pertanto, dovresti sempre provare a implementare [`From`] e poi tornare a [`Into`] se [`From`] non può essere implementato.
///
/// # Examples
///
/// [`String`] implementa [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Per esprimere che vogliamo che una funzione generica prenda tutti gli argomenti che possono essere convertiti in un tipo specificato `T`, possiamo usare trait bound di [`Into`]`<T>".
///
/// Ad esempio: La funzione `is_hello` accetta tutti gli argomenti che possono essere convertiti in un [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Esegue la conversione.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Utilizzato per eseguire conversioni da valore a valore consumando il valore di input.È il reciproco di [`Into`].
///
/// Si dovrebbe sempre preferire l'implementazione di `From` rispetto a [`Into`] perché l'implementazione di `From` fornisce automaticamente un'implementazione di [`Into`] grazie all'implementazione generale nella libreria standard.
///
///
/// Implementare [`Into`] solo quando si sceglie come target una versione precedente a Rust 1.41 e si converte in un tipo esterno a crate corrente.
/// `From` non è stato in grado di eseguire questi tipi di conversioni nelle versioni precedenti a causa delle regole orfane di Rust.
/// Vedi [`Into`] per maggiori dettagli.
///
/// Preferisci usare [`Into`] rispetto a `From` quando specifichi trait bounds su una funzione generica.
/// In questo modo, anche i tipi che implementano direttamente [`Into`] possono essere usati come argomenti.
///
/// L `From` è anche molto utile quando si esegue la gestione degli errori.Quando si costruisce una funzione che può fallire, il tipo restituito sarà generalmente del formato `Result<T, E>`.
/// `From` trait semplifica la gestione degli errori consentendo a una funzione di restituire un singolo tipo di errore che incapsula più tipi di errore.Vedere la sezione "Examples" e [the book][book] per maggiori dettagli.
///
/// **Note: Questo trait non deve fallire **.Se la conversione può fallire, usa [`TryFrom`].
///
/// # Implementazioni generiche
///
/// - `From<T> for U` implica ["Into"] "<U>per T"</u>
/// - `From` è riflessivo, il che significa che `From<T> for T` è implementato
///
/// # Examples
///
/// [`String`] implementa `From<&str>`:
///
/// Una conversione esplicita da `&str` a String viene eseguita come segue:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Durante la gestione degli errori è spesso utile implementare `From` per il proprio tipo di errore.
/// Convertendo i tipi di errore sottostanti nel nostro tipo di errore personalizzato che incapsula il tipo di errore sottostante, possiamo restituire un singolo tipo di errore senza perdere le informazioni sulla causa sottostante.
/// L'operatore '?' converte automaticamente il tipo di errore sottostante nel nostro tipo di errore personalizzato chiamando `Into<CliError>::into` che viene fornito automaticamente durante l'implementazione di `From`.
/// Il compilatore quindi deduce quale implementazione di `Into` dovrebbe essere utilizzata.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Esegue la conversione.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Un tentativo di conversione che consuma `self`, che può essere costoso o meno.
///
/// Gli autori di librerie di solito non dovrebbero implementare direttamente questo trait, ma dovrebbero preferire implementare [`TryFrom`] trait, che offre una maggiore flessibilità e fornisce un'implementazione `TryInto` equivalente gratuitamente, grazie a un'implementazione generale nella libreria standard.
/// Per ulteriori informazioni su questo, vedere la documentazione per [`Into`].
///
/// # Implementazione di `TryInto`
///
/// Ciò subisce le stesse restrizioni e ragionamenti dell'implementazione di [`Into`], vedere lì per i dettagli.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Il tipo restituito in caso di errore di conversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Esegue la conversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Conversioni di tipi semplici e sicure che potrebbero non riuscire in modo controllato in alcune circostanze.È il reciproco di [`TryInto`].
///
/// Ciò è utile quando si esegue una conversione di tipo che potrebbe avere successo banalmente ma potrebbe anche richiedere una gestione speciale.
/// Ad esempio, non c'è modo di convertire un [`i64`] in un [`i32`] utilizzando [`From`] trait, perché un [`i64`] può contenere un valore che un [`i32`] non può rappresentare e quindi la conversione perderebbe i dati.
///
/// Questo può essere gestito troncando [`i64`] in [`i32`] (essenzialmente fornendo il valore di [`i64`] modulo [`i32::MAX`]) o semplicemente restituendo [`i32::MAX`], o con qualche altro metodo.
/// [`From`] trait è concepito per conversioni perfette, quindi `TryFrom` trait informa il programmatore quando una conversione di tipo potrebbe andare male e gli lascia decidere come gestirla.
///
/// # Implementazioni generiche
///
/// - `TryFrom<T> for U` implica [`TryInto`]`<U>per T`</u>
/// - [`try_from`] è riflessivo, il che significa che `TryFrom<T> for T` è implementato e non può fallire: il tipo `Error` associato per chiamare `T::try_from()` su un valore di tipo `T` è [`Infallible`].
/// Quando il tipo [`!`] è stabilizzato, [`Infallible`] e [`!`] saranno equivalenti.
///
/// `TryFrom<T>` può essere implementato come segue:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Come descritto, [`i32`] implementa `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Silenziosamente tronca `big_number`, richiede il rilevamento e la gestione del troncamento dopo il fatto.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Restituisce un errore perché `big_number` è troppo grande per entrare in un `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Restituisce `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Il tipo restituito in caso di errore di conversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Esegue la conversione.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPIANTI GENERICI
////////////////////////////////////////////////////////////////////////////////

// Mentre si solleva e
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Come solleva oltre &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): sostituire il precedente impls per&/&mut con il seguente più generale:
// // Mentre solleva Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>per D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut solleva &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): sostituire il suddetto impl per &mut con il seguente più generale:
// // AsMut solleva DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>per D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Da implica Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (e quindi Into) è riflessivo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota di stabilità:** Questo impl non esiste ancora, ma siamo "reserving space" ad aggiungerlo nella future.
/// Vedere [rust-lang/rust#64715][#64715] per i dettagli.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): fare invece una correzione di principio.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom implica TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Le conversioni infallibili sono semanticamente equivalenti alle conversioni fallibili con un tipo di errore disabitato.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLICAZIONI CONCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// IL TIPO DI ERRORE SENZA ERRORE
////////////////////////////////////////////////////////////////////////////////

/// Il tipo di errore per errori che non possono mai verificarsi.
///
/// Poiché questa enumerazione non ha varianti, un valore di questo tipo non può mai esistere effettivamente.
/// Ciò può essere utile per API generiche che utilizzano [`Result`] e parametrizzano il tipo di errore, per indicare che il risultato è sempre [`Ok`].
///
/// Ad esempio, [`TryFrom`] trait (conversione che restituisce un [`Result`]) ha un'implementazione globale per tutti i tipi in cui esiste un'implementazione [`Into`] inversa.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Compatibilità Future
///
/// Questa enumerazione ha lo stesso ruolo di [the `!`“never”type][never], che è instabile in questa versione di Rust.
/// Quando `!` è stabilizzato, prevediamo di rendere `Infallible` un alias di tipo per esso:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... e infine deprecare `Infallible`.
///
/// Tuttavia, esiste un caso in cui la sintassi `!` può essere utilizzata prima che `!` venga stabilizzato come tipo a tutti gli effetti: nella posizione del tipo restituito di una funzione.
/// Nello specifico, sono possibili implementazioni per due diversi tipi di puntatori a funzione:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Con `Infallible` come enum, questo codice è valido.
/// Tuttavia, quando `Infallible` diventa un alias per never type, i due `impl` inizieranno a sovrapporsi e quindi non saranno consentiti dalle regole di coerenza trait della lingua.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}