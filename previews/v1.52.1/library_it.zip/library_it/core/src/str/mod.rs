//! Manipolazione delle stringhe.
//!
//! Per maggiori dettagli, vedere il modulo [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. fuori dai limiti
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. inizio <=fine
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. confine di carattere
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // trova il personaggio
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` deve essere inferiore a len e un contorno di caratteri
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Restituisce la lunghezza di `self`.
    ///
    /// Questa lunghezza è in byte, non [`char`] so grafemi.
    /// In altre parole, potrebbe non essere ciò che un essere umano considera la lunghezza della stringa.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fantasia f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Restituisce `true` se `self` ha una lunghezza di zero byte.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Verifica che il byte "index" sia il primo byte in una sequenza di punti di codice UTF-8 o la fine della stringa.
    ///
    ///
    /// L'inizio e la fine della stringa (quando `index== self.len()`) sono considerati limiti.
    ///
    /// Restituisce `false` se `index` è maggiore di `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // inizio di `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // secondo byte di `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // terzo byte di `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 e len sono sempre ok.
        // Verifica esplicitamente 0 in modo che possa ottimizzare facilmente il controllo e saltare la lettura dei dati della stringa per quel caso.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Questo è un po 'magico equivalente a: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Converte una sezione di stringa in una sezione di byte.
    /// Per riconvertire la fetta di byte in una fetta di stringa, utilizzare la funzione [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SICUREZZA: suono costante perché trasmutiamo due tipi con lo stesso layout
        unsafe { mem::transmute(self) }
    }

    /// Converte una sezione di stringa modificabile in una sezione di byte modificabile.
    ///
    /// # Safety
    ///
    /// Il chiamante deve assicurarsi che il contenuto della slice sia valido UTF-8 prima che il prestito termini e venga utilizzato il sottostante `str`.
    ///
    ///
    /// L'uso di un `str` i cui contenuti non sono validi UTF-8 è un comportamento indefinito.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SICUREZZA: il cast da `&str` a `&[u8]` è sicuro da `str`
        // ha lo stesso layout di `&[u8]` (solo libstd può dare questa garanzia).
        // La dereferenziazione del puntatore è sicura poiché proviene da un riferimento mutabile che è garantito essere valido per le scritture.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Converte una sezione di stringa in un puntatore non elaborato.
    ///
    /// Poiché le sezioni di stringa sono una sezione di byte, il puntatore grezzo punta a un [`u8`].
    /// Questo puntatore punterà al primo byte della fetta di stringa.
    ///
    /// Il chiamante deve assicurarsi che il puntatore restituito non venga mai scritto.
    /// Se è necessario modificare il contenuto della sezione della stringa, utilizzare [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Converte una porzione di stringa modificabile in un puntatore non elaborato.
    ///
    /// Poiché le sezioni di stringa sono una sezione di byte, il puntatore grezzo punta a un [`u8`].
    /// Questo puntatore punterà al primo byte della fetta di stringa.
    ///
    /// È tua responsabilità assicurarti che lo slice di stringa venga modificato solo in modo che rimanga valido UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Restituisce una sottosezione di `str`.
    ///
    /// Questa è l'alternativa senza panico all'indicizzazione dell `str`.
    /// Restituisce [`None`] ogni volta che un'operazione di indicizzazione equivalente sarebbe panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indici non sui limiti della sequenza UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // fuori dai limiti
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Restituisce una sottosezione modificabile di `str`.
    ///
    /// Questa è l'alternativa senza panico all'indicizzazione dell `str`.
    /// Restituisce [`None`] ogni volta che un'operazione di indicizzazione equivalente sarebbe panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // lunghezza corretta
    /// assert!(v.get_mut(0..5).is_some());
    /// // fuori dai limiti
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Restituisce una sottosezione non controllata di `str`.
    ///
    /// Questa è l'alternativa incontrollata all'indicizzazione di `str`.
    ///
    /// # Safety
    ///
    /// I chiamanti di questa funzione sono responsabili che queste condizioni preliminari siano soddisfatte:
    ///
    /// * L'indice iniziale non deve superare l'indice finale;
    /// * Gli indici devono essere entro i limiti della sezione originale;
    /// * Gli indici devono trovarsi sui limiti della sequenza UTF-8.
    ///
    /// In caso contrario, la porzione di stringa restituita potrebbe fare riferimento a una memoria non valida o violare le invarianti comunicate dal tipo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Restituisce una sottosezione modificabile e non controllata di `str`.
    ///
    /// Questa è l'alternativa incontrollata all'indicizzazione di `str`.
    ///
    /// # Safety
    ///
    /// I chiamanti di questa funzione sono responsabili che queste condizioni preliminari siano soddisfatte:
    ///
    /// * L'indice iniziale non deve superare l'indice finale;
    /// * Gli indici devono essere entro i limiti della sezione originale;
    /// * Gli indici devono trovarsi sui limiti della sequenza UTF-8.
    ///
    /// In caso contrario, la porzione di stringa restituita potrebbe fare riferimento a una memoria non valida o violare le invarianti comunicate dal tipo `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked_mut`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Crea una sezione di stringa da un'altra sezione di stringa, ignorando i controlli di sicurezza.
    ///
    /// Questo in genere non è raccomandato, usalo con cautela!Per un'alternativa sicura vedere [`str`] e [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Questa nuova fetta va da `begin` a `end`, incluso `begin` ma escluso `end`.
    ///
    /// Per ottenere invece una sezione di stringa modificabile, vedere il metodo [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// I chiamanti di questa funzione sono responsabili del soddisfacimento di tre condizioni preliminari:
    ///
    /// * `begin` non deve superare `end`.
    /// * `begin` e `end` devono essere posizioni di byte all'interno della sezione di stringa.
    /// * `begin` e `end` deve trovarsi sui limiti della sequenza UTF-8.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Crea una sezione di stringa da un'altra sezione di stringa, ignorando i controlli di sicurezza.
    /// Questo in genere non è raccomandato, usalo con cautela!Per un'alternativa sicura vedere [`str`] e [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Questa nuova fetta va da `begin` a `end`, incluso `begin` ma escluso `end`.
    ///
    /// Per ottenere invece uno slice di stringa immutabile, vedere il metodo [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// I chiamanti di questa funzione sono responsabili del soddisfacimento di tre condizioni preliminari:
    ///
    /// * `begin` non deve superare `end`.
    /// * `begin` e `end` devono essere posizioni di byte all'interno della sezione di stringa.
    /// * `begin` e `end` deve trovarsi sui limiti della sequenza UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked_mut`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Dividi una sezione di stringa in due in corrispondenza di un indice.
    ///
    /// L'argomento, `mid`, dovrebbe essere un offset di byte dall'inizio della stringa.
    /// Deve anche essere sul confine di un punto di codice UTF-8.
    ///
    /// Le due sezioni restituite vanno dall'inizio della sezione della stringa a `mid` e da `mid` alla fine della sezione della stringa.
    ///
    /// Per ottenere invece sezioni di stringa modificabili, vedere il metodo [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics se `mid` non si trova su un limite del punto di codice UTF-8 o se è oltre la fine dell'ultimo punto di codice della sezione di stringa.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary controlla che l'indice sia in [0, .len()]
        if self.is_char_boundary(mid) {
            // SICUREZZA: ho appena controllato che `mid` sia su un confine di caratteri.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Dividi una porzione di stringa mutabile in due in corrispondenza di un indice.
    ///
    /// L'argomento, `mid`, dovrebbe essere un offset di byte dall'inizio della stringa.
    /// Deve anche essere sul confine di un punto di codice UTF-8.
    ///
    /// Le due sezioni restituite vanno dall'inizio della sezione della stringa a `mid` e da `mid` alla fine della sezione della stringa.
    ///
    /// Per ottenere invece sezioni di stringa immutabili, vedere il metodo [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics se `mid` non si trova su un limite del punto di codice UTF-8 o se è oltre la fine dell'ultimo punto di codice della sezione di stringa.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary controlla che l'indice sia in [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SICUREZZA: ho appena controllato che `mid` sia su un confine di caratteri.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Restituisce un iteratore sui [`char`] di una porzione di stringa.
    ///
    /// Poiché uno slice di stringa è costituito da UTF-8 valido, possiamo iterare attraverso uno slice di stringa da [`char`].
    /// Questo metodo restituisce un tale iteratore.
    ///
    /// È importante ricordare che [`char`] rappresenta un valore scalare Unicode e potrebbe non corrispondere alla tua idea di cosa sia 'character'.
    ///
    /// L'iterazione sui cluster di grafema potrebbe essere ciò che desideri effettivamente.
    /// Questa funzionalità non è fornita dalla libreria standard di Rust, controlla invece crates.io.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Ricorda, i [`char`] potrebbero non corrispondere alla tua intuizione sui personaggi:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // non 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Restituisce un iteratore sui [`char`] di una porzione di stringa e le loro posizioni.
    ///
    /// Poiché uno slice di stringa è costituito da UTF-8 valido, possiamo iterare attraverso uno slice di stringa da [`char`].
    /// Questo metodo restituisce un iteratore di entrambi questi [`char`], così come le loro posizioni in byte.
    ///
    /// L'iteratore produce tuple.La posizione è la prima, l [`char`] è la seconda.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Ricorda, i [`char`] potrebbero non corrispondere alla tua intuizione sui personaggi:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // non (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // notare il 3 qui, l'ultimo carattere ha occupato due byte
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Un iteratore sui byte di una sezione di stringa.
    ///
    /// Poiché una sezione di stringa consiste in una sequenza di byte, possiamo iterare su una sezione di stringa per byte.
    /// Questo metodo restituisce un tale iteratore.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Divide una sezione di stringa per spazi.
    ///
    /// L'iteratore restituito restituirà sezioni di stringa che sono sotto-sezioni della sezione di stringa originale, separate da qualsiasi quantità di spazio bianco.
    ///
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    /// Se invece vuoi dividere solo su spazi ASCII, usa [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Vengono considerati tutti i tipi di spazi bianchi:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Divide una sezione di stringa per spazi bianchi ASCII.
    ///
    /// L'iteratore restituito restituirà sezioni di stringa che sono sotto-sezioni della sezione di stringa originale, separate da qualsiasi quantità di spazi bianchi ASCII.
    ///
    ///
    /// Per dividere per Unicode `Whitespace` invece, usa [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Vengono considerati tutti i tipi di spazi bianchi ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Un iteratore sulle linee di una stringa, come sezioni di stringa.
    ///
    /// Le righe terminano con una nuova riga (`\n`) o un ritorno a capo con un avanzamento riga (`\r\n`).
    ///
    /// La fine della riga finale è facoltativa.
    /// Una stringa che termina con una riga finale che termina restituirà le stesse righe di una stringa altrimenti identica senza una riga finale che termina.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// La fine della riga finale non è richiesta:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Un iteratore sulle righe di una stringa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Restituisce un iteratore di `u16` sulla stringa codificata come UTF-16.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Restituisce `true` se il modello dato corrisponde a una sottosezione di questa sezione di stringa.
    ///
    /// Restituisce `false` se non lo fa.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Restituisce `true` se il modello dato corrisponde a un prefisso di questa sezione di stringa.
    ///
    /// Restituisce `false` se non lo fa.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Restituisce `true` se il modello specificato corrisponde a un suffisso di questa sezione di stringa.
    ///
    /// Restituisce `false` se non lo fa.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Restituisce l'indice di byte del primo carattere di questa sezione di stringa che corrisponde al modello.
    ///
    /// Restituisce [`None`] se il modello non corrisponde.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modelli più complessi che utilizzano stili e chiusure senza punti:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Non trovando lo schema:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Restituisce l'indice di byte per il primo carattere della corrispondenza più a destra del modello in questa sezione di stringa.
    ///
    /// Restituisce [`None`] se il modello non corrisponde.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Modelli più complessi con chiusure:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Non trovando lo schema:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Un iteratore su sottostringhe di questa sezione di stringa, separate da caratteri corrispondenti a un modello.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito sarà un [`DoubleEndedIterator`] se il pattern consente una ricerca inversa e la ricerca forward/reverse restituisce gli stessi elementi.
    /// Ciò è vero, ad esempio, per [`char`], ma non per `&str`.
    ///
    /// Se il modello consente una ricerca inversa ma i suoi risultati potrebbero differire da una ricerca in avanti, è possibile utilizzare il metodo [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Se lo schema è una porzione di caratteri, dividi ogni volta che si verifica uno qualsiasi dei caratteri:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Se una stringa contiene più separatori contigui, ti ritroverai con stringhe vuote nell'output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// I separatori contigui sono separati dalla stringa vuota.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// I separatori all'inizio o alla fine di una stringa sono adiacenti a stringhe vuote.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Quando la stringa vuota viene utilizzata come separatore, separa ogni carattere nella stringa, insieme all'inizio e alla fine della stringa.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// I separatori contigui possono portare a comportamenti sorprendenti quando si utilizzano spazi bianchi come separatori.Questo codice è corretto:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ ti offre:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Usa [`split_whitespace`] per questo comportamento.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Un iteratore su sottostringhe di questa sezione di stringa, separate da caratteri corrispondenti a un modello.
    /// Differisce dall'iteratore prodotto da `split` in quanto `split_inclusive` lascia la parte corrispondente come terminatore della sottostringa.
    ///
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Se l'ultimo elemento della stringa trova corrispondenza, quell'elemento sarà considerato il terminatore della sottostringa precedente.
    /// Quella sottostringa sarà l'ultimo elemento restituito dall'iteratore.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Un iteratore su sottostringhe della sezione di stringa data, separato da caratteri corrispondenti a un modello e restituito in ordine inverso.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito richiede che il pattern supporti una ricerca inversa e sarà un [`DoubleEndedIterator`] se una ricerca forward/reverse restituisce gli stessi elementi.
    ///
    ///
    /// Per l'iterazione dalla parte anteriore, è possibile utilizzare il metodo [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Un iteratore su sottostringhe della sezione di stringa data, separate da caratteri corrispondenti a un modello.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalente a [`split`], tranne per il fatto che la sottostringa finale viene ignorata se vuota.
    ///
    /// [`split`]: str::split
    ///
    /// Questo metodo può essere utilizzato per i dati di stringa che sono _terminated_, piuttosto che _separated_ da un modello.
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito sarà un [`DoubleEndedIterator`] se il pattern consente una ricerca inversa e la ricerca forward/reverse restituisce gli stessi elementi.
    /// Ciò è vero, ad esempio, per [`char`], ma non per `&str`.
    ///
    /// Se il modello consente una ricerca inversa ma i suoi risultati potrebbero differire da una ricerca in avanti, è possibile utilizzare il metodo [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Un iteratore su sottostringhe di `self`, separato da caratteri abbinati da un modello e restituito in ordine inverso.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Equivalente a [`split`], tranne per il fatto che la sottostringa finale viene ignorata se vuota.
    ///
    /// [`split`]: str::split
    ///
    /// Questo metodo può essere utilizzato per i dati di stringa che sono _terminated_, piuttosto che _separated_ da un modello.
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito richiede che il pattern supporti una ricerca inversa e avrà una doppia terminazione se una ricerca forward/reverse restituisce gli stessi elementi.
    ///
    ///
    /// Per l'iterazione dalla parte anteriore, è possibile utilizzare il metodo [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Un iteratore su sottostringhe della sezione di stringa data, separato da un modello, limitato a restituire al massimo elementi `n`.
    ///
    /// Se vengono restituite sottostringhe `n`, l'ultima sottostringa (la `n`esima sottostringa) conterrà il resto della stringa.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito non avrà una doppia terminazione, perché non è efficiente da supportare.
    ///
    /// Se il pattern consente una ricerca inversa, è possibile utilizzare il metodo [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Un iteratore su sottostringhe di questa sezione di stringa, separato da un modello, a partire dalla fine della stringa, limitato a restituire al massimo elementi `n`.
    ///
    ///
    /// Se vengono restituite sottostringhe `n`, l'ultima sottostringa (la `n`esima sottostringa) conterrà il resto della stringa.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito non avrà una doppia terminazione, perché non è efficiente da supportare.
    ///
    /// Per la divisione dalla parte anteriore, è possibile utilizzare il metodo [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Divide la stringa alla prima occorrenza del delimitatore specificato e restituisce il prefisso prima del delimitatore e il suffisso dopo il delimitatore.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Divide la stringa sull'ultima occorrenza del delimitatore specificato e restituisce il prefisso prima del delimitatore e il suffisso dopo il delimitatore.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Un iteratore sulle corrispondenze disgiunte di un pattern all'interno della fetta di stringa data.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito sarà un [`DoubleEndedIterator`] se il pattern consente una ricerca inversa e la ricerca forward/reverse restituisce gli stessi elementi.
    /// Ciò è vero, ad esempio, per [`char`], ma non per `&str`.
    ///
    /// Se il modello consente una ricerca inversa ma i suoi risultati potrebbero differire da una ricerca in avanti, è possibile utilizzare il metodo [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Un iteratore sulle corrispondenze disgiunte di un pattern all'interno di questa porzione di stringa, restituito in ordine inverso.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito richiede che il pattern supporti una ricerca inversa e sarà un [`DoubleEndedIterator`] se una ricerca forward/reverse restituisce gli stessi elementi.
    ///
    ///
    /// Per l'iterazione dalla parte anteriore, è possibile utilizzare il metodo [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Un iteratore sulle corrispondenze disgiunte di un pattern all'interno di questa sezione di stringa e sull'indice da cui inizia la corrispondenza.
    ///
    /// Per le corrispondenze di `pat` all'interno di `self` che si sovrappongono, vengono restituiti solo gli indici corrispondenti alla prima corrispondenza.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito sarà un [`DoubleEndedIterator`] se il pattern consente una ricerca inversa e la ricerca forward/reverse restituisce gli stessi elementi.
    /// Ciò è vero, ad esempio, per [`char`], ma non per `&str`.
    ///
    /// Se il modello consente una ricerca inversa ma i suoi risultati potrebbero differire da una ricerca in avanti, è possibile utilizzare il metodo [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // solo il primo `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Un iteratore sulle corrispondenze disgiunte di un pattern all'interno di `self`, restituito in ordine inverso insieme all'indice della corrispondenza.
    ///
    /// Per le corrispondenze di `pat` all'interno di `self` che si sovrappongono, vengono restituiti solo gli indici corrispondenti all'ultima corrispondenza.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Comportamento iteratore
    ///
    /// L'iteratore restituito richiede che il pattern supporti una ricerca inversa e sarà un [`DoubleEndedIterator`] se una ricerca forward/reverse restituisce gli stessi elementi.
    ///
    ///
    /// Per l'iterazione dalla parte anteriore, è possibile utilizzare il metodo [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // solo l'ultimo `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Restituisce una sezione di stringa con spazi bianchi iniziali e finali rimossi.
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Restituisce una sezione di stringa con gli spazi bianchi iniziali rimossi.
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// `start` in questo contesto si intende la prima posizione di quella stringa di byte;per una lingua da sinistra a destra come l'inglese o il russo, questo sarà il lato sinistro, e per le lingue da destra a sinistra come l'arabo o l'ebraico, questo sarà il lato destro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Restituisce una sezione di stringa con gli spazi vuoti finali rimossi.
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// `end` in questo contesto si intende l'ultima posizione di quella stringa di byte;per una lingua da sinistra a destra come l'inglese o il russo, questo sarà il lato destro, e per le lingue da destra a sinistra come l'arabo o l'ebraico, questo sarà il lato sinistro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Restituisce una sezione di stringa con gli spazi bianchi iniziali rimossi.
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// 'Left' in questo contesto si intende la prima posizione di quella stringa di byte;per una lingua come l'arabo o l'ebraico che sono "da destra a sinistra" anziché "da sinistra a destra", questo sarà il lato _right_, non il lato sinistro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Restituisce una sezione di stringa con gli spazi vuoti finali rimossi.
    ///
    /// 'Whitespace' è definito in base ai termini della proprietà Unicode Derived Core `White_Space`.
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// 'Right' in questo contesto si intende l'ultima posizione di quella stringa di byte;per una lingua come l'arabo o l'ebraico che sono "da destra a sinistra" anziché "da sinistra a destra", questo sarà il lato _left_, non il lato destro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Restituisce una sezione di stringa con tutti i prefissi e suffissi che corrispondono a un modello ripetutamente rimossi.
    ///
    /// [pattern] può essere un [`char`], uno slice di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ricorda la prima corrispondenza conosciuta, correggila di seguito se
            // l'ultima partita è diversa
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SICUREZZA: `Searcher` è noto per restituire indici validi.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Restituisce una sezione di stringa con tutti i prefissi che corrispondono a un modello ripetutamente rimossi.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// `start` in questo contesto si intende la prima posizione di quella stringa di byte;per una lingua da sinistra a destra come l'inglese o il russo, questo sarà il lato sinistro, e per le lingue da destra a sinistra come l'arabo o l'ebraico, questo sarà il lato destro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SICUREZZA: `Searcher` è noto per restituire indici validi.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Restituisce una sezione di stringa con il prefisso rimosso.
    ///
    /// Se la stringa inizia con il modello `prefix`, restituisce la sottostringa dopo il prefisso, racchiusa in `Some`.
    /// A differenza di `trim_start_matches`, questo metodo rimuove il prefisso esattamente una volta.
    ///
    /// Se la stringa non inizia con `prefix`, restituisce `None`.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Restituisce una sezione di stringa con il suffisso rimosso.
    ///
    /// Se la stringa termina con il modello `suffix`, restituisce la sottostringa prima del suffisso, racchiusa in `Some`.
    /// A differenza di `trim_end_matches`, questo metodo rimuove il suffisso esattamente una volta.
    ///
    /// Se la stringa non termina con `suffix`, restituisce `None`.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Restituisce una sezione di stringa con tutti i suffissi che corrispondono a un modello ripetutamente rimossi.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// `end` in questo contesto si intende l'ultima posizione di quella stringa di byte;per una lingua da sinistra a destra come l'inglese o il russo, questo sarà il lato destro, e per le lingue da destra a sinistra come l'arabo o l'ebraico, questo sarà il lato sinistro.
    ///
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SICUREZZA: `Searcher` è noto per restituire indici validi.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Restituisce una sezione di stringa con tutti i prefissi che corrispondono a un modello ripetutamente rimossi.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// 'Left' in questo contesto si intende la prima posizione di quella stringa di byte;per una lingua come l'arabo o l'ebraico che sono "da destra a sinistra" anziché "da sinistra a destra", questo sarà il lato _right_, non il lato sinistro.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Restituisce una sezione di stringa con tutti i suffissi che corrispondono a un modello ripetutamente rimossi.
    ///
    /// L [pattern] può essere un `&str`, [`char`], una porzione di [`char`] s, o una funzione o chiusura che determina se un carattere corrisponde.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Direzionalità del testo
    ///
    /// Una stringa è una sequenza di byte.
    /// 'Right' in questo contesto si intende l'ultima posizione di quella stringa di byte;per una lingua come l'arabo o l'ebraico che sono "da destra a sinistra" anziché "da sinistra a destra", questo sarà il lato _left_, non il lato destro.
    ///
    ///
    /// # Examples
    ///
    /// Modelli semplici:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Uno schema più complesso, utilizzando una chiusura:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analizza questa sezione di stringa in un altro tipo.
    ///
    /// Poiché `parse` è così generale, può causare problemi con l'inferenza del tipo.
    /// In quanto tale, `parse` è una delle poche volte in cui vedrai la sintassi affettuosamente nota come 'turbofish': `::<>`.
    ///
    /// Questo aiuta l'algoritmo di inferenza a capire in modo specifico quale tipo stai cercando di analizzare.
    ///
    /// `parse` può analizzare qualsiasi tipo che implementa [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Restituirà [`Err`] se non è possibile analizzare questa sezione di stringa nel tipo desiderato.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Utilizzo di base
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Utilizzando 'turbofish' invece di annotare `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Impossibile analizzare:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Controlla se tutti i caratteri in questa stringa rientrano nell'intervallo ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Possiamo trattare ogni byte come carattere qui: tutti i caratteri multibyte iniziano con un byte che non è nell'intervallo ascii, quindi ci fermeremo già qui.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Verifica che due stringhe siano una corrispondenza ASCII senza distinzione tra maiuscole e minuscole.
    ///
    /// Come `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ma senza allocare e copiare i provvisori.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Converte questa stringa nel suo equivalente in maiuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'a' a 'z' vengono mappate da 'A' a 'Z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore maiuscolo senza modificare quello esistente, utilizzare [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SICUREZZA: sicura perché trasmutiamo due tipi con lo stesso layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Converte questa stringa nel suo equivalente in minuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'A' a 'Z' vengono mappate da 'a' a 'z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore minuscolo senza modificare quello esistente, utilizzare [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SICUREZZA: sicura perché trasmutiamo due tipi con lo stesso layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Restituisce un iteratore che esegue l'escape di ogni carattere in `self` con [`char::escape_debug`].
    ///
    ///
    /// Note: solo i codepoint estesi del grafema che iniziano la stringa verranno sottoposti a escape.
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Restituisce un iteratore che esegue l'escape di ogni carattere in `self` con [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Restituisce un iteratore che esegue l'escape di ogni carattere in `self` con [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Come iteratore:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Utilizzando `println!` direttamente:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Entrambi sono equivalenti a:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Utilizzando `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Crea uno str vuoto
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Crea uno str mutabile vuoto
    #[inline]
    fn default() -> Self {
        // SICUREZZA: la stringa vuota è valida UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Un tipo fn nominabile e clonabile
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SICUREZZA: non sicura
        unsafe { from_utf8_unchecked(bytes) }
    };
}