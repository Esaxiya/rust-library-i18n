//! Definisce il tipo di errore utf8.

use crate::fmt;

/// Errori che possono verificarsi quando si tenta di interpretare una sequenza di [`u8`] come una stringa.
///
/// In quanto tale, la famiglia `from_utf8` di funzioni e metodi sia per [`String`] se [`&str`] fa uso di questo errore, per esempio.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// I metodi di questo tipo di errore possono essere utilizzati per creare funzionalità simili a `String::from_utf8_lossy` senza allocare memoria heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Restituisce l'indice nella stringa data fino a cui è stato verificato UTF-8 valido.
    ///
    /// È l'indice massimo in modo tale che `from_utf8(&input[..index])` restituisca `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::str;
    ///
    /// // alcuni byte non validi, in un file vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 restituisce un Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // il secondo byte non è valido qui
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Fornisce ulteriori informazioni sull'errore:
    ///
    /// * `None`: la fine dell'input è stata raggiunta inaspettatamente.
    ///   `self.valid_up_to()` è compreso tra 1 e 3 byte dalla fine dell'input.
    ///   Se un flusso di byte (come un file o un socket di rete) viene decodificato in modo incrementale, potrebbe trattarsi di un `char` valido la cui sequenza di byte UTF-8 si estende su più blocchi.
    ///
    ///
    /// * `Some(len)`: è stato rilevato un byte imprevisto.
    ///   La lunghezza fornita è quella della sequenza di byte non valida che inizia dall'indice fornito da `valid_up_to()`.
    ///   La decodifica dovrebbe riprendere dopo quella sequenza (dopo aver inserito un [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) in caso di decodifica con perdita.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Un errore restituito durante l'analisi di un `bool` utilizzando [`from_str`] non riesce
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}