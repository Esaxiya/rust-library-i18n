//! L'API del pattern di stringhe.
//!
//! L'API Pattern fornisce un meccanismo generico per l'utilizzo di diversi tipi di pattern durante la ricerca in una stringa.
//!
//! Per maggiori dettagli, vedere traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] e [`DoubleEndedSearcher`].
//!
//! Sebbene questa API sia instabile, viene esposta tramite API stabili sul tipo [`str`].
//!
//! # Examples
//!
//! [`Pattern`] è [implemented][pattern-impls] nell'API stabile per [`&str`][`str`], [`char`], sezioni di [`char`] e funzioni e chiusure che implementano `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // modello di carattere
//! assert_eq!(s.find('n'), Some(2));
//! // fetta di pattern chars
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // modello di chiusura
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Uno schema di corde.
///
/// Un `Pattern<'a>` esprime che il tipo di implementazione può essere utilizzato come modello di stringa per la ricerca in un [`&'a str`][str].
///
/// Ad esempio, sia `'a'` che `"aa"` sono modelli che corrisponderebbero all'indice `1` nella stringa `"baaaab"`.
///
/// Lo stesso trait funge da builder per un tipo [`Searcher`] associato, che fa il lavoro effettivo di trovare le occorrenze del pattern in una stringa.
///
///
/// A seconda del tipo di pattern, il comportamento di metodi come [`str::find`] e [`str::contains`] può cambiare.
/// La tabella seguente descrive alcuni di questi comportamenti.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Ricercatore associato per questo modello
    type Searcher: Searcher<'a>;

    /// Costruisce il ricercatore associato da `self` e `haystack` in cui cercare.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Controlla se il motivo corrisponde ovunque nel pagliaio
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Controlla se il motivo corrisponde nella parte anteriore del pagliaio
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Controlla se il motivo corrisponde sul retro del pagliaio
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Rimuove il motivo dalla parte anteriore del pagliaio, se corrisponde.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SICUREZZA: `Searcher` è noto per restituire indici validi.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Rimuove il motivo dal retro del pagliaio, se corrisponde.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SICUREZZA: `Searcher` è noto per restituire indici validi.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Risultato della chiamata a [`Searcher::next()`] o [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Esprime che è stata trovata una corrispondenza del modello in `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Esprime che `haystack[a..b]` è stato rifiutato come possibile corrispondenza del pattern.
    ///
    /// Nota che potrebbe esserci più di un `Reject` tra due `Match`, non è necessario che siano combinati in uno solo.
    ///
    ///
    Reject(usize, usize),
    /// Esprime che ogni byte del pagliaio è stato visitato, terminando l'iterazione.
    ///
    Done,
}

/// Un ricercatore di uno schema di corde.
///
/// Questo trait fornisce metodi per la ricerca di corrispondenze non sovrapposte di un pattern a partire dall (left) anteriore di una stringa.
///
/// Sarà implementato dai tipi `Searcher` associati di [`Pattern`] trait.
///
/// trait è contrassegnato come non sicuro perché gli indici restituiti dai metodi [`next()`][Searcher::next] devono trovarsi su confini utf8 validi nel pagliaio.
/// Ciò consente ai consumatori di questo trait di tagliare il pagliaio senza ulteriori controlli di runtime.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter per la stringa sottostante in cui cercare
    ///
    /// Restituirà sempre lo stesso [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Esegue il passaggio di ricerca successivo partendo dalla parte anteriore.
    ///
    /// - Restituisce [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` corrisponde al modello.
    /// - Restituisce [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` non può abbinare il pattern, anche parzialmente.
    /// - Restituisce [`Done`][SearchStep::Done] se ogni byte del pagliaio è stato visitato.
    ///
    /// Il flusso di valori [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] fino a un [`Done`][SearchStep::Done] conterrà intervalli di indice adiacenti, non sovrapposti, che coprono l'intero pagliaio e si trovano sui confini di utf8.
    ///
    ///
    /// Un risultato [`Match`][SearchStep::Match] deve contenere l'intero pattern abbinato, tuttavia i risultati [`Reject`][SearchStep::Reject] possono essere suddivisi in molti frammenti adiacenti arbitrari.Entrambi gli intervalli possono avere lunghezza zero.
    ///
    /// Ad esempio, il pattern `"aaa"` e il pagliaio `"cbaaaaab"` potrebbero produrre il flusso
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Trova il successivo risultato [`Match`][SearchStep::Match].Vedi [`next()`][Searcher::next].
    ///
    /// A differenza di [`next()`][Searcher::next], non vi è alcuna garanzia che gli intervalli restituiti di questo e di [`next_reject`][Searcher::next_reject] si sovrappongano.
    /// Questo restituirà `(start_match, end_match)`, dove start_match è l'indice di dove inizia la partita e end_match è l'indice dopo la fine della partita.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Trova il successivo risultato [`Reject`][SearchStep::Reject].Vedi [`next()`][Searcher::next] e [`next_match()`][Searcher::next_match].
    ///
    /// A differenza di [`next()`][Searcher::next], non vi è alcuna garanzia che gli intervalli restituiti di questo e di [`next_match`][Searcher::next_match] si sovrappongano.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un cercatore inverso per uno schema di corde.
///
/// Questo trait fornisce metodi per la ricerca di corrispondenze non sovrapposte di un pattern a partire dal retro (right) di una stringa.
///
/// Sarà implementato dai tipi [`Searcher`] associati dell [`Pattern`] trait se il pattern supporta la ricerca dal retro.
///
///
/// Gli intervalli di indice restituiti da questo trait non devono corrispondere esattamente a quelli della ricerca in avanti al contrario.
///
/// Per il motivo per cui questo trait è contrassegnato come non sicuro, vederli genitore trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Esegue il passaggio di ricerca successivo partendo da dietro.
    ///
    /// - Restituisce [`Match(a, b)`][SearchStep::Match] se `haystack[a..b]` corrisponde al modello.
    /// - Restituisce [`Reject(a, b)`][SearchStep::Reject] se `haystack[a..b]` non può abbinare il pattern, anche parzialmente.
    /// - Restituisce [`Done`][SearchStep::Done] se ogni byte del pagliaio è stato visitato
    ///
    /// Il flusso di valori [`Match`][SearchStep::Match] e [`Reject`][SearchStep::Reject] fino a un [`Done`][SearchStep::Done] conterrà intervalli di indice adiacenti, non sovrapposti, che coprono l'intero pagliaio e si trovano sui confini di utf8.
    ///
    ///
    /// Un risultato [`Match`][SearchStep::Match] deve contenere l'intero pattern abbinato, tuttavia i risultati [`Reject`][SearchStep::Reject] possono essere suddivisi in molti frammenti adiacenti arbitrari.Entrambi gli intervalli possono avere lunghezza zero.
    ///
    /// Ad esempio, il pattern `"aaa"` e il pagliaio `"cbaaaaab"` potrebbero produrre lo stream `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Trova il successivo risultato [`Match`][SearchStep::Match].
    /// Vedi [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Trova il successivo risultato [`Reject`][SearchStep::Reject].
    /// Vedi [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Un marker trait per esprimere che un [`ReverseSearcher`] può essere utilizzato per un'implementazione [`DoubleEndedIterator`].
///
/// Per questo, l'impl di [`Searcher`] e [`ReverseSearcher`] deve seguire queste condizioni:
///
/// - Tutti i risultati di `next()` devono essere identici ai risultati di `next_back()` in ordine inverso.
/// - `next()` e `next_back()` devono comportarsi come le due estremità di un intervallo di valori, ovvero non possono "walk past each other".
///
/// # Examples
///
/// `char::Searcher` è un `DoubleEndedSearcher` perché la ricerca di un [`char`] richiede solo di guardarne uno alla volta, che si comporta allo stesso modo da entrambe le estremità.
///
/// `(&str)::Searcher` non è un `DoubleEndedSearcher` perché il pattern `"aa"` nel pagliaio `"aaa"` corrisponde a `"[aa]a"` o `"a[aa]"`, a seconda del lato in cui viene cercato.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl per char
/////////////////////////////////////////////////////////////////////////////

/// Tipo associato per `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariante di sicurezza: `finger`/`finger_back` deve essere un indice di byte utf8 valido di `haystack` Questo invariante può essere interrotto *all'interno di* next_match e next_match_back, tuttavia devono uscire con le dita sui limiti dei punti di codice validi.
    //
    //
    /// `finger` è l'indice di byte corrente della ricerca in avanti.
    /// Immagina che esista prima del byte nel suo indice, ad es
    /// `haystack[finger]` è il primo byte della slice che dobbiamo ispezionare durante la ricerca in avanti
    ///
    finger: usize,
    /// `finger_back` è l'indice di byte corrente della ricerca inversa.
    /// Immagina che esista dopo il byte nel suo indice, ad es
    /// haystack [finger_back, 1] è l'ultimo byte della slice che dobbiamo ispezionare durante la ricerca in avanti (e quindi il primo byte da ispezionare quando si chiama next_back()).
    ///
    finger_back: usize,
    /// Il personaggio cercato
    needle: char,

    // invariante di sicurezza: `utf8_size` deve essere inferiore a 5
    /// Il numero di byte che `needle` occupa quando codificato in utf8.
    utf8_size: usize,
    /// Una copia codificata utf8 dell `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SICUREZZA: 1-4 garantiscono la sicurezza di `get_unchecked`
        // 1. `self.finger` e `self.finger_back` sono mantenuti sui confini Unicode (questo è invariante)
        // 2. `self.finger >= 0` poiché inizia da 0 e aumenta solo
        // 3. `self.finger < self.finger_back` perché altrimenti il char `iter` restituirebbe `SearchStep::Done`
        // 4.
        // `self.finger` viene prima della fine del pagliaio perché `self.finger_back` inizia alla fine e diminuisce solo
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // aggiungere l'offset di byte del carattere corrente senza ricodificare come utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // prendi il pagliaio dopo l'ultimo personaggio trovato
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // l'ultimo byte dell'ago codificato utf8 SICUREZZA: abbiamo un invariante che `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Il nuovo dito è l'indice del byte che abbiamo trovato, più uno, poiché abbiamo memorizzato l'ultimo byte del carattere.
                //
                // Nota che questo non ci dà sempre un dito su un confine UTF8.
                // Se *non* abbiamo trovato il nostro carattere, potremmo essere indicizzati all'ultimo byte di un carattere a 3 o 4 byte.
                // Non possiamo semplicemente saltare al successivo byte iniziale valido perché un carattere come ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ci farà sempre trovare il secondo byte durante la ricerca del terzo.
                //
                //
                // Tuttavia, questo è assolutamente ok.
                // Sebbene abbiamo l'invariante che self.finger si trova su un confine UTF8, questa invariante non è invariata all'interno di questo metodo (è invocata in CharSearcher::next()).
                //
                // Usciamo da questo metodo solo quando raggiungiamo la fine della stringa o se troviamo qualcosa.Quando troviamo qualcosa, l `finger` verrà impostato su un limite UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // non trovato niente, esci
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // lascia che next_reject utilizzi l'implementazione predefinita dal Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SICUREZZA: vedere il commento per next() sopra
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // sottrarre l'offset di byte del carattere corrente senza ricodificare come utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // porta il pagliaio fino all'ultimo carattere cercato ma escluso
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // l'ultimo byte dell'ago codificato utf8 SICUREZZA: abbiamo un invariante che `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // abbiamo cercato una fetta che è stata compensata da self.finger, abbiamo aggiunto self.finger per recuperare l'indice originale
                //
                let index = self.finger + index;
                // memrchr restituirà l'indice del byte che desideriamo trovare.
                // Nel caso di un carattere ASCII, questo è effettivamente dove vorremmo che fosse il nostro nuovo dito ("after" il carattere trovato nel paradigma dell'iterazione inversa).
                //
                // Per i caratteri multibyte, dobbiamo saltare il numero di byte in più rispetto a ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // sposta il dito prima del carattere trovato (cioè, al suo indice iniziale)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Non possiamo usare finger_back=index, size + 1 qui.
                // Se abbiamo trovato l'ultimo carattere di un carattere di dimensioni diverse (o il byte centrale di un carattere diverso) abbiamo bisogno di riportare finger_back a `index`.
                // Allo stesso modo, `finger_back` ha il potenziale per non essere più su un confine, ma questo va bene poiché usciamo da questa funzione solo su un confine o quando il pagliaio è stato completamente cercato.
                //
                //
                // A differenza di next_match, questo non ha il problema di byte ripetuti in utf-8 perché stiamo cercando l'ultimo byte e possiamo solo aver trovato l'ultimo byte durante la ricerca al contrario.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // non trovato niente, esci
                return None;
            }
        }
    }

    // lascia che next_reject_back utilizzi l'implementazione predefinita dal Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Cerca caratteri uguali a un dato [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl per un wrapper MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Confronta le lunghezze dell'iteratore di slice di byte interno per trovare la lunghezza del carattere corrente
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Confronta le lunghezze dell'iteratore di slice di byte interno per trovare la lunghezza del carattere corrente
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl per&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Cambia/Rimuovi a causa di ambiguità di significato.

/// Tipo associato per `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Cerca i caratteri uguali a uno qualsiasi dei [`char`] nella sezione.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tipo associato per `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Cerca [`char`] che corrispondono al predicato dato.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegati all `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl per &str
/////////////////////////////////////////////////////////////////////////////

/// Ricerca di sottostringhe senza allocazione.
///
/// Gestirà il modello `""` come restituendo corrispondenze vuote a ciascun confine di carattere.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Controlla se il motivo corrisponde nella parte anteriore del pagliaio.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Rimuove il motivo dalla parte anteriore del pagliaio, se corrisponde.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SICUREZZA: è stata appena verificata l'esistenza del prefisso.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Controlla se il motivo corrisponde sul retro del pagliaio.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Rimuove il motivo dal retro del pagliaio, se corrisponde.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SICUREZZA: è stata appena verificata l'esistenza del suffisso.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Ricercatore di sottostringa bidirezionale
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tipo associato per `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // l'ago vuoto rifiuta ogni carattere e corrisponde a ogni stringa vuota tra di loro
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher produce indici *Match* validi che si dividono ai confini del carattere fintanto che esegue la corrispondenza corretta e che pagliaio e ago sono validi UTF-8 *I rifiuti* dall'algoritmo possono cadere su qualsiasi indice, ma li cammineremo manualmente fino al confine del carattere successivo, in modo che siano utf-8 sicuri.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // passa al confine del carattere successivo
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // scrivere i casi `true` e `false` per incoraggiare il compilatore a specializzare i due casi separatamente.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // passa al confine del carattere successivo
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // scrivi `true` e `false`, come `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Lo stato interno dell'algoritmo di ricerca della sottostringa a due vie.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indice di fattorizzazione critica
    crit_pos: usize,
    /// indice critico di fattorizzazione per l'ago invertito
    crit_pos_back: usize,
    period: usize,
    /// `byteset` è un'estensione (non fa parte dell'algoritmo a due vie);
    /// è un "fingerprint" a 64 bit dove ogni bit `j` impostato corrisponde a un (byte&63)==j presente nell'ago.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indice nell'ago prima del quale abbiamo già abbinato
    memory: usize,
    /// indice nell'ago dopo di che abbiamo già abbinato
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Una spiegazione particolarmente leggibile di quello che sta succedendo qui può essere trovata nel libro "Text Algorithms" di Crochemore e Rytter, cap.13.
        // In particolare, vedere il codice per "Algorithm CP" a p.
        // 323.
        //
        // Quello che sta succedendo è che abbiamo una fattorizzazione critica (u, v) dell'ago e vogliamo determinare se u è un suffisso di&v [.. punto].
        // Se lo è, usiamo "Algorithm CP1".
        // Altrimenti usiamo "Algorithm CP2", che è ottimizzato per quando il periodo dell'ago è grande.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // caso di periodo breve-il periodo è esatto calcola una fattorizzazione critica separata per l'ago invertito x=u 'v' dove | v '|<period(x).
            //
            // Ciò è accelerato dal periodo già noto.
            // Si noti che un caso come x= "acba" può essere scomposto esattamente in avanti (crit_pos=1, periodo=3) mentre viene scomposto con periodo approssimativo al contrario (crit_pos=2, periodo=2).
            // Usiamo la fattorizzazione inversa data ma manteniamo il periodo esatto.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // caso di lungo periodo: abbiamo un'approssimazione del periodo effettivo e non usiamo la memorizzazione.
            //
            //
            // Approssimare il periodo con il limite inferiore max(|u|, |v|) + 1.
            // La fattorizzazione critica è efficiente da utilizzare sia per la ricerca diretta che per quella inversa.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valore fittizio per indicare che il periodo è lungo
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Una delle idee principali di Two-Way è che fattorizziamo l'ago in due metà, (u, v), e iniziamo a cercare di trovare v nel pagliaio scansionando da sinistra a destra.
    // Se v corrisponde, proviamo a trovare u scansionando da destra a sinistra.
    // Quanto lontano possiamo saltare quando incontriamo una mancata corrispondenza è tutto basato sul fatto che (u, v) è una fattorizzazione critica per l'ago.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` utilizza `self.position` come cursore
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Controlla di avere spazio per la ricerca in position + needle_last non può overflow se assumiamo che le slice siano limitate dall'intervallo di isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Salta rapidamente porzioni abbondanti non correlate alla nostra sottostringa
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Controlla se la parte destra dell'ago corrisponde
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Controlla se la parte sinistra dell'ago corrisponde
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Abbiamo trovato una corrispondenza!
            let match_pos = self.position;

            // Note: aggiungi self.period invece di needle.len() per avere corrispondenze sovrapposte
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // impostato su needle.len(), self.period per le corrispondenze sovrapposte
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Segue le idee in `next()`.
    //
    // Le definizioni sono simmetriche, con period(x) = period(reverse(x)) e local_period(u, v) = local_period(reverse(v), reverse(u)), quindi se (u, v) è una fattorizzazione critica, lo è anche (reverse(v), reverse(u)).
    //
    //
    // Per il caso inverso abbiamo calcolato una fattorizzazione critica x=u 'v' (campo `crit_pos_back`).Abbiamo bisogno di | u |<period(x) per il caso in avanti e quindi | v '|<period(x) per il contrario.
    //
    // Per cercare al contrario attraverso il pagliaio, cerchiamo in avanti attraverso un pagliaio invertito con un ago invertito, facendo corrispondere prima u 'e poi v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` utilizza `self.end` come cursore, in modo che `next()` e `next_back()` siano indipendenti.
        //
        let old_end = self.end;
        'search: loop {
            // Verificare di avere spazio per la ricerca alla fine, needle.len() si riavvolgerà quando non c'è più spazio, ma a causa dei limiti di lunghezza della fetta non potrà mai tornare indietro nella lunghezza del pagliaio.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Salta rapidamente porzioni abbondanti non correlate alla nostra sottostringa
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Controlla se la parte sinistra dell'ago corrisponde
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Controlla se la parte destra dell'ago corrisponde
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Abbiamo trovato una corrispondenza!
            let match_pos = self.end - needle.len();
            // Note: sub self.period invece di needle.len() per avere corrispondenze sovrapposte
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Calcola il suffisso massimo di `arr`.
    //
    // Il suffisso massimo è una possibile fattorizzazione critica (u, v) di `arr`.
    //
    // Restituisce (`i`, `p`) dove `i` è l'indice iniziale di v e `p` è il periodo di v.
    //
    // `order_greater` determina se l'ordine lessicale è `<` o `>`.
    // Entrambi gli ordini devono essere calcolati: l'ordine con l `i` più grande fornisce una fattorizzazione critica.
    //
    //
    // Per i casi di lungo periodo, il periodo risultante non è esatto (è troppo breve).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Corrisponde a i nel documento
        let mut right = 1; // Corrisponde a j nel documento
        let mut offset = 0; // Corrisponde a k nel foglio, ma a partire da 0
        // in modo che corrisponda all'indicizzazione basata su 0.
        let mut period = 1; // Corrisponde a p nel documento

        while let Some(&a) = arr.get(right + offset) {
            // `left` saranno in entrata quando `right` è.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Il suffisso è più piccolo, il periodo finora è l'intero prefisso.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avanza attraverso la ripetizione del periodo corrente.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Il suffisso è più grande, ricomincia dalla posizione corrente.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Calcola il suffisso massimo dell'inverso di `arr`.
    //
    // Il suffisso massimo è una possibile fattorizzazione critica (u ', v') di `arr`.
    //
    // Restituisce `i` dove `i` è l'indice iniziale di v ', dal retro;
    // restituisce immediatamente quando viene raggiunto un periodo di `known_period`.
    //
    // `order_greater` determina se l'ordine lessicale è `<` o `>`.
    // Entrambi gli ordini devono essere calcolati: l'ordine con l `i` più grande fornisce una fattorizzazione critica.
    //
    //
    // Per i casi di lungo periodo, il periodo risultante non è esatto (è troppo breve).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Corrisponde a i nel documento
        let mut right = 1; // Corrisponde a j nel documento
        let mut offset = 0; // Corrisponde a k nel foglio, ma a partire da 0
        // in modo che corrisponda all'indicizzazione basata su 0.
        let mut period = 1; // Corrisponde a p nel documento
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Il suffisso è più piccolo, il periodo finora è l'intero prefisso.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avanza attraverso la ripetizione del periodo corrente.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Il suffisso è più grande, ricomincia dalla posizione corrente.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy consente all'algoritmo di saltare le non corrispondenze il più rapidamente possibile o di lavorare in una modalità in cui emette i rifiuti in modo relativamente rapido.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Salta per abbinare gli intervalli il più rapidamente possibile
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emetti rifiuti regolarmente
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}