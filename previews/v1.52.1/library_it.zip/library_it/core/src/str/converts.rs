//! Modi per creare un `str` da una fetta di byte.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Converte una sezione di byte in una sezione di stringa.
///
/// Uno slice di stringa ([`&str`]) è composto da byte ([`u8`]) e uno slice di byte ([`&[u8]`][byteslice]) è composto da byte, quindi questa funzione converte tra i due.
/// Tuttavia, non tutte le sezioni di byte sono sezioni di stringa valide: [`&str`] richiede che sia UTF-8 valido.
/// `from_utf8()` verifica che i byte siano validi UTF-8, quindi esegue la conversione.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Se sei sicuro che il byte slice sia valido UTF-8 e non vuoi sostenere il sovraccarico del controllo di validità, esiste una versione non sicura di questa funzione, [`from_utf8_unchecked`], che ha lo stesso comportamento ma salta il controllo.
///
///
/// Se hai bisogno di un `String` invece di un `&str`, considera [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Poiché puoi allocare in stack un `[u8; N]` e puoi prenderne uno [`&[u8]`][byteslice], questa funzione è un modo per avere una stringa allocata nello stack.C'è un esempio di questo nella sezione degli esempi di seguito.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Restituisce `Err` se la slice non è UTF-8 con una descrizione del motivo per cui la slice fornita non è UTF-8.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::str;
///
/// // alcuni byte, in un file vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Sappiamo che questi byte sono validi, quindi usa `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Byte errati:
///
/// ```
/// use std::str;
///
/// // alcuni byte non validi, in un file vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Vedere i documenti per [`Utf8Error`] per maggiori dettagli sui tipi di errori che possono essere restituiti.
///
/// Un "stack allocated string":
///
/// ```
/// use std::str;
///
/// // alcuni byte, in un array allocato nello stack
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Sappiamo che questi byte sono validi, quindi usa `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICUREZZA: ho appena eseguito la convalida.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Converte una sezione di byte modificabile in una sezione di stringa modificabile.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" come vector mutevole
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Poiché sappiamo che questi byte sono validi, possiamo usare `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Byte errati:
///
/// ```
/// use std::str;
///
/// // Alcuni byte non validi in un vector mutabile
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Vedere i documenti per [`Utf8Error`] per maggiori dettagli sui tipi di errori che possono essere restituiti.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SICUREZZA: ho appena eseguito la convalida.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Converte una sezione di byte in una sezione di stringa senza verificare che la stringa contenga UTF-8 valido.
///
/// Vedere la versione sicura, [`from_utf8`], per ulteriori informazioni.
///
/// # Safety
///
/// Questa funzione non è sicura perché non controlla che i byte passati siano validi UTF-8.
/// Se questo vincolo viene violato, ne risulta un comportamento indefinito, poiché il resto di Rust presume che [`&str`] s siano UTF-8 validi.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::str;
///
/// // alcuni byte, in un file vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SICUREZZA: il chiamante deve garantire che i byte `v` siano validi UTF-8.
    // Si basa anche su `&str` e `&[u8]` con lo stesso layout.
    unsafe { mem::transmute(v) }
}

/// Converte una porzione di byte in una porzione di stringa senza verificare che la stringa contenga UTF-8 valido;versione mutevole.
///
///
/// Vedere la versione immutabile, [`from_utf8_unchecked()`] per ulteriori informazioni.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SICUREZZA: il chiamante deve garantire che i byte `v`
    // sono validi UTF-8, quindi il cast a `*mut str` è sicuro.
    // Inoltre, la dereferenziazione del puntatore è sicura perché quel puntatore proviene da un riferimento che è garantito essere valido per le scritture.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}