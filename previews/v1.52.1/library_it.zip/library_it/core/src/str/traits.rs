//! Implementazioni di Trait per `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementa l'ordinamento delle stringhe.
///
/// Le stringhe sono ordinate [lexicographically](Ord#lexicographical-comparison) in base ai rispettivi valori di byte.
/// Questo ordina i punti di codice Unicode in base alle loro posizioni nelle tabelle dei codici.
/// Questo non è necessariamente lo stesso dell'ordine "alphabetical", che varia in base alla lingua e alle impostazioni locali.
/// L'ordinamento delle stringhe in base a standard culturalmente accettati richiede dati specifici della locale che non rientrano nell'ambito del tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementa operazioni di confronto sulle stringhe.
///
/// Le stringhe vengono confrontate [lexicographically](Ord#lexicographical-comparison) in base ai rispettivi valori di byte.
/// Questo confronta i punti di codice Unicode in base alle loro posizioni nei grafici dei codici.
/// Questo non è necessariamente lo stesso dell'ordine "alphabetical", che varia in base alla lingua e alle impostazioni locali.
/// Il confronto delle stringhe in base a standard culturalmente accettati richiede dati specifici della locale che non rientrano nell'ambito del tipo `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[..]` o `&mut self[..]`.
///
/// Restituisce una porzione dell'intera stringa, ovvero restituisce `&self` o `&mut self`.Equivalente a `&self [0 ..
/// len] "o`&mut self [0 ..
/// len]`.
/// A differenza di altre operazioni di indicizzazione, questo non può mai essere panic.
///
/// Questa operazione è *O*(1).
///
/// Prima di 1.20.0, queste operazioni di indicizzazione erano ancora supportate dall'implementazione diretta di `Index` e `IndexMut`.
///
/// Equivalente a `&self[0 .. len]` o `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[begin .. end]` o `&mut self[begin .. end]`.
///
/// Restituisce una porzione della stringa data dall'intervallo di byte [`begin`, `end`).
///
/// Questa operazione è *O*(1).
///
/// Prima di 1.20.0, queste operazioni di indicizzazione erano ancora supportate dall'implementazione diretta di `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` o `end` non punta all'offset del byte iniziale di un carattere (come definito da `is_char_boundary`), se `begin > end` o `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // questi saranno panic:
/// // il byte 2 si trova all'interno di `ö`:
/// // &s [2 ..3];
///
/// // il byte 8 si trova all'interno di `老`&s [1 ..
/// // 8];
///
/// // il byte 100 è esterno alla stringa&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICUREZZA: appena controllato che `start` e `end` siano su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            // Abbiamo anche controllato i confini dei caratteri, quindi questo è UTF-8 valido.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICUREZZA: appena controllato che `start` e `end` siano su un confine di caratteri.
            // Sappiamo che il puntatore è unico perché lo abbiamo ottenuto da `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SICUREZZA: il chiamante garantisce che `self` è nei limiti di `slice`
        // che soddisfa tutte le condizioni per `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SICUREZZA: vedere i commenti per `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary controlla che l'indice sia in [0, .len()] non può riutilizzare `get` come sopra, a causa di problemi NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SICUREZZA: appena controllato che `start` e `end` siano su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[.. end]` o `&mut self[.. end]`.
///
/// Restituisce una porzione della stringa data dall'intervallo di byte ["0", `end`).
/// Equivalente a `&self[0 .. end]` o `&mut self[0 .. end]`.
///
/// Questa operazione è *O*(1).
///
/// Prima di 1.20.0, queste operazioni di indicizzazione erano ancora supportate dall'implementazione diretta di `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `end` non punta all'offset di byte iniziale di un carattere (come definito da `is_char_boundary`) o se `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SICUREZZA: ho appena controllato che `end` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SICUREZZA: ho appena controllato che `end` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SICUREZZA: ho appena controllato che `end` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[begin ..]` o `&mut self[begin ..]`.
///
/// Restituisce una porzione della stringa data dall'intervallo di byte [`begin`, `len`).Equivalente a `&self [inizio ..
/// len] "o`&mut self [inizio ..
/// len]`.
///
/// Questa operazione è *O*(1).
///
/// Prima di 1.20.0, queste operazioni di indicizzazione erano ancora supportate dall'implementazione diretta di `Index` e `IndexMut`.
///
/// # Panics
///
/// Panics se `begin` non punta all'offset di byte iniziale di un carattere (come definito da `is_char_boundary`) o se `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SICUREZZA: ho appena controllato che `start` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SICUREZZA: ho appena controllato che `start` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SICUREZZA: il chiamante garantisce che `self` è nei limiti di `slice`
        // che soddisfa tutte le condizioni per `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SICUREZZA: identica a `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SICUREZZA: ho appena controllato che `start` sia su un confine di caratteri,
            // e stiamo passando un riferimento sicuro, quindi anche il valore restituito sarà uno.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[begin ..= end]` o `&mut self[begin ..= end]`.
///
/// Restituisce una porzione della stringa data dall'intervallo di byte [`begin`, `end`].Equivalente a `&self [begin .. end + 1]` o `&mut self[begin .. end + 1]`, tranne se `end` ha il valore massimo per `usize`.
///
/// Questa operazione è *O*(1).
///
/// # Panics
///
/// Panics se `begin` non punta all'offset di byte iniziale di un carattere (come definito da `is_char_boundary`), se `end` non punta all'offset di byte finale di un carattere (`end + 1` è un offset di byte iniziale o uguale a `len`), se `begin > end` o se `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementa il sezionamento della sottostringa con la sintassi `&self[..= end]` o `&mut self[..= end]`.
///
/// Restituisce una porzione della stringa data dall'intervallo di byte [0, `end`].
/// Equivalente a `&self [0 .. end + 1]`, tranne se `end` ha il valore massimo per `usize`.
///
/// Questa operazione è *O*(1).
///
/// # Panics
///
/// Panics se `end` non punta all'offset di byte finale di un carattere (`end + 1` è un offset di byte iniziale come definito da `is_char_boundary` o uguale a `len`) o se `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizza un valore da una stringa
///
/// Il metodo [`from_str`] di `FromStr` è spesso usato implicitamente, attraverso il metodo [`parse`] di [`str`].
/// Vedere la documentazione di [`parse`] per esempi.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` non dispone di un parametro di durata, quindi è possibile analizzare solo i tipi che non contengono un parametro di durata.
///
/// In altre parole, puoi analizzare un `i32` con `FromStr`, ma non un `&i32`.
/// Puoi analizzare una struttura che contiene un `i32`, ma non uno che contiene un `&i32`.
///
/// # Examples
///
/// Implementazione di base di `FromStr` su un tipo `Point` di esempio:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// L'errore associato che può essere restituito dall'analisi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizza una stringa `s` per restituire un valore di questo tipo.
    ///
    /// Se l'analisi ha esito positivo, restituisce il valore all'interno di [`Ok`], altrimenti quando la stringa è mal formattata restituisce un errore specifico all'interno di [`Err`].
    /// Il tipo di errore è specifico per l'implementazione di trait.
    ///
    /// # Examples
    ///
    /// Utilizzo di base con [`i32`], un tipo che implementa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizza un `bool` da una stringa.
    ///
    /// Restituisce un `Result<bool, ParseBoolError>`, perché `s` può o non può essere effettivamente analizzabile.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Nota, in molti casi, il metodo `.parse()` su `str` è più appropriato.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}