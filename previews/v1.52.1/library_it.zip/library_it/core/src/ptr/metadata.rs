#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Fornisce il tipo di metadati del puntatore di qualsiasi tipo a cui punta.
///
/// # Metadati del puntatore
///
/// I tipi di puntatore non elaborati e i tipi di riferimento in Rust possono essere pensati come composti da due parti:
/// un puntatore ai dati che contiene l'indirizzo di memoria del valore e alcuni metadati.
///
/// Per i tipi di dimensioni statiche (che implementano `Sized` traits) così come per i tipi `extern`, i puntatori sono detti "sottili": i metadati sono di dimensione zero e il loro tipo è `()`.
///
///
/// Si dice che i puntatori a [dynamically-sized types][dst] siano "larghi" o "grassi", hanno metadati di dimensioni diverse da zero:
///
/// * Per le strutture il cui ultimo campo è un DST, i metadati sono i metadati per l'ultimo campo
/// * Per il tipo `str`, i metadati sono la lunghezza in byte come `usize`
/// * Per i tipi di slice come `[T]`, i metadati sono la lunghezza degli elementi come `usize`
/// * Per gli oggetti trait come `dyn SomeTrait`, i metadati sono [`DynMetadata<Self>`][DynMetadata] (ad esempio `DynMetadata<dyn SomeTrait>`)
///
/// In future, il linguaggio Rust può acquisire nuovi tipi di tipi con metadati del puntatore diversi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Il `Pointee` trait
///
/// Il punto di questo trait è il suo tipo associato a `Metadata`, che è `()` o `usize` o `DynMetadata<_>` come descritto sopra.
/// Viene implementato automaticamente per ogni tipo.
/// Si può presumere che sia implementato in un contesto generico, anche senza un limite corrispondente.
///
/// # Usage
///
/// I puntatori non elaborati possono essere scomposti nell'indirizzo dei dati e nei componenti dei metadati con il loro metodo [`to_raw_parts`].
///
/// In alternativa, i metadati da soli possono essere estratti con la funzione [`metadata`].
/// Un riferimento può essere passato a [`metadata`] e implicitamente forzato.
///
/// Un puntatore (possibly-wide) può essere ricomposto dal suo indirizzo e metadati con [`from_raw_parts`] o [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Il tipo di metadati nei puntatori e nei riferimenti a `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mantieni trait bounds in `static_assert_expected_bounds_for_metadata`
    //
    // in `library/core/src/ptr/metadata.rs` in sincronia con quelli qui:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// I puntatori ai tipi che implementano questo alias trait sono "sottili".
///
/// Ciò include i tipi "Dimensionati" staticamente e i tipi `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: non stabilizzare questo prima che gli alias trait siano stabili nella lingua?
pub trait Thin = Pointee<Metadata = ()>;

/// Estrai il componente metadati di un puntatore.
///
/// I valori di tipo `*mut T`, `&T` o `&mut T` possono essere passati direttamente a questa funzione in quanto costringono implicitamente a `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SICUREZZA: l'accesso al valore dall'unione `PtrRepr` è sicuro poiché * const T
    // e PtrComponents<T>hanno gli stessi layout di memoria.
    // Solo std può fornire questa garanzia.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Forma un puntatore non elaborato (possibly-wide) da un indirizzo dati e metadati.
///
/// Questa funzione è sicura ma il puntatore restituito non è necessariamente sicuro da dereferenziare.
/// Per le sezioni, vedere la documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza.
/// Per gli oggetti trait, i metadati devono provenire da un puntatore allo stesso tipo di cancellazione sottostante.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SICUREZZA: l'accesso al valore dall'unione `PtrRepr` è sicuro poiché * const T
    // e PtrComponents<T>hanno gli stessi layout di memoria.
    // Solo std può fornire questa garanzia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Esegue la stessa funzionalità di [`from_raw_parts`], tranne per il fatto che viene restituito un puntatore `*mut` non elaborato, al contrario di un puntatore `* const` non elaborato.
///
///
/// Vedere la documentazione di [`from_raw_parts`] per maggiori dettagli.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SICUREZZA: l'accesso al valore dall'unione `PtrRepr` è sicuro poiché * const T
    // e PtrComponents<T>hanno gli stessi layout di memoria.
    // Solo std può fornire questa garanzia.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// L'impianto manuale necessario per evitare il vincolo `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// L'impianto manuale necessario per evitare il vincolo `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// I metadati per un tipo di oggetto `Dyn = dyn SomeTrait` trait.
///
/// È un puntatore a una vtable (virtual call table) che rappresenta tutte le informazioni necessarie per manipolare il tipo concreto memorizzato all'interno di un oggetto trait.
/// Il vtable in particolare contiene:
///
/// * tipo di dimensione
/// * tipo di allineamento
/// * un puntatore all'impl `drop_in_place` del tipo (potrebbe essere un no-op per i dati semplici-vecchi)
/// * puntatori a tutti i metodi per l'implementazione del tipo di trait
///
/// Nota che i primi tre sono speciali perché sono necessari per allocare, rilasciare e deallocare qualsiasi oggetto trait.
///
/// È possibile denominare questa struttura con un parametro di tipo che non è un oggetto `dyn` trait (ad esempio `DynMetadata<u64>`) ma non per ottenere un valore significativo di quella struttura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Il prefisso comune di tutti i vtables.È seguito da puntatori a funzione per i metodi trait.
///
/// Dettaglio dell'implementazione privata di `DynMetadata::size_of` ecc.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Restituisce la dimensione del tipo associato a questa tabella v.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Restituisce l'allineamento del tipo associato a questa tabella v.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Restituisce la dimensione e l'allineamento insieme come `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SICUREZZA: il compilatore ha emesso questo vtable per un tipo Rust in cemento che
        // è noto per avere un layout valido.Stessa logica di `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Impls manuali necessari per evitare i limiti `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}