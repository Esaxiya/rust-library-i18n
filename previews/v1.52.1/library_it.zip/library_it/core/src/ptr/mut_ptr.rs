use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Restituisce `true` se il puntatore è nullo.
    ///
    /// Si noti che i tipi non dimensionati hanno molti possibili puntatori nulli, poiché viene considerato solo il puntatore ai dati grezzi, non la loro lunghezza, vtable, ecc.
    /// Pertanto, due puntatori nulli potrebbero non essere uguali tra loro.
    ///
    /// ## Comportamento durante la valutazione const
    ///
    /// Quando questa funzione viene utilizzata durante la valutazione const, può restituire `false` per i puntatori che risultano essere nulli in fase di esecuzione.
    /// In particolare, quando un puntatore a una certa memoria viene spostato oltre i suoi limiti in modo tale che il puntatore risultante sia nullo, la funzione restituirà comunque `false`.
    ///
    /// Non c'è modo per CTFE di conoscere la posizione assoluta di quella memoria, quindi non possiamo dire se il puntatore è nullo o meno.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Confronta tramite un cast con un puntatore sottile, quindi i puntatori grossi considerano solo la loro parte "data" per nullità.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Trasmette a un puntatore di un altro tipo.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Decompone un puntatore (possibilmente largo) nei componenti dell'indirizzo e dei metadati.
    ///
    /// Il puntatore può essere successivamente ricostruito con [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce un riferimento condiviso al valore racchiuso in `Some`.Se il valore può non essere inizializzato, è necessario utilizzare [`as_uninit_ref`].
    ///
    /// Per la controparte mutevole vedere [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * Il puntatore deve puntare a un'istanza inizializzata di `T`.
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    /// (La parte relativa all'inizializzazione non è ancora completamente decisa, ma fino a quando non lo è, l'unico approccio sicuro è assicurarsi che siano effettivamente inizializzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Versione non selezionata
    ///
    /// Se sei sicuro che il puntatore non possa mai essere nullo e stai cercando un qualche tipo di `as_ref_unchecked` che restituisca `&T` invece di `Option<&T>`, sappi che puoi dereferenziare direttamente il puntatore.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SICUREZZA: il chiamante deve garantire che `self` è valido per un file
        // riferimento se non è nullo.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce un riferimento condiviso al valore racchiuso in `Some`.
    /// A differenza di [`as_ref`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte mutevole vedere [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Calcola l'offset da un puntatore.
    ///
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Se una delle seguenti condizioni viene violata, il risultato è un comportamento indefinito:
    ///
    /// * Sia il puntatore iniziale che quello risultante devono trovarsi nei limiti o un byte oltre la fine dello stesso oggetto allocato.
    /// Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// * L'offset calcolato,**in byte**, non può superare un `isize`.
    ///
    /// * L'offset che è nei limiti non può fare affidamento su "wrapping around" lo spazio degli indirizzi.Cioè, la somma a precisione infinita,**in byte**, deve rientrare in una dimensione.
    ///
    /// Il compilatore e la libreria standard generalmente cercano di garantire che le allocazioni non raggiungano mai una dimensione in cui un offset è un problema.
    /// Ad esempio, `Vec` e `Box` assicurano di non allocare mai più di `isize::MAX` byte, quindi `vec.as_ptr().add(vec.len())` è sempre sicuro.
    ///
    /// La maggior parte delle piattaforme fondamentalmente non può nemmeno costruire una simile allocazione.
    /// Ad esempio, nessuna piattaforma a 64 bit nota potrà mai servire una richiesta di 2 <sup>63</sup> byte a causa delle limitazioni della tabella delle pagine o della suddivisione dello spazio degli indirizzi.
    /// Tuttavia, alcune piattaforme a 32 e 16 bit possono servire correttamente una richiesta per più di `isize::MAX` byte con cose come l'estensione dell'indirizzo fisico.
    ///
    /// In quanto tale, la memoria acquisita direttamente dagli allocatori o dai file mappati in memoria *potrebbe* essere troppo grande per essere gestita con questa funzione.
    ///
    /// Considerare invece l'utilizzo di [`wrapping_offset`] se questi vincoli sono difficili da soddisfare.
    /// L'unico vantaggio di questo metodo è che consente ottimizzazioni del compilatore più aggressive.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `offset`.
        // Il puntatore ottenuto è valido per le scritture poiché il chiamante deve garantire che punti allo stesso oggetto allocato di `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Calcola l'offset da un puntatore utilizzando l'aritmetica di avvolgimento.
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Questa stessa operazione è sempre sicura, ma l'uso del puntatore risultante non lo è.
    ///
    /// Il puntatore risultante rimane collegato allo stesso oggetto allocato a cui punta `self`.
    /// *Non* può essere utilizzato per accedere a un oggetto allocato diverso.Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// In altre parole, `let z = x.wrapping_offset((y as isize) - (x as isize))`*non* rende `z` uguale a `y` anche se assumiamo che `T` abbia dimensione `1` e non vi sia overflow: `z` è ancora attaccato all'oggetto a cui `x` è attaccato, e dereferenziarlo è un comportamento indefinito a meno che `x` e Punto `y` nello stesso oggetto allocato.
    ///
    /// Rispetto a [`offset`], questo metodo sostanzialmente ritarda la necessità di rimanere all'interno dello stesso oggetto allocato: [`offset`] è un comportamento indefinito immediato quando si attraversano i confini dell'oggetto;`wrapping_offset` produce un puntatore ma porta comunque a un comportamento indefinito se un puntatore viene dereferenziato quando è fuori dai limiti dell'oggetto a cui è collegato.
    /// [`offset`] può essere ottimizzato meglio ed è quindi preferibile nel codice sensibile alle prestazioni.
    ///
    /// Il controllo ritardato considera solo il valore del puntatore che è stato dereferenziato, non i valori intermedi utilizzati durante il calcolo del risultato finale.
    /// Ad esempio, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` è sempre uguale a `x`.In altre parole, è consentito lasciare l'oggetto allocato e quindi reinserirlo in un secondo momento.
    ///
    /// Se hai bisogno di oltrepassare i confini degli oggetti, lancia il puntatore su un numero intero e calcola lì.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // Itera utilizzando un puntatore non elaborato in incrementi di due elementi
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // SICUREZZA: l'intrinseco `arith_offset` non ha prerequisiti per essere chiamato.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce un riferimento univoco al valore racchiuso in `Some`.Se il valore può non essere inizializzato, è necessario utilizzare [`as_uninit_mut`].
    ///
    /// Per la controparte condivisa vedere [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * Il puntatore deve puntare a un'istanza inizializzata di `T`.
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    /// (La parte relativa all'inizializzazione non è ancora completamente decisa, ma fino a quando non lo è, l'unico approccio sicuro è assicurarsi che siano effettivamente inizializzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Stamperà: "[4, 2, 3]".
    /// ```
    ///
    /// # Versione non selezionata
    ///
    /// Se sei sicuro che il puntatore non possa mai essere nullo e stai cercando un qualche tipo di `as_mut_unchecked` che restituisca `&mut T` invece di `Option<&mut T>`, sappi che puoi dereferenziare direttamente il puntatore.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Stamperà: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // SICUREZZA: il chiamante deve garantire che `self` sia valido per
        // un riferimento modificabile se non è nullo.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce un riferimento univoco al valore racchiuso in `Some`.
    /// A differenza di [`as_mut`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte condivisa vedere [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Restituisce se due puntatori sono garantiti per essere uguali.
    ///
    /// In fase di esecuzione questa funzione si comporta come `self == other`.
    /// Tuttavia, in alcuni contesti (ad esempio, la valutazione in fase di compilazione), non è sempre possibile determinare l'uguaglianza di due puntatori, quindi questa funzione può restituire erroneamente `false` per puntatori che successivamente risultano effettivamente uguali.
    ///
    /// Ma quando restituisce `true`, è garantito che i puntatori siano uguali.
    ///
    /// Questa funzione è il mirror di [`guaranteed_ne`], ma non il suo inverso.Esistono confronti di puntatori per i quali entrambe le funzioni restituiscono `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Il valore restituito può cambiare a seconda della versione del compilatore e il codice non sicuro potrebbe non fare affidamento sul risultato di questa funzione per la solidità.
    /// Si consiglia di utilizzare questa funzione solo per l'ottimizzazione delle prestazioni in cui i valori restituiti da `false` spuri da questa funzione non influiscono sul risultato, ma solo sulle prestazioni.
    /// Le conseguenze dell'utilizzo di questo metodo per fare in modo che il codice in fase di esecuzione e in fase di compilazione si comportino diversamente non sono state esplorate.
    /// Questo metodo non dovrebbe essere utilizzato per introdurre tali differenze e non dovrebbe nemmeno essere stabilizzato prima di avere una migliore comprensione di questo problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Restituisce se è garantito che due puntatori siano disuguali.
    ///
    /// In fase di esecuzione questa funzione si comporta come `self != other`.
    /// Tuttavia, in alcuni contesti (ad esempio, la valutazione in fase di compilazione), non è sempre possibile determinare la disuguaglianza di due puntatori, quindi questa funzione potrebbe restituire falsamente `false` per i puntatori che successivamente si rivelano effettivamente disuguali.
    ///
    /// Ma quando restituisce `true`, è garantito che i puntatori non siano uguali.
    ///
    /// Questa funzione è il mirror di [`guaranteed_eq`], ma non il suo inverso.Esistono confronti di puntatori per i quali entrambe le funzioni restituiscono `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Il valore restituito può cambiare a seconda della versione del compilatore e il codice non sicuro potrebbe non fare affidamento sul risultato di questa funzione per la solidità.
    /// Si consiglia di utilizzare questa funzione solo per l'ottimizzazione delle prestazioni in cui i valori restituiti da `false` spuri da questa funzione non influiscono sul risultato, ma solo sulle prestazioni.
    /// Le conseguenze dell'utilizzo di questo metodo per fare in modo che il codice in fase di esecuzione e in fase di compilazione si comportino diversamente non sono state esplorate.
    /// Questo metodo non dovrebbe essere utilizzato per introdurre tali differenze e non dovrebbe nemmeno essere stabilizzato prima di avere una migliore comprensione di questo problema.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Calcola la distanza tra due puntatori.Il valore restituito è in unità di T: la distanza in byte viene divisa per `mem::size_of::<T>()`.
    ///
    /// Questa funzione è l'inverso di [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Se una delle seguenti condizioni viene violata, il risultato è un comportamento indefinito:
    ///
    /// * Sia il puntatore iniziale che l'altro devono trovarsi nei limiti o un byte oltre la fine dello stesso oggetto allocato.
    /// Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// * Entrambi i puntatori devono essere *derivati da* un puntatore allo stesso oggetto.
    ///   (Vedi sotto per un esempio.)
    ///
    /// * La distanza tra i puntatori, in byte, deve essere un multiplo esatto della dimensione di `T`.
    ///
    /// * La distanza tra i puntatori,**in byte**, non può superare un `isize`.
    ///
    /// * La distanza che è nei limiti non può fare affidamento su "wrapping around" lo spazio degli indirizzi.
    ///
    /// I tipi Rust non sono mai più grandi di `isize::MAX` e le allocazioni Rust non vanno mai a capo dello spazio degli indirizzi, quindi due puntatori all'interno di un valore di qualsiasi tipo Rust `T` soddisferanno sempre le ultime due condizioni.
    ///
    /// La libreria standard garantisce inoltre generalmente che le allocazioni non raggiungano mai una dimensione in cui un offset è un problema.
    /// Ad esempio, `Vec` e `Box` assicurano di non allocare mai più di `isize::MAX` byte, quindi `ptr_into_vec.offset_from(vec.as_ptr())` soddisfa sempre le ultime due condizioni.
    ///
    /// La maggior parte delle piattaforme fondamentalmente non può nemmeno costruire un'allocazione così ampia.
    /// Ad esempio, nessuna piattaforma a 64 bit nota potrà mai servire una richiesta di 2 <sup>63</sup> byte a causa delle limitazioni della tabella delle pagine o della suddivisione dello spazio degli indirizzi.
    /// Tuttavia, alcune piattaforme a 32 e 16 bit possono servire correttamente una richiesta per più di `isize::MAX` byte con cose come l'estensione dell'indirizzo fisico.
    /// In quanto tale, la memoria acquisita direttamente dagli allocatori o dai file mappati in memoria *potrebbe* essere troppo grande per essere gestita con questa funzione.
    /// (Si noti che [`offset`] e [`add`] hanno anche una limitazione simile e quindi non possono essere utilizzati nemmeno su allocazioni così grandi.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Questa funzione panics se `T` è un tipo ("ZST") di dimensioni zero.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Utilizzo errato*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Rendi ptr2_other un "alias" di ptr2, ma derivato da ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Poiché ptr2_other e ptr2 derivano da puntatori a oggetti diversi, calcolare il loro offset è un comportamento indefinito, anche se puntano allo stesso indirizzo!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Comportamento indefinito
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Calcola l'offset da un puntatore (comodità per `.offset(count as isize)`).
    ///
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Se una delle seguenti condizioni viene violata, il risultato è un comportamento indefinito:
    ///
    /// * Sia il puntatore iniziale che quello risultante devono trovarsi nei limiti o un byte oltre la fine dello stesso oggetto allocato.
    /// Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// * L'offset calcolato,**in byte**, non può superare un `isize`.
    ///
    /// * L'offset che si trova nei limiti non può fare affidamento su "wrapping around" nello spazio degli indirizzi.Cioè, la somma a precisione infinita deve essere contenuta in un `usize`.
    ///
    /// Il compilatore e la libreria standard generalmente cercano di garantire che le allocazioni non raggiungano mai una dimensione in cui un offset è un problema.
    /// Ad esempio, `Vec` e `Box` assicurano di non allocare mai più di `isize::MAX` byte, quindi `vec.as_ptr().add(vec.len())` è sempre sicuro.
    ///
    /// La maggior parte delle piattaforme fondamentalmente non può nemmeno costruire una simile allocazione.
    /// Ad esempio, nessuna piattaforma a 64 bit nota potrà mai servire una richiesta di 2 <sup>63</sup> byte a causa delle limitazioni della tabella delle pagine o della suddivisione dello spazio degli indirizzi.
    /// Tuttavia, alcune piattaforme a 32 e 16 bit possono servire correttamente una richiesta per più di `isize::MAX` byte con cose come l'estensione dell'indirizzo fisico.
    ///
    /// In quanto tale, la memoria acquisita direttamente dagli allocatori o dai file mappati in memoria *potrebbe* essere troppo grande per essere gestita con questa funzione.
    ///
    /// Considerare invece l'utilizzo di [`wrapping_add`] se questi vincoli sono difficili da soddisfare.
    /// L'unico vantaggio di questo metodo è che consente ottimizzazioni del compilatore più aggressive.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Calcola l'offset da un puntatore (comodo per `.offset ((conta come isize).wrapping_neg())`).
    ///
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Se una delle seguenti condizioni viene violata, il risultato è un comportamento indefinito:
    ///
    /// * Sia il puntatore iniziale che quello risultante devono trovarsi nei limiti o un byte oltre la fine dello stesso oggetto allocato.
    /// Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// * L'offset calcolato non può superare `isize::MAX`**byte**.
    ///
    /// * L'offset che è nei limiti non può fare affidamento su "wrapping around" lo spazio degli indirizzi.Cioè, la somma a precisione infinita deve rientrare in una dimensione.
    ///
    /// Il compilatore e la libreria standard generalmente cercano di garantire che le allocazioni non raggiungano mai una dimensione in cui un offset è un problema.
    /// Ad esempio, `Vec` e `Box` assicurano di non allocare mai più di `isize::MAX` byte, quindi `vec.as_ptr().add(vec.len()).sub(vec.len())` è sempre sicuro.
    ///
    /// La maggior parte delle piattaforme fondamentalmente non può nemmeno costruire una simile allocazione.
    /// Ad esempio, nessuna piattaforma a 64 bit nota potrà mai servire una richiesta di 2 <sup>63</sup> byte a causa delle limitazioni della tabella delle pagine o della suddivisione dello spazio degli indirizzi.
    /// Tuttavia, alcune piattaforme a 32 e 16 bit possono servire correttamente una richiesta per più di `isize::MAX` byte con cose come l'estensione dell'indirizzo fisico.
    ///
    /// In quanto tale, la memoria acquisita direttamente dagli allocatori o dai file mappati in memoria *potrebbe* essere troppo grande per essere gestita con questa funzione.
    ///
    /// Considerare invece l'utilizzo di [`wrapping_sub`] se questi vincoli sono difficili da soddisfare.
    /// L'unico vantaggio di questo metodo è che consente ottimizzazioni del compilatore più aggressive.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Calcola l'offset da un puntatore utilizzando l'aritmetica di avvolgimento.
    /// (comodità per `.wrapping_offset(count as isize)`)
    ///
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Questa stessa operazione è sempre sicura, ma l'uso del puntatore risultante non lo è.
    ///
    /// Il puntatore risultante rimane collegato allo stesso oggetto allocato a cui punta `self`.
    /// *Non* può essere utilizzato per accedere a un oggetto allocato diverso.Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// In altre parole, `let z = x.wrapping_add((y as usize) - (x as usize))`*non* rende `z` uguale a `y` anche se assumiamo che `T` abbia dimensione `1` e non vi sia overflow: `z` è ancora attaccato all'oggetto a cui `x` è attaccato, e dereferenziarlo è un comportamento indefinito a meno che `x` e Punto `y` nello stesso oggetto allocato.
    ///
    /// Rispetto a [`add`], questo metodo sostanzialmente ritarda la necessità di rimanere all'interno dello stesso oggetto allocato: [`add`] è un comportamento indefinito immediato quando si attraversano i confini dell'oggetto;`wrapping_add` produce un puntatore ma porta comunque a un comportamento indefinito se un puntatore viene dereferenziato quando è fuori dai limiti dell'oggetto a cui è collegato.
    /// [`add`] può essere ottimizzato meglio ed è quindi preferibile nel codice sensibile alle prestazioni.
    ///
    /// Il controllo ritardato considera solo il valore del puntatore che è stato dereferenziato, non i valori intermedi utilizzati durante il calcolo del risultato finale.
    /// Ad esempio, `x.wrapping_add(o).wrapping_sub(o)` è sempre uguale a `x`.In altre parole, è consentito lasciare l'oggetto allocato e quindi reinserirlo in un secondo momento.
    ///
    /// Se hai bisogno di oltrepassare i confini degli oggetti, lancia il puntatore su un numero intero e calcola lì.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // Itera utilizzando un puntatore non elaborato in incrementi di due elementi
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Questo ciclo stampa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Calcola l'offset da un puntatore utilizzando l'aritmetica di avvolgimento.
    /// (convenienza per `.wrapping_offset ((conta come isize).wrapping_neg())`)
    ///
    /// `count` è in unità di T;ad esempio, un `count` di 3 rappresenta un offset del puntatore di `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Questa stessa operazione è sempre sicura, ma l'uso del puntatore risultante non lo è.
    ///
    /// Il puntatore risultante rimane collegato allo stesso oggetto allocato a cui punta `self`.
    /// *Non* può essere utilizzato per accedere a un oggetto allocato diverso.Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
    ///
    /// In altre parole, `let z = x.wrapping_sub((x as usize) - (y as usize))`*non* rende `z` uguale a `y` anche se assumiamo che `T` abbia dimensione `1` e non vi sia overflow: `z` è ancora attaccato all'oggetto a cui `x` è attaccato, e dereferenziarlo è un comportamento indefinito a meno che `x` e Punto `y` nello stesso oggetto allocato.
    ///
    /// Rispetto a [`sub`], questo metodo sostanzialmente ritarda la necessità di rimanere all'interno dello stesso oggetto allocato: [`sub`] è un comportamento indefinito immediato quando si attraversano i confini dell'oggetto;`wrapping_sub` produce un puntatore ma porta comunque a un comportamento indefinito se un puntatore viene dereferenziato quando è fuori dai limiti dell'oggetto a cui è collegato.
    /// [`sub`] può essere ottimizzato meglio ed è quindi preferibile nel codice sensibile alle prestazioni.
    ///
    /// Il controllo ritardato considera solo il valore del puntatore che è stato dereferenziato, non i valori intermedi utilizzati durante il calcolo del risultato finale.
    /// Ad esempio, `x.wrapping_add(o).wrapping_sub(o)` è sempre uguale a `x`.In altre parole, è consentito lasciare l'oggetto allocato e quindi reinserirlo in un secondo momento.
    ///
    /// Se hai bisogno di oltrepassare i confini degli oggetti, lancia il puntatore su un numero intero e calcola lì.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// // Itera utilizzando un puntatore non elaborato in incrementi di due elementi (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Questo ciclo stampa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Imposta il valore del puntatore su `ptr`.
    ///
    /// Nel caso in cui `self` sia un puntatore (fat) a un tipo non dimensionato, questa operazione interesserà solo la parte del puntatore, mentre per i puntatori (thin) a tipi dimensionati, ha lo stesso effetto di una semplice assegnazione.
    ///
    /// Il puntatore risultante avrà la provenienza di `val`, ovvero, per un puntatore grasso, questa operazione è semanticamente uguale alla creazione di un nuovo puntatore grasso con il valore del puntatore dati di `val` ma con i metadati di `self`.
    ///
    ///
    /// # Examples
    ///
    /// Questa funzione è utile principalmente per consentire l'aritmetica del puntatore byte-wise su puntatori potenzialmente fat:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // stamperà "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // SICUREZZA: Nel caso di un puntatore sottile, questa operazione è identica
        // a un semplice incarico.
        // In caso di un puntatore grasso, con l'attuale implementazione del layout del puntatore grasso, il primo campo di tale puntatore è sempre il puntatore dati, che viene assegnato allo stesso modo.
        //
        unsafe { *thin = val };
        self
    }

    /// Legge il valore da `self` senza spostarlo.
    /// Ciò lascia la memoria in `self` invariata.
    ///
    /// Vedere [`ptr::read`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per ``.
        unsafe { read(self) }
    }

    /// Esegue una lettura volatile del valore da `self` senza spostarlo.Ciò lascia la memoria in `self` invariata.
    ///
    /// Le operazioni volatili hanno lo scopo di agire sulla memoria I/O e si garantisce che non vengano elise o riordinate dal compilatore attraverso altre operazioni volatili.
    ///
    ///
    /// Vedere [`ptr::read_volatile`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Legge il valore da `self` senza spostarlo.
    /// Ciò lascia la memoria in `self` invariata.
    ///
    /// A differenza di `read`, il puntatore potrebbe non essere allineato.
    ///
    /// Vedere [`ptr::read_unaligned`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Copia i byte `count * size_of<T>` da `self` a `dest`.
    /// L'origine e la destinazione potrebbero sovrapporsi.
    ///
    /// NOTE: questo ha lo *stesso* ordine degli argomenti di [`ptr::copy`].
    ///
    /// Vedere [`ptr::copy`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Copia i byte `count * size_of<T>` da `self` a `dest`.
    /// L'origine e la destinazione possono *non* sovrapporsi.
    ///
    /// NOTE: questo ha lo *stesso* ordine degli argomenti di [`ptr::copy_nonoverlapping`].
    ///
    /// Vedere [`ptr::copy_nonoverlapping`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Copia i byte `count * size_of<T>` da `src` a `self`.
    /// L'origine e la destinazione potrebbero sovrapporsi.
    ///
    /// NOTE: questo ha l'ordine degli argomenti *opposto* di [`ptr::copy`].
    ///
    /// Vedere [`ptr::copy`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Copia i byte `count * size_of<T>` da `src` a `self`.
    /// L'origine e la destinazione possono *non* sovrapporsi.
    ///
    /// NOTE: questo ha l'ordine degli argomenti *opposto* di [`ptr::copy_nonoverlapping`].
    ///
    /// Vedere [`ptr::copy_nonoverlapping`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Esegue il distruttore (se presente) del valore puntato.
    ///
    /// Vedere [`ptr::drop_in_place`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Sovrascrive una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
    ///
    ///
    /// Vedere [`ptr::write`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `write`.
        unsafe { write(self, val) }
    }

    /// Richiama memset sul puntatore specificato, impostando `count * size_of::<T>()` byte di memoria a partire da `self` su `val`.
    ///
    ///
    /// Vedere [`ptr::write_bytes`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Esegue una scrittura volatile di una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
    ///
    /// Le operazioni volatili hanno lo scopo di agire sulla memoria I/O e si garantisce che non vengano elise o riordinate dal compilatore attraverso altre operazioni volatili.
    ///
    ///
    /// Vedere [`ptr::write_volatile`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Sovrascrive una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
    ///
    ///
    /// A differenza di `write`, il puntatore potrebbe non essere allineato.
    ///
    /// Vedere [`ptr::write_unaligned`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Sostituisce il valore in `self` con `src`, restituendo il vecchio valore, senza rilasciarne neanche uno.
    ///
    ///
    /// Vedere [`ptr::replace`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `replace`.
        unsafe { replace(self, src) }
    }

    /// Scambia i valori in due posizioni mutabili dello stesso tipo, senza deinizializzarne neanche uno.
    /// Possono sovrapporsi, a differenza di `mem::swap` che è altrimenti equivalente.
    ///
    /// Vedere [`ptr::swap`] per problemi di sicurezza ed esempi.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `swap`.
        unsafe { swap(self, with) }
    }

    /// Calcola l'offset che deve essere applicato al puntatore per renderlo allineato a `align`.
    ///
    /// Se non è possibile allineare il puntatore, l'implementazione restituisce `usize::MAX`.
    /// È consentito che l'implementazione restituisca *sempre*`usize::MAX`.
    /// Solo le prestazioni del tuo algoritmo possono dipendere dall'ottenimento di un offset utilizzabile qui, non dalla sua correttezza.
    ///
    /// L'offset è espresso in numero di elementi `T` e non in byte.Il valore restituito può essere utilizzato con il metodo `wrapping_add`.
    ///
    /// Non ci sono garanzie di sorta che l'offset del puntatore non trabocchi o vada oltre l'allocazione a cui punta il puntatore.
    ///
    /// Spetta al chiamante assicurarsi che l'offset restituito sia corretto in tutti i termini diversi dall'allineamento.
    ///
    /// # Panics
    ///
    /// La funzione panics se `align` non è una potenza di due.
    ///
    /// # Examples
    ///
    /// Accesso a `u8` adiacente come `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mentre il puntatore può essere allineato tramite `offset`, punta all'esterno dell'allocazione
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SICUREZZA: `align` è stato verificato per essere una potenza di 2 sopra
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Restituisce la lunghezza di una fetta grezza.
    ///
    /// Il valore restituito è il numero di **elementi**, non il numero di byte.
    ///
    /// Questa funzione è sicura, anche quando non è possibile eseguire il cast della sezione grezza su un riferimento a una sezione perché il puntatore è nullo o non allineato.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICUREZZA: questo è sicuro perché `*const [T]` e `FatPtr<T>` hanno lo stesso layout.
            // Solo `std` può fornire questa garanzia.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Restituisce un puntatore non elaborato al buffer della fetta.
    ///
    /// Ciò equivale a trasmettere da `self` a `*mut T`, ma più indipendente dai tipi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Restituisce un puntatore non elaborato a un elemento o una sottosezione, senza eseguire il controllo dei limiti.
    ///
    /// Chiamare questo metodo con un indice fuori limite o quando `self` non è dereferenziabile è *[comportamento undefined]* anche se il puntatore risultante non viene utilizzato.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SICUREZZA: il chiamante garantisce che `self` sia dereferenziabile e `index` in-bound.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce una fetta condivisa al valore racchiuso in `Some`.
    /// A differenza di [`as_ref`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte mutevole vedere [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere [valid] per le letture per `ptr.len() * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
    ///
    ///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
    ///       Le sezioni non possono mai estendersi su più oggetti allocati.
    ///
    ///     * Il puntatore deve essere allineato anche per le sezioni di lunghezza zero.
    ///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
    ///
    ///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
    ///
    /// * La dimensione totale `ptr.len() * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
    ///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// Vedi anche [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Restituisce `None` se il puntatore è nullo, oppure restituisce una fetta univoca al valore racchiuso in `Some`.
    /// A differenza di [`as_mut`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte condivisa vedere [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Quando si chiama questo metodo, è necessario assicurarsi che *o* il puntatore sia NULL *o* tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere [valid] per le letture e le scritture per `ptr.len() * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
    ///
    ///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
    ///       Le sezioni non possono mai estendersi su più oggetti allocati.
    ///
    ///     * Il puntatore deve essere allineato anche per le sezioni di lunghezza zero.
    ///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
    ///
    ///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
    ///
    /// * La dimensione totale `ptr.len() * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
    ///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// Vedi anche [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Uguaglianza per i puntatori
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}