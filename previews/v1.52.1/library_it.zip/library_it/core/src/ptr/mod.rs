//! Gestisci manualmente la memoria tramite puntatori non elaborati.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Molte funzioni in questo modulo accettano puntatori non elaborati come argomenti e leggono o scrivono su di essi.Affinché ciò sia sicuro, questi puntatori devono essere *validi*.
//! La validità di un puntatore dipende dall'operazione per la quale viene utilizzato (lettura o scrittura) e dall'estensione della memoria a cui si accede (ovvero, quanti byte sono read/written).
//! La maggior parte delle funzioni utilizza `*mut T` e `* const T` per accedere a un solo valore, nel qual caso la documentazione omette la dimensione e presuppone implicitamente che sia `size_of::<T>()` byte.
//!
//! Le regole precise per la validità non sono ancora state determinate.Le garanzie che vengono fornite a questo punto sono davvero minime:
//!
//! * Un puntatore [null] non è *mai* valido, nemmeno per gli accessi di [size zero][zst].
//! * Affinché un puntatore sia valido, è necessario, ma non sempre sufficiente, che il puntatore sia *dereferenziabile*: l'intervallo di memoria della dimensione data a partire dal puntatore deve essere tutto all'interno dei limiti di un singolo oggetto allocato.
//!
//! Notare che in Rust, ogni variabile (stack-allocated) è considerata un oggetto allocato separato.
//! * Anche per le operazioni di [size zero][zst], il puntatore non deve puntare alla memoria deallocata, ovvero, la deallocazione rende i puntatori non validi anche per operazioni di dimensione zero.
//! Tuttavia, il cast di qualsiasi numero intero diverso da zero *letterale* a un puntatore è valido per gli accessi di dimensione zero, anche se una certa memoria esiste a quell'indirizzo e viene deallocata.
//! Ciò corrisponde alla scrittura del proprio allocatore: allocare oggetti di dimensione zero non è molto difficile.
//! Il modo canonico per ottenere un puntatore valido per accessi di dimensione zero è [`NonNull::dangling`].
//! * Tutti gli accessi eseguiti dalle funzioni in questo modulo sono *non atomici* nel senso di [atomic operations] utilizzato per la sincronizzazione tra i thread.
//! Ciò significa che è un comportamento indefinito eseguire due accessi simultanei alla stessa posizione da thread diversi a meno che entrambi accedano solo in lettura dalla memoria.
//! Si noti che questo include esplicitamente [`read_volatile`] e [`write_volatile`]: gli accessi volatili non possono essere utilizzati per la sincronizzazione tra thread.
//! * Il risultato del cast di un riferimento a un puntatore è valido fintanto che l'oggetto sottostante è attivo e nessun riferimento (solo puntatori non elaborati) viene utilizzato per accedere alla stessa memoria.
//!
//! Questi assiomi, insieme a un uso attento di [`offset`] per l'aritmetica dei puntatori, sono sufficienti per implementare correttamente molte cose utili in codice non sicuro.
//! Alla fine verranno fornite garanzie più forti, poiché le regole di [aliasing] sono in fase di definizione.
//! Per ulteriori informazioni, vedere [book] e la sezione nel riferimento dedicata a [undefined behavior][ub].
//!
//! ## Alignment
//!
//! I puntatori grezzi validi come definiti sopra non sono necessariamente allineati correttamente (dove l'allineamento "proper" è definito dal tipo di punta, cioè, `*const T` deve essere allineato a `mem::align_of::<T>()`).
//! Tuttavia, la maggior parte delle funzioni richiede che i propri argomenti siano allineati correttamente e dichiareranno esplicitamente questo requisito nella loro documentazione.
//! Notevoli eccezioni a questo sono [`read_unaligned`] e [`write_unaligned`].
//!
//! Quando una funzione richiede un allineamento appropriato, lo fa anche se l'accesso ha dimensione 0, cioè anche se la memoria non viene effettivamente toccata.Considera l'utilizzo di [`NonNull::dangling`] in questi casi.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Esegue il distruttore (se presente) del valore puntato.
///
/// Questo è semanticamente equivalente a chiamare [`ptr::read`] e scartare il risultato, ma presenta i seguenti vantaggi:
///
/// * È *obbligatorio* usare `drop_in_place` per eliminare tipi non dimensionati come oggetti trait, perché non possono essere letti nello stack e rilasciati normalmente.
///
/// * È più amichevole per l'ottimizzatore farlo su [`ptr::read`] quando rilascia memoria allocata manualmente (ad esempio, nelle implementazioni di `Box`/`Rc`/`Vec`), poiché il compilatore non ha bisogno di dimostrare che è corretto elide la copia.
///
///
/// * Può essere utilizzato per eliminare i dati [pinned] quando `T` non è `repr(packed)` (i dati bloccati non devono essere spostati prima di essere rilasciati).
///
/// I valori non allineati non possono essere rilasciati in posizione, devono essere prima copiati in una posizione allineata utilizzando [`ptr::read_unaligned`].Per gli struct compressi, questa mossa viene eseguita automaticamente dal compilatore.
/// Ciò significa che i campi degli struct compressi non vengono rilasciati sul posto.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `to_drop` deve essere [valid] sia per le letture che per le scritture.
///
/// * `to_drop` deve essere correttamente allineato.
///
/// * Il valore a cui punta `to_drop` deve essere valido per l'eliminazione, il che può significare che deve sostenere invarianti aggiuntive, questo dipende dal tipo.
///
/// Inoltre, se `T` non è [`Copy`], l'utilizzo del valore puntato dopo aver chiamato `drop_in_place` può causare un comportamento indefinito.Notare che `*to_drop = foo` conta come un utilizzo perché farà cadere nuovamente il valore.
/// [`write()`] può essere utilizzato per sovrascrivere i dati senza provocarne l'eliminazione.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Rimuovi manualmente l'ultimo elemento da un vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Ottieni un puntatore grezzo all'ultimo elemento in `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Accorcia `v` per evitare che l'ultimo oggetto venga lasciato cadere.
///     // Lo facciamo prima, per evitare problemi se l `drop_in_place` sotto panics.
///     v.set_len(1);
///     // Senza una chiamata `drop_in_place`, l'ultimo elemento non verrebbe mai eliminato e la memoria che gestisce sarebbe trapelata.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Assicurati che l'ultimo elemento sia stato eliminato.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Si noti che il compilatore esegue questa copia automaticamente quando rilascia gli struct compressi, cioè, di solito non devi preoccuparti di tali problemi a meno che tu non chiami `drop_in_place` manualmente.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Il codice qui non ha importanza, questo è sostituito dalla vera colla a goccia del compilatore.
    //

    // SICUREZZA: vedi commento sopra
    unsafe { drop_in_place(to_drop) }
}

/// Crea un puntatore non elaborato nullo.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Crea un puntatore raw mutabile null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// L'impianto manuale necessario per evitare il vincolo `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// L'impianto manuale necessario per evitare il vincolo `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Forma una fetta grezza da un puntatore e una lunghezza.
///
/// L'argomento `len` è il numero di **elementi**, non il numero di byte.
///
/// Questa funzione è sicura, ma l'utilizzo del valore restituito non è sicuro.
/// Vedere la documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza degli slice.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // creare un puntatore di fetta quando si inizia con un puntatore al primo elemento
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SICUREZZA: l'accesso al valore dall'unione `Repr` è sicuro poiché * const [T]
        //
        // e FatPtr hanno gli stessi layout di memoria.Solo std può fornire questa garanzia.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Esegue la stessa funzionalità di [`slice_from_raw_parts`], tranne per il fatto che viene restituita una slice modificabile non elaborata, invece di una slice non modificabile non modificata.
///
///
/// Vedere la documentazione di [`slice_from_raw_parts`] per maggiori dettagli.
///
/// Questa funzione è sicura, ma l'utilizzo del valore restituito non è sicuro.
/// Vedere la documentazione di [`slice::from_raw_parts_mut`] per i requisiti di sicurezza degli slice.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assegna un valore a un indice nella sezione
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SICUREZZA: l'accesso al valore dall'unione `Repr` è sicuro poiché * mut [T]
        // e FatPtr hanno gli stessi layout di memoria
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Scambia i valori in due posizioni mutabili dello stesso tipo, senza deinizializzarne neanche uno.
///
/// Ma per le seguenti due eccezioni, questa funzione è semanticamente equivalente a [`mem::swap`]:
///
///
/// * Funziona su puntatori non elaborati invece che su riferimenti.
/// Quando i riferimenti sono disponibili, [`mem::swap`] dovrebbe essere preferito.
///
/// * I due valori puntati possono sovrapporsi.
/// Se i valori si sovrappongono, verrà utilizzata la regione di memoria sovrapposta da `x`.
/// Ciò è dimostrato nel secondo esempio di seguito.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * Sia `x` che `y` devono essere [valid] sia per le letture che per le scritture.
///
/// * Sia `x` che `y` devono essere allineati correttamente.
///
/// Notare che anche se `T` ha dimensione `0`, i puntatori devono essere non NULL e correttamente allineati.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Scambio di due regioni non sovrapposte:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // questo è `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // questo è `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Scambio di due regioni sovrapposte:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // questo è `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // questo è `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Gli indici `1..3` dello slice si sovrappongono tra `x` e `y`.
///     // Risultati ragionevoli sarebbero per loro `[2, 3]`, in modo che gli indici `0..3` siano `[1, 2, 3]` (corrispondenti a `y` prima di `swap`);o che siano `[0, 1]` in modo che gli indici `1..4` siano `[0, 1, 2]` (corrispondenti a `x` prima di `swap`).
/////
///     // Questa implementazione è definita per fare la seconda scelta.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dacci un po 'di spazio per lavorare con i graffi.
    // Non dobbiamo preoccuparci delle cadute: `MaybeUninit` non fa nulla quando viene lasciato cadere.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Eseguire lo swap in SICUREZZA: il chiamante deve garantire che `x` e `y` siano validi per le scritture e correttamente allineati.
    // `tmp` non può essere sovrapposto a `x` o `y` perché `tmp` è stato semplicemente allocato sullo stack come oggetto allocato separato.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` e `y` potrebbero sovrapporsi
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Scambia i byte `count * size_of::<T>()` tra le due regioni di memoria a partire da `x` e `y`.
/// Le due regioni *non* devono sovrapporsi.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * Sia `x` che `y` devono essere [valid] sia per le letture che per le scritture di `count *
///   taglia di: :<T>() `byte.
///
/// * Sia `x` che `y` devono essere allineati correttamente.
///
/// * La regione di memoria che inizia da `x` con una dimensione di `count *
///   taglia di: :<T>() `byte non devono *non* sovrapporsi alla regione di memoria che inizia a `y` con la stessa dimensione.
///
/// Nota che anche se la dimensione effettivamente copiata (`count * size_of: :<T>()`) è `0`, i puntatori devono essere non NULL e correttamente allineati.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SICUREZZA: il chiamante deve garantire che `x` e `y` lo siano
    // valido per le scritture e correttamente allineato.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Per i tipi più piccoli dell'ottimizzazione del blocco di seguito, basta scambiare direttamente per evitare di pessimizzare il codegen.
    //
    if mem::size_of::<T>() < 32 {
        // SICUREZZA: il chiamante deve garantire che `x` e `y` siano validi
        // per le scritture, correttamente allineate e non sovrapposte.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // L'approccio qui consiste nell'utilizzare simd per scambiare x&y in modo efficiente.
    // I test rivelano che lo scambio di 32 o 64 byte alla volta è più efficiente per i processori Intel Haswell E.
    // LLVM è più in grado di ottimizzare se diamo a una struttura un #[repr(simd)], anche se in realtà non usiamo questa struttura direttamente.
    //
    //
    // FIXME repr(simd) rotto su emscripten e redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Passa attraverso x e y, copiandoli `Block` alla volta L'ottimizzatore dovrebbe svolgere il ciclo completamente per la maggior parte dei tipi NB
    // Non possiamo usare un ciclo for poiché l `range` impl chiama `mem::swap` in modo ricorsivo
    //
    let mut i = 0;
    while i + block_size <= len {
        // Crea un po 'di memoria non inizializzata come spazio di lavoro Dichiarare `t` qui evita di allineare lo stack quando questo ciclo è inutilizzato
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SICUREZZA: come `i < len` e come il chiamante deve garantire che `x` e `y` siano validi
        // per i byte `len`, `x + i` e `y + i` devono essere indirizzi validi, che soddisfano il contratto di sicurezza per `add`.
        //
        // Inoltre, il chiamante deve garantire che `x` e `y` siano validi per le scritture, correttamente allineati e non sovrapposti, il che soddisfa il contratto di sicurezza per `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Scambia un blocco di byte di x&y, usando t come buffer temporaneo Dovrebbe essere ottimizzato in operazioni SIMD efficienti ove disponibili
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Scambia eventuali byte rimanenti
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SICUREZZA: vedere il precedente commento sulla sicurezza.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Sposta `src` nell `dst` puntato, restituendo il valore `dst` precedente.
///
/// Nessuno dei due valori viene eliminato.
///
/// Questa funzione è semanticamente equivalente a [`mem::replace`] tranne per il fatto che opera su puntatori non elaborati invece che su riferimenti.
/// Quando i riferimenti sono disponibili, [`mem::replace`] dovrebbe essere preferito.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `dst` deve essere [valid] sia per le letture che per le scritture.
///
/// * `dst` deve essere correttamente allineato.
///
/// * `dst` deve puntare a un valore inizializzato correttamente di tipo `T`.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` avrebbe lo stesso effetto senza richiedere il blocco non sicuro.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SICUREZZA: il chiamante deve garantire che `dst` sia valido per essere
    // cast a un riferimento modificabile (valido per scritture, allineato, inizializzato) e non può sovrapporsi a `src` poiché `dst` deve puntare a un oggetto allocato distinto.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // non possono sovrapporsi
    }
    src
}

/// Legge il valore da `src` senza spostarlo.Ciò lascia la memoria in `src` invariata.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `src` deve essere [valid] per le letture.
///
/// * `src` deve essere correttamente allineato.Usa [`read_unaligned`] se questo non è il caso.
///
/// * `src` deve puntare a un valore inizializzato correttamente di tipo `T`.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementa manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea una copia bit per bit del valore in `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // L'uscita a questo punto (restituendo esplicitamente o chiamando una funzione che panics) causerebbe l'eliminazione del valore in `tmp` mentre `a` fa ancora riferimento allo stesso valore.
///         // Ciò potrebbe attivare un comportamento indefinito se `T` non è `Copy`.
/////
/////
///
///         // Crea una copia bit per bit del valore in `b` in `a`.
///         // Questo è sicuro perché i riferimenti modificabili non possono creare alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Come sopra, uscire da qui potrebbe attivare un comportamento indefinito perché `a` e `b` fanno riferimento allo stesso valore.
/////
///
///         // Sposta `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` è stato spostato (`write` assume la proprietà del suo secondo argomento), quindi qui nulla viene lasciato implicitamente.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Proprietà del valore restituito
///
/// `read` crea una copia bit per bit di `T`, indipendentemente dal fatto che `T` sia [`Copy`].
/// Se `T` non è [`Copy`], l'utilizzo sia del valore restituito che del valore in `*src` può violare la sicurezza della memoria.
/// Si noti che l'assegnazione a `*src` conta come un utilizzo perché tenterà di eliminare il valore su `* src`.
///
/// [`write()`] può essere utilizzato per sovrascrivere i dati senza provocarne l'eliminazione.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ora punta alla stessa memoria sottostante di `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // L'assegnazione a `s2` causa l'eliminazione del valore originale.
///     // Oltre questo punto, `s` non deve più essere utilizzato, poiché la memoria sottostante è stata liberata.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // L'assegnazione a `s` provocherebbe la nuova eliminazione del vecchio valore, determinando un comportamento indefinito.
/////
///     // s= String::from("bar");//ERRORE
///
///     // `ptr::write` può essere utilizzato per sovrascrivere un valore senza rilasciarlo.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICUREZZA: il chiamante deve garantire che `src` sia valido per le letture.
    // `src` non può sovrapporsi a `tmp` perché `tmp` è stato semplicemente allocato sullo stack come oggetto allocato separato.
    //
    //
    // Inoltre, poiché abbiamo appena scritto un valore valido in `tmp`, è garantito che sia inizializzato correttamente.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Legge il valore da `src` senza spostarlo.Ciò lascia la memoria in `src` invariata.
///
/// A differenza di [`read`], `read_unaligned` funziona con puntatori non allineati.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `src` deve essere [valid] per le letture.
///
/// * `src` deve puntare a un valore inizializzato correttamente di tipo `T`.
///
/// Come [`read`], `read_unaligned` crea una copia bit per bit di `T`, indipendentemente dal fatto che `T` sia [`Copy`].
/// Se `T` non è [`Copy`], utilizzando sia il valore restituito che il valore in `*src` può [violate memory safety][read-ownership].
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Nelle strutture `packed`
///
/// È attualmente impossibile creare puntatori grezzi a campi non allineati di una struttura compressa.
///
/// Il tentativo di creare un puntatore non elaborato a un campo struct `unaligned` con un'espressione come `&packed.unaligned as *const FieldType` crea un riferimento non allineato intermedio prima di convertirlo in un puntatore non elaborato.
///
/// Che questo riferimento sia temporaneo e che venga eseguito immediatamente è irrilevante poiché il compilatore si aspetta sempre che i riferimenti siano allineati correttamente.
/// Di conseguenza, l'utilizzo di `&packed.unaligned as *const FieldType` provoca un* comportamento non definito * immediato nel programma.
///
/// Un esempio di cosa non fare e di come questo si collega a `read_unaligned` è:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Qui proviamo a prendere l'indirizzo di un intero a 32 bit che non è allineato.
///     let unaligned =
///         // Qui viene creato un riferimento temporaneo non allineato che si traduce in un comportamento indefinito indipendentemente dal fatto che il riferimento venga utilizzato o meno.
/////
///         &packed.unaligned
///         // Il cast su un puntatore grezzo non aiuta;l'errore è già accaduto.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tuttavia, l'accesso ai campi non allineati direttamente con, ad esempio, `packed.unaligned` è sicuro.
///
///
///
///
///
///
// FIXME: Aggiorna i documenti in base ai risultati di RFC #2582 e amici.
/// # Examples
///
/// Leggi un valore usize da un buffer di byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SICUREZZA: il chiamante deve garantire che `src` sia valido per le letture.
    // `src` non può sovrapporsi a `tmp` perché `tmp` è stato semplicemente allocato sullo stack come oggetto allocato separato.
    //
    //
    // Inoltre, poiché abbiamo appena scritto un valore valido in `tmp`, è garantito che sia inizializzato correttamente.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Sovrascrive una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
///
/// `write` non rilascia il contenuto di `dst`.
/// Questo è sicuro, ma potrebbe perdere allocazioni o risorse, quindi è necessario prestare attenzione a non sovrascrivere un oggetto che dovrebbe essere eliminato.
///
///
/// Inoltre, non rilascia `src`.Semanticamente, `src` viene spostato nella posizione indicata da `dst`.
///
/// Ciò è appropriato per inizializzare la memoria non inizializzata o per sovrascrivere la memoria che è stata precedentemente [`read`] da.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `dst` deve essere [valid] per le scritture.
///
/// * `dst` deve essere correttamente allineato.Usa [`write_unaligned`] se questo non è il caso.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implementa manualmente [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Crea una copia bit per bit del valore in `a` in `tmp`.
///         let tmp = ptr::read(a);
///
///         // L'uscita a questo punto (restituendo esplicitamente o chiamando una funzione che panics) causerebbe l'eliminazione del valore in `tmp` mentre `a` fa ancora riferimento allo stesso valore.
///         // Ciò potrebbe attivare un comportamento indefinito se `T` non è `Copy`.
/////
/////
///
///         // Crea una copia bit per bit del valore in `b` in `a`.
///         // Questo è sicuro perché i riferimenti modificabili non possono creare alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Come sopra, uscire da qui potrebbe attivare un comportamento indefinito perché `a` e `b` fanno riferimento allo stesso valore.
/////
///
///         // Sposta `tmp` in `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` è stato spostato (`write` assume la proprietà del suo secondo argomento), quindi qui nulla viene lasciato implicitamente.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Stiamo chiamando gli intrinseci direttamente per evitare chiamate di funzione nel codice generato poiché `intrinsics::copy_nonoverlapping` è una funzione wrapper.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SICUREZZA: il chiamante deve garantire che `dst` sia valido per le scritture.
    // `dst` non può sovrapporsi a `src` perché il chiamante ha accesso modificabile a `dst` mentre `src` è di proprietà di questa funzione.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Sovrascrive una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
///
/// A differenza di [`write()`], il puntatore potrebbe non essere allineato.
///
/// `write_unaligned` non rilascia il contenuto di `dst`.Questo è sicuro, ma potrebbe perdere allocazioni o risorse, quindi è necessario prestare attenzione a non sovrascrivere un oggetto che dovrebbe essere eliminato.
///
/// Inoltre, non rilascia `src`.Semanticamente, `src` viene spostato nella posizione indicata da `dst`.
///
/// Ciò è appropriato per inizializzare la memoria non inizializzata o per sovrascrivere la memoria che è stata precedentemente letta con [`read_unaligned`].
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `dst` deve essere [valid] per le scritture.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL.
///
/// [valid]: self#safety
///
/// ## Nelle strutture `packed`
///
/// È attualmente impossibile creare puntatori grezzi a campi non allineati di una struttura compressa.
///
/// Il tentativo di creare un puntatore non elaborato a un campo struct `unaligned` con un'espressione come `&packed.unaligned as *const FieldType` crea un riferimento non allineato intermedio prima di convertirlo in un puntatore non elaborato.
///
/// Che questo riferimento sia temporaneo e che venga eseguito immediatamente è irrilevante poiché il compilatore si aspetta sempre che i riferimenti siano allineati correttamente.
/// Di conseguenza, l'utilizzo di `&packed.unaligned as *const FieldType` provoca un* comportamento non definito * immediato nel programma.
///
/// Un esempio di cosa non fare e di come questo si collega a `write_unaligned` è:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Qui proviamo a prendere l'indirizzo di un intero a 32 bit che non è allineato.
///     let unaligned =
///         // Qui viene creato un riferimento temporaneo non allineato che si traduce in un comportamento indefinito indipendentemente dal fatto che il riferimento venga utilizzato o meno.
/////
///         &mut packed.unaligned
///         // Il cast su un puntatore grezzo non aiuta;l'errore è già accaduto.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tuttavia, l'accesso ai campi non allineati direttamente con, ad esempio, `packed.unaligned` è sicuro.
///
///
///
///
///
///
///
///
///
// FIXME: Aggiorna i documenti in base ai risultati di RFC #2582 e amici.
/// # Examples
///
/// Scrivi un valore usize in un buffer di byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SICUREZZA: il chiamante deve garantire che `dst` sia valido per le scritture.
    // `dst` non può sovrapporsi a `src` perché il chiamante ha accesso modificabile a `dst` mentre `src` è di proprietà di questa funzione.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Stiamo chiamando l'intrinseco direttamente per evitare chiamate di funzione nel codice generato.
        intrinsics::forget(src);
    }
}

/// Esegue una lettura volatile del valore da `src` senza spostarlo.Ciò lascia la memoria in `src` invariata.
///
/// Le operazioni volatili hanno lo scopo di agire sulla memoria I/O e si garantisce che non vengano elise o riordinate dal compilatore attraverso altre operazioni volatili.
///
/// # Notes
///
/// Rust non ha attualmente un modello di memoria rigorosamente e formalmente definito, quindi la semantica precisa di ciò che "volatile" significa qui è soggetta a modifiche nel tempo.
/// Detto questo, la semantica finirà quasi sempre per essere abbastanza simile a [C11's definition of volatile][c11].
///
/// Il compilatore non dovrebbe modificare l'ordine relativo o il numero di operazioni di memoria volatile.
/// Tuttavia, le operazioni di memoria volatile su tipi di dimensione zero (ad esempio, se un tipo di dimensione zero viene passato a `read_volatile`) sono noops e possono essere ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `src` deve essere [valid] per le letture.
///
/// * `src` deve essere correttamente allineato.
///
/// * `src` deve puntare a un valore inizializzato correttamente di tipo `T`.
///
/// Come [`read`], `read_volatile` crea una copia bit per bit di `T`, indipendentemente dal fatto che `T` sia [`Copy`].
/// Se `T` non è [`Copy`], utilizzando sia il valore restituito che il valore in `*src` può [violate memory safety][read-ownership].
/// Tuttavia, la memorizzazione di tipi non [`Copy`] nella memoria volatile è quasi certamente errata.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Proprio come in C, se un'operazione è volatile non ha alcuna rilevanza sulle questioni che coinvolgono l'accesso simultaneo da più thread.A tale riguardo, gli accessi volatili si comportano esattamente come gli accessi non atomici.
///
/// In particolare, una gara tra un `read_volatile` e qualsiasi operazione di scrittura nella stessa posizione è un comportamento indefinito.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Non farti prendere dal panico per mantenere più piccolo l'impatto del codegen.
        abort();
    }
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Esegue una scrittura volatile di una posizione di memoria con il valore specificato senza leggere o eliminare il vecchio valore.
///
/// Le operazioni volatili hanno lo scopo di agire sulla memoria I/O e si garantisce che non vengano elise o riordinate dal compilatore attraverso altre operazioni volatili.
///
/// `write_volatile` non rilascia il contenuto di `dst`.Questo è sicuro, ma potrebbe perdere allocazioni o risorse, quindi è necessario prestare attenzione a non sovrascrivere un oggetto che dovrebbe essere eliminato.
///
/// Inoltre, non rilascia `src`.Semanticamente, `src` viene spostato nella posizione indicata da `dst`.
///
/// # Notes
///
/// Rust non ha attualmente un modello di memoria rigorosamente e formalmente definito, quindi la semantica precisa di ciò che "volatile" significa qui è soggetta a modifiche nel tempo.
/// Detto questo, la semantica finirà quasi sempre per essere abbastanza simile a [C11's definition of volatile][c11].
///
/// Il compilatore non dovrebbe modificare l'ordine relativo o il numero di operazioni di memoria volatile.
/// Tuttavia, le operazioni di memoria volatile su tipi di dimensione zero (ad esempio, se un tipo di dimensione zero viene passato a `write_volatile`) sono noops e possono essere ignorate.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `dst` deve essere [valid] per le scritture.
///
/// * `dst` deve essere correttamente allineato.
///
/// Notare che anche se `T` ha dimensione `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: self#safety
///
/// Proprio come in C, se un'operazione è volatile non ha alcuna rilevanza sulle questioni che coinvolgono l'accesso simultaneo da più thread.A tale riguardo, gli accessi volatili si comportano esattamente come gli accessi non atomici.
///
/// In particolare, una gara tra un `write_volatile` e qualsiasi altra operazione (lettura o scrittura) sulla stessa posizione è un comportamento indefinito.
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Non farti prendere dal panico per mantenere più piccolo l'impatto del codegen.
        abort();
    }
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Allinea il puntatore `p`.
///
/// Calcola l'offset (in termini di elementi di `stride` stride) che deve essere applicato al puntatore `p` in modo che il puntatore `p` venga allineato a `a`.
///
/// Note: Questa implementazione è stata attentamente adattata a non panic.È UB per questo a panic.
/// L'unico vero cambiamento che può essere fatto qui è il cambiamento di `INV_TABLE_MOD_16` e delle costanti associate.
///
/// Se mai decidessimo di rendere possibile chiamare l'intrinseco con `a` che non è una potenza di due, probabilmente sarà più prudente passare a un'implementazione ingenua piuttosto che cercare di adattarla per accogliere quel cambiamento.
///
///
/// Qualsiasi domanda va a@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): L'uso diretto di questi elementi intrinseci migliora significativamente il codegen a livello di opt <=
    // 1, dove le versioni del metodo di queste operazioni non sono inline.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Calcola l'inverso modulare moltiplicativo di `x` modulo `m`.
    ///
    /// Questa implementazione è personalizzata per `align_offset` e ha le seguenti condizioni preliminari:
    ///
    /// * `m` è un potere di due;
    /// * `x < m`; (se `x ≥ m`, passa invece `x % m`)
    ///
    /// L'implementazione di questa funzione non deve panic.Mai.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabella moltiplicativa inversa modulare modulo 2⁴=16.
        ///
        /// Si noti che questa tabella non contiene valori in cui l'inverso non esiste (ad esempio, per `0⁻¹ mod 16`, `2⁻¹ mod 16`, ecc.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo per il quale è previsto l `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SICUREZZA: `m` deve essere una potenza di due, quindi diverso da zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Ripetiamo "up" usando la seguente formula:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // fino a 2²ⁿ ≥ m.Quindi possiamo ridurre al nostro `m` desiderato prendendo il risultato `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Nota, che qui usiamo intenzionalmente operazioni di avvolgimento: la formula originale usa ad esempio la sottrazione `mod n`.
                // Va benissimo invece eseguirli `mod usize::MAX`, perché prendiamo comunque il risultato `mod n` alla fine.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SICUREZZA: `a` è una potenza di due, quindi diversa da zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` case può essere calcolato più semplicemente tramite `-p (mod a)`, ma così facendo si inibisce la capacità di LLVM di selezionare istruzioni come `lea`.Invece calcoliamo
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // che distribuisce le operazioni attorno al portante, ma pessimizzando `and` sufficientemente per consentire a LLVM di utilizzare le varie ottimizzazioni di cui è a conoscenza.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Già allineato.Sìì!
        return 0;
    } else if stride == 0 {
        // Se il puntatore non è allineato e l'elemento è di dimensione zero, nessuna quantità di elementi allineerà mai il puntatore.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SICUREZZA: a è potenza di due quindi non zero.stride==0 caso è gestito sopra.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SICUREZZA: gcdpow ha un limite superiore che è al massimo il numero di bit in una dimensione.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SICUREZZA: mcd è sempre maggiore o uguale a 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Questo branch risolve per la seguente equazione di congruenza lineare:
        //
        // ` p + so = 0 mod a `
        //
        // `p` ecco il valore del puntatore, `s`, passo di `T`, offset `o` in `T`s e `a`, l'allineamento richiesto.
        //
        // Con `g = gcd(a, s)`, e la condizione di cui sopra che asserisce che `p` è anche divisibile per `g`, possiamo denotare `a' = a/g`, `s' = s/g`, `p' = p/g`, quindi questo diventa equivalente a:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Il primo termine è "the relative alignment of `p` to `a`" (diviso per `g`), il secondo termine è "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (di nuovo diviso per `g`).
        //
        // La divisione per `g` è necessaria per rendere l'inverso ben formato se `a` e `s` non sono co-adescati.
        //
        // Inoltre, il risultato prodotto da questa soluzione non è "minimal", quindi è necessario prendere il risultato `o mod lcm(s, a)`.Possiamo sostituire `lcm(s, a)` con solo un `a'`.
        //
        //
        //
        //
        //

        // SICUREZZA: `gcdpow` ha un limite superiore non maggiore del numero di 0 bit finali in `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SICUREZZA: `a2` è diverso da zero.Lo spostamento di `a` con `gcdpow` non può spostare nessuno dei bit impostati
        // in `a` (di cui ne ha esattamente uno).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SICUREZZA: `gcdpow` ha un limite superiore non maggiore del numero di 0 bit finali in `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SICUREZZA: `gcdpow` ha un limite superiore non maggiore del numero di 0 bit finali in
        // `a`.
        // Inoltre, la sottrazione non può superare, perché `a2 = a >> gcdpow` sarà sempre strettamente maggiore di `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SICUREZZA: `a2` è un potere di due, come dimostrato sopra.`s2` è strettamente inferiore a `a2`
        // perché `(s % a) >> gcdpow` è strettamente inferiore a `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Non può essere allineato affatto.
    usize::MAX
}

/// Confronta i puntatori non elaborati per l'uguaglianza.
///
/// È come usare l'operatore `==`, ma meno generico:
/// gli argomenti devono essere puntatori grezzi `*const T`, non qualsiasi cosa che implementi `PartialEq`.
///
/// Questo può essere utilizzato per confrontare i riferimenti `&T` (che costringono a `*const T` implicitamente) in base al loro indirizzo piuttosto che confrontare i valori a cui puntano (che è ciò che fa l'implementazione `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Le fette vengono anche confrontate in base alla loro lunghezza (indicatori di grasso):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits vengono anche confrontati in base alla loro implementazione:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // I puntatori hanno indirizzi uguali.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Gli oggetti hanno indirizzi uguali, ma `Trait` ha implementazioni diverse.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // La conversione del riferimento in un `*const u8` confronta per indirizzo.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash un puntatore grezzo.
///
/// Questo può essere usato per hash un riferimento `&T` (che costringe a `*const T` implicitamente) dal suo indirizzo piuttosto che dal valore a cui punta (che è ciò che fa l'implementazione `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impl per puntatori a funzione
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Il cast intermedio come usize è richiesto per AVR
                // in modo che lo spazio degli indirizzi del puntatore alla funzione sorgente venga conservato nel puntatore alla funzione finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Il cast intermedio come usize è richiesto per AVR
                // in modo che lo spazio degli indirizzi del puntatore alla funzione sorgente venga conservato nel puntatore alla funzione finale.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nessuna funzione variadica con 0 parametri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Crea un puntatore raw `const` a un luogo, senza creare un riferimento intermedio.
///
/// La creazione di un riferimento con `&`/`&mut` è consentita solo se il puntatore è allineato correttamente e punta ai dati inizializzati.
/// Per i casi in cui tali requisiti non valgono, è necessario utilizzare invece puntatori non elaborati.
/// Tuttavia, `&expr as *const _` crea un riferimento prima di eseguirne il cast a un puntatore non elaborato e tale riferimento è soggetto alle stesse regole di tutti gli altri riferimenti.
///
/// Questa macro può creare un puntatore grezzo *senza* creare prima un riferimento.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` creerebbe un riferimento non allineato e quindi sarebbe un comportamento indefinito!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Crea un puntatore raw `mut` a un luogo, senza creare un riferimento intermedio.
///
/// La creazione di un riferimento con `&`/`&mut` è consentita solo se il puntatore è allineato correttamente e punta ai dati inizializzati.
/// Per i casi in cui tali requisiti non valgono, è necessario utilizzare invece puntatori non elaborati.
/// Tuttavia, `&mut expr as *mut _` crea un riferimento prima di eseguirne il cast a un puntatore non elaborato e tale riferimento è soggetto alle stesse regole di tutti gli altri riferimenti.
///
/// Questa macro può creare un puntatore grezzo *senza* creare prima un riferimento.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` creerebbe un riferimento non allineato e quindi sarebbe un comportamento indefinito!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forza la copia del campo invece di creare un riferimento.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}