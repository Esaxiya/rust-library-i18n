use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ma diverso da zero e covariante.
///
/// Questa è spesso la cosa corretta da usare quando si costruiscono strutture dati usando puntatori non elaborati, ma alla fine è più pericoloso da usare a causa delle sue proprietà aggiuntive.Se non sei sicuro di dover usare `NonNull<T>`, usa semplicemente `*mut T`!
///
/// A differenza di `*mut T`, il puntatore deve essere sempre non nullo, anche se il puntatore non viene mai dereferenziato.In questo modo le enumerazioni possono utilizzare questo valore proibito come discriminante: `Option<NonNull<T>>` ha la stessa dimensione di `* mut T`.
/// Tuttavia, il puntatore può ancora penzolare se non viene dereferenziato.
///
/// A differenza di `*mut T`, `NonNull<T>` è stato scelto per essere covariante rispetto a `T`.Ciò rende possibile utilizzare `NonNull<T>` durante la creazione di tipi covarianti, ma introduce il rischio di non correttezza se utilizzato in un tipo che non dovrebbe effettivamente essere covariante.
/// (La scelta opposta è stata fatta per `*mut T` anche se tecnicamente l'insufficienza potrebbe essere causata solo dalla chiamata di funzioni non sicure.)
///
/// La covarianza è corretta per la maggior parte delle astrazioni sicure, come `Box`, `Rc`, `Arc`, `Vec` e `LinkedList`.Questo è il caso perché forniscono un'API pubblica che segue le normali regole modificabili XOR condivise di Rust.
///
/// Se il tuo tipo non può essere covariante in modo sicuro, devi assicurarti che contenga un campo aggiuntivo per fornire l'invarianza.Spesso questo campo sarà di tipo [`PhantomData`] come `PhantomData<Cell<T>>` o `PhantomData<&'a mut T>`.
///
/// Si noti che `NonNull<T>` ha un'istanza `From` per `&T`.Tuttavia, questo non cambia il fatto che la mutazione tramite un riferimento condiviso (puntatore derivato da un) è un comportamento indefinito a meno che la mutazione non avvenga all'interno di un [`UnsafeCell<T>`].Lo stesso vale per la creazione di un riferimento modificabile da un riferimento condiviso.
///
/// Quando si utilizza questa istanza `From` senza un `UnsafeCell<T>`, è responsabilità dell'utente assicurarsi che `as_mut` non venga mai chiamato e che `as_ptr` non venga mai utilizzato per la mutazione.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` i puntatori non sono `Send` perché i dati a cui fanno riferimento potrebbero essere alias.
// NB, questo impl non è necessario, ma dovrebbe fornire messaggi di errore migliori.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` i puntatori non sono `Sync` perché i dati a cui fanno riferimento potrebbero essere alias.
// NB, questo impl non è necessario, ma dovrebbe fornire messaggi di errore migliori.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Crea un nuovo `NonNull` che penzola, ma ben allineato.
    ///
    /// Questo è utile per inizializzare i tipi che allocano pigramente, come fa `Vec::new`.
    ///
    /// Si noti che il valore del puntatore può potenzialmente rappresentare un puntatore valido a un `T`, il che significa che questo non deve essere utilizzato come valore sentinella "not yet initialized".
    /// I tipi che allocano pigramente devono tenere traccia dell'inizializzazione con altri mezzi.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SICUREZZA: mem::align_of() restituisce un valore usize diverso da zero che viene poi lanciato
        // a un * mut T.
        // Pertanto, `ptr` non è nullo e le condizioni per chiamare new_unchecked() sono rispettate.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Restituisce un riferimento condiviso al valore.A differenza di [`as_ref`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte mutevole vedere [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Restituisce un riferimento univoco al valore.A differenza di [`as_mut`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte condivisa vedere [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Crea un nuovo `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` deve essere non nullo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICUREZZA: il chiamante deve garantire che `ptr` non sia nullo.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Crea un nuovo `NonNull` se `ptr` non è nullo.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICUREZZA: il puntatore è già controllato e non è nullo
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Esegue la stessa funzionalità di [`std::ptr::from_raw_parts`], tranne per il fatto che viene restituito un puntatore `NonNull`, al contrario di un puntatore `*const` grezzo.
    ///
    ///
    /// Vedere la documentazione di [`std::ptr::from_raw_parts`] per maggiori dettagli.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SICUREZZA: il risultato di `ptr::from::raw_parts_mut` non è nullo perché `data_address` lo è.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Decompone un puntatore (possibilmente largo) nei componenti dell'indirizzo e dei metadati.
    ///
    /// Il puntatore può essere successivamente ricostruito con [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Acquisisce il puntatore `*mut` sottostante.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Restituisce un riferimento condiviso al valore.Se il valore può essere non inizializzato, è necessario utilizzare [`as_uninit_ref`].
    ///
    /// Per la controparte mutevole vedere [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * Il puntatore deve puntare a un'istanza inizializzata di `T`.
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    /// (La parte relativa all'inizializzazione non è ancora completamente decisa, ma fino a quando non lo è, l'unico approccio sicuro è assicurarsi che siano effettivamente inizializzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        unsafe { &*self.as_ptr() }
    }

    /// Restituisce un riferimento univoco al valore.Se il valore può essere non inizializzato, è necessario utilizzare [`as_uninit_mut`].
    ///
    /// Per la controparte condivisa vedere [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere allineato correttamente.
    ///
    /// * Deve essere "dereferencable" nel senso definito in [the module documentation].
    ///
    /// * Il puntatore deve puntare a un'istanza inizializzata di `T`.
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    /// (La parte relativa all'inizializzazione non è ancora completamente decisa, ma fino a quando non lo è, l'unico approccio sicuro è assicurarsi che siano effettivamente inizializzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento mutevole.
        unsafe { &mut *self.as_ptr() }
    }

    /// Trasmette a un puntatore di un altro tipo.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SICUREZZA: `self` è un puntatore `NonNull` che è necessariamente non nullo
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Crea una sezione grezza non nulla da un puntatore sottile e una lunghezza.
    ///
    /// L'argomento `len` è il numero di **elementi**, non il numero di byte.
    ///
    /// Questa funzione è sicura, ma l'annullamento del riferimento al valore restituito non è sicuro.
    /// Vedere la documentazione di [`slice::from_raw_parts`] per i requisiti di sicurezza degli slice.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // creare un puntatore di fetta quando si inizia con un puntatore al primo elemento
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Notare che questo esempio dimostra artificialmente un uso di questo metodo, ma `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SICUREZZA: `data` è un puntatore `NonNull` che è necessariamente non nullo
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Restituisce la lunghezza di una slice raw non nulla.
    ///
    /// Il valore restituito è il numero di **elementi**, non il numero di byte.
    ///
    /// Questa funzione è sicura, anche quando la slice raw non nulla non può essere dereferenziata a una slice perché il puntatore non ha un indirizzo valido.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Restituisce un puntatore non nullo al buffer della fetta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SICUREZZA: sappiamo che `self` non è nullo.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Restituisce un puntatore non elaborato al buffer della fetta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Restituisce un riferimento condiviso a una porzione di valori possibilmente non inizializzati.A differenza di [`as_ref`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte mutevole vedere [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere [valid] per le letture per `ptr.len() * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
    ///
    ///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
    ///       Le sezioni non possono mai estendersi su più oggetti allocati.
    ///
    ///     * Il puntatore deve essere allineato anche per le sezioni di lunghezza zero.
    ///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
    ///
    ///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
    ///
    /// * La dimensione totale `ptr.len() * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
    ///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per la durata di questa vita, la memoria a cui punta il puntatore non deve essere mutata (tranne che all'interno di `UnsafeCell`).
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// Vedi anche [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Restituisce un riferimento univoco a una porzione di valori possibilmente non inizializzati.A differenza di [`as_mut`], ciò non richiede l'inizializzazione del valore.
    ///
    /// Per la controparte condivisa vedere [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Quando chiami questo metodo, devi assicurarti che tutte le seguenti condizioni siano vere:
    ///
    /// * Il puntatore deve essere [valid] per le letture e le scritture per `ptr.len() * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
    ///
    ///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
    ///       Le sezioni non possono mai estendersi su più oggetti allocati.
    ///
    ///     * Il puntatore deve essere allineato anche per le sezioni di lunghezza zero.
    ///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
    ///
    ///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
    ///
    /// * La dimensione totale `ptr.len() * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
    ///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
    ///
    /// * È necessario applicare le regole di aliasing di Rust, poiché la durata restituita `'a` viene scelta arbitrariamente e non riflette necessariamente la durata effettiva dei dati.
    ///   In particolare, per tutta la durata di questa vita, la memoria a cui punta il puntatore non deve essere acceduta (letta o scritta) tramite nessun altro puntatore.
    ///
    /// Questo vale anche se il risultato di questo metodo non è utilizzato!
    ///
    /// Vedi anche [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Questo è sicuro poiché `memory` è valido per letture e scritture per `memory.len()` molti byte.
    /// // Notare che la chiamata a `memory.as_mut()` non è consentita qui poiché il contenuto potrebbe non essere inizializzato.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Restituisce un puntatore non elaborato a un elemento o una sottosezione, senza eseguire il controllo dei limiti.
    ///
    /// Chiamare questo metodo con un indice fuori limite o quando `self` non è dereferenziabile è *[comportamento undefined]* anche se il puntatore risultante non viene utilizzato.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SICUREZZA: il chiamante garantisce che `self` sia dereferenziabile e `index` in-bound.
        // Di conseguenza, il puntatore risultante non può essere NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SICUREZZA: un puntatore univoco non può essere nullo, quindi le condizioni per
        // new_unchecked() sono rispettati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICUREZZA: un riferimento modificabile non può essere nullo.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SICUREZZA: un riferimento non può essere nullo, quindi le condizioni per
        // new_unchecked() sono rispettati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}