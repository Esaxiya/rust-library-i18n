use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Un wrapper attorno a un `*mut T` non nullo grezzo che indica che il possessore di questo wrapper possiede il referente.
/// Utile per creare astrazioni come `Box<T>`, `Vec<T>`, `String` e `HashMap<K, V>`.
///
/// A differenza di `*mut T`, `Unique<T>` si comporta "as if" se era un'istanza di `T`.
/// Implementa `Send`/`Sync` se `T` è `Send`/`Sync`.
/// Implica anche il tipo di forte aliasing che un'istanza di `T` può aspettarsi:
/// il referente del puntatore non dovrebbe essere modificato senza un percorso univoco al suo proprietario Unique.
///
/// Se non sei sicuro che sia corretto utilizzare `Unique` per i tuoi scopi, considera l'utilizzo di `NonNull`, che ha una semantica più debole.
///
///
/// A differenza di `*mut T`, il puntatore deve essere sempre non nullo, anche se il puntatore non viene mai dereferenziato.
/// In questo modo le enumerazioni possono utilizzare questo valore proibito come discriminante: `Option<Unique<T>>` ha la stessa dimensione di `Unique<T>`.
/// Tuttavia, il puntatore può ancora penzolare se non viene dereferenziato.
///
/// A differenza di `*mut T`, `Unique<T>` è covariante rispetto a `T`.
/// Questo dovrebbe sempre essere corretto per qualsiasi tipo che rispetti i requisiti di aliasing di Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: questo indicatore non ha conseguenze per la varianza, ma è necessario
    // per far capire a dropck che logicamente possediamo un `T`.
    //
    // Per i dettagli, vedere:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` i puntatori sono `Send` se `T` è `Send` perché i dati a cui fanno riferimento non sono allineati.
/// Notare che questa invariante di aliasing non viene applicata dal sistema di tipi;l'astrazione utilizzando `Unique` deve imporla.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` i puntatori sono `Sync` se `T` è `Sync` perché i dati a cui fanno riferimento non sono allineati.
/// Notare che questa invariante di aliasing non viene applicata dal sistema di tipi;l'astrazione utilizzando `Unique` deve imporla.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Crea un nuovo `Unique` che penzola, ma ben allineato.
    ///
    /// Questo è utile per inizializzare i tipi che allocano pigramente, come fa `Vec::new`.
    ///
    /// Si noti che il valore del puntatore può potenzialmente rappresentare un puntatore valido a un `T`, il che significa che questo non deve essere utilizzato come valore sentinella "not yet initialized".
    /// I tipi che allocano pigramente devono tenere traccia dell'inizializzazione con altri mezzi.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SICUREZZA: mem::align_of() restituisce un puntatore valido, non nullo.Il
        // vengono così rispettate le condizioni per chiamare new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Crea un nuovo `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` deve essere non nullo.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SICUREZZA: il chiamante deve garantire che `ptr` non sia nullo.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Crea un nuovo `Unique` se `ptr` non è nullo.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SICUREZZA: il puntatore è già stato controllato e non è nullo.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Acquisisce il puntatore `*mut` sottostante.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferenzia il contenuto.
    ///
    /// La durata risultante è legata a se stessa, quindi questo si comporta "as if" era in realtà un'istanza di T che viene presa in prestito.
    /// Se è necessaria una durata (unbound) più lunga, utilizzare `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento.
        unsafe { &*self.as_ptr() }
    }

    /// Dereferenzia reciprocamente il contenuto.
    ///
    /// La durata risultante è legata a se stessa, quindi questo si comporta "as if" era in realtà un'istanza di T che viene presa in prestito.
    /// Se è necessaria una durata (unbound) più lunga, utilizzare `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SICUREZZA: il chiamante deve garantire che `self` soddisfi tutti i
        // requisiti per un riferimento mutevole.
        unsafe { &mut *self.as_ptr() }
    }

    /// Trasmette a un puntatore di un altro tipo.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SICUREZZA: Unique::new_unchecked() crea un nuovo e unico bisogno
        // il puntatore specificato non deve essere nullo.
        // Poiché stiamo passando self come puntatore, non può essere nullo.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SICUREZZA: un riferimento modificabile non può essere nullo
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}