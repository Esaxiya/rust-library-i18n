//! `Clone` trait per i tipi che non possono essere "copiati implicitamente".
//!
//! In Rust, alcuni tipi semplici sono "implicitly copyable" e quando li assegni o li passi come argomenti, il destinatario ne riceverà una copia, lasciando il valore originale al suo posto.
//! Questi tipi non richiedono l'allocazione per copiare e non hanno finalizzatori (cioè, non contengono box posseduti o implementano [`Drop`]), quindi il compilatore li considera economici e sicuri da copiare.
//!
//! Per gli altri tipi le copie devono essere fatte esplicitamente, per convenzione implementando [`Clone`] trait e chiamando il metodo [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Esempio di utilizzo di base:
//!
//! ```
//! let s = String::new(); // Il tipo di stringa implementa Clone
//! let copy = s.clone(); // così possiamo clonarlo
//! ```
//!
//! Per implementare facilmente Clone trait, puoi anche usare `#[derive(Clone)]`.Esempio:
//!
//! ```
//! #[derive(Clone)] // aggiungiamo Clone trait alla struttura Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // e ora possiamo clonarlo!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Un comune trait per la capacità di duplicare esplicitamente un oggetto.
///
/// Differisce da [`Copy`] in quanto [`Copy`] è implicito ed estremamente economico, mentre `Clone` è sempre esplicito e può o non può essere costoso.
/// Per applicare queste caratteristiche, Rust non consente di reimplementare [`Copy`], ma è possibile reimplementare `Clone` ed eseguire codice arbitrario.
///
/// Poiché `Clone` è più generale di [`Copy`], puoi automaticamente fare in modo che qualsiasi cosa [`Copy`] sia anche `Clone`.
///
/// ## Derivable
///
/// Questo trait può essere utilizzato con `#[derive]` se tutti i campi sono `Clone`.L'implementazione `derive`d di [`Clone`] chiama [`clone`] su ogni campo.
///
/// [`clone`]: Clone::clone
///
/// Per una struttura generica, `#[derive]` implementa `Clone` in modo condizionale aggiungendo `Clone` associato a parametri generici.
///
/// ```
/// // `derive` implementa Clone for Reading<T>quando T è Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Come posso implementare `Clone`?
///
/// I tipi che sono [`Copy`] dovrebbero avere un'implementazione banale di `Clone`.Più formalmente:
/// se `T: Copy`, `x: T` e `y: &T`, `let x = y.clone();` è equivalente a `let x = *y;`.
/// Le implementazioni manuali dovrebbero fare attenzione a mantenere questa invariante;tuttavia, il codice non sicuro non deve fare affidamento su di esso per garantire la sicurezza della memoria.
///
/// Un esempio è una struttura generica che contiene un puntatore a funzione.In questo caso, l'implementazione di `Clone` non può essere `derive`d, ma può essere implementata come:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implementatori aggiuntivi
///
/// Oltre a [implementors listed below][impls], i seguenti tipi implementano anche `Clone`:
///
/// * Tipi di elementi funzione (ovvero, i tipi distinti definiti per ciascuna funzione)
/// * Tipi di puntatori a funzione (ad es. `fn() -> i32`)
/// * Tipi di array, per tutte le dimensioni, se il tipo di elemento implementa anche `Clone` (ad esempio, `[i32; 123456]`)
/// * Tipi di tupla, se ogni componente implementa anche `Clone` (ad esempio, `()`, `(i32, bool)`)
/// * Tipi di chiusura, se non acquisiscono alcun valore dall'ambiente o se tutti questi valori acquisiti implementano `Clone` da soli.
///   Si noti che le variabili catturate dal riferimento condiviso implementano sempre `Clone` (anche se il referente non lo fa), mentre le variabili catturate dal riferimento mutabile non implementano mai `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Restituisce una copia del valore.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementa Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Esegue l'assegnazione della copia da `source`.
    ///
    /// `a.clone_from(&b)` è equivalente a `a = b.clone()` nella funzionalità, ma può essere sovrascritto per riutilizzare le risorse di `a` per evitare allocazioni non necessarie.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Deriva macro generando un impl di trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): queste strutture sono usate esclusivamente da#[derive] per affermare che ogni componente di un tipo implementa Clone o Copy.
//
//
// Queste strutture non dovrebbero mai apparire nel codice utente.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementazioni di `Clone` per tipi primitivi.
///
/// Le implementazioni che non possono essere descritte in Rust vengono implementate in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// I riferimenti condivisi possono essere clonati, ma i riferimenti modificabili *non possono*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// I riferimenti condivisi possono essere clonati, ma i riferimenti modificabili *non possono*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}