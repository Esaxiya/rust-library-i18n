#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un future rappresenta un calcolo asincrono.
///
/// Un future è un valore che potrebbe non essere stato ancora calcolato.
/// Questo tipo di "asynchronous value" consente a un thread di continuare a svolgere un lavoro utile mentre attende che il valore diventi disponibile.
///
///
/// # Il metodo `poll`
///
/// Il metodo principale di future, `poll`,*tenta* di risolvere future in un valore finale.
/// Questo metodo non si blocca se il valore non è pronto.
/// Invece, l'attività corrente è pianificata per essere riattivata quando è possibile fare ulteriori progressi eseguendo nuovamente il `poll`.
/// L `context` passato al metodo `poll` può fornire un [`Waker`], che è un handle per riattivare l'attività corrente.
///
/// Quando si utilizza un future, generalmente non si chiama `poll` direttamente, ma invece `.await` il valore.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Il tipo di valore prodotto al completamento.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Tentare di risolvere future su un valore finale, registrando l'attività corrente per il risveglio se il valore non è ancora disponibile.
    ///
    /// # Valore di ritorno
    ///
    /// Questa funzione restituisce:
    ///
    /// - [`Poll::Pending`] se future non è ancora pronto
    /// - [`Poll::Ready(val)`] con il risultato `val` di questo future se è finito con successo.
    ///
    /// Una volta che future è terminato, i client non dovrebbero `poll` di nuovo.
    ///
    /// Quando un future non è ancora pronto, `poll` restituisce `Poll::Pending` e memorizza un clone di [`Waker`] copiato dall [`Context`] corrente.
    /// Questo [`Waker`] viene quindi riattivato una volta che future può fare progressi.
    /// Ad esempio, uno future in attesa che un socket diventi leggibile chiamerebbe `.clone()` sull [`Waker`] e lo memorizzerebbe.
    /// Quando un segnale arriva altrove indicando che il socket è leggibile, viene chiamato [`Waker::wake`] e il compito del socket future viene risvegliato.
    /// Una volta che un'attività è stata riattivata, dovrebbe tentare di `poll` di nuovo future, il che può o non può produrre un valore finale.
    ///
    /// Si noti che su più chiamate a `poll`, solo l [`Waker`] dall [`Context`] passato alla chiamata più recente dovrebbe essere programmato per ricevere una sveglia.
    ///
    /// # Caratteristiche di runtime
    ///
    /// Solo Futures sono *inerti*;devono essere *attivamente*`sondati` per fare progressi, il che significa che ogni volta che l'attività corrente viene svegliata, dovrebbe attivamente ri-`poll` in attesa di futures a cui ha ancora interesse.
    ///
    /// La funzione `poll` non viene chiamata ripetutamente in un ciclo stretto, ma dovrebbe essere chiamata solo quando future indica che è pronto per fare progressi (chiamando `wake()`).
    /// Se hai familiarità con le chiamate di sistema `poll(2)` o `select(2)` su Unix, vale la pena notare che futures in genere *non* soffre degli stessi problemi di "all wakeups must poll all events";sono più simili a `epoll(4)`.
    ///
    /// Un'implementazione di `poll` dovrebbe sforzarsi di tornare rapidamente e non dovrebbe bloccarsi.Il ritorno rapido impedisce di intasare inutilmente thread o loop di eventi.
    /// Se è noto in anticipo che una chiamata a `poll` potrebbe richiedere del tempo, il lavoro dovrebbe essere trasferito a un pool di thread (o qualcosa di simile) per garantire che `poll` possa tornare rapidamente.
    ///
    /// # Panics
    ///
    /// Una volta che future è stato completato (restituito `Ready` da `poll`), chiamare nuovamente il suo metodo `poll` può panic, bloccarsi per sempre o causare altri tipi di problemi;l `Future` trait non pone requisiti sugli effetti di tale chiamata.
    /// Tuttavia, poiché il metodo `poll` non è contrassegnato con `unsafe`, si applicano le normali regole di Rust: le chiamate non devono mai causare un comportamento indefinito (danneggiamento della memoria, uso errato delle funzioni `unsafe` o simili), indipendentemente dallo stato di future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}