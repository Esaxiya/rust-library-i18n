#![stable(feature = "futures_api", since = "1.36.0")]

//! Valori asincroni.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Questo tipo è necessario perché:
///
/// a) I generatori non possono implementare `for<'a, 'b> Generator<&'a mut Context<'b>>`, quindi dobbiamo passare un puntatore grezzo (vedi <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) I puntatori grezzi e `NonNull` non sono `Send` o `Sync`, quindi questo renderebbe anche ogni singolo future non-Send/Sync, e non lo vogliamo.
///
/// Inoltre semplifica l'abbassamento HIR di `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Avvolgi un generatore in una future.
///
/// Questa funzione restituisce un `GenFuture` sotto, ma lo nasconde in `impl Trait` per fornire messaggi di errore migliori (`impl Future` invece di `GenFuture<[closure.....]>`).
///
// Questo è `const` per evitare errori aggiuntivi dopo il ripristino da `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Facciamo affidamento sul fatto che async/await futures sono immobili per creare prestiti autoreferenziali nel generatore sottostante.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SICUREZZA: sicuro perché siamo !Unpin + !Drop, e questa è solo una proiezione sul campo.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Riprendi il generatore, trasformando l `&mut Context` in un puntatore grezzo `NonNull`.
            // L'abbassamento dell `.await` lo restituirà in modo sicuro a un `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SICUREZZA: il chiamante deve garantire che `cx.0` sia un puntatore valido
    // che soddisfa tutti i requisiti per un riferimento mutevole.
    unsafe { &mut *cx.0.as_ptr().cast() }
}