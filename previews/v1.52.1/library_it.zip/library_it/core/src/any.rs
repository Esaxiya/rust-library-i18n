//! Questo modulo implementa `Any` trait, che consente la digitazione dinamica di qualsiasi tipo `'static` tramite la riflessione in runtime.
//!
//! `Any` stesso può essere utilizzato per ottenere un `TypeId` e ha più funzionalità se utilizzato come oggetto trait.
//! Come `&dyn Any` (un oggetto trait preso in prestito), ha i metodi `is` e `downcast_ref`, per verificare se il valore contenuto è di un determinato tipo e per ottenere un riferimento al valore interno come tipo.
//! Come `&mut dyn Any`, esiste anche il metodo `downcast_mut`, per ottenere un riferimento mutabile al valore interno.
//! `Box<dyn Any>` aggiunge il metodo `downcast`, che tenta di convertire in un `Box<T>`.
//! Vedere la documentazione di [`Box`] per i dettagli completi.
//!
//! Si noti che `&dyn Any` si limita a verificare se un valore è di un tipo concreto specificato e non può essere utilizzato per verificare se un tipo implementa uno trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Puntatori intelligenti e `dyn Any`
//!
//! Un comportamento da tenere a mente quando si utilizza `Any` come oggetto trait, specialmente con tipi come `Box<dyn Any>` o `Arc<dyn Any>`, è che la semplice chiamata di `.type_id()` sul valore produrrà l `TypeId` del *container*, non l'oggetto trait sottostante.
//!
//! Questo può essere evitato convertendo invece il puntatore intelligente in un `&dyn Any`, che restituirà l `TypeId` dell'oggetto.
//! Per esempio:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // È più probabile che tu voglia questo:
//! let actual_id = (&*boxed).type_id();
//! // ... di questo:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Considera una situazione in cui vogliamo disconnettere un valore passato a una funzione.
//! Conosciamo il valore su cui stiamo lavorando implementa Debug, ma non conosciamo il suo tipo concreto.Vogliamo dare un trattamento speciale a certi tipi: in questo caso stampando la lunghezza dei valori String prima del loro valore.
//! Non conosciamo il tipo concreto del nostro valore in fase di compilazione, quindi dobbiamo usare invece la riflessione di runtime.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funzione di registrazione per qualsiasi tipo che implementa Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Prova a convertire il nostro valore in un `String`.
//!     // In caso di successo, vogliamo restituire la lunghezza della stringa oltre al suo valore.
//!     // In caso contrario, è un tipo diverso: basta stamparlo senza ornamenti.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Questa funzione desidera disconnettere il proprio parametro prima di lavorarci.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... fai qualche altro lavoro
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Qualsiasi trait
///////////////////////////////////////////////////////////////////////////////

/// Un trait per emulare la digitazione dinamica.
///
/// La maggior parte dei tipi implementa `Any`.Tuttavia, qualsiasi tipo che contiene un riferimento non "statico" non lo fa.
/// Vedere [module-level documentation][mod] per maggiori dettagli.
///
/// [mod]: crate::any
// Questo trait non è pericoloso, sebbene ci affidiamo alle specifiche della sua unica funzione `type_id` di impl in codice non sicuro (ad esempio, `downcast`).Normalmente, questo sarebbe un problema, ma poiché l'unico impl di `Any` è un'implementazione globale, nessun altro codice può implementare `Any`.
//
// Potremmo plausibilmente rendere questo trait non sicuro-non causerebbe rotture, poiché controlliamo tutte le implementazioni-ma scegliamo di non farlo poiché non è realmente necessario e potrebbe confondere gli utenti sulla distinzione tra traits non sicuri e metodi non sicuri `type_id` sarebbe comunque sicuro da chiamare, ma probabilmente vorremmo indicare come tale nella documentazione).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Ottiene l `TypeId` di `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metodi di estensione per qualsiasi oggetto trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Assicurarsi che il risultato, ad esempio, dell'unione di un thread possa essere stampato e quindi utilizzato con `unwrap`.
// Potrebbe non essere più necessario se la spedizione funziona con l'upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Restituisce `true` se il tipo boxed è lo stesso di `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Ottieni `TypeId` del tipo con cui è istanziata questa funzione.
        let t = TypeId::of::<T>();

        // Ottieni `TypeId` del tipo nell'oggetto trait (`self`).
        let concrete = self.type_id();

        // Confronta entrambi i TypeId sull'uguaglianza.
        t == concrete
    }

    /// Restituisce un riferimento al valore boxed se è di tipo `T`, o `None` se non lo è.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SICUREZZA: è sufficiente verificare se stiamo puntando al tipo corretto e su cui possiamo fare affidamento
            // che controlla la sicurezza della memoria perché abbiamo implementato Any per tutti i tipi;nessun altro impl può esistere in quanto entrerebbe in conflitto con il nostro impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Restituisce un riferimento modificabile al valore boxed se è di tipo `T`, o `None` se non lo è.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SICUREZZA: è sufficiente verificare se stiamo puntando al tipo corretto e su cui possiamo fare affidamento
            // che controlla la sicurezza della memoria perché abbiamo implementato Any per tutti i tipi;nessun altro impl può esistere in quanto entrerebbe in conflitto con il nostro impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Avanti al metodo definito sul tipo `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID e i suoi metodi
///////////////////////////////////////////////////////////////////////////////

/// Un `TypeId` rappresenta un identificatore univoco globale per un tipo.
///
/// Ogni `TypeId` è un oggetto opaco che non consente l'ispezione di ciò che è all'interno ma consente operazioni di base come la clonazione, il confronto, la stampa e la visualizzazione.
///
///
/// Un `TypeId` è attualmente disponibile solo per i tipi che attribuiscono a `'static`, ma questa limitazione può essere rimossa in future.
///
/// Sebbene `TypeId` implementa `Hash`, `PartialOrd` e `Ord`, vale la pena notare che gli hash e l'ordinamento varieranno tra le versioni di Rust.
/// Fai attenzione a non fare affidamento su di loro all'interno del tuo codice!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Restituisce l `TypeId` del tipo con cui è stata istanziata questa funzione generica.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Restituisce il nome di un tipo come porzione di stringa.
///
/// # Note
///
/// Questo è inteso per uso diagnostico.
/// Il contenuto esatto e il formato della stringa restituita non sono specificati, a parte essere una descrizione di massima fatica del tipo.
/// Ad esempio, tra le stringhe che `type_name::<Option<String>>()` potrebbe restituire ci sono `"Option<String>"` e `"std::option::Option<std::string::String>"`.
///
///
/// La stringa restituita non deve essere considerata un identificatore univoco di un tipo poiché più tipi possono mappare lo stesso nome di tipo.
/// Allo stesso modo, non vi è alcuna garanzia che tutte le parti di un tipo appariranno nella stringa restituita: ad esempio, gli specificatori di durata non sono attualmente inclusi.
/// Inoltre, l'output può cambiare tra le versioni del compilatore.
///
/// L'attuale implementazione utilizza la stessa infrastruttura della diagnostica del compilatore e del debuginfo, ma ciò non è garantito.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Restituisce il nome del tipo del valore a cui si punta come fetta di stringa.
/// È lo stesso di `type_name::<T>()`, ma può essere utilizzato dove il tipo di variabile non è facilmente disponibile.
///
/// # Note
///
/// Questo è inteso per uso diagnostico.Il contenuto esatto e il formato della stringa non sono specificati, a parte essere una descrizione del tipo best-effort.
/// Ad esempio, `type_name_of_val::<Option<String>>(None)` potrebbe restituire `"Option<String>"` o `"std::option::Option<std::string::String>"`, ma non `"foobar"`.
///
/// Inoltre, l'output può cambiare tra le versioni del compilatore.
///
/// Questa funzione non risolve gli oggetti trait, il che significa che `type_name_of_val(&7u32 as &dyn Debug)` potrebbe restituire `"dyn Debug"`, ma non `"u32"`.
///
/// Il nome del tipo non deve essere considerato un identificatore univoco di un tipo;
/// più tipi possono condividere lo stesso nome di tipo.
///
/// L'attuale implementazione utilizza la stessa infrastruttura della diagnostica del compilatore e del debuginfo, ma ciò non è garantito.
///
/// # Examples
///
/// Stampa i tipi integer e float predefiniti.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}