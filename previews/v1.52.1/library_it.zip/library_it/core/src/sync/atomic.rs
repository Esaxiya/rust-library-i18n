//! Tipi atomici
//!
//! I tipi atomici forniscono comunicazioni primitive di memoria condivisa tra i thread e sono gli elementi costitutivi di altri tipi simultanei.
//!
//! Questo modulo definisce le versioni atomiche di un numero selezionato di tipi primitivi, inclusi [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ecc.
//! I tipi atomici presentano operazioni che, se utilizzate correttamente, sincronizzano gli aggiornamenti tra i thread.
//!
//! Ogni metodo richiede un [`Ordering`] che rappresenta la forza della barriera di memoria per quell'operazione.Questi ordini sono gli stessi dell [C++20 atomic orderings][1].Per ulteriori informazioni, vedere [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Le variabili atomiche possono essere condivise in sicurezza tra i thread (implementano [`Sync`]) ma non forniscono esse stesse il meccanismo per la condivisione e seguono l [threading model](../../../std/thread/index.html#the-threading-model) di Rust.
//!
//! Il modo più comune per condividere una variabile atomica è metterla in un [`Arc`][arc] (un puntatore condiviso con conteggio di riferimenti atomici).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! I tipi atomici possono essere memorizzati in variabili statiche, inizializzate utilizzando gli inizializzatori di costanti come [`AtomicBool::new`].La statistica atomica viene spesso utilizzata per l'inizializzazione globale lenta.
//!
//! # Portability
//!
//! Tutti i tipi atomici in questo modulo sono garantiti per essere [lock-free] se disponibili.Ciò significa che non acquisiscono internamente un mutex globale.Non è garantito che i tipi e le operazioni atomici siano privi di attese.
//! Ciò significa che operazioni come `fetch_or` possono essere implementate con un ciclo di confronto e scambio.
//!
//! Le operazioni atomiche possono essere implementate a livello di istruzione con atomiche di dimensioni maggiori.Ad esempio, alcune piattaforme utilizzano istruzioni atomiche a 4 byte per implementare `AtomicI8`.
//! Si noti che questa emulazione non dovrebbe avere un impatto sulla correttezza del codice, è solo qualcosa di cui essere consapevoli.
//!
//! I tipi atomici in questo modulo potrebbero non essere disponibili su tutte le piattaforme.I tipi atomici qui sono tutti ampiamente disponibili, tuttavia, e generalmente si può fare affidamento su quelli esistenti.Alcune eccezioni degne di nota sono:
//!
//! * PowerPC e le piattaforme MIPS con puntatori a 32 bit non hanno i tipi `AtomicU64` o `AtomicI64`.
//! * ARM piattaforme come `armv5te` che non sono per Linux forniscono solo operazioni `load` e `store` e non supportano le operazioni Confronta e scambia (CAS), come `swap`, `fetch_add`, ecc.
//! Inoltre su Linux, queste operazioni CAS vengono implementate tramite [operating system support], che può comportare una riduzione delle prestazioni.
//! * ARM le destinazioni con `thumbv6m` forniscono solo operazioni `load` e `store` e non supportano le operazioni Confronta e scambia (CAS), come `swap`, `fetch_add`, ecc.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Si noti che potrebbero essere aggiunte piattaforme future che non supportano anche alcune operazioni atomiche.Il codice massimamente portabile vorrà fare attenzione a quali tipi atomici vengono utilizzati.
//! `AtomicUsize` e `AtomicIsize` sono generalmente i più portatili, ma anche in questo caso non sono disponibili ovunque.
//! Per riferimento, la libreria `std` richiede atomics della dimensione di un puntatore, sebbene `core` non lo faccia.
//!
//! Attualmente dovrai usare `#[cfg(target_arch)]` principalmente per compilare in modo condizionale il codice con atomics.C'è anche un `#[cfg(target_has_atomic)]` instabile che può essere stabilizzato nello future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Un semplice spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Attendi che l'altro thread rilasci il blocco
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Tieni un conteggio globale dei thread in tempo reale:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Un tipo booleano che può essere condiviso in modo sicuro tra i thread.
///
/// Questo tipo ha la stessa rappresentazione in memoria di un [`bool`].
///
/// **Nota**: questo tipo è disponibile solo su piattaforme che supportano carichi atomici e archivi di `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Crea un `AtomicBool` inizializzato su `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// L'invio è implementato in modo implicito per AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Un tipo di puntatore grezzo che può essere condiviso in modo sicuro tra i thread.
///
/// Questo tipo ha la stessa rappresentazione in memoria di un `*mut T`.
///
/// **Nota**: questo tipo è disponibile solo su piattaforme che supportano carichi atomici e archivi di puntatori.
/// La sua dimensione dipende dalla dimensione del puntatore di destinazione.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Crea un `AtomicPtr<T>` nullo.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ordinamenti della memoria atomica
///
/// L'ordinamento della memoria specifica il modo in cui le operazioni atomiche sincronizzano la memoria.
/// Nel suo [`Ordering::Relaxed`] più debole, viene sincronizzata solo la memoria direttamente toccata dall'operazione.
/// D'altra parte, una coppia store-load di operazioni [`Ordering::SeqCst`] sincronizza altra memoria preservando inoltre un ordine totale di tali operazioni su tutti i thread.
///
///
/// Gli ordini di memoria di Rust sono [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Per ulteriori informazioni, vedere [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Nessun vincolo di ordinamento, solo operazioni atomiche.
    ///
    /// Corrisponde a [`memory_order_relaxed`] in C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Quando accoppiato con un negozio, tutte le operazioni precedenti vengono ordinate prima di qualsiasi caricamento di questo valore con l'ordinamento [`Acquire`] (o superiore).
    ///
    /// In particolare, tutte le scritture precedenti diventano visibili a tutti i thread che eseguono un carico [`Acquire`] (o superiore) di questo valore.
    ///
    /// Si noti che l'utilizzo di questo ordine per un'operazione che combina carichi e archivi porta a un'operazione di caricamento [`Relaxed`]!
    ///
    /// Questo ordine è applicabile solo per le operazioni che possono eseguire un negozio.
    ///
    /// Corrisponde a [`memory_order_release`] in C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Quando accoppiato con un carico, se il valore caricato è stato scritto da un'operazione di negozio con un ordine [`Release`] (o superiore), tutte le operazioni successive vengono ordinate dopo quel negozio.
    /// In particolare, tutti i caricamenti successivi vedranno i dati scritti prima del negozio.
    ///
    /// Si noti che l'utilizzo di questo ordine per un'operazione che combina carichi e archivi porta a un'operazione di archivio [`Relaxed`]!
    ///
    /// Questo ordine è applicabile solo per le operazioni che possono eseguire un carico.
    ///
    /// Corrisponde a [`memory_order_acquire`] in C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ha gli effetti di [`Acquire`] e [`Release`] insieme:
    /// Per i carichi utilizza l'ordinazione [`Acquire`].Per i negozi utilizza l'ordinazione [`Release`].
    ///
    /// Si noti che nel caso di `compare_and_swap`, è possibile che l'operazione finisca per non eseguire alcun archivio e quindi ha solo l'ordinazione [`Acquire`].
    ///
    /// Tuttavia, `AcqRel` non eseguirà mai gli accessi [`Relaxed`].
    ///
    /// Questo ordine è applicabile solo per le operazioni che combinano carichi e magazzini.
    ///
    /// Corrisponde a [`memory_order_acq_rel`] in C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Come [`Acquire`]/[`Release`]/[`AcqRel`](rispettivamente per le operazioni di caricamento, archiviazione e caricamento con archivio) con la garanzia aggiuntiva che tutti i thread vedano tutte le operazioni coerenti in sequenza nello stesso ordine .
    ///
    ///
    /// Corrisponde a [`memory_order_seq_cst`] in C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Un [`AtomicBool`] inizializzato su `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Crea un nuovo `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Restituisce un riferimento modificabile all [`bool`] sottostante.
    ///
    /// Ciò è sicuro perché il riferimento modificabile garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SICUREZZA: il riferimento mutevole garantisce una proprietà unica.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Ottieni l'accesso atomico a un `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SICUREZZA: il riferimento mutevole garantisce una proprietà unica, e
        // l'allineamento di `bool` e `Self` è 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Consuma l'atomico e restituisce il valore contenuto.
    ///
    /// Ciò è sicuro perché il passaggio di `self` in base al valore garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Carica un valore da bool.
    ///
    /// `load` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// I valori possibili sono [`SeqCst`], [`Acquire`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` è [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SICUREZZA: eventuali gare di dati sono impedite da elementi intrinseci atomici e grezzi
        // il puntatore passato è valido perché lo abbiamo ottenuto da un riferimento.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Memorizza un valore in bool.
    ///
    /// `store` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// I valori possibili sono [`SeqCst`], [`Release`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` è [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SICUREZZA: eventuali gare di dati sono impedite da elementi intrinseci atomici e grezzi
        // il puntatore passato è valido perché lo abbiamo ottenuto da un riferimento.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Memorizza un valore in bool, restituendo il valore precedente.
    ///
    /// `swap` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Memorizza un valore nell [`bool`] se il valore corrente è uguale al valore `current`.
    ///
    /// Il valore restituito è sempre il valore precedente.Se è uguale a `current`, il valore è stato aggiornato.
    ///
    /// `compare_and_swap` accetta anche un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// Si noti che anche quando si utilizza [`AcqRel`], l'operazione potrebbe non riuscire e quindi eseguire solo un caricamento `Acquire`, ma non avere la semantica `Release`.
    /// L'utilizzo di [`Acquire`] rende la memorizzazione parte di questa operazione [`Relaxed`] se avviene, e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Migrazione a `compare_exchange` e `compare_exchange_weak`
    ///
    /// `compare_and_swap` è equivalente a `compare_exchange` con la seguente mappatura per gli ordini di memoria:
    ///
    /// Originale |Successo |Fallimento
    /// -------- | ------- | -------
    /// Rilassato |Rilassato |Acquisisci rilassato |Acquisisci |Acquisisci versione |Rilascio |AcqRel rilassato |AcqRel |Acquisisci SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` può fallire in modo spurio anche quando il confronto ha esito positivo, il che consente al compilatore di generare un codice assembly migliore quando il confronto e lo scambio vengono utilizzati in un ciclo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Memorizza un valore nell [`bool`] se il valore corrente è uguale al valore `current`.
    ///
    /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
    /// In caso di successo, questo valore è garantito per essere uguale a `current`.
    ///
    /// `compare_exchange` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
    /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
    ///
    /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Memorizza un valore nell [`bool`] se il valore corrente è uguale al valore `current`.
    ///
    /// A differenza di [`AtomicBool::compare_exchange`], questa funzione può fallire falsamente anche quando il confronto ha esito positivo, il che può portare a un codice più efficiente su alcune piattaforme.
    ///
    /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
    ///
    /// `compare_exchange_weak` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
    /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
    /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" con un valore booleano.
    ///
    /// Esegue un'operazione logica "and" sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
    ///
    /// Restituisce il valore precedente.
    ///
    /// `fetch_and` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" con un valore booleano.
    ///
    /// Esegue un'operazione logica "nand" sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
    ///
    /// Restituisce il valore precedente.
    ///
    /// `fetch_nand` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Non possiamo usare atomic_nand qui perché può risultare in uno bool con un valore non valido.
        // Ciò accade perché l'operazione atomica viene eseguita internamente con un numero intero a 8 bit, che imposterebbe i 7 bit superiori.
        //
        // Quindi usiamo invece fetch_xor o swap.
        if val {
            // ! (x&true)== !x Dobbiamo invertire bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Dobbiamo impostare bool su true.
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" con un valore booleano.
    ///
    /// Esegue un'operazione logica "or" sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
    ///
    /// Restituisce il valore precedente.
    ///
    /// `fetch_or` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" con un valore booleano.
    ///
    /// Esegue un'operazione logica "xor" sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
    ///
    /// Restituisce il valore precedente.
    ///
    /// `fetch_xor` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Restituisce un puntatore modificabile all [`bool`] sottostante.
    ///
    /// L'esecuzione di letture e scritture non atomiche sull'intero risultante può essere una gara di dati.
    /// Questo metodo è principalmente utile per FFI, in cui la firma della funzione può utilizzare `*mut bool` invece di `&AtomicBool`.
    ///
    /// Restituire un puntatore `*mut` da un riferimento condiviso a questo atomic è sicuro perché i tipi atomic funzionano con la mutabilità interna.
    /// Tutte le modifiche di un atomico cambiano il valore tramite un riferimento condiviso e possono farlo in sicurezza fintanto che utilizzano operazioni atomiche.
    /// Qualsiasi utilizzo del puntatore grezzo restituito richiede un blocco `unsafe` e deve comunque mantenere la stessa restrizione: le operazioni su di esso devono essere atomiche.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Recupera il valore e vi applica una funzione che restituisce un nuovo valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se la funzione ha restituito `Some(_)`, altrimenti `Err(previous_value)`.
    ///
    /// Note: Questo può chiamare la funzione più volte se il valore è stato modificato da altri thread nel frattempo, purché la funzione restituisca `Some(_)`, ma la funzione sarà stata applicata solo una volta al valore memorizzato.
    ///
    ///
    /// `fetch_update` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// Il primo descrive l'ordinamento richiesto per quando l'operazione riesce finalmente, mentre il secondo descrive l'ordinamento richiesto per i carichi.
    /// Questi corrispondono rispettivamente all'ordine di successo e di errore di [`AtomicBool::compare_exchange`].
    ///
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento finale riuscito [`Relaxed`].
    /// L'ordine di caricamento (failed) può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento riuscito.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Crea un nuovo `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Restituisce un riferimento modificabile al puntatore sottostante.
    ///
    /// Ciò è sicuro perché il riferimento modificabile garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Ottieni l'accesso atomico a un puntatore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - il riferimento mutevole garantisce una proprietà unica.
        //  - l'allineamento di `*mut T` e `Self` è lo stesso su tutte le piattaforme supportate da rust, come verificato sopra.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Consuma l'atomico e restituisce il valore contenuto.
    ///
    /// Ciò è sicuro perché il passaggio di `self` in base al valore garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Carica un valore dal puntatore.
    ///
    /// `load` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// I valori possibili sono [`SeqCst`], [`Acquire`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` è [`Release`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Memorizza un valore nel puntatore.
    ///
    /// `store` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// I valori possibili sono [`SeqCst`], [`Release`] e [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics se `order` è [`Acquire`] o [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Memorizza un valore nel puntatore, restituendo il valore precedente.
    ///
    /// `swap` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
    /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche sui puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Memorizza un valore nel puntatore se il valore corrente è uguale al valore `current`.
    ///
    /// Il valore restituito è sempre il valore precedente.Se è uguale a `current`, il valore è stato aggiornato.
    ///
    /// `compare_and_swap` accetta anche un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
    /// Si noti che anche quando si utilizza [`AcqRel`], l'operazione potrebbe non riuscire e quindi eseguire solo un caricamento `Acquire`, ma non avere la semantica `Release`.
    /// L'utilizzo di [`Acquire`] rende la memorizzazione parte di questa operazione [`Relaxed`] se avviene, e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche sui puntatori.
    ///
    /// # Migrazione a `compare_exchange` e `compare_exchange_weak`
    ///
    /// `compare_and_swap` è equivalente a `compare_exchange` con la seguente mappatura per gli ordini di memoria:
    ///
    /// Originale |Successo |Fallimento
    /// -------- | ------- | -------
    /// Rilassato |Rilassato |Acquisisci rilassato |Acquisisci |Acquisisci versione |Rilascio |AcqRel rilassato |AcqRel |Acquisisci SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` può fallire in modo spurio anche quando il confronto ha esito positivo, il che consente al compilatore di generare un codice assembly migliore quando il confronto e lo scambio vengono utilizzati in un ciclo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Memorizza un valore nel puntatore se il valore corrente è uguale al valore `current`.
    ///
    /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
    /// In caso di successo, questo valore è garantito per essere uguale a `current`.
    ///
    /// `compare_exchange` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
    /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
    ///
    /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche sui puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Memorizza un valore nel puntatore se il valore corrente è uguale al valore `current`.
    ///
    /// A differenza di [`AtomicPtr::compare_exchange`], questa funzione può fallire falsamente anche quando il confronto ha esito positivo, il che può portare a un codice più efficiente su alcune piattaforme.
    ///
    /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
    ///
    /// `compare_exchange_weak` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
    /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
    /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche sui puntatori.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SICUREZZA: questo intrinseco non è sicuro perché opera su un puntatore non elaborato
        // ma sappiamo per certo che il puntatore è valido (lo abbiamo appena preso da un `UnsafeCell` che abbiamo per riferimento) e l'operazione atomica stessa ci permette di mutare in sicurezza i contenuti di `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Recupera il valore e vi applica una funzione che restituisce un nuovo valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se la funzione ha restituito `Some(_)`, altrimenti `Err(previous_value)`.
    ///
    /// Note: Questo può chiamare la funzione più volte se il valore è stato modificato da altri thread nel frattempo, purché la funzione restituisca `Some(_)`, ma la funzione sarà stata applicata solo una volta al valore memorizzato.
    ///
    ///
    /// `fetch_update` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
    /// Il primo descrive l'ordinamento richiesto per quando l'operazione riesce finalmente, mentre il secondo descrive l'ordinamento richiesto per i carichi.
    /// Questi corrispondono rispettivamente all'ordine di successo e di errore di [`AtomicPtr::compare_exchange`].
    ///
    /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento finale riuscito [`Relaxed`].
    /// L'ordine di caricamento (failed) può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento riuscito.
    ///
    /// **Note:** Questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche sui puntatori.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Converte un `bool` in un `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Questa macro finisce per essere inutilizzata su alcune architetture.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Un tipo intero che può essere condiviso in modo sicuro tra i thread.
        ///
        /// Questo tipo ha la stessa rappresentazione in memoria del tipo intero sottostante, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Per ulteriori informazioni sulle differenze tra tipi atomici e tipi non atomici, nonché informazioni sulla portabilità di questo tipo, vedere [module-level documentation].
        ///
        ///
        /// **Note:** Questo tipo è disponibile solo su piattaforme che supportano carichi atomici e archivi di [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Un numero intero atomico inizializzato su `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // L'invio è implementato in modo implicito.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Crea un nuovo numero intero atomico.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Restituisce un riferimento modificabile all'intero sottostante.
            ///
            /// Ciò è sicuro perché il riferimento modificabile garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - il riferimento mutevole garantisce una proprietà unica.
                //  - l'allineamento di `$int_type` e `Self` è lo stesso, come promesso da $cfg_align e verificato sopra.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Consuma l'atomico e restituisce il valore contenuto.
            ///
            /// Ciò è sicuro perché il passaggio di `self` in base al valore garantisce che nessun altro thread acceda contemporaneamente ai dati atomici.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Carica un valore dall'intero atomico.
            ///
            /// `load` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
            /// I valori possibili sono [`SeqCst`], [`Acquire`] e [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` è [`Release`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Memorizza un valore nel numero intero atomico.
            ///
            /// `store` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
            ///  I valori possibili sono [`SeqCst`], [`Release`] e [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics se `order` è [`Acquire`] o [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Memorizza un valore nell'intero atomico, restituendo il valore precedente.
            ///
            /// `swap` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Memorizza un valore nel numero intero atomico se il valore corrente è uguale al valore `current`.
            ///
            /// Il valore restituito è sempre il valore precedente.Se è uguale a `current`, il valore è stato aggiornato.
            ///
            /// `compare_and_swap` accetta anche un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.
            /// Si noti che anche quando si utilizza [`AcqRel`], l'operazione potrebbe non riuscire e quindi eseguire solo un caricamento `Acquire`, ma non avere la semantica `Release`.
            ///
            /// L'utilizzo di [`Acquire`] rende la memorizzazione parte di questa operazione [`Relaxed`] se avviene, e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrazione a `compare_exchange` e `compare_exchange_weak`
            ///
            /// `compare_and_swap` è equivalente a `compare_exchange` con la seguente mappatura per gli ordini di memoria:
            ///
            /// Originale |Successo |Fallimento
            /// -------- | ------- | -------
            /// Rilassato |Rilassato |Acquisisci rilassato |Acquisisci |Acquisisci versione |Rilascio |AcqRel rilassato |AcqRel |Acquisisci SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` può fallire in modo spurio anche quando il confronto ha esito positivo, il che consente al compilatore di generare un codice assembly migliore quando il confronto e lo scambio vengono utilizzati in un ciclo.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Memorizza un valore nel numero intero atomico se il valore corrente è uguale al valore `current`.
            ///
            /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
            /// In caso di successo, questo valore è garantito per essere uguale a `current`.
            ///
            /// `compare_exchange` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
            /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
            /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
            /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
            ///
            /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Memorizza un valore nel numero intero atomico se il valore corrente è uguale al valore `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// questa funzione può fallire falsamente anche quando il confronto ha esito positivo, il che può portare a un codice più efficiente su alcune piattaforme.
            /// Il valore restituito è un risultato che indica se il nuovo valore è stato scritto e contiene il valore precedente.
            ///
            /// `compare_exchange_weak` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
            /// `success` descrive l'ordinamento richiesto per l'operazione di lettura-modifica-scrittura che ha luogo se il confronto con `current` ha esito positivo.
            /// `failure` descrive l'ordinamento richiesto per l'operazione di caricamento che ha luogo quando il confronto non riesce.
            /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento corretto di [`Relaxed`].
            ///
            /// L'ordine di errore può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento di successo.
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Aggiunge al valore corrente, restituendo il valore precedente.
            ///
            /// Questa operazione si conclude con l'overflow.
            ///
            /// `fetch_add` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Sottrae dal valore corrente, restituendo il valore precedente.
            ///
            /// Questa operazione si conclude con l'overflow.
            ///
            /// `fetch_sub` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" con il valore corrente.
            ///
            /// Esegue un'operazione "and" bit per bit sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_and` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" con il valore corrente.
            ///
            /// Esegue un'operazione "nand" bit per bit sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_nand` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 e 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" con il valore corrente.
            ///
            /// Esegue un'operazione "or" bit per bit sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_or` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" con il valore corrente.
            ///
            /// Esegue un'operazione "xor" bit per bit sul valore corrente e sull'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_xor` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Recupera il valore e vi applica una funzione che restituisce un nuovo valore opzionale.Restituisce un `Result` di `Ok(previous_value)` se la funzione ha restituito `Some(_)`, altrimenti `Err(previous_value)`.
            ///
            /// Note: Questo può chiamare la funzione più volte se il valore è stato modificato da altri thread nel frattempo, purché la funzione restituisca `Some(_)`, ma la funzione sarà stata applicata solo una volta al valore memorizzato.
            ///
            ///
            /// `fetch_update` richiede due argomenti [`Ordering`] per descrivere l'ordine di memoria di questa operazione.
            /// Il primo descrive l'ordinamento richiesto per quando l'operazione riesce finalmente, mentre il secondo descrive l'ordinamento richiesto per i carichi.Questi corrispondono agli ordini di successo e fallimento di
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// L'utilizzo di [`Acquire`] come ordine di successo rende il negozio parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende il caricamento finale riuscito [`Relaxed`].
            /// L'ordine di caricamento (failed) può essere solo [`SeqCst`], [`Acquire`] o [`Relaxed`] e deve essere equivalente o più debole dell'ordinamento riuscito.
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordering: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Massimo con il valore corrente.
            ///
            /// Trova il massimo del valore corrente e dell'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_max` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// let max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// asserisci! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimo con il valore corrente.
            ///
            /// Trova il minimo del valore corrente e dell'argomento `val` e imposta il nuovo valore sul risultato.
            ///
            /// Restituisce il valore precedente.
            ///
            /// `fetch_min` accetta un argomento [`Ordering`] che descrive l'ordine di memoria di questa operazione.Sono possibili tutte le modalità di ordinazione.
            /// Si noti che l'utilizzo di [`Acquire`] rende la parte di memorizzazione parte di questa operazione [`Relaxed`] e l'utilizzo di [`Release`] rende la parte di caricamento [`Relaxed`].
            ///
            ///
            /// **Nota**: questo metodo è disponibile solo su piattaforme che supportano operazioni atomiche su
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// sia bar=12;
            /// let min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SICUREZZA: le gare di dati sono impedite da elementi intrinseci atomici.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Restituisce un puntatore modificabile all'intero sottostante.
            ///
            /// L'esecuzione di letture e scritture non atomiche sull'intero risultante può essere una gara di dati.
            /// Questo metodo è principalmente utile per FFI, dove può essere utilizzata la firma della funzione
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Restituire un puntatore `*mut` da un riferimento condiviso a questo atomic è sicuro perché i tipi atomic funzionano con la mutabilità interna.
            /// Tutte le modifiche di un atomico cambiano il valore tramite un riferimento condiviso e possono farlo in sicurezza fintanto che utilizzano operazioni atomiche.
            /// Qualsiasi utilizzo del puntatore grezzo restituito richiede un blocco `unsafe` e deve comunque mantenere la stessa restrizione: le operazioni su di esso devono essere atomiche.
            ///
            ///
            /// # Examples
            ///
            /// `` ignora (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SICUREZZA: sicuro fintanto che `my_atomic_op` è atomico.
            /// unsafe {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Restituisce il valore precedente (come __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Restituisce il valore precedente (come __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// restituisce il valore massimo (confronto con segno)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// restituisce il valore minimo (confronto con segno)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// restituisce il valore massimo (confronto senza segno)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// restituisce il valore minimo (confronto senza segno)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Un recinto atomico.
///
/// A seconda dell'ordine specificato, una barriera impedisce al compilatore e alla CPU di riordinare determinati tipi di operazioni di memoria attorno ad essa.
/// Ciò crea rapporti di sincronizzazione tra esso e operazioni atomiche o recinzioni in altri thread.
///
/// Una fence 'A' che ha (almeno) la semantica di ordinamento [`Release`], si sincronizza con una fence 'B' con (almeno) la semantica [`Acquire`], se e solo se esistono operazioni X e Y, entrambe operanti su qualche oggetto atomico 'M' tale che A sia sequenziato prima X, Y viene sincronizzato prima che B e Y osservino la modifica in M.
/// Ciò fornisce una dipendenza accade prima tra A e B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Anche le operazioni atomiche con la semantica [`Release`] o [`Acquire`] possono essere sincronizzate con un fence.
///
/// Una fence che ha l'ordinamento [`SeqCst`], oltre ad avere semantica [`Acquire`] e [`Release`], partecipa all'ordine di programma globale delle altre operazioni e/o fences [`SeqCst`].
///
/// Accetta gli ordini [`Acquire`], [`Release`], [`AcqRel`] e [`SeqCst`].
///
/// # Panics
///
/// Panics se `order` è [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Una primitiva di mutua esclusione basata su spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Attendi fino a quando il vecchio valore è `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Questa barriera si sincronizza con il negozio in `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SICUREZZA: l'utilizzo di una recinzione atomica è sicuro.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Una barriera di memoria del compilatore.
///
/// `compiler_fence` non emette alcun codice macchina, ma limita i tipi di riordino della memoria che il compilatore è autorizzato a fare.In particolare, a seconda della semantica [`Ordering`] specificata, al compilatore potrebbe non essere consentito lo spostamento di letture o scritture prima o dopo la chiamata sull'altro lato della chiamata a `compiler_fence`.Notare che **non** impedisce all '*hardware* di effettuare tale riordino.
///
/// Questo non è un problema in un contesto di esecuzione a thread singolo, ma quando altri thread possono modificare la memoria contemporaneamente, sono necessarie primitive di sincronizzazione più potenti come [`fence`].
///
/// I riordinamenti impediti dalle diverse semantiche di ordinamento sono:
///
///  - con [`SeqCst`], non è consentito riordinare le letture e le scritture in questo punto.
///  - con [`Release`], le letture e le scritture precedenti non possono essere spostate oltre le scritture successive.
///  - con [`Acquire`], le letture e le scritture successive non possono essere spostate prima delle letture precedenti.
///  - con [`AcqRel`] vengono applicate entrambe le regole precedenti.
///
/// `compiler_fence` è generalmente utile solo per impedire a un thread di correre *con se stesso*.Cioè, se un dato thread sta eseguendo un pezzo di codice, quindi viene interrotto e inizia a eseguire codice altrove (mentre è ancora nello stesso thread e concettualmente ancora sullo stesso core).Nei programmi tradizionali, ciò può avvenire solo quando è registrato un gestore di segnali.
/// In un codice di livello più basso, tali situazioni possono verificarsi anche durante la gestione degli interrupt, durante l'implementazione di thread verdi con prelazione, ecc.
/// I lettori curiosi sono incoraggiati a leggere la discussione del kernel Linux su [memory barriers].
///
/// # Panics
///
/// Panics se `order` è [`Relaxed`].
///
/// # Examples
///
/// Senza `compiler_fence`,*non* è garantito il successo dell `assert_eq!` nel codice seguente, nonostante tutto avvenga in un singolo thread.
/// Per capire perché, ricorda che il compilatore è libero di scambiare gli archivi con `IMPORTANT_VARIABLE` e `IS_READ` poiché sono entrambi `Ordering::Relaxed`.Se lo fa e il gestore del segnale viene richiamato subito dopo l'aggiornamento di `IS_READY`, il gestore del segnale vedrà `IS_READY=1`, ma `IMPORTANT_VARIABLE=0`.
/// L'utilizzo di un `compiler_fence` risolve questa situazione.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // impedire che le scritture precedenti vengano spostate oltre questo punto
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SICUREZZA: l'utilizzo di una recinzione atomica è sicuro.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Segnala al processore che si trova all'interno di uno spin-loop ("spin lock").
///
/// Questa funzione è deprecata a favore di [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}