//! Decodifica un valore a virgola mobile in singole parti e intervalli di errore.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valore finito senza segno decodificato, in modo tale che:
///
/// - Il valore originale è uguale a `mant * 2^exp`.
///
/// - Qualsiasi numero da `(mant - minus)*2^exp` a `(mant + plus)* 2^exp` verrà arrotondato al valore originale.
/// L'intervallo è compreso solo quando `inclusive` è `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// La mantissa squamata.
    pub mant: u64,
    /// L'intervallo di errore inferiore.
    pub minus: u64,
    /// L'intervallo di errore superiore.
    pub plus: u64,
    /// L'esponente condiviso in base 2.
    pub exp: i16,
    /// Vero quando l'intervallo di errore è inclusivo.
    ///
    /// In IEEE 754, questo è vero quando la mantissa originale era pari.
    pub inclusive: bool,
}

/// Valore senza segno decodificato.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinità, positive o negative.
    Infinite,
    /// Zero, positivo o negativo.
    Zero,
    /// Numeri finiti con ulteriori campi decodificati.
    Finite(Decoded),
}

/// Un tipo a virgola mobile che può essere `decodificato`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Il valore normalizzato positivo minimo.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Restituisce un segno (vero se negativo) e un valore `FullDecoded` da un dato numero in virgola mobile.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vicini: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode conserva sempre l'esponente, quindi la mantissa viene ridimensionata per i subnormali.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vicini: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // dove maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vicini: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}