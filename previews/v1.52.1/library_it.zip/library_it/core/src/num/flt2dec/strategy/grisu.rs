//! Adattamento Rust dell'algoritmo Grisu3 descritto in "Stampa rapida e accurata di numeri in virgola mobile con numeri interi" [^ 1].
//! Utilizza circa 1 KB di tabella precalcolata e, a sua volta, è molto veloce per la maggior parte degli input.
//!
//! [^1]: Florian Loitsch.2010. Stampa rapida di numeri in virgola mobile e
//!   accuratamente con numeri interi.SIGPLAN No.45, 6 (giugno 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// vedere i commenti in `format_shortest_opt` per la logica.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Dato `x > 0`, restituisce `(k, 10^k)` in modo tale che `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// L'implementazione della modalità più breve per Grisu.
///
/// Restituisce `None` quando altrimenti restituirebbe una rappresentazione inesatta.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // abbiamo bisogno di almeno tre bit di precisione aggiuntiva

    // inizia con i valori normalizzati con l'esponente condiviso
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // trova qualsiasi `cached = 10^minusk` tale che `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // poiché `plus` è normalizzato, questo significa `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // date le nostre scelte di `ALPHA` e `GAMMA`, questo inserisce `plus * cached` in `[4, 2^32)`.
    //
    // è ovviamente desiderabile massimizzare `GAMMA - ALPHA`, in modo da non aver bisogno di molti poteri di 10 memorizzati nella cache, ma ci sono alcune considerazioni:
    //
    //
    // 1. vogliamo mantenere `floor(plus * cached)` all'interno di `u32` poiché necessita di una divisione costosa.
    //    (questo non è realmente evitabile, il resto è richiesto per la stima dell'accuratezza.)
    // 2.
    // il resto di `floor(plus * cached)` viene ripetutamente moltiplicato per 10 e non dovrebbe traboccare.
    //
    // il primo dà `64 + GAMMA <= 32`, mentre il secondo dà `10 * 2^-ALPHA <= 2^64`;
    // -60 e -32 è l'intervallo massimo con questo vincolo e anche V8 li utilizza.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // scala fps.questo dà l'errore massimo di 1 ulp (dimostrato dal Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-intervallo effettivo di meno
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // sopra `minus`, `v` e `plus` sono approssimazioni *quantizzate*(errore <1 ulp).
    // poiché non sappiamo che l'errore è positivo o negativo, utilizziamo due approssimazioni equamente distanziate e abbiamo l'errore massimo di 2 ulps.
    //
    // l "unsafe region" è un intervallo libero che inizialmente generiamo.
    // l "safe region" è un intervallo conservativo che accettiamo solo.
    // iniziamo con la riproduzione corretta all'interno della regione non sicura e proviamo a trovare la riproduzione più vicina a `v`, anch'essa all'interno della regione sicura.
    // se non possiamo, ci arrendiamo.
    //
    let plus1 = plus.f + 1;
    // sia plus0 = plus.f, 1;//solo per spiegazione lascia minus0 = minus.f + 1;//solo per spiegazione
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // esponente condiviso

    // dividere `plus1` in parti integrali e frazionarie.
    // è garantito che le parti integrali si adattino a u32, poiché l'alimentazione memorizzata nella cache garantisce `plus < 2^32` e `plus.f` normalizzato è sempre inferiore a `2^64 - 2^4` a causa dei requisiti di precisione.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // calcolare il più grande `10^max_kappa` non più di `plus1` (quindi `plus1 < 10^(max_kappa+1)`).
    // questo è un limite superiore di `kappa` di seguito.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: se `k` è il più grande intero st
    // `0 <= y mod 10^k <= y - x`,              quindi `V = floor(y / 10^k) * 10^k` è in `[x, y]` e una delle rappresentazioni più brevi (con il numero minimo di cifre significative) in quell'intervallo.
    //
    //
    // trova la lunghezza della cifra `kappa` tra `(minus1, plus1)` secondo il Teorema 6.2.
    // Il teorema 6.2 può essere adottato per escludere `x` richiedendo invece `y mod 10^k < y - x`.
    // (ad esempio, `x` =32000, `y` =32777; `kappa` =2 poiché "y mod 10 ^ 3=777 <y, x=777".) l'algoritmo si basa sulla fase di verifica successiva per escludere `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) as usize;//solo per spiegazione
    let delta1frac = delta1 & ((1 << e) - 1);

    // eseguire il rendering di parti integranti, verificando la precisione in ogni passaggio.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cifre ancora da rendere
    loop {
        // abbiamo sempre almeno una cifra da rendere, come invarianti `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ne consegue che `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // dividere `remainder` per `10^kappa`.entrambi sono ridimensionati da `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; abbiamo trovato l `kappa` corretto.
            let ten_kappa = (ten_kappa as u64) << e; // scala 10 ^ kappa all'esponente condiviso
            return round_and_weed(
                // SICUREZZA: abbiamo inizializzato quella memoria sopra.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // interrompere il ciclo quando abbiamo reso tutte le cifre integrali.
        // il numero esatto di cifre è `max_kappa + 1` come `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ripristinare le invarianti
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // eseguire il rendering di parti frazionarie, controllando la precisione in ogni passaggio.
    // questa volta ci affidiamo a moltiplicazioni ripetute, poiché la divisione perderà la precisione.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // la cifra successiva dovrebbe essere significativa poiché l'abbiamo testata prima di rompere gli invarianti, dove `m = max_kappa + 1` (numero di cifre nella parte integrale):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // non traboccherà, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // dividere `remainder` per `10^kappa`.
        // entrambi sono ridimensionati da `2^e / 10^kappa`, quindi quest'ultimo è implicito qui.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // divisore implicito
            return round_and_weed(
                // SICUREZZA: abbiamo inizializzato quella memoria sopra.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ripristinare le invarianti
        kappa -= 1;
        remainder = r;
    }

    // abbiamo generato tutte le cifre significative di `plus1`, ma non siamo sicuri che sia quella ottimale.
    // ad esempio, se `minus1` è 3.14153 ... e `plus1` è 3.14158 ..., ci sono 5 diverse rappresentazioni più brevi da 3.14154 a 3.14158 ma abbiamo solo quella più grande.
    // dobbiamo successivamente diminuire l'ultima cifra e controllare se questa è la riproduzione ottimale.
    // ci sono al massimo 9 candidati (da ..1 a ..9), quindi è abbastanza veloce.(Fase "rounding")
    //
    // la funzione controlla se questo repr "optimal" è effettivamente all'interno degli intervalli ulp, ed inoltre, è possibile che il repr "second-to-optimal" possa effettivamente essere ottimale a causa dell'errore di arrotondamento.
    // in entrambi i casi questo restituisce `None`.
    // (Fase "weeding")
    //
    // tutti gli argomenti qui sono scalati dal valore comune (ma implicito) `k`, in modo che:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (e anche `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (e anche `threshold > plus1v` da invarianti precedenti)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producono due approssimazioni a `v` (in realtà `plus1 - v`) all'interno di 1.5 ulps.
        // la rappresentazione risultante dovrebbe essere la rappresentazione più vicina a entrambi.
        //
        // qui viene utilizzato `plus1 - v` poiché i calcoli vengono eseguiti rispetto a `plus1` per evitare overflow/underflow (da cui i nomi apparentemente scambiati).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // diminuire l'ultima cifra e fermarsi alla rappresentazione più vicina a `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // lavoriamo con le cifre approssimative `w(n)`, che inizialmente è uguale a `plus1 - plus1 % 10^kappa`.dopo aver eseguito il corpo del ciclo `n` volte, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // impostiamo `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (quindi `remainder= plus1w(0)`) per semplificare i controlli.
            // notare che `plus1w(n)` è sempre in aumento.
            //
            // abbiamo tre condizioni per terminare.nessuno di questi renderà il ciclo incapace di procedere, ma abbiamo comunque almeno una rappresentazione valida nota per essere la più vicina a `v + 1 ulp`.
            // li indicheremo come da TC1 a TC3 per brevità.
            //
            // TC1: `w(n) <= v + 1 ulp`, ovvero, questa è l'ultima riproduzione che può essere la più vicina.
            // questo è equivalente a `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // combinato con TC2 (che controlla se `w(n+1)` is valid), questo impedisce il possibile overflow sul calcolo di `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, vale a dire, la prossima riproduzione sicuramente non si arrotonda a `v`.
            // questo è equivalente a `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // il lato sinistro può traboccare, ma sappiamo che `threshold > plus1v`, quindi se TC1 è falso, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` e possiamo tranquillamente testare se `threshold - plus1w(n) < 10^kappa` invece.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, cioè, la prossima riproduzione è
            // non più vicino a `v + 1 ulp` dell'attuale repr.
            // dato `z(n) = plus1v_up - plus1w(n)`, questo diventa `abs(z(n)) <= abs(z(n+1))`.assumendo ancora che TC1 sia falso, abbiamo `z(n) > 0`.abbiamo due casi da considerare:
            //
            // - quando `z(n+1) >= 0`: TC3 diventa `z(n) <= z(n+1)`.
            // poiché `plus1w(n)` è in aumento, `z(n)` dovrebbe diminuire e questo è chiaramente falso.
            // - quando `z(n+1) < 0`:
            //   - TC3a: il presupposto è `plus1v_up < plus1w(n) + 10^kappa`.supponendo che TC2 sia falso, `threshold >= plus1w(n) + 10^kappa` quindi non può overflow.
            //   - TC3b: TC3 diventa `z(n) <= -z(n+1)`, ovvero `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   l TC1 negato dà `plus1v_up > plus1w(n)`, quindi non può overflow o underflow se combinato con TC3a.
            //
            // di conseguenza, dovremmo fermarci quando `TC1 || TC2 || (TC3a && TC3b)`.il seguente è uguale al suo inverso, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // la riproduzione più breve non può terminare con `0`
                plus1w += ten_kappa;
            }
        }

        // controlla se questa rappresentazione è anche la rappresentazione più vicina a `v - 1 ulp`.
        //
        // questo è semplicemente lo stesso delle condizioni di terminazione per `v + 1 ulp`, con tutti gli `plus1v_up` sostituiti da `plus1v_down`.
        // vale anche per l'analisi dell'overflow.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ora abbiamo la rappresentazione più vicina a `v` tra `plus1` e `minus1`.
        // questo è troppo liberale, tuttavia, quindi rifiutiamo qualsiasi `w(n)` non compreso tra `plus0` e `minus0`, cioè `plus1 - plus1w(n) <= minus0` o `plus1 - plus1w(n) >= plus0`.
        // utilizziamo i fatti che `threshold = plus1 - minus1` e `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// L'implementazione della modalità più breve per Grisu con il fallback di Dragon.
///
/// Questo dovrebbe essere usato per la maggior parte dei casi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SICUREZZA: il controllo del prestito non è abbastanza intelligente da permetterci di utilizzare `buf`
    // nel secondo branch, quindi qui ricicliamo la vita.
    // Ma riutilizziamo `buf` solo se `format_shortest_opt` ha restituito `None`, quindi va bene.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// L'implementazione in modalità esatta e fissa per Grisu.
///
/// Restituisce `None` quando altrimenti restituirebbe una rappresentazione inesatta.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // abbiamo bisogno di almeno tre bit di precisione aggiuntiva
    assert!(!buf.is_empty());

    // normalizza e ridimensiona `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // dividere `v` in parti integrali e frazionarie.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // sia il vecchio `v` che il nuovo `v` (scalato da `10^-k`) hanno un errore di <1 ulp (Teorema 5.1).
    // siccome non sappiamo che l'errore è positivo o negativo, usiamo due approssimazioni equidistanti e abbiamo l'errore massimo di 2 ulps (uguale al caso più breve).
    //
    //
    // l'obiettivo è trovare la serie di cifre esattamente arrotondate che sono comuni sia a `v - 1 ulp` che a `v + 1 ulp`, in modo da avere la massima sicurezza.
    // se questo non è possibile, non sappiamo quale sia l'output corretto per `v`, quindi ci arrendiamo e torniamo indietro.
    //
    // `err` è definito come `1 ulp * 2^e` qui (come per ulp in `vfrac`), e lo scaleremo ogni volta che `v` viene ridimensionato.
    //
    //
    //
    let mut err = 1;

    // calcolare il più grande `10^max_kappa` non più di `v` (quindi `v < 10^(max_kappa+1)`).
    // questo è un limite superiore di `kappa` di seguito.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // se stiamo lavorando con la limitazione dell'ultima cifra, dobbiamo accorciare il buffer prima del rendering effettivo per evitare doppi arrotondamenti.
    //
    // nota che dobbiamo allargare nuovamente il buffer quando avviene l'arrotondamento!
    let len = if exp <= limit {
        // oops, non possiamo nemmeno produrre *una* cifra.
        // questo è possibile quando, diciamo, abbiamo qualcosa come 9.5 e viene arrotondato a 10.
        //
        // in linea di principio possiamo chiamare immediatamente `possibly_round` con un buffer vuoto, ma il ridimensionamento di `max_ten_kappa << e` di 10 può provocare un overflow.
        //
        // quindi siamo sciatti qui e ampliamo l'intervallo di errore di un fattore 10.
        // questo aumenterà il tasso di falsi negativi, ma solo molto,*molto* leggermente;
        // può avere una notevole importanza solo quando la mantissa è più grande di 60 bit.
        //
        // SICUREZZA: `len=0`, quindi l'obbligo di aver inizializzato questa memoria è banale.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // rendere parti integranti.
    // l'errore è interamente frazionario, quindi non è necessario verificarlo in questa parte.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cifre ancora da rendere
    loop {
        // abbiamo sempre almeno una cifra per rendere invarianti:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ne consegue che `remainder = vint % 10^(kappa+1)`)
        //
        //

        // dividere `remainder` per `10^kappa`.entrambi sono ridimensionati da `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // il buffer è pieno?eseguire la passata di arrotondamento con il resto.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SICUREZZA: abbiamo inizializzato `len` molti byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // interrompere il ciclo quando abbiamo reso tutte le cifre integrali.
        // il numero esatto di cifre è `max_kappa + 1` come `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ripristinare le invarianti
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // rendere le parti frazionarie.
    //
    // in linea di principio possiamo continuare fino all'ultima cifra disponibile e verificare la precisione.
    // sfortunatamente stiamo lavorando con interi di dimensione finita, quindi abbiamo bisogno di un criterio per rilevare l'overflow.
    // V8 utilizza `remainder > err`, che diventa falso quando le prime cifre significative `i` di `v - 1 ulp` e `v` differiscono.
    // tuttavia questo rifiuta troppi input altrimenti validi.
    //
    // poiché la fase successiva ha un corretto rilevamento dell'overflow, utilizziamo invece un criterio più rigoroso:
    // continuiamo fino a quando `err` supera `10^kappa / 2`, in modo che l'intervallo tra `v - 1 ulp` e `v + 1 ulp` contenga sicuramente due o più rappresentazioni arrotondate.
    //
    // questo è lo stesso dei primi due confronti da `possibly_round`, per riferimento.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianti, dove `m = max_kappa + 1` (numero di cifre nella parte integrale):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // non traboccherà, `2^e * 10 < 2^64`
        err *= 10; // non traboccherà, `err * 10 < 2^e * 5 < 2^64`

        // dividere `remainder` per `10^kappa`.
        // entrambi sono ridimensionati da `2^e / 10^kappa`, quindi quest'ultimo è implicito qui.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // il buffer è pieno?eseguire la passata di arrotondamento con il resto.
        if i == len {
            // SICUREZZA: abbiamo inizializzato `len` molti byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ripristinare le invarianti
        remainder = r;
    }

    // ulteriori calcoli sono inutili (`possibly_round` fallisce decisamente), quindi ci arrendiamo.
    return None;

    // abbiamo generato tutte le cifre richieste di `v`, che dovrebbero essere uguali anche alle cifre corrispondenti di `v - 1 ulp`.
    // ora controlliamo se esiste una rappresentazione univoca condivisa sia da `v - 1 ulp` che da `v + 1 ulp`;questo può essere uguale alle cifre generate o alla versione arrotondata di quelle cifre.
    //
    // se l'intervallo contiene più rappresentazioni della stessa lunghezza, non possiamo esserne sicuri e dovremmo invece restituire `None`.
    //
    // tutti gli argomenti qui sono scalati dal valore comune (ma implicito) `k`, in modo che:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SICUREZZA: i primi `len` byte di `buf` devono essere inizializzati.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (per il riferimento, la linea tratteggiata indica il valore esatto per le possibili rappresentazioni in un dato numero di cifre.)
        //
        //
        // l'errore è troppo grande perché ci siano almeno tre possibili rappresentazioni tra `v - 1 ulp` e `v + 1 ulp`.
        // non possiamo determinare quale sia quella corretta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // infatti, 1/2 ulp è sufficiente per introdurre due possibili rappresentazioni.
        // (ricorda che abbiamo bisogno di una rappresentazione univoca sia per `v - 1 ulp` che per `v + 1 ulp`.) questo non andrà in overflow, come `ulp < ten_kappa` dal primo controllo.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // se `v + 1 ulp` è più vicino alla rappresentazione arrotondata per difetto (che è già in `buf`), allora possiamo tranquillamente tornare.
        // si noti che `v - 1 ulp`*può* essere inferiore alla rappresentazione corrente, ma come `1 ulp < 10^kappa / 2`, questa condizione è sufficiente:
        // la distanza tra `v - 1 ulp` e la rappresentazione corrente non può superare `10^kappa / 2`.
        //
        // la condizione è uguale a `remainder + ulp < 10^kappa / 2`.
        // poiché questo può facilmente traboccare, prima controlla se `remainder < 10^kappa / 2`.
        // abbiamo già verificato che `ulp < 10^kappa / 2`, quindi finché `10^kappa` non è andato in overflow, il secondo controllo va bene.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SICUREZZA: il nostro chiamante ha inizializzato quella memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resto------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // d'altra parte, se `v - 1 ulp` è più vicino alla rappresentazione arrotondata per eccesso, dovremmo arrotondare per eccesso e tornare.
        // per lo stesso motivo non è necessario controllare `v + 1 ulp`.
        //
        // la condizione è uguale a `remainder - ulp >= 10^kappa / 2`.
        // di nuovo controlliamo prima se `remainder > ulp` (nota che questo non è `remainder >= ulp`, poiché `10^kappa` non è mai zero).
        //
        // notare anche che `remainder - ulp <= 10^kappa`, quindi il secondo controllo non va in overflow.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SICUREZZA: il nostro chiamante deve aver inizializzato quella memoria.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // aggiungi una cifra aggiuntiva solo quando ci è stata richiesta la precisione fissa.
                // dobbiamo anche verificare che, se il buffer originale era vuoto, la cifra aggiuntiva può essere aggiunta solo quando `exp == limit` (caso edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SICUREZZA: noi e il nostro chiamante abbiamo inizializzato quella memoria.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // altrimenti siamo condannati (cioè, alcuni valori tra `v - 1 ulp` e `v + 1 ulp` vengono arrotondati per difetto e altri vengono arrotondati per eccesso) e ci arrendiamo.
        //
        None
    }
}

/// L'implementazione della modalità esatta e fissa per Grisu con il fallback di Dragon.
///
/// Questo dovrebbe essere usato per la maggior parte dei casi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SICUREZZA: il controllo del prestito non è abbastanza intelligente da permetterci di utilizzare `buf`
    // nel secondo branch, quindi qui ricicliamo la vita.
    // Ma riutilizziamo `buf` solo se `format_exact_opt` ha restituito `None`, quindi va bene.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}