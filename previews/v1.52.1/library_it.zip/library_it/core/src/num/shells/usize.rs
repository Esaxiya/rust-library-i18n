//! Costanti per il tipo intero senza segno della dimensione di un puntatore.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Il nuovo codice dovrebbe utilizzare le costanti associate direttamente sul tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }