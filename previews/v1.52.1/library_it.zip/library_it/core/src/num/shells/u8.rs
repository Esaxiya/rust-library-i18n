//! Costanti per il tipo intero senza segno a 8 bit.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Il nuovo codice dovrebbe utilizzare le costanti associate direttamente sul tipo primitivo.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }