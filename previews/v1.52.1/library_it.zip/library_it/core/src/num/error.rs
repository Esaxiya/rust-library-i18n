//! Tipi di errore per la conversione in tipi integrali.

use crate::convert::Infallible;
use crate::fmt;

/// Il tipo di errore restituito quando una conversione di tipo integrale controllato non riesce.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Abbina piuttosto che forzare per assicurarti che il codice come `From<Infallible> for TryFromIntError` sopra continuerà a funzionare quando `Infallible` diventa un alias di `!`.
        //
        //
        match never {}
    }
}

/// Un errore che può essere restituito durante l'analisi di un numero intero.
///
/// Questo errore viene utilizzato come tipo di errore per le funzioni `from_str_radix()` sui tipi interi primitivi, come [`i8::from_str_radix`].
///
/// # Possibili cause
///
/// Tra le altre cause, `ParseIntError` può essere lanciato a causa di spazi bianchi iniziali o finali nella stringa, ad esempio quando viene ottenuto dallo standard input.
///
/// L'utilizzo del metodo [`str::trim()`] garantisce che non rimangano spazi vuoti prima dell'analisi.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum per memorizzare i vari tipi di errori che possono causare il fallimento dell'analisi di un numero intero.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Il valore da analizzare è vuoto.
    ///
    /// Tra le altre cause, questa variante verrà costruita durante l'analisi di una stringa vuota.
    Empty,
    /// Contiene una cifra non valida nel suo contesto.
    ///
    /// Tra le altre cause, questa variante verrà costruita durante l'analisi di una stringa che contiene un carattere non ASCII.
    ///
    /// Questa variante viene costruita anche quando un `+` o `-` è posizionato in modo errato all'interno di una stringa da solo o nel mezzo di un numero.
    ///
    ///
    InvalidDigit,
    /// Il numero intero è troppo grande per essere memorizzato nel tipo intero di destinazione.
    PosOverflow,
    /// Il numero intero è troppo piccolo per essere memorizzato nel tipo intero di destinazione.
    NegOverflow,
    /// Il valore era zero
    ///
    /// Questa variante verrà emessa quando la stringa di analisi ha un valore di zero, che sarebbe illegale per i tipi diversi da zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Restituisce la causa dettagliata dell'analisi di un numero intero non riuscito.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}