//! Funzioni di utilità per bignum che non hanno molto senso da trasformare in metodi.

// FIXME Il nome di questo modulo è un po 'sfortunato, poiché anche altri moduli importano `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Verifica se il troncamento di tutti i bit meno significativi di `ones_place` introduce un errore relativo minore, uguale o maggiore di 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Se tutti i bit rimanenti sono zero, è= 0.5 ULP, altrimenti> 0.5 Se non ci sono più bit (half_bit==0), anche il sotto restituisce correttamente Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Converte una stringa ASCII contenente solo cifre decimali in un `u64`.
///
/// Non esegue controlli per overflow o caratteri non validi, quindi se il chiamante non sta attento, il risultato è falso e può panic (anche se non sarà `unsafe`).
/// Inoltre, le stringhe vuote vengono considerate zero.
/// Questa funzione esiste perché
///
/// 1. l'utilizzo di `FromStr` su `&[u8]` richiede `from_utf8_unchecked`, che non è valido, e
/// 2. mettere insieme i risultati di `integral.parse()` e `fractional.parse()` è più complicato di questa intera funzione.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Converte una stringa di cifre ASCII in un bignum.
///
/// Come `from_str_unchecked`, questa funzione si basa sul parser per eliminare le non cifre.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Decomprime un bignum in un intero a 64 bit.Panics se il numero è troppo grande.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Estrae una serie di bit.

/// L'indice 0 è il bit meno significativo e l'intervallo è semiaperto come al solito.
/// Panics se viene chiesto di estrarre più bit di quelli che rientrano nel tipo restituito.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}