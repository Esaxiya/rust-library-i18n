//! Un po 'giocherellare con i float positivi IEEE 754.I numeri negativi non sono e non devono essere gestiti.
//! I normali numeri in virgola mobile hanno una rappresentazione canonica come (frac, exp) tale che il valore è 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) dove N è il numero di bit.
//!
//! I subnormali sono leggermente diversi e strani, ma si applica lo stesso principio.
//!
//! Qui, tuttavia, li rappresentiamo come (sig, k) con f positivo, in modo tale che il valore sia f *
//! 2 <sup>e</sup> .Oltre a rendere esplicito l "hidden bit", questo cambia l'esponente tramite il cosiddetto spostamento della mantissa.
//!
//! In altre parole, normalmente i float sono scritti come (1) ma qui sono scritti come (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Chiamiamo (1) la **rappresentazione frazionaria** e (2) la **rappresentazione integrale**.
//!
//! Molte funzioni in questo modulo gestiscono solo numeri normali.Le routine dec2flt seguono conservativamente il percorso lento universalmente corretto (Algoritmo M) per numeri molto piccoli e molto grandi.
//! Quell'algoritmo necessita solo di next_float() che gestisce subnormali e zeri.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Un aiuto trait per evitare di duplicare praticamente tutto il codice di conversione per `f32` e `f64`.
///
/// Vedere il commento alla documentazione del modulo genitore per sapere perché è necessario.
///
/// Non dovrebbe **mai e poi mai** essere implementato per altri tipi o essere usato al di fuori del modulo dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tipo utilizzato da `to_bits` e `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Esegue una trasmutazione grezza in un numero intero.
    fn to_bits(self) -> Self::Bits;

    /// Esegue una trasmutazione grezza da un numero intero.
    fn from_bits(v: Self::Bits) -> Self;

    /// Restituisce la categoria in cui rientra questo numero.
    fn classify(self) -> FpCategory;

    /// Restituisce la mantissa, l'esponente e il segno come numeri interi.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Decodifica il float.
    fn unpack(self) -> Unpacked;

    /// Esegue il cast da un piccolo numero intero che può essere rappresentato esattamente.
    /// Panic se il numero intero non può essere rappresentato, l'altro codice in questo modulo si assicura che non accada mai.
    fn from_int(x: u64) -> Self;

    /// Ottiene il valore 10 <sup>e</sup> da una tabella precalcolata.
    /// Panics per `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Cosa dice il nome.
    /// È più facile codificare in modo rigido che destreggiarsi tra intrinseci e sperare che la costante LLVM lo pieghi.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Un limite conservativo sulle cifre decimali degli input che non possono produrre overflow o zero o
    /// subnormali.Probabilmente l'esponente decimale del valore normale massimo, da cui il nome.
    const MAX_NORMAL_DIGITS: usize;

    /// Quando la cifra decimale più significativa ha un valore di posizione maggiore di questo, il numero viene certamente arrotondato all'infinito.
    ///
    const INF_CUTOFF: i64;

    /// Quando la cifra decimale più significativa ha un valore di posizione inferiore a questo, il numero viene certamente arrotondato a zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Il numero di bit nell'esponente.
    const EXP_BITS: u8;

    /// Il numero di bit nel significante,*incluso* il bit nascosto.
    const SIG_BITS: u8;

    /// Il numero di bit nel significante,*escluso* il bit nascosto.
    const EXPLICIT_SIG_BITS: u8;

    /// Il massimo esponente legale nella rappresentazione frazionaria.
    const MAX_EXP: i16;

    /// L'esponente legale minimo nella rappresentazione frazionaria, esclusi i subnormali.
    const MIN_EXP: i16;

    /// `MAX_EXP` per la rappresentazione integrale, cioè con lo spostamento applicato.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` codificato (cioè, con offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` per la rappresentazione integrale, cioè con lo spostamento applicato.
    const MIN_EXP_INT: i16;

    /// Il massimo significato normalizzato nella rappresentazione integrale.
    const MAX_SIG: u64;

    /// Il significato normalizzato minimo nella rappresentazione integrale.
    const MIN_SIG: u64;
}

// Principalmente una soluzione alternativa per #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Restituisce la mantissa, l'esponente e il segno come numeri interi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bias esponente + spostamento mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe è incerto se `as` arrotonda correttamente su tutte le piattaforme.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Restituisce la mantissa, l'esponente e il segno come numeri interi.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bias esponente + spostamento mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe è incerto se `as` arrotonda correttamente su tutte le piattaforme.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Converte un `Fp` nel tipo float della macchina più vicino.
/// Non gestisce risultati subnormali.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f è 64 bit, quindi xe ha uno spostamento della mantissa di 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Arrotonda il significato a 64 bit a T::SIG_BITS bit con metà pari.
/// Non gestisce l'overflow degli esponenti.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Regola lo spostamento della mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inversa di `RawFloat::unpack()` per i numeri normalizzati.
/// Panics se il significante o l'esponente non sono validi per i numeri normalizzati.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Rimuovi la parte nascosta
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Regola l'esponente per la distorsione esponente e lo spostamento della mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lascia il bit di segno a 0 ("+"), i nostri numeri sono tutti positivi
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Costruisci un subnormale.Una mantissa di 0 è consentita e costruisce zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // L'esponente codificato è 0, il bit del segno è 0, quindi dobbiamo solo reinterpretare i bit.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Approssimare un bignum con un Fp.Arrotonda entro 0.5 ULP da metà a pari.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Abbiamo tagliato tutti i bit prima dell'indice `start`, cioè, effettivamente spostiamo a destra di una quantità di `start`, quindi questo è anche l'esponente di cui abbiamo bisogno.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) a seconda dei bit troncati.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Trova il numero in virgola mobile più grande strettamente più piccolo dell'argomento.
/// Non gestisce subnormali, zero o underflow esponente.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Trova il numero in virgola mobile più piccolo strettamente più grande dell'argomento.
// Questa operazione è saturante, cioè next_float(inf) ==inf.
// A differenza della maggior parte del codice in questo modulo, questa funzione gestisce zero, subnormali e infiniti.
// Tuttavia, come tutti gli altri codici qui, non si occupa di NaN e numeri negativi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Sembra troppo bello per essere vero, ma funziona.
        // 0.0 è codificato come la parola tutto zero.I subnormali sono 0x000m ... m dove m è la mantissa.
        // In particolare, il subnormale più piccolo è 0x0 ... 01 e il più grande è 0x000F ... F.
        // Il numero normale più piccolo è 0x0010 ... 0, quindi anche questo caso d'angolo funziona.
        // Se l'incremento supera la mantissa, il bit di riporto incrementa l'esponente come vogliamo e i bit di mantissa diventano zero.
        // A causa della convenzione dei bit nascosti, anche questo è esattamente quello che vogliamo!
        // Infine, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}