//! I vari algoritmi tratti dalla carta.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Numero di bit significativi in Fp
const P: u32 = 64;

// Memorizziamo semplicemente la migliore approssimazione per *tutti* gli esponenti, in modo che la variabile "h" e le condizioni associate possano essere omesse.
// Questo scambia le prestazioni per un paio di kilobyte di spazio.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Nella maggior parte delle architetture, le operazioni in virgola mobile hanno una dimensione di bit esplicita, quindi la precisione del calcolo è determinata in base all'operazione.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Su x86, l x87 FPU viene utilizzato per le operazioni float se le estensioni SSE/SSE2 non sono disponibili.
// L'FPU x87 funziona con 80 bit di precisione per impostazione predefinita, il che significa che le operazioni verranno arrotondate a 80 bit causando il doppio arrotondamento quando i valori vengono infine rappresentati come
//
// 32/64 valori in virgola mobile.Per ovviare a ciò, la parola di controllo FPU può essere impostata in modo che i calcoli vengano eseguiti con la precisione desiderata.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Una struttura utilizzata per preservare il valore originale della parola di controllo FPU, in modo che possa essere ripristinata quando la struttura viene abbandonata.
    ///
    ///
    /// L x87 FPU è un registro a 16 bit i cui campi sono i seguenti:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// La documentazione per tutti i campi è disponibile nel IA-32 Architectures Software Developer's Manual (Volume 1).
    ///
    /// L'unico campo rilevante per il codice seguente è PC, Precision Control.
    /// Questo campo determina la precisione delle operazioni eseguite dalla FPU.
    /// Può essere impostato su:
    ///  - 0b00, precisione singola, ovvero 32 bit
    ///  - 0b10, doppia precisione, ovvero 64 bit
    ///  - 0b11, doppia precisione estesa, ovvero 80 bit (stato predefinito) Il valore 0b01 è riservato e non deve essere utilizzato.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SICUREZZA: l'istruzione `fldcw` è stata verificata per poter funzionare correttamente con
        // qualsiasi `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Stiamo usando la sintassi ATT per supportare LLVM 8 e LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Imposta il campo di precisione della FPU su `T` e restituisce un `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Calcola il valore per il campo Controllo precisione appropriato per `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // predefinito, 80 bit
        };

        // Ottenere il valore originale della parola di controllo per ripristinarlo in seguito, quando la struttura `FPUControlWord` viene abbandonata SICUREZZA: l'istruzione `fnstcw` è stata verificata per poter funzionare correttamente con qualsiasi `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Stiamo usando la sintassi ATT per supportare LLVM 8 e LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Impostare la parola di controllo sulla precisione desiderata.
        // Ciò si ottiene mascherando la vecchia precisione (bit 8 e 9, 0x300) e sostituendola con il flag di precisione calcolato sopra.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Il percorso veloce di Bellerophon utilizzando numeri interi e float di dimensioni macchina.
///
/// Questo viene estratto in una funzione separata in modo che possa essere tentato prima di costruire un bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Confrontiamo il valore esatto con MAX_SIG verso la fine, questo è solo un rifiuto rapido ed economico (e libera anche il resto del codice dalla preoccupazione dell'underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Il percorso veloce dipende in modo cruciale dall'aritmetica che viene arrotondata al numero corretto di bit senza alcun arrotondamento intermedio.
    // Su x86 (senza SSE o SSE2) ciò richiede la modifica della precisione dello stack FPU x87 in modo che venga arrotondato direttamente al bit 64/32.
    // La funzione `set_precision` si occupa di impostare la precisione sulle architetture che la richiedono modificando lo stato globale (come la parola di controllo dell x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // La custodia e <0 non può essere piegata nell'altro branch.
    // I poteri negativi si traducono in una parte frazionaria ripetuta in binario, che viene arrotondata, il che causa errori reali (e talvolta piuttosto significativi!) Nel risultato finale.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// L'algoritmo Bellerophon è un codice banale giustificato da un'analisi numerica non banale.
///
/// Arrotonda `` f '' a un float con significato a 64 bit e lo moltiplica per la migliore approssimazione di `10^e` (nello stesso formato in virgola mobile).Questo è spesso sufficiente per ottenere il risultato corretto.
/// Tuttavia, quando il risultato è vicino alla metà tra due numeri (ordinary) adiacenti, l'errore di arrotondamento composto derivante dalla moltiplicazione di due approssimazioni significa che il risultato potrebbe essere sfasato di pochi bit.
/// Quando ciò accade, l'algoritmo iterativo R risolve le cose.
///
/// L "close to halfway" ondulato a mano è reso preciso dall'analisi numerica nella carta.
/// Nelle parole di Clinger:
///
/// > Slop, espresso in unità del bit meno significativo, è un limite inclusivo per l'errore
/// > accumulato durante il calcolo in virgola mobile dell'approssimazione af * 10 ^ e.(Slop è
/// > non è un limite per il vero errore, ma delimita la differenza tra l'approssimazione ze
/// > la migliore approssimazione possibile che utilizza p bit di significante.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // I casi abs(e) <log5(2^N) sono in fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Lo slop è abbastanza grande da fare la differenza quando si arrotonda ad n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Un algoritmo iterativo che migliora un'approssimazione in virgola mobile di `f * 10^e`.
///
/// Ogni iterazione avvicina un'unità all'ultimo posto, il che ovviamente richiede molto tempo per convergere se `z0` è anche leggermente spento.
/// Fortunatamente, quando viene utilizzato come riserva per Bellerophon, l'approssimazione iniziale è al massimo di un ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Trova numeri interi positivi `x`, `y` tali che `x / y` sia esattamente `(f *10^e) / (m* 2^k)`.
        // Questo non solo evita di affrontare i segni di `e` e `k`, ma elimina anche la potenza di due comuni a `10^e` e `2^k` per ridurre i numeri.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Questo è scritto in modo un po 'imbarazzante perché i nostri bignum non supportano i numeri negativi, quindi usiamo il valore assoluto + le informazioni sul segno.
        // La moltiplicazione con m_digits non può traboccare.
        // Se `x` o `y` sono abbastanza grandi da doverci preoccupare dell'overflow, allora sono anche abbastanza grandi che `make_ratio` ha ridotto la frazione di un fattore 2 ^ 64 o più.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Non hai più bisogno di x, salva un clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ho ancora bisogno di te, fai una copia.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Dato `x = f` e `y = m` dove `f` rappresentano le cifre decimali di input come al solito e `m` è il significato di un'approssimazione in virgola mobile, rendere il rapporto `x / y` uguale a `(f *10^e) / (m* 2^k)`, eventualmente ridotto di una potenza di due che entrambi hanno in comune.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, tranne per il fatto che riduciamo la frazione di una potenza di due.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Questo non può eccedere perché richiede `e` positivo e `k` negativo, il che può accadere solo per valori estremamente vicini a 1, il che significa che `e` e `k` saranno relativamente piccoli.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Anche questo non può traboccare, vedi sopra.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), riducendo nuovamente di una potenza comune di due.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Concettualmente, l'algoritmo M è il modo più semplice per convertire un decimale in un float.
///
/// Formiamo un rapporto che è uguale a `f * 10^e`, quindi lanciamo potenze di due fino a quando non fornisce un significato float valido.
/// L'esponente binario `k` è il numero di volte in cui abbiamo moltiplicato il numeratore o il denominatore per due, cioè in ogni momento `f *10^e` è uguale a `(u / v)* 2^k`.
/// Quando abbiamo scoperto il significato, dobbiamo solo arrotondare ispezionando il resto della divisione, che viene fatto nelle funzioni di supporto più in basso.
///
///
/// Questo algoritmo è super lento, anche con l'ottimizzazione descritta in `quick_start()`.
/// Tuttavia, è il più semplice degli algoritmi da adattare per risultati di overflow, underflow e subnormali.
/// Questa implementazione prende il sopravvento quando Bellerophon e Algorithm R vengono sopraffatti.
/// Rilevare underflow e overflow è facile: il rapporto non è ancora un significato compreso nell'intervallo, ma è stato raggiunto l'esponente minimum/maximum.
/// In caso di overflow, restituiamo semplicemente infinity.
///
/// Gestire underflow e subnormali è più complicato.
/// Un grosso problema è che, con l'esponente minimo, il rapporto potrebbe essere ancora troppo grande per un significante.
/// Vedere underflow() per i dettagli.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME possibile ottimizzazione: generalizza big_to_fp in modo da poter fare qui l'equivalente di fp_to_float(big_to_fp(u)), solo senza il doppio arrotondamento.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Dobbiamo fermarci all'esponente minimo, se aspettiamo fino a `k < T::MIN_EXP_INT`, saremmo fuori di un fattore due.
            // Sfortunatamente questo significa che dobbiamo usare numeri normali in casi speciali con l'esponente minimo.
            // FIXME trova una formulazione più elegante, ma esegui il test `tiny-pow10` per assicurarti che sia effettivamente corretta!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Salta la maggior parte delle iterazioni dell'algoritmo controllando la lunghezza del bit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // La lunghezza in bit è una stima del logaritmo in base due e log(u / v) = log(u), log(v).
    // La stima è al massimo di 1, ma sempre una sottovalutazione, quindi l'errore su log(u) e log(v) sono dello stesso segno e si annullano (se entrambi sono grandi).
    // Pertanto anche l'errore per log(u / v) è al massimo uno.
    // Il rapporto target è quello in cui u/v è in un significato compreso nell'intervallo.Quindi la nostra condizione di terminazione è log2(u / v) per i bit significativi, plus/minus uno.
    // FIXME Guardando il secondo bit potrebbe migliorare la stima ed evitare alcune ulteriori divisioni.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow o subnormale.Lascialo alla funzione principale.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Overflow.Lascialo alla funzione principale.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Il rapporto non è un significato compreso nell'intervallo con l'esponente minimo, quindi è necessario arrotondare i bit in eccesso e regolare l'esponente di conseguenza.
    // Il valore reale ora assomiglia a questo:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(rappresentato da rem)
    //
    // Pertanto, quando i bit arrotondati sono!= 0.5 ULP, decidono autonomamente l'arrotondamento.
    // Quando sono uguali e il resto è diverso da zero, il valore deve comunque essere arrotondato per eccesso.
    // Solo quando i bit arrotondati sono 1/2 e il resto è zero, abbiamo una situazione da metà a pari.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Ordinario round-to-even, offuscato dalla necessità di arrotondare in base al resto di una divisione.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}