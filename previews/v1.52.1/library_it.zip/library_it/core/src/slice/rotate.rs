// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ruota l'intervallo `[mid-left, mid+right)` in modo tale che l'elemento in `mid` diventi il primo elemento.In modo equivalente, ruota gli elementi dell'intervallo `left` a sinistra o gli elementi `right` a destra.
///
/// # Safety
///
/// L'intervallo specificato deve essere valido per la lettura e la scrittura.
///
/// # Algorithm
///
/// L'algoritmo 1 viene utilizzato per valori piccoli di `left + right` o per `T` grandi.
/// Gli elementi vengono spostati nelle loro posizioni finali uno alla volta a partire da `mid - left` e avanzando di passi `right` modulo `left + right`, in modo tale che sia necessario solo un temporaneo.
/// Alla fine, torniamo a `mid - left`.
/// Tuttavia, se `gcd(left + right, right)` non è 1, i passaggi precedenti hanno saltato gli elementi.
/// Per esempio:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Fortunatamente, il numero di elementi saltati tra gli elementi finalizzati è sempre uguale, quindi possiamo semplicemente compensare la nostra posizione iniziale e fare più round (il numero totale di round è `gcd(left + right, right)` value).
///
/// Il risultato finale è che tutti gli elementi vengono finalizzati una sola volta.
///
/// L'algoritmo 2 viene utilizzato se `left + right` è grande ma `min(left, right)` è abbastanza piccolo da stare in uno stack buffer.
/// Gli elementi `min(left, right)` vengono copiati nel buffer, `memmove` viene applicato agli altri e quelli sul buffer vengono spostati nuovamente nel foro sul lato opposto rispetto a dove hanno avuto origine.
///
/// Gli algoritmi che possono essere vettorizzati superano i precedenti una volta che `left + right` diventa abbastanza grande.
/// L'algoritmo 1 può essere vettorializzato suddividendo ed eseguendo molti round contemporaneamente, ma in media ci sono troppo pochi round finché `left + right` non è enorme e il caso peggiore di un singolo round è sempre presente.
/// Al contrario, l'algoritmo 3 utilizza lo scambio ripetuto di elementi `min(left, right)` fino a quando non rimane un problema di rotazione più piccolo.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// quando `left < right` lo scambio avviene invece da sinistra.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. gli algoritmi seguenti possono fallire se questi casi non vengono controllati
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmo 1 I microbenchmark indicano che le prestazioni medie per i turni casuali sono migliori fino a circa `left + right == 32`, ma le prestazioni del caso peggiore si attestano intorno a 16.
            // 24 è stato scelto come via di mezzo.
            // Se la dimensione di `T` è maggiore di 4 `usize`s, questo algoritmo supera anche altri algoritmi.
            //
            //
            let x = unsafe { mid.sub(left) };
            // inizio del primo round
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` può essere trovato prima calcolando `gcd(left + right, right)`, ma è più veloce fare un ciclo che calcola il gcd come effetto collaterale, quindi fare il resto del pezzo
            //
            //
            let mut gcd = right;
            // i benchmark rivelano che è più veloce scambiare completamente i provvisori invece di leggerne uno temporaneo una volta, copiarlo all'indietro e poi scrivere quello temporaneo alla fine.
            // Ciò è probabilmente dovuto al fatto che lo scambio o la sostituzione dei provvisori utilizza un solo indirizzo di memoria nel ciclo invece di doverne gestire due.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // invece di incrementare `i` e quindi controllare se è fuori dai limiti, controlliamo se `i` uscirà dai limiti all'incremento successivo.
                // Ciò impedisce qualsiasi avvolgimento di puntatori o `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fine del primo round
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // questo condizionale deve essere qui se `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // finire il pezzo con più giri
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` non è un tipo di dimensione zero, quindi va bene dividere per la sua dimensione.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmo 2 L `[T; 0]` qui serve a garantire che sia allineato in modo appropriato per T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmo 3 Esiste un modo alternativo di scambiare che implica trovare dove sarebbe l'ultimo scambio di questo algoritmo e scambiare utilizzando l'ultimo pezzo invece di scambiare pezzi adiacenti come sta facendo questo algoritmo, ma in questo modo è ancora più veloce.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmo 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}