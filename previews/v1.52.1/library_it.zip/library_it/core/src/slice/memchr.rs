// Implementazione originale tratta da rust-memchr.
// Copyright 2015 Andrew Gallant, bluss e Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Usa il troncamento.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Restituisce `true` se `x` contiene un byte zero.
///
/// Da *Matters Computational*, J. Arndt:
///
/// "L'idea è di sottrarre uno da ciascuno dei byte e quindi cercare i byte in cui il prestito si è propagato fino al più significativo
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Restituisce il primo indice che corrisponde al byte `x` in `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Percorso veloce per piccole fette
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Cerca un valore a byte singolo leggendo due parole `usize` alla volta.
    //
    // Dividi `text` in tre parti
    // - parte iniziale non allineata, prima dell'indirizzo della prima parola allineata nel testo
    // - corpo, eseguire la scansione di 2 parole alla volta
    // - l'ultima parte rimanente, <2 parole

    // ricerca fino a un confine allineato
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // cerca nel corpo del testo
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SICUREZZA: il predicato di while garantisce una distanza di almeno 2 * usize_bytes
        // tra l'offset e la fine della fetta.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break se c'è un byte corrispondente
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Trova il byte dopo il punto in cui il body loop si è fermato.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Restituisce l'ultimo indice che corrisponde al byte `x` in `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Cerca un valore a byte singolo leggendo due parole `usize` alla volta.
    //
    // Dividi `text` in tre parti:
    // - coda non allineata, dopo l'ultima parola allineata indirizzo nel testo,
    // - corpo, scandito da 2 parole alla volta,
    // - i primi byte rimanenti, <2 parole di dimensione.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Lo chiamiamo solo per ottenere la lunghezza del prefisso e del suffisso.
        // Nel mezzo elaboriamo sempre due blocchi contemporaneamente.
        // SICUREZZA: la trasmissione da `[u8]` a `[usize]` è sicura tranne che per le differenze di dimensioni gestite da `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Cerca nel corpo del testo, assicurati di non incrociare min_aligned_offset.
    // offset è sempre allineato, quindi è sufficiente testare `>` ed evitare possibili overflow.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SICUREZZA: l'offset parte da len, suffix.len(), purché sia maggiore di
        // min_aligned_offset (prefix.len()) la distanza rimanente è almeno 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Interrompi se c'è un byte corrispondente.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Trova il byte prima del punto in cui il body loop si è fermato.
    text[..offset].iter().rposition(|elt| *elt == x)
}