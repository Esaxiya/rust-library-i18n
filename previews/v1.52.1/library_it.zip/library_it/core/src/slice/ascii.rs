//! Operazioni su ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Verifica se tutti i byte in questa sezione rientrano nell'intervallo ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Verifica che due sezioni siano una corrispondenza ASCII senza distinzione tra maiuscole e minuscole.
    ///
    /// Come `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ma senza allocare e copiare i provvisori.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Converte questa sezione nel suo equivalente in maiuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'a' a 'z' vengono mappate da 'A' a 'Z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore maiuscolo senza modificare quello esistente, utilizzare [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Converte questa sezione nel suo equivalente in minuscolo ASCII sul posto.
    ///
    /// Le lettere ASCII da 'A' a 'Z' vengono mappate da 'a' a 'z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per restituire un nuovo valore minuscolo senza modificare quello esistente, utilizzare [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Restituisce `true` se qualsiasi byte nella parola `v` è nonascii (>=128).
/// Snarfed da `../str/mod.rs`, che fa qualcosa di simile per la convalida utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Test ASCII ottimizzato che utilizzerà operazioni usize-at-a-time invece di operazioni byte-at-a-time (quando possibile).
///
/// L'algoritmo che usiamo qui è piuttosto semplice.Se `s` è troppo corto, controlliamo semplicemente ogni byte e finiamo con esso.Altrimenti:
///
/// - Leggi la prima parola con un carico non allineato.
/// - Allinea il puntatore, leggi le parole successive fino alla fine con carichi allineati.
/// - Leggi l'ultimo `usize` da `s` con un carico non allineato.
///
/// Se uno di questi carichi produce qualcosa per cui `contains_nonascii` (above) restituisce true, allora sappiamo che la risposta è falsa.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Se non ottenessimo nulla dall'implementazione parola alla volta, torniamo a un ciclo scalare.
    //
    // Lo facciamo anche per architetture in cui `size_of::<usize>()` non è allineamento sufficiente per `usize`, perché è uno strano caso edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Leggiamo sempre la prima parola non allineata, il che significa che `align_offset` lo è
    // 0, avremmo letto di nuovo lo stesso valore per la lettura allineata.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SICUREZZA: Verifichiamo `len < USIZE_SIZE` sopra.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Lo abbiamo verificato sopra, in modo piuttosto implicito.
    // Nota che `offset_to_aligned` è `align_offset` o `USIZE_SIZE`, entrambi sono esplicitamente selezionati sopra.
    //
    debug_assert!(offset_to_aligned <= len);

    // SICUREZZA: word_ptr è il ptr usize (correttamente allineato) che usiamo per leggere il file
    // pezzo medio della fetta.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` è l'indice di byte di `word_ptr`, utilizzato per i controlli di fine ciclo.
    let mut byte_pos = offset_to_aligned;

    // Controllo della paranoia sull'allineamento, dato che stiamo per eseguire un mucchio di carichi non allineati.
    // In pratica questo dovrebbe essere impossibile a parte un bug in `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Leggere le parole successive fino all'ultima parola allineata, escludendo l'ultima parola allineata da sola da eseguire in seguito nel controllo della coda, per assicurarsi che la coda sia sempre una `usize` al massimo per branch `byte_pos == len` extra.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Verifica della sanità mentale che la lettura sia entro i limiti
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // E che le nostre ipotesi su `byte_pos` sono valide.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SICUREZZA: sappiamo che `word_ptr` è correttamente allineato (a causa di
        // `align_offset`), e sappiamo di avere abbastanza byte tra `word_ptr` e la fine
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SICUREZZA: sappiamo che `byte_pos <= len - USIZE_SIZE`, il che significa che
        // dopo questo `add`, `word_ptr` sarà al massimo uno oltre la fine.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Verifica dell'integrità per assicurarti che sia rimasto solo un `usize`.
    // Questo dovrebbe essere garantito dalla nostra condizione di loop.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SICUREZZA: si basa su `len >= USIZE_SIZE`, che controlliamo all'inizio.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}