// ignore-tidy-filelength

//! Gestione e manipolazione delle sezioni.
//!
//! Per maggiori dettagli vedere [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Pure rust memchr implementazione, presa da rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Questa funzione è pubblica solo perché non esiste un altro modo per eseguire lo unit test heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Restituisce il numero di elementi nella sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SICUREZZA: suono costante perché trasmutiamo il campo della lunghezza come una dimensione (che deve essere)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SICUREZZA: questo è sicuro perché `&[T]` e `FatPtr<T>` hanno lo stesso layout.
            // Solo `std` può fornire questa garanzia.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Sostituisci con `crate::ptr::metadata(self)` quando è const-stabile.
            // Al momento della stesura di questo articolo, ciò causa un errore "Const-stable functions can only call other const-stable functions".
            //

            // SICUREZZA: l'accesso al valore dall'unione `PtrRepr` è sicuro poiché * const T
            // e PtrComponents<T>hanno gli stessi layout di memoria.
            // Solo std può fornire questa garanzia.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Restituisce `true` se la sezione ha una lunghezza pari a 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Restituisce il primo elemento della slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Restituisce un puntatore modificabile al primo elemento della sezione o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Restituisce il primo e tutti gli altri elementi dello slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Restituisce il primo e tutti gli altri elementi dello slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Restituisce l'ultimo e tutti gli altri elementi dello slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Restituisce l'ultimo e tutti gli altri elementi dello slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Restituisce l'ultimo elemento della slice o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Restituisce un puntatore modificabile all'ultimo elemento nella sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Restituisce un riferimento a un elemento o una sottosezione a seconda del tipo di indice.
    ///
    /// - Se viene data una posizione, restituisce un riferimento all'elemento in quella posizione o `None` se fuori dai limiti.
    ///
    /// - Se viene fornito un intervallo, restituisce la sottosezione corrispondente a tale intervallo o `None` se fuori dai limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Restituisce un riferimento modificabile a un elemento o sottosezione a seconda del tipo di indice (vedere [`get`]) o `None` se l'indice è fuori dai limiti.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Restituisce un riferimento a un elemento o una sottosezione, senza eseguire il controllo dei limiti.
    ///
    /// Per un'alternativa sicura vedere [`get`].
    ///
    /// # Safety
    ///
    /// La chiamata a questo metodo con un indice fuori limite è *[comportamento undefined]* anche se il riferimento risultante non viene utilizzato.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SICUREZZA: il chiamante deve rispettare la maggior parte dei requisiti di sicurezza per `get_unchecked`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Restituisce un riferimento modificabile a un elemento o una sottosezione, senza eseguire il controllo dei limiti.
    ///
    /// Per un'alternativa sicura vedere [`get_mut`].
    ///
    /// # Safety
    ///
    /// La chiamata a questo metodo con un indice fuori limite è *[comportamento undefined]* anche se il riferimento risultante non viene utilizzato.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SICUREZZA: il chiamante deve rispettare i requisiti di sicurezza per `get_unchecked_mut`;
        // lo slice è dereferenziabile perché `self` è un riferimento sicuro.
        // Il puntatore restituito è sicuro perché gli impls di `SliceIndex` devono garantire che lo sia.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Restituisce un puntatore non elaborato al buffer della fetta.
    ///
    /// Il chiamante deve assicurarsi che la slice sopravviva al puntatore restituito da questa funzione, altrimenti finirà per puntare alla spazzatura.
    ///
    /// Il chiamante deve anche assicurarsi che la memoria a cui punta il puntatore (non-transitively) non venga mai scritta (eccetto all'interno di un `UnsafeCell`) utilizzando questo puntatore o qualsiasi puntatore derivato da esso.
    /// Se è necessario modificare il contenuto della slice, utilizzare [`as_mut_ptr`].
    ///
    /// La modifica del contenitore a cui fa riferimento questa slice può causare la riallocazione del suo buffer, il che renderebbe anche invalidi eventuali puntatori a esso.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Restituisce un puntatore modificabile non sicuro al buffer della fetta.
    ///
    /// Il chiamante deve assicurarsi che la slice sopravviva al puntatore restituito da questa funzione, altrimenti finirà per puntare alla spazzatura.
    ///
    /// La modifica del contenitore a cui fa riferimento questa slice può causare la riallocazione del suo buffer, il che renderebbe anche invalidi eventuali puntatori a esso.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Restituisce i due puntatori non elaborati che si estendono sulla sezione.
    ///
    /// L'intervallo restituito è semiaperto, il che significa che il puntatore finale punta *uno dopo* l'ultimo elemento della sezione.
    /// In questo modo, una fetta vuota è rappresentata da due puntatori uguali e la differenza tra i due puntatori rappresenta la dimensione della fetta.
    ///
    /// Vedere [`as_ptr`] per avvertenze sull'utilizzo di questi puntatori.Il puntatore finale richiede un'attenzione particolare, poiché non punta a un elemento valido nella sezione.
    ///
    /// Questa funzione è utile per interagire con interfacce esterne che utilizzano due puntatori per fare riferimento a un intervallo di elementi in memoria, come è comune in C++ .
    ///
    ///
    /// Può anche essere utile controllare se un puntatore a un elemento si riferisce a un elemento di questa sezione:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SICUREZZA: l `add` qui è sicuro, perché:
        //
        //   - Entrambi i puntatori fanno parte dello stesso oggetto, poiché conta anche puntare direttamente oltre l'oggetto.
        //
        //   - La dimensione della fetta non è mai maggiore di isize::MAX byte, come indicato qui:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Non è coinvolto alcun avvolgimento, poiché le sezioni non vanno a capo oltre la fine dello spazio degli indirizzi.
        //
        // Consulta la documentazione di pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Restituisce i due puntatori mutabili non sicuri che si estendono sulla slice.
    ///
    /// L'intervallo restituito è semiaperto, il che significa che il puntatore finale punta *uno dopo* l'ultimo elemento della sezione.
    /// In questo modo, una fetta vuota è rappresentata da due puntatori uguali e la differenza tra i due puntatori rappresenta la dimensione della fetta.
    ///
    /// Vedere [`as_mut_ptr`] per avvertenze sull'utilizzo di questi puntatori.
    /// Il puntatore finale richiede un'attenzione particolare, poiché non punta a un elemento valido nella sezione.
    ///
    /// Questa funzione è utile per interagire con interfacce esterne che utilizzano due puntatori per fare riferimento a un intervallo di elementi in memoria, come è comune in C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SICUREZZA: vedi as_ptr_range() sopra per il motivo per cui `add` qui è sicuro.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Scambia due elementi nella sezione.
    ///
    /// # Arguments
    ///
    /// * a, L'indice del primo elemento
    /// * b, l'indice del secondo elemento
    ///
    /// # Panics
    ///
    /// Panics se `a` o `b` sono fuori limite.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Non puoi prendere due mutui mutabili da uno vector, quindi usa invece puntatori non elaborati.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SICUREZZA: `pa` e `pb` sono stati creati da riferimenti mutabili e sicuri
        // agli elementi nella sezione e quindi sono garantiti per essere validi e allineati.
        // Si noti che l'accesso agli elementi dietro `a` e `b` è controllato e panic sarà fuori dai limiti.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Inverte l'ordine degli elementi nella sezione, in posizione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Per i tipi molto piccoli, tutte le letture individuali nel percorso normale hanno prestazioni scadenti.
        // Possiamo fare di meglio, dato un load/store non allineato efficiente, caricando un pezzo più grande e invertendo un registro.
        //

        // Idealmente LLVM lo farebbe per noi, poiché sa meglio di noi se le letture non allineate sono efficienti (dal momento che cambia tra le diverse versioni ARM, ad esempio) e quale sarebbe la migliore dimensione del blocco.
        // Sfortunatamente, a partire da LLVM 4.0 (2017-05) si srotola solo il ciclo, quindi dobbiamo farlo da soli.
        // (Ipotesi: il contrario è problematico perché i lati possono essere allineati in modo diverso-lo sarà, quando la lunghezza è dispari-quindi non c'è modo di emettere pre e postludi per utilizzare SIMD completamente allineato nel mezzo.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Usa l'intrinseco llvm.bswap per invertire gli u8 in una dimensione
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SICUREZZA: ci sono diverse cose da controllare qui:
                //
                // - Nota che `chunk` è 4 o 8 a causa del controllo cfg sopra.Quindi `chunk - 1` è positivo.
                // - L'indicizzazione con l'indice `i` va bene come garantisce il controllo del ciclo
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - L'indicizzazione con l'indice `ln - i - chunk = ln - (i + chunk)` va bene:
                //   - `i + chunk > 0` è banalmente vero.
                //   - Il loop check garantisce:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, quindi la sottrazione non va in underflow.
                // - Le chiamate `read_unaligned` e `write_unaligned` vanno bene:
                //   - `pa` punta all'indice `i` dove `i < ln / 2 - (chunk - 1)` (vedi sopra) e `pb` punta all'indice `ln - i - chunk`, quindi entrambi sono almeno `chunk` a molti byte dalla fine di `self`.
                //
                //   - Qualsiasi memoria inizializzata è valida `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Usa la rotazione di 16 per invertire gli u16 in un u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SICUREZZA: un u32 non allineato può essere letto da `i` se `i + 1 < ln`
                // (e ovviamente `i < ln`), perché ogni elemento è di 2 byte e stiamo leggendo 4.
                //
                // `i + chunk - 1 < ln / 2` # mentre condizione
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Poiché è inferiore alla lunghezza divisa per 2, deve essere entro limiti.
                //
                // Ciò significa anche che la condizione `0 < i + chunk <= ln` viene sempre rispettata, assicurando che il puntatore `pb` possa essere utilizzato in sicurezza.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SICUREZZA: `i` è quindi inferiore alla metà della lunghezza della fetta
            // l'accesso a `i` e `ln - i - 1` è sicuro (`i` parte da 0 e non andrà oltre `ln / 2 - 1`).
            // I puntatori risultanti `pa` e `pb` sono quindi validi e allineati e possono essere letti e scritti.
            //
            //
            unsafe {
                // Scambio non sicuro per evitare il controllo dei limiti nello scambio sicuro.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Restituisce un iteratore sulla sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Restituisce un iteratore che consente di modificare ogni valore.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Restituisce un iteratore su tutti i contigui windows di lunghezza `size`.
    /// L windows si sovrappone.
    /// Se la sezione è più corta di `size`, l'iteratore non restituisce alcun valore.
    ///
    /// # Panics
    ///
    /// Panics se `size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se lo slice è più corto di `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I pezzi sono fette e non si sovrappongono.Se `chunk_size` non divide la lunghezza della fetta, l'ultimo pezzo non avrà la lunghezza `chunk_size`.
    ///
    /// Vedere [`chunks_exact`] per una variante di questo iteratore che restituisce blocchi di elementi `chunk_size` sempre esattamente e [`rchunks`] per lo stesso iteratore ma a partire dalla fine della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I pezzi sono sezioni modificabili e non si sovrappongono.Se `chunk_size` non divide la lunghezza della fetta, l'ultimo pezzo non avrà la lunghezza `chunk_size`.
    ///
    /// Vedere [`chunks_exact_mut`] per una variante di questo iteratore che restituisce blocchi di elementi `chunk_size` sempre esattamente e [`rchunks_mut`] per lo stesso iteratore ma a partire dalla fine della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I pezzi sono fette e non si sovrappongono.
    /// Se `chunk_size` non divide la lunghezza dello slice, gli ultimi elementi fino a `chunk_size-1` verranno omessi e potranno essere recuperati dalla funzione `remainder` dell'iteratore.
    ///
    ///
    /// Dato che ogni blocco ha esattamente elementi `chunk_size`, il compilatore può spesso ottimizzare il codice risultante meglio che nel caso di [`chunks`].
    ///
    /// Vedere [`chunks`] per una variante di questo iteratore che restituisce anche il resto come un blocco più piccolo e [`rchunks_exact`] per lo stesso iteratore ma a partire dalla fine della sezione.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I pezzi sono sezioni modificabili e non si sovrappongono.
    /// Se `chunk_size` non divide la lunghezza dello slice, gli ultimi elementi fino a `chunk_size-1` verranno omessi e potranno essere recuperati dalla funzione `into_remainder` dell'iteratore.
    ///
    ///
    /// Dato che ogni blocco ha esattamente elementi `chunk_size`, il compilatore può spesso ottimizzare il codice risultante meglio che nel caso di [`chunks_mut`].
    ///
    /// Vedere [`chunks_mut`] per una variante di questo iteratore che restituisce anche il resto come un blocco più piccolo e [`rchunks_exact_mut`] per lo stesso iteratore ma a partire dalla fine della sezione.
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Divide la fetta in una fetta di array di elementi "N", assumendo che non ci sia resto.
    ///
    ///
    /// # Safety
    ///
    /// Può essere chiamato solo quando
    /// - Lo slice si divide esattamente in blocchi di elementi "N" (noti anche come `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SICUREZZA: i blocchi di 1 elemento non hanno mai resto
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SICUREZZA: La lunghezza della fetta (6) è un multiplo di 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Questi sarebbero malsani:
    /// // lascia pezzi: &[[_;5]]= slice.as_chunks_unchecked()//La lunghezza della slice non è un multiplo di 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked()//I blocchi di lunghezza zero non sono mai consentiti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICUREZZA: la nostra precondizione è esattamente ciò che è necessario per chiamare questo
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICUREZZA: lanciamo una fetta di elementi `new_len * N` in
        // una fetta di `new_len` molti blocchi di elementi `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Divide la sezione in una sezione di array di elementi "N", a partire dall'inizio della sezione, e una sezione rimanente con lunghezza strettamente inferiore a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SICUREZZA: eravamo già in preda al panico per zero e garantiti dalla costruzione
        // che la lunghezza della sottosezione è un multiplo di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Divide la sezione in una sezione di array di elementi "N", a partire dalla fine della sezione, e una sezione rimanente con lunghezza strettamente inferiore a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SICUREZZA: eravamo già in preda al panico per zero e garantiti dalla costruzione
        // che la lunghezza della sottosezione è un multiplo di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Restituisce un iteratore su `N` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I blocchi sono riferimenti di array e non si sovrappongono.
    /// Se `N` non divide la lunghezza dello slice, gli ultimi elementi fino a `N-1` verranno omessi e potranno essere recuperati dalla funzione `remainder` dell'iteratore.
    ///
    ///
    /// Questo metodo è l'equivalente generico const di [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Divide la fetta in una fetta di array di elementi "N", assumendo che non ci sia resto.
    ///
    ///
    /// # Safety
    ///
    /// Può essere chiamato solo quando
    /// - Lo slice si divide esattamente in blocchi di elementi "N" (noti anche come `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SICUREZZA: i blocchi di 1 elemento non hanno mai resto
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SICUREZZA: La lunghezza della fetta (6) è un multiplo di 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Questi sarebbero malsani:
    /// // lascia pezzi: &[[_;5]]= slice.as_chunks_unchecked_mut()//La lunghezza della slice non è un multiplo di 5 let chunks:&[[_;0]]= slice.as_chunks_unchecked_mut()//I blocchi di lunghezza zero non sono mai consentiti
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SICUREZZA: la nostra precondizione è esattamente ciò che è necessario per chiamare questo
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SICUREZZA: lanciamo una fetta di elementi `new_len * N` in
        // una fetta di `new_len` molti blocchi di elementi `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Divide la sezione in una sezione di array di elementi "N", a partire dall'inizio della sezione, e una sezione rimanente con lunghezza strettamente inferiore a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SICUREZZA: eravamo già in preda al panico per zero e garantiti dalla costruzione
        // che la lunghezza della sottosezione è un multiplo di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Divide la sezione in una sezione di array di elementi "N", a partire dalla fine della sezione, e una sezione rimanente con lunghezza strettamente inferiore a `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SICUREZZA: eravamo già in preda al panico per zero e garantiti dalla costruzione
        // che la lunghezza della sottosezione è un multiplo di N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Restituisce un iteratore su `N` elementi della sezione alla volta, a partire dall'inizio della sezione.
    ///
    /// I blocchi sono riferimenti di array modificabili e non si sovrappongono.
    /// Se `N` non divide la lunghezza dello slice, gli ultimi elementi fino a `N-1` verranno omessi e potranno essere recuperati dalla funzione `into_remainder` dell'iteratore.
    ///
    ///
    /// Questo metodo è l'equivalente generico const di [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0. Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Restituisce un iteratore sovrapposto a windows di `N` elementi di una sezione, a partire dall'inizio della sezione.
    ///
    ///
    /// Questo è l'equivalente generico const di [`windows`].
    ///
    /// Se `N` è maggiore della dimensione dello slice, non restituirà windows.
    ///
    /// # Panics
    ///
    /// Panics se `N` è 0.
    /// Questo controllo molto probabilmente verrà modificato in un errore in fase di compilazione prima che questo metodo venga stabilizzato.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dalla fine della sezione.
    ///
    /// I pezzi sono fette e non si sovrappongono.Se `chunk_size` non divide la lunghezza della fetta, l'ultimo pezzo non avrà la lunghezza `chunk_size`.
    ///
    /// Vedere [`rchunks_exact`] per una variante di questo iteratore che restituisce blocchi di elementi `chunk_size` sempre esattamente e [`chunks`] per lo stesso iteratore ma a partire dall'inizio della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dalla fine della sezione.
    ///
    /// I pezzi sono sezioni modificabili e non si sovrappongono.Se `chunk_size` non divide la lunghezza della fetta, l'ultimo pezzo non avrà la lunghezza `chunk_size`.
    ///
    /// Vedere [`rchunks_exact_mut`] per una variante di questo iteratore che restituisce blocchi di elementi `chunk_size` sempre esattamente e [`chunks_mut`] per lo stesso iteratore ma a partire dall'inizio della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dalla fine della sezione.
    ///
    /// I pezzi sono fette e non si sovrappongono.
    /// Se `chunk_size` non divide la lunghezza dello slice, gli ultimi elementi fino a `chunk_size-1` verranno omessi e potranno essere recuperati dalla funzione `remainder` dell'iteratore.
    ///
    /// Dato che ogni blocco ha esattamente elementi `chunk_size`, il compilatore può spesso ottimizzare il codice risultante meglio che nel caso di [`chunks`].
    ///
    /// Vedere [`rchunks`] per una variante di questo iteratore che restituisce anche il resto come un blocco più piccolo e [`chunks_exact`] per lo stesso iteratore ma a partire dall'inizio della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Restituisce un iteratore su `chunk_size` elementi della sezione alla volta, a partire dalla fine della sezione.
    ///
    /// I pezzi sono sezioni modificabili e non si sovrappongono.
    /// Se `chunk_size` non divide la lunghezza dello slice, gli ultimi elementi fino a `chunk_size-1` verranno omessi e potranno essere recuperati dalla funzione `into_remainder` dell'iteratore.
    ///
    /// Dato che ogni blocco ha esattamente elementi `chunk_size`, il compilatore può spesso ottimizzare il codice risultante meglio che nel caso di [`chunks_mut`].
    ///
    /// Vedere [`rchunks_mut`] per una variante di questo iteratore che restituisce anche il resto come un blocco più piccolo e [`chunks_exact_mut`] per lo stesso iteratore ma a partire dall'inizio della sezione.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `chunk_size` è 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Restituisce un iteratore sulla sezione producendo sequenze di elementi non sovrapposte utilizzando il predicato per separarli.
    ///
    /// Il predicato viene chiamato su due elementi che si seguono, significa che il predicato viene chiamato su `slice[0]` e `slice[1]` poi su `slice[1]` e `slice[2]` e così via.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Questo metodo può essere utilizzato per estrarre le sottosezioni ordinate:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Restituisce un iteratore sulla sezione producendo sequenze mutabili non sovrapposte di elementi utilizzando il predicato per separarli.
    ///
    /// Il predicato viene chiamato su due elementi che si seguono, significa che il predicato viene chiamato su `slice[0]` e `slice[1]` poi su `slice[1]` e `slice[2]` e così via.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Questo metodo può essere utilizzato per estrarre le sottosezioni ordinate:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Divide una fetta in due in corrispondenza di un indice.
    ///
    /// Il primo conterrà tutti gli indici di `[0, mid)` (escluso lo stesso indice `mid`) e il secondo conterrà tutti gli indici di `[mid, len)` (escluso lo stesso indice `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SICUREZZA: `[ptr; mid]` e `[mid; len]` sono all'interno di `self`, che
        // soddisfa i requisiti di `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Divide una porzione modificabile in due in corrispondenza di un indice.
    ///
    /// Il primo conterrà tutti gli indici di `[0, mid)` (escluso lo stesso indice `mid`) e il secondo conterrà tutti gli indici di `[mid, len)` (escluso lo stesso indice `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics se `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SICUREZZA: `[ptr; mid]` e `[mid; len]` sono all'interno di `self`, che
        // soddisfa i requisiti di `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Divide una fetta in due in corrispondenza di un indice, senza eseguire il controllo dei limiti.
    ///
    /// Il primo conterrà tutti gli indici di `[0, mid)` (escluso lo stesso indice `mid`) e il secondo conterrà tutti gli indici di `[mid, len)` (escluso lo stesso indice `len`).
    ///
    ///
    /// Per un'alternativa sicura vedere [`split_at`].
    ///
    /// # Safety
    ///
    /// La chiamata a questo metodo con un indice fuori limite è *[comportamento undefined]* anche se il riferimento risultante non viene utilizzato.Il chiamante deve assicurarsi che `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SICUREZZA: il chiamante deve controllare che `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Divide una porzione modificabile in due in corrispondenza di un indice, senza eseguire il controllo dei limiti.
    ///
    /// Il primo conterrà tutti gli indici di `[0, mid)` (escluso lo stesso indice `mid`) e il secondo conterrà tutti gli indici di `[mid, len)` (escluso lo stesso indice `len`).
    ///
    ///
    /// Per un'alternativa sicura vedere [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// La chiamata a questo metodo con un indice fuori limite è *[comportamento undefined]* anche se il riferimento risultante non viene utilizzato.Il chiamante deve assicurarsi che `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SICUREZZA: il chiamante deve controllare che `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` e `[mid; len]` non si sovrappongono, quindi la restituzione di un riferimento modificabile va bene.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred`.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se il primo elemento corrisponde, una sezione vuota sarà il primo elemento restituito dall'iteratore.
    /// Allo stesso modo, se l'ultimo elemento nella sezione corrisponde, una sezione vuota sarà l'ultimo elemento restituito dall'iteratore:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se due elementi corrispondenti sono direttamente adiacenti, sarà presente una sezione vuota tra di loro:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni modificabili separati da elementi che corrispondono a `pred`.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred`.
    /// L'elemento corrispondente è contenuto alla fine della sottosezione precedente come terminatore.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Se l'ultimo elemento della fetta è abbinato, quell'elemento sarà considerato il terminatore della fetta precedente.
    ///
    /// Quella fetta sarà l'ultimo elemento restituito dall'iteratore.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni modificabili separati da elementi che corrispondono a `pred`.
    /// L'elemento corrispondente è contenuto nella sottosezione precedente come terminatore.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred`, a partire dalla fine della sezione e procedendo all'indietro.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Come con `split()`, se il primo o l'ultimo elemento corrisponde, uno slice vuoto sarà il primo (o l'ultimo) elemento restituito dall'iteratore.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni modificabili separati da elementi che corrispondono a `pred`, a partire dalla fine della sezione e procedendo all'indietro.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred`, limitatamente alla restituzione di elementi `n` al massimo.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// L'ultimo elemento restituito, se presente, conterrà il resto della sezione.
    ///
    /// # Examples
    ///
    /// Stampa la sezione suddivisa una volta per numeri divisibili per 3 (ad esempio, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred`, limitatamente alla restituzione di elementi `n` al massimo.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// L'ultimo elemento restituito, se presente, conterrà il resto della sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred` limitatamente alla restituzione di elementi `n` al massimo.
    /// Inizia alla fine della fetta e funziona all'indietro.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// L'ultimo elemento restituito, se presente, conterrà il resto della sezione.
    ///
    /// # Examples
    ///
    /// Stampa la divisione della sezione una volta, a partire dalla fine, per numeri divisibili per 3 (ad esempio, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Restituisce un iteratore su sottosezioni separate da elementi che corrispondono a `pred` limitatamente alla restituzione di elementi `n` al massimo.
    /// Inizia alla fine della fetta e funziona all'indietro.
    /// L'elemento corrispondente non è contenuto nelle sottosezioni.
    ///
    /// L'ultimo elemento restituito, se presente, conterrà il resto della sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Restituisce `true` se la fetta contiene un elemento con il valore dato.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Se non hai un `&T`, ma solo un `&U` tale che `T: Borrow<U>` (es
    /// `String: prendere in prestito<str>`), puoi usare `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // fetta di `String`
    /// assert!(v.iter().any(|e| e == "hello")); // cerca con `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Restituisce `true` se `needle` è un prefisso della sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Restituisce sempre `true` se `needle` è uno slice vuoto:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Restituisce `true` se `needle` è un suffisso della sezione.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Restituisce sempre `true` se `needle` è uno slice vuoto:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Restituisce una sottosezione con il prefisso rimosso.
    ///
    /// Se la sezione inizia con `prefix`, restituisce la sezione secondaria dopo il prefisso, racchiusa in `Some`.
    /// Se `prefix` è vuoto, restituisce semplicemente la slice originale.
    ///
    /// Se la slice non inizia con `prefix`, restituisce `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Questa funzione dovrà essere riscritta se e quando SlicePattern diventerà più sofisticato.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Restituisce una sottosezione con il suffisso rimosso.
    ///
    /// Se la sezione termina con `suffix`, restituisce la sezione secondaria prima del suffisso, racchiusa in `Some`.
    /// Se `suffix` è vuoto, restituisce semplicemente la slice originale.
    ///
    /// Se la slice non termina con `suffix`, restituisce `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Questa funzione dovrà essere riscritta se e quando SlicePattern diventerà più sofisticato.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary cerca in questa sezione ordinata un dato elemento.
    ///
    /// Se il valore viene trovato, viene restituito [`Result::Ok`], contenente l'indice dell'elemento corrispondente.
    /// Se sono presenti più corrispondenze, potrebbe essere restituita una qualsiasi delle corrispondenze.
    /// Se il valore non viene trovato, viene restituito [`Result::Err`], contenente l'indice in cui è possibile inserire un elemento corrispondente mantenendo l'ordine ordinato.
    ///
    ///
    /// Vedi anche [`binary_search_by`], [`binary_search_by_key`] e [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una serie di quattro elementi.
    /// Si trova il primo, con una posizione determinata in modo univoco;il secondo e il terzo non si trovano;il quarto potrebbe corrispondere a qualsiasi posizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Se desideri inserire un elemento in un vector ordinato, mantenendo l'ordinamento:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary ricerca questa sezione ordinata con una funzione di confronto.
    ///
    /// La funzione di confronto dovrebbe implementare un ordine coerente con l'ordinamento della sezione sottostante, restituendo un codice ordine che indica se il suo argomento è `Less`, `Equal` o `Greater` l'obiettivo desiderato.
    ///
    ///
    /// Se il valore viene trovato, viene restituito [`Result::Ok`], contenente l'indice dell'elemento corrispondente.Se sono presenti più corrispondenze, potrebbe essere restituita una qualsiasi delle corrispondenze.
    /// Se il valore non viene trovato, viene restituito [`Result::Err`], contenente l'indice in cui è possibile inserire un elemento corrispondente mantenendo l'ordine ordinato.
    ///
    /// Vedi anche [`binary_search`], [`binary_search_by_key`] e [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una serie di quattro elementi.Si trova il primo, con una posizione determinata in modo univoco;il secondo e il terzo non si trovano;il quarto potrebbe corrispondere a qualsiasi posizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SICUREZZA: la chiamata è resa sicura dai seguenti invarianti:
            // - `mid >= 0`
            // - `mid < size`: `mid` è limitato da `[left; right)` bound.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Il motivo per cui utilizziamo il flusso di controllo if/else piuttosto che il match è perché match riordina le operazioni di confronto, che è sensibile alle prestazioni.
            //
            // Questo è x86 asm per u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary ricerca questa sezione ordinata con una funzione di estrazione chiave.
    ///
    /// Presuppone che la slice sia ordinata in base alla chiave, ad esempio con [`sort_by_key`] che utilizza la stessa funzione di estrazione della chiave.
    ///
    /// Se il valore viene trovato, viene restituito [`Result::Ok`], contenente l'indice dell'elemento corrispondente.
    /// Se sono presenti più corrispondenze, potrebbe essere restituita una qualsiasi delle corrispondenze.
    /// Se il valore non viene trovato, viene restituito [`Result::Err`], contenente l'indice in cui è possibile inserire un elemento corrispondente mantenendo l'ordine ordinato.
    ///
    ///
    /// Vedi anche [`binary_search`], [`binary_search_by`] e [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Cerca una serie di quattro elementi in una sezione di coppie ordinate in base ai loro secondi elementi.
    /// Si trova il primo, con una posizione determinata in modo univoco;il secondo e il terzo non si trovano;il quarto potrebbe corrispondere a qualsiasi posizione in `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links è consentito poiché `slice::sort_by_key` è in crate `alloc` e come tale non esiste ancora durante la creazione di `core`.
    //
    // collegamenti a crate a valle: #74481.Poiché le primitive sono documentate solo in libstd (#73423), questo non porta mai a collegamenti interrotti nella pratica.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Ordina la porzione, ma potrebbe non mantenere l'ordine degli elementi uguali.
    ///
    /// Questo ordinamento è instabile (cioè, può riordinare elementi uguali), sul posto (cioè, non alloca) e *O*(*n*\*log(* n*)) caso peggiore.
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è basato su [pattern-defeating quicksort][pdqsort] di Orson Peters, che combina il caso medio veloce di quicksort randomizzato con il caso peggiore veloce di heaport, ottenendo il tempo lineare su slice con determinati pattern.
    /// Usa un po 'di randomizzazione per evitare casi degeneri, ma con un seed fisso per fornire sempre un comportamento deterministico.
    ///
    /// In genere è più veloce dell'ordinamento stabile, tranne in alcuni casi speciali, ad esempio quando la sezione consiste di diverse sequenze ordinate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Ordina la sezione con una funzione di confronto, ma potrebbe non mantenere l'ordine degli elementi uguali.
    ///
    /// Questo ordinamento è instabile (cioè, può riordinare elementi uguali), sul posto (cioè, non alloca) e *O*(*n*\*log(* n*)) caso peggiore.
    ///
    /// La funzione di confronto deve definire un ordinamento totale per gli elementi nella sezione.Se l'ordine non è totale, l'ordine degli elementi non è specificato.Un ordine è un ordine totale se è (per tutti i modelli `a`, `b` e `c`):
    ///
    /// * totale e antisimmetrico: esattamente uno tra `a < b`, `a == b` o `a > b` è vero, e
    /// * transitivo, `a < b` e `b < c` implica `a < c`.Lo stesso deve valere sia per `==` che per `>`.
    ///
    /// Ad esempio, mentre [`f64`] non implementa [`Ord`] perché `NaN != NaN`, possiamo usare `partial_cmp` come nostra funzione di ordinamento quando sappiamo che lo slice non contiene `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è basato su [pattern-defeating quicksort][pdqsort] di Orson Peters, che combina il caso medio veloce di quicksort randomizzato con il caso peggiore veloce di heaport, ottenendo il tempo lineare su slice con determinati pattern.
    /// Usa un po 'di randomizzazione per evitare casi degeneri, ma con un seed fisso per fornire sempre un comportamento deterministico.
    ///
    /// In genere è più veloce dell'ordinamento stabile, tranne in alcuni casi speciali, ad esempio quando la sezione consiste di diverse sequenze ordinate concatenate.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // smistamento inverso
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Ordina la sezione con una funzione di estrazione chiave, ma potrebbe non mantenere l'ordine degli elementi uguali.
    ///
    /// Questo ordinamento è instabile (cioè, può riordinare elementi uguali), sul posto (cioè, non alloca) e *O*(m\* * n *\* log(*n*)) caso peggiore, dove la funzione chiave è *O*(*m*).
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è basato su [pattern-defeating quicksort][pdqsort] di Orson Peters, che combina il caso medio veloce di quicksort randomizzato con il caso peggiore veloce di heaport, ottenendo il tempo lineare su slice con determinati pattern.
    /// Usa un po 'di randomizzazione per evitare casi degeneri, ma con un seed fisso per fornire sempre un comportamento deterministico.
    ///
    /// A causa della sua strategia di chiamata chiave, è probabile che [`sort_unstable_by_key`](#method.sort_unstable_by_key) sia più lento di [`sort_by_cached_key`](#method.sort_by_cached_key) nei casi in cui la funzione chiave è costosa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Riordina la sezione in modo che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Riordina la sezione con una funzione di confronto in modo tale che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Riordina la sezione con una funzione di estrazione chiave in modo tale che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Riordina la sezione in modo che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    ///
    /// Questo riordino ha la proprietà aggiuntiva che qualsiasi valore nella posizione `i < index` sarà inferiore o uguale a qualsiasi valore in una posizione `j > index`.
    /// Inoltre, questo riordino è instabile (ad es
    /// qualsiasi numero di elementi uguali può finire nella posizione `index`), sul posto (ad es
    /// non alloca) e *O*(*n*) caso peggiore.
    /// Questa funzione è anche/conosciuta come "kth element" in altre librerie.
    /// Restituisce una terzina dei seguenti valori: tutti gli elementi inferiori a quello all'indice dato, il valore all'indice dato e tutti gli elementi maggiori di quello all'indice dato.
    ///
    ///
    /// # Attuale implementazione
    ///
    /// L'algoritmo corrente si basa sulla porzione quickselect dello stesso algoritmo quicksort utilizzato per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quando `index >= len()`, il che significa che è sempre panics su slice vuote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Trova la mediana
    /// v.select_nth_unstable(2);
    ///
    /// // Ci viene garantito solo che la sezione sarà una delle seguenti, in base al modo in cui ordiniamo in base all'indice specificato.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Riordina la sezione con una funzione di confronto in modo tale che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    ///
    /// Questo riordino ha la proprietà aggiuntiva che qualsiasi valore nella posizione `i < index` sarà inferiore o uguale a qualsiasi valore in una posizione `j > index` utilizzando la funzione di confronto.
    /// Inoltre, questo riordino è instabile (cioè qualsiasi numero di elementi uguali può finire nella posizione `index`), sul posto (cioè non alloca) e *O*(*n*) caso peggiore.
    /// Questa funzione è nota anche come "kth element" in altre librerie.
    /// Restituisce una terzina dei seguenti valori: tutti gli elementi inferiori a quello all'indice dato, il valore all'indice dato e tutti gli elementi maggiori di quello all'indice dato, usando la funzione comparatore fornita.
    ///
    ///
    /// # Attuale implementazione
    ///
    /// L'algoritmo corrente si basa sulla porzione quickselect dello stesso algoritmo quicksort utilizzato per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quando `index >= len()`, il che significa che è sempre panics su slice vuote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Trova la mediana come se la sezione fosse ordinata in ordine decrescente.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ci viene garantito solo che la sezione sarà una delle seguenti, in base al modo in cui ordiniamo in base all'indice specificato.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Riordina la sezione con una funzione di estrazione chiave in modo tale che l'elemento in `index` si trovi nella sua posizione ordinata finale.
    ///
    /// Questo riordino ha la proprietà aggiuntiva che qualsiasi valore nella posizione `i < index` sarà inferiore o uguale a qualsiasi valore in una posizione `j > index` utilizzando la funzione di estrazione della chiave.
    /// Inoltre, questo riordino è instabile (cioè qualsiasi numero di elementi uguali può finire nella posizione `index`), sul posto (cioè non alloca) e *O*(*n*) caso peggiore.
    /// Questa funzione è nota anche come "kth element" in altre librerie.
    /// Restituisce una terzina dei seguenti valori: tutti gli elementi minori di uno all'indice dato, il valore all'indice dato e tutti gli elementi maggiori di uno all'indice dato, usando la funzione di estrazione chiave fornita.
    ///
    ///
    /// # Attuale implementazione
    ///
    /// L'algoritmo corrente si basa sulla porzione quickselect dello stesso algoritmo quicksort utilizzato per [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics quando `index >= len()`, il che significa che è sempre panics su slice vuote.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Restituisce la mediana come se l'array fosse ordinato in base al valore assoluto.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ci viene garantito solo che la sezione sarà una delle seguenti, in base al modo in cui ordiniamo in base all'indice specificato.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Sposta tutti gli elementi ripetuti consecutivi alla fine della sezione in base all'implementazione [`PartialEq`] trait.
    ///
    ///
    /// Restituisce due sezioni.Il primo non contiene elementi ripetuti consecutivi.
    /// Il secondo contiene tutti i duplicati in nessun ordine specificato.
    ///
    /// Se la sezione è ordinata, la prima sezione restituita non contiene duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Sposta tutti gli elementi consecutivi tranne il primo alla fine della sezione soddisfacendo una data relazione di uguaglianza.
    ///
    /// Restituisce due sezioni.Il primo non contiene elementi ripetuti consecutivi.
    /// Il secondo contiene tutti i duplicati in nessun ordine specificato.
    ///
    /// Alla funzione `same_bucket` vengono passati i riferimenti a due elementi della sezione e deve determinare se gli elementi sono uguali.
    /// Gli elementi vengono passati in ordine opposto rispetto al loro ordine nello slice, quindi se `same_bucket(a, b)` restituisce `true`, `a` viene spostato alla fine dello slice.
    ///
    ///
    /// Se la sezione è ordinata, la prima sezione restituita non contiene duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Sebbene abbiamo un riferimento mutevole a `self`, non possiamo apportare modifiche *arbitrarie*.Le chiamate `same_bucket` potrebbero panic, quindi dobbiamo assicurarci che lo slice sia sempre in uno stato valido.
        //
        // Il modo in cui gestiamo questo è usando gli swap;iteriamo su tutti gli elementi, scambiandoli man mano che procediamo in modo che alla fine gli elementi che desideriamo mantenere siano in primo piano e quelli che desideriamo rifiutare siano in fondo.
        // Possiamo quindi dividere la fetta.
        // Questa operazione è ancora `O(n)`.
        //
        // Esempio: iniziamo in questo stato, dove `r` rappresenta "next"
        // read "e `w` rappresenta" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Confrontando self[r] con self [w-1], questo non è un duplicato, quindi scambiamo self[r] e self[w] (nessun effetto come r==w) e quindi incrementiamo sia r che w, lasciandoci con:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Confrontando self[r] con self [w-1], questo valore è un duplicato, quindi incrementiamo `r` ma lasciamo tutto il resto invariato:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Confrontando self[r] con self [w-1], questo non è un duplicato, quindi scambia self[r] e self[w] e avanza r e w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Non un duplicato, ripeti:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicato, advance r. End di slice.Diviso a w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SICUREZZA: la condizione `while` garantisce `next_read` e `next_write`
        // sono inferiori a `len`, quindi sono all'interno di `self`.
        // `prev_ptr_write` punta a un elemento prima di `ptr_write`, ma `next_write` inizia da 1, quindi `prev_ptr_write` non è mai inferiore a 0 ed è all'interno della sezione.
        // Ciò soddisfa i requisiti per la dereferenziazione di `ptr_read`, `prev_ptr_write` e `ptr_write` e per l'utilizzo di `ptr.add(next_read)`, `ptr.add(next_write - 1)` e `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` viene anche incrementato al massimo una volta per ciclo al massimo, il che significa che nessun elemento viene saltato quando potrebbe essere necessario scambiarlo.
        //
        // `ptr_read` e `prev_ptr_write` non puntano mai allo stesso elemento.Ciò è necessario affinché `&mut *ptr_read`, `&mut* prev_ptr_write` siano sicuri.
        // La spiegazione è semplicemente che `next_read >= next_write` è sempre vero, quindi anche `next_read > next_write - 1` lo è.
        //
        //
        //
        //
        //
        unsafe {
            // Evita i controlli dei limiti utilizzando puntatori non elaborati.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Sposta tutti gli elementi consecutivi tranne il primo alla fine dello slice che si risolvono nella stessa chiave.
    ///
    ///
    /// Restituisce due sezioni.Il primo non contiene elementi ripetuti consecutivi.
    /// Il secondo contiene tutti i duplicati in nessun ordine specificato.
    ///
    /// Se la sezione è ordinata, la prima sezione restituita non contiene duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Ruota la sezione in posizione in modo che i primi elementi `mid` della sezione si spostino alla fine mentre gli ultimi elementi `self.len() - mid` si spostano in primo piano.
    /// Dopo aver chiamato `rotate_left`, l'elemento precedentemente all'indice `mid` diventerà il primo elemento nello slice.
    ///
    /// # Panics
    ///
    /// Questa funzione panic se `mid` è maggiore della lunghezza dello slice.Nota che `mid == self.len()` esegue _not_ panic ed è una rotazione non operativa.
    ///
    /// # Complexity
    ///
    /// Prende lineare (in tempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotazione di una sottosezione:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SICUREZZA: La gamma `[p.add(mid) - mid, p.add(mid) + k)` è banale
        // valido per lettura e scrittura, come richiesto da `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Ruota la sezione in posizione in modo che i primi elementi `self.len() - k` della sezione si spostino alla fine mentre gli ultimi elementi `k` si spostano in primo piano.
    /// Dopo aver chiamato `rotate_right`, l'elemento precedentemente all'indice `self.len() - k` diventerà il primo elemento nello slice.
    ///
    /// # Panics
    ///
    /// Questa funzione panic se `k` è maggiore della lunghezza dello slice.Nota che `k == self.len()` esegue _not_ panic ed è una rotazione non operativa.
    ///
    /// # Complexity
    ///
    /// Prende lineare (in tempo `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Ruota una sottosezione:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SICUREZZA: La gamma `[p.add(mid) - mid, p.add(mid) + k)` è banale
        // valido per lettura e scrittura, come richiesto da `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Riempie `self` con elementi clonando `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Riempie `self` con gli elementi restituiti chiamando ripetutamente una chiusura.
    ///
    /// Questo metodo utilizza una chiusura per creare nuovi valori.Se preferisci [`Clone`] un dato valore, usa [`fill`].
    /// Se desideri utilizzare [`Default`] trait per generare valori, puoi passare [`Default::default`] come argomento.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Copia gli elementi da `src` a `self`.
    ///
    /// La lunghezza di `src` deve essere la stessa di `self`.
    ///
    /// Se `T` implementa `Copy`, può essere più performante usare [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Questa funzione panic se le due fette hanno lunghezze diverse.
    ///
    /// # Examples
    ///
    /// Clonare due elementi da una slice a un'altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Poiché le sezioni devono avere la stessa lunghezza, tagliamo la sezione di origine da quattro elementi a due.
    /// // Sarà panic se non lo facciamo.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impone che ci possa essere un solo riferimento modificabile senza riferimenti immutabili a un particolare pezzo di dati in un particolare ambito.
    /// Per questo motivo, il tentativo di utilizzare `clone_from_slice` su una singola slice risulterà in un errore di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per ovviare a questo problema, possiamo usare [`split_at_mut`] per creare due sottosezioni distinte da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Copia tutti gli elementi da `src` a `self`, utilizzando un memcpy.
    ///
    /// La lunghezza di `src` deve essere la stessa di `self`.
    ///
    /// Se `T` non implementa `Copy`, utilizzare [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Questa funzione panic se le due fette hanno lunghezze diverse.
    ///
    /// # Examples
    ///
    /// Copia di due elementi da una slice all'altra:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Poiché le sezioni devono avere la stessa lunghezza, tagliamo la sezione di origine da quattro elementi a due.
    /// // Sarà panic se non lo facciamo.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust impone che ci possa essere un solo riferimento modificabile senza riferimenti immutabili a un particolare pezzo di dati in un particolare ambito.
    /// Per questo motivo, il tentativo di utilizzare `copy_from_slice` su una singola slice risulterà in un errore di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Per ovviare a questo problema, possiamo usare [`split_at_mut`] per creare due sottosezioni distinte da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Il percorso del codice panic è stato inserito in una funzione fredda per non gonfiare il sito della chiamata.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SICUREZZA: `self` è valido per gli elementi `self.len()` per definizione e `src` lo era
        // controllato per avere la stessa lunghezza.
        // Le sezioni non possono sovrapporsi perché i riferimenti modificabili sono esclusivi.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Copia gli elementi da una parte della slice a un'altra parte di se stessa, utilizzando un memmove.
    ///
    /// `src` è l'intervallo all'interno di `self` da cui copiare.
    /// `dest` è l'indice iniziale dell'intervallo all'interno di `self` in cui copiare, che avrà la stessa lunghezza di `src`.
    /// I due intervalli possono sovrapporsi.
    /// Le estremità dei due intervalli devono essere inferiori o uguali a `self.len()`.
    ///
    /// # Panics
    ///
    /// Questa funzione sarà panic se uno degli intervalli supera la fine dello slice o se la fine di `src` è prima dell'inizio.
    ///
    ///
    /// # Examples
    ///
    /// Copia di quattro byte all'interno di una slice:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SICUREZZA: le condizioni per `ptr::copy` sono state tutte verificate sopra,
        // come quelli per `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Scambia tutti gli elementi in `self` con quelli in `other`.
    ///
    /// La lunghezza di `other` deve essere la stessa di `self`.
    ///
    /// # Panics
    ///
    /// Questa funzione panic se le due fette hanno lunghezze diverse.
    ///
    /// # Example
    ///
    /// Scambiare due elementi tra le sezioni:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust impone che ci possa essere un solo riferimento modificabile a un particolare dato in un particolare ambito.
    ///
    /// Per questo motivo, il tentativo di utilizzare `swap_with_slice` su una singola slice risulterà in un errore di compilazione:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Per ovviare a questo, possiamo usare [`split_at_mut`] per creare due distinte sottosezioni modificabili da una fetta:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SICUREZZA: `self` è valido per gli elementi `self.len()` per definizione e `src` lo era
        // controllato per avere la stessa lunghezza.
        // Le sezioni non possono sovrapporsi perché i riferimenti modificabili sono esclusivi.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funzione per calcolare le lunghezze della fetta centrale e finale per `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Quello che faremo su `rest` è capire quale multiplo di "U" possiamo mettere nel numero più basso di "T".
        //
        // E quante `T` abbiamo bisogno per ciascuno di questi "multiple".
        //
        // Considera ad esempio T=u8 U=u16.Quindi possiamo mettere 1 U in 2 Ts.Semplice.
        // Consideriamo ora, ad esempio, un caso in cui size_of: :<T>=16, size_of::<U>=24.</u>
        // Possiamo mettere 2 Us al posto di ogni 3 Ts nello slice `rest`.
        // Un po 'più complicato.
        //
        // La formula per calcolare questo è:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Ampliato e semplificato:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Per fortuna, dal momento che tutto questo viene valutato costantemente ... le prestazioni qui non contano!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // Algoritmo di stein iterativo Dovremmo ancora fare questo `const fn` (e tornare all'algoritmo ricorsivo se lo facciamo) perché fare affidamento su llvm per constevalare tutto questo è ... beh, mi mette a disagio.
            //
            //

            // SICUREZZA: `a` e `b` sono verificati per essere valori diversi da zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // rimuovere tutti i fattori di 2 da b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SICUREZZA: `b` viene verificato per essere diverso da zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Armati di questa conoscenza, possiamo trovare quante `U` possiamo adattare!
        let us_len = self.len() / ts * us;
        // E quante "T" ci saranno nella fetta finale!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Trasmuta la sezione in una sezione di un altro tipo, assicurando che l'allineamento dei tipi venga mantenuto.
    ///
    /// Questo metodo divide la sezione in tre sezioni distinte: prefisso, sezione centrale correttamente allineata di un nuovo tipo e sezione suffisso.
    /// Il metodo può rendere la sezione centrale la massima lunghezza possibile per un dato tipo e sezione di input, ma solo le prestazioni del tuo algoritmo dovrebbero dipendere da questo, non dalla sua correttezza.
    ///
    /// È consentito che tutti i dati di input vengano restituiti come fetta di prefisso o suffisso.
    ///
    /// Questo metodo non ha scopo quando l'elemento di input `T` o l'elemento di output `U` sono di dimensione zero e restituiranno la slice originale senza dividere nulla.
    ///
    /// # Safety
    ///
    /// Questo metodo è essenzialmente un `transmute` rispetto agli elementi nella sezione centrale restituita, quindi tutti i soliti avvertimenti relativi a `transmute::<T, U>` si applicano anche qui.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Nota che la maggior parte di questa funzione sarà valutata in base alle costanti,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // gestire in modo speciale gli ZST, ovvero non gestirli affatto.
            return (self, &[], &[]);
        }

        // Per prima cosa, trova a che punto dividiamo tra la prima e la seconda fetta.
        // Facile con ptr.align_offset.
        let ptr = self.as_ptr();
        // SICUREZZA: vedere il metodo `align_to_mut` per il commento dettagliato sulla sicurezza.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SICUREZZA: ora `rest` è decisamente allineato, quindi `from_raw_parts` sotto va bene,
            // poiché il chiamante garantisce che possiamo trasmettere da `T` a `U` in modo sicuro.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Trasmuta la sezione in una sezione di un altro tipo, assicurando che l'allineamento dei tipi venga mantenuto.
    ///
    /// Questo metodo divide la sezione in tre sezioni distinte: prefisso, sezione centrale correttamente allineata di un nuovo tipo e sezione suffisso.
    /// Il metodo può rendere la sezione centrale la massima lunghezza possibile per un dato tipo e sezione di input, ma solo le prestazioni del tuo algoritmo dovrebbero dipendere da questo, non dalla sua correttezza.
    ///
    /// È consentito che tutti i dati di input vengano restituiti come fetta di prefisso o suffisso.
    ///
    /// Questo metodo non ha scopo quando l'elemento di input `T` o l'elemento di output `U` sono di dimensione zero e restituiranno la slice originale senza dividere nulla.
    ///
    /// # Safety
    ///
    /// Questo metodo è essenzialmente un `transmute` rispetto agli elementi nella sezione centrale restituita, quindi tutti i soliti avvertimenti relativi a `transmute::<T, U>` si applicano anche qui.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Nota che la maggior parte di questa funzione sarà valutata in base alle costanti,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // gestire in modo speciale gli ZST, ovvero non gestirli affatto.
            return (self, &mut [], &mut []);
        }

        // Per prima cosa, trova a che punto dividiamo tra la prima e la seconda fetta.
        // Facile con ptr.align_offset.
        let ptr = self.as_ptr();
        // SICUREZZA: qui ci assicuriamo di utilizzare puntatori allineati per U per il file
        // resto del metodo.Questo viene fatto passando un puntatore a&[T] con un allineamento mirato per U.
        // `crate::ptr::align_offset` viene chiamato con un puntatore correttamente allineato e valido `ptr` (deriva da un riferimento a `self`) e con una dimensione che è una potenza di due (poiché proviene dall'allineamento per U), soddisfacendo i suoi vincoli di sicurezza.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Non possiamo usare di nuovo `rest` dopo questo, ciò invaliderebbe il suo alias `mut_ptr`!SICUREZZA: vedere i commenti per `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Controlla se gli elementi di questa sezione sono ordinati.
    ///
    /// Cioè, per ogni elemento `a` e il suo elemento successivo `b`, `a <= b` deve contenere.Se la fetta restituisce esattamente zero o un elemento, viene restituito `true`.
    ///
    /// Si noti che se `Self::Item` è solo `PartialOrd`, ma non `Ord`, la definizione precedente implica che questa funzione restituisca `false` se due elementi consecutivi non sono confrontabili.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Controlla se gli elementi di questa sezione sono ordinati utilizzando la funzione di confronto data.
    ///
    /// Invece di usare `PartialOrd::partial_cmp`, questa funzione usa la funzione `compare` data per determinare l'ordinamento di due elementi.
    /// A parte questo, è equivalente a [`is_sorted`];vedere la sua documentazione per maggiori informazioni.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Controlla se gli elementi di questa sezione sono ordinati utilizzando la funzione di estrazione chiave specificata.
    ///
    /// Invece di confrontare direttamente gli elementi dello slice, questa funzione confronta le chiavi degli elementi, come determinato da `f`.
    /// A parte questo, è equivalente a [`is_sorted`];vedere la sua documentazione per maggiori informazioni.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Restituisce l'indice del punto di partizione in base al predicato dato (l'indice del primo elemento della seconda partizione).
    ///
    /// Si presume che la sezione sia partizionata in base al predicato specificato.
    /// Ciò significa che tutti gli elementi per i quali il predicato restituisce true sono all'inizio della sezione e tutti gli elementi per i quali il predicato restituisce false sono alla fine.
    ///
    /// Ad esempio, [7, 15, 3, 5, 4, 12, 6] è partizionato con il predicato x% 2!=0 (tutti i numeri dispari sono all'inizio, tutti pari alla fine).
    ///
    /// Se questa slice non è partizionata, il risultato restituito è non specificato e privo di significato, poiché questo metodo esegue una sorta di ricerca binaria.
    ///
    /// Vedi anche [`binary_search`], [`binary_search_by`] e [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SICUREZZA: quando `left < right`, `left <= mid < right`.
            // Pertanto `left` aumenta sempre e `right` diminuisce sempre e viene selezionato uno dei due.In entrambi i casi `left <= right` è soddisfatto.Pertanto, se `left < right` in una fase, `left <= right` è soddisfatta nella fase successiva.
            //
            // Quindi fintanto che `left != right`, `0 <= left < right <= len` è soddisfatto e se questo caso è soddisfatto anche `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Dobbiamo tagliarli esplicitamente alla stessa lunghezza
        // per rendere più facile per l'ottimizzatore elide il controllo dei limiti.
        // Ma poiché non ci si può fare affidamento, abbiamo anche una specializzazione esplicita per T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Crea uno slice vuoto.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Crea uno slice vuoto modificabile.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Pattern in slice, attualmente, utilizzati solo da `strip_prefix` e `strip_suffix`.
/// In un punto future, speriamo di generalizzare `core::str::Pattern` (che al momento della scrittura è limitato a `str`) in slice, e quindi questo trait verrà sostituito o abolito.
///
pub trait SlicePattern {
    /// Il tipo di elemento della sezione su cui si abbina.
    type Item;

    /// Attualmente, i consumatori di `SlicePattern` hanno bisogno di una fetta.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}