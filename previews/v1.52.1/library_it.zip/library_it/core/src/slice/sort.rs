//! Ordinamento delle fette
//!
//! Questo modulo contiene un algoritmo di ordinamento basato sul quicksort che sconfigge i pattern di Orson Peters, pubblicato su: <https://github.com/orlp/pdqsort>
//!
//!
//! L'ordinamento instabile è compatibile con libcore perché non alloca memoria, a differenza della nostra implementazione dell'ordinamento stabile.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Quando viene rilasciato, copia da `src` a `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SICUREZZA: questa è una classe di aiuto.
        //          Si prega di fare riferimento al suo utilizzo per la correttezza.
        //          Vale a dire, bisogna essere sicuri che `src` e `dst` non si sovrappongano come richiesto da `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Sposta il primo elemento a destra finché non incontra un elemento maggiore o uguale.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICUREZZA: le operazioni non sicure riportate di seguito prevedono l'indicizzazione senza un controllo vincolato (`get_unchecked` e `get_unchecked_mut`)
    // e copiare la memoria (`ptr::copy_nonoverlapping`).
    //
    // un.Indicizzazione:
    //  1. Abbiamo controllato la dimensione dell'array su>=2.
    //  2. Tutta l'indicizzazione che faremo è sempre tra {0 <= index < len} al massimo.
    //
    // b.Copia da memoria
    //  1. Stiamo ottenendo puntatori a riferimenti di cui è garantita la validità.
    //  2. Non possono sovrapporsi perché si ottengono puntatori agli indici di differenza della fetta.
    //     Vale a dire, `i` e `i-1`.
    //  3. Se la sezione è allineata correttamente, gli elementi sono allineati correttamente.
    //     È responsabilità del chiamante assicurarsi che la sezione sia allineata correttamente.
    //
    // Vedere i commenti di seguito per ulteriori dettagli.
    unsafe {
        // Se i primi due elementi sono fuori servizio ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Legge il primo elemento in una variabile allocata nello stack.
            // Se una seguente operazione di confronto panics, `hole` verrà rilasciata e riscriverà automaticamente l'elemento nello slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Spostare l'elemento "i" di un posto a sinistra, spostando così il foro a destra.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` viene lasciato cadere e quindi copia `tmp` nel foro rimanente in `v`.
        }
    }
}

/// Sposta l'ultimo elemento a sinistra finché non incontra un elemento più piccolo o uguale.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SICUREZZA: le operazioni non sicure riportate di seguito prevedono l'indicizzazione senza un controllo vincolato (`get_unchecked` e `get_unchecked_mut`)
    // e copiare la memoria (`ptr::copy_nonoverlapping`).
    //
    // un.Indicizzazione:
    //  1. Abbiamo controllato la dimensione dell'array su>=2.
    //  2. Tutta l'indicizzazione che faremo è sempre tra `0 <= index < len-1` al massimo.
    //
    // b.Copia da memoria
    //  1. Stiamo ottenendo puntatori a riferimenti di cui è garantita la validità.
    //  2. Non possono sovrapporsi perché si ottengono puntatori agli indici di differenza della fetta.
    //     Vale a dire, `i` e `i+1`.
    //  3. Se la sezione è allineata correttamente, gli elementi sono allineati correttamente.
    //     È responsabilità del chiamante assicurarsi che la sezione sia allineata correttamente.
    //
    // Vedere i commenti di seguito per ulteriori dettagli.
    unsafe {
        // Se gli ultimi due elementi sono fuori servizio ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Leggi l'ultimo elemento in una variabile allocata nello stack.
            // Se una seguente operazione di confronto panics, `hole` verrà rilasciata e riscriverà automaticamente l'elemento nello slice.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Spostare l'elemento "i" di un posto a destra, spostando così il foro a sinistra.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` viene lasciato cadere e quindi copia `tmp` nel foro rimanente in `v`.
        }
    }
}

/// Ordina parzialmente una sezione spostando diversi elementi fuori ordine.
///
/// Restituisce `true` se la sezione è ordinata alla fine.Questa funzione è *O*(*n*) nel caso peggiore.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Numero massimo di coppie adiacenti fuori ordine che verranno spostate.
    const MAX_STEPS: usize = 5;
    // Se la sezione è più corta di questa, non spostare alcun elemento.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SICUREZZA: Abbiamo già fatto esplicitamente il controllo del limite con `i < len`.
        // Tutta la nostra successiva indicizzazione è solo nella gamma `0 <= index < len`
        unsafe {
            // Trova la coppia successiva di elementi fuori ordine adiacenti.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Abbiamo finito?
        if i == len {
            return true;
        }

        // Non spostare elementi su array brevi, ciò ha un costo in termini di prestazioni.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Scambia la coppia di elementi trovati.Questo li mette nell'ordine corretto.
        v.swap(i - 1, i);

        // Sposta l'elemento più piccolo a sinistra.
        shift_tail(&mut v[..i], is_less);
        // Sposta l'elemento maggiore a destra.
        shift_head(&mut v[i..], is_less);
    }

    // Non sono riuscito a ordinare la fetta nel numero limitato di passaggi.
    false
}

/// Ordina una sezione utilizzando l'ordinamento per inserzione, che è *O*(*n*^ 2) nel caso peggiore.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ordina `v` utilizzando heapsort, che garantisce *O*(*n*\*log(* n*)) worst-case.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Questo heap binario rispetta l `parent >= child` invariante.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Figli di `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Scegli il bambino più grande.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Fermati se l'invariante è `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Scambia `node` con il bambino più grande, sposta un gradino verso il basso e continua a setacciare.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Costruisci l'heap in tempo lineare.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Estrai gli elementi massimi dal mucchio.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partiziona `v` in elementi più piccoli di `pivot`, seguiti da elementi maggiori o uguali a `pivot`.
///
///
/// Restituisce il numero di elementi inferiore a `pivot`.
///
/// Il partizionamento viene eseguito blocco per blocco al fine di ridurre al minimo il costo delle operazioni di ramificazione.
/// Questa idea è presentata nel documento [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Numero di elementi in un blocco tipico.
    const BLOCK: usize = 128;

    // L'algoritmo di partizionamento ripete i seguenti passaggi fino al completamento:
    //
    // 1. Traccia un blocco dal lato sinistro per identificare gli elementi maggiori o uguali al perno.
    // 2. Traccia un blocco dal lato destro per identificare gli elementi più piccoli del perno.
    // 3. Scambia gli elementi identificati tra il lato sinistro e quello destro.
    //
    // Manteniamo le seguenti variabili per un blocco di elementi:
    //
    // 1. `block` - Numero di elementi nel blocco.
    // 2. `start` - Avvia il puntatore nell'array `offsets`.
    // 3. `end` - Puntatore finale nell'array `offsets`.
    // 4. `offset, indici di elementi fuori ordine all'interno del blocco.

    // Il blocco corrente sul lato sinistro (da `l` a `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Il blocco corrente sul lato destro (da `r.sub(block_r)` to `r`).
    // SICUREZZA: La documentazione per .add() menziona specificamente che `vec.as_ptr().add(vec.len())` è sempre sicuro`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Quando otteniamo i VLA, prova a creare un array di lunghezza `min(v.len(), 2 * BLOCK) `
    // di due array di dimensioni fisse di lunghezza `BLOCK`.I VLA potrebbero essere più efficienti nella cache.

    // Restituisce il numero di elementi tra i puntatori `l` (inclusive) e `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Abbiamo finito con il partizionamento blocco per blocco quando `l` e `r` si avvicinano molto.
        // Quindi eseguiamo un po 'di lavoro di patch-up per partizionare gli elementi rimanenti nel mezzo.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numero di elementi rimanenti (ancora non rispetto al pivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Regola le dimensioni del blocco in modo che il blocco sinistro e destro non si sovrappongano, ma siano perfettamente allineati per coprire l'intero spazio rimanente.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Traccia gli elementi `block_l` dal lato sinistro.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SICUREZZA: le operazioni non sicure riportate di seguito implicano l'utilizzo di `offset`.
                //         In base alle condizioni richieste dalla funzione, le soddisfiamo perché:
                //         1. `offsets_l` è allocato nello stack e quindi considerato oggetto allocato separato.
                //         2. La funzione `is_less` restituisce un `bool`.
                //            La trasmissione di un `bool` non supererà mai `isize`.
                //         3. Abbiamo garantito che `block_l` sarà `<= BLOCK`.
                //            Inoltre, `end_l` era inizialmente impostato sul puntatore di inizio di `offsets_` che era stato dichiarato nello stack.
                //            Quindi, sappiamo che anche nel caso peggiore (tutte le invocazioni di `is_less` restituiscono false) saremo solo al massimo 1 byte oltre la fine.
                //        Un'altra operazione non sicura qui è dereferenziare `elem`.
                //        Tuttavia, `elem` era inizialmente il puntatore di inizio allo slice che è sempre valido.
                unsafe {
                    // Confronto senza rami.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traccia gli elementi `block_r` dal lato destro.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SICUREZZA: le operazioni non sicure riportate di seguito implicano l'utilizzo di `offset`.
                //         In base alle condizioni richieste dalla funzione, le soddisfiamo perché:
                //         1. `offsets_r` è allocato nello stack e quindi considerato oggetto allocato separato.
                //         2. La funzione `is_less` restituisce un `bool`.
                //            La trasmissione di un `bool` non supererà mai `isize`.
                //         3. Abbiamo garantito che `block_r` sarà `<= BLOCK`.
                //            Inoltre, `end_r` era inizialmente impostato sul puntatore di inizio di `offsets_` che era stato dichiarato nello stack.
                //            Quindi, sappiamo che anche nel caso peggiore (tutte le invocazioni di `is_less` restituiscono true) saremo solo al massimo 1 byte oltre la fine.
                //        Un'altra operazione non sicura qui è dereferenziare `elem`.
                //        Tuttavia, `elem` era inizialmente `1 *sizeof(T)` oltre la fine e lo abbiamo diminuito di `1* sizeof(T)` prima di accedervi.
                //        Inoltre, è stato affermato che `block_r` è inferiore a `BLOCK` e quindi `elem` al massimo punterà all'inizio dello slice.
                unsafe {
                    // Confronto senza rami.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numero di elementi fuori ordine da scambiare tra il lato sinistro e quello destro.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Invece di scambiare una coppia alla volta, è più efficiente eseguire una permutazione ciclica.
            // Ciò non è strettamente equivalente allo scambio, ma produce un risultato simile utilizzando meno operazioni di memoria.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Tutti gli elementi fuori ordine nel blocco di sinistra sono stati spostati.Passa al blocco successivo.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Tutti gli elementi fuori ordine nel blocco di destra sono stati spostati.Passa al blocco precedente.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Tutto ciò che resta ora è al massimo un blocco (a sinistra oa destra) con elementi fuori ordine che devono essere spostati.
    // Tali elementi rimanenti possono essere semplicemente spostati alla fine all'interno del loro blocco.
    //

    if start_l < end_l {
        // Il blocco di sinistra rimane.
        // Sposta i suoi elementi rimanenti fuori ordine all'estrema destra.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Rimane il blocco di destra.
        // Sposta i suoi elementi rimanenti fuori ordine all'estrema sinistra.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nient'altro da fare, abbiamo finito.
        width(v.as_mut_ptr(), l)
    }
}

/// Partiziona `v` in elementi più piccoli di `v[pivot]`, seguiti da elementi maggiori o uguali a `v[pivot]`.
///
///
/// Restituisce una tupla di:
///
/// 1. Numero di elementi inferiore a `v[pivot]`.
/// 2. Vero se `v` era già partizionato.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Posizionare il perno all'inizio della fetta.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Leggi il pivot in una variabile allocata nello stack per l'efficienza.
        // Se una successiva operazione di confronto panics, il pivot verrà riscritto automaticamente nella slice.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Trova la prima coppia di elementi fuori ordine.
        let mut l = 0;
        let mut r = v.len();

        // SICUREZZA: la non sicurezza di seguito implica l'indicizzazione di un array.
        // Per il primo: abbiamo già fatto il controllo dei limiti qui con `l < r`.
        // Per il secondo: inizialmente abbiamo `l == 0` e `r == v.len()` e abbiamo verificato che `l < r` ad ogni operazione di indicizzazione.
        //                     Da qui sappiamo che `r` deve essere almeno `r == l` che si è dimostrato valido dal primo.
        unsafe {
            // Trova il primo elemento maggiore o uguale al perno.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Trova l'ultimo elemento più piccolo del perno.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` esce dall'ambito e scrive il pivot (che è una variabile allocata nello stack) nella sezione in cui si trovava originariamente.
        // Questo passaggio è fondamentale per garantire la sicurezza!
        //
    };

    // Posiziona il perno tra le due partizioni.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partiziona `v` in elementi uguali a `v[pivot]` seguiti da elementi maggiori di `v[pivot]`.
///
/// Restituisce il numero di elementi uguale al pivot.
/// Si presume che `v` non contenga elementi più piccoli del pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Posizionare il perno all'inizio della fetta.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Leggi il pivot in una variabile allocata nello stack per l'efficienza.
    // Se una successiva operazione di confronto panics, il pivot verrà riscritto automaticamente nella slice.
    // SICUREZZA: Il puntatore qui è valido perché è ottenuto da un riferimento a uno slice.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ora partiziona la fetta.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SICUREZZA: la non sicurezza di seguito implica l'indicizzazione di un array.
        // Per il primo: abbiamo già fatto il controllo dei limiti qui con `l < r`.
        // Per il secondo: inizialmente abbiamo `l == 0` e `r == v.len()` e abbiamo verificato che `l < r` ad ogni operazione di indicizzazione.
        //                     Da qui sappiamo che `r` deve essere almeno `r == l` che si è dimostrato valido dal primo.
        unsafe {
            // Trova il primo elemento più grande del pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Trova l'ultimo elemento uguale al perno.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Abbiamo finito?
            if l >= r {
                break;
            }

            // Scambia la coppia trovata di elementi fuori ordine.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Abbiamo trovato elementi `l` uguali al pivot.Aggiungi 1 per tenere conto del pivot stesso.
    l + 1

    // `_pivot_guard` esce dall'ambito e scrive il pivot (che è una variabile allocata nello stack) nella sezione in cui si trovava originariamente.
    // Questo passaggio è fondamentale per garantire la sicurezza!
}

/// Distribuisce alcuni elementi nel tentativo di rompere gli schemi che potrebbero causare partizioni sbilanciate nel quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generatore di numeri pseudocasuali dal documento "Xorshift RNGs" di George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Prendi numeri casuali modulo questo numero.
        // Il numero rientra in `usize` perché `len` non è maggiore di `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Alcuni candidati pivot saranno nelle vicinanze di questo indice.Let's randomizzarli.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Genera un numero casuale modulo `len`.
            // Tuttavia, per evitare operazioni costose, prima lo prendiamo modulo una potenza di due, quindi diminuiamo di `len` fino a quando non rientra nell'intervallo `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` è garantito essere inferiore a `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Sceglie un pivot in `v` e restituisce l'indice e `true` se la sezione è probabilmente già ordinata.
///
/// Gli elementi in `v` potrebbero essere riordinati durante il processo.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Lunghezza minima per scegliere il metodo della mediana delle mediane.
    // Le fette più corte utilizzano il semplice metodo della mediana di tre.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Numero massimo di scambi che possono essere eseguiti in questa funzione.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tre indici vicino ai quali sceglieremo un pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Conta il numero totale di swap che stiamo per eseguire durante l'ordinamento degli indici.
    let mut swaps = 0;

    if len >= 8 {
        // Scambia gli indici in modo che `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Scambia gli indici in modo che `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Trova la mediana di `v[a - 1], v[a], v[a + 1]` e memorizza l'indice in `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Trova le mediane nei dintorni di `a`, `b` e `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Trova la mediana tra `a`, `b` e `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // È stato eseguito il numero massimo di swap.
        // È probabile che la fetta stia discendendo o per lo più discendente, quindi invertire probabilmente aiuterà a ordinarla più velocemente.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ordina `v` in modo ricorsivo.
///
/// Se la slice aveva un predecessore nell'array originale, viene specificato come `pred`.
///
/// `limit` è il numero di partizioni sbilanciate consentite prima di passare a `heapsort`.
/// Se zero, questa funzione passerà immediatamente a heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Le sezioni fino a questa lunghezza vengono ordinate utilizzando l'ordinamento per inserzione.
    const MAX_INSERTION: usize = 20;

    // Vero se l'ultimo partizionamento era ragionevolmente bilanciato.
    let mut was_balanced = true;
    // Vero se l'ultimo partizionamento non ha mescolato gli elementi (la slice era già partizionata).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Le sezioni molto brevi vengono ordinate utilizzando l'ordinamento per inserimento.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Se sono state fatte troppe scelte pivot sbagliate, ripiegare semplicemente su heapsort per garantire il caso peggiore di `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Se l'ultimo partizionamento era sbilanciato, prova a rompere i pattern nella slice rimescolando alcuni elementi.
        // Speriamo di scegliere un perno migliore questa volta.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Scegli un pivot e prova a indovinare se la fetta è già ordinata.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Se l'ultimo partizionamento è stato adeguatamente bilanciato e non ha mischiato gli elementi e se la selezione del pivot prevede che la fetta è probabilmente già ordinata ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Prova a identificare diversi elementi fuori ordine e a spostarli nelle posizioni corrette.
            // Se la fetta finisce per essere completamente ordinata, abbiamo finito.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Se il pivot scelto è uguale al predecessore, allora è l'elemento più piccolo nella fetta.
        // Suddividi la sezione in elementi uguali a ed elementi maggiori del pivot.
        // Questo caso viene generalmente rilevato quando la sezione contiene molti elementi duplicati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Continua a ordinare gli elementi più grandi del pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Suddividi la fetta.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dividi la sezione in `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Ricorso solo al lato più corto per ridurre al minimo il numero totale di chiamate ricorsive e consumare meno spazio nello stack.
        // Quindi continua con il lato più lungo (questo è simile alla ricorsione della coda).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Ordina `v` usando il quicksort che sconfigge i pattern, che è *O*(*n*\*log(* n*)) worst-case.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // L'ordinamento non ha un comportamento significativo sui tipi di dimensione zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limita il numero di partizioni sbilanciate a `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Per fette fino a questa lunghezza è probabilmente più veloce ordinarle semplicemente.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Scegli un perno
        let (pivot, _) = choose_pivot(v, is_less);

        // Se il pivot scelto è uguale al predecessore, allora è l'elemento più piccolo nella fetta.
        // Suddividi la sezione in elementi uguali a ed elementi maggiori del pivot.
        // Questo caso viene generalmente rilevato quando la sezione contiene molti elementi duplicati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Se abbiamo superato il nostro indice, allora siamo a posto.
                if mid > index {
                    return;
                }

                // Altrimenti, continua a ordinare gli elementi maggiori del pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dividi la sezione in `left`, `pivot` e `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Se mid==index, allora abbiamo finito, poiché partition() ha garantito che tutti gli elementi dopo mid sono maggiori o uguali a mid.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // L'ordinamento non ha un comportamento significativo sui tipi di dimensione zero.Fare niente.
    } else if index == v.len() - 1 {
        // Trova max element e posizionalo nell'ultima posizione dell'array.
        // Siamo liberi di usare `unwrap()` qui perché sappiamo che v non deve essere vuoto.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Trova l'elemento min e posizionalo nella prima posizione della matrice.
        // Siamo liberi di usare `unwrap()` qui perché sappiamo che v non deve essere vuoto.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}