//! Macro usate dagli iteratori di slice.

// Inlining is_empty e len fa un'enorme differenza di prestazioni
macro_rules! is_empty {
    // Il modo in cui codifichiamo la lunghezza di un iteratore ZST, funziona sia per ZST che per non ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Per eliminare alcuni controlli dei limiti (vedere `position`), calcoliamo la lunghezza in un modo alquanto inaspettato.
// (Testato da `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // a volte veniamo utilizzati all'interno di un blocco non sicuro

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Questo _cannot_ usa `unchecked_sub` perché dipendiamo dal wrapping per rappresentare la lunghezza degli iteratori di slice ZST lunghi.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Sappiamo che `start <= end`, quindi può fare di meglio di `offset_from`, che deve occuparsi di firmato.
            // Impostando i flag appropriati qui possiamo dire a LLVM questo, il che aiuta a rimuovere i controlli dei limiti.
            // SICUREZZA: dal tipo invariante, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Dicendo anche a LLVM che i puntatori sono separati da un multiplo esatto della dimensione del tipo, può ottimizzare `len() == 0` fino a `start == end` invece di `(end - start) < size`.
            //
            // SICUREZZA: In base al tipo invariante, i puntatori sono allineati in modo che il
            //         la distanza tra loro deve essere un multiplo delle dimensioni delle punte
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// La definizione condivisa degli iteratori `Iter` e `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Restituisce il primo elemento e sposta l'inizio dell'iteratore in avanti di 1.
        // Migliora notevolmente le prestazioni rispetto a una funzione inline.
        // L'iteratore non deve essere vuoto.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Restituisce l'ultimo elemento e sposta la fine dell'iteratore all'indietro di 1.
        // Migliora notevolmente le prestazioni rispetto a una funzione inline.
        // L'iteratore non deve essere vuoto.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Riduce l'iteratore quando T è uno ZST, spostando la fine dell'iteratore all'indietro di `n`.
        // `n` non deve superare `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funzione di supporto per la creazione di una sezione dall'iteratore.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SICUREZZA: l'iteratore è stato creato da uno slice con puntatore
                // `self.ptr` e lunghezza `len!(self)`.
                // Ciò garantisce che tutti i prerequisiti per `from_raw_parts` siano soddisfatti.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funzione di aiuto per spostare l'inizio dell'iteratore in avanti di elementi `offset`, restituendo il vecchio inizio.
            //
            // Non sicuro perché l'offset non deve superare `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SICUREZZA: il chiamante garantisce che `offset` non superi `self.len()`,
                    // quindi questo nuovo puntatore è all'interno di `self` e quindi è garantito che non sia nullo.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funzione di aiuto per spostare la fine dell'iteratore all'indietro di elementi `offset`, restituendo la nuova fine.
            //
            // Non sicuro perché l'offset non deve superare `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SICUREZZA: il chiamante garantisce che `offset` non superi `self.len()`,
                    // che è garantito per non sovraccaricare un `isize`.
                    // Inoltre, il puntatore risultante è nei limiti di `slice`, che soddisfa gli altri requisiti per `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // potrebbe essere implementato con le sezioni, ma questo evita il controllo dei limiti

                // SICUREZZA: le chiamate `assume` sono sicure poiché il puntatore di avvio di uno slice
                // deve essere non nullo e anche le sezioni su non ZST devono avere un puntatore finale non nullo.
                // La chiamata a `next_unchecked!` è sicura poiché controlliamo prima se l'iteratore è vuoto.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Questo iteratore è ora vuoto.
                    if mem::size_of::<T>() == 0 {
                        // Dobbiamo farlo in questo modo poiché `ptr` potrebbe non essere mai 0, ma `end` potrebbe esserlo (a causa del wrapping).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SICUREZZA: end non può essere 0 se T non è ZST perché ptr non è 0 e end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SICUREZZA: siamo nei limiti.`post_inc_start` fa la cosa giusta anche per gli ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            // Inoltre, l `assume` evita un controllo dei limiti.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SICUREZZA: siamo garantiti per essere nei limiti dall'invariante del ciclo:
                        // quando `i >= n`, `self.next()` restituisce `None` e il ciclo si interrompe.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Sostituiamo l'implementazione predefinita, che utilizza `try_fold`, perché questa semplice implementazione genera meno IR LLVM ed è più veloce da compilare.
            // Inoltre, l `assume` evita un controllo dei limiti.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SICUREZZA: `i` deve essere inferiore a `n` poiché inizia da `n`
                        // e sta solo diminuendo.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SICUREZZA: il chiamante deve garantire che `i` sia nei limiti di
                // la slice sottostante, quindi `i` non può superare un `isize`, e si garantisce che i riferimenti restituiti si riferiscano a un elemento della slice e quindi la validità è garantita.
                //
                // Si noti inoltre che il chiamante garantisce anche che non saremo mai più chiamati con lo stesso indice e che non vengono chiamati altri metodi che accederanno a questa sottosezione, quindi è valido che il riferimento restituito sia modificabile nel caso di
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // potrebbe essere implementato con le sezioni, ma questo evita il controllo dei limiti

                // SICUREZZA: le chiamate `assume` sono sicure poiché il puntatore di inizio di una fetta deve essere non nullo,
                // e le sezioni su non ZST devono anche avere un puntatore finale non nullo.
                // La chiamata a `next_back_unchecked!` è sicura poiché controlliamo prima se l'iteratore è vuoto.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Questo iteratore è ora vuoto.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SICUREZZA: siamo nei limiti.`pre_dec_end` fa la cosa giusta anche per gli ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}