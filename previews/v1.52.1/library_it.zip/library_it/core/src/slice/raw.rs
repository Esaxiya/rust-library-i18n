//! Funzioni gratuite per creare `&[T]` e `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Forma una fetta da un puntatore e una lunghezza.
///
/// L'argomento `len` è il numero di **elementi**, non il numero di byte.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `data` deve essere [valid] per letture per `len * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
///
///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
///       Le sezioni non possono mai estendersi su più oggetti allocati.Vedere [below](#incorrect-usage) per un esempio che non tiene conto in modo errato di ciò.
///     * `data` deve essere non nullo e allineato anche per le sezioni di lunghezza zero.
///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
///
/// * `data` deve puntare a `len` valori consecutivi correttamente inizializzati di tipo `T`.
///
/// * La memoria a cui fa riferimento la slice restituita non deve essere modificata per tutta la durata di `'a`, tranne all'interno di un `UnsafeCell`.
///
/// * La dimensione totale `len * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
///
/// # Caveat
///
/// La durata della sezione restituita viene dedotta dal suo utilizzo.
/// Per evitare un uso improprio accidentale, si consiglia di legare la durata a qualsiasi durata di origine sia sicura nel contesto, ad esempio fornendo una funzione di supporto che prenda la durata di un valore host per la sezione o mediante annotazioni esplicite.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestare uno slice per un singolo elemento
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Utilizzo errato
///
/// La seguente funzione `join_slices` è **non valida** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // L'asserzione precedente garantisce che `fst` e `snd` siano contigui, ma potrebbero comunque essere contenuti all'interno di _different allocated objects_, nel qual caso la creazione di questa sezione è un comportamento indefinito.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` e `b` sono diversi oggetti allocati ...
///     let a = 42;
///     let b = 27;
///     // ... che può tuttavia essere disposto in modo contiguo nella memoria: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Esegue la stessa funzionalità di [`from_raw_parts`], tranne per il fatto che viene restituita una slice modificabile.
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `data` deve essere [valid] sia per le letture che per le scritture per `len * mem::size_of::<T>()` molti byte e deve essere allineato correttamente.Ciò significa in particolare:
///
///     * L'intero intervallo di memoria di questa slice deve essere contenuto in un singolo oggetto allocato!
///       Le sezioni non possono mai estendersi su più oggetti allocati.
///     * `data` deve essere non nullo e allineato anche per le sezioni di lunghezza zero.
///     Uno dei motivi è che le ottimizzazioni del layout di enum possono fare affidamento su riferimenti (inclusi segmenti di qualsiasi lunghezza) allineati e non nulli per distinguerli da altri dati.
///
///     È possibile ottenere un puntatore utilizzabile come `data` per sezioni di lunghezza zero utilizzando [`NonNull::dangling()`].
///
/// * `data` deve puntare a `len` valori consecutivi correttamente inizializzati di tipo `T`.
///
/// * Non è necessario accedere alla memoria a cui fa riferimento la slice restituita tramite nessun altro puntatore (non derivato dal valore restituito) per la durata di `'a`.
///   Sia l'accesso in lettura che in scrittura sono vietati.
///
/// * La dimensione totale `len * mem::size_of::<T>()` dello slice non deve essere maggiore di `isize::MAX`.
///   Vedere la documentazione sulla sicurezza di [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SICUREZZA: il chiamante deve rispettare il contratto di sicurezza per `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Converte un riferimento a T in una sezione di lunghezza 1 (senza copiare).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Converte un riferimento a T in una sezione di lunghezza 1 (senza copiare).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}