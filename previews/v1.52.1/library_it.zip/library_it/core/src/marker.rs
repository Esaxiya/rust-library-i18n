//! Primitive traits e tipi che rappresentano le proprietà di base dei tipi.
//!
//! I tipi Rust possono essere classificati in vari modi utili in base alle loro proprietà intrinseche.
//! Queste classificazioni sono rappresentate come traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipi che possono essere trasferiti attraverso i confini del thread.
///
/// Questo trait viene implementato automaticamente quando il compilatore determina che è appropriato.
///
/// Un esempio di un tipo non "Invia" è il puntatore per il conteggio dei riferimenti [`rc::Rc`][`Rc`].
/// Se due thread tentano di clonare [`Rc`] che puntano allo stesso valore di conteggio dei riferimenti, potrebbero provare ad aggiornare il conteggio dei riferimenti contemporaneamente, che è [undefined behavior][ub] perché [`Rc`] non utilizza operazioni atomiche.
///
/// Suo cugino [`sync::Arc`][arc] utilizza operazioni atomiche (che incorrono in un sovraccarico) e quindi è `Send`.
///
/// Vedi [the Nomicon](../../nomicon/send-and-sync.html) per maggiori dettagli.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipi con una dimensione costante nota in fase di compilazione.
///
/// Tutti i parametri di tipo hanno un limite implicito di `Sized`.La sintassi speciale `?Sized` può essere utilizzata per rimuovere questo limite se non è appropriato.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//errore: Sized non è implementato per [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// L'unica eccezione è il tipo `Self` implicito di uno trait.
/// Uno trait non ha un limite `Sized` implicito in quanto questo è incompatibile con [trait object] dove, per definizione, lo trait deve funzionare con tutti i possibili implementatori, e quindi potrebbe essere di qualsiasi dimensione.
///
///
/// Sebbene Rust ti consentirà di legare `Sized` a uno trait, non sarai in grado di usarlo per formare un oggetto trait in seguito:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // sia y: &dyn Bar= &Impl;//errore: lo trait `Bar` non può essere trasformato in un oggetto
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // per Default, ad esempio, che richiede che `[T]: !Default` sia valutabile
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipi che possono essere "unsized" in un tipo di dimensioni dinamiche.
///
/// Ad esempio, il tipo di array dimensionato `[i8; 2]` implementa `Unsize<[i8]>` e `Unsize<dyn fmt::Debug>`.
///
/// Tutte le implementazioni di `Unsize` vengono fornite automaticamente dal compilatore.
///
/// `Unsize` è implementato per:
///
/// - `[T; N]` è `Unsize<[T]>`
/// - `T` è `Unsize<dyn Trait>` quando `T: Trait`
/// - `Foo<..., T, ...>` è `Unsize<Foo<..., U, ...>>` se:
///   - `T: Unsize<U>`
///   - Foo è una struttura
///   - Solo l'ultimo campo di `Foo` ha un tipo che coinvolge `T`
///   - `T` non fa parte del tipo di altri campi
///   - `Bar<T>: Unsize<Bar<U>>`, se l'ultimo campo di `Foo` è di tipo `Bar<T>`
///
/// `Unsize` viene utilizzato insieme a [`ops::CoerceUnsized`] per consentire ai contenitori "user-defined" come [`Rc`] di contenere tipi di dimensioni dinamiche.
/// Vedere [DST coercion RFC][RFC982] e [the nomicon entry on coercion][nomicon-coerce] per maggiori dettagli.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait richiesto per le costanti utilizzate nelle corrispondenze di pattern.
///
/// Qualsiasi tipo che derivi `PartialEq` implementa automaticamente questo trait,*indipendentemente* dal fatto che i suoi parametri di tipo implementino `Eq`.
///
/// Se un elemento `const` contiene un tipo che non implementa questo trait, allora quel tipo (1.) non implementa `PartialEq` (il che significa che la costante non fornirà quel metodo di confronto, che la generazione del codice presume sia disponibile), o (2.) implementa *il proprio* versione di `PartialEq` (che presumiamo non sia conforme a un confronto di uguaglianza strutturale).
///
///
/// In uno dei due scenari precedenti, rifiutiamo l'uso di una tale costante in una corrispondenza di pattern.
///
/// Vedi anche [structural match RFC][RFC1445] e [issue 63438] che hanno motivato la migrazione dal design basato sugli attributi a questo trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait richiesto per le costanti utilizzate nelle corrispondenze di pattern.
///
/// Qualsiasi tipo che derivi `Eq` implementa automaticamente questo trait,*indipendentemente* dal fatto che i suoi parametri di tipo implementino `Eq`.
///
/// Questo è un trucco per aggirare una limitazione nel nostro sistema di tipi.
///
/// # Background
///
/// Vogliamo richiedere che i tipi di const utilizzati nelle corrispondenze di pattern abbiano l'attributo `#[derive(PartialEq, Eq)]`.
///
/// In un mondo più ideale, potremmo verificare quel requisito semplicemente controllando che il tipo dato implementi sia `StructuralPartialEq` trait *che*`Eq` trait.
/// Tuttavia, puoi avere ADT che *fanno*`derive(PartialEq, Eq)`, ed è un caso che vogliamo che il compilatore accetti, e tuttavia il tipo della costante non riesce a implementare `Eq`.
///
/// Vale a dire, un caso come questo:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Il problema nel codice sopra è che `Wrap<fn(&())>` non implementa `PartialEq`, né `Eq`, perché `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Pertanto, non possiamo fare affidamento su un controllo ingenuo per `StructuralPartialEq` e solo per `Eq`.
///
/// Come trucco per aggirare questo problema, utilizziamo due traits separati iniettati da ciascuna delle due derivate (`#[derive(PartialEq)]` e `#[derive(Eq)]`) e controlliamo che entrambi siano presenti come parte del controllo di corrispondenza strutturale.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipi i cui valori possono essere duplicati semplicemente copiando i bit.
///
/// Per impostazione predefinita, le associazioni di variabili hanno "semantica di spostamento".In altre parole:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` si è spostato in `y` e quindi non può essere utilizzato
///
/// // println! ("{: ?}", x);//errore: utilizzo del valore spostato
/// ```
///
/// Tuttavia, se un tipo implementa `Copy`, ha invece 'copia semantica':
///
/// ```
/// // Possiamo derivare un'implementazione `Copy`.
/// // `Clone` è anche richiesto, in quanto è un supertrait di `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` è una copia di `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// È importante notare che in questi due esempi, l'unica differenza è se è consentito accedere a `x` dopo l'assegnazione.
/// Sotto il cofano, sia una copia che una mossa possono comportare la copia di bit in memoria, anche se a volte questo è ottimizzato.
///
/// ## Come posso implementare `Copy`?
///
/// Ci sono due modi per implementare `Copy` sul tuo tipo.Il più semplice è usare `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Puoi anche implementare `Copy` e `Clone` manualmente:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// C'è una piccola differenza tra i due: la strategia `derive` posizionerà anche un limite `Copy` sui parametri di tipo, che non è sempre desiderato.
///
/// ## Qual è la differenza tra `Copy` e `Clone`?
///
/// Le copie avvengono implicitamente, ad esempio come parte di un'assegnazione `y = x`.Il comportamento di `Copy` non è sovraccaricabile;è sempre una semplice copia un po 'saggia.
///
/// La clonazione è un'azione esplicita, `x.clone()`.L'implementazione di [`Clone`] può fornire qualsiasi comportamento specifico del tipo necessario per duplicare i valori in modo sicuro.
/// Ad esempio, l'implementazione di [`Clone`] per [`String`] deve copiare il buffer di stringa puntato nell'heap.
/// Una semplice copia bit per bit dei valori [`String`] copierebbe semplicemente il puntatore, portando a un doppio libero lungo la linea.
/// Per questo motivo, [`String`] è [`Clone`] ma non `Copy`.
///
/// [`Clone`] è un supertrait di `Copy`, quindi tutto ciò che è `Copy` deve implementare anche [`Clone`].
/// Se un tipo è `Copy`, la sua implementazione [`Clone`] deve solo restituire `*self` (vedere l'esempio sopra).
///
/// ## Quando il mio tipo può essere `Copy`?
///
/// Un tipo può implementare `Copy` se tutti i suoi componenti implementano `Copy`.Ad esempio, questa struttura può essere `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Una struttura può essere `Copy` e [`i32`] è `Copy`, quindi `Point` può essere `Copy`.
/// Al contrario, considera
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// La struttura `PointList` non può implementare `Copy`, perché [`Vec<T>`] non è `Copy`.Se proviamo a derivare un'implementazione `Copy`, otterremo un errore:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// I riferimenti condivisi (`&T`) sono anche `Copy`, quindi un tipo può essere `Copy`, anche quando contiene riferimenti condivisi di tipi `T` che *non*`Copy`.
/// Considera la seguente struttura, che può implementare `Copy`, perché contiene solo un *riferimento condiviso* al nostro tipo `PointList` non "Copia" dall'alto:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Quando *non* il mio tipo può essere `Copy`?
///
/// Alcuni tipi non possono essere copiati in modo sicuro.Ad esempio, la copia di `&mut T` creerebbe un riferimento modificabile con alias.
/// Copiare [`String`] duplicherebbe la responsabilità della gestione del buffer di [`String`], portando a un doppio free.
///
/// Generalizzando quest'ultimo caso, qualsiasi tipo che implementa [`Drop`] non può essere `Copy`, perché gestisce alcune risorse oltre ai propri byte [`size_of::<T>`].
///
/// Se provi a implementare `Copy` su una struttura o enum contenente dati non "Copia", otterrai l'errore [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Quando *dovrebbe* il mio tipo essere `Copy`?
///
/// In generale, se il tuo tipo _can_ implementa `Copy`, dovrebbe.
/// Tieni presente, tuttavia, che l'implementazione di `Copy` fa parte dell'API pubblica del tuo tipo.
/// Se il tipo potrebbe diventare non-`Copy` in future, potrebbe essere prudente omettere l'implementazione di `Copy` ora, per evitare un cambiamento di API di rottura.
///
/// ## Implementatori aggiuntivi
///
/// Oltre a [implementors listed below][impls], i seguenti tipi implementano anche `Copy`:
///
/// * Tipi di elementi funzione (ovvero, i tipi distinti definiti per ciascuna funzione)
/// * Tipi di puntatori a funzione (ad es. `fn() -> i32`)
/// * Tipi di array, per tutte le dimensioni, se il tipo di elemento implementa anche `Copy` (ad esempio, `[i32; 123456]`)
/// * Tipi di tupla, se ogni componente implementa anche `Copy` (ad esempio, `()`, `(i32, bool)`)
/// * Tipi di chiusura, se non acquisiscono alcun valore dall'ambiente o se tutti questi valori acquisiti implementano `Copy` da soli.
///   Si noti che le variabili catturate dal riferimento condiviso implementano sempre `Copy` (anche se il referente non lo fa), mentre le variabili catturate dal riferimento mutabile non implementano mai `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ciò consente di copiare un tipo che non implementa `Copy` a causa di limiti di durata insoddisfatti (copia `A<'_>` quando solo `A<'static>: Copy` e `A<'_>: Clone`).
// Abbiamo questo attributo qui per ora solo perché ci sono alcune specializzazioni esistenti su `Copy` che già esistono nella libreria standard e non c'è modo di avere questo comportamento in modo sicuro in questo momento.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Deriva macro generando un impl di trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipi per i quali è sicuro condividere i riferimenti tra i thread.
///
/// Questo trait viene implementato automaticamente quando il compilatore determina che è appropriato.
///
/// La definizione precisa è: un tipo `T` è [`Sync`] se e solo se `&T` è [`Send`].
/// In altre parole, se non c'è la possibilità di [undefined behavior][ub] (comprese le gare di dati) quando si passano riferimenti `&T` tra i thread.
///
/// Come ci si aspetterebbe, i tipi primitivi come [`u8`] e [`f64`] sono tutti [`Sync`], così come i tipi aggregati semplici che li contengono, come tuple, strutture ed enumerazioni.
/// Altri esempi di tipi [`Sync`] di base includono i tipi "immutable" come `&T` e quelli con semplice mutabilità ereditata, come [`Box<T>`][box], [`Vec<T>`][vec] e la maggior parte degli altri tipi di raccolta.
///
/// (I parametri generici devono essere [`Sync`] perché il loro contenitore sia [`Sync`].)
///
/// Una conseguenza in qualche modo sorprendente della definizione è che `&mut T` è `Sync` (se `T` è `Sync`) anche se sembra che ciò possa fornire una mutazione non sincronizzata.
/// Il trucco è che un riferimento mutabile dietro un riferimento condiviso (cioè `& &mut T`) diventa di sola lettura, come se fosse un `& &T`.
/// Quindi non c'è rischio di una corsa di dati.
///
/// I tipi che non sono `Sync` sono quelli che hanno "interior mutability" in una forma non thread-safe, come [`Cell`][cell] e [`RefCell`][refcell].
/// Questi tipi consentono la mutazione dei loro contenuti anche attraverso un riferimento immutabile e condiviso.
/// Ad esempio, il metodo `set` su [`Cell<T>`][cell] accetta `&self`, quindi richiede solo un riferimento condiviso [`&Cell<T>`][cell].
/// Il metodo non esegue la sincronizzazione, quindi [`Cell`][cell] non può essere `Sync`.
///
/// Un altro esempio di tipo non "Sync" è il puntatore per il conteggio dei riferimenti [`Rc`][rc].
/// Dato un qualsiasi riferimento [`&Rc<T>`][rc], è possibile clonare un nuovo [`Rc<T>`][rc], modificando i conteggi dei riferimenti in modo non atomico.
///
/// Per i casi in cui è necessaria la mutabilità interna thread-safe, Rust fornisce [atomic data types], oltre al blocco esplicito tramite [`sync::Mutex`][mutex] e [`sync::RwLock`][rwlock].
/// Questi tipi assicurano che qualsiasi mutazione non possa causare gare di dati, quindi i tipi sono `Sync`.
/// Allo stesso modo, [`sync::Arc`][arc] fornisce un analogo thread-safe di [`Rc`][rc].
///
/// Tutti i tipi con mutabilità interna devono anche utilizzare il wrapper [`cell::UnsafeCell`][unsafecell] attorno all value(s) che può essere modificato tramite un riferimento condiviso.
/// Non riuscendo a farlo è [undefined behavior][ub].
/// Ad esempio, [`transmute`][transmute]-ing da `&T` a `&mut T` non è valido.
///
/// Vedere [the Nomicon][nomicon-send-and-sync] per maggiori dettagli su `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): una volta che il supporto per aggiungere note in `rustc_on_unimplemented` arriva in beta, ed è stato esteso per verificare se una chiusura è ovunque nella catena dei requisiti, estenderla come tale (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tipo di dimensione zero utilizzato per contrassegnare le cose che "act like" possiedono un `T`.
///
/// L'aggiunta di un campo `PhantomData<T>` al tuo tipo dice al compilatore che il tuo tipo si comporta come se memorizzasse un valore di tipo `T`, anche se in realtà non lo fa.
/// Queste informazioni vengono utilizzate durante il calcolo di determinate proprietà di sicurezza.
///
/// Per una spiegazione più approfondita di come utilizzare `PhantomData<T>`, vedere [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Una nota orribile 👻👻👻
///
/// Sebbene entrambi abbiano nomi spaventosi, `PhantomData` e "tipi fantasma" sono correlati, ma non identici.Un parametro di tipo fantasma è semplicemente un parametro di tipo che non viene mai utilizzato.
/// In Rust, questo spesso fa lamentare il compilatore e la soluzione è aggiungere un uso "dummy" tramite `PhantomData`.
///
/// # Examples
///
/// ## Parametri di durata non utilizzati
///
/// Forse il caso d'uso più comune per `PhantomData` è una struttura che ha un parametro di durata inutilizzato, tipicamente come parte di un codice non sicuro.
/// Ad esempio, ecco una struttura `Slice` che ha due puntatori di tipo `*const T`, presumibilmente che puntano a un array da qualche parte:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// L'intenzione è che i dati sottostanti siano validi solo per la durata di `'a`, quindi `Slice` non dovrebbe sopravvivere a `'a`.
/// Tuttavia, questo intento non è espresso nel codice, poiché non ci sono usi della durata di `'a` e quindi non è chiaro a quali dati si applica.
/// Possiamo correggerlo dicendo al compilatore di agire *come se* la struttura `Slice` contenesse un riferimento `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Anche questo a sua volta richiede l'annotazione `T: 'a`, che indica che tutti i riferimenti in `T` sono validi per tutta la durata di `'a`.
///
/// Quando si inizializza un `Slice`, fornire semplicemente il valore `PhantomData` per il campo `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametri di tipo non utilizzati
///
/// A volte capita di avere parametri di tipo inutilizzati che indicano a quale tipo di dati è "tied" una struttura, anche se quei dati non si trovano effettivamente nella struttura stessa.
/// Ecco un esempio in cui ciò si verifica con [FFI].
/// L'interfaccia esterna utilizza handle di tipo `*mut ()` per fare riferimento a valori Rust di diversi tipi.
/// Tracciamo il tipo Rust utilizzando un parametro di tipo fantasma sulla struct `ExternalResource` che avvolge un handle.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Proprietà e controllo di consegna
///
/// L'aggiunta di un campo di tipo `PhantomData<T>` indica che il tipo possiede dati di tipo `T`.Ciò a sua volta implica che quando il tuo tipo viene eliminato, potrebbe cadere una o più istanze del tipo `T`.
/// Ciò influisce sull'analisi [drop check] del compilatore Rust.
///
/// Se la tua struttura in effetti *possiede* i dati di tipo `T`, è meglio usare un tipo di riferimento, come `PhantomData<&'a T>` (ideally) o `PhantomData<*const T>` (se non si applica la durata), in modo da non indicare la proprietà.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait interno al compilatore utilizzato per indicare il tipo di discriminanti enum.
///
/// Questo trait viene implementato automaticamente per ogni tipo e non aggiunge alcuna garanzia a [`mem::Discriminant`].
/// È un **comportamento indefinito** trasmutare tra `DiscriminantKind::Discriminant` e `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Il tipo di discriminante, che deve soddisfare lo trait bounds richiesto da `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait interno al compilatore utilizzato per determinare se un tipo contiene internamente `UnsafeCell`, ma non tramite un riferimento indiretto.
///
/// Ciò influisce, ad esempio, se un `static` di quel tipo viene inserito nella memoria statica di sola lettura o nella memoria statica scrivibile.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipi che possono essere spostati in sicurezza dopo essere stati bloccati.
///
/// Rust stesso non ha la nozione di tipi immobili e considera le mosse (ad esempio, tramite assegnazione o [`mem::replace`]) sempre sicure.
///
/// Il tipo [`Pin`][Pin] viene invece utilizzato per impedire gli spostamenti attraverso il sistema dei tipi.I puntatori `P<T>` avvolti nel wrapper [`Pin<P<T>>`][Pin] non possono essere spostati fuori.
/// Vedere la documentazione di [`pin` module] per ulteriori informazioni sul blocco.
///
/// L'implementazione di `Unpin` trait per `T` elimina le limitazioni del blocco del tipo, che consente quindi di spostare `T` fuori da [`Pin<P<T>>`][Pin] con funzioni come [`mem::replace`].
///
///
/// `Unpin` non ha alcuna conseguenza per i dati non bloccati.
/// In particolare, [`mem::replace`] sposta felicemente i dati `!Unpin` (funziona per qualsiasi `&mut T`, non solo quando `T: Unpin`).
/// Tuttavia, non è possibile utilizzare [`mem::replace`] su dati racchiusi in un [`Pin<P<T>>`][Pin] perché non è possibile ottenere l `&mut T` di cui si ha bisogno, e *questo* è ciò che fa funzionare questo sistema.
///
/// Quindi questo, ad esempio, può essere fatto solo sui tipi che implementano `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Abbiamo bisogno di un riferimento mutabile per chiamare `mem::replace`.
/// // Possiamo ottenere tale riferimento da (implicitly) invocando `Pin::deref_mut`, ma ciò è possibile solo perché `String` implementa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Questo trait viene implementato automaticamente per quasi tutti i tipi.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Un tipo di marker che non implementa `Unpin`.
///
/// Se un tipo contiene un `PhantomPinned`, non implementerà `Unpin` per impostazione predefinita.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementazioni di `Copy` per tipi primitivi.
///
/// Le implementazioni che non possono essere descritte in Rust vengono implementate in `traits::SelectionContext::copy_clone_conditions()` in `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// I riferimenti condivisi possono essere copiati, ma i riferimenti modificabili *non possono*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}