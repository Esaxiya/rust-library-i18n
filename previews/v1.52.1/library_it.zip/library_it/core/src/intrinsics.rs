//! Elementi intrinseci del compilatore.
//!
//! Le definizioni corrispondenti sono in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Le implementazioni cost corrispondenti sono in `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Costanti intrinseche
//!
//! Note: qualsiasi modifica alla costanza degli intrinseci dovrebbe essere discussa con il team linguistico.
//! Ciò include i cambiamenti nella stabilità della costanza.
//!
//! Per rendere un intrinseco utilizzabile in fase di compilazione, è necessario copiare l'implementazione da <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> a `compiler/rustc_mir/src/interpret/intrinsics.rs` e aggiungere un `#[rustc_const_unstable(feature = "foo", issue = "01234")]` all'intrinseco.
//!
//!
//! Se si suppone che un intrinseco debba essere utilizzato da un `const fn` con un attributo `rustc_const_stable`, anche l'attributo dell'intrinseco deve essere `rustc_const_stable`.
//! Una tale modifica non dovrebbe essere eseguita senza la consultazione di T-lang, perché inserisce nel linguaggio una funzionalità che non può essere replicata nel codice utente senza il supporto del compilatore.
//!
//! # Volatiles
//!
//! Gli intrinseci volatili forniscono operazioni destinate ad agire sulla memoria I/O, che sono garantite per non essere riordinate dal compilatore su altri elementi intrinseci volatili.Vedere la documentazione LLVM su [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Gli intrinseci atomici forniscono operazioni atomiche comuni sulle parole macchina, con più possibili ordinamenti di memoria.Obbediscono alla stessa semantica di C++ 11.Vedere la documentazione LLVM su [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Un rapido aggiornamento sull'ordinamento della memoria:
//!
//! * Acquire, una barriera per l'acquisizione di un lucchetto.Le successive letture e scritture avvengono dopo la barriera.
//! * Release, una barriera per il rilascio di una serratura.Le letture e le scritture precedenti avvengono prima della barriera.
//! * È garantito che le operazioni coerenti sequenzialmente e sequenzialmente si svolgano in ordine.Questa è la modalità standard per lavorare con i tipi atomici ed è equivalente a `volatile` di Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Queste importazioni vengono utilizzate per semplificare i collegamenti intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SICUREZZA: vedi `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, questi intrinseci accettano puntatori non elaborati perché mutano la memoria con alias, che non è valido né per `&` né per `&mut`.
    //

    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::SeqCst`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::Acquire`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::Release`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::AcqRel`] come `success` e [`Ordering::Acquire`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::Relaxed`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::SeqCst`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::SeqCst`] come `success` e [`Ordering::Acquire`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::Acquire`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange` passando [`Ordering::AcqRel`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::SeqCst`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::Acquire`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::Release`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::AcqRel`] come `success` e [`Ordering::Acquire`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::Relaxed`] sia come parametri `success` che `failure`.
    ///
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::SeqCst`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::SeqCst`] come `success` e [`Ordering::Acquire`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::Acquire`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Memorizza un valore se il valore corrente è uguale al valore `old`.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `compare_exchange_weak` passando [`Ordering::AcqRel`] come `success` e [`Ordering::Relaxed`] come parametri `failure`.
    /// Per esempio, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Carica il valore corrente del puntatore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `load` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Carica il valore corrente del puntatore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `load` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Carica il valore corrente del puntatore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `load` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Memorizza il valore nella posizione di memoria specificata.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `store` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Memorizza il valore nella posizione di memoria specificata.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `store` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Memorizza il valore nella posizione di memoria specificata.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `store` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Memorizza il valore nella posizione di memoria specificata, restituendo il vecchio valore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `swap` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza il valore nella posizione di memoria specificata, restituendo il vecchio valore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `swap` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza il valore nella posizione di memoria specificata, restituendo il vecchio valore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `swap` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza il valore nella posizione di memoria specificata, restituendo il vecchio valore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `swap` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Memorizza il valore nella posizione di memoria specificata, restituendo il vecchio valore.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `swap` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Aggiunge al valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_add` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aggiunge al valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_add` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aggiunge al valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_add` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aggiunge al valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_add` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Aggiunge al valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_add` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Sottrai dal valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_sub` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottrai dal valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_sub` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottrai dal valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_sub` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottrai dal valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_sub` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Sottrai dal valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_sub` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise e con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_and` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_and` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_and` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_and` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise e con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_and` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Nand bit per bit con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sul tipo [`AtomicBool`] tramite il metodo `fetch_nand` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit per bit con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sul tipo [`AtomicBool`] tramite il metodo `fetch_nand` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit per bit con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sul tipo [`AtomicBool`] tramite il metodo `fetch_nand` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit per bit con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sul tipo [`AtomicBool`] tramite il metodo `fetch_nand` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Nand bit per bit con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sul tipo [`AtomicBool`] tramite il metodo `fetch_nand` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise o con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_or` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_or` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_or` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_or` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise o con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_or` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_xor` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_xor` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_xor` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_xor` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor con il valore corrente, restituendo il valore precedente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi [`atomic`] tramite il metodo `fetch_xor` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto con segno.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile sui tipi interi con segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_min` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::SeqCst`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Acquire`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Release`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::AcqRel`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimo con il valore corrente utilizzando un confronto senza segno.
    ///
    /// La versione stabilizzata di questo elemento intrinseco è disponibile sui tipi interi senza segno [`atomic`] tramite il metodo `fetch_max` passando [`Ordering::Relaxed`] come `order`.
    /// Per esempio, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// L'intrinseco `prefetch` è un suggerimento per il generatore di codice di inserire un'istruzione di prefetch se supportata;altrimenti, è un no-op.
    /// I precaricamenti non hanno effetto sul comportamento del programma ma possono modificare le sue caratteristiche di prestazione.
    ///
    /// L'argomento `locality` deve essere un numero intero costante ed è un identificatore di località temporale che va da (0), nessuna località, a (3), conservazione estremamente locale nella cache.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// L'intrinseco `prefetch` è un suggerimento per il generatore di codice di inserire un'istruzione di prefetch se supportata;altrimenti, è un no-op.
    /// I precaricamenti non hanno effetto sul comportamento del programma ma possono modificare le sue caratteristiche di prestazione.
    ///
    /// L'argomento `locality` deve essere un numero intero costante ed è un identificatore di località temporale che va da (0), nessuna località, a (3), conservazione estremamente locale nella cache.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// L'intrinseco `prefetch` è un suggerimento per il generatore di codice di inserire un'istruzione di prefetch se supportata;altrimenti, è un no-op.
    /// I precaricamenti non hanno effetto sul comportamento del programma ma possono modificare le sue caratteristiche di prestazione.
    ///
    /// L'argomento `locality` deve essere un numero intero costante ed è un identificatore di località temporale che va da (0), nessuna località, a (3), conservazione estremamente locale nella cache.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// L'intrinseco `prefetch` è un suggerimento per il generatore di codice di inserire un'istruzione di prefetch se supportata;altrimenti, è un no-op.
    /// I precaricamenti non hanno effetto sul comportamento del programma ma possono modificare le sue caratteristiche di prestazione.
    ///
    /// L'argomento `locality` deve essere un numero intero costante ed è un identificatore di località temporale che va da (0), nessuna località, a (3), conservazione estremamente locale nella cache.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Un recinto atomico.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::fence`] passando [`Ordering::SeqCst`] come `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Un recinto atomico.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::fence`] passando [`Ordering::Acquire`] come `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Un recinto atomico.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::fence`] passando [`Ordering::Release`] come `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Un recinto atomico.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::fence`] passando [`Ordering::AcqRel`] come `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Una barriera di memoria solo per il compilatore.
    ///
    /// Gli accessi alla memoria non verranno mai riordinati attraverso questa barriera dal compilatore, ma non verranno emesse istruzioni per esso.
    /// Ciò è appropriato per le operazioni sullo stesso thread che possono essere anticipate, ad esempio quando si interagisce con i gestori di segnali.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::compiler_fence`] passando [`Ordering::SeqCst`] come `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Una barriera di memoria solo per il compilatore.
    ///
    /// Gli accessi alla memoria non verranno mai riordinati attraverso questa barriera dal compilatore, ma non verranno emesse istruzioni per esso.
    /// Ciò è appropriato per le operazioni sullo stesso thread che possono essere anticipate, ad esempio quando si interagisce con i gestori di segnali.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::compiler_fence`] passando [`Ordering::Acquire`] come `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Una barriera di memoria solo per il compilatore.
    ///
    /// Gli accessi alla memoria non verranno mai riordinati attraverso questa barriera dal compilatore, ma non verranno emesse istruzioni per esso.
    /// Ciò è appropriato per le operazioni sullo stesso thread che possono essere anticipate, ad esempio quando si interagisce con i gestori di segnali.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::compiler_fence`] passando [`Ordering::Release`] come `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Una barriera di memoria solo per il compilatore.
    ///
    /// Gli accessi alla memoria non verranno mai riordinati attraverso questa barriera dal compilatore, ma non verranno emesse istruzioni per esso.
    /// Ciò è appropriato per le operazioni sullo stesso thread che possono essere anticipate, ad esempio quando si interagisce con i gestori di segnali.
    ///
    /// La versione stabilizzata di questo intrinseco è disponibile in [`atomic::compiler_fence`] passando [`Ordering::AcqRel`] come `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magia intrinseca che deriva il suo significato dagli attributi legati alla funzione.
    ///
    /// Ad esempio, dataflow lo utilizza per iniettare asserzioni statiche in modo che `rustc_peek(potentially_uninitialized)` verifichi effettivamente che il flusso di dati abbia effettivamente calcolato che non è inizializzato in quel punto del flusso di controllo.
    ///
    ///
    /// Questo intrinseco non deve essere utilizzato al di fuori del compilatore.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Interrompe l'esecuzione del processo.
    ///
    /// Una versione più user-friendly e stabile di questa operazione è [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informa l'ottimizzatore che questo punto nel codice non è raggiungibile, consentendo ulteriori ottimizzazioni.
    ///
    /// NB, questo è molto diverso dalla macro `unreachable!()`: a differenza della macro, che panics quando viene eseguita, è *comportamento indefinito* raggiungere il codice contrassegnato con questa funzione.
    ///
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informa l'ottimizzatore che una condizione è sempre vera.
    /// Se la condizione è falsa, il comportamento non è definito.
    ///
    /// Nessun codice viene generato per questo intrinseco, ma l'ottimizzatore proverà a preservarlo (e le sue condizioni) tra i passaggi, il che potrebbe interferire con l'ottimizzazione del codice circostante e ridurre le prestazioni.
    /// Non deve essere utilizzato se l'invariante può essere rilevato dall'ottimizzatore da solo o se non consente ottimizzazioni significative.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Suggerimenti al compilatore che probabilmente la condizione branch è vera.
    /// Restituisce il valore passato ad esso.
    ///
    /// Qualsiasi utilizzo diverso dalle istruzioni `if` probabilmente non avrà alcun effetto.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Suggerisce al compilatore che la condizione branch potrebbe essere falsa.
    /// Restituisce il valore passato ad esso.
    ///
    /// Qualsiasi utilizzo diverso dalle istruzioni `if` probabilmente non avrà alcun effetto.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Esegue una trap del punto di interruzione, per l'ispezione da parte di un debugger.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn breakpoint();

    /// La dimensione di un tipo in byte.
    ///
    /// Più specificamente, questo è l'offset in byte tra elementi successivi dello stesso tipo, incluso il riempimento dell'allineamento.
    ///
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// L'allineamento minimo di un tipo.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// L'allineamento preferito di un tipo.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// La dimensione del valore di riferimento in byte.
    ///
    /// La versione stabilizzata di questo intrinseco è [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// L'allineamento richiesto del valore di riferimento.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Ottiene una sezione di stringa statica contenente il nome di un tipo.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Ottiene un identificatore globalmente univoco per il tipo specificato.
    /// Questa funzione restituirà lo stesso valore per un tipo indipendentemente dallo crate in cui viene richiamato.
    ///
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Una guardia per funzioni non sicure che non possono mai essere eseguite se `T` è disabitato:
    /// Questo staticamente panic o non fa nulla.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Una guardia per le funzioni non sicure che non possono essere eseguite se `T` non consente l'inizializzazione zero: questo staticamente panic o non farà nulla.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn assert_zero_valid<T>();

    /// Una guardia per le funzioni non sicure che non possono mai essere eseguite se `T` ha schemi di bit non validi: questo sarà staticamente panic o non farà nulla.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn assert_uninit_valid<T>();

    /// Ottiene un riferimento a un `Location` statico che indica dove è stato chiamato.
    ///
    /// Considera invece l'utilizzo di [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Sposta un valore fuori dall'ambito senza eseguire il drop glue.
    ///
    /// Questo esiste solo per [`mem::forget_unsized`];normale `forget` utilizza invece `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterpreta i bit di un valore di un tipo come un altro tipo.
    ///
    /// Entrambi i tipi devono avere le stesse dimensioni.
    /// Né l'originale, né il risultato, possono essere un [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` è semanticamente equivalente a uno spostamento bit per bit di un tipo in un altro.Copia i bit dal valore di origine nel valore di destinazione, quindi dimentica l'originale.
    /// È equivalente all `memcpy` di C sotto il cofano, proprio come `transmute_copy`.
    ///
    /// Poiché `transmute` è un'operazione in base al valore, l'allineamento dei *valori trasmutati* non è un problema.
    /// Come con qualsiasi altra funzione, il compilatore garantisce già che `T` e `U` siano allineati correttamente.
    /// Tuttavia, quando si trasmettono valori che *puntano altrove*(come puntatori, riferimenti, riquadri ...), il chiamante deve garantire il corretto allineamento dei valori puntati.
    ///
    /// `transmute` è **incredibilmente** pericoloso.Esistono molti modi per causare [undefined behavior][ub] con questa funzione.`transmute` dovrebbe essere l'ultima risorsa assoluta.
    ///
    /// L [nomicon](../../nomicon/transmutes.html) dispone di documentazione aggiuntiva.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ci sono alcune cose per le quali `transmute` è davvero utile.
    ///
    /// Trasformare un puntatore in un puntatore a funzione.Questo *non* è portabile su macchine in cui i puntatori a funzione e quelli a dati hanno dimensioni diverse.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Estendere una durata o accorciare una durata invariante.Questo è Rust avanzato, molto pericoloso!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Non disperare: molti usi di `transmute` possono essere raggiunti con altri mezzi.
    /// Di seguito sono elencate le applicazioni comuni di `transmute` che possono essere sostituite con costrutti più sicuri.
    ///
    /// Trasformando bytes(`&[u8]`) grezzo in `u32`, `f64`, ecc .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // usa invece `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // oppure usa `u32::from_le_bytes` o `u32::from_be_bytes` per specificare l'endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Trasformare un puntatore in un `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Usa invece un cast `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Trasformare un `*mut T` in un `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Usa invece un reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Trasformare un `&mut T` in un `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ora, metti insieme `as` e reborrowing, nota che il concatenamento di `as` `as` non è transitivo
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Trasformare un `&str` in un `&[u8]`:
    ///
    /// ```
    /// // questo non è un buon modo per farlo.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Potresti usare `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Oppure, usa semplicemente una stringa di byte, se hai il controllo sulla stringa letterale
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Trasformare un `Vec<&T>` in un `Vec<Option<&T>>`.
    ///
    /// Per trasmutare il tipo interno del contenuto di un contenitore, devi assicurarti di non violare nessuna delle invarianti del contenitore.
    /// Per `Vec`, ciò significa che sia la dimensione *che l'allineamento* dei tipi interni devono corrispondere.
    /// Altri contenitori potrebbero fare affidamento sulla dimensione del tipo, sull'allineamento o persino sull `TypeId`, nel qual caso la trasmutazione non sarebbe affatto possibile senza violare le invarianti del contenitore.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clonare lo vector poiché li riutilizzeremo in seguito
    /// let v_clone = v_orig.clone();
    ///
    /// // Utilizzo di transmute: si basa sul layout dei dati non specificato di `Vec`, che è una cattiva idea e potrebbe causare un comportamento indefinito.
    /////
    /// // Tuttavia, non è una copia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Questo è il modo sicuro e suggerito.
    /// // Tuttavia, copia l'intero vector in un nuovo array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Questo è il modo corretto e non sicuro di "transmuting" e `Vec`, senza fare affidamento sul layout dei dati.
    /// // Invece di chiamare letteralmente `transmute`, eseguiamo un cast del puntatore, ma in termini di conversione del tipo interno originale (`&i32`) nel nuovo (`Option<&i32>`), questo ha tutti gli stessi avvertimenti.
    /////
    /// // Oltre alle informazioni fornite sopra, consultare anche la documentazione di [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aggiorna questo quando vec_into_raw_parts è stabilizzato.
    ///     // Assicurati che lo vector originale non venga lasciato cadere.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementazione di `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ci sono diversi modi per farlo e ci sono più problemi con il seguente modo (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // primo: la trasmutazione non è sicura per i tipi;tutto ciò che controlla è che T e
    ///         // U sono della stessa taglia.
    ///         // Secondo, proprio qui, hai due riferimenti mutabili che puntano alla stessa memoria.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Questo elimina i problemi di sicurezza del tipo;`&mut *` ti darà* solo *un `&mut T` da un `&mut T` o `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tuttavia, hai ancora due riferimenti mutabili che puntano alla stessa memoria.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Questo è il modo in cui lo fa la libreria standard.
    /// // Questo è il metodo migliore, se devi fare qualcosa del genere
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Questo ora ha tre riferimenti mutabili che puntano alla stessa memoria.`slice`, rvalue ret.0 e rvalue ret.1.
    ///         // `slice` non viene mai utilizzato dopo `let ptr = ...`, quindi si può trattarlo come "dead" e quindi si hanno solo due slice mutabili reali.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Anche se questo rende stabile il const intrinseco, abbiamo del codice personalizzato in const fn
    // controlli che ne impediscano l'utilizzo all'interno di `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Restituisce `true` se il tipo effettivo dato come `T` richiede colla a goccia;restituisce `false` se il tipo effettivo fornito per `T` implementa `Copy`.
    ///
    ///
    /// Se il tipo effettivo non richiede colla a goccia né implementa `Copy`, il valore di ritorno di questa funzione non è specificato.
    ///
    /// La versione stabilizzata di questo intrinseco è [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Calcola l'offset da un puntatore.
    ///
    /// Questo è implementato come un elemento intrinseco per evitare la conversione da e verso un numero intero, poiché la conversione eliminerebbe le informazioni di aliasing.
    ///
    /// # Safety
    ///
    /// Sia il puntatore iniziale che quello risultante devono trovarsi nei limiti o un byte oltre la fine di un oggetto allocato.
    /// Se uno dei due puntatori è fuori dai limiti o si verifica un overflow aritmetico, qualsiasi ulteriore utilizzo del valore restituito comporterà un comportamento indefinito.
    ///
    ///
    /// La versione stabilizzata di questo intrinseco è [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Calcola l'offset da un puntatore, potenzialmente a capo.
    ///
    /// Questo è implementato come un elemento intrinseco per evitare la conversione da e verso un numero intero, poiché la conversione inibisce alcune ottimizzazioni.
    ///
    /// # Safety
    ///
    /// A differenza dell'intrinseco `offset`, questo intrinseco non limita il puntatore risultante a puntare o un byte oltre la fine di un oggetto allocato e si avvolge con l'aritmetica del complemento a due.
    /// Il valore risultante non è necessariamente valido per essere utilizzato per accedere effettivamente alla memoria.
    ///
    /// La versione stabilizzata di questo intrinseco è [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Equivalente all'intrinseco `llvm.memcpy.p0i8.0i8.*` appropriato, con una dimensione di `count`*`size_of::<T>()` e un allineamento di
    ///
    /// `min_align_of::<T>()`
    ///
    /// Il parametro volatile è impostato su `true`, quindi non verrà ottimizzato a meno che la dimensione non sia uguale a zero.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente all'intrinseco `llvm.memmove.p0i8.0i8.*` appropriato, con una dimensione di `count* size_of::<T>()` e un allineamento di
    ///
    /// `min_align_of::<T>()`
    ///
    /// Il parametro volatile è impostato su `true`, quindi non verrà ottimizzato a meno che la dimensione non sia uguale a zero.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Equivalente all'intrinseco `llvm.memset.p0i8.*` appropriato, con una dimensione di `count* size_of::<T>()` e un allineamento di `min_align_of::<T>()`.
    ///
    ///
    /// Il parametro volatile è impostato su `true`, quindi non verrà ottimizzato a meno che la dimensione non sia uguale a zero.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Esegue un caricamento volatile dal puntatore `src`.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Esegue una memorizzazione volatile nel puntatore `dst`.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Esegue un carico volatile dal puntatore `src` Il puntatore non deve essere allineato.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Esegue una memorizzazione volatile nel puntatore `dst`.
    /// Il puntatore non deve essere allineato.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Restituisce la radice quadrata di un `f32`
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Restituisce la radice quadrata di un `f64`
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Eleva un `f32` a una potenza intera.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Eleva un `f64` a una potenza intera.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Restituisce il seno di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Restituisce il seno di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Restituisce il coseno di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Restituisce il coseno di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Alza un `f32` a un potere `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Alza un `f64` a un potere `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Restituisce l'esponenziale di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Restituisce l'esponenziale di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Restituisce 2 elevato alla potenza di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Restituisce 2 elevato alla potenza di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Restituisce il logaritmo naturale di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Restituisce il logaritmo naturale di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Restituisce il logaritmo in base 10 di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Restituisce il logaritmo in base 10 di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Restituisce il logaritmo in base 2 di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Restituisce il logaritmo in base 2 di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Restituisce `a * b + c` per i valori `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Restituisce `a * b + c` per i valori `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Restituisce il valore assoluto di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Restituisce il valore assoluto di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Restituisce il minimo di due valori `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Restituisce il minimo di due valori `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Restituisce il massimo di due valori `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Restituisce il massimo di due valori `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Copia il segno da `y` a `x` per i valori `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Copia il segno da `y` a `x` per i valori `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Restituisce il numero intero più grande minore o uguale a `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Restituisce il numero intero più grande minore o uguale a `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Restituisce il numero intero più piccolo maggiore o uguale a `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Restituisce il numero intero più piccolo maggiore o uguale a `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Restituisce la parte intera di un `f32`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Restituisce la parte intera di un `f64`.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Restituisce il numero intero più vicino a un `f32`.
    /// Può sollevare un'eccezione a virgola mobile inesatta se l'argomento non è un numero intero.
    pub fn rintf32(x: f32) -> f32;
    /// Restituisce il numero intero più vicino a un `f64`.
    /// Può sollevare un'eccezione a virgola mobile inesatta se l'argomento non è un numero intero.
    pub fn rintf64(x: f64) -> f64;

    /// Restituisce il numero intero più vicino a un `f32`.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Restituisce il numero intero più vicino a un `f64`.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Restituisce il numero intero più vicino a un `f32`.Arrotonda i casi a metà distanza dallo zero.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Restituisce il numero intero più vicino a un `f64`.Arrotonda i casi a metà distanza dallo zero.
    ///
    /// La versione stabilizzata di questo intrinseco è
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Aggiunta mobile che consente ottimizzazioni basate su regole algebriche.
    /// Può assumere che gli input siano finiti.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Sottrazione flottante che consente ottimizzazioni basate su regole algebriche.
    /// Può assumere che gli input siano finiti.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Moltiplicazione in virgola mobile che consente ottimizzazioni basate su regole algebriche.
    /// Può assumere che gli input siano finiti.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Divisione in virgola mobile che consente ottimizzazioni basate su regole algebriche.
    /// Può assumere che gli input siano finiti.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Resto mobile che consente ottimizzazioni basate su regole algebriche.
    /// Può assumere che gli input siano finiti.
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Converti con fptoui/fptosi di LLVM, che potrebbe restituire undef per valori fuori intervallo
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizzato come [`f32::to_int_unchecked`] e [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Restituisce il numero di bit impostato in un intero di tipo `T`
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `count_ones`.
    /// Per esempio,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Restituisce il numero di bit iniziali non impostati (zeroes) in un intero di tipo `T`.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `leading_zeros`.
    /// Per esempio,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Un `x` con valore `0` restituirà la larghezza di bit di `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Come `ctlz`, ma estremamente pericoloso in quanto restituisce `undef` quando viene fornito un `x` con valore `0`.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Restituisce il numero di bit finali non impostati (zeroes) in un intero di tipo `T`.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `trailing_zeros`.
    /// Per esempio,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Un `x` con valore `0` restituirà la larghezza di bit di `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Come `cttz`, ma estremamente pericoloso in quanto restituisce `undef` quando viene fornito un `x` con valore `0`.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inverte i byte in un intero di tipo `T`.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `swap_bytes`.
    /// Per esempio,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inverte i bit in un intero di tipo `T`.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `reverse_bits`.
    /// Per esempio,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Esegue l'addizione di interi controllati.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `overflowing_add`.
    /// Per esempio,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue la sottrazione di interi controllati
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `overflowing_sub`.
    /// Per esempio,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue la moltiplicazione dei numeri interi verificata
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `overflowing_mul`.
    /// Per esempio,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Esegue una divisione esatta, risultando in un comportamento indefinito in cui `x % y != 0` o `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Esegue una divisione non controllata, risultando in un comportamento indefinito in cui `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// I wrapper sicuri per questo intrinseco sono disponibili sulle primitive intere tramite il metodo `checked_div`.
    /// Per esempio,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Restituisce il resto di una divisione non selezionata, con conseguente comportamento indefinito quando `y == 0` o `x == T::MIN && y == -1`
    ///
    ///
    /// I wrapper sicuri per questo intrinseco sono disponibili sulle primitive intere tramite il metodo `checked_rem`.
    /// Per esempio,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Esegue uno spostamento a sinistra non controllato, con conseguente comportamento indefinito quando `y < 0` o `y >= N`, dove N è la larghezza di T in bit.
    ///
    ///
    /// I wrapper sicuri per questo intrinseco sono disponibili sulle primitive intere tramite il metodo `checked_shl`.
    /// Per esempio,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Esegue uno spostamento a destra non controllato, risultando in un comportamento indefinito quando `y < 0` o `y >= N`, dove N è la larghezza di T in bit.
    ///
    ///
    /// I wrapper sicuri per questo intrinseco sono disponibili sulle primitive intere tramite il metodo `checked_shr`.
    /// Per esempio,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Restituisce il risultato di un'aggiunta non controllata, che determina un comportamento non definito quando `x + y > T::MAX` o `x + y < T::MIN`.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Restituisce il risultato di una sottrazione non controllata, che determina un comportamento non definito quando `x - y > T::MAX` o `x - y < T::MIN`.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Restituisce il risultato di una moltiplicazione non controllata, che determina un comportamento non definito quando `x *y > T::MAX` o `x* y < T::MIN`.
    ///
    ///
    /// Questo intrinseco non ha una controparte stabile.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Esegue la rotazione a sinistra.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `rotate_left`.
    /// Per esempio,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Esegue la rotazione a destra.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `rotate_right`.
    /// Per esempio,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Restituisce (a + b) mod 2 <sup>N</sup>, dove N è la larghezza di T in bit.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `wrapping_add`.
    /// Per esempio,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Restituisce (a, b) mod 2 <sup>N</sup>, dove N è la larghezza di T in bit.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `wrapping_sub`.
    /// Per esempio,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Restituisce (a * b) mod 2 <sup>N</sup>, dove N è la larghezza di T in bit.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `wrapping_mul`.
    /// Per esempio,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Calcola `a + b`, saturando i limiti numerici.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `saturating_add`.
    /// Per esempio,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Calcola `a - b`, saturando i limiti numerici.
    ///
    /// Le versioni stabilizzate di questo intrinseco sono disponibili sulle primitive intere tramite il metodo `saturating_sub`.
    /// Per esempio,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Restituisce il valore del discriminante per la variante in 'v';
    /// se `T` non ha discriminanti, restituisce `0`.
    ///
    /// La versione stabilizzata di questo intrinseco è [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Restituisce il numero di varianti del tipo `T` cast a un `usize`;
    /// se `T` non ha varianti, restituisce `0`.Verranno conteggiate le varianti disabitate.
    ///
    /// La versione da stabilizzare di questo intrinseco è [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Il costrutto "try catch" di Rust che richiama il puntatore alla funzione `try_fn` con il puntatore ai dati `data`.
    ///
    /// Il terzo argomento è una funzione chiamata se si verifica un panic.
    /// Questa funzione accetta il puntatore ai dati e un puntatore all'oggetto eccezione specifico della destinazione che è stato catturato.
    ///
    /// Per ulteriori informazioni, vedere il codice sorgente del compilatore e l'implementazione catch di std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Emette un archivio `!nontemporal` secondo LLVM (vedi i loro documenti).
    /// Probabilmente non diventerà mai stabile.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Vedere la documentazione di `<*const T>::offset_from` per i dettagli.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Vedere la documentazione di `<*const T>::guaranteed_eq` per i dettagli.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Vedere la documentazione di `<*const T>::guaranteed_ne` per i dettagli.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Assegna in fase di compilazione.Non dovrebbe essere chiamato in fase di esecuzione.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Alcune funzioni sono definite qui perché sono state accidentalmente rese disponibili in questo modulo su stable.
// Vedi <https://github.com/rust-lang/rust/issues/15702>.
// (Anche `transmute` rientra in questa categoria, ma non può essere avvolto a causa del controllo che `T` e `U` abbiano le stesse dimensioni.)
//

/// Controlla se `ptr` è allineato correttamente rispetto a `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Copia i byte `count *size_of::<T>()` da `src` a `dst`.L'origine e la destinazione* non * devono sovrapporsi.
///
/// Per le regioni di memoria che potrebbero sovrapporsi, utilizzare invece [`copy`].
///
/// `copy_nonoverlapping` è semanticamente equivalente a [`memcpy`] di C, ma con l'ordine degli argomenti scambiato.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `src` deve essere [valid] per letture di byte `count * size_of::<T>()`.
///
/// * `dst` deve essere [valid] per le scritture di byte `count * size_of::<T>()`.
///
/// * Sia `src` che `dst` devono essere allineati correttamente.
///
/// * La regione di memoria che inizia da `src` con una dimensione di `count *
///   taglia di: :<T>() `byte non devono *non* sovrapporsi alla regione di memoria che inizia a `dst` con la stessa dimensione.
///
/// Come [`read`], `copy_nonoverlapping` crea una copia bit per bit di `T`, indipendentemente dal fatto che `T` sia [`Copy`].
/// Se `T` non è [`Copy`], utilizzando *entrambi* i valori nella regione che inizia in `*src` e nella regione che inizia in `* dst` può [violate memory safety][read-ownership].
///
///
/// Nota che anche se la dimensione effettivamente copiata (`count * size_of: :<T>()`) è `0`, i puntatori devono essere non NULL e correttamente allineati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implementa manualmente [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Sposta tutti gli elementi di `src` in `dst`, lasciando `src` vuoto.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Assicurati che `dst` abbia una capacità sufficiente per contenere tutto `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // La chiamata all'offset è sempre sicura perché `Vec` non allocherà mai più di `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Tronca `src` senza far cadere il suo contenuto.
///         // Lo facciamo prima, per evitare problemi nel caso qualcosa più in basso panics.
///         src.set_len(0);
///
///         // Le due regioni non possono sovrapporsi perché i riferimenti modificabili non sono alias e due vectors differenti non possono possedere la stessa memoria.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Notifica a `dst` che ora contiene il contenuto di `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Eseguire questi controlli solo in fase di esecuzione
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Non farti prendere dal panico per mantenere più piccolo l'impatto del codegen.
        abort();
    }*/

    // SICUREZZA: il contratto di sicurezza per `copy_nonoverlapping` deve essere
    // confermato dal chiamante.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Copia i byte `count * size_of::<T>()` da `src` a `dst`.L'origine e la destinazione potrebbero sovrapporsi.
///
/// Se l'origine e la destinazione *non* si sovrappongono, è possibile utilizzare [`copy_nonoverlapping`].
///
/// `copy` è semanticamente equivalente a [`memmove`] di C, ma con l'ordine degli argomenti scambiato.
/// La copia avviene come se i byte fossero copiati da `src` a un array temporaneo e quindi copiati dall'array a `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `src` deve essere [valid] per letture di byte `count * size_of::<T>()`.
///
/// * `dst` deve essere [valid] per le scritture di byte `count * size_of::<T>()`.
///
/// * Sia `src` che `dst` devono essere allineati correttamente.
///
/// Come [`read`], `copy` crea una copia bit per bit di `T`, indipendentemente dal fatto che `T` sia [`Copy`].
/// Se `T` non è [`Copy`], utilizzando entrambi i valori nella regione che inizia in `*src` e la regione che inizia in `* dst` può [violate memory safety][read-ownership].
///
///
/// Nota che anche se la dimensione effettivamente copiata (`count * size_of: :<T>()`) è `0`, i puntatori devono essere non NULL e correttamente allineati.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Crea in modo efficiente un Rust vector da un buffer non sicuro:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` deve essere allineato correttamente per il suo tipo e diverso da zero.
/// /// * `ptr` deve essere valido per le letture di elementi contigui `elts` di tipo `T`.
/// /// * Questi elementi non devono essere utilizzati dopo aver chiamato questa funzione a meno che `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SICUREZZA: la nostra precondizione garantisce che la fonte sia allineata e valida,
///     // e `Vec::with_capacity` assicura che abbiamo spazio utilizzabile per scriverli.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SICUREZZA: l'abbiamo creata con questa capacità in precedenza,
///     // e il precedente `copy` ha inizializzato questi elementi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Eseguire questi controlli solo in fase di esecuzione
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Non farti prendere dal panico per mantenere più piccolo l'impatto del codegen.
        abort();
    }*/

    // SICUREZZA: il contratto di sicurezza per `copy` deve essere mantenuto dal chiamante.
    unsafe { copy(src, dst, count) }
}

/// Imposta i byte di memoria da `count * size_of::<T>()` a partire da `dst` su `val`.
///
/// `write_bytes` è simile a [`memset`] di C, ma imposta i byte `count * size_of::<T>()` su `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Il comportamento non è definito se viene violata una delle seguenti condizioni:
///
/// * `dst` deve essere [valid] per le scritture di byte `count * size_of::<T>()`.
///
/// * `dst` deve essere correttamente allineato.
///
/// Inoltre, il chiamante deve assicurarsi che la scrittura di byte `count * size_of::<T>()` nella regione di memoria specificata restituisca un valore valido di `T`.
/// L'utilizzo di una regione di memoria digitata come `T` che contiene un valore non valido di `T` è un comportamento indefinito.
///
/// Nota che anche se la dimensione effettivamente copiata (`count * size_of: :<T>()`) è `0`, il puntatore deve essere diverso da NULL e correttamente allineato.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Creazione di un valore non valido:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Perde il valore precedentemente mantenuto sovrascrivendo l `Box<T>` con un puntatore nullo.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // A questo punto, l'utilizzo o l'eliminazione di `v` produce un comportamento indefinito.
/// // drop(v); // ERROR
///
/// // Anche la perdita di `v` "uses", e quindi è un comportamento indefinito.
/// // mem::forget(v); // ERROR
///
/// // Infatti, `v` non è valido in base alle invarianti del layout del tipo di base, quindi *qualsiasi* operazione che lo tocchi è un comportamento indefinito.
/////
/// // lascia v2 =v;//ERRORE
///
/// unsafe {
///     // Mettiamo invece un valore valido
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ora la scatola va bene
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SICUREZZA: il contratto di sicurezza per `write_bytes` deve essere mantenuto dal chiamante.
    unsafe { write_bytes(dst, val, count) }
}