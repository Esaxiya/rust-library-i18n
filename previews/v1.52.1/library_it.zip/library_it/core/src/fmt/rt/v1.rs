//! Questo è un modulo interno utilizzato da ifmt!runtime.Queste strutture vengono emesse in array statici per precompilare le stringhe di formato in anticipo.
//!
//! Queste definizioni sono simili ai loro equivalenti `ct`, ma differiscono in quanto possono essere allocate staticamente e sono leggermente ottimizzate per il runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Possibili allineamenti che possono essere richiesti come parte di una direttiva di formattazione.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indica che i contenuti devono essere allineati a sinistra.
    Left,
    /// Indicazione che i contenuti dovrebbero essere allineati a destra.
    Right,
    /// Indica che i contenuti devono essere allineati al centro.
    Center,
    /// Non è stato richiesto alcun allineamento.
    Unknown,
}

/// Utilizzato dagli specificatori [width](https://doc.rust-lang.org/std/fmt/#width) e [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Specificato con un numero letterale, memorizza il valore
    Is(usize),
    /// Specificato utilizzando le sintassi `$` e `*`, memorizza l'indice in `args`
    Param(usize),
    /// Non specificato
    Implied,
}