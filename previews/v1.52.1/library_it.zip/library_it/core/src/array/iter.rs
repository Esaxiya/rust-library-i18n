//! Definisce l'iteratore di proprietà `IntoIter` per gli array.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Un iteratore [array] per valore.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Questo è l'array su cui stiamo iterando.
    ///
    /// Elementi con indice `i` dove `alive.start <= i < alive.end` non sono ancora stati restituiti e sono voci di array valide.
    /// Gli elementi con indici `i < alive.start` o `i >= alive.end` sono già stati forniti e non devono più essere consultati!Quegli elementi morti potrebbero anche essere in uno stato completamente non inizializzato!
    ///
    ///
    /// Quindi gli invarianti sono:
    /// - `data[alive]` è vivo (cioè contiene elementi validi)
    /// - `data[..alive.start]` e `data[alive.end..]` sono morti (ovvero gli elementi erano già stati letti e non devono più essere toccati!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Gli elementi in `data` che non sono stati ancora ceduti.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Crea un nuovo iteratore sul dato `array`.
    ///
    /// *Nota*: questo metodo potrebbe essere deprecato in future, dopo [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Il tipo di `value` è un `i32` qui, invece di `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SICUREZZA: la trasmutazione qui è effettivamente sicura.I documenti di `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` è garantito che abbia le stesse dimensioni e allineamento
        // > come `T`.
        //
        // I documenti mostrano anche una trasmutazione da un array di `MaybeUninit<T>` a un array di `T`.
        //
        //
        // Con ciò, questa inizializzazione soddisfa gli invarianti.

        // FIXME(LukasKalbertodt): effettivamente usa `mem::transmute` qui, una volta che funziona con const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Fino ad allora, possiamo usare `mem::transmute_copy` per creare una copia bit per bit come un tipo diverso, quindi dimenticare `array` in modo che non venga eliminato.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Restituisce una porzione immutabile di tutti gli elementi che non sono stati ancora ceduti.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SICUREZZA: sappiamo che tutti gli elementi all'interno di `alive` sono inizializzati correttamente.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Restituisce una porzione modificabile di tutti gli elementi che non sono stati ancora ceduti.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SICUREZZA: sappiamo che tutti gli elementi all'interno di `alive` sono inizializzati correttamente.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Prendi il prossimo indice dalla parte anteriore.
        //
        // L'aumento di `alive.start` di 1 mantiene l'invariante rispetto a `alive`.
        // Tuttavia, a causa di questo cambiamento, per un breve periodo, la zona attiva non è più `data[alive]`, ma `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Leggi l'elemento dall'array.
            // SICUREZZA: `idx` è un indice nella precedente regione "alive" di
            // Vettore.Leggere questo elemento significa che `data[idx]` è considerato morto ora (cioè non toccare).
            // Poiché `idx` era l'inizio della zona viva, la zona viva è ora di nuovo `data[alive]`, ripristinando tutte le invarianti.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Prendi il prossimo indice dal retro.
        //
        // Diminuendo `alive.end` di 1 si mantiene l'invariante rispetto a `alive`.
        // Tuttavia, a causa di questo cambiamento, per un breve periodo, la zona attiva non è più `data[alive]`, ma `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Leggi l'elemento dall'array.
            // SICUREZZA: `idx` è un indice nella precedente regione "alive" di
            // Vettore.Leggere questo elemento significa che `data[idx]` è considerato morto ora (cioè non toccare).
            // Poiché `idx` era la fine della zona viva, la zona viva è ora di nuovo `data[alive]`, ripristinando tutte le invarianti.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SICUREZZA: Questo è sicuro: `as_mut_slice` restituisce esattamente la sottosezione
        // di elementi che non sono stati ancora spostati e che devono ancora essere abbandonati.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Non sarà mai underflow a causa dell'invariante `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// L'iteratore infatti riporta la lunghezza corretta.
// Il numero di elementi "alive" (che verranno comunque restituiti) è la lunghezza dell'intervallo `alive`.
// Questa gamma viene ridotta in lunghezza in `next` o `next_back`.
// Viene sempre decrementato di 1 in questi metodi, ma solo se viene restituito `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Nota, non abbiamo davvero bisogno di abbinare esattamente lo stesso intervallo vivo, quindi possiamo semplicemente clonare in offset 0 indipendentemente da dove si trova `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Clona tutti gli elementi vivi.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Scrivi un clone nel nuovo array, quindi aggiorna il suo range attivo.
            // Se si clona panics, elimineremo correttamente gli elementi precedenti.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Stampa solo gli elementi che non sono stati ancora ceduti: non possiamo più accedere agli elementi resi.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}