use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Un allocatore di memoria che può essere registrato come predefinito della libreria standard tramite l'attributo `#[global_allocator]`.
///
/// Alcuni metodi richiedono che un blocco di memoria sia *attualmente allocato* tramite un allocatore.Ciò significa che:
///
/// * l'indirizzo iniziale per quel blocco di memoria era stato precedentemente restituito da una precedente chiamata a un metodo di allocazione come `alloc` e
///
/// * il blocco di memoria non è stato successivamente deallocato, dove i blocchi vengono deallocati passando a un metodo di deallocazione come `dealloc` o passando a un metodo di riallocazione che restituisce un puntatore non nullo.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// L `GlobalAlloc` trait è un `unsafe` trait per una serie di motivi e gli implementatori devono assicurarsi di aderire a questi contratti:
///
/// * È un comportamento indefinito se gli allocatori globali si rilassano.Questa restrizione può essere rimossa in future, ma attualmente un panic da una qualsiasi di queste funzioni può portare alla sicurezza della memoria.
///
/// * `Layout` query e calcoli in generale devono essere corretti.I chiamanti di questo trait possono fare affidamento sui contratti definiti su ciascun metodo e gli implementatori devono garantire che tali contratti rimangano veri.
///
/// * Non puoi fare affidamento sulle allocazioni che avvengono effettivamente, anche se sono presenti allocazioni di heap esplicite nell'origine.
/// L'ottimizzatore può rilevare le allocazioni inutilizzate che può eliminare completamente o spostarsi nello stack e quindi non richiamare mai l'allocatore.
/// L'ottimizzatore può inoltre presumere che l'allocazione sia infallibile, quindi il codice che non funzionava a causa di errori dell'allocatore ora può funzionare improvvisamente perché l'ottimizzatore ha risolto la necessità di un'allocazione.
/// Più concretamente, il seguente esempio di codice non è valido, indipendentemente dal fatto che l'allocatore personalizzato consenta di contare quante allocazioni sono state eseguite.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Tieni presente che le ottimizzazioni sopra menzionate non sono le uniche che possono essere applicate.In genere non si può fare affidamento sulle allocazioni degli heap se possono essere rimosse senza modificare il comportamento del programma.
///   Se le allocazioni avvengono o meno non fa parte del comportamento del programma, anche se potrebbe essere rilevato tramite un allocatore che tiene traccia delle allocazioni stampando o con effetti collaterali.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Allocare la memoria come descritto dal dato `layout`.
    ///
    /// Restituisce un puntatore alla memoria appena allocata o null per indicare un errore di allocazione.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura perché può verificarsi un comportamento indefinito se il chiamante non si assicura che `layout` abbia una dimensione diversa da zero.
    ///
    /// (I sottotitoli di estensione potrebbero fornire limiti più specifici sul comportamento, ad esempio, garantire un indirizzo sentinella o un puntatore nullo in risposta a una richiesta di allocazione di dimensione zero.)
    ///
    /// Il blocco di memoria allocato può o non può essere inizializzato.
    ///
    /// # Errors
    ///
    /// La restituzione di un puntatore nullo indica che la memoria è esaurita o che `layout` non soddisfa le dimensioni o i vincoli di allineamento di questo allocatore.
    ///
    /// Le implementazioni sono incoraggiate a restituire null in caso di esaurimento della memoria piuttosto che interrompersi, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Distribuire il blocco di memoria al puntatore `ptr` specificato con `layout` specificato.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura perché può verificarsi un comportamento indefinito se il chiamante non garantisce tutto quanto segue:
    ///
    ///
    /// * `ptr` deve indicare un blocco di memoria attualmente allocato tramite questo allocatore,
    ///
    /// * `layout` deve essere lo stesso layout utilizzato per allocare quel blocco di memoria.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Si comporta come `alloc`, ma garantisce anche che i contenuti siano impostati su zero prima di essere restituiti.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura per gli stessi motivi per cui lo è `alloc`.
    /// Tuttavia, è garantito che il blocco di memoria allocato venga inizializzato.
    ///
    /// # Errors
    ///
    /// La restituzione di un puntatore nullo indica che la memoria è esaurita o che `layout` non soddisfa i vincoli di dimensione o allineamento dell'allocatore, proprio come in `alloc`.
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SICUREZZA: il contratto di sicurezza per `alloc` deve essere mantenuto dal chiamante.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SICUREZZA: poiché l'allocazione è riuscita, la regione da `ptr`
            // di dimensione `size` è garantito per essere valido per le scritture.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Riduci o espandi un blocco di memoria al dato `new_size`.
    /// Il blocco è descritto dal puntatore `ptr` fornito e da `layout`.
    ///
    /// Se questo restituisce un puntatore non nullo, la proprietà del blocco di memoria a cui fa riferimento `ptr` è stata trasferita a questo allocatore.
    /// La memoria può essere stata deallocata o meno e dovrebbe essere considerata inutilizzabile (a meno che, naturalmente, non sia stata ritrasferita al chiamante tramite il valore di ritorno di questo metodo).
    /// Il nuovo blocco di memoria viene allocato con `layout`, ma con `size` aggiornato a `new_size`.
    /// Questo nuovo layout dovrebbe essere utilizzato durante la deallocazione del nuovo blocco di memoria con `dealloc`.
    /// La gamma `0..min(layout.size(), new_size) `del nuovo blocco di memoria è garantita per avere gli stessi valori del blocco originale.
    ///
    /// Se questo metodo restituisce null, la proprietà del blocco di memoria non è stata trasferita a questo allocatore e il contenuto del blocco di memoria rimane inalterato.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura perché può verificarsi un comportamento indefinito se il chiamante non garantisce tutto quanto segue:
    ///
    /// * `ptr` deve essere attualmente assegnato tramite questo allocatore,
    ///
    /// * `layout` deve essere lo stesso layout utilizzato per allocare quel blocco di memoria,
    ///
    /// * `new_size` deve essere maggiore di zero.
    ///
    /// * `new_size`, quando viene arrotondato per eccesso al multiplo più vicino di `layout.align()`, non deve eccedere (ovvero, il valore arrotondato deve essere inferiore a `usize::MAX`).
    ///
    /// (I sottotitoli di estensione potrebbero fornire limiti più specifici sul comportamento, ad esempio, garantire un indirizzo sentinella o un puntatore nullo in risposta a una richiesta di allocazione di dimensione zero.)
    ///
    /// # Errors
    ///
    /// Restituisce null se il nuovo layout non soddisfa i vincoli di dimensione e allineamento dell'allocatore o se la riallocazione fallisce altrimenti.
    ///
    /// Le implementazioni sono incoraggiate a restituire null sull'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di riallocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SICUREZZA: il chiamante deve assicurarsi che l `new_size` non trabocchi.
        // `layout.align()` proviene da un `Layout` ed è quindi garantito per essere valido.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SICUREZZA: il chiamante deve assicurarsi che `new_layout` sia maggiore di zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SICUREZZA: il blocco precedentemente allocato non può sovrapporsi al blocco appena allocato.
            // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}