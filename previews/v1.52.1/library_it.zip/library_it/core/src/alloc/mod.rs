//! API di allocazione della memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// L'errore `AllocError` indica un errore di allocazione che potrebbe essere dovuto all'esaurimento delle risorse o a qualcosa di sbagliato quando si combinano gli argomenti di input forniti con questo allocatore.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ne abbiamo bisogno per l'impl a valle di trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Un'implementazione di `Allocator` può allocare, aumentare, ridurre e deallocare blocchi arbitrari di dati descritti tramite [`Layout`][].
///
/// `Allocator` è progettato per essere implementato su ZST, riferimenti o puntatori intelligenti perché avere un allocatore come `MyAlloc([u8; N])` non può essere spostato, senza aggiornare i puntatori alla memoria allocata.
///
/// A differenza di [`GlobalAlloc`][], le allocazioni di dimensioni zero sono consentite in `Allocator`.
/// Se un allocatore sottostante non lo supporta (come jemalloc) o restituisce un puntatore nullo (come `libc::malloc`), questo deve essere rilevato dall'implementazione.
///
/// ### Memoria attualmente allocata
///
/// Alcuni metodi richiedono che un blocco di memoria sia *attualmente allocato* tramite un allocatore.Ciò significa che:
///
/// * l'indirizzo iniziale per quel blocco di memoria era stato precedentemente restituito da [`allocate`], [`grow`] o [`shrink`] e
///
/// * il blocco di memoria non è stato successivamente deallocato, dove i blocchi vengono deallocati direttamente passando a [`deallocate`] o sono stati modificati passando a [`grow`] o [`shrink`] che restituisce `Ok`.
///
/// Se `grow` o `shrink` hanno restituito `Err`, il puntatore passato rimane valido.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Adattamento della memoria
///
/// Alcuni metodi richiedono che un layout *si adatti* a un blocco di memoria.
/// Ciò che significa per un layout su "fit" un blocco di memoria (o, in modo equivalente, per un blocco di memoria su "fit" un layout) è che devono essere soddisfatte le seguenti condizioni:
///
/// * Il blocco deve essere allocato con lo stesso allineamento di [`layout.align()`] e
///
/// * L [`layout.size()`] fornito deve rientrare nell'intervallo `min ..= max`, dove:
///   - `min` è la dimensione del layout utilizzato più di recente per allocare il blocco e
///   - `max` è l'ultima dimensione effettiva restituita da [`allocate`], [`grow`] o [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * I blocchi di memoria restituiti da un allocatore devono puntare a una memoria valida e mantenere la loro validità fino a quando l'istanza e tutti i suoi cloni non vengono eliminati,
///
/// * la clonazione o lo spostamento dell'allocatore non deve invalidare i blocchi di memoria restituiti da questo allocatore.Un allocatore clonato deve comportarsi come lo stesso allocatore e
///
/// * qualsiasi puntatore a un blocco di memoria che è [*currently allocated*] può essere passato a qualsiasi altro metodo dell'allocatore.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tenta di allocare un blocco di memoria.
    ///
    /// In caso di successo, restituisce un [`NonNull<[u8]>`][NonNull] che soddisfa le dimensioni e le garanzie di allineamento di `layout`.
    ///
    /// Il blocco restituito può avere una dimensione maggiore di quella specificata da `layout.size()` e può o non può avere il suo contenuto inizializzato.
    ///
    /// # Errors
    ///
    /// La restituzione di `Err` indica che la memoria è esaurita o che `layout` non soddisfa le dimensioni dell'allocatore o i vincoli di allineamento.
    ///
    /// Le implementazioni sono incoraggiate a restituire `Err` all'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Si comporta come `allocate`, ma garantisce anche che la memoria restituita sia inizializzata a zero.
    ///
    /// # Errors
    ///
    /// La restituzione di `Err` indica che la memoria è esaurita o che `layout` non soddisfa le dimensioni dell'allocatore o i vincoli di allineamento.
    ///
    /// Le implementazioni sono incoraggiate a restituire `Err` all'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SICUREZZA: `alloc` restituisce un blocco di memoria valido
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Dealloca la memoria a cui fa riferimento `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve indicare un blocco di memoria [*currently allocated*] tramite questo allocatore e
    /// * `layout` deve [*fit*] quel blocco di memoria.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tenta di estendere il blocco di memoria.
    ///
    /// Restituisce un nuovo [`NonNull<[u8]>`][NonNull] contenente un puntatore e la dimensione effettiva della memoria allocata.Il puntatore è adatto per contenere i dati descritti da `new_layout`.
    /// A tale scopo, l'allocatore può estendere l'allocazione a cui fa riferimento `ptr` per adattarla al nuovo layout.
    ///
    /// Se questo restituisce `Ok`, la proprietà del blocco di memoria a cui fa riferimento `ptr` è stata trasferita a questo allocatore.
    /// La memoria può essere stata liberata o meno e deve essere considerata inutilizzabile a meno che non sia stata ritrasferita al chiamante tramite il valore di ritorno di questo metodo.
    ///
    /// Se questo metodo restituisce `Err`, la proprietà del blocco di memoria non è stata trasferita a questo allocatore e il contenuto del blocco di memoria rimane inalterato.
    ///
    /// # Safety
    ///
    /// * `ptr` deve indicare un blocco di memoria [*currently allocated*] tramite questo allocatore.
    /// * `old_layout` deve [*fit*] quel blocco di memoria (l'argomento `new_layout` non deve necessariamente adattarlo.).
    /// * `new_layout.size()` deve essere maggiore o uguale a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Restituisce `Err` se il nuovo layout non soddisfa le dimensioni dell'allocatore e i vincoli di allineamento dell'allocatore o se la crescita non riesce altrimenti.
    ///
    /// Le implementazioni sono incoraggiate a restituire `Err` all'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICUREZZA: perché `new_layout.size()` deve essere maggiore o uguale a
        // `old_layout.size()`, sia la vecchia che la nuova allocazione di memoria sono valide per le letture e le scritture per i byte `old_layout.size()`.
        // Inoltre, poiché la vecchia allocazione non è stata ancora deallocata, non può sovrapporsi a `new_ptr`.
        // Pertanto, la chiamata a `copy_nonoverlapping` è sicura.
        // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Si comporta come `grow`, ma garantisce anche che i nuovi contenuti siano impostati su zero prima di essere restituiti.
    ///
    /// Il blocco di memoria conterrà i seguenti contenuti dopo una chiamata riuscita a
    /// `grow_zeroed`:
    ///   * I byte `0..old_layout.size()` vengono preservati dall'allocazione originale.
    ///   * I byte `old_layout.size()..old_size` verranno conservati o azzerati, a seconda dell'implementazione dell'allocatore.
    ///   `old_size` si riferisce alla dimensione del blocco di memoria prima della chiamata `grow_zeroed`, che può essere maggiore della dimensione originariamente richiesta al momento dell'allocazione.
    ///   * I byte `old_size..new_size` vengono azzerati.`new_size` si riferisce alla dimensione del blocco di memoria restituito dalla chiamata `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` deve indicare un blocco di memoria [*currently allocated*] tramite questo allocatore.
    /// * `old_layout` deve [*fit*] quel blocco di memoria (l'argomento `new_layout` non deve necessariamente adattarlo.).
    /// * `new_layout.size()` deve essere maggiore o uguale a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Restituisce `Err` se il nuovo layout non soddisfa le dimensioni dell'allocatore e i vincoli di allineamento dell'allocatore o se la crescita non riesce altrimenti.
    ///
    /// Le implementazioni sono incoraggiate a restituire `Err` all'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SICUREZZA: perché `new_layout.size()` deve essere maggiore o uguale a
        // `old_layout.size()`, sia la vecchia che la nuova allocazione di memoria sono valide per le letture e le scritture per i byte `old_layout.size()`.
        // Inoltre, poiché la vecchia allocazione non è stata ancora deallocata, non può sovrapporsi a `new_ptr`.
        // Pertanto, la chiamata a `copy_nonoverlapping` è sicura.
        // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tenta di ridurre il blocco di memoria.
    ///
    /// Restituisce un nuovo [`NonNull<[u8]>`][NonNull] contenente un puntatore e la dimensione effettiva della memoria allocata.Il puntatore è adatto per contenere i dati descritti da `new_layout`.
    /// A tale scopo, l'allocatore può ridurre l'allocazione a cui fa riferimento `ptr` per adattarla al nuovo layout.
    ///
    /// Se questo restituisce `Ok`, la proprietà del blocco di memoria a cui fa riferimento `ptr` è stata trasferita a questo allocatore.
    /// La memoria può essere stata liberata o meno e deve essere considerata inutilizzabile a meno che non sia stata ritrasferita al chiamante tramite il valore di ritorno di questo metodo.
    ///
    /// Se questo metodo restituisce `Err`, la proprietà del blocco di memoria non è stata trasferita a questo allocatore e il contenuto del blocco di memoria rimane inalterato.
    ///
    /// # Safety
    ///
    /// * `ptr` deve indicare un blocco di memoria [*currently allocated*] tramite questo allocatore.
    /// * `old_layout` deve [*fit*] quel blocco di memoria (l'argomento `new_layout` non deve necessariamente adattarlo.).
    /// * `new_layout.size()` deve essere minore o uguale a `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Restituisce `Err` se il nuovo layout non soddisfa le dimensioni dell'allocatore e i vincoli di allineamento dell'allocatore o se la riduzione non riesce altrimenti.
    ///
    /// Le implementazioni sono incoraggiate a restituire `Err` all'esaurimento della memoria piuttosto che andare nel panico o interrompere, ma questo non è un requisito rigoroso.
    /// (In particolare: è *legale* implementare questo trait sopra una libreria di allocazione nativa sottostante che si interrompe per esaurimento della memoria.)
    ///
    /// I clienti che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare la funzione [`handle_alloc_error`], piuttosto che invocare direttamente `panic!` o simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SICUREZZA: perché `new_layout.size()` deve essere inferiore o uguale a
        // `old_layout.size()`, sia la vecchia che la nuova allocazione di memoria sono valide per le letture e le scritture per i byte `new_layout.size()`.
        // Inoltre, poiché la vecchia allocazione non è stata ancora deallocata, non può sovrapporsi a `new_ptr`.
        // Pertanto, la chiamata a `copy_nonoverlapping` è sicura.
        // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Crea un adattatore "by reference" per questa istanza di `Allocator`.
    ///
    /// L'adattatore restituito implementa anche `Allocator` e lo prenderà semplicemente in prestito.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SICUREZZA: il contratto di sicurezza deve essere mantenuto dal chiamante
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: il contratto di sicurezza deve essere mantenuto dal chiamante
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: il contratto di sicurezza deve essere mantenuto dal chiamante
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: il contratto di sicurezza deve essere mantenuto dal chiamante
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}