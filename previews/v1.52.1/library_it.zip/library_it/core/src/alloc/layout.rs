use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Sebbene questa funzione sia utilizzata in un unico posto e la sua implementazione potrebbe essere inline, i precedenti tentativi in tal senso hanno reso rustc più lento:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout di un blocco di memoria.
///
/// Un'istanza di `Layout` descrive un particolare layout di memoria.
/// Costruisci un `Layout` come input da dare a un allocatore.
///
/// Tutti i layout hanno una dimensione associata e un allineamento a due.
///
/// (Si noti che i layout *non* devono avere dimensioni diverse da zero, anche se `GlobalAlloc` richiede che tutte le richieste di memoria siano di dimensioni diverse da zero.
/// Un chiamante deve assicurarsi che condizioni come questa siano soddisfatte, utilizzare allocatori specifici con requisiti più flessibili o utilizzare l'interfaccia `Allocator` più indulgente.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // dimensione del blocco di memoria richiesto, misurata in byte.
    size_: usize,

    // allineamento del blocco di memoria richiesto, misurato in byte.
    // ci assicuriamo che questo sia sempre un potere di due, perché API come `posix_memalign` lo richiedono ed è un vincolo ragionevole da imporre ai costruttori di layout.
    //
    //
    // (Tuttavia, non richiediamo analogamente `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Costruisce un `Layout` da un determinato `size` e `align` o restituisce `LayoutError` se una delle seguenti condizioni non è soddisfatta:
    ///
    /// * `align` non deve essere zero,
    ///
    /// * `align` deve essere una potenza di due,
    ///
    /// * `size`, quando viene arrotondato per eccesso al multiplo più vicino di `align`, non deve superare (ovvero, il valore arrotondato deve essere minore o uguale a `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (la potenza di due implica allineare!=0.)

        // La dimensione arrotondata è:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Sappiamo dall'alto che allineare!=0.
        // Se l'aggiunta di (allinea, 1) non trabocca, l'arrotondamento per eccesso andrà bene.
        //
        // Al contrario,&-masking con! (Align, 1) sottrarrà solo bit di ordine inferiore.
        // Pertanto, se si verifica un overflow con la somma, la maschera&non può sottrarre abbastanza da annullare tale overflow.
        //
        //
        // Quanto sopra implica che il controllo dell'overflow della somma è sia necessario che sufficiente.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SICUREZZA: le condizioni per `from_size_align_unchecked` sono state
        // controllato sopra.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Crea un layout, ignorando tutti i controlli.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura in quanto non verifica le precondizioni da [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SICUREZZA: il chiamante deve assicurarsi che `align` sia maggiore di zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// La dimensione minima in byte per un blocco di memoria di questo layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// L'allineamento di byte minimo per un blocco di memoria di questo layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Costruisce un `Layout` adatto a contenere un valore di tipo `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SICUREZZA: l'allineamento è garantito da Rust come una potenza di due e
        // la combinazione size + align è garantita per adattarsi al nostro spazio degli indirizzi.
        // Di conseguenza, usa il costruttore non selezionato qui per evitare di inserire codice che panics non è ottimizzato abbastanza bene.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un layout che descrive un record che potrebbe essere utilizzato per allocare la struttura di supporto per `T` (che potrebbe essere un trait o un altro tipo non dimensionato come uno slice).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICUREZZA: vedere la motivazione in `new` per il motivo per cui viene utilizzata la variante non sicura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produce un layout che descrive un record che potrebbe essere utilizzato per allocare la struttura di supporto per `T` (che potrebbe essere un trait o un altro tipo non dimensionato come uno slice).
    ///
    /// # Safety
    ///
    /// Questa funzione può essere chiamata in sicurezza solo se sussistono le seguenti condizioni:
    ///
    /// - Se `T` è `Sized`, questa funzione è sempre sicura da chiamare.
    /// - Se la coda non dimensionata di `T` è:
    ///     - a [slice], la lunghezza della coda della sezione deve essere un numero intero inizializzato e la dimensione del *valore intero*(lunghezza della coda dinamica + prefisso di dimensioni statiche) deve essere contenuta in `isize`.
    ///     - a [trait object], la parte vtable del puntatore deve puntare a una vtable valida per il tipo `T` acquisita da una coersione senza dimensionamento, e la dimensione del *valore intero*(lunghezza della coda dinamica + prefisso dimensionato staticamente) deve rientrare in `isize`.
    ///
    ///     - un (unstable) [extern type], allora questa funzione è sempre sicura da chiamare, ma può panic o altrimenti restituire il valore sbagliato, poiché il layout del tipo esterno non è noto.
    ///     Questo è lo stesso comportamento di [`Layout::for_value`] su un riferimento a una coda di tipo esterno.
    ///     - in caso contrario, non è prudentemente consentito chiamare questa funzione.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SICUREZZA: trasmettiamo al chiamante i prerequisiti di queste funzioni
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SICUREZZA: vedere la motivazione in `new` per il motivo per cui viene utilizzata la variante non sicura
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Crea un `NonNull` che penzola, ma ben allineato per questo layout.
    ///
    /// Notare che il valore del puntatore può potenzialmente rappresentare un puntatore valido, il che significa che questo non deve essere utilizzato come valore sentinella "not yet initialized".
    /// I tipi che allocano pigramente devono tenere traccia dell'inizializzazione con altri mezzi.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SICUREZZA: align è garantito essere diverso da zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Crea un layout che descrive il record che può contenere un valore dello stesso layout di `self`, ma che è anche allineato all'allineamento `align` (misurato in byte).
    ///
    ///
    /// Se `self` soddisfa già l'allineamento prescritto, restituisce `self`.
    ///
    /// Si noti che questo metodo non aggiunge alcun riempimento alla dimensione complessiva, indipendentemente dal fatto che il layout restituito abbia un allineamento diverso.
    /// In altre parole, se `K` ha la dimensione 16, `K.align_to(32)` avrà *ancora* la dimensione 16.
    ///
    /// Restituisce un errore se la combinazione di `self.size()` e il dato `align` viola le condizioni elencate in [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Restituisce la quantità di riempimento che dobbiamo inserire dopo `self` per garantire che il seguente indirizzo soddisfi `align` (misurato in byte).
    ///
    /// ad esempio, se `self.size()` è 9, `self.padding_needed_for(4)` restituisce 3, perché questo è il numero minimo di byte di riempimento richiesto per ottenere un indirizzo allineato a 4 (supponendo che il blocco di memoria corrispondente inizi con un indirizzo allineato a 4).
    ///
    ///
    /// Il valore di ritorno di questa funzione non ha significato se `align` non è una potenza di due.
    ///
    /// Si noti che l'utilità del valore restituito richiede che `align` sia minore o uguale all'allineamento dell'indirizzo iniziale per l'intero blocco di memoria allocato.Un modo per soddisfare questo vincolo è garantire `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Il valore arrotondato è:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // e quindi restituiamo la differenza di padding: `len_rounded_up - len`.
        //
        // Usiamo l'aritmetica modulare in tutto:
        //
        // 1. align è garantito per essere> 0, quindi align, 1 è sempre valido.
        //
        // 2.
        // `len + align - 1` può overflow al massimo `align - 1`, quindi la maschera&con `!(align - 1)` assicurerà che in caso di overflow, `len_rounded_up` stesso sarà 0.
        //
        //    Pertanto, il riempimento restituito, quando aggiunto a `len`, restituisce 0, che soddisfa banalmente l'allineamento `align`.
        //
        // (Ovviamente, i tentativi di allocare blocchi di memoria la cui dimensione e riempimento eccessivo nel modo sopra dovrebbe causare comunque un errore da parte dell'allocatore.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Crea un layout arrotondando le dimensioni di questo layout fino a un multiplo dell'allineamento del layout.
    ///
    ///
    /// Ciò equivale ad aggiungere il risultato di `padding_needed_for` alla dimensione corrente del layout.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Questo non può traboccare.Citando dall'invariante di Layout:
        // > `size`, quando arrotondato per eccesso al multiplo più vicino di `align`,
        // > non deve traboccare (ovvero, il valore arrotondato deve essere inferiore a
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Crea un layout che descrive il record per le istanze `n` di `self`, con una quantità adeguata di riempimento tra ciascuna per garantire che a ciascuna istanza venga assegnata la dimensione e l'allineamento richiesti.
    /// In caso di successo, restituisce `(k, offs)` dove `k` è il layout dell'array e `offs` è la distanza tra l'inizio di ogni elemento dell'array.
    ///
    /// In caso di overflow aritmetico, restituisce `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Questo non può traboccare.Citando dall'invariante di Layout:
        // > `size`, quando arrotondato per eccesso al multiplo più vicino di `align`,
        // > non deve traboccare (ovvero, il valore arrotondato deve essere inferiore a
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SICUREZZA: self.align è già noto per essere valido e alloc_size lo è stato
        // già imbottito.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Crea un layout che descrive il record per `self` seguito da `next`, incluso qualsiasi riempimento necessario per garantire che `next` sia allineato correttamente, ma *nessun riempimento finale*.
    ///
    /// Per far corrispondere il layout di rappresentazione C `repr(C)`, è necessario chiamare `pad_to_align` dopo aver esteso il layout a tutti i campi.
    /// (Non è possibile abbinare il layout di rappresentazione Rust predefinito `repr(Rust)`, as it is unspecified.)
    ///
    /// Si noti che l'allineamento del layout risultante sarà il massimo di quelli di `self` e `next`, in modo da garantire l'allineamento di entrambe le parti.
    ///
    /// Restituisce `Ok((k, offset))`, dove `k` è il layout del record concatenato e `offset` è la posizione relativa, in byte, dell'inizio di `next` incorporato nel record concatenato (supponendo che il record stesso inizi con offset 0).
    ///
    ///
    /// In caso di overflow aritmetico, restituisce `LayoutError`.
    ///
    /// # Examples
    ///
    /// Per calcolare il layout di una struttura `#[repr(C)]` e gli offset dei campi dai layout dei suoi campi:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ricordati di finalizzare con `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // prova che funzioni
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Crea un layout che descrive il record per le istanze `n` di `self`, senza riempimento tra ciascuna istanza.
    ///
    /// Si noti che, a differenza di `repeat`, `repeat_packed` non garantisce che le istanze ripetute di `self` saranno correttamente allineate, anche se una data istanza di `self` è correttamente allineata.
    /// In altre parole, se il layout restituito da `repeat_packed` viene utilizzato per allocare un array, non è garantito che tutti gli elementi dell'array saranno correttamente allineati.
    ///
    /// In caso di overflow aritmetico, restituisce `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Crea un layout che descrive il record per `self` seguito da `next` senza riempimento aggiuntivo tra i due.
    /// Poiché non è inserito alcun riempimento, l'allineamento di `next` è irrilevante e non è incorporato *affatto* nel layout risultante.
    ///
    ///
    /// In caso di overflow aritmetico, restituisce `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Crea un layout che descrive il record per un `[T; n]`.
    ///
    /// In caso di overflow aritmetico, restituisce `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// I parametri forniti a `Layout::from_size_align` o qualche altro costruttore `Layout` non soddisfano i suoi vincoli documentati.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ne abbiamo bisogno per l'impl a valle di trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}