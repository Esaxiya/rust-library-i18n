#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Contiene le definizioni della struttura per il layout dei tipi incorporati del compilatore.
//!
//! Possono essere usati come bersagli di trasmutazioni in codice non sicuro per manipolare direttamente le rappresentazioni grezze.
//!
//!
//! La loro definizione dovrebbe sempre corrispondere all'ABI definito in `rustc_middle::ty::layout`.
//!

/// La rappresentazione di un oggetto trait come `&dyn SomeTrait`.
///
/// Questa struttura ha lo stesso layout dei tipi come `&dyn SomeTrait` e `Box<dyn AnotherTrait>`.
///
/// `TraitObject` è garantito che corrisponda ai layout, ma non è il tipo di oggetti trait (ad esempio, i campi non sono direttamente accessibili su un `&dyn SomeTrait`) né controlla quel layout (cambiando la definizione non cambierà il layout di un `&dyn SomeTrait`).
///
/// È progettato solo per essere utilizzato da codice non sicuro che deve manipolare i dettagli di basso livello.
///
/// Non c'è modo di fare riferimento a tutti gli oggetti trait genericamente, quindi l'unico modo per creare valori di questo tipo è con funzioni come [`std::mem::transmute`][transmute].
/// Allo stesso modo, l'unico modo per creare un vero oggetto trait da un valore `TraitObject` è con `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// La sintesi di un oggetto trait con tipi non corrispondenti, uno in cui la tabella v non corrisponde al tipo del valore a cui punta il puntatore dati, è molto probabile che porti a un comportamento indefinito.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // un esempio trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lascia che il compilatore crei un oggetto trait
/// let object: &dyn Foo = &value;
///
/// // guarda la rappresentazione grezza
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // il puntatore ai dati è l'indirizzo di `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // costruire un nuovo oggetto, puntando a un `i32` diverso, facendo attenzione a utilizzare `i32` vtable da `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // dovrebbe funzionare proprio come se avessimo costruito un oggetto trait direttamente da `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}