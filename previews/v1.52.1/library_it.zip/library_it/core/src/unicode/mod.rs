#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// La versione di [Unicode](http://www.unicode.org/) su cui si basano le parti Unicode dei metodi `char` e `str`.
///
/// Nuove versioni di Unicode vengono rilasciate regolarmente e successivamente tutti i metodi nella libreria standard che dipendono da Unicode vengono aggiornati.
/// Pertanto il comportamento di alcuni metodi `char` e `str` e il valore di questa costante cambia nel tempo.
/// Questo *non* è considerato un cambiamento radicale.
///
/// Lo schema di numerazione delle versioni è spiegato in [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Per l'uso in liballoc, non riesportato in libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;