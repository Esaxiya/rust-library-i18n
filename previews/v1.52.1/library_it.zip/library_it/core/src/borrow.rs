//! Un modulo per lavorare con i dati presi in prestito.

#![stable(feature = "rust1", since = "1.0.0")]

/// Uno trait per prendere in prestito i dati.
///
/// In Rust, è comune fornire diverse rappresentazioni di un tipo per diversi casi d'uso.
/// Ad esempio, la posizione di archiviazione e la gestione di un valore possono essere scelte in modo specifico come appropriato per un uso particolare tramite tipi di puntatore come [`Box<T>`] o [`Rc<T>`].
/// Oltre a questi wrapper generici che possono essere utilizzati con qualsiasi tipo, alcuni tipi forniscono sfaccettature opzionali che forniscono funzionalità potenzialmente costose.
/// Un esempio per un tale tipo è [`String`] che aggiunge la possibilità di estendere una stringa all [`str`] di base.
/// Ciò richiede di mantenere informazioni aggiuntive non necessarie per una stringa semplice e immutabile.
///
/// Questi tipi forniscono l'accesso ai dati sottostanti tramite riferimenti al tipo di tali dati.Si dice che siano "presi in prestito come" quel tipo.
/// Ad esempio, un [`Box<T>`] può essere preso in prestito come `T` mentre un [`String`] può essere preso in prestito come `str`.
///
/// I tipi esprimono che possono essere presi in prestito come un tipo `T` implementando `Borrow<T>`, fornendo un riferimento a un `T` nel metodo [`borrow`] di trait.Un tipo può essere preso in prestito liberamente da diversi tipi.
/// Se desidera mutuamente prendere in prestito come tipo, consentendo la modifica dei dati sottostanti, può inoltre implementare [`BorrowMut<T>`].
///
/// Inoltre, quando si forniscono implementazioni per traits aggiuntivi, è necessario considerare se devono comportarsi in modo identico a quelli del tipo sottostante come conseguenza dell'azione come rappresentazione di quel tipo sottostante.
/// Il codice generico utilizza in genere `Borrow<T>` quando si basa sul comportamento identico di queste implementazioni trait aggiuntive.
/// Questi traits appariranno probabilmente come trait bounds aggiuntivi.
///
/// In particolare `Eq`, `Ord` e `Hash` devono essere equivalenti per i valori presi in prestito e posseduti: `x.borrow() == y.borrow()` dovrebbe dare lo stesso risultato di `x == y`.
///
/// Se il codice generico deve semplicemente funzionare per tutti i tipi che possono fornire un riferimento al tipo correlato `T`, spesso è meglio usare [`AsRef<T>`] poiché più tipi possono implementarlo in sicurezza.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Come raccolta di dati, [`HashMap<K, V>`] possiede sia chiavi che valori.Se i dati effettivi della chiave sono racchiusi in un tipo di gestione di qualche tipo, dovrebbe, tuttavia, essere ancora possibile cercare un valore utilizzando un riferimento ai dati della chiave.
/// Ad esempio, se la chiave è una stringa, è probabile che venga memorizzata con la mappa hash come [`String`], mentre dovrebbe essere possibile eseguire la ricerca utilizzando un [`&str`][`str`].
/// Pertanto, `insert` deve funzionare su un `String` mentre `get` deve essere in grado di utilizzare un `&str`.
///
/// Leggermente semplificato, le parti rilevanti di `HashMap<K, V>` hanno questo aspetto:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // campi omessi
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// L'intera mappa hash è generica su un tipo di chiave `K`.Poiché queste chiavi sono archiviate con la mappa hash, questo tipo deve possedere i dati della chiave.
/// Quando si inserisce una coppia chiave-valore, alla mappa viene assegnato un `K` di questo tipo e deve trovare il bucket hash corretto e verificare se la chiave è già presente in base a tale `K`.Pertanto richiede `K: Hash + Eq`.
///
/// Quando si cerca un valore nella mappa, tuttavia, dover fornire un riferimento a un `K` come chiave da cercare richiederebbe la creazione sempre di tale valore di proprietà.
/// Per le chiavi stringa, ciò significherebbe che è necessario creare un valore `String` solo per la ricerca dei casi in cui è disponibile solo `str`.
///
/// Invece, il metodo `get` è generico rispetto al tipo di dati chiave sottostanti, chiamato `Q` nella firma del metodo sopra.Afferma che `K` prende in prestito come `Q` richiedendo che `K: Borrow<Q>`.
/// Richiedendo inoltre `Q: Hash + Eq`, segnala il requisito che `K` e `Q` abbiano implementazioni di `Hash` e `Eq` traits che producono risultati identici.
///
/// L'implementazione di `get` si basa in particolare su implementazioni identiche di `Hash` determinando l'hash bucket della chiave chiamando `Hash::hash` sul valore `Q` anche se ha inserito la chiave in base al valore hash calcolato dal valore `K`.
///
///
/// Di conseguenza, la mappa hash si interrompe se un `K` che avvolge un valore `Q` produce un hash diverso da `Q`.Ad esempio, immagina di avere un tipo che racchiude una stringa ma confronta le lettere ASCII ignorandone le maiuscole:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Poiché due valori uguali devono produrre lo stesso valore hash, l'implementazione di `Hash` deve ignorare anche il caso ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` può implementare `Borrow<str>`?Certamente può fornire un riferimento a una sezione di stringa tramite la stringa di proprietà contenuta.
/// Ma poiché la sua implementazione `Hash` è diversa, si comporta diversamente da `str` e quindi non deve, infatti, implementare `Borrow<str>`.
/// Se vuole consentire ad altri l'accesso all `str` sottostante, può farlo tramite `AsRef<str>` che non comporta requisiti aggiuntivi.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Immutabilmente prende in prestito da un valore di proprietà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Un trait per mutuamente prendere in prestito dati.
///
/// In aggiunta a [`Borrow<T>`], questo trait consente a un tipo di prendere in prestito come tipo sottostante fornendo un riferimento modificabile.
/// Vedere [`Borrow<T>`] per ulteriori informazioni sul prestito come un altro tipo.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutuamente prende in prestito da un valore di proprietà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}