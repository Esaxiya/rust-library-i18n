#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// Un `RawWaker` consente all'implementatore di un esecutore di attività di creare un [`Waker`] che fornisce un comportamento di riattivazione personalizzato.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Consiste in un puntatore dati e un [virtual function pointer table (vtable)][vtable] che personalizza il comportamento dell `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Un puntatore ai dati, che può essere utilizzato per memorizzare dati arbitrari come richiesto dall'esecutore.
    /// Questo potrebbe essere ad es
    /// un puntatore cancellato dal tipo a un `Arc` associato all'attività.
    /// Il valore di questo campo viene passato a tutte le funzioni che fanno parte di vtable come primo parametro.
    ///
    data: *const (),
    /// Tabella del puntatore di funzione virtuale che personalizza il comportamento di questo waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Crea un nuovo `RawWaker` dal puntatore `data` fornito e `vtable`.
    ///
    /// Il puntatore `data` può essere utilizzato per memorizzare dati arbitrari come richiesto dall'esecutore.Questo potrebbe essere ad es
    /// un puntatore cancellato dal tipo a un `Arc` associato all'attività.
    /// Il valore di questo puntatore verrà passato a tutte le funzioni che fanno parte di `vtable` come primo parametro.
    ///
    /// L `vtable` personalizza il comportamento di un `Waker` che viene creato da un `RawWaker`.
    /// Per ogni operazione sull `Waker`, verrà chiamata la funzione associata nell `vtable` dell `RawWaker` sottostante.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Una tabella di puntatori a funzioni virtuali (vtable) che specifica il comportamento di un [`RawWaker`].
///
/// Il puntatore passato a tutte le funzioni all'interno di vtable è il puntatore `data` dall'oggetto [`RawWaker`] che lo racchiude.
///
/// Le funzioni all'interno di questa struttura devono essere chiamate solo sul puntatore `data` di un oggetto [`RawWaker`] costruito correttamente dall'interno dell'implementazione [`RawWaker`].
/// Chiamare una delle funzioni contenute utilizzando qualsiasi altro puntatore `data` provocherà un comportamento indefinito.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Questa funzione verrà chiamata quando l [`RawWaker`] viene clonato, ad esempio quando l [`Waker`] in cui è memorizzato l [`RawWaker`] viene clonato.
    ///
    /// L'implementazione di questa funzione deve conservare tutte le risorse necessarie per questa istanza aggiuntiva di un [`RawWaker`] e l'attività associata.
    /// Chiamare `wake` sull [`RawWaker`] risultante dovrebbe comportare il risveglio della stessa attività che sarebbe stata svegliata dall [`RawWaker`] originale.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Questa funzione verrà chiamata quando `wake` viene richiamato su [`Waker`].
    /// Deve riattivare l'attività associata a questo [`RawWaker`].
    ///
    /// L'implementazione di questa funzione deve assicurarsi di rilasciare tutte le risorse associate a questa istanza di un [`RawWaker`] e all'attività associata.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Questa funzione verrà chiamata quando `wake_by_ref` viene richiamato su [`Waker`].
    /// Deve riattivare l'attività associata a questo [`RawWaker`].
    ///
    /// Questa funzione è simile a `wake`, ma non deve consumare il puntatore ai dati fornito.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Questa funzione viene chiamata quando viene rilasciato un [`RawWaker`].
    ///
    /// L'implementazione di questa funzione deve assicurarsi di rilasciare tutte le risorse associate a questa istanza di un [`RawWaker`] e all'attività associata.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Crea un nuovo `RawWakerVTable` dalle funzioni `clone`, `wake`, `wake_by_ref` e `drop` fornite.
    ///
    /// # `clone`
    ///
    /// Questa funzione verrà chiamata quando l [`RawWaker`] viene clonato, ad esempio quando l [`Waker`] in cui è memorizzato l [`RawWaker`] viene clonato.
    ///
    /// L'implementazione di questa funzione deve conservare tutte le risorse necessarie per questa istanza aggiuntiva di un [`RawWaker`] e l'attività associata.
    /// Chiamare `wake` sull [`RawWaker`] risultante dovrebbe comportare il risveglio della stessa attività che sarebbe stata svegliata dall [`RawWaker`] originale.
    ///
    /// # `wake`
    ///
    /// Questa funzione verrà chiamata quando `wake` viene richiamato su [`Waker`].
    /// Deve riattivare l'attività associata a questo [`RawWaker`].
    ///
    /// L'implementazione di questa funzione deve assicurarsi di rilasciare tutte le risorse associate a questa istanza di un [`RawWaker`] e all'attività associata.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Questa funzione verrà chiamata quando `wake_by_ref` viene richiamato su [`Waker`].
    /// Deve riattivare l'attività associata a questo [`RawWaker`].
    ///
    /// Questa funzione è simile a `wake`, ma non deve consumare il puntatore ai dati fornito.
    ///
    /// # `drop`
    ///
    /// Questa funzione viene chiamata quando viene rilasciato un [`RawWaker`].
    ///
    /// L'implementazione di questa funzione deve assicurarsi di rilasciare tutte le risorse associate a questa istanza di un [`RawWaker`] e all'attività associata.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// L `Context` di un'attività asincrona.
///
/// Attualmente, `Context` serve solo a fornire l'accesso a un `&Waker` che può essere utilizzato per riattivare l'attività corrente.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Assicurati di essere a prova di future contro i cambiamenti di varianza forzando la durata a essere invariante (la durata della posizione dell'argomento è controvariante mentre la durata della posizione di ritorno è covariante).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Crea un nuovo `Context` da un `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Restituisce un riferimento a `Waker` per l'attività corrente.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// Un `Waker` è un handle per riattivare un'attività notificando al suo esecutore che è pronta per essere eseguita.
///
/// Questo handle incapsula un'istanza [`RawWaker`], che definisce il comportamento di attivazione specifico dell'esecutore.
///
///
/// Implementa [`Clone`], [`Send`] e [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Riattiva l'attività associata a questo `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // La chiamata di sveglia effettiva viene delegata all'implementazione definita dall'esecutore tramite una chiamata di funzione virtuale.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Non chiamare `drop`: il waker verrà consumato da `wake`.
        crate::mem::forget(self);

        // SICUREZZA: questo è sicuro perché `Waker::from_raw` è l'unico modo
        // per inizializzare `wake` e `data` richiedendo all'utente di riconoscere che il contratto di `RawWaker` è rispettato.
        //
        unsafe { (wake)(data) };
    }

    /// Riattiva l'attività associata a questo `Waker` senza consumare `Waker`.
    ///
    /// È simile a `wake`, ma potrebbe essere leggermente meno efficiente nel caso in cui sia disponibile un `Waker` di proprietà.
    /// Questo metodo dovrebbe essere preferito alla chiamata di `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // La chiamata di sveglia effettiva viene delegata all'implementazione definita dall'esecutore tramite una chiamata di funzione virtuale.
        //

        // SICUREZZA: vedi `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Restituisce `true` se questo `Waker` e un altro `Waker` hanno risvegliato la stessa attività.
    ///
    /// Questa funzione funziona su una base di massimo sforzo e può restituire false anche quando il `Waker` s risveglia lo stesso compito.
    /// Tuttavia, se questa funzione restituisce `true`, è garantito che il `Waker` s risveglierà lo stesso compito.
    ///
    /// Questa funzione viene utilizzata principalmente per scopi di ottimizzazione.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Crea un nuovo `Waker` da [`RawWaker`].
    ///
    /// Il comportamento dell `Waker` restituito non è definito se il contratto definito nella documentazione di [`RawWaker`] e [`RawWakerVTable`] non è rispettato.
    ///
    /// Pertanto questo metodo non è sicuro.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SICUREZZA: questo è sicuro perché `Waker::from_raw` è l'unico modo
            // per inizializzare `clone` e `data` richiedendo all'utente di riconoscere che il contratto di [`RawWaker`] è rispettato.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SICUREZZA: questo è sicuro perché `Waker::from_raw` è l'unico modo
        // per inizializzare `drop` e `data` richiedendo all'utente di riconoscere che il contratto di `RawWaker` è rispettato.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}