//! Tipi che bloccano i dati nella loro posizione in memoria.
//!
//! A volte è utile avere oggetti di cui è garantito il non movimento, nel senso che la loro collocazione nella memoria non cambia e quindi su cui si può fare affidamento.
//! Un primo esempio di tale scenario sarebbe la costruzione di strutture autoreferenziali, poiché lo spostamento di un oggetto con puntatori a se stesso le invaliderà, il che potrebbe causare un comportamento indefinito.
//!
//! Ad un livello elevato, un [`Pin<P>`] garantisce che le punte di qualsiasi tipo di puntatore `P` abbiano una posizione stabile in memoria, il che significa che non possono essere spostate altrove e la sua memoria non può essere rilasciata finché non viene rilasciata.Diciamo che la punta è "pinned".Le cose diventano più sottili quando si discute di tipi che combinano dati bloccati con dati non bloccati;[see below](#projections-and-structural-pinning) per maggiori dettagli.
//!
//! Per impostazione predefinita, tutti i tipi in Rust sono mobili.
//! Rust consente di passare tutti i tipi per valore e i tipi comuni di puntatori intelligenti come [`Box<T>`] e `&mut T` consentono di sostituire e spostare i valori che contengono: puoi uscire da un [`Box<T>`], oppure puoi usare [`mem::swap`].
//! [`Pin<P>`] racchiude un puntatore di tipo `P`, quindi [`Pin`]`<`[`Box`] `<T>>`funziona in modo molto simile a un normale
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`viene eliminato, così come il suo contenuto, e la memoria viene
//!
//! deallocato.Allo stesso modo, [`Pin`]`<&mut T>`è molto simile a `&mut T`.Tuttavia, [`Pin<P>`] non consente ai client di ottenere effettivamente un [`Box<T>`] o `&mut T` per i dati bloccati, il che implica che non è possibile utilizzare operazioni come [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` ha bisogno di `&mut T`, ma non possiamo ottenerlo.
//!     // Siamo bloccati, non possiamo scambiare il contenuto di questi riferimenti.
//!     // Potremmo usare `Pin::get_unchecked_mut`, ma non è sicuro per un motivo:
//!     // non ci è permesso usarlo per spostare cose fuori dall `Pin`.
//! }
//! ```
//!
//! Vale la pena ribadire che [`Pin<P>`]*non* cambia il fatto che un compilatore Rust considera tutti i tipi mobili.[`mem::swap`] rimane richiamabile per qualsiasi `T`.Invece, [`Pin<P>`] impedisce che determinati *valori*(puntati da puntatori racchiusi in [`Pin<P>`]) vengano spostati rendendo impossibile chiamare metodi che richiedono `&mut T` su di essi (come [`mem::swap`]).
//!
//! [`Pin<P>`] può essere utilizzato per avvolgere qualsiasi tipo di puntatore `P`, e come tale interagisce con [`Deref`] e [`DerefMut`].Un [`Pin<P>`] dove `P: Deref` dovrebbe essere considerato come un "`P`-style pointer" per un `P::Target` bloccato, quindi un [`Pin`]`<`[`Box`] `<T>>`è un puntatore di proprietà a un `T` bloccato e un [`Pin`] `<` [`Rc`]`<T>>`è un puntatore conteggio dei riferimenti a un `T` bloccato.
//! Per correttezza, [`Pin<P>`] si basa sulle implementazioni di [`Deref`] e [`DerefMut`] per non uscire dal loro parametro `self` e solo per restituire un puntatore ai dati bloccati quando vengono chiamati su un puntatore bloccato.
//!
//! # `Unpin`
//!
//! Molti tipi sono sempre spostabili liberamente, anche se bloccati, perché non si basano sull'avere un indirizzo stabile.Ciò include tutti i tipi di base (come [`bool`], [`i32`] e riferimenti) nonché i tipi costituiti esclusivamente da questi tipi.I tipi che non si preoccupano del pinning implementano l'auto-trait di [`Unpin`], che annulla l'effetto di [`Pin<P>`].
//! Per `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`e [`Box<T>`] funzionano in modo identico, così come [`Pin`] `<&mut T>` e `&mut T`.
//!
//! Si noti che il pinning e [`Unpin`] influiscono solo sul tipo a punta `P::Target`, non sul tipo di puntatore `P` stesso che è stato avvolto in [`Pin<P>`].Ad esempio, il fatto che [`Box<T>`] sia [`Unpin`] non ha alcun effetto sul comportamento di [`Pin`]`<`[`Box`] `<T>>`(qui, `T` è il tipo a punta).
//!
//! # Esempio: struttura autoreferenziale
//!
//! Prima di entrare in maggiori dettagli per spiegare le garanzie e le scelte associate a `Pin<T>`, discutiamo alcuni esempi di come potrebbe essere utilizzato.
//! Sentiti libero di [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Questa è una struttura autoreferenziale perché il campo slice punta al campo dati.
//! // Non possiamo informare il compilatore di questo con un riferimento normale, poiché questo modello non può essere descritto con le solite regole di prestito.
//! //
//! // Invece usiamo un puntatore grezzo, anche se noto per non essere nullo, poiché sappiamo che punta alla stringa.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Per garantire che i dati non si spostino quando la funzione ritorna, li posizioniamo nell'heap dove rimarrà per la durata dell'oggetto e l'unico modo per accedervi sarebbe tramite un puntatore ad esso.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // creiamo il puntatore solo una volta che i dati sono a posto altrimenti sarà già spostato prima ancora di iniziare
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // sappiamo che questo è sicuro perché la modifica di un campo non sposta l'intera struttura
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Il puntatore dovrebbe puntare alla posizione corretta, purché la struttura non si sia spostata.
//! //
//! // Nel frattempo, siamo liberi di spostare il puntatore.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Poiché il nostro tipo non implementa Unpin, non verrà compilato:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Esempio: elenco intrusivo a doppio collegamento
//!
//! In un elenco intrusivo a doppio collegamento, la raccolta non alloca effettivamente la memoria per gli elementi stessi.
//! L'allocazione è controllata dai client e gli elementi possono vivere su uno stack frame che dura meno della raccolta.
//!
//! Per far funzionare questo, ogni elemento ha puntatori al suo predecessore e successore nell'elenco.Gli elementi possono essere aggiunti solo quando sono bloccati, perché spostare gli elementi in giro invaliderebbe i puntatori.Inoltre, l'implementazione [`Drop`] di un elemento dell'elenco collegato correggerà i puntatori del suo predecessore e successore per rimuoverlo dall'elenco.
//!
//! Fondamentalmente, dobbiamo essere in grado di fare affidamento sul fatto che [`drop`] venga chiamato.Se un elemento potesse essere deallocato o altrimenti invalidato senza chiamare [`drop`], i puntatori in esso dai suoi elementi vicini diventerebbero non validi, il che romperebbe la struttura dei dati.
//!
//! Pertanto, il blocco viene fornito anche con una garanzia relativa a [`drop`].
//!
//! # `Drop` guarantee
//!
//! Lo scopo del pinning è poter fare affidamento sul posizionamento di alcuni dati in memoria.
//! Per fare in modo che funzioni, non solo lo spostamento dei dati è limitato;anche la deallocazione, la riproposizione o l'invalidamento in altro modo della memoria utilizzata per archiviare i dati sono limitate.
//! In concreto, per i dati bloccati devi mantenere l'invariante che *la sua memoria non verrà invalidata o riproposta dal momento in cui viene bloccata fino a quando viene chiamato [`drop`]*.Solo una volta che [`drop`] ritorna o panics, la memoria può essere riutilizzata.
//!
//! La memoria può essere "invalidated" per deallocazione, ma anche sostituendo un [`Some(v)`] con [`None`], o chiamando [`Vec::set_len`] a "kill" alcuni elementi da un vector.Può essere riproposto utilizzando [`ptr::write`] per sovrascriverlo senza chiamare prima il distruttore.Niente di tutto questo è consentito per i dati bloccati senza chiamare [`drop`].
//!
//! Questo è esattamente il tipo di garanzia che l'elenco collegato intrusivo della sezione precedente deve funzionare correttamente.
//!
//! Notare che questa garanzia *non* significa che la memoria non perde!Va comunque del tutto bene non chiamare mai [`drop`] su un elemento bloccato (ad esempio, puoi ancora chiamare [`mem::forget`] su un [`Pin`]`<`[`Box`] `<T>>`).Nell'esempio dell'elenco a doppio collegamento, quell'elemento rimarrebbe semplicemente nell'elenco.Tuttavia non puoi liberare o riutilizzare lo spazio di archiviazione *senza chiamare [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Se il tuo tipo usa il pinning (come i due esempi sopra), devi stare attento quando implementi [`Drop`].La funzione [`drop`] accetta `&mut self`, ma viene chiamata *anche se il tuo tipo è stato precedentemente bloccato*!È come se il compilatore chiamasse automaticamente [`Pin::get_unchecked_mut`].
//!
//! Ciò non può mai causare un problema nel codice sicuro perché l'implementazione di un tipo che si basa sul pinning richiede codice non sicuro, ma sii consapevole che decidere di utilizzare il pinning nel tuo tipo (ad esempio implementando alcune operazioni su [`Pin`]`<&Self>`o [`Pin`] `<&mut Self>`) ha conseguenze anche per la tua implementazione [`Drop`]: se un elemento del tuo tipo poteva essere bloccato, devi considerare [`Drop`] come implicitamente prendendo [`Pin`]`<&mut Self>`.
//!
//!
//! Ad esempio, potresti implementare `Drop` come segue:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` va bene perché sappiamo che questo valore non viene mai più utilizzato dopo essere stato eliminato.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Il codice di rilascio effettivo va qui.
//!         }
//!     }
//! }
//! ```
//!
//! La funzione `inner_drop` ha il tipo che [`drop`]*dovrebbe* avere, quindi questo assicura che non si utilizzi accidentalmente `self`/`this` in un modo che sia in conflitto con il pinning.
//!
//! Inoltre, se il tuo tipo è `#[repr(packed)]`, il compilatore sposterà automaticamente i campi per poterli rilasciare.Potrebbe anche farlo per i campi che sono sufficientemente allineati.Di conseguenza, non è possibile utilizzare il pinning con un tipo `#[repr(packed)]`.
//!
//! # Proiezioni e vincoli strutturali
//!
//! Quando si lavora con strutture bloccate, sorge la domanda su come si possa accedere ai campi di quella struttura in un metodo che richiede solo [`Pin`]`<&mut Struct>`.
//! L'approccio usuale è scrivere metodi di supporto (le cosiddette *proiezioni*) che trasformano [`Pin`]`<&mut Struct>`in un riferimento al campo, ma che tipo dovrebbe avere quel riferimento?È [`Pin`]`<&mut Field>`o `&mut Field`?
//! La stessa domanda sorge con i campi di un `enum`, e anche quando si considerano i tipi container/wrapper come [`Vec<T>`], [`Box<T>`] o [`RefCell<T>`].
//! (Questa domanda si applica sia ai riferimenti mutabili che condivisi, qui usiamo solo il caso più comune di riferimenti mutabili a scopo illustrativo.)
//!
//! Si scopre che in realtà spetta all'autore della struttura dati decidere se la proiezione bloccata per un particolare campo trasforma [`Pin`]`<&mut Struct>`in [`Pin`] `<&mut Field>` o `&mut Field`.Ci sono tuttavia alcuni vincoli, e il vincolo più importante è *coerenza*:
//! ogni campo può essere *o* proiettato su un riferimento bloccato,*o* avere il blocco rimosso come parte della proiezione.
//! Se entrambi vengono eseguiti per lo stesso campo, probabilmente non sarà corretto!
//!
//! In qualità di autore di una struttura dati, puoi decidere per ogni campo se bloccare o meno "propagates" a questo campo.
//! Il pinning che si propaga è anche chiamato "structural", perché segue la struttura del tipo.
//! Nelle seguenti sottosezioni, descriviamo le considerazioni che devono essere fatte per entrambe le scelte.
//!
//! ## Il pinning *non* è strutturale per `field`
//!
//! Può sembrare controintuitivo che il campo di una struttura bloccata potrebbe non essere bloccato, ma questa è in realtà la scelta più semplice: se un [`Pin`]`<&mut Field>`non viene mai creato, niente può andare storto!Quindi, se decidi che un campo non ha il blocco strutturale, tutto ciò che devi assicurarti è di non creare mai un riferimento bloccato a quel campo.
//!
//! I campi senza vincoli strutturali possono avere un metodo di proiezione che trasforma [`Pin`]`<&mut Struct>`in `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Questo va bene perché `field` non viene mai considerato bloccato.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Puoi anche `impl Unpin for Struct`*anche se* il tipo di `field` non è [`Unpin`].Ciò che quel tipo pensa del blocco non è rilevante quando non viene mai creato alcun [`Pin`]`<&mut Field>`.
//!
//! ## Il blocco *è* strutturale per `field`
//!
//! L'altra opzione è decidere che il pinning è "structural" per `field`, il che significa che se lo struct è bloccato, lo è anche il campo.
//!
//! Ciò consente di scrivere una proiezione che crea un [`Pin`]`<&mut Field>`, testimoniando così che il campo è bloccato:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Questo va bene perché `field` è bloccato quando `self` è.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tuttavia, il fissaggio strutturale viene fornito con alcuni requisiti aggiuntivi:
//!
//! 1. La struttura deve essere [`Unpin`] solo se tutti i campi strutturali sono [`Unpin`].Questa è l'impostazione predefinita, ma [`Unpin`] è uno trait sicuro, quindi come autore della struttura è tua *responsabilità* non * aggiungere qualcosa come `impl<T> Unpin for Struct<T>`.
//! (Si noti che l'aggiunta di un'operazione di proiezione richiede un codice non sicuro, quindi il fatto che [`Unpin`] sia uno trait sicuro non infrange il principio secondo cui devi preoccuparti di tutto ciò solo se usi `unsafe`.)
//! 2. Il distruttore della struttura non deve spostare i campi strutturali fuori dal suo argomento.Questo è il punto esatto che è stato sollevato nell [previous section][drop-impl]: `drop` accetta `&mut self`, ma la struttura (e quindi i suoi campi) potrebbe essere stata bloccata prima.
//!     Devi garantire di non spostare un campo all'interno della tua implementazione [`Drop`].
//!     In particolare, come spiegato in precedenza, questo significa che la tua struttura *non* deve essere `#[repr(packed)]`.
//!     Vedi quella sezione per come scrivere [`drop`] in modo che il compilatore possa aiutarti a non interrompere accidentalmente il pinning.
//! 3. Devi assicurarti di sostenere l [`Drop` guarantee][drop-guarantee]:
//!     una volta che la tua struttura è bloccata, la memoria che contiene il contenuto non viene sovrascritta o deallocata senza chiamare i distruttori del contenuto.
//!     Questo può essere complicato, come testimoniato da [`VecDeque<T>`]: il distruttore di [`VecDeque<T>`] può non chiamare [`drop`] su tutti gli elementi se uno dei distruttori panics.Ciò viola la garanzia [`Drop`], perché può portare alla deallocazione di elementi senza che venga chiamato il loro distruttore.([`VecDeque<T>`] non ha proiezioni di blocco, quindi ciò non causa problemi di integrità.)
//! 4. Non è necessario offrire altre operazioni che potrebbero portare allo spostamento dei dati fuori dai campi strutturali quando il tipo è bloccato.Ad esempio, se la struttura contiene un [`Option<T>`] e c'è un'operazione simile a `take` con il tipo `fn(Pin<&mut Struct<T>>) -> Option<T>`, tale operazione può essere utilizzata per spostare un `T` da un `Struct<T>` bloccato-il che significa che il pinning non può essere strutturale per il campo che lo contiene dati.
//!
//!     Per un esempio più complesso di spostamento dei dati da un tipo bloccato, immagina se [`RefCell<T>`] avesse un metodo `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Quindi potremmo fare quanto segue:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Questo è catastrofico, significa che possiamo prima bloccare il contenuto di [`RefCell<T>`] (usando `RefCell::get_pin_mut`) e poi spostare quel contenuto usando il riferimento mutabile che abbiamo ottenuto in seguito.
//!
//! ## Examples
//!
//! Per un tipo come [`Vec<T>`], entrambe le possibilità (blocco strutturale o meno) hanno senso.
//! Un [`Vec<T>`] con blocco strutturale potrebbe avere metodi `get_pin`/`get_pin_mut` per ottenere riferimenti bloccati agli elementi.Tuttavia,*non* consentirebbe di chiamare [`pop`][Vec::pop] su un [`Vec<T>`] bloccato perché ciò sposterebbe i contenuti (bloccati strutturalmente)!Né potrebbe consentire [`push`][Vec::push], che potrebbe riallocare e quindi spostare anche i contenuti.
//!
//! Un [`Vec<T>`] senza blocco strutturale potrebbe `impl<T> Unpin for Vec<T>`, perché i contenuti non vengono mai bloccati e anche l [`Vec<T>`] stesso può essere spostato.
//! A quel punto il blocco non ha alcun effetto su vector.
//!
//! Nella libreria standard, i tipi di puntatore in genere non hanno vincoli strutturali e quindi non offrono proiezioni di vincolo.Questo è il motivo per cui `Box<T>: Unpin` vale per tutti gli `T`.
//! Ha senso farlo per i tipi di puntatore, perché lo spostamento dell `Box<T>` non sposta effettivamente l `T`: l [`Box<T>`] può essere spostato liberamente (noto anche come `Unpin`) anche se l `T` non lo è.In effetti, anche [`Pin`]`<`[`Box`] `<T>>`e [`Pin`] `<&mut T>` sono sempre gli stessi [`Unpin`], per lo stesso motivo: i loro contenuti (l `T`) sono bloccati, ma i puntatori stessi possono essere spostati senza spostare i dati bloccati.
//! Sia per [`Box<T>`] che per [`Pin`]`<`[`Box`] `<T>>`, se il contenuto è bloccato è del tutto indipendente dal fatto che il puntatore sia bloccato, il che significa che il blocco è *non* strutturale.
//!
//! Quando si implementa un combinatore [`Future`], di solito è necessario un blocco strutturale per futures annidato, poiché è necessario ottenere riferimenti bloccati ad essi per chiamare [`poll`].
//! Ma se il tuo combinatore contiene altri dati che non devono essere bloccati, puoi rendere quei campi non strutturali e quindi accedervi liberamente con un riferimento mutabile anche quando hai solo [`Pin`]`<&mut Self>`(come come nella tua implementazione [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Un puntatore appuntato.
///
/// Questo è un wrapper attorno a un tipo di puntatore che rende quel puntatore "pin" il suo valore in posizione, impedendo che il valore a cui fa riferimento quel puntatore venga spostato a meno che non implementi [`Unpin`].
///
///
/// *Vedere la documentazione di [`pin` module] per una spiegazione del pinning.*
///
/// [`pin` module]: self
///
// Note: l `Clone` derivato di seguito causa malfunzionamento in quanto è possibile implementarlo
// `Clone` per riferimenti mutabili.
// Vedi <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> per maggiori dettagli.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Le seguenti implementazioni non sono derivate per evitare problemi di solidità.
// `&self.pointer` non dovrebbe essere accessibile a implementazioni trait non attendibili.
//
// Vedi <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> per maggiori dettagli.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Costruisci un nuovo `Pin<P>` attorno a un puntatore ad alcuni dati di un tipo che implementa [`Unpin`].
    ///
    /// A differenza di `Pin::new_unchecked`, questo metodo è sicuro perché il puntatore `P` dereferisce a un tipo [`Unpin`], il che annulla le garanzie di pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SICUREZZA: il valore puntato è `Unpin`, quindi non ha requisiti
        // intorno al pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Annulla il wrapping di questo `Pin<P>` restituendo il puntatore sottostante.
    ///
    /// Ciò richiede che i dati all'interno di questo `Pin` siano [`Unpin`] in modo da poter ignorare gli invarianti di blocco quando lo si scarta.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Costruisci un nuovo `Pin<P>` attorno a un riferimento ad alcuni dati di un tipo che può o non può implementare `Unpin`.
    ///
    /// Se `pointer` dereferenzia a un tipo `Unpin`, è necessario utilizzare `Pin::new`.
    ///
    /// # Safety
    ///
    /// Questo costruttore non è sicuro perché non possiamo garantire che i dati puntati da `pointer` siano bloccati, il che significa che i dati non verranno spostati o la loro archiviazione invalidata finché non vengono rilasciati.
    /// Se l `Pin<P>` costruito non garantisce che i dati a cui punta `P` siano bloccati, si tratta di una violazione del contratto API e può portare a un comportamento indefinito nelle successive operazioni (safe).
    ///
    /// Usando questo metodo, stai facendo una promise sulle implementazioni `P::Deref` e `P::DerefMut`, se esistono.
    /// Soprattutto, non devono uscire dai loro argomenti `self`: `Pin::as_mut` e `Pin::as_ref` chiameranno `DerefMut::deref_mut` e `Deref::deref`*sul puntatore bloccato* e si aspettano che questi metodi mantengano le invarianti di blocco.
    /// Inoltre, chiamando questo metodo si promise che il riferimento `P` dereferenzia non verrà spostato nuovamente;in particolare, non deve essere possibile ottenere un `&mut P::Target` e poi uscire da quel riferimento (utilizzando, ad esempio, [`mem::swap`]).
    ///
    ///
    /// Ad esempio, chiamare `Pin::new_unchecked` su un `&'a mut T` non è sicuro perché mentre sei in grado di bloccarlo per la durata di `'a` data, non hai alcun controllo sul fatto che venga mantenuto bloccato una volta che `'a` termina:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Ciò dovrebbe significare che la punta `a` non potrà mai più muoversi.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // L'indirizzo di `a` è cambiato nello stack slot di `b`, quindi `a` è stato spostato anche se lo abbiamo bloccato in precedenza!Abbiamo violato il contratto API di blocco.
    /////
    /// }
    /// ```
    ///
    /// Un valore, una volta bloccato, deve rimanere bloccato per sempre (a meno che il suo tipo non implementi `Unpin`).
    ///
    /// Allo stesso modo, chiamare `Pin::new_unchecked` su un `Rc<T>` non è sicuro perché potrebbero esserci alias per gli stessi dati che non sono soggetti alle restrizioni di blocco:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Questo dovrebbe significare che le punte non potranno mai più muoversi.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Ora, se `x` fosse l'unico riferimento, abbiamo un riferimento mutabile ai dati che abbiamo bloccato sopra, che potremmo usare per spostarlo come abbiamo visto nell'esempio precedente.
    ///     // Abbiamo violato il contratto API di blocco.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Ottiene un riferimento condiviso bloccato da questo puntatore bloccato.
    ///
    /// Questo è un metodo generico per passare da `&Pin<Pointer<T>>` a `Pin<&T>`.
    /// È sicuro perché, come parte del contratto di `Pin::new_unchecked`, le punte non possono muoversi dopo che `Pin<Pointer<T>>` è stato creato.
    ///
    /// "Malicious" anche le implementazioni di `Pointer::Deref` sono escluse dal contratto di `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SICUREZZA: vedere la documentazione su questa funzione
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Annulla il wrapping di questo `Pin<P>` restituendo il puntatore sottostante.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura.È necessario garantire che si continuerà a trattare il puntatore `P` come bloccato dopo aver chiamato questa funzione, in modo che le invarianti sul tipo `Pin` possano essere confermate.
    /// Se il codice che utilizza l `P` risultante non continua a mantenere le invarianti di blocco, si tratta di una violazione del contratto API e può portare a un comportamento indefinito nelle successive operazioni (safe).
    ///
    ///
    /// Se i dati sottostanti sono [`Unpin`], è necessario utilizzare [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Ottiene un riferimento modificabile bloccato da questo puntatore bloccato.
    ///
    /// Questo è un metodo generico per passare da `&mut Pin<Pointer<T>>` a `Pin<&mut T>`.
    /// È sicuro perché, come parte del contratto di `Pin::new_unchecked`, le punte non possono muoversi dopo che `Pin<Pointer<T>>` è stato creato.
    ///
    /// "Malicious" anche le implementazioni di `Pointer::DerefMut` sono escluse dal contratto di `Pin::new_unchecked`.
    ///
    /// Questo metodo è utile quando si eseguono più chiamate a funzioni che utilizzano il tipo bloccato.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // fare qualcosa
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` consuma `self`, quindi riassume l `Pin<&mut Self>` tramite `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SICUREZZA: vedere la documentazione su questa funzione
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Assegna un nuovo valore alla memoria dietro il riferimento bloccato.
    ///
    /// Questo sovrascrive i dati bloccati, ma va bene: il suo distruttore viene eseguito prima di essere sovrascritto, quindi non viene violata alcuna garanzia di blocco.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Costruisce un nuovo perno mappando il valore interno.
    ///
    /// Ad esempio, se si desidera ottenere un `Pin` di un campo di qualcosa, è possibile utilizzarlo per accedere a quel campo in una riga di codice.
    /// Tuttavia, ci sono diversi trucchi con questi "pinning projections";
    /// vedere la documentazione di [`pin` module] per ulteriori dettagli su questo argomento.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura.
    /// Devi garantire che i dati che restituisci non si sposteranno fintanto che il valore dell'argomento non si sposta (ad esempio, perché è uno dei campi di quel valore), e anche che non esci dall'argomento che ricevi a la funzione interna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SICUREZZA: il contratto di sicurezza per `new_unchecked` deve essere
        // confermato dal chiamante.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Ottiene un riferimento condiviso da un pin.
    ///
    /// Questo è sicuro perché non è possibile uscire da un riferimento condiviso.
    /// Può sembrare che qui ci sia un problema con la mutabilità interna: infatti,*è* possibile spostare un `T` da un `&RefCell<T>`.
    /// Tuttavia, questo non è un problema fintanto che non esiste anche un `Pin<&T>` che punta agli stessi dati e `RefCell<T>` non consente di creare un riferimento bloccato al suo contenuto.
    ///
    /// Vedere la discussione su ["pinning projections"] per ulteriori dettagli.
    ///
    /// Note: `Pin` implementa anche `Deref` sul target, che può essere utilizzato per accedere al valore interno.
    /// Tuttavia, `Deref` fornisce solo un riferimento che dura quanto il prestito dell `Pin`, non la durata dell `Pin` stesso.
    /// Questo metodo consente di trasformare l `Pin` in un riferimento con la stessa durata dell `Pin` originale.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Converte questo `Pin<&mut T>` in un `Pin<&T>` con la stessa durata.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Ottiene un riferimento modificabile ai dati all'interno di questo `Pin`.
    ///
    /// Ciò richiede che i dati all'interno di questo `Pin` siano `Unpin`.
    ///
    /// Note: `Pin` implementa anche `DerefMut` ai dati, che può essere utilizzato per accedere al valore interno.
    /// Tuttavia, `DerefMut` fornisce solo un riferimento che dura quanto il prestito dell `Pin`, non la durata dell `Pin` stesso.
    ///
    /// Questo metodo consente di trasformare l `Pin` in un riferimento con la stessa durata dell `Pin` originale.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Ottiene un riferimento modificabile ai dati all'interno di questo `Pin`.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura.
    /// Devi garantire che non sposterai mai i dati fuori dal riferimento mutabile che ricevi quando chiami questa funzione, in modo che gli invarianti sul tipo `Pin` possano essere confermati.
    ///
    ///
    /// Se i dati sottostanti sono `Unpin`, è necessario utilizzare `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Costruisci un nuovo perno mappando il valore interno.
    ///
    /// Ad esempio, se si desidera ottenere un `Pin` di un campo di qualcosa, è possibile utilizzarlo per accedere a quel campo in una riga di codice.
    /// Tuttavia, ci sono diversi trucchi con questi "pinning projections";
    /// vedere la documentazione di [`pin` module] per ulteriori dettagli su questo argomento.
    ///
    /// # Safety
    ///
    /// Questa funzione non è sicura.
    /// Devi garantire che i dati che restituisci non si sposteranno fintanto che il valore dell'argomento non si sposta (ad esempio, perché è uno dei campi di quel valore), e anche che non esci dall'argomento che ricevi a la funzione interna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SICUREZZA: il chiamante è responsabile di non spostare il file
        // valore fuori da questo riferimento.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SICUREZZA: poiché è garantito che il valore di `this` non avrà
        // stata spostata, questa chiamata a `new_unchecked` è sicura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Ottieni un riferimento bloccato da un riferimento statico.
    ///
    /// Questo è sicuro, perché `T` viene preso in prestito per la durata di `'static`, che non finisce mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SICUREZZA: L 'prestito statico garantisce che i dati non lo saranno
        // moved/invalidated fino a quando non viene lasciato cadere (che non è mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Ottieni un riferimento modificabile bloccato da un riferimento modificabile statico.
    ///
    /// Questo è sicuro, perché `T` viene preso in prestito per la durata di `'static`, che non finisce mai.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SICUREZZA: L 'prestito statico garantisce che i dati non lo saranno
        // moved/invalidated fino a quando non viene lasciato cadere (che non è mai).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: questo significa che qualsiasi impl di `CoerceUnsized` che consente la coercizione da
// un tipo che implementa `Deref<Target=impl !Unpin>` in un tipo che implementa `Deref<Target=Unpin>` non è valido.
// Tuttavia, qualsiasi impianto di questo tipo non sarebbe corretto per altri motivi, quindi dobbiamo solo fare attenzione a non consentire a tali impianti di atterrare in std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}