//! Iterazione asincrona componibile.
//!
//! Se futures sono valori asincroni, i flussi sono iteratori asincroni.
//! Se ti sei trovato con una raccolta asincrona di qualche tipo e hai bisogno di eseguire un'operazione sugli elementi di detta raccolta, ti imbatterai rapidamente in 'streams'.
//! Gli stream sono ampiamente utilizzati nel codice Rust asincrono idiomatico, quindi vale la pena familiarizzarsi con loro.
//!
//! Prima di spiegare di più, parliamo di come è strutturato questo modulo:
//!
//! # Organization
//!
//! Questo modulo è in gran parte organizzato per tipo:
//!
//! * [Traits] sono la parte fondamentale: questi traits definiscono che tipo di stream esistono e cosa puoi fare con loro.Vale la pena dedicare del tempo extra allo studio sui metodi di questi traits.
//! * Le funzioni forniscono alcuni modi utili per creare alcuni flussi di base.
//! * Le strutture sono spesso i tipi di ritorno dei vari metodi su traits di questo modulo.Di solito vorrai guardare il metodo che crea l `struct`, piuttosto che l `struct` stesso.
//! Per maggiori dettagli sul motivo, vedere "[Implementing Stream](#implementation-stream)".
//!
//! [Traits]: #traits
//!
//! Questo è tutto!Analizziamo i flussi.
//!
//! # Stream
//!
//! Il cuore e l'anima di questo modulo è l [`Stream`] trait.Il nucleo di [`Stream`] si presenta così:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! A differenza di `Iterator`, `Stream` fa una distinzione tra il metodo [`poll_next`] che viene utilizzato quando si implementa un `Stream` e un metodo (to-be-implemented) `next` che viene utilizzato quando si consuma uno stream.
//!
//! I consumatori di `Stream` devono solo considerare `next`, che quando chiamato, restituisce un future che restituisce `Option<Stream::Item>`.
//!
//! future restituito da `next` produrrà `Some(Item)` fintanto che ci sono elementi e, una volta che sono stati tutti esauriti, restituirà `None` per indicare che l'iterazione è terminata.
//! Se stiamo aspettando che qualcosa di asincrono si risolva, future aspetterà fino a quando il flusso non sarà pronto a cedere di nuovo.
//!
//! I singoli flussi possono scegliere di riprendere l'iterazione, quindi chiamare di nuovo `next` potrebbe o non potrebbe alla fine restituire `Some(Item)` di nuovo ad un certo punto.
//!
//! La definizione completa di [`Stream`] include anche una serie di altri metodi, ma sono metodi predefiniti, costruiti sopra [`poll_next`], e quindi li ottieni gratuitamente.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementazione di Stream
//!
//! La creazione di un proprio flusso comporta due passaggi: la creazione di un `struct` per mantenere lo stato del flusso e quindi l'implementazione di [`Stream`] per tale `struct`.
//!
//! Creiamo un flusso chiamato `Counter` che conta da `1` a `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Innanzitutto, la struttura:
//!
//! /// Un flusso che conta da uno a cinque
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vogliamo che il nostro conteggio inizi da uno, quindi aggiungiamo un metodo new() per aiutare.
//! // Questo non è strettamente necessario, ma è conveniente.
//! // Nota che iniziamo `count` da zero, vedremo perché nell'implementazione di `poll_next()`'s di seguito.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Quindi, implementiamo `Stream` per il nostro `Counter`:
//!
//! impl Stream for Counter {
//!     // conteremo con usize
//!     type Item = usize;
//!
//!     // poll_next() è l'unico metodo richiesto
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Aumenta il nostro conteggio.Questo è il motivo per cui siamo partiti da zero.
//!         self.count += 1;
//!
//!         // Controlla se abbiamo finito di contare o meno.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Gli stream sono *pigri*.Ciò significa che la semplice creazione di uno stream non fa molto _do_.Non succede nulla finché non chiami `next`.
//! Questo a volte è fonte di confusione quando si crea un flusso esclusivamente per i suoi effetti collaterali.
//! Il compilatore ci avviserà di questo tipo di comportamento:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;