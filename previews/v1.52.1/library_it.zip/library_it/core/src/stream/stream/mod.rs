use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Un'interfaccia per gestire gli iteratori asincroni.
///
/// Questo è il flusso principale trait.
/// Per ulteriori informazioni sul concetto di stream in generale, vedere [module-level documentation].
/// In particolare, potresti voler sapere come fare [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Il tipo di elementi prodotti dal flusso.
    type Item;

    /// Tenta di estrarre il valore successivo di questo flusso, registrando l'attività corrente per la riattivazione se il valore non è ancora disponibile e restituendo `None` se il flusso è esaurito.
    ///
    /// # Valore di ritorno
    ///
    /// Sono disponibili diversi valori di ritorno possibili, ciascuno dei quali indica uno stato del flusso distinto:
    ///
    /// - `Poll::Pending` significa che il valore successivo di questo flusso non è ancora pronto.Le implementazioni garantiranno che l'attività corrente verrà notificata quando il valore successivo potrebbe essere pronto.
    ///
    /// - `Poll::Ready(Some(val))` significa che il flusso ha prodotto con successo un valore, `val`, e può produrre ulteriori valori nelle successive chiamate `poll_next`.
    ///
    /// - `Poll::Ready(None)` significa che il flusso è terminato e `poll_next` non deve essere richiamato di nuovo.
    ///
    /// # Panics
    ///
    /// Una volta che uno stream è terminato (restituito `Ready(None)` from `poll_next`), chiamare nuovamente il suo metodo `poll_next` può panic, bloccarsi per sempre o causare altri tipi di problemi; l `Stream` trait non pone requisiti sugli effetti di tale chiamata.
    ///
    /// Tuttavia, poiché il metodo `poll_next` non è contrassegnato con `unsafe`, si applicano le normali regole di Rust: le chiamate non devono mai causare un comportamento indefinito (danneggiamento della memoria, uso errato delle funzioni `unsafe` o simili), indipendentemente dallo stato del flusso.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Restituisce i limiti sulla lunghezza rimanente del flusso.
    ///
    /// In particolare, `size_hint()` restituisce una tupla in cui il primo elemento è il limite inferiore e il secondo elemento è il limite superiore.
    ///
    /// La seconda metà della tupla restituita è un [`Option`]`<`[`usize`] `>`.
    /// Un [`None`] qui significa che non esiste un limite superiore noto o che il limite superiore è maggiore di [`usize`].
    ///
    /// # Note di implementazione
    ///
    /// Non viene imposto che un'implementazione del flusso restituisca il numero dichiarato di elementi.Un flusso con bug può produrre meno del limite inferiore o più del limite superiore degli elementi.
    ///
    /// `size_hint()` è concepito principalmente per essere utilizzato per ottimizzazioni come la prenotazione di spazio per gli elementi del flusso, ma non deve essere considerato attendibile, ad esempio, per omettere i controlli dei limiti nel codice non sicuro.
    /// Un'implementazione errata di `size_hint()` non dovrebbe portare a violazioni della sicurezza della memoria.
    ///
    /// Detto questo, l'implementazione dovrebbe fornire una stima corretta, perché altrimenti sarebbe una violazione del protocollo trait.
    ///
    /// L'implementazione predefinita restituisce `(0,` [`None`]`)`che è corretta per qualsiasi flusso.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}