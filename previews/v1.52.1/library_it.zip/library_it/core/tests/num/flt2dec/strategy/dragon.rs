use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri è troppo lenta
fn exact_sanity_test() {
    // Questo test finisce per eseguire quello che posso solo presumere sia un caso d'angolo della funzione di libreria `exp2`, definita in qualsiasi runtime C che stiamo utilizzando.
    // In VS 2013 questa funzione apparentemente aveva un bug in quanto questo test fallisce quando viene collegato, ma con VS 2015 il bug appare risolto poiché il test viene eseguito correttamente.
    //
    // Il bug sembra essere una differenza nel valore di ritorno di `exp2(-1057)`, dove in VS 2013 restituisce un doppio con lo schema di bit 0x2 e in VS 2015 restituisce 0x20000.
    //
    //
    // Per ora ignora completamente questo test su MSVC poiché è comunque testato altrove e non siamo molto interessati a testare l'implementazione exp2 di ciascuna piattaforma.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}