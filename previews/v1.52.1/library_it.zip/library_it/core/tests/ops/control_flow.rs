use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Questa non è un'area di superficie stabile, ma aiuta a mantenere `?` a buon mercato tra di loro, anche se LLVM non può sempre trarne vantaggio in questo momento.
    //
    // (Purtroppo Risultato e Opzione non sono coerenti, quindi ControlFlow non può abbinare entrambi.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}