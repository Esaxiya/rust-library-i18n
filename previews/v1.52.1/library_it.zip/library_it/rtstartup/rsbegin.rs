// rsbegin.o e rsend.o sono i cosiddetti "compiler runtime startup objects".
// Contengono il codice necessario per inizializzare correttamente il runtime del compilatore.
//
// Quando un'immagine eseguibile o dylib è collegata, tutto il codice utente e le librerie sono "sandwiched" tra questi due file oggetto, quindi il codice oi dati di rsbegin.o diventano i primi nelle rispettive sezioni dell'immagine, mentre il codice ei dati di rsend.o diventano gli ultimi.
// Questo effetto può essere utilizzato per posizionare i simboli all'inizio o alla fine di una sezione, nonché per inserire eventuali intestazioni o piè di pagina richiesti.
//
// Si noti che il punto di ingresso effettivo del modulo si trova nell'oggetto di avvio del runtime C (solitamente chiamato `crtX.o`), che quindi richiama i callback di inizializzazione di altri componenti di runtime (registrati tramite un'altra sezione di immagine speciale).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Contrassegna l'inizio della sezione delle informazioni sullo svolgimento dello stack frame
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Spazio gratta e vinci per la contabilità interna dello svolgitore.
    // Questo è definito come `struct object` in $ GCC/unfind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Informazioni sulle routine registration/deregistration.
    // Vedi la documentazione di libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registra le informazioni di svolgimento all'avvio del modulo
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // annullare la registrazione allo spegnimento
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Registrazione di routine init/uninit specifica per MinGW
    pub mod mingw_init {
        // Gli oggetti di avvio di MinGW (crt0.o/dllcrt0.o) richiameranno i costruttori globali nelle sezioni .ctors e .dtors all'avvio e all'uscita.
        // Nel caso delle DLL, ciò avviene quando la DLL viene caricata e scaricata.
        //
        // Il linker ordinerà le sezioni, il che garantisce che i nostri callback si trovino alla fine dell'elenco.
        // Poiché i costruttori vengono eseguiti in ordine inverso, ciò garantisce che i nostri callback siano i primi e gli ultimi eseguiti.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: callback di inizializzazione C.
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: callback di terminazione C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}