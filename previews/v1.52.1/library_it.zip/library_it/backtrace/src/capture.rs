use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Rappresentazione di un backtrace di proprietà e autonomo.
///
/// Questa struttura può essere utilizzata per acquisire un backtrace in vari punti di un programma e successivamente utilizzata per ispezionare quale fosse il backtrace in quel momento.
///
///
/// `Backtrace` supporta la bella stampa di backtrace attraverso la sua implementazione `Debug`.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // I frame qui sono elencati dall'alto verso il basso della pila
    frames: Vec<BacktraceFrame>,
    // L'indice che riteniamo sia l'inizio effettivo del backtrace, omettendo frame come `Backtrace::new` e `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Versione acquisita di un frame in un backtrace.
///
/// Questo tipo viene restituito come un elenco da `Backtrace::frames` e rappresenta uno stack frame in un backtrace acquisito.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Versione acquisita di un simbolo in un backtrace.
///
/// Questo tipo viene restituito come elenco da `BacktraceFrame::symbols` e rappresenta i metadati per un simbolo in un backtrace.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Cattura un backtrace nel callsite di questa funzione, restituendo una rappresentazione di proprietà.
    ///
    /// Questa funzione è utile per rappresentare un backtrace come oggetto in Rust.Questo valore restituito può essere inviato attraverso i thread e stampato altrove, e lo scopo di questo valore è di essere completamente autonomo.
    ///
    /// Si noti che su alcune piattaforme acquisire un backtrace completo e risolverlo può essere estremamente costoso.
    /// Se il costo è troppo alto per la tua applicazione, si consiglia di utilizzare invece `Backtrace::new_unresolved()` che evita il passaggio di risoluzione dei simboli (che in genere richiede il più lungo) e consente di rimandarlo a una data successiva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vuoi assicurarti che qui ci sia una cornice da rimuovere
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Simile a `new` tranne per il fatto che questo non risolve alcun simbolo, cattura semplicemente il backtrace come un elenco di indirizzi.
    ///
    /// In un secondo momento la funzione `resolve` può essere chiamata per risolvere i simboli di questo backtrace in nomi leggibili.
    /// Questa funzione esiste perché il processo di risoluzione a volte può richiedere una notevole quantità di tempo, mentre un qualsiasi backtrace può essere stampato solo raramente.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // nessun nome di simbolo
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // i nomi dei simboli ora sono presenti
    /// ```
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    ///
    #[inline(never)] // vuoi assicurarti che qui ci sia una cornice da rimuovere
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Restituisce i frame da quando è stato acquisito questo backtrace.
    ///
    /// La prima voce di questa sezione è probabilmente la funzione `Backtrace::new` e l'ultimo fotogramma è probabilmente qualcosa su come è iniziato questo thread o la funzione principale.
    ///
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Se questo backtrace è stato creato da `new_unresolved`, questa funzione risolverà tutti gli indirizzi nel backtrace nei loro nomi simbolici.
    ///
    ///
    /// Se questo backtrace è stato precedentemente risolto o è stato creato tramite `new`, questa funzione non fa nulla.
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Come `Frame::ip`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Come `Frame::symbol_address`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Come `Frame::module_base_address`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Restituisce l'elenco di simboli a cui corrisponde questo frame.
    ///
    /// Normalmente c'è un solo simbolo per frame, ma a volte se un numero di funzioni è integrato in un frame, verranno restituiti più simboli.
    /// Il primo simbolo elencato è l "innermost function", mentre l'ultimo simbolo è il più esterno (ultimo chiamante).
    ///
    /// Nota che se questo frame proviene da un backtrace non risolto, questo restituirà un elenco vuoto.
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Come `Symbol::name`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Come `Symbol::addr`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Come `Symbol::filename`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Come `Symbol::lineno`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Come `Symbol::colno`
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Quando stampiamo i percorsi proviamo a rimuovere il cwd se esiste, altrimenti stampiamo semplicemente il percorso così com'è.
        // Nota che lo facciamo anche solo per il formato breve, perché se è pieno presumibilmente vogliamo stampare tutto.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}