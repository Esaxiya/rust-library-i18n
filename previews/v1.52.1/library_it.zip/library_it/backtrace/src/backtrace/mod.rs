use core::ffi::c_void;
use core::fmt;

/// Ispeziona lo stack di chiamate corrente, passando tutti i frame attivi nella chiusura fornita per calcolare una traccia dello stack.
///
/// Questa funzione è il cavallo di battaglia di questa libreria nel calcolo delle tracce dello stack per un programma.La data chiusura `cb` fornisce istanze di un `Frame` che rappresentano le informazioni su quel frame di chiamata sullo stack.
/// La chiusura è resa frame in modo top-down (più recentemente chiamato prima funzioni).
///
/// Il valore di ritorno della chiusura è un'indicazione se il backtrace deve continuare.Un valore di ritorno di `false` terminerà il backtrace e tornerà immediatamente.
///
/// Una volta acquisito un `Frame`, probabilmente vorrai chiamare `backtrace::resolve` per convertire l `ip` (puntatore di istruzioni) o l'indirizzo del simbolo in un `Symbol` attraverso il quale è possibile apprendere il nome e/o il nome del file/numero di riga.
///
///
/// Nota che questa è una funzione di livello relativamente basso e se desideri, ad esempio, acquisire un backtrace da ispezionare in seguito, il tipo `Backtrace` potrebbe essere più appropriato.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
/// # Panics
///
/// Questa funzione si sforza di non avere mai panic, ma se `cb` ha fornito panics, alcune piattaforme forzeranno un doppio panic ad interrompere il processo.
/// Alcune piattaforme utilizzano una libreria C che utilizza internamente callback che non possono essere annullate, quindi il panico da `cb` può attivare l'interruzione del processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // continuare il backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Come `trace`, solo pericoloso in quanto non sincronizzato.
///
/// Questa funzione non ha garanzie di sincronizzazione ma è disponibile quando la funzionalità `std` di questo crate non è compilata.
/// Vedere la funzione `trace` per ulteriore documentazione ed esempi.
///
/// # Panics
///
/// Vedere le informazioni su `trace` per avvertenze su `cb` in preda al panico.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Uno trait che rappresenta un frame di un backtrace, ceduto alla funzione `trace` di questo crate.
///
/// La chiusura della funzione di traccia verrà restituita frame e il frame viene inviato virtualmente poiché l'implementazione sottostante non è sempre nota fino al runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Restituisce il puntatore dell'istruzione corrente di questo frame.
    ///
    /// Questa è normalmente l'istruzione successiva da eseguire nel frame, ma non tutte le implementazioni elencano questo con una precisione del 100% (ma generalmente è abbastanza vicino).
    ///
    ///
    /// Si consiglia di passare questo valore a `backtrace::resolve` per trasformarlo in un nome di simbolo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Restituisce il puntatore allo stack corrente di questo frame.
    ///
    /// Nel caso in cui un backend non possa recuperare il puntatore allo stack per questo frame, viene restituito un puntatore nullo.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Restituisce l'indirizzo del simbolo iniziale del frame di questa funzione.
    ///
    /// Questo tenterà di riavvolgere il puntatore dell'istruzione restituito da `ip` all'inizio della funzione, restituendo quel valore.
    ///
    /// In alcuni casi, tuttavia, i backend restituiranno solo `ip` da questa funzione.
    ///
    /// Il valore restituito a volte può essere utilizzato se `backtrace::resolve` non è riuscito su `ip` sopra indicato.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Restituisce l'indirizzo di base del modulo a cui appartiene il frame.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Questo deve essere il primo, per garantire che Miri abbia la priorità sulla piattaforma host
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // utilizzato solo in dbghelp simbolizza
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}