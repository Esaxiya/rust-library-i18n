use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr accetta un callback che riceverà un puntatore dl_phdr_info per ogni DSO che è stato collegato al processo.
    // dl_iterate_phdr assicura anche che il linker dinamico sia bloccato dall'inizio alla fine dell'iterazione.
    // Se il callback restituisce un valore diverso da zero, l'iterazione viene terminata in anticipo.
    // 'data' verrà passato come terzo argomento alla richiamata su ogni chiamata.
    // 'size' dà la dimensione di dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Abbiamo bisogno di analizzare l'ID build e alcuni dati di intestazione del programma di base, il che significa che abbiamo bisogno anche di un po 'di cose dalle specifiche ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ora dobbiamo replicare, bit per bit, la struttura del tipo dl_phdr_info usata dall'attuale linker dinamico di fuchsia.
// Chromium ha anche questo limite ABI e crashpad.
// Alla fine vorremmo spostare questi casi per utilizzare elf-search, ma avremmo bisogno di fornirlo nell'SDK e ciò non è stato ancora fatto.
//
// Quindi noi (e loro) siamo bloccati a dover usare questo metodo che incorre in uno stretto accoppiamento con la libc fucsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Non abbiamo modo di sapere se e_phoff e e_phnum sono validi.
    // libc dovrebbe garantire questo per noi comunque, quindi è sicuro formare una fetta qui.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr rappresenta un'intestazione del programma ELF a 64 bit nell'endianness dell'architettura di destinazione.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr rappresenta un'intestazione di programma ELF valida e il suo contenuto.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Non abbiamo modo di verificare se p_addr o p_memsz sono validi.
    // La libc di Fuchsia analizza prima le note, quindi in virtù della presenza qui queste intestazioni devono essere valide.
    //
    // NotaIter non richiede che i dati sottostanti siano validi ma richiede che i limiti siano validi.
    // Confidiamo che libc abbia assicurato che questo sia il nostro caso qui.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Il tipo di nota per gli ID build.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr rappresenta un'intestazione di una nota ELF nell'endianness del target.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota rappresenta una nota ELF (intestazione + contenuto).
// Il nome viene lasciato come slice u8 perché non è sempre terminato da null e rust rende abbastanza facile controllare che i byte corrispondano in entrambi i casi.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ti consente di iterare in modo sicuro su un segmento di nota.
// Termina non appena si verifica un errore o non ci sono più note.
// Se iterate su dati non validi, funzionerà come se non fossero state trovate note.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // È una funzione invariante che il puntatore e la dimensione data denotino un intervallo valido di byte che possono essere letti tutti.
    // Il contenuto di questi byte può essere qualsiasi cosa ma l'intervallo deve essere valido affinché ciò sia sicuro.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to allinea 'x' all'allineamento 'to' byte assumendo che 'to' sia una potenza di 2.
// Questo segue un modello standard nel codice di analisi ELF C/C ++ in cui viene utilizzato (x + to, 1) e -to.
// Rust non ti permette di negare l'uso quindi io uso
// Conversione in complemento di 2 per ricrearlo.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 consuma num byte dalla slice (se presente) e garantisce inoltre che la slice finale sia allineata correttamente.
// Se il numero di byte richiesti è troppo grande o la slice non può essere riallineata in seguito a causa di un numero insufficiente di byte rimanenti, viene restituito None e la slice non viene modificata.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Questa funzione non ha invarianti reali che il chiamante deve sostenere a parte forse che 'bytes' dovrebbe essere allineato per le prestazioni (e per la correttezza di alcune architetture).
// I valori nei campi Elf_Nhdr potrebbero non avere senso, ma questa funzione non garantisce nulla del genere.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Questo è sicuro fintanto che c'è abbastanza spazio e lo abbiamo appena confermato nell'istruzione if sopra, quindi questo non dovrebbe essere pericoloso.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Nota che sice_of: :<Elf_Nhdr>() è sempre allineato a 4 byte.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Controlla se siamo arrivati alla fine.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Trasmutiamo un nhdr ma consideriamo attentamente la struttura risultante.
        // Non ci fidiamo di namesz o descsz e non prendiamo decisioni pericolose in base al tipo.
        //
        // Quindi, anche se tiriamo fuori la spazzatura completa, dovremmo comunque essere al sicuro.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Indica che un segmento è eseguibile.
const PERM_X: u32 = 0b00000001;
/// Indica che un segmento è scrivibile.
const PERM_W: u32 = 0b00000010;
/// Indica che un segmento è leggibile.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Rappresenta un segmento ELF in fase di esecuzione.
struct Segment {
    /// Fornisce l'indirizzo virtuale di runtime dei contenuti di questo segmento.
    addr: usize,
    /// Fornisce la dimensione della memoria del contenuto di questo segmento.
    size: usize,
    /// Fornisce l'indirizzo virtuale del modulo di questo segmento con il file ELF.
    mod_rel_addr: usize,
    /// Fornisce le autorizzazioni trovate nel file ELF.
    /// Tuttavia, queste autorizzazioni non sono necessariamente le autorizzazioni presenti in fase di esecuzione.
    flags: Perm,
}

/// Consente di iterare sui segmenti da un DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Rappresenta un ELF DSO (Dynamic Shared Object).
/// Questo tipo fa riferimento ai dati archiviati nel DSO effettivo anziché crearne una propria copia.
struct Dso<'a> {
    /// Il linker dinamico ci fornisce sempre un nome, anche se il nome è vuoto.
    /// Nel caso dell'eseguibile principale questo nome sarà vuoto.
    /// Nel caso di un oggetto condiviso sarà il soname (vedi DT_SONAME).
    name: &'a str,
    /// Su Fuchsia praticamente tutti i binari hanno ID build, ma questo non è un requisito rigoroso.
    /// Non c'è modo di abbinare le informazioni DSO con un vero file ELF in seguito se non c'è build_id, quindi è necessario che ogni DSO ne abbia uno qui.
    ///
    /// I DSO senza build_id vengono ignorati.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Restituisce un iteratore sui segmenti in questo DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Questi errori codificano i problemi che si verificano durante l'analisi delle informazioni su ogni DSO.
///
enum Error {
    /// NameError significa che si è verificato un errore durante la conversione di una stringa di stile C in una stringa rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError significa che non abbiamo trovato un ID build.
    /// Ciò potrebbe essere dovuto al fatto che il DSO non aveva un ID build o perché il segmento contenente l'ID build non era corretto.
    ///
    BuildIDError,
}

/// Chiama 'dso' o 'error' per ogni DSO collegato al processo dal linker dinamico.
///
///
/// # Arguments
///
/// * `visitor` - Un DsoPrinter che avrà uno dei metodi eats chiamati foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr garantisce che info.name punterà a una posizione valida.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Questa funzione stampa il markup del simbolizzatore Fuchsia per tutte le informazioni contenute in un DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}