//! Un modulo per assistere nella gestione dei collegamenti dbghelp su Windows
//!
//! I backtrace su Windows (almeno per MSVC) sono ampiamente alimentati da `dbghelp.dll` e dalle varie funzioni che contiene.
//! Queste funzioni sono attualmente caricate *dinamicamente* anziché collegarsi a `dbghelp.dll` staticamente.
//! Questo è attualmente fatto dalla libreria standard (ed è in teoria richiesto lì), ma è uno sforzo per aiutare a ridurre le dipendenze dll statiche di una libreria poiché i backtrace sono in genere piuttosto opzionali.
//!
//! Detto questo, `dbghelp.dll` si carica quasi sempre con successo su Windows.
//!
//! Nota però che poiché stiamo caricando tutto questo supporto dinamicamente, non possiamo effettivamente usare le definizioni grezze in `winapi`, ma piuttosto dobbiamo definire noi stessi i tipi di puntatore a funzione e usarli.
//! Non vogliamo davvero essere nel business della duplicazione di winapi, quindi abbiamo una funzione Cargo `verify-winapi` che afferma che tutti i binding corrispondono a quelli in winapi e questa funzione è abilitata su CI.
//!
//! Infine, noterai qui che la dll per `dbghelp.dll` non viene mai scaricata, e questo è attualmente intenzionale.
//! Il pensiero è che possiamo memorizzarlo globalmente nella cache e usarlo tra le chiamate all'API, evitando il costoso loads/unloads.
//! Se questo è un problema per i rilevatori di perdite o qualcosa del genere, possiamo attraversare il ponte quando arriviamo lì.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Aggira `SymGetOptions` e `SymSetOptions` non presenti in winapi stesso.
// Altrimenti questo viene utilizzato solo quando controlliamo due volte i tipi contro winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Non ancora definito in winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Questo è definito in winapi, ma non è corretto (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Non ancora definito in winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Questa macro viene utilizzata per definire una struttura `Dbghelp` che contiene internamente tutti i puntatori a funzione che potremmo caricare.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// La DLL caricata per `dbghelp.dll`
            dll: HMODULE,

            // Ogni puntatore a funzione per ogni funzione che potremmo usare
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inizialmente non abbiamo caricato la DLL
            dll: 0 as *mut _,
            // Inizialmente tutte le funzioni sono impostate a zero per indicare che devono essere caricate dinamicamente.
            //
            $($name: 0,)*
        };

        // Tipo di convenienza per ogni tipo di funzione.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tenta di aprire `dbghelp.dll`.
            /// Restituisce successo se funziona o errore se `LoadLibraryW` fallisce.
            ///
            /// Panics se la libreria è già caricata.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funzione per ogni metodo che vorremmo usare.
            // Quando viene chiamato, leggerà il puntatore della funzione memorizzato nella cache o lo caricherà e restituirà il valore caricato.
            // Si afferma che i carichi abbiano successo.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Proxy pratico per utilizzare i blocchi di pulizia per fare riferimento alle funzioni di dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inizializza tutto il supporto necessario per accedere alle funzioni API `dbghelp` da questo crate.
///
///
/// Notare che questa funzione è **sicura**, ha internamente la propria sincronizzazione.
/// Si noti inoltre che è sicuro chiamare questa funzione più volte in modo ricorsivo.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // La prima cosa che dobbiamo fare è sincronizzare questa funzione.Questo può essere chiamato contemporaneamente da altri thread o in modo ricorsivo all'interno di un thread.
        // Nota che è più complicato di così perché quello che stiamo usando qui, `dbghelp`,*anche* deve essere sincronizzato con tutti gli altri chiamanti a `dbghelp` in questo processo.
        //
        // In genere non ci sono davvero così tante chiamate a `dbghelp` all'interno dello stesso processo e probabilmente possiamo tranquillamente presumere che siamo gli unici ad accedervi.
        // C'è, tuttavia, un altro utente principale di cui dobbiamo preoccuparci, che ironicamente è noi stessi, ma nella libreria standard.
        // La libreria standard Rust dipende da questo crate per il supporto del backtrace e questo crate esiste anche su crates.io.
        // Ciò significa che se la libreria standard sta stampando un backtrace panic, potrebbe correre con questo crate proveniente da crates.io, causando segfaults.
        //
        // Per aiutare a risolvere questo problema di sincronizzazione, utilizziamo qui un trucco specifico per Windows (dopotutto si tratta di una restrizione specifica di Windows sulla sincronizzazione).
        // Creiamo un *session-local* chiamato mutex per proteggere questa chiamata.
        // L'intenzione qui è che la libreria standard e questo crate non devono condividere le API di livello Rust per sincronizzarsi qui, ma possono invece lavorare dietro le quinte per assicurarsi che si sincronizzino tra loro.
        //
        // In questo modo quando questa funzione viene chiamata tramite la libreria standard o tramite crates.io possiamo essere sicuri che lo stesso mutex viene acquisito.
        //
        // Quindi tutto questo per dire che la prima cosa che facciamo qui è creare atomicamente un `HANDLE` che è un mutex denominato su Windows.
        // Sincronizziamo un po 'con altri thread che condividono questa funzione in modo specifico e assicuriamo che venga creato un solo handle per istanza di questa funzione.
        // Notare che l'handle non viene mai chiuso una volta memorizzato nel file global.
        //
        // Dopo aver effettivamente attivato il blocco, lo acquisiamo semplicemente e la nostra maniglia `Init` che distribuiamo sarà responsabile della sua caduta alla fine.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Ora che siamo tutti sincronizzati in modo sicuro, iniziamo effettivamente a elaborare tutto.
        // Per prima cosa dobbiamo assicurarci che `dbghelp.dll` sia effettivamente caricato in questo processo.
        // Lo facciamo dinamicamente per evitare una dipendenza statica.
        // Questo è stato storicamente fatto per aggirare strani problemi di collegamento ed è inteso a rendere i binari un po 'più portabili poiché si tratta in gran parte solo di un'utilità di debug.
        //
        //
        // Una volta aperto `dbghelp.dll`, dobbiamo richiamare alcune funzioni di inizializzazione al suo interno, e questo è dettagliato più avanti.
        // Tuttavia, lo facciamo solo una volta, quindi abbiamo un valore booleano globale che indica se abbiamo ancora finito o meno.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Assicurati che il flag `SYMOPT_DEFERRED_LOADS` sia impostato, perché secondo i documenti di MSVC su questo: "This is the fastest, most efficient way to use the symbol handler.", quindi facciamolo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Inizializza effettivamente i simboli con MSVC.Nota che questo può fallire, ma lo ignoriamo.
        // Non c'è un sacco di arte precedente per questo di per sé, ma LLVM sembra ignorare internamente il valore di ritorno qui e una delle librerie di disinfettanti in LLVM stampa un avviso spaventoso se questo fallisce, ma fondamentalmente lo ignora a lungo termine.
        //
        //
        // Un caso in cui questo viene fuori molto per Rust è che la libreria standard e questo crate su crates.io vogliono entrambi competere per `SymInitializeW`.
        // La libreria standard storicamente voleva inizializzare e poi ripulire la maggior parte del tempo, ma ora che sta usando questo crate significa che qualcuno arriverà prima all'inizializzazione e l'altro raccoglierà quell'inizializzazione.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}