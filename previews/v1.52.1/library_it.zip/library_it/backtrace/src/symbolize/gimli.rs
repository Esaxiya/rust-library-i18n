//! Supporto per la simbolizzazione utilizzando `gimli` crate su crates.io
//!
//! Questa è l'implementazione della simbolizzazione predefinita per Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'la durata statica è una bugia da hackerare per la mancanza di supporto per strutture autoreferenziali.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Converti in vite statiche poiché i simboli dovrebbero prendere in prestito solo `map` e `stash` e li conserviamo di seguito.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Per caricare le librerie native su Windows, vedere alcune discussioni su rust-lang/rust#71060 per le varie strategie qui.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Le librerie MinGW attualmente non supportano ASLR (rust-lang/rust#16514), ma le DLL possono ancora essere riposizionate nello spazio degli indirizzi.
            // Sembra che gli indirizzi nelle informazioni di debug siano tutti come se questa libreria fosse stata caricata nel suo "image base", che è un campo nelle intestazioni dei file COFF.
            // Poiché questo è ciò che debuginfo sembra elencare, analizziamo la tabella dei simboli e memorizziamo gli indirizzi come se anche la libreria fosse caricata su "image base".
            //
            // Tuttavia, la libreria potrebbe non essere caricata su "image base".
            // (presumibilmente potrebbe essere caricato qualcos'altro lì?) È qui che entra in gioco il campo `bias`, e qui dobbiamo calcolare il valore di `bias`.Purtroppo però non è chiaro come ottenerlo da un modulo caricato.
            // Quello che abbiamo, tuttavia, è l'effettivo indirizzo di carico (`modBaseAddr`).
            //
            // Come una sorta di scappatoia per ora, mmapmo il file, leggiamo le informazioni di intestazione del file, quindi rilasciamo mmap.Questo è uno spreco perché probabilmente riapriremo il mmap più tardi, ma per ora dovrebbe funzionare abbastanza bene.
            //
            // Una volta che abbiamo `image_base` (posizione di caricamento desiderata) e `base_addr` (posizione di caricamento effettiva), possiamo compilare `bias` (differenza tra l'effettivo e desiderato) e quindi l'indirizzo dichiarato di ogni segmento è l `image_base` poiché è quello che dice il file.
            //
            //
            // Per ora sembra che a differenza di ELF/MachO possiamo accontentarci di un segmento per libreria, utilizzando `modBaseSize` come dimensione intera.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS utilizza il formato di file Mach-O e utilizza API specifiche di DYLD per caricare un elenco di librerie native che fanno parte dell'applicazione.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Recupera anche il nome di questa libreria che corrisponde al percorso in cui caricarla.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Carica l'intestazione dell'immagine di questa libreria e delega a `object` per analizzare tutti i comandi di caricamento in modo da poter capire tutti i segmenti coinvolti qui.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Scorri i segmenti e registra le regioni conosciute per i segmenti che troviamo.
            // Inoltre, registra le informazioni sui segmenti di testo per elaborarli in un secondo momento, vedere i commenti di seguito.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Determina l "slide" per questa libreria che finisce per essere il bias che usiamo per capire dove vengono caricati gli oggetti in memoria.
            // Questo è un calcolo un po 'strano però ed è il risultato di provare alcune cose in natura e vedere cosa si attacca.
            //
            // L'idea generale è che l `bias` più l `stated_virtual_memory_address` di un segmento sarà dove nello spazio degli indirizzi effettivo risiede il segmento.
            // L'altra cosa su cui facciamo affidamento è che un indirizzo reale meno l `bias` è l'indice da cercare nella tabella dei simboli e in debuginfo.
            //
            // Risulta, tuttavia, che per le librerie caricate dal sistema questi calcoli non sono corretti.Per gli eseguibili nativi, tuttavia, sembra corretto.
            // Sollevando un po 'di logica dalla sorgente di LLDB, ha alcuni caratteri speciali per la prima sezione `__TEXT` caricata dal file offset 0 con una dimensione diversa da zero.
            // Per qualsiasi motivo, quando è presente, sembra che la tabella dei simboli sia relativa solo alla diapositiva vmaddr per la libreria.
            // Se *non* è presente, la tabella dei simboli è relativa alla diapositiva vmaddr più l'indirizzo dichiarato del segmento.
            //
            // Per gestire questa situazione, se *non* troviamo una sezione di testo con offset del file zero, aumentiamo il bias in base all'indirizzo dichiarato della prima sezione di testo e diminuiamo anche tutti gli indirizzi dichiarati di tale importo.
            //
            // In questo modo la tabella dei simboli appare sempre relativa all'importo di bias della libreria.
            // Questo sembra avere i risultati giusti per la simbolizzazione tramite la tabella dei simboli.
            //
            // Onestamente non sono del tutto sicuro se sia giusto o se c'è qualcos'altro che dovrebbe indicare come farlo.
            // Per ora però questo sembra funzionare abbastanza bene (?) e dovremmo sempre essere in grado di modificarlo nel tempo, se necessario.
            //
            // Per ulteriori informazioni vedere #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Altro Unix (es
        // Le piattaforme Linux) utilizzano ELF come formato di file oggetto e in genere implementano un'API chiamata `dl_iterate_phdr` per caricare le librerie native.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` dovrebbe essere un puntatore valido.
        // `vec` dovrebbe essere un puntatore valido a un `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 non supporta nativamente le informazioni di debug, ma il sistema di compilazione inserirà le informazioni di debug nel percorso `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Tutto il resto dovrebbe usare ELF, ma non sa come caricare le librerie native.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Tutte le librerie condivise conosciute che sono state caricate.
    libraries: Vec<Library>,

    /// Cache delle mappature in cui conserviamo le informazioni sui nani analizzate.
    ///
    /// Questo elenco ha una capacità fissa per tutto il suo tempo di sollevamento che non aumenta mai.
    /// L'elemento `usize` di ogni coppia è un indice in `libraries` sopra dove `usize::max_value()` rappresenta l'eseguibile corrente.
    ///
    /// L `Mapping` corrisponde alle informazioni nane analizzate corrispondenti.
    ///
    /// Nota che questa è fondamentalmente una cache LRU e sposteremo le cose qui mentre simboleggiamo gli indirizzi.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenti di questa libreria caricati in memoria e dove vengono caricati.
    segments: Vec<LibrarySegment>,
    /// L "bias" di questa libreria, in genere dove viene caricato in memoria.
    /// Questo valore viene aggiunto all'indirizzo dichiarato di ogni segmento per ottenere l'indirizzo di memoria virtuale effettivo in cui viene caricato il segmento.
    /// Inoltre, questo bias viene sottratto dagli indirizzi di memoria virtuale reale per indicizzarli in debuginfo e nella tabella dei simboli.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// L'indirizzo dichiarato di questo segmento nel file oggetto.
    /// Questo non è effettivamente il punto in cui viene caricato il segmento, ma piuttosto questo indirizzo più l `bias` della libreria che lo contiene è dove trovarlo.
    ///
    stated_virtual_memory_address: usize,
    /// La dimensione di questo segmento in memoria.
    len: usize,
}

// non sicuro perché deve essere sincronizzato esternamente
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // non sicuro perché deve essere sincronizzato esternamente
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Una cache LRU molto piccola e molto semplice per la mappatura delle informazioni di debug.
        //
        // Il tasso di successo dovrebbe essere molto alto, poiché lo stack tipico non si incrocia tra molte librerie condivise.
        //
        // Le strutture `addr2line::Context` sono piuttosto costose da creare.
        // Ci si aspetta che il suo costo venga ammortizzato dalle successive query `locate`, che sfruttano le strutture costruite durante la costruzione di `addr2line: : Context`s per ottenere buone velocità.
        //
        // Se non avessimo questa cache, quell'ammortamento non sarebbe mai accaduto e la simbolizzazione dei backtrace sarebbe ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Per prima cosa, verifica se questo `lib` ha un segmento contenente `addr` (gestione del riposizionamento).Se questo controllo viene superato, possiamo continuare di seguito e tradurre effettivamente l'indirizzo.
                //
                // Nota che qui stiamo usando `wrapping_add` per evitare controlli di overflow.È stato visto in natura che il calcolo del bias SVMA + trabocca.
                // Sembra un po 'strano che possa accadere, ma non c'è molto che possiamo fare al riguardo se non ignorare semplicemente quei segmenti poiché probabilmente puntano nello spazio.
                //
                // Questo è originariamente apparso in rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Ora che sappiamo che `lib` contiene `addr`, possiamo compensare con il bias per trovare l'indirizzo di memoria virutale dichiarato.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariante: dopo che questo condizionale viene completato senza ritorno anticipato
        // da un errore, la voce della cache per questo percorso è all'indice 0.

        if let Some(idx) = idx {
            // Quando la mappatura è già nella cache, spostala in primo piano.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Quando la mappatura non è nella cache, creare una nuova mappatura, inserirla nella parte anteriore della cache ed eliminare la voce della cache meno recente, se necessario.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // non perdere la durata di `'static`, assicurati che sia limitato a noi stessi
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Estendi la durata di `sym` a `'static` poiché purtroppo siamo obbligati a farlo qui, ma è sempre uscito come riferimento, quindi nessun riferimento ad esso dovrebbe essere persistito oltre questo frame comunque.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Infine, ottieni una mappatura memorizzata nella cache o crea una nuova mappatura per questo file e valuta le informazioni DWARF per trovare l file/line/name per questo indirizzo.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Siamo stati in grado di individuare le informazioni sul frame per questo simbolo, e il frame di `addr2line` ha internamente tutti i dettagli nitidi.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Impossibile trovare le informazioni di debug, ma le abbiamo trovate nella tabella dei simboli dell'eseguibile elf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}