use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Risolvi un indirizzo in un simbolo, passando il simbolo alla chiusura specificata.
///
/// Questa funzione cercherà l'indirizzo specificato in aree come la tabella dei simboli locale, la tabella dei simboli dinamici o le informazioni di debug DWARF (a seconda dell'implementazione attivata) per trovare i simboli da produrre.
///
///
/// La chiusura potrebbe non essere chiamata se non è stato possibile eseguire la risoluzione, e potrebbe anche essere chiamata più di una volta nel caso di funzioni inline.
///
/// I simboli restituiti rappresentano l'esecuzione all `addr` specificato, restituendo le coppie file/line per quell'indirizzo (se disponibile).
///
/// Nota che se hai un `Frame`, ti consigliamo di usare la funzione `resolve_frame` invece di questa.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
/// # Panics
///
/// Questa funzione si sforza di non avere mai panic, ma se `cb` ha fornito panics, alcune piattaforme forzeranno un doppio panic ad interrompere il processo.
/// Alcune piattaforme utilizzano una libreria C che utilizza internamente callback che non possono essere annullate, quindi il panico da `cb` può attivare l'interruzione del processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // guarda solo il telaio superiore
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Risolvi un fotogramma acquisito in precedenza in un simbolo, passando il simbolo alla chiusura specificata.
///
/// Questa funzione svolge la stessa funzione di `resolve` tranne per il fatto che accetta un `Frame` come argomento invece di un indirizzo.
/// Ciò può consentire ad alcune implementazioni di backtracing della piattaforma di fornire informazioni sui simboli più accurate o informazioni sui frame in linea, ad esempio.
///
/// Si consiglia di utilizzarlo se possibile.
///
/// # Funzionalità richieste
///
/// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
///
/// # Panics
///
/// Questa funzione si sforza di non avere mai panic, ma se `cb` ha fornito panics, alcune piattaforme forzeranno un doppio panic ad interrompere il processo.
/// Alcune piattaforme utilizzano una libreria C che utilizza internamente callback che non possono essere annullate, quindi il panico da `cb` può attivare l'interruzione del processo.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // guarda solo il telaio superiore
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// I valori IP degli stack frame sono in genere (always?) l'istruzione *dopo* la chiamata che è l'effettiva traccia dello stack.
// Simboleggiarlo fa sì che il numero filename/line sia uno avanti e forse nel vuoto se è vicino alla fine della funzione.
//
// Questo sembra essere fondamentalmente sempre il caso su tutte le piattaforme, quindi ne sottraiamo sempre uno da un ip risolto per risolverlo nell'istruzione di chiamata precedente invece dell'istruzione a cui viene restituita.
//
//
// Idealmente non lo faremmo.
// Idealmente dovremmo richiedere ai chiamanti delle API `resolve` qui di eseguire manualmente l -1 e dichiarare che desiderano informazioni sulla posizione per l'istruzione *precedente*, non per quella corrente.
// Idealmente, esporremmo anche su `Frame` se siamo effettivamente l'indirizzo dell'istruzione successiva o quella corrente.
//
// Per ora però questa è una preoccupazione piuttosto di nicchia, quindi internamente ne sottraiamo sempre una.
// I consumatori dovrebbero continuare a lavorare e ottenere risultati piuttosto buoni, quindi dovremmo essere abbastanza bravi.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Come `resolve`, solo pericoloso in quanto non sincronizzato.
///
/// Questa funzione non ha garanzie di sincronizzazione ma è disponibile quando la funzionalità `std` di questo crate non è compilata.
/// Vedere la funzione `resolve` per ulteriore documentazione ed esempi.
///
/// # Panics
///
/// Vedere le informazioni su `resolve` per avvertenze su `cb` in preda al panico.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Come `resolve_frame`, solo pericoloso in quanto non sincronizzato.
///
/// Questa funzione non ha garanzie di sincronizzazione ma è disponibile quando la funzionalità `std` di questo crate non è compilata.
/// Vedere la funzione `resolve_frame` per ulteriore documentazione ed esempi.
///
/// # Panics
///
/// Vedere le informazioni su `resolve_frame` per avvertenze su `cb` in preda al panico.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Un trait che rappresenta la risoluzione di un simbolo in un file.
///
/// Questo trait viene ceduto come oggetto trait alla chiusura data alla funzione `backtrace::resolve`, ed è virtualmente inviato poiché non è noto quale implementazione ci sia dietro.
///
///
/// Un simbolo può fornire informazioni contestuali su una funzione, ad esempio il nome, il nome del file, il numero di riga, l'indirizzo preciso, ecc.
/// Tuttavia, non tutte le informazioni sono sempre disponibili in un simbolo, quindi tutti i metodi restituiscono un `Option`.
///
///
pub struct Symbol {
    // TODO: questo limite di durata deve essere mantenuto alla fine su `Symbol`,
    // ma questo è attualmente un cambiamento radicale.
    // Per ora questo è sicuro poiché `Symbol` viene distribuito solo per riferimento e non può essere clonato.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Restituisce il nome di questa funzione.
    ///
    /// La struttura restituita può essere utilizzata per interrogare varie proprietà sul nome del simbolo:
    ///
    ///
    /// * L'implementazione `Display` stamperà il simbolo demangled.
    /// * È possibile accedere al valore `str` grezzo del simbolo (se è utf-8 valido).
    /// * È possibile accedere ai byte grezzi per il nome del simbolo.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Restituisce l'indirizzo iniziale di questa funzione.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Restituisce il nome del file non elaborato come slice.
    /// Ciò è utile principalmente per gli ambienti `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Restituisce il numero di colonna per la posizione in cui questo simbolo è attualmente in esecuzione.
    ///
    /// Solo gimli attualmente fornisce un valore qui e anche in questo caso solo se `filename` restituisce `Some`, e quindi è quindi soggetto a caveat simili.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Restituisce il numero di riga per la posizione in cui questo simbolo è attualmente in esecuzione.
    ///
    /// Questo valore di ritorno è tipicamente `Some` se `filename` restituisce `Some`, ed è di conseguenza soggetto a simili avvertenze.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Restituisce il nome del file in cui è stata definita questa funzione.
    ///
    /// Attualmente è disponibile solo quando si utilizza libbacktrace o gimli (ad es
    /// unix piattaforme altro) e quando un binario viene compilato con debuginfo.
    /// Se nessuna di queste condizioni viene soddisfatta, è probabile che venga restituito `None`.
    ///
    /// # Funzionalità richieste
    ///
    /// Questa funzione richiede che la funzione `std` di `backtrace` crate sia abilitata e la funzione `std` è abilitata per impostazione predefinita.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Forse un simbolo C++ analizzato, se l'analisi del simbolo alterato come Rust non è riuscita.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Assicurati di mantenere questa dimensione zero, in modo che la funzione `cpp_demangle` non abbia alcun costo quando disabilitata.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Un wrapper attorno al nome di un simbolo per fornire funzioni di accesso ergonomiche al nome demangled, ai byte grezzi, alla stringa grezza, ecc.
///
// Consenti codice morto per quando la funzione `cpp_demangle` non è abilitata.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Crea un nuovo nome di simbolo dai byte sottostanti non elaborati.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Restituisce il nome del simbolo (mangled) grezzo come `str` se il simbolo è utf-8 valido.
    ///
    /// Usa l'implementazione `Display` se vuoi la versione demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Restituisce il nome del simbolo grezzo come un elenco di byte
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Questo può essere stampato se il simbolo demangled non è effettivamente valido, quindi gestisci l'errore qui con garbo non propagandolo all'esterno.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Tentare di recuperare la memoria cache utilizzata per simbolizzare gli indirizzi.
///
/// Questo metodo tenterà di rilasciare tutte le strutture di dati globali che sono state altrimenti memorizzate nella cache a livello globale o nel thread che in genere rappresentano informazioni DWARF analizzate o simili.
///
///
/// # Caveats
///
/// Sebbene questa funzione sia sempre disponibile, in realtà non fa nulla sulla maggior parte delle implementazioni.
/// Librerie come dbghelp o libbacktrace non forniscono servizi per deallocare lo stato e gestire la memoria allocata.
/// Per ora la funzione `gimli-symbolize` di questo crate è l'unica caratteristica in cui questa funzione ha qualche effetto.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}