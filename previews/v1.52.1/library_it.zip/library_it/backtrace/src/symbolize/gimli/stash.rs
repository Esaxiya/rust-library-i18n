// utilizzato solo su Linux in questo momento, quindi consenti il codice morto altrove
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Un semplice allocatore di arena per buffer di byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alloca un buffer della dimensione specificata e restituisce un riferimento modificabile ad esso.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SICUREZZA: questa è l'unica funzione che costruisce mai un mutabile
        // riferimento a `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SICUREZZA: non rimuoviamo mai elementi da `self.buffers`, quindi un riferimento
        // ai dati all'interno di qualsiasi buffer vivrà finché `self` fa.
        &mut buffers[i]
    }
}