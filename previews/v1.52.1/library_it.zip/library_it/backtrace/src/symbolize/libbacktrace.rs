//! Strategia di simbolizzazione utilizzando il codice di analisi DWARF in libbacktrace.
//!
//! La libreria libbacktrace C, tipicamente distribuita con gcc, supporta non solo la generazione di un backtrace (che in realtà non usiamo) ma anche la simbolizzazione del backtrace e la gestione delle informazioni di debug dei nani su cose come i frame inline e quant'altro.
//!
//!
//! Questo è relativamente complicato a causa di molte varie preoccupazioni qui, ma l'idea di base è:
//!
//! * Per prima cosa chiamiamo `backtrace_syminfo`.Questo ottiene le informazioni sui simboli dalla tabella dei simboli dinamici, se possibile.
//! * Successivamente chiamiamo `backtrace_pcinfo`.Questo analizzerà le tabelle debuginfo se sono disponibili e ci consentirà di recuperare informazioni su frame inline, nomi di file, numeri di riga, ecc.
//!
//! Ci sono molti trucchi per inserire le tabelle nane in libbacktrace, ma si spera che non sia la fine del mondo ed è abbastanza chiaro leggendo di seguito.
//!
//! Questa è la strategia di simbolizzazione predefinita per piattaforme non MSVC e non OSX.In libstd però questa è la strategia predefinita per OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Se possibile, preferisci il nome `function` che proviene da debuginfo e può essere tipicamente più accurato per i frame in linea, ad esempio.
                // Se non è presente, torna al nome della tabella dei simboli specificato in `symname`.
                //
                // Si noti che a volte `function` può sembrare un po 'meno preciso, ad esempio essendo elencato come `try<i32,closure>` non è più `std::panicking::try::do_call`.
                //
                // Non è proprio chiaro il motivo, ma nel complesso il nome `function` sembra più accurato.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // non fare niente per ora
}

/// Tipo di puntatore `data` passato a `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Una volta che questo callback viene richiamato da `backtrace_syminfo`, quando iniziamo a risolvere andiamo oltre a chiamare `backtrace_pcinfo`.
    // La funzione `backtrace_pcinfo` consulterà le informazioni di debug e tenterà di fare cose come recuperare le informazioni file/line così come i frame inline.
    // Nota però che `backtrace_pcinfo` può fallire o non fare molto se non ci sono informazioni di debug, quindi se ciò accade siamo sicuri di chiamare il callback con almeno un simbolo da `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tipo di puntatore `data` passato a `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// L'API libbacktrace supporta la creazione di uno stato, ma non supporta la distruzione di uno stato.
// Personalmente ritengo che questo significhi che uno stato deve essere creato e quindi vivere per sempre.
//
// Mi piacerebbe registrare un gestore at_exit() che ripulisca questo stato, ma libbacktrace non fornisce alcun modo per farlo.
//
// Con questi vincoli, questa funzione ha uno stato memorizzato nella cache staticamente che viene calcolato la prima volta che viene richiesto.
//
// Ricorda che il backtracing avviene tutto in serie (un blocco globale).
//
// Notare che la mancanza di sincronizzazione qui è dovuta al requisito che `resolve` sia sincronizzato esternamente.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Non esercitare le capacità threadsafe di libbacktrace poiché lo chiamiamo sempre in modo sincronizzato.
        //
        0,
        error_cb,
        ptr::null_mut(), // nessun dato aggiuntivo
    );

    return STATE;

    // Si noti che per far funzionare libbacktrace è necessario trovare le informazioni di debug DWARF per l'eseguibile corrente.In genere lo fa tramite una serie di meccanismi inclusi, ma non limitati a:
    //
    // * /proc/self/exe sulle piattaforme supportate
    // * Il nome del file passato esplicitamente durante la creazione dello stato
    //
    // La libreria libbacktrace è un grande batuffolo di codice C.Ciò significa naturalmente che ha vulnerabilità di sicurezza della memoria, specialmente quando si gestiscono informazioni di debug non corrette.
    // Libstd si è imbattuto in molti di questi storicamente.
    //
    // Se viene utilizzato /proc/self/exe, in genere possiamo ignorarli poiché presumiamo che libbacktrace sia "mostly correct" e altrimenti non fa cose strane con le informazioni di debug nano di "attempted to be correct".
    //
    //
    // Se passiamo un nome di file, tuttavia, è possibile su alcune piattaforme (come BSD) in cui un attore malintenzionato può causare l'inserimento di un file arbitrario in quella posizione.
    // Ciò significa che se comunichiamo a libbacktrace un nome di file, potrebbe essere utilizzato un file arbitrario, che potrebbe causare segfaults.
    // Se non diciamo nulla a libbacktrace, non farà nulla su piattaforme che non supportano percorsi come /proc/self/exe!
    //
    // Dato tutto ciò, ci sforziamo il più possibile di *non* passare un nome di file, ma dobbiamo farlo su piattaforme che non supportano affatto /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Nota che idealmente dovremmo usare `std::env::current_exe`, ma non possiamo richiedere `std` qui.
            //
            // Usa `_NSGetExecutablePath` per caricare il percorso eseguibile corrente in un'area statica (che se è troppo piccola rinuncia).
            //
            //
            // Nota che qui ci fidiamo seriamente di libbacktrace per non morire con eseguibili corrotti, ma sicuramente lo fa ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ha una modalità di apertura dei file in cui dopo l'apertura non può essere eliminata.
            // Questo è in generale ciò che vogliamo qui perché vogliamo assicurarci che il nostro eseguibile non cambi da sotto di noi dopo averlo consegnato a libbacktrace, sperando di mitigare la capacità di passare dati arbitrari a libbacktrace (che potrebbe essere mal gestito).
            //
            //
            // Dato che qui facciamo un po 'di danza per tentare di ottenere una sorta di blocco sulla nostra immagine:
            //
            // * Ottieni un handle per il processo corrente, carica il suo nome file.
            // * Apri un file con quel nome file con i flag giusti.
            // * Ricarica il nome del file del processo corrente, assicurandoti che sia lo stesso
            //
            // Se tutto questo va a buon fine, in teoria abbiamo effettivamente aperto il file del nostro processo e ci viene garantito che non cambierà.FWIW un sacco di questo è stato copiato da libstd storicamente, quindi questa è la mia migliore interpretazione di ciò che stava accadendo.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Questo vive nella memoria statica, quindi possiamo restituirlo ..
                static mut BUF: [i8; N] = [0; N];
                // ... e questo vive in pila poiché è temporaneo
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // intenzionalmente trapelare `handle` qui perché avere quell'apertura dovrebbe preservare il nostro blocco su questo nome di file.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vogliamo restituire una sezione che è terminata con valore nul, quindi se tutto è stato riempito ed è uguale alla lunghezza totale, allora lo identifichiamo a fallimento.
                //
                //
                // Altrimenti, quando si restituisce successo, assicurarsi che il byte nul sia incluso nella slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // gli errori di backtrace sono attualmente nascosti
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Chiama l'API `backtrace_syminfo` che (dalla lettura del codice) dovrebbe chiamare `syminfo_cb` esattamente una volta (o fallire presumibilmente con un errore).
    // Quindi ne gestiamo di più all'interno dell `syminfo_cb`.
    //
    // Nota che lo facciamo poiché `syminfo` consulterà la tabella dei simboli, trovando i nomi dei simboli anche se non ci sono informazioni di debug nel binario.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}