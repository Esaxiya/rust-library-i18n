# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Una libreria per l'acquisizione di backtrace in fase di esecuzione per Rust.
Questa libreria mira a migliorare il supporto della libreria standard fornendo un'interfaccia programmatica con cui lavorare, ma supporta anche la semplice stampa del backtrace corrente come panics di libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Per acquisire semplicemente un backtrace e rimandare la sua gestione a un momento successivo, è possibile utilizzare il tipo `Backtrace` di primo livello.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Se, tuttavia, desideri un accesso più grezzo alla funzionalità di traccia effettiva, puoi utilizzare direttamente le funzioni `trace` e `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Risolvi questo puntatore di istruzioni a un nome di simbolo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // vai al fotogramma successivo
    });
}
```

# License

Questo progetto è concesso in licenza con uno dei due

 * Licenza Apache, versione 2.0, ([LICENSE-APACHE](LICENSE-APACHE) o http://www.apache.org/licenses/LICENSE-2.0)
 * Licenza MIT ([LICENSE-MIT](LICENSE-MIT) o http://opensource.org/licenses/MIT)

a tua scelta.

### Contribution

A meno che tu non dichiari esplicitamente diversamente, qualsiasi contributo inviato intenzionalmente per l'inclusione in backtrace-rs da te, come definito nella licenza Apache-2.0, sarà concesso in doppia licenza come sopra, senza termini o condizioni aggiuntivi.







