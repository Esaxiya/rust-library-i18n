//! Utilità per la formattazione e la stampa di `String`s.
//!
//! Questo modulo contiene il supporto runtime per l'estensione della sintassi [`format!`].
//! Questa macro è implementata nel compilatore per emettere chiamate a questo modulo al fine di formattare gli argomenti in fase di esecuzione in stringhe.
//!
//! # Usage
//!
//! La macro [`format!`] deve essere familiare a coloro che provengono dalle funzioni `printf`/`fprintf` di C o dalla funzione `str.format` di Python.
//!
//! Alcuni esempi dell'estensione [`format!`] sono:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" con zeri iniziali
//! ```
//!
//! Da questi, puoi vedere che il primo argomento è una stringa di formato.È richiesto dal compilatore affinché questo sia un letterale stringa;non può essere una variabile passata (per eseguire il controllo di validità).
//! Il compilatore analizzerà quindi la stringa di formato e determinerà se l'elenco di argomenti fornito è adatto per il passaggio a questa stringa di formato.
//!
//! Per convertire un singolo valore in una stringa, utilizzare il metodo [`to_string`].Questo userà la formattazione [`Display`] trait.
//!
//! ## Parametri posizionali
//!
//! Ogni argomento di formattazione può specificare a quale argomento valore fa riferimento e, se omesso, si presume che sia "the next argument".
//! Ad esempio, la stringa di formato `{} {} {}` richiederebbe tre parametri e verrebbero formattati nello stesso ordine in cui sono stati forniti.
//! La stringa di formato `{2} {1} {0}`, tuttavia, formatterà gli argomenti in ordine inverso.
//!
//! Le cose possono diventare un po 'complicate una volta che inizi a mescolare i due tipi di specificatori di posizione.Lo specificatore "next argument" può essere pensato come un iteratore sull'argomento.
//! Ogni volta che viene visualizzato un identificatore "next argument", l'iteratore avanza.Questo porta a comportamenti come questo:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! L'iteratore interno sull'argomento non è stato avanzato nel momento in cui viene visualizzato il primo `{}`, quindi stampa il primo argomento.Quindi, una volta raggiunto il secondo `{}`, l'iteratore è avanzato al secondo argomento.
//! Essenzialmente, i parametri che nominano esplicitamente il loro argomento non influenzano i parametri che non nominano un argomento in termini di specificatori posizionali.
//!
//! È necessaria una stringa di formato per utilizzare tutti i suoi argomenti, altrimenti è un errore in fase di compilazione.Puoi fare riferimento allo stesso argomento più di una volta nella stringa di formato.
//!
//! ## Parametri denominati
//!
//! Rust stesso non ha un equivalente simile a Python dei parametri denominati per una funzione, ma la macro [`format!`] è un'estensione della sintassi che le consente di sfruttare i parametri denominati.
//! I parametri denominati sono elencati alla fine dell'elenco degli argomenti e hanno la sintassi:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Ad esempio, le seguenti espressioni [`format!`] utilizzano tutte l'argomento denominato:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Non è valido inserire parametri posizionali (quelli senza nome) dopo argomenti che hanno nomi.Come con i parametri posizionali, non è valido fornire parametri denominati non utilizzati dalla stringa di formato.
//!
//! # Parametri di formattazione
//!
//! Ogni argomento in fase di formattazione può essere trasformato da un numero di parametri di formattazione (corrispondenti a `format_spec` in [the syntax](#syntax)). Questi parametri influenzano la rappresentazione di stringa di ciò che viene formattato.
//!
//! ## Width
//!
//! ```
//! // Tutti questi stampano "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Questo è un parametro per l "minimum width" che il formato dovrebbe assumere.
//! Se la stringa del valore non riempie questo numero di caratteri, verrà utilizzato il riempimento specificato da fill/alignment per occupare lo spazio richiesto (vedere di seguito).
//!
//! Il valore per la larghezza può anche essere fornito come [`usize`] nell'elenco dei parametri aggiungendo un suffisso `$`, che indica che il secondo argomento è un [`usize`] che specifica la larghezza.
//!
//! Fare riferimento a un argomento con la sintassi del dollaro non influisce sul contatore "next argument", quindi di solito è una buona idea fare riferimento agli argomenti in base alla posizione o utilizzare argomenti con nome.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Il carattere di riempimento opzionale e l'allineamento vengono forniti normalmente insieme al parametro [`width`](#width).Deve essere definito prima di `width`, subito dopo `:`.
//! Ciò indica che se il valore da formattare è inferiore a `width`, verranno stampati alcuni caratteri aggiuntivi attorno ad esso.
//! Il riempimento è disponibile nelle seguenti varianti per diversi allineamenti:
//!
//! * `[fill]<` - l'argomento è allineato a sinistra nelle colonne `width`
//! * `[fill]^` - l'argomento è allineato al centro nelle colonne `width`
//! * `[fill]>` - l'argomento è allineato a destra nelle colonne `width`
//!
//! Il valore predefinito [fill/alignment](#fillalignment) per i non numerici è uno spazio e allineato a sinistra.L'impostazione predefinita per i formattatori numerici è anche un carattere spazio ma con allineamento a destra.
//! Se il flag `0` (vedere di seguito) è specificato per i valori numerici, il carattere di riempimento implicito è `0`.
//!
//! Notare che l'allineamento potrebbe non essere implementato da alcuni tipi.In particolare, non è generalmente implementato per `Debug` trait.
//! Un buon modo per assicurarsi che il riempimento sia applicato è formattare l'input, quindi riempire questa stringa risultante per ottenere l'output:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Ciao Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Questi sono tutti flag che alterano il comportamento del formattatore.
//!
//! * `+` - È inteso per i tipi numerici e indica che il segno deve essere sempre stampato.I segni positivi non vengono mai stampati per impostazione predefinita e il segno negativo viene stampato solo per impostazione predefinita per `Signed` trait.
//! Questo flag indica che deve essere sempre stampato il segno corretto (`+` o `-`).
//! * `-` - Attualmente non utilizzato
//! * `#` - Questo flag indica che deve essere utilizzato il formato di stampa "alternate".Le forme alternative sono:
//!     * `#?` - stampa abbastanza la formattazione [`Debug`]
//!     * `#x` - precede l'argomento con un `0x`
//!     * `#X` - precede l'argomento con un `0x`
//!     * `#b` - precede l'argomento con un `0b`
//!     * `#o` - precede l'argomento con un `0o`
//! * `0` - Questo è usato per indicare per i formati interi che il riempimento a `width` dovrebbe essere sia fatto con un carattere `0` che essere in grado di riconoscere il segno.
//! Un formato come `{:08}` restituirebbe `00000001` per l'intero `1`, mentre lo stesso formato restituirebbe `-0000001` per l'intero `-1`.
//! Si noti che la versione negativa ha uno zero in meno rispetto alla versione positiva.
//!         Nota che gli zeri di riempimento vengono sempre inseriti dopo il segno (se presente) e prima delle cifre.Quando viene utilizzato insieme al flag `#`, si applica una regola simile: gli zeri di riempimento vengono inseriti dopo il prefisso ma prima delle cifre.
//!         Il prefisso è compreso nella larghezza totale.
//!
//! ## Precision
//!
//! Per i tipi non numerici, questo può essere considerato un "maximum width".
//! Se la stringa risultante è più lunga di questa larghezza, viene troncata a questo numero di caratteri e quel valore troncato viene emesso con `fill`, `alignment` e `width` appropriati se tali parametri sono impostati.
//!
//! Per i tipi integrali, questo viene ignorato.
//!
//! Per i tipi a virgola mobile, indica quante cifre devono essere stampate dopo il punto decimale.
//!
//! Esistono tre modi possibili per specificare l `precision` desiderato:
//!
//! 1. Un numero intero `.N`:
//!
//!    il numero intero `N` stesso è la precisione.
//!
//! 2. Un numero intero o un nome seguito dal simbolo del dollaro `.N$`:
//!
//!    usa il formato *argomento*`N` (che deve essere un `usize`) come precisione.
//!
//! 3. Un asterisco `.*`:
//!
//!    `.*` significa che questo `{...}` è associato a *due* input di formato anziché uno: il primo input contiene la precisione `usize` e il secondo contiene il valore da stampare.
//!    Si noti che in questo caso, se si utilizza la stringa di formato `{<arg>:<spec>.*}`, la parte `<arg>` si riferisce al* valore * da stampare e `precision` deve essere nell'input che precede `<arg>`.
//!
//! Ad esempio, le seguenti chiamate stampano tutte la stessa cosa `Hello x is 0.01000`:
//!
//! ```
//! // Ciao {arg 0 ("x")} è {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Ciao {arg 1 ("x")} è {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Ciao {arg 0 ("x")} è {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Ciao {next arg ("x")} è {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Ciao {next arg ("x")} è {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Ciao {next arg ("x")} è {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mentre questi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! stampare tre cose significativamente diverse:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! In alcuni linguaggi di programmazione, il comportamento delle funzioni di formattazione delle stringhe dipende dalle impostazioni locali del sistema operativo.
//! Le funzioni di formattazione fornite dalla libreria standard di Rust non hanno alcun concetto di locale e produrranno gli stessi risultati su tutti i sistemi indipendentemente dalla configurazione dell'utente.
//!
//! Ad esempio, il codice seguente stamperà sempre `1.5` anche se le impostazioni internazionali del sistema utilizzano un separatore decimale diverso da un punto.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! I caratteri letterali `{` e `}` possono essere inclusi in una stringa facendoli precedere con lo stesso carattere.Ad esempio, il carattere `{` è sottoposto a escape con `{{` e al carattere `}` con `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Per riassumere, qui puoi trovare la grammatica completa delle stringhe di formato.
//! La sintassi per il linguaggio di formattazione utilizzato è tratta da altre lingue, quindi non dovrebbe essere troppo estranea.Gli argomenti sono formattati con la sintassi simile a Python, il che significa che gli argomenti sono circondati da `{}` invece che da `%` tipo C.
//! La grammatica effettiva per la sintassi di formattazione è:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Nella grammatica precedente, `text` non può contenere caratteri `'{'` o `'}'`.
//!
//! # Formattazione traits
//!
//! Quando si richiede che un argomento sia formattato con un tipo particolare, in realtà si richiede che un argomento venga attribuito a un particolare trait.
//! Ciò consente di formattare più tipi effettivi tramite `{:x}` (come [`i8`] e [`isize`]).L'attuale mappatura dei tipi su traits è:
//!
//! * *niente* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] con interi esadecimali minuscoli
//! * `X?` ⇒ [`Debug`] con interi esadecimali maiuscoli
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Ciò significa che qualsiasi tipo di argomento che implementa [`fmt::Binary`][`Binary`] trait può quindi essere formattato con `{:b}`.Le implementazioni sono fornite per questi traits anche per un numero di tipi primitivi dalla libreria standard.
//!
//! Se non viene specificato alcun formato (come in `{}` o `{:6}`), il formato trait utilizzato è [`Display`] trait.
//!
//! Quando si implementa un formato trait per il proprio tipo, sarà necessario implementare un metodo di firma:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // il nostro tipo personalizzato
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Il tuo tipo verrà passato come riferimento `self`, quindi la funzione dovrebbe emettere un output nel flusso `f.buf`.Spetta a ciascuna implementazione del formato trait aderire correttamente ai parametri di formattazione richiesti.
//! I valori di questi parametri verranno elencati nei campi della struttura [`Formatter`].Per aiutare in questo, la struttura [`Formatter`] fornisce anche alcuni metodi di supporto.
//!
//! Inoltre, il valore di ritorno di questa funzione è [`fmt::Result`] che è un alias di tipo di [`Result`]`<(),`[`std: : fmt::Error`] `>`.
//! Le implementazioni di formattazione dovrebbero garantire che propagano errori da [`Formatter`] (ad esempio, quando si chiama [`write!`]).
//! Tuttavia, non dovrebbero mai restituire errori falsamente.
//! Cioè, un'implementazione di formattazione deve e può restituire un errore solo se l [`Formatter`] passato restituisce un errore.
//! Questo perché, contrariamente a quanto potrebbe suggerire la firma della funzione, la formattazione della stringa è un'operazione infallibile.
//! Questa funzione restituisce solo un risultato perché la scrittura nel flusso sottostante potrebbe non riuscire e deve fornire un modo per propagare il fatto che si è verificato un errore di backup nello stack.
//!
//! Un esempio di implementazione della formattazione traits sarebbe simile a:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Il valore `f` implementa `Write` trait, che è ciò che scrive!la macro è in attesa.
//!         // Notare che questa formattazione ignora i vari flag forniti per formattare le stringhe.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Diversi traits consentono diverse forme di output di un tipo.
//! // Il significato di questo formato è stampare la grandezza di un vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Rispetta i flag di formattazione utilizzando il metodo di supporto `pad_integral` sull'oggetto Formatter.
//!         // Vedere la documentazione del metodo per i dettagli e la funzione `pad` può essere utilizzata per riempire le stringhe.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` contro `fmt::Debug`
//!
//! Questi due traits di formattazione hanno scopi distinti:
//!
//! - [`fmt::Display`][`Display`] le implementazioni affermano che il tipo può essere rappresentato fedelmente come una stringa UTF-8 in ogni momento.**Non** è previsto che tutti i tipi implementino [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] le implementazioni dovrebbero essere implementate per **tutti** i tipi pubblici.
//!   L'output rappresenterà in genere lo stato interno nel modo più fedele possibile.
//!   Lo scopo di [`Debug`] trait è facilitare il debug del codice Rust.Nella maggior parte dei casi, l'utilizzo di `#[derive(Debug)]` è sufficiente e consigliato.
//!
//! Alcuni esempi dell'output di entrambi traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Macro correlate
//!
//! Esistono numerose macro correlate nella famiglia [`format!`].Quelli attualmente implementati sono:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Questo e [`writeln!`] sono due macro che vengono utilizzate per emettere la stringa di formato in un flusso specificato.Viene utilizzato per evitare allocazioni intermedie di stringhe di formato e invece scrivere direttamente l'output.
//! Sotto il cofano, questa funzione sta effettivamente invocando la funzione [`write_fmt`] definita su [`std::io::Write`] trait.
//! L'utilizzo di esempio è:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Questo e [`println!`] emettono il loro output su stdout.Analogamente alla macro [`write!`], l'obiettivo di queste macro è evitare allocazioni intermedie durante la stampa dell'output.L'utilizzo di esempio è:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Le macro [`eprint!`] e [`eprintln!`] sono identiche rispettivamente a [`print!`] e [`println!`], tranne per il fatto che emettono il loro output su stderr.
//!
//! ### `format_args!`
//!
//! Questa è una curiosa macro usata per passare in sicurezza un oggetto opaco che descrive la stringa di formato.Questo oggetto non richiede alcuna allocazione di heap per la creazione e fa riferimento solo alle informazioni sullo stack.
//! Sotto il cofano, tutte le macro correlate sono implementate in termini di questo.
//! Prima di tutto, alcuni esempi di utilizzo sono:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Il risultato della macro [`format_args!`] è un valore di tipo [`fmt::Arguments`].
//! Questa struttura può quindi essere passata alle funzioni [`write`] e [`format`] all'interno di questo modulo per elaborare la stringa di formato.
//! L'obiettivo di questa macro è impedire ulteriormente le allocazioni intermedie quando si tratta di stringhe di formattazione.
//!
//! Ad esempio, una libreria di registrazione potrebbe utilizzare la sintassi di formattazione standard, ma passerebbe internamente a questa struttura fino a quando non sarà stato determinato dove dovrebbe andare l'output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// La funzione `format` accetta una struttura [`Arguments`] e restituisce la stringa formattata risultante.
///
///
/// L'istanza [`Arguments`] può essere creata con la macro [`format_args!`].
///
/// # Examples
///
/// Utilizzo di base:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Tieni presente che potrebbe essere preferibile utilizzare [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}