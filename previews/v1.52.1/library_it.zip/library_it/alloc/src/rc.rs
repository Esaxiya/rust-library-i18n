//! Puntatori per il conteggio dei riferimenti a thread singolo.'Rc' sta per 'Reference
//! Counted'.
//!
//! Il tipo [`Rc<T>`][`Rc`] fornisce la proprietà condivisa di un valore di tipo `T`, allocato nell'heap.
//! Invocare [`clone`][clone] su [`Rc`] produce un nuovo puntatore alla stessa allocazione nell'heap.
//! Quando l'ultimo puntatore [`Rc`] a una determinata allocazione viene distrutto, viene eliminato anche il valore memorizzato in tale allocazione (spesso indicato come "inner value").
//!
//! I riferimenti condivisi in Rust non consentono la mutazione per impostazione predefinita e [`Rc`] non fa eccezione: generalmente non è possibile ottenere un riferimento modificabile a qualcosa all'interno di un [`Rc`].
//! Se hai bisogno di mutabilità, metti un [`Cell`] o [`RefCell`] all'interno dell [`Rc`];vedi [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] utilizza un conteggio dei riferimenti non atomico.
//! Ciò significa che l'overhead è molto basso, ma un [`Rc`] non può essere inviato tra i thread e di conseguenza [`Rc`] non implementa [`Send`][send].
//! Di conseguenza, il compilatore Rust controllerà *in fase di compilazione* che non stai inviando [`Rc`] tra i thread.
//! Se hai bisogno di un conteggio dei riferimenti atomico multi-thread, usa [`sync::Arc`][arc].
//!
//! Il metodo [`downgrade`][downgrade] può essere utilizzato per creare un puntatore [`Weak`] non proprietario.
//! Un puntatore [`Weak`] può essere [`upgrade`][upgrade] d a un [`Rc`], ma questo restituirà [`None`] se il valore memorizzato nell'allocazione è già stato eliminato.
//! In altre parole, i puntatori `Weak` non mantengono vivo il valore all'interno dell'allocazione;tuttavia,*mantengono* viva l'allocazione (l'archivio di supporto per il valore interno).
//!
//! Un ciclo tra i puntatori [`Rc`] non verrà mai deallocato.
//! Per questo motivo, [`Weak`] viene utilizzato per interrompere i cicli.
//! Ad esempio, un albero potrebbe avere puntatori [`Rc`] potenti dai nodi padre ai figli e puntatori [`Weak`] dai figli ai loro genitori.
//!
//! `Rc<T>` dereferenzia automaticamente a `T` (tramite [`Deref`] trait), quindi puoi chiamare i metodi di `T` su un valore di tipo [`Rc<T>`][`Rc`].
//! Per evitare conflitti di nome con i metodi di `T`, i metodi di [`Rc<T>`][`Rc`] stesso sono funzioni associate, chiamate utilizzando [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Le implementazioni di traits come `Clone` possono anche essere chiamate utilizzando una sintassi completamente qualificata.
//! Alcune persone preferiscono utilizzare una sintassi completamente qualificata, mentre altre preferiscono utilizzare la sintassi della chiamata al metodo.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintassi della chiamata al metodo
//! let rc2 = rc.clone();
//! // Sintassi completamente qualificata
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] non esegue la dereferenziazione automatica a `T`, perché il valore interno potrebbe essere già stato eliminato.
//!
//! # Riferimenti di clonazione
//!
//! La creazione di un nuovo riferimento alla stessa allocazione di un puntatore conteggio di riferimento esistente viene eseguita utilizzando `Clone` trait implementato per [`Rc<T>`][`Rc`] e [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Le due sintassi seguenti sono equivalenti.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // aeb puntano entrambi alla stessa posizione di memoria di pippo.
//! ```
//!
//! La sintassi `Rc::clone(&from)` è la più idiomatica perché trasmette in modo più esplicito il significato del codice.
//! Nell'esempio sopra, questa sintassi rende più facile vedere che questo codice sta creando un nuovo riferimento piuttosto che copiare l'intero contenuto di foo.
//!
//! # Examples
//!
//! Considera uno scenario in cui un set di `Gadget` è di proprietà di un dato `Owner`.
//! Vogliamo che i nostri gadget puntino sul loro `Owner`.Non possiamo farlo con una proprietà unica, perché più di un gadget può appartenere allo stesso `Owner`.
//! [`Rc`] ci permette di condividere un `Owner` tra più `Gadget` e di mantenere l `Owner` allocato fintanto che qualsiasi `Gadget` lo punta.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... altri campi
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altri campi
//! }
//!
//! fn main() {
//!     // Crea un `Owner` con conteggio dei riferimenti.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Crea "Gadget" appartenenti a `gadget_owner`.
//!     // La clonazione dell `Rc<Owner>` ci fornisce un nuovo puntatore alla stessa allocazione `Owner`, incrementando il conteggio dei riferimenti nel processo.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Smaltire la nostra variabile locale `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Nonostante l'abbandono di `gadget_owner`, siamo ancora in grado di stampare il nome dell `Owner` di `Gadget`s.
//!     // Questo perché abbiamo rilasciato solo un singolo `Rc<Owner>`, non l `Owner` a cui punta.
//!     // Finché ci sono altri `Rc<Owner>` che puntano alla stessa allocazione `Owner`, rimarrà attivo.
//!     // La proiezione di campo `gadget1.owner.name` funziona perché `Rc<Owner>` dereferisce automaticamente a `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Alla fine della funzione, `gadget1` e `gadget2` vengono distrutti, e con essi gli ultimi riferimenti contati al nostro `Owner`.
//!     // Anche Gadget Man ora viene distrutto.
//!     //
//! }
//! ```
//!
//! Se i nostri requisiti cambiano e dobbiamo anche essere in grado di passare da `Owner` a `Gadget`, incorreremo in problemi.
//! Un puntatore [`Rc`] da `Owner` a `Gadget` introduce un ciclo.
//! Ciò significa che i loro conteggi di riferimento non possono mai raggiungere 0 e l'allocazione non verrà mai distrutta:
//! una perdita di memoria.Per aggirare questo problema, possiamo usare i puntatori [`Weak`].
//!
//! Rust rende effettivamente un po 'difficile produrre questo loop in primo luogo.Per ottenere due valori che puntano l'uno verso l'altro, uno di loro deve essere mutevole.
//! Questo è difficile perché [`Rc`] impone la sicurezza della memoria fornendo solo riferimenti condivisi al valore che racchiude e questi non consentono la mutazione diretta.
//! Dobbiamo racchiudere la parte del valore che desideriamo mutare in un [`RefCell`], che fornisce *mutabilità interna*: un metodo per ottenere la mutabilità attraverso un riferimento condiviso.
//! [`RefCell`] applica le regole di prestito di Rust in fase di esecuzione.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... altri campi
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... altri campi
//! }
//!
//! fn main() {
//!     // Crea un `Owner` con conteggio dei riferimenti.
//!     // Nota che abbiamo inserito lo vector del `Proprietario` di`Gadget` all'interno di un `RefCell` in modo da poterlo mutare tramite un riferimento condiviso.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Crea "Gadget" appartenenti a `gadget_owner`, come prima.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Aggiungi il gadget al loro `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` il prestito dinamico finisce qui.
//!     }
//!
//!     // Ripeti i nostri `Gadget`, stampandone i dettagli.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` è un `Weak<Gadget>`.
//!         // Poiché i puntatori `Weak` non possono garantire che l'allocazione esista ancora, dobbiamo chiamare `upgrade`, che restituisce un `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // In questo caso sappiamo che l'allocazione esiste ancora, quindi semplicemente `unwrap` l `Option`.
//!         // In un programma più complicato, potresti aver bisogno di un'elegante gestione degli errori per un risultato `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Alla fine della funzione, `gadget_owner`, `gadget1` e `gadget2` vengono distrutti.
//!     // Ora non ci sono forti puntatori (`Rc`) ai gadget, quindi vengono distrutti.
//!     // Questo azzera il conteggio dei riferimenti su Gadget Man, quindi viene distrutto anche lui.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Questo è repr(C) a future a prova di possibile riordino sul campo, che interferirebbe con [into|from]_raw() altrimenti sicuro di tipi interni trasmutabili.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Puntatore per il conteggio dei riferimenti a thread singolo.'Rc' sta per 'Reference
/// Counted'.
///
/// Vedere [module-level documentation](./index.html) per maggiori dettagli.
///
/// I metodi intrinseci di `Rc` sono tutte funzioni associate, il che significa che devi chiamarli come, ad esempio, [`Rc::get_mut(&mut value)`][get_mut] invece di `value.get_mut()`.
/// Ciò evita conflitti con metodi del tipo interno `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Questa insicurezza va bene perché mentre questo Rc è attivo, ci viene garantito che il puntatore interno è valido.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Costruisce un nuovo `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // C'è un puntatore debole implicito di proprietà di tutti i puntatori forti, che assicura che il distruttore debole non liberi mai l'allocazione mentre il distruttore forte è in esecuzione, anche se il puntatore debole è memorizzato all'interno di quello forte.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Costruisce un nuovo `Rc<T>` utilizzando un riferimento debole a se stesso.
    /// Il tentativo di aggiornare il riferimento debole prima che questa funzione ritorni risulterà in un valore `None`.
    ///
    /// Tuttavia, il riferimento debole può essere clonato liberamente e archiviato per essere utilizzato in un secondo momento.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... più campi
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Costruisci l'interno nello stato "uninitialized" con un singolo riferimento debole.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // È importante non rinunciare alla proprietà del puntatore debole, altrimenti la memoria potrebbe essere liberata nel momento in cui `data_fn` ritorna.
        // Se volessimo davvero passare la proprietà, potremmo creare un ulteriore puntatore debole per noi stessi, ma ciò comporterebbe aggiornamenti aggiuntivi al conteggio dei riferimenti deboli che potrebbero non essere necessari altrimenti.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // I riferimenti forti dovrebbero possedere collettivamente un riferimento debole condiviso, quindi non eseguire il distruttore per il nostro vecchio riferimento debole.
        //
        mem::forget(weak);
        strong
    }

    /// Costruisce un nuovo `Rc` con contenuti non inizializzati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Costruisce un nuovo `Rc` con contenuti non inizializzati, con la memoria riempita con byte `0`.
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Costruisce un nuovo `Rc<T>`, restituendo un errore se l'allocazione fallisce
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // C'è un puntatore debole implicito di proprietà di tutti i puntatori forti, che assicura che il distruttore debole non liberi mai l'allocazione mentre il distruttore forte è in esecuzione, anche se il puntatore debole è memorizzato all'interno di quello forte.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Costruisce un nuovo `Rc` con contenuti non inizializzati, restituendo un errore se l'allocazione fallisce
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Costruisce un nuovo `Rc` con contenuti non inizializzati, con la memoria riempita con byte `0`, restituendo un errore se l'allocazione fallisce
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Costruisce un nuovo `Pin<Rc<T>>`.
    /// Se `T` non implementa `Unpin`, `value` verrà bloccato in memoria e non potrà essere spostato.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Restituisce il valore interno, se `Rc` ha esattamente un riferimento forte.
    ///
    /// In caso contrario, viene restituito un [`Err`] con lo stesso `Rc` passato.
    ///
    ///
    /// Ciò riuscirà anche se ci sono riferimenti deboli in sospeso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // copia l'oggetto contenuto

                // Indica ai deboli che non possono essere promossi diminuendo il conteggio forte, quindi rimuovi il puntatore "strong weak" implicito mentre gestisci anche la logica di rilascio semplicemente creando un falso debole.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Costruisce una nuova porzione con conteggio dei riferimenti con contenuti non inizializzati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializzazione differita:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Costruisce una nuova fetta con conteggio dei riferimenti con contenuti non inizializzati, con la memoria riempita con `0` byte.
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Converte in `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Come con [`MaybeUninit::assume_init`], spetta al chiamante garantire che il valore interno sia realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento immediato non definito.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Converte in `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Come con [`MaybeUninit::assume_init`], spetta al chiamante garantire che il valore interno sia realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento immediato non definito.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializzazione differita:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Consuma `Rc`, restituendo il puntatore avvolto.
    ///
    /// Per evitare una perdita di memoria, il puntatore deve essere riconvertito in un `Rc` utilizzando [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornisce un puntatore non elaborato ai dati.
    ///
    /// I conteggi non vengono influenzati in alcun modo e l `Rc` non viene consumato.
    /// Il puntatore è valido fintanto che ci sono conteggi forti nell `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SICUREZZA: questo non può passare attraverso Deref::deref o Rc::inner perché
        // questo è necessario per mantenere la provenienza raw/mut in modo tale che ad es
        // `get_mut` può scrivere tramite il puntatore dopo che Rc è stato ripristinato tramite `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Costruisce un `Rc<T>` da un puntatore grezzo.
    ///
    /// Il puntatore non elaborato deve essere stato precedentemente restituito da una chiamata a [`Rc<U>::into_raw`][into_raw], dove `U` deve avere la stessa dimensione e allineamento di `T`.
    /// Questo è banalmente vero se `U` è `T`.
    /// Nota che se `U` non è `T` ma ha la stessa dimensione e allineamento, questo è fondamentalmente come trasmettere riferimenti di diversi tipi.
    /// Vedere [`mem::transmute`][transmute] per ulteriori informazioni su quali limitazioni si applicano in questo caso.
    ///
    /// L'utente di `from_raw` deve assicurarsi che un valore specifico di `T` venga eliminato solo una volta.
    ///
    /// Questa funzione non è sicura perché un uso improprio può portare alla sicurezza della memoria, anche se non si accede mai all `Rc<T>` restituito.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converti di nuovo in un `Rc` per evitare perdite.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ulteriori chiamate a `Rc::from_raw(x_ptr)` non sarebbero sicure per la memoria.
    /// }
    ///
    /// // La memoria è stata liberata quando `x` è uscito dall'ambito di cui sopra, quindi `x_ptr` ora penzola!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Invertire l'offset per trovare l'RcBox originale.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Crea un nuovo puntatore [`Weak`] a questa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Assicurati di non creare un debole penzolante
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Ottiene il numero di puntatori [`Weak`] a questa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Ottiene il numero di puntatori (`Rc`) efficaci a questa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Restituisce `true` se non sono presenti altri puntatori `Rc` o [`Weak`] a questa allocazione.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Restituisce un riferimento modificabile nel dato `Rc`, se non ci sono altri puntatori `Rc` o [`Weak`] alla stessa allocazione.
    ///
    ///
    /// In caso contrario, restituisce [`None`], poiché non è sicuro modificare un valore condiviso.
    ///
    /// Vedi anche [`make_mut`][make_mut], che [`clone`][clone] sarà il valore interno quando ci sono altri puntatori.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Restituisce un riferimento modificabile nel dato `Rc`, senza alcun controllo.
    ///
    /// Vedi anche [`get_mut`], che è sicuro e fa i controlli appropriati.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Qualsiasi altro puntatore `Rc` o [`Weak`] alla stessa allocazione non deve essere dereferenziato per la durata del prestito restituito.
    ///
    /// Questo è banalmente il caso se non esistono tali puntatori, ad esempio immediatamente dopo `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Stiamo attenti a *non* creare un riferimento che copra i campi "count", poiché ciò entrerebbe in conflitto con gli accessi ai conteggi dei riferimenti (ad es.
        // di `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Restituisce `true` se i due `Rc` puntano alla stessa allocazione (in una vena simile a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Crea un riferimento mutabile nel dato `Rc`.
    ///
    /// Se sono presenti altri puntatori `Rc` alla stessa allocazione, `make_mut` assegnerà a [`clone`] il valore interno a una nuova allocazione per garantire una proprietà univoca.
    /// Questo è anche indicato come clone-on-write.
    ///
    /// Se non sono presenti altri puntatori `Rc` a questa allocazione, i puntatori [`Weak`] a questa allocazione verranno dissociati.
    ///
    /// Vedi anche [`get_mut`], che fallirà invece di clonare.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Non clonerà nulla
    /// let mut other_data = Rc::clone(&data);    // Non clonerà i dati interni
    /// *Rc::make_mut(&mut data) += 1;        // Clona i dati interni
    /// *Rc::make_mut(&mut data) += 1;        // Non clonerà nulla
    /// *Rc::make_mut(&mut other_data) *= 2;  // Non clonerà nulla
    ///
    /// // Ora `data` e `other_data` puntano a diverse allocazioni.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] i puntatori verranno dissociati:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Devo clonare i dati, ci sono altri Rcs.
            // Pre-allocare la memoria per consentire la scrittura diretta del valore clonato.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Posso solo rubare i dati, tutto ciò che resta è Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Rimuovi ref forte-debole implicito (non è necessario creare un falso debole qui-sappiamo che altri deboli possono ripulire per noi)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Questa insicurezza va bene perché siamo garantiti che il puntatore restituito è il *solo* puntatore che verrà mai restituito a T.
        // Il nostro conteggio dei riferimenti è garantito essere 1 a questo punto e abbiamo richiesto che lo stesso `Rc<T>` fosse `mut`, quindi restituiamo l'unico riferimento possibile all'allocazione.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Tenta di abbattere l `Rc<dyn Any>` su un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alloca un `RcBox<T>` con spazio sufficiente per un valore interno possibilmente non dimensionato in cui il valore ha il layout fornito.
    ///
    /// La funzione `mem_to_rcbox` viene chiamata con il puntatore ai dati e deve restituire un puntatore (potenzialmente fat) per `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Calcola il layout utilizzando il layout del valore specificato.
        // In precedenza, il layout veniva calcolato sull'espressione `&*(ptr as* const RcBox<T>)`, ma ciò creava un riferimento disallineato (vedere #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alloca un `RcBox<T>` con spazio sufficiente per un valore interno possibilmente non dimensionato in cui il valore ha il layout fornito, restituendo un errore se l'allocazione fallisce.
    ///
    ///
    /// La funzione `mem_to_rcbox` viene chiamata con il puntatore ai dati e deve restituire un puntatore (potenzialmente fat) per `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Calcola il layout utilizzando il layout del valore specificato.
        // In precedenza, il layout veniva calcolato sull'espressione `&*(ptr as* const RcBox<T>)`, ma ciò creava un riferimento disallineato (vedere #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Assegna per il layout.
        let ptr = allocate(layout)?;

        // Inizializza RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alloca un `RcBox<T>` con spazio sufficiente per un valore interno non dimensionato
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Allocare per `RcBox<T>` utilizzando il valore fornito.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia il valore come byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Libera l'assegnazione senza farne cadere il contenuto
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alloca un `RcBox<[T]>` con la lunghezza data.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Copia gli elementi dalla slice nella Rc <\[T\]> appena allocata
    ///
    /// Non sicuro perché il chiamante deve assumere la proprietà o associare `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Costruisce un `Rc<[T]>` da un iteratore noto per essere di una certa dimensione.
    ///
    /// Il comportamento non è definito se la dimensione è sbagliata.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic protegge durante la clonazione degli elementi T.
        // In caso di panic, gli elementi che sono stati scritti nel nuovo RcBox verranno eliminati, quindi la memoria verrà liberata.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntatore al primo elemento
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tutto chiaro.Dimentica la guardia in modo che non liberi il nuovo RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializzazione trait usata per `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Elimina l `Rc`.
    ///
    /// Ciò diminuirà il conteggio dei riferimenti forti.
    /// Se il conteggio dei riferimenti forti raggiunge lo zero, gli unici altri riferimenti (se presenti) sono [`Weak`], quindi `drop` è il valore interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Non stampa nulla
    /// drop(foo2);   // Stampa "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // distruggere l'oggetto contenuto
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // rimuovere il puntatore "strong weak" implicito ora che abbiamo distrutto il contenuto.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Crea un clone del puntatore `Rc`.
    ///
    /// Questo crea un altro puntatore alla stessa allocazione, aumentando il conteggio dei riferimenti forti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Crea un nuovo `Rc<T>`, con il valore `Default` per `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack per consentire la specializzazione su `Eq` anche se `Eq` ha un metodo.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Stiamo facendo questa specializzazione qui, e non come un'ottimizzazione più generale su `&T`, perché altrimenti aggiungerebbe un costo a tutti i controlli di uguaglianza sui ref.
/// Partiamo dal presupposto che `Rc`s siano usati per memorizzare valori grandi, che sono lenti da clonare, ma anche pesanti per verificare l'uguaglianza, facendo sì che questo costo si ripaghi più facilmente.
///
/// È anche più probabile che abbia due cloni `Rc`, che puntano allo stesso valore, rispetto a due `&T`.
///
/// Possiamo farlo solo quando `T: Eq` come `PartialEq` potrebbe essere deliberatamente irriflessivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Uguaglianza per due "Rc".
    ///
    /// Due "Rc" sono uguali se i loro valori interni sono uguali, anche se sono memorizzati in allocazioni diverse.
    ///
    /// Se `T` implementa anche `Eq` (implicando riflessività di uguaglianza), due `Rc` che puntano alla stessa allocazione sono sempre uguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Disuguaglianza per due "Rc".
    ///
    /// Due "Rc" sono disuguali se i loro valori interni non sono uguali.
    ///
    /// Se `T` implementa anche `Eq` (che implica riflessività di uguaglianza), due `Rc` che puntano alla stessa allocazione non sono mai disuguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Confronto parziale per due `Rc`.
    ///
    /// I due vengono confrontati chiamando `partial_cmp()` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Confronto minore di due "Rc".
    ///
    /// I due vengono confrontati chiamando `<` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Confronto 'Minore o uguale a' per due 'Rc`.
    ///
    /// I due vengono confrontati chiamando `<=` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Confronto maggiore di per due "Rc".
    ///
    /// I due vengono confrontati chiamando `>` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Confronto 'Maggiore o uguale a' per due 'Rc`.
    ///
    /// I due vengono confrontati chiamando `>=` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Confronto per due "Rc".
    ///
    /// I due vengono confrontati chiamando `cmp()` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alloca una fetta contata come riferimento e riempila clonando gli elementi di "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Allocare una sezione di stringa con conteggio dei riferimenti e copiarvi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Allocare una sezione di stringa con conteggio dei riferimenti e copiarvi `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Spostare un oggetto boxed in una nuova allocazione con conteggio dei riferimenti.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alloca uno slice contato per riferimento e sposta gli elementi di "v" al suo interno.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Consenti al Vec di liberare la sua memoria, ma non distruggere il suo contenuto
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Prende ogni elemento nell `Iterator` e lo raccoglie in un `Rc<[T]>`.
    ///
    /// # Caratteristiche di performance
    ///
    /// ## Il caso generale
    ///
    /// Nel caso generale, la raccolta in `Rc<[T]>` viene eseguita raccogliendo prima in `Vec<T>`.Cioè, quando si scrive quanto segue:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// questo si comporta come se scrivessimo:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // La prima serie di allocazioni avviene qui.
    ///     .into(); // Una seconda allocazione per `Rc<[T]>` avviene qui.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Questo allocherà tante volte quante sono necessarie per costruire l `Vec<T>` e poi allocherà una volta per trasformare l `Vec<T>` nell `Rc<[T]>`.
    ///
    ///
    /// ## Iteratori di lunghezza nota
    ///
    /// Quando il tuo `Iterator` implementa `TrustedLen` ed è di una dimensione esatta, verrà effettuata una singola allocazione per `Rc<[T]>`.Per esempio:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Qui avviene solo una singola allocazione.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializzazione trait utilizzata per la raccolta in `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Questo è il caso di un iteratore `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICUREZZA: Dobbiamo assicurarci che l'iteratore abbia una lunghezza esatta e l'abbiamo.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Torna alla normale implementazione.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` è una versione di [`Rc`] che contiene un riferimento non proprietario all'allocazione gestita.Si accede all'assegnazione chiamando [`upgrade`] sul puntatore `Weak`, che restituisce un [`Option`]`<`[`Rc`] `<T>>`.
///
/// Poiché un riferimento `Weak` non viene conteggiato ai fini della proprietà, non impedirà l'eliminazione del valore memorizzato nell'allocazione e `Weak` stesso non garantisce che il valore sia ancora presente.
/// Quindi può restituire [`None`] quando [`upgrade`] d.
/// Si noti tuttavia che un riferimento `Weak`*impedisce* la deallocazione dell'allocazione stessa (l'archivio di supporto).
///
/// Un puntatore `Weak` è utile per mantenere un riferimento temporaneo all'allocazione gestita da [`Rc`] senza impedire che il suo valore interno venga eliminato.
/// Viene anche utilizzato per evitare riferimenti circolari tra i puntatori [`Rc`], poiché i riferimenti di proprietà reciproca non consentirebbero mai di eliminare nessuno dei due [`Rc`].
/// Ad esempio, un albero potrebbe avere puntatori [`Rc`] potenti dai nodi padre ai figli e puntatori `Weak` dai figli ai loro genitori.
///
/// Il modo tipico per ottenere un puntatore `Weak` è chiamare [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Questo è un `NonNull` per consentire l'ottimizzazione della dimensione di questo tipo in enumerazioni, ma non è necessariamente un puntatore valido.
    //
    // `Weak::new` lo imposta su `usize::MAX` in modo che non sia necessario allocare spazio sull'heap.
    // Questo non è un valore che un puntatore reale avrà mai perché RcBox ha almeno 2 allineamenti.
    // Questo è possibile solo quando `T: Sized`;`T` non dimensionato non penzola mai.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Costruisce un nuovo `Weak<T>`, senza allocare memoria.
    /// Chiamare [`upgrade`] sul valore di ritorno fornisce sempre [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Tipo di supporto per consentire l'accesso ai conteggi dei riferimenti senza fare affermazioni sul campo dati.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Restituisce un puntatore grezzo all'oggetto `T` puntato da questo `Weak<T>`.
    ///
    /// Il puntatore è valido solo se ci sono dei riferimenti forti.
    /// Il puntatore può essere sospeso, non allineato o addirittura [`null`] in caso contrario.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Entrambi puntano allo stesso oggetto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Il forte qui lo tiene in vita, quindi possiamo ancora accedere all'oggetto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ma non più.
    /// // Possiamo fare weak.as_ptr(), ma l'accesso al puntatore porterebbe a un comportamento indefinito.
    /// // assert_eq! ("ciao", non sicuro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se il puntatore penzola, restituiamo direttamente la sentinella.
            // Questo non può essere un indirizzo di payload valido, poiché il payload è allineato almeno quanto RcBox (usize).
            ptr as *const T
        } else {
            // SICUREZZA: se is_dangling restituisce false, il puntatore è dereferenziabile.
            // Il carico utile può essere eliminato a questo punto e dobbiamo mantenere la provenienza, quindi usa la manipolazione del puntatore grezzo.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Consuma l `Weak<T>` e lo trasforma in un puntatore grezzo.
    ///
    /// Questo converte il puntatore debole in un puntatore grezzo, pur conservando la proprietà di un riferimento debole (il conteggio debole non viene modificato da questa operazione).
    /// Può essere trasformato di nuovo nell `Weak<T>` con [`from_raw`].
    ///
    /// Si applicano le stesse restrizioni di accesso alla destinazione del puntatore come con [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un puntatore non elaborato precedentemente creato da [`into_raw`] in `Weak<T>`.
    ///
    /// Questo può essere utilizzato per ottenere in sicurezza un riferimento forte (chiamando [`upgrade`] in seguito) o per deallocare il conteggio debole rilasciando `Weak<T>`.
    ///
    /// Prende la proprietà di un riferimento debole (ad eccezione dei puntatori creati da [`new`], poiché questi non possiedono nulla; il metodo funziona ancora su di essi).
    ///
    /// # Safety
    ///
    /// Il puntatore deve aver avuto origine dall [`into_raw`] e deve ancora possedere il suo potenziale riferimento debole.
    ///
    /// È consentito che il conteggio forte sia 0 al momento della chiamata.
    /// Tuttavia, questo assume la proprietà di un riferimento debole attualmente rappresentato come un puntatore grezzo (il conteggio debole non viene modificato da questa operazione) e quindi deve essere accoppiato con una precedente chiamata a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminuisci l'ultimo conteggio debole.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vedere Weak::as_ptr per il contesto su come viene derivato il puntatore di input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Questo è un debole penzolante.
            ptr as *mut RcBox<T>
        } else {
            // Altrimenti, ci viene garantito che il puntatore proviene da un debole non intricato.
            // SICUREZZA: data_offset è sicuro da chiamare, poiché ptr fa riferimento a un T.
            let offset = unsafe { data_offset(ptr) };
            // Quindi, invertiamo l'offset per ottenere l'intero RcBox.
            // SICUREZZA: il puntatore ha avuto origine da un debole, quindi questo offset è sicuro.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICUREZZA: ora abbiamo recuperato il puntatore debole originale, quindi possiamo creare il debole.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Tenta di aggiornare il puntatore `Weak` a un [`Rc`], ritardando l'eliminazione del valore interno in caso di successo.
    ///
    ///
    /// Restituisce [`None`] se il valore interno è stato successivamente eliminato.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distruggi tutti i puntatori forti.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Ottiene il numero di puntatori (`Rc`) potenti che puntano a questa allocazione.
    ///
    /// Se `self` è stato creato utilizzando [`Weak::new`], restituirà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Ottiene il numero di puntatori `Weak` che puntano a questa allocazione.
    ///
    /// Se non rimangono puntatori forti, questo restituirà zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // sottrarre la ptr debole implicita
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Restituisce `None` quando il puntatore è sospeso e non è presente alcun `RcBox` allocato, (ovvero, quando questo `Weak` è stato creato da `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Stiamo attenti a *non* creare un riferimento che copra il campo "data", poiché il campo potrebbe essere modificato contemporaneamente (ad esempio, se l'ultimo `Rc` viene eliminato, il campo dati verrà rilasciato sul posto).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Restituisce `true` se i due "Debole" puntano alla stessa allocazione (simile a [`ptr::eq`]), o se entrambi non puntano ad alcuna allocazione (perché sono stati creati con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Poiché questo confronta i puntatori, significa che `Weak::new()` sarà uguale a vicenda, anche se non punta ad alcuna allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Confrontando `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Rilascia il puntatore `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Non stampa nulla
    /// drop(foo);        // Stampa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // il conteggio debole inizia da 1 e andrà a zero solo se tutti i puntatori forti sono scomparsi.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Crea un clone del puntatore `Weak` che punta alla stessa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Costruisce un nuovo `Weak<T>`, allocando memoria per `T` senza inizializzarlo.
    /// Chiamare [`upgrade`] sul valore di ritorno fornisce sempre [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Abbiamo controllato_add qui per gestire mem::forget in sicurezza.In particolare
// se si mem::forget Rcs (o Weaks), il ref-count può traboccare, quindi è possibile liberare l'allocazione mentre esistono Rcs (o Weaks) in sospeso.
//
// Abortiamo perché questo è uno scenario così degenerato che non ci interessa quello che succede-nessun vero programma dovrebbe mai sperimentarlo.
//
// Questo dovrebbe avere un sovraccarico trascurabile poiché in realtà non è necessario clonarli molto in Rust grazie alla proprietà e alla semantica dello spostamento.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Vogliamo interrompere in caso di overflow invece di eliminare il valore.
        // Il conteggio dei riferimenti non sarà mai zero quando viene chiamato;
        // tuttavia, inseriamo un interruzione qui per suggerire a LLVM un'ottimizzazione altrimenti mancata.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Vogliamo interrompere in caso di overflow invece di eliminare il valore.
        // Il conteggio dei riferimenti non sarà mai zero quando viene chiamato;
        // tuttavia, inseriamo un interruzione qui per suggerire a LLVM un'ottimizzazione altrimenti mancata.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Ottieni l'offset all'interno di un `RcBox` per il carico utile dietro un puntatore.
///
/// # Safety
///
/// Il puntatore deve puntare a (e disporre di metadati validi per) un'istanza precedentemente valida di T, ma è consentito eliminare T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Allinea il valore non dimensionato alla fine di RcBox.
    // Poiché RcBox è repr(C), sarà sempre l'ultimo campo in memoria.
    // SICUREZZA: poiché gli unici tipi non dimensionati possibili sono gli slice, trait oggetti,
    // ed extern, il requisito di sicurezza dell'ingresso è attualmente sufficiente per soddisfare i requisiti di align_of_val_raw;questo è un dettaglio di implementazione del linguaggio su cui non si può fare affidamento al di fuori di std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}