//! API di allocazione della memoria

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Questi sono i simboli magici per chiamare l'allocatore globale.rustc li genera per chiamare `__rg_alloc` ecc.
    // se è presente un attributo `#[global_allocator]` (il codice che espande la macro di quell'attributo genera quelle funzioni), o per chiamare le implementazioni predefinite in libstd (`__rdl_alloc` ecc.
    //
    // in `library/std/src/alloc.rs`) altrimenti.
    // rustc fork di LLVM ha anche casi speciali di questi nomi di funzioni per poterli ottimizzare come `malloc`, `realloc` e `free`, rispettivamente.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// L'allocatore di memoria globale.
///
/// Questo tipo implementa [`Allocator`] trait inoltrando le chiamate all'allocatore registrato con l'attributo `#[global_allocator]`, se presente, o al valore predefinito di `std` crate.
///
///
/// Note: sebbene questo tipo sia instabile, è possibile accedere alle funzionalità che fornisce tramite [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Alloca la memoria con l'allocatore globale.
///
/// Questa funzione inoltra le chiamate al metodo [`GlobalAlloc::alloc`] dell'allocatore registrato con l'attributo `#[global_allocator]`, se presente, o al valore predefinito di `std` crate.
///
///
/// Questa funzione dovrebbe essere deprecata a favore del metodo `alloc` del tipo [`Global`] quando esso e l [`Allocator`] trait diventeranno stabili.
///
/// # Safety
///
/// Vedi [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Distribuire la memoria con l'allocatore globale.
///
/// Questa funzione inoltra le chiamate al metodo [`GlobalAlloc::dealloc`] dell'allocatore registrato con l'attributo `#[global_allocator]`, se presente, o al valore predefinito di `std` crate.
///
///
/// Questa funzione dovrebbe essere deprecata a favore del metodo `dealloc` del tipo [`Global`] quando esso e l [`Allocator`] trait diventeranno stabili.
///
/// # Safety
///
/// Vedi [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Rialloca la memoria con l'allocatore globale.
///
/// Questa funzione inoltra le chiamate al metodo [`GlobalAlloc::realloc`] dell'allocatore registrato con l'attributo `#[global_allocator]`, se presente, o al valore predefinito di `std` crate.
///
///
/// Questa funzione dovrebbe essere deprecata a favore del metodo `realloc` del tipo [`Global`] quando esso e l [`Allocator`] trait diventeranno stabili.
///
/// # Safety
///
/// Vedi [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Allocare la memoria inizializzata zero con l'allocatore globale.
///
/// Questa funzione inoltra le chiamate al metodo [`GlobalAlloc::alloc_zeroed`] dell'allocatore registrato con l'attributo `#[global_allocator]`, se presente, o al valore predefinito di `std` crate.
///
///
/// Questa funzione dovrebbe essere deprecata a favore del metodo `alloc_zeroed` del tipo [`Global`] quando esso e l [`Allocator`] trait diventeranno stabili.
///
/// # Safety
///
/// Vedi [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SICUREZZA: `layout` ha una dimensione diversa da zero,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SICUREZZA: come `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SICUREZZA: `new_size` è diverso da zero poiché `old_size` è maggiore o uguale a `new_size`
            // come richiesto dalle condizioni di sicurezza.Altre condizioni devono essere rispettate dal chiamante
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` probabilmente controlla `new_size >= old_layout.size()` o qualcosa di simile.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SICUREZZA: poiché `new_layout.size()` deve essere maggiore o uguale a `old_size`,
            // sia la vecchia che la nuova allocazione di memoria sono valide per le letture e le scritture per i byte `old_size`.
            // Inoltre, poiché la vecchia allocazione non è stata ancora deallocata, non può sovrapporsi a `new_ptr`.
            // Pertanto, la chiamata a `copy_nonoverlapping` è sicura.
            // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SICUREZZA: `layout` ha una dimensione diversa da zero,
            // altre condizioni devono essere rispettate dal chiamante
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: tutte le condizioni devono essere rispettate dal chiamante
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SICUREZZA: tutte le condizioni devono essere rispettate dal chiamante
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SICUREZZA: le condizioni devono essere rispettate dal chiamante
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SICUREZZA: `new_size` è diverso da zero.Altre condizioni devono essere rispettate dal chiamante
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` probabilmente controlla `new_size <= old_layout.size()` o qualcosa di simile.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SICUREZZA: poiché `new_size` deve essere minore o uguale a `old_layout.size()`,
            // sia la vecchia che la nuova allocazione di memoria sono valide per le letture e le scritture per i byte `new_size`.
            // Inoltre, poiché la vecchia allocazione non è stata ancora deallocata, non può sovrapporsi a `new_ptr`.
            // Pertanto, la chiamata a `copy_nonoverlapping` è sicura.
            // Il contratto di sicurezza per `dealloc` deve essere confermato dal chiamante.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// L'allocatore per puntatori univoci.
// Questa funzione non deve svolgersi.Se lo fa, il codegen MIR fallirà.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Questa firma deve essere la stessa di `Box`, altrimenti si verificherà un ICE.
// Quando viene aggiunto un parametro aggiuntivo a `Box` (come `A: Allocator`), anche questo deve essere aggiunto qui.
// Ad esempio, se `Box` viene modificato in `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, anche questa funzione deve essere modificata in `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Gestore degli errori di allocazione

extern "Rust" {
    // Questo è il simbolo magico per chiamare il gestore degli errori di allocazione globale.
    // rustc lo genera per chiamare `__rg_oom` se è presente un `#[alloc_error_handler]`, o altrimenti per chiamare le implementazioni predefinite sotto (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Interruzione in caso di errore o errore di allocazione della memoria.
///
/// I chiamanti delle API di allocazione della memoria che desiderano interrompere il calcolo in risposta a un errore di allocazione sono incoraggiati a chiamare questa funzione, piuttosto che invocare direttamente `panic!` o simili.
///
///
/// Il comportamento predefinito di questa funzione è stampare un messaggio sull'errore standard e interrompere il processo.
/// Può essere sostituito con [`set_alloc_error_hook`] e [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Per il test alloc `std::alloc::handle_alloc_error` può essere utilizzato direttamente.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // chiamato tramite `__rust_alloc_error_handler` generato

    // se non è presente `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // se è presente un `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Specializza i cloni nella memoria pre-allocata e non inizializzata.
/// Utilizzato da `Box::clone` e `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Avere allocato *first* può consentire all'ottimizzatore di creare il valore clonato sul posto, saltando il locale e spostandosi.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Possiamo sempre copiare sul posto, senza mai coinvolgere un valore locale.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}