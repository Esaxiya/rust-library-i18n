/// Crea un [`Vec`] contenente gli argomenti.
///
/// `vec!` permette di definire `Vec`s con la stessa sintassi delle espressioni di array.
/// Esistono due forme di questa macro:
///
/// - Crea un [`Vec`] contenente un determinato elenco di elementi:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Crea un [`Vec`] da un dato elemento e dimensione:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Si noti che a differenza delle espressioni di matrice, questa sintassi supporta tutti gli elementi che implementano [`Clone`] e il numero di elementi non deve essere una costante.
///
/// Questo userà `clone` per duplicare un'espressione, quindi dovresti stare attento a usarlo con tipi che hanno un'implementazione `Clone` non standard.
/// Ad esempio, `vec![Rc::new(1);5] `creerà uno vector di cinque riferimenti allo stesso valore intero boxed, non cinque riferimenti che puntano a interi boxed indipendenti.
///
///
/// Inoltre, nota che `vec![expr; 0]` è consentito e produce un vector vuoto.
/// Tuttavia, questo valuterà comunque `expr` e lascerà cadere immediatamente il valore risultante, quindi fai attenzione agli effetti collaterali.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): con cfg(test) il metodo `[T]::into_vec` intrinseco, richiesto per questa definizione di macro, non è disponibile.
// Utilizzare invece la funzione `slice::into_vec` che è disponibile solo con cfg(test) NB vedere il modulo slice::hack in slice.rs per maggiori informazioni
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Crea un `String` utilizzando l'interpolazione delle espressioni di runtime.
///
/// Il primo argomento che `format!` riceve è una stringa di formato.Deve essere una stringa letterale.La potenza della stringa di formattazione è nelle "{}" contenute.
///
/// Parametri aggiuntivi passati a `format!` sostituiscono i "{}" all'interno della stringa di formattazione nell'ordine dato a meno che non vengano utilizzati parametri nominali o posizionali;vedere [`std::fmt`] per ulteriori informazioni.
///
///
/// Un uso comune di `format!` è la concatenazione e l'interpolazione di stringhe.
/// La stessa convenzione viene utilizzata con le macro [`print!`] e [`write!`], a seconda della destinazione prevista della stringa.
///
/// Per convertire un singolo valore in una stringa, utilizzare il metodo [`to_string`].Questo userà la formattazione [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics se un'implementazione trait di formattazione restituisce un errore.
/// Ciò indica un'implementazione errata poiché `fmt::Write for String` non restituisce mai un errore stesso.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Forza il nodo AST a un'espressione per migliorare la diagnostica nella posizione del pattern.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}