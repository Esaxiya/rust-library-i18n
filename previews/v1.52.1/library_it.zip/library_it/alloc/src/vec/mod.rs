//! Un tipo di array espandibile contiguo con contenuti allocati nell'heap, scritto `Vec<T>`.
//!
//! Vectors ha l'indicizzazione `O(1)`, il push `O(1)` ammortizzato (fino alla fine) e il pop `O(1)` (dalla fine).
//!
//!
//! Vectors garantisce di non allocare mai più di `isize::MAX` byte.
//!
//! # Examples
//!
//! Puoi creare esplicitamente un [`Vec`] con [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... o utilizzando la macro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dieci zeri
//! ```
//!
//! Puoi [`push`] valori alla fine di un vector (che aumenterà vector secondo necessità):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! I valori scoppiettanti funzionano più o meno allo stesso modo:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors supporta anche l'indicizzazione (tramite [`Index`] e [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Un tipo di array espandibile contiguo, scritto come `Vec<T>` e pronunciato 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// La macro [`vec!`] viene fornita per rendere più conveniente l'inizializzazione:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Può anche inizializzare ogni elemento di un `Vec<T>` con un dato valore.
/// Questo può essere più efficiente rispetto all'esecuzione di allocazione e inizializzazione in passaggi separati, specialmente quando si inizializza un vector di zeri:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Quanto segue è equivalente, ma potenzialmente più lento:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Per ulteriori informazioni, vedere [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Usa un `Vec<T>` come stack efficiente:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Stampe 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Il tipo `Vec` permette di accedere ai valori per indice, perché implementa [`Index`] trait.Un esempio sarà più esplicito:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // visualizzerà '2'
/// ```
///
/// Tuttavia fai attenzione: se provi ad accedere a un indice che non è nell `Vec`, il tuo software panic!Non puoi farlo:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Usa [`get`] e [`get_mut`] se vuoi controllare se l'indice è nell `Vec`.
///
/// # Slicing
///
/// Un `Vec` può essere mutevole.D'altra parte, le sezioni sono oggetti di sola lettura.
/// Per ottenere un [slice][prim@slice], usa [`&`].Esempio:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... e questo è tutto!
/// // puoi anche farlo in questo modo:
/// let u: &[usize] = &v;
/// // o così:
/// let u: &[_] = &v;
/// ```
///
/// In Rust, è più comune passare le sezioni come argomenti piuttosto che vectors quando si desidera fornire solo l'accesso in lettura.Lo stesso vale per [`String`] e [`&str`].
///
/// # Capacità e riallocazione
///
/// La capacità di un vector è la quantità di spazio allocato per qualsiasi elemento future che verrà aggiunto a vector.Questo non deve essere confuso con la *length* di vector, che specifica il numero di elementi effettivi all'interno di vector.
/// Se la lunghezza di uno vector supera la sua capacità, la sua capacità verrà automaticamente aumentata, ma i suoi elementi dovranno essere riallocati.
///
/// Ad esempio, un vector con capacità 10 e lunghezza 0 sarebbe uno vector vuoto con spazio per altri 10 elementi.Spingere 10 o meno elementi su vector non cambierà la sua capacità né causerà la riallocazione.
/// Tuttavia, se la lunghezza di vector viene aumentata a 11, dovrà essere riallocata, il che può essere lento.Per questo motivo, si consiglia di utilizzare [`Vec::with_capacity`] ogni volta che è possibile per specificare la dimensione prevista per vector.
///
/// # Guarantees
///
/// A causa della sua natura incredibilmente fondamentale, `Vec` offre molte garanzie sul suo design.Ciò garantisce che sia il più basso possibile nel caso generale e possa essere correttamente manipolato in modi primitivi da codice non sicuro.Notare che queste garanzie si riferiscono a un `Vec<T>` non qualificato.
/// Se vengono aggiunti parametri di tipo aggiuntivi (ad esempio, per supportare allocatori personalizzati), l'override dei valori predefiniti potrebbe modificare il comportamento.
///
/// Fondamentalmente, `Vec` è e sarà sempre una tripletta (puntatore, capacità, lunghezza).Ne più ne meno.L'ordine di questi campi è completamente non specificato ed è necessario utilizzare i metodi appropriati per modificarli.
/// Il puntatore non sarà mai nullo, quindi questo tipo è ottimizzato per il puntatore nullo.
///
/// Tuttavia, il puntatore potrebbe non puntare effettivamente alla memoria allocata.
/// In particolare, se costruisci un `Vec` con capacità 0 tramite [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] o chiamando [`shrink_to_fit`] su un Vec vuoto, non allocherà memoria.Allo stesso modo, se memorizzi tipi di dimensione zero all'interno di un `Vec`, non allocherà spazio per loro.
/// *Notare che in questo caso l `Vec` potrebbe non riportare un [`capacity`] pari a 0*.
/// `Vec` allocerà se e solo se [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// In generale, i dettagli di allocazione di `Vec` sono molto sottili-se intendi allocare memoria usando un `Vec` e usarlo per qualcos'altro (sia per passare a codice non sicuro, o per costruire la tua raccolta supportata dalla memoria), assicurati per deallocare questa memoria utilizzando `from_raw_parts` per recuperare l `Vec` e quindi rilasciarlo.
///
/// Se un `Vec`*ha* memoria allocata, la memoria a cui punta è sull'heap (come definito dall'allocatore Rust è configurato per l'uso di default) e il suo puntatore punta a [`len`] inizializzato, elementi contigui in ordine (cosa vorresti controlla se l'hai costretto a diventare uno slice), seguito da [`capacity`]`,`[`len`] elementi contigui logicamente non inizializzati.
///
///
/// Uno vector contenente gli elementi `'a'` e `'b'` con capacità 4 può essere visualizzato come di seguito.La parte superiore è la struttura `Vec`, contiene un puntatore all'head dell'allocazione in heap, length e capacity.
/// La parte inferiore è l'allocazione sull'heap, un blocco di memoria contiguo.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** rappresenta la memoria non inizializzata, vedere [`MaybeUninit`].
/// - Note: l'ABI non è stabile e `Vec` non fornisce alcuna garanzia sul layout della memoria (compreso l'ordine dei campi).
///
/// `Vec` non eseguirà mai un "small optimization" in cui gli elementi sono effettivamente memorizzati nello stack per due motivi:
///
/// * Renderebbe più difficile per il codice non sicuro manipolare correttamente un `Vec`.Il contenuto di un `Vec` non avrebbe un indirizzo stabile se fosse solo spostato, e sarebbe più difficile determinare se un `Vec` avesse effettivamente allocato memoria.
///
/// * Penalizzerebbe il caso generale, incorrere in un ulteriore branch ad ogni accesso.
///
/// `Vec` non si restringerà mai automaticamente, anche se completamente vuoto.Ciò garantisce che non si verifichino allocazioni o deallocazioni non necessarie.Svuotare un `Vec` e poi riempirlo di nuovo nello stesso [`len`] non dovrebbe comportare chiamate all'allocatore.Se desideri liberare memoria inutilizzata, usa [`shrink_to_fit`] o [`shrink_to`].
///
/// [`push`] e [`insert`] non (ri) assegnerà mai se la capacità segnalata è sufficiente.[`push`] e [`insert`]* * verranno (ri) allocati se [`len`]`==`[`capacity`].Cioè, la capacità riportata è completamente accurata e su cui si può fare affidamento.Può anche essere utilizzato per liberare manualmente la memoria allocata da un `Vec`, se lo si desidera.
/// I metodi di inserimento in blocco *possono* riallocare, anche quando non necessario.
///
/// `Vec` non garantisce alcuna strategia di crescita particolare quando si rialloca quando è pieno, né quando viene chiamato [`reserve`].L'attuale strategia è basilare e potrebbe rivelarsi opportuno utilizzare un fattore di crescita non costante.Qualunque sia la strategia utilizzata, ovviamente garantirà *O*(1) [`push`] ammortizzato.
///
/// `vec![x; n]`, `vec![a, b, c, d]` e [`Vec::with_capacity(n)`][`Vec::with_capacity`] produrranno tutti un `Vec` con esattamente la capacità richiesta.
/// Se [`len`]`==`[`capacity`], (come nel caso della macro [`vec!`]), allora un `Vec<T>` può essere convertito in e da un [`Box<[T]>`][owned slice] senza riallocare o spostare gli elementi.
///
/// `Vec` non sovrascriverà in modo specifico i dati rimossi da esso, ma non li preserverà in modo specifico.La sua memoria non inizializzata è spazio di memoria virtuale che può utilizzare come preferisce.Generalmente farà solo ciò che è più efficiente o altrimenti facile da implementare.Non fare affidamento sulla cancellazione dei dati rimossi per motivi di sicurezza.
/// Anche se si rilascia un `Vec`, il suo buffer può essere semplicemente riutilizzato da un altro `Vec`.
/// Anche se azzeri prima la memoria di un "Vec", ciò potrebbe non accadere perché l'ottimizzatore non lo considera un effetto collaterale che deve essere preservato.
/// C'è un caso che non interromperemo, tuttavia: usare il codice `unsafe` per scrivere sulla capacità in eccesso, e quindi aumentare la lunghezza per adattarla, è sempre valido.
///
/// Attualmente, `Vec` non garantisce l'ordine in cui gli elementi vengono eliminati.
/// L'ordine è cambiato in passato e potrebbe cambiare di nuovo.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metodi intrinseci
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Costruisce un nuovo `Vec<T>` vuoto.
    ///
    /// vector non verrà allocato fino a quando gli elementi non verranno inseriti su di esso.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Costruisce un nuovo `Vec<T>` vuoto con la capacità specificata.
    ///
    /// vector sarà in grado di contenere esattamente gli elementi `capacity` senza riallocare.
    /// Se `capacity` è 0, vector non verrà allocato.
    ///
    /// È importante notare che sebbene vector restituito abbia la *capacità* specificata, vector avrà una *lunghezza* zero.
    ///
    /// Per una spiegazione della differenza tra lunghezza e capacità, vedere *[Capacità e riallocazione]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector non contiene elementi, anche se può contenere altri elementi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tutto questo viene fatto senza riallocare ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ma questo potrebbe far riallocare vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Crea un `Vec<T>` direttamente dai componenti grezzi di un altro vector.
    ///
    /// # Safety
    ///
    /// Questo è altamente pericoloso, a causa del numero di invarianti che non vengono verificati:
    ///
    /// * `ptr` deve essere stato precedentemente allocato tramite [`String`]/`Vec<T>`(almeno, è molto probabile che non sia corretto se non lo fosse).
    /// * `T` deve avere le stesse dimensioni e allineamento di quelli con cui è stato allocato `ptr`.
    ///   (`T` avere un allineamento meno rigoroso non è sufficiente, l'allineamento deve davvero essere uguale per soddisfare il requisito [`dealloc`] che la memoria deve essere allocata e deallocata con lo stesso layout.)
    ///
    /// * `length` deve essere minore o uguale a `capacity`.
    /// * `capacity` deve essere la capacità con cui è stato allocato il puntatore.
    ///
    /// La violazione di questi può causare problemi come il danneggiamento delle strutture di dati interne dell'allocatore.Ad esempio,**non** è sicuro costruire un `Vec<u8>` da un puntatore a un array C `char` con lunghezza `size_t`.
    /// Inoltre, non è sicuro costruirne uno da un `Vec<u16>` e dalla sua lunghezza, perché l'allocatore si preoccupa dell'allineamento e questi due tipi hanno allineamenti diversi.
    /// Il buffer è stato allocato con l'allineamento 2 (per `u16`), ma dopo averlo trasformato in un `Vec<u8>` verrà deallocato con l'allineamento 1.
    ///
    /// La proprietà di `ptr` viene effettivamente trasferita all `Vec<T>` che può quindi deallocare, riallocare o modificare a piacimento il contenuto della memoria puntato dal puntatore.
    /// Assicurati che nient'altro utilizzi il puntatore dopo aver chiamato questa funzione.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Aggiorna questo quando vec_into_raw_parts è stabilizzato.
    ///     // Impedisci l'esecuzione del distruttore di `v` in modo da avere il controllo completo dell'allocazione.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Estrarre le varie informazioni importanti su `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Sovrascrivi la memoria con 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rimetti tutto insieme in un Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Costruisce un nuovo `Vec<T, A>` vuoto.
    ///
    /// vector non verrà allocato fino a quando gli elementi non verranno inseriti su di esso.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Costruisce un nuovo `Vec<T, A>` vuoto con la capacità specificata con l'allocatore fornito.
    ///
    /// vector sarà in grado di contenere esattamente gli elementi `capacity` senza riallocare.
    /// Se `capacity` è 0, vector non verrà allocato.
    ///
    /// È importante notare che sebbene vector restituito abbia la *capacità* specificata, vector avrà una *lunghezza* zero.
    ///
    /// Per una spiegazione della differenza tra lunghezza e capacità, vedere *[Capacità e riallocazione]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector non contiene elementi, anche se può contenere altri elementi
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Tutto questo viene fatto senza riallocare ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ma questo potrebbe far riallocare vector
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Crea un `Vec<T, A>` direttamente dai componenti grezzi di un altro vector.
    ///
    /// # Safety
    ///
    /// Questo è altamente pericoloso, a causa del numero di invarianti che non vengono verificati:
    ///
    /// * `ptr` deve essere stato precedentemente allocato tramite [`String`]/`Vec<T>`(almeno, è molto probabile che non sia corretto se non lo fosse).
    /// * `T` deve avere le stesse dimensioni e allineamento di quelli con cui è stato allocato `ptr`.
    ///   (`T` avere un allineamento meno rigoroso non è sufficiente, l'allineamento deve davvero essere uguale per soddisfare il requisito [`dealloc`] che la memoria deve essere allocata e deallocata con lo stesso layout.)
    ///
    /// * `length` deve essere minore o uguale a `capacity`.
    /// * `capacity` deve essere la capacità con cui è stato allocato il puntatore.
    ///
    /// La violazione di questi può causare problemi come il danneggiamento delle strutture di dati interne dell'allocatore.Ad esempio,**non** è sicuro costruire un `Vec<u8>` da un puntatore a un array C `char` con lunghezza `size_t`.
    /// Inoltre, non è sicuro costruirne uno da un `Vec<u16>` e dalla sua lunghezza, perché l'allocatore si preoccupa dell'allineamento e questi due tipi hanno allineamenti diversi.
    /// Il buffer è stato allocato con l'allineamento 2 (per `u16`), ma dopo averlo trasformato in un `Vec<u8>` verrà deallocato con l'allineamento 1.
    ///
    /// La proprietà di `ptr` viene effettivamente trasferita all `Vec<T>` che può quindi deallocare, riallocare o modificare a piacimento il contenuto della memoria puntato dal puntatore.
    /// Assicurati che nient'altro utilizzi il puntatore dopo aver chiamato questa funzione.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Aggiorna questo quando vec_into_raw_parts è stabilizzato.
    ///     // Impedisci l'esecuzione del distruttore di `v` in modo da avere il controllo completo dell'allocazione.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Estrarre le varie informazioni importanti su `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Sovrascrivi la memoria con 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Rimetti tutto insieme in un Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decompone un `Vec<T>` nei suoi componenti grezzi.
    ///
    /// Restituisce il puntatore non elaborato ai dati sottostanti, la lunghezza di vector (in elementi) e la capacità allocata dei dati (in elementi).
    /// Questi sono gli stessi argomenti nello stesso ordine degli argomenti di [`from_raw_parts`].
    ///
    /// Dopo aver chiamato questa funzione, il chiamante è responsabile della memoria precedentemente gestita dall `Vec`.
    /// L'unico modo per farlo è riconvertire il puntatore, la lunghezza e la capacità non elaborati in un `Vec` con la funzione [`from_raw_parts`], consentendo al distruttore di eseguire la pulizia.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Ora possiamo apportare modifiche ai componenti, come trasmutare il puntatore non elaborato a un tipo compatibile.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decompone un `Vec<T>` nei suoi componenti grezzi.
    ///
    /// Restituisce il puntatore non elaborato ai dati sottostanti, la lunghezza di vector (in elementi), la capacità allocata dei dati (in elementi) e l'allocatore.
    /// Questi sono gli stessi argomenti nello stesso ordine degli argomenti di [`from_raw_parts_in`].
    ///
    /// Dopo aver chiamato questa funzione, il chiamante è responsabile della memoria precedentemente gestita dall `Vec`.
    /// L'unico modo per farlo è riconvertire il puntatore, la lunghezza e la capacità non elaborati in un `Vec` con la funzione [`from_raw_parts_in`], consentendo al distruttore di eseguire la pulizia.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Ora possiamo apportare modifiche ai componenti, come trasmutare il puntatore non elaborato a un tipo compatibile.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Restituisce il numero di elementi che vector può contenere senza riallocare.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Riserva capacità per almeno `additional` più elementi da inserire nel dato `Vec<T>`.
    /// La collezione può riservare più spazio per evitare frequenti riallocazioni.
    /// Dopo aver chiamato `reserve`, la capacità sarà maggiore o uguale a `self.len() + additional`.
    /// Non fa nulla se la capacità è già sufficiente.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Si riserva la capacità minima per `additional` esattamente più elementi da inserire nel dato `Vec<T>`.
    ///
    /// Dopo aver chiamato `reserve_exact`, la capacità sarà maggiore o uguale a `self.len() + additional`.
    /// Non fa nulla se la capacità è già sufficiente.
    ///
    /// Notare che l'allocatore può dare alla raccolta più spazio di quanto richiede.
    /// Pertanto, non si può fare affidamento sulla capacità esattamente minima.
    /// Preferisci `reserve` se sono previsti inserimenti future.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Tenta di riservare capacità per almeno `additional` più elementi da inserire nell `Vec<T>` specificato.
    /// La collezione può riservare più spazio per evitare frequenti riallocazioni.
    /// Dopo aver chiamato `try_reserve`, la capacità sarà maggiore o uguale a `self.len() + additional`.
    /// Non fa nulla se la capacità è già sufficiente.
    ///
    /// # Errors
    ///
    /// Se la capacità va in overflow o l'allocatore segnala un errore, viene restituito un errore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Riservare la memoria, uscire se non possiamo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Ora sappiamo che questo non può OOM nel bel mezzo del nostro lavoro complesso
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // molto complicato
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Cerca di riservare la capacità minima per gli elementi `additional` da inserire esattamente nell `Vec<T>` specificato.
    /// Dopo aver chiamato `try_reserve_exact`, la capacità sarà maggiore o uguale a `self.len() + additional` se restituisce `Ok(())`.
    ///
    /// Non fa nulla se la capacità è già sufficiente.
    ///
    /// Notare che l'allocatore può dare alla raccolta più spazio di quanto richiede.
    /// Pertanto, non si può fare affidamento sulla capacità esattamente minima.
    /// Preferisci `reserve` se sono previsti inserimenti future.
    ///
    /// # Errors
    ///
    /// Se la capacità va in overflow o l'allocatore segnala un errore, viene restituito un errore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Riservare la memoria, uscire se non possiamo
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Ora sappiamo che questo non può OOM nel bel mezzo del nostro lavoro complesso
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // molto complicato
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Riduce il più possibile la capacità di vector.
    ///
    /// Scenderà il più vicino possibile alla lunghezza, ma l'allocatore potrebbe comunque informare vector che c'è spazio per alcuni elementi in più.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // La capacità non è mai inferiore alla lunghezza e non c'è niente da fare quando sono uguali, quindi possiamo evitare il caso panic in `RawVec::shrink_to_fit` chiamandolo solo con una capacità maggiore.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Riduce la capacità di vector con un limite inferiore.
    ///
    /// La capacità rimarrà grande almeno quanto la lunghezza e il valore fornito.
    ///
    ///
    /// Se la capacità attuale è inferiore al limite inferiore, non è possibile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Converte vector in [`Box<[T]>`][owned slice].
    ///
    /// Notare che questo farà diminuire la capacità in eccesso.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Qualsiasi capacità in eccesso viene rimossa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Accorcia vector, mantenendo i primi elementi `len` e lasciando cadere il resto.
    ///
    /// Se `len` è maggiore della lunghezza corrente di vector, ciò non ha effetto.
    ///
    /// Il metodo [`drain`] può emulare `truncate`, ma fa sì che gli elementi in eccesso vengano restituiti anziché eliminati.
    ///
    ///
    /// Si noti che questo metodo non ha alcun effetto sulla capacità allocata di vector.
    ///
    /// # Examples
    ///
    /// Troncando un vector di cinque elementi a due elementi:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Nessun troncamento si verifica quando `len` è maggiore della lunghezza corrente di vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Troncamento quando `len == 0` equivale a chiamare il metodo [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Questo è sicuro perché:
        //
        // * lo slice passato a `drop_in_place` è valido;il caso `len > self.len` evita di creare uno slice non valido e
        // * l `len` di vector viene ridotto prima di chiamare `drop_in_place`, in modo tale che nessun valore verrà eliminato due volte nel caso in cui `drop_in_place` fosse su panic una volta (se panics due volte, il programma si interrompe).
        //
        //
        //
        unsafe {
            // Note: È intenzionale che questo sia `>` e non `>=`.
            //       In alcuni casi, modificarlo in `>=` ha implicazioni negative sulle prestazioni.
            //       Vedi #78884 per ulteriori informazioni.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Estrae una fetta contenente l'intero vector.
    ///
    /// Equivalente a `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Estrae una fetta modificabile dell'intero vector.
    ///
    /// Equivalente a `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Restituisce un puntatore grezzo al buffer di vector.
    ///
    /// Il chiamante deve assicurarsi che vector sopravviva al puntatore restituito da questa funzione, altrimenti finirà per puntare alla spazzatura.
    /// La modifica di vector può causare la riallocazione del suo buffer, il che renderebbe anche invalidi eventuali puntatori ad esso.
    ///
    /// Il chiamante deve anche assicurarsi che la memoria a cui punta il puntatore (non-transitively) non venga mai scritta (eccetto all'interno di un `UnsafeCell`) utilizzando questo puntatore o qualsiasi puntatore derivato da esso.
    /// Se è necessario modificare il contenuto della slice, utilizzare [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Mettiamo in ombra il metodo slice con lo stesso nome per evitare di passare attraverso `deref`, che crea un riferimento intermedio.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Restituisce un puntatore mutabile non sicuro al buffer di vector.
    ///
    /// Il chiamante deve assicurarsi che vector sopravviva al puntatore restituito da questa funzione, altrimenti finirà per puntare alla spazzatura.
    ///
    /// La modifica di vector può causare la riallocazione del suo buffer, il che renderebbe anche invalidi eventuali puntatori ad esso.
    ///
    /// # Examples
    ///
    /// ```
    /// // Assegna vector abbastanza grande per 4 elementi.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inizializza gli elementi tramite scritture di puntatori non elaborati, quindi imposta la lunghezza.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Mettiamo in ombra il metodo slice con lo stesso nome per evitare di passare attraverso `deref_mut`, che crea un riferimento intermedio.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Restituisce un riferimento all'allocatore sottostante.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forza la lunghezza di vector su `new_len`.
    ///
    /// Questa è un'operazione di basso livello che non mantiene nessuna delle normali invarianti del tipo.
    /// Normalmente la modifica della lunghezza di un vector viene eseguita utilizzando invece una delle operazioni sicure, come [`truncate`], [`resize`], [`extend`] o [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` deve essere minore o uguale a [`capacity()`].
    /// - Gli elementi in `old_len..new_len` devono essere inizializzati.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Questo metodo può essere utile per le situazioni in cui vector funge da buffer per altro codice, in particolare su FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Questo è solo uno scheletro minimo per l'esempio doc;
    /// # // non usarlo come punto di partenza per una vera libreria.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Secondo i documenti del metodo FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SICUREZZA: quando `deflateGetDictionary` restituisce `Z_OK`, mantiene che:
    ///     // 1. `dict_length` gli elementi sono stati inizializzati.
    ///     // 2.
    ///     // `dict_length` <=la capacità (32_768) che rende `set_len` sicuro da chiamare.
    ///     unsafe {
    ///         // Effettua la chiamata FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... e aggiorna la lunghezza a ciò che è stato inizializzato.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Sebbene il seguente esempio sia valido, c'è una perdita di memoria poiché i vectors interni non sono stati liberati prima della chiamata `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` è vuoto, quindi non è necessario inizializzare alcun elemento.
    /// // 2. `0 <= capacity` contiene sempre qualunque cosa sia `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalmente, qui, si userebbe [`clear`] invece per eliminare correttamente il contenuto e quindi non perdere memoria.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Rimuove un elemento da vector e lo restituisce.
    ///
    /// L'elemento rimosso viene sostituito dall'ultimo elemento di vector.
    ///
    /// Ciò non preserva l'ordine, ma è O(1).
    ///
    /// # Panics
    ///
    /// Panics se `index` è fuori dai limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Sostituiamo self [index] con l'ultimo elemento.
            // Nota che se il controllo dei limiti sopra ha esito positivo, deve esserci un ultimo elemento (che può essere lo stesso self [index]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inserisce un elemento nella posizione `index` all'interno di vector, spostando tutti gli elementi dopo di esso a destra.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spazio per il nuovo elemento
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallibile Lo spot per mettere il nuovo valore
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Sposta tutto per fare spazio.
                // (Duplicando l'elemento `index`th in due posizioni consecutive.)
                ptr::copy(p, p.offset(1), len - index);
                // Scrivilo, sovrascrivendo la prima copia dell'elemento `index`th.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Rimuove e restituisce l'elemento nella posizione `index` all'interno di vector, spostando tutti gli elementi dopo di esso a sinistra.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `index` è fuori dai limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // il posto da cui stiamo prendendo.
                let ptr = self.as_mut_ptr().add(index);
                // copialo, avendo in modo pericoloso una copia del valore nello stack e nello vector allo stesso tempo.
                //
                ret = ptr::read(ptr);

                // Sposta tutto in basso per riempire quel punto.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Conserva solo gli elementi specificati dal predicato.
    ///
    /// In altre parole, rimuovere tutti gli elementi `e` in modo tale che `f(&e)` restituisca `false`.
    /// Questo metodo opera sul posto, visitando ogni elemento esattamente una volta nell'ordine originale e preserva l'ordine degli elementi mantenuti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Poiché gli elementi vengono visitati esattamente una volta nell'ordine originale, è possibile utilizzare lo stato esterno per decidere quali elementi mantenere.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evita la doppia caduta se la protezione anticaduta non viene eseguita, poiché potremmo praticare dei fori durante il processo.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len elaborato-> |^-accanto a controllare
        //                  | <-cnt cancellato-> |
        //      | <-original_len-> |Kept: elementi su cui il predicato restituisce true.
        //
        // Foro: slot per elementi spostati o rilasciati.
        // Non selezionato: elementi validi non selezionati.
        //
        // Questa protezione dalla caduta verrà invocata quando il predicato o `drop` dell'elemento è in preda al panico.
        // Sposta gli elementi non selezionati per coprire i fori e `set_len` alla lunghezza corretta.
        // Nei casi in cui predicate e `drop` non vanno mai nel panico, verranno ottimizzati.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SICUREZZA: gli elementi finali non selezionati devono essere validi poiché non li tocchiamo mai.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SICUREZZA: dopo aver riempito i buchi, tutti gli elementi sono nella memoria contigua.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SICUREZZA: l'elemento non selezionato deve essere valido.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avanza presto per evitare una doppia caduta se `drop_in_place` è stato preso dal panico.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SICUREZZA: non tocchiamo mai più questo elemento dopo essere caduto.
                unsafe { ptr::drop_in_place(cur) };
                // Abbiamo già avanzato il contatore.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SICUREZZA: `deleted_cnt`> 0, quindi l'asola del foro non deve sovrapporsi all'elemento corrente.
                // Usiamo la copia per spostarci e non tocchiamo mai più questo elemento.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Tutti gli articoli vengono elaborati.Questo può essere ottimizzato per `set_len` da LLVM.
        drop(g);
    }

    /// Rimuove tutti gli elementi consecutivi tranne il primo in vector che si risolvono nella stessa chiave.
    ///
    ///
    /// Se vector viene ordinato, vengono rimossi tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Rimuove tutti gli elementi consecutivi tranne il primo in vector che soddisfano una data relazione di uguaglianza.
    ///
    /// Alla funzione `same_bucket` vengono passati riferimenti a due elementi da vector e deve determinare se gli elementi sono uguali.
    /// Gli elementi vengono passati in ordine opposto rispetto al loro ordine nella slice, quindi se `same_bucket(a, b)` restituisce `true`, `a` viene rimosso.
    ///
    ///
    /// Se vector viene ordinato, vengono rimossi tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Aggiunge un elemento al retro di una raccolta.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Questo panic o si interromperà se dovessimo allocare> isize::MAX byte o se l'incremento di lunghezza andasse in overflow per i tipi di dimensione zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Rimuove l'ultimo elemento da un vector e lo restituisce, o [`None`] se è vuoto.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Sposta tutti gli elementi di `other` in `Self`, lasciando `other` vuoto.
    ///
    /// # Panics
    ///
    /// Panics se il numero di elementi in vector supera un `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Aggiunge elementi a `Self` da un altro buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Crea un iteratore drenante che rimuove l'intervallo specificato in vector e restituisce gli elementi rimossi.
    ///
    /// Quando l'iteratore ** viene eliminato, tutti gli elementi nell'intervallo vengono rimossi da vector, anche se l'iteratore non è stato completamente consumato.
    /// Se l'iteratore **non viene eliminato**(ad esempio con [`mem::forget`]), non è specificato quanti elementi vengono rimossi.
    ///
    /// # Panics
    ///
    /// Panics se il punto iniziale è maggiore del punto finale o se il punto finale è maggiore della lunghezza di vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Una gamma completa cancella vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sicurezza della memoria
        //
        // Quando Drain viene creato per la prima volta, riduce la lunghezza della sorgente vector per assicurarsi che nessun elemento non inizializzato o spostato sia accessibile se il distruttore di Drain non viene mai eseguito.
        //
        //
        // Drain restituirà ptr::read i valori da rimuovere.
        // Al termine, la coda rimanente del vec viene copiata indietro per coprire il foro e la lunghezza vector viene ripristinata alla nuova lunghezza.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // impostare la lunghezza di self.vec per iniziare, per essere sicuri nel caso in cui Drain sia trapelato
            self.set_len(start);
            // Usa il prestito in IterMut per indicare il comportamento di prestito dell'intero iteratore Drain (come &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Cancella vector, rimuovendo tutti i valori.
    ///
    /// Si noti che questo metodo non ha alcun effetto sulla capacità allocata di vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Restituisce il numero di elementi in vector, noto anche come 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Restituisce `true` se vector non contiene elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Divide la raccolta in due in corrispondenza dell'indice specificato.
    ///
    /// Restituisce un vector appena allocato contenente gli elementi nell'intervallo `[at, len)`.
    /// Dopo la chiamata, lo vector originale verrà lasciato contenente gli elementi `[0, at)` con la sua capacità precedente invariata.
    ///
    ///
    /// # Panics
    ///
    /// Panics se `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // il nuovo vector può sostituire il buffer originale ed evitare la copia
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Non sicuro `set_len` e copia gli elementi su `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ridimensiona l `Vec` sul posto in modo che `len` sia uguale a `new_len`.
    ///
    /// Se `new_len` è maggiore di `len`, `Vec` viene esteso della differenza, con ogni slot aggiuntivo riempito con il risultato della chiamata della chiusura `f`.
    ///
    /// I valori restituiti da `f` finiranno nell `Vec` nell'ordine in cui sono stati generati.
    ///
    /// Se `new_len` è minore di `len`, `Vec` viene semplicemente troncato.
    ///
    /// Questo metodo utilizza una chiusura per creare nuovi valori a ogni spinta.Se preferisci [`Clone`] un dato valore, usa [`Vec::resize`].
    /// Se vuoi usare [`Default`] trait per generare valori, puoi passare [`Default::default`] come secondo argomento.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Consuma e perde l `Vec`, restituendo un riferimento mutevole al contenuto, `&'a mut [T]`.
    /// Si noti che il tipo `T` deve sopravvivere alla durata scelta `'a`.
    /// Se il tipo ha solo riferimenti statici o nessuno, allora questo può essere scelto come `'static`.
    ///
    /// Questa funzione è simile alla funzione [`leak`][Box::leak] su [`Box`] tranne per il fatto che non è possibile recuperare la memoria persa.
    ///
    ///
    /// Questa funzione è utile principalmente per i dati che vivono per il resto della vita del programma.
    /// L'eliminazione del riferimento restituito causerà una perdita di memoria.
    ///
    /// # Examples
    ///
    /// Utilizzo semplice:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Restituisce la capacità di riserva rimanente di vector come slice di `MaybeUninit<T>`.
    ///
    /// La slice restituita può essere utilizzata per riempire vector con i dati (es
    /// leggendo da un file) prima di contrassegnare i dati come inizializzati utilizzando il metodo [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Assegna vector abbastanza grande per 10 elementi.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Compila i primi 3 elementi.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Contrassegna i primi 3 elementi di vector come inizializzati.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Questo metodo non è implementato in termini di `split_at_spare_mut`, per evitare l'invalidazione dei puntatori al buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Restituisce il contenuto vector come slice di `T`, insieme alla capacità di riserva rimanente di vector come slice di `MaybeUninit<T>`.
    ///
    /// La porzione di capacità di riserva restituita può essere utilizzata per riempire vector con i dati (ad esempio leggendo da un file) prima di contrassegnare i dati come inizializzati utilizzando il metodo [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Tieni presente che questa è un'API di basso livello, che dovrebbe essere utilizzata con attenzione per scopi di ottimizzazione.
    /// Se è necessario aggiungere dati a un `Vec`, è possibile utilizzare [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] o [`resize_with`], a seconda delle proprie esigenze.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Riserva spazio aggiuntivo abbastanza grande per 10 elementi.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Compila i prossimi 4 elementi.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Contrassegna i 4 elementi di vector come inizializzati.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len viene ignorato e quindi non viene mai modificato
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sicurezza: la modifica di .2 restituita (&mut usize) è considerata uguale alla chiamata di `.set_len(_)`.
    ///
    /// Questo metodo viene utilizzato per avere accesso univoco a tutte le parti vec contemporaneamente in `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` è garantito per essere valido per gli elementi `len`
        // - `spare_ptr` punta un elemento oltre il buffer, quindi non si sovrappone a `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ridimensiona l `Vec` sul posto in modo che `len` sia uguale a `new_len`.
    ///
    /// Se `new_len` è maggiore di `len`, `Vec` viene esteso della differenza, con ogni slot aggiuntivo riempito con `value`.
    ///
    /// Se `new_len` è minore di `len`, `Vec` viene semplicemente troncato.
    ///
    /// Questo metodo richiede che `T` implementi [`Clone`], per poter clonare il valore passato.
    /// Se hai bisogno di maggiore flessibilità (o vuoi fare affidamento su [`Default`] invece di [`Clone`]), usa [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clona e aggiunge tutti gli elementi in una sezione a `Vec`.
    ///
    /// Itera sulla slice `other`, clona ogni elemento e poi lo aggiunge a questo `Vec`.
    /// `other` vector viene attraversato in ordine.
    ///
    /// Nota che questa funzione è la stessa di [`extend`] tranne per il fatto che è specializzata per lavorare invece con le slice.
    ///
    /// Se e quando Rust ottiene la specializzazione, questa funzione sarà probabilmente deprecata (ma ancora disponibile).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Copia gli elementi dall'intervallo `src` alla fine di vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garantisce che l'intervallo specificato sia valido per l'indicizzazione di sé
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Questo codice generalizza `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Estendi vector di valori `n`, utilizzando il generatore fornito.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Usa SetLenOnDrop per aggirare il bug in cui il compilatore potrebbe non realizzare l'archivio tramite `ptr` tramite self.set_len() non alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Scrivi tutti gli elementi tranne l'ultimo
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Aumenta la lunghezza in ogni passaggio nel caso in cui next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Possiamo scrivere l'ultimo elemento direttamente senza clonare inutilmente
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len impostato dalla guardia di portata
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Rimuove gli elementi ripetuti consecutivi in vector secondo l'implementazione [`PartialEq`] trait.
    ///
    ///
    /// Se vector viene ordinato, vengono rimossi tutti i duplicati.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metodi e funzioni interne
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` deve essere un indice valido
    /// - `self.capacity() - self.len()` deve essere `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len viene aumentato solo dopo aver inizializzato gli elementi
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - caller garantisce che src è un indice valido
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element è stato appena inizializzato con `MaybeUninit::write`, quindi va bene aumentare len
            // - len viene aumentata dopo ogni elemento per evitare perdite (vedere problema #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - il chiamante garantisce che `src` è un indice valido
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Entrambi i puntatori sono creati da riferimenti a slice univoci (`&mut [_]`) quindi sono validi e non si sovrappongono.
            //
            // - Gli elementi sono: Copia quindi va bene copiarli, senza fare nulla con i valori originali
            // - `count` è uguale al len di `source`, quindi la sorgente è valida per le letture `count`
            // - `.reserve(count)` garantisce che `spare.len() >= count` so spare sia valido per le scritture `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Gli elementi sono stati appena inizializzati da `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementazioni trait comuni per Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): con cfg(test) il metodo `[T]::to_vec` intrinseco, richiesto per questa definizione di metodo, non è disponibile.
    // Utilizzare invece la funzione `slice::to_vec` che è disponibile solo con cfg(test) NB vedere il modulo slice::hack in slice.rs per maggiori informazioni
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // eliminare tutto ciò che non verrà sovrascritto
        self.truncate(other.len());

        // self.len <= other.len a causa del troncamento sopra, quindi le sezioni qui sono sempre in-bound.
        //
        let (init, tail) = other.split_at(self.len());

        // riutilizzare i valori contenuti allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Crea un iteratore di consumo, ovvero uno che sposta ogni valore fuori da vector (dall'inizio alla fine).
    /// vector non può essere utilizzato dopo averlo chiamato.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ha il tipo String, non &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metodo foglia a cui delegano varie implementazioni SpecFrom/SpecExtend quando non hanno ulteriori ottimizzazioni da applicare
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Questo è il caso di un iteratore generale.
        //
        // Questa funzione dovrebbe essere l'equivalente morale di:
        //
        //      per l'elemento nell'iteratore {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB non può overflow poiché avremmo dovuto allocare lo spazio degli indirizzi
                self.set_len(len + 1);
            }
        }
    }

    /// Crea un iteratore di giunzione che sostituisce l'intervallo specificato in vector con l'iteratore `replace_with` specificato e restituisce gli elementi rimossi.
    ///
    /// `replace_with` non è necessario che abbia la stessa lunghezza di `range`.
    ///
    /// `range` viene rimosso anche se l'iteratore non viene utilizzato fino alla fine.
    ///
    /// Non è specificato quanti elementi vengono rimossi da vector se il valore `Splice` è trapelato.
    ///
    /// L'iteratore di input `replace_with` viene utilizzato solo quando il valore `Splice` viene eliminato.
    ///
    /// Questo è ottimale se:
    ///
    /// * La coda (elementi in vector dopo `range`) è vuota,
    /// * o `replace_with` restituisce un numero di elementi inferiore o uguale alla lunghezza di "intervallo"
    /// * o il limite inferiore del suo `size_hint()` è esatto.
    ///
    /// In caso contrario, viene allocato uno vector temporaneo e la coda viene spostata due volte.
    ///
    /// # Panics
    ///
    /// Panics se il punto iniziale è maggiore del punto finale o se il punto finale è maggiore della lunghezza di vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Crea un iteratore che utilizza una chiusura per determinare se un elemento deve essere rimosso.
    ///
    /// Se la chiusura restituisce true, l'elemento viene rimosso e restituito.
    /// Se la chiusura restituisce false, l'elemento rimarrà in vector e non verrà restituito dall'iteratore.
    ///
    /// L'utilizzo di questo metodo equivale al codice seguente:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // il tuo codice qui
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Ma `drain_filter` è più facile da usare.
    /// `drain_filter` è anche più efficiente, perché può spostare all'indietro gli elementi dell'array in blocco.
    ///
    /// Nota che `drain_filter` ti consente anche di mutare ogni elemento nella chiusura del filtro, indipendentemente dal fatto che tu scelga di mantenerlo o rimuoverlo.
    ///
    ///
    /// # Examples
    ///
    /// Suddivisione di un array in pari e dispari, riutilizzando l'allocazione originale:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Guardiamoci dalle perdite (amplificazione delle perdite)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Estendi l'implementazione che copia gli elementi dai riferimenti prima di inserirli nel Vec.
///
/// Questa implementazione è specializzata per gli iteratori di slice, dove utilizza [`copy_from_slice`] per aggiungere l'intera slice in una volta.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementa il confronto di vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementa l'ordinamento di vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // usa drop per [T] usa uno slice grezzo per riferirti agli elementi di vector come il tipo più debole necessario;
            //
            // potrebbe evitare questioni di validità in alcuni casi
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec gestisce la deallocazione
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Crea un `Vec<T>` vuoto.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test tira in libstd, che causa errori qui
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test tira in libstd, che causa errori qui
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Ottiene l'intero contenuto di `Vec<T>` come array, se la sua dimensione corrisponde esattamente a quella dell'array richiesto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Se la lunghezza non corrisponde, l'input torna in `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Se stai bene solo per ottenere un prefisso dell `Vec<T>`, puoi chiamare prima [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SICUREZZA: `.set_len(0)` è sempre suono.
        unsafe { vec.set_len(0) };

        // SICUREZZA: Il puntatore di un "Vec" è sempre allineato correttamente, e
        // l'allineamento richiesto dall'array è lo stesso degli elementi.
        // Abbiamo verificato in precedenza di avere articoli sufficienti.
        // Gli elementi non verranno rilasciati due volte poiché l `set_len` dice all `Vec` di non lasciarli cadere anche loro.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}