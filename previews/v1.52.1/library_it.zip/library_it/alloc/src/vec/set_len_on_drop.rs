// Imposta la lunghezza del vec quando il valore `SetLenOnDrop` esce dall'ambito.
//
// L'idea è: il campo della lunghezza in SetLenOnDrop è una variabile locale che l'ottimizzatore vedrà non è alias con nessun archivio tramite il puntatore ai dati del Vec.
// Questa è una soluzione alternativa per il problema di analisi degli alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}