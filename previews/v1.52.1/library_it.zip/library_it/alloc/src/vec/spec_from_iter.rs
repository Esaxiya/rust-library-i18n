use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializzazione trait usata per Vec::from_iter
///
/// ## Il grafico della delega:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Un caso comune è il passaggio di vector in una funzione che si riunisce immediatamente in vector.
        // Possiamo cortocircuitare questo se l'IntoIter non è stato avanzato affatto.
        // Quando è stato avanzato, possiamo anche riutilizzare la memoria e spostare i dati in primo piano.
        // Ma lo facciamo solo quando il Vec risultante non avrebbe più capacità inutilizzata rispetto a crearlo attraverso l'implementazione generica di FromIterator.
        //
        // Questa limitazione non è strettamente necessaria poiché il comportamento di allocazione di Vec è intenzionalmente non specificato.
        // Ma è una scelta conservatrice.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // deve delegare a spec_extend() poiché extend() stesso delega a spec_from per Vec vuoti
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Questo utilizza `iterator.as_slice().to_vec()` poiché spec_extend deve eseguire più passaggi per ragionare sulla capacità finale + lunghezza e quindi fare più lavoro.
// `to_vec()` assegna direttamente l'importo corretto e lo riempie esattamente.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): con cfg(test) il metodo `[T]::to_vec` intrinseco, richiesto per questa definizione di metodo, non è disponibile.
    // Utilizzare invece la funzione `slice::to_vec` che è disponibile solo con cfg(test) NB vedere il modulo slice::hack in slice.rs per maggiori informazioni
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}