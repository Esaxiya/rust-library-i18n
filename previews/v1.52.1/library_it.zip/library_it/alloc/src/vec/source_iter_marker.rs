use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Marcatore di specializzazione per raccogliere una pipeline iteratore in una Vec riutilizzando l'allocazione della sorgente, ad es
/// esecuzione della pipeline in atto.
///
/// Il genitore SourceIter trait è necessario affinché la funzione di specializzazione acceda all'allocazione che deve essere riutilizzata.
/// Ma non è sufficiente che la specializzazione sia valida.
/// Vedi limiti aggiuntivi sull'impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Gli std interni SourceIter/InPlaceIterable traits sono implementati solo da catene di Adapter <Adapter<Adapter<IntoIter>>> (tutti di proprietà di core/std).
// Limiti aggiuntivi sulle implementazioni dell'adattatore (oltre `impl<I: Trait> Trait for Adapter<I>`) dipendono solo da altri traits già contrassegnati come specializzazione traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. il marker non dipende dalla durata dei tipi forniti dall'utente.Modulo il Copy Hole, da cui dipendono già molte altre specializzazioni.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Requisiti aggiuntivi che non possono essere espressi tramite trait bounds.Ci affidiamo invece a const eval:
        // a) nessuno ZST in quanto non ci sarebbe allocazione per il riutilizzo e l'aritmetica dei puntatori panic b) le dimensioni corrispondono come richiesto dal contratto Alloc c) gli allineamenti corrispondono come richiesto dal contratto Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // fallback a implementazioni più generiche
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // usa try-fold da allora
        // - vettorizza meglio per alcuni adattatori iteratori
        // - a differenza della maggior parte dei metodi di iterazione interna, richiede solo un &mut self
        // - ci permette di far passare il puntatore di scrittura attraverso le sue parti interne e di recuperarlo alla fine
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterazione riuscita, non lasciare cadere la testa
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // controlla se il contratto SourceIter è stato confermato avvertenza: se non lo fossero potremmo anche non arrivare a questo punto
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // controlla contratto InPlaceIterable.Ciò è possibile solo se l'iteratore ha avanzato il puntatore di origine.
        // Se utilizza l'accesso non controllato tramite TrustedRandomAccess, il puntatore di origine rimarrà nella sua posizione iniziale e non possiamo usarlo come riferimento
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // rilascia tutti i valori rimanenti alla fine della sorgente ma evita la caduta dell'allocazione stessa una volta che IntoIter esce dall'ambito se il rilascio panics, quindi perdiamo anche tutti gli elementi raccolti in dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // il contratto InPlaceIterable non può essere verificato esattamente qui poiché try_fold ha un riferimento esclusivo al puntatore di origine tutto ciò che possiamo fare è controllare se è ancora nell'intervallo
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}