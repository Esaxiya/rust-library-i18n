use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Un iteratore che utilizza una chiusura per determinare se un elemento deve essere rimosso.
///
/// Questa struttura è creata da [`Vec::drain_filter`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// L'indice dell'elemento che verrà ispezionato dalla prossima chiamata a `next`.
    pub(super) idx: usize,
    /// Il numero di elementi che sono stati prosciugati (removed) finora.
    pub(super) del: usize,
    /// La lunghezza originale di `vec` prima dello scarico.
    pub(super) old_len: usize,
    /// Il predicato del test del filtro.
    pub(super) pred: F,
    /// Un flag che indica che si è verificato un panic nel predicato del test del filtro.
    /// Viene utilizzato come suggerimento nell'implementazione del rilascio per evitare il consumo del resto dell `DrainFilter`.
    /// Tutti gli elementi non elaborati verranno spostati all'indietro nell `vec`, ma nessun ulteriore elemento verrà eliminato o testato dal predicato del filtro.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Restituisce un riferimento all'allocatore sottostante.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Aggiorna l'indice *dopo* che il predicato è stato chiamato.
                // Se l'indice viene aggiornato prima e il predicato panics, l'elemento in questo indice verrebbe perso.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Questo è uno stato piuttosto incasinato e non c'è davvero una cosa ovviamente giusta da fare.
                        // Non vogliamo continuare a provare a eseguire `pred`, quindi spostiamo indietro tutti gli elementi non elaborati e diciamo al vec che esistono ancora.
                        //
                        // Il backshift è necessario per evitare un doppio rilascio dell'ultimo elemento drenato con successo prima di un panic nel predicato.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Tenta di consumare gli elementi rimanenti se il predicato del filtro non è stato ancora preso dal panico.
        // Effettueremo il backshift di tutti gli elementi rimanenti se siamo già stati presi dal panico o se il consumo qui panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}