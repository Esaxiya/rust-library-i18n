use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Un progetto per istanze fittizie di crash test che monitorano eventi particolari.
/// Alcune istanze possono essere configurate su panic a un certo punto.
/// Gli eventi sono `clone`, `drop` o alcuni `query` anonimi.
///
/// I manichini dei crash test sono identificati e ordinati da un id, quindi possono essere usati come chiavi in una BTreeMap.
/// L'implementazione intenzionalmente utilizzata non si basa su nulla di definito in crate, a parte `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Crea un design fittizio per crash test.L `id` determina l'ordine e l'uguaglianza delle istanze.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Crea un'istanza di un manichino per crash test che registra quali eventi sperimenta e, facoltativamente, panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Restituisce quante volte sono state clonate istanze del dummy.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Restituisce il numero di volte in cui le istanze del dummy sono state eliminate.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Restituisce quante volte è stato richiamato il membro `query` di istanze del dummy.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Qualche query anonima, il cui risultato è già stato fornito.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}