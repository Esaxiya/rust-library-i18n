// Questo è un tentativo di implementazione seguendo l'ideale
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Poiché Rust in realtà non ha tipi dipendenti e ricorsione polimorfica, ci accontentiamo di molta insicurezza.
//

// Uno degli obiettivi principali di questo modulo è evitare la complessità trattando l'albero come un contenitore generico (se di forma strana) ed evitando di trattare la maggior parte degli invarianti B-Tree.
//
// In quanto tale, a questo modulo non interessa se le voci sono ordinate, quali nodi possono essere underfull o anche cosa significa underfull.Tuttavia, ci basiamo su alcune invarianti:
//
// - Gli alberi devono avere depth/height uniforme.Ciò significa che ogni percorso fino a una foglia da un dato nodo ha esattamente la stessa lunghezza.
// - Un nodo di lunghezza `n` ha chiavi `n`, valori `n` e fronti `n + 1`.
//   Ciò implica che anche un nodo vuoto ha almeno uno edge.
//   Per un nodo foglia, "having an edge" significa solo che possiamo identificare una posizione nel nodo, poiché i bordi foglia sono vuoti e non necessitano di rappresentazione dei dati.
// In un nodo interno, un edge identifica una posizione e contiene un puntatore a un nodo figlio.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// La rappresentazione sottostante dei nodi foglia e parte della rappresentazione dei nodi interni.
struct LeafNode<K, V> {
    /// Vogliamo essere covarianti in `K` e `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// L'indice di questo nodo nell'array `edges` del nodo padre.
    /// `*node.parent.edges[node.parent_idx]` dovrebbe essere la stessa cosa di `node`.
    /// È garantito che venga inizializzato solo quando `parent` non è nullo.
    parent_idx: MaybeUninit<u16>,

    /// Il numero di chiavi e valori memorizzati da questo nodo.
    len: u16,

    /// Gli array che memorizzano i dati effettivi del nodo.
    /// Solo i primi elementi `len` di ogni array sono inizializzati e validi.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inizializza un nuovo `LeafNode` sul posto.
    unsafe fn init(this: *mut Self) {
        // Come politica generale, lasciamo i campi non inizializzati se possono essere, poiché dovrebbe essere leggermente più veloce e più facile da tracciare in Valgrind.
        //
        unsafe {
            // parent_idx, keys e vals sono tutti forseUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Crea un nuovo `LeafNode` in box.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// La rappresentazione sottostante dei nodi interni.Come con `LeafNode`s, questi dovrebbero essere nascosti dietro`BoxedNode`s per evitare di far cadere chiavi e valori non inizializzati.
/// Qualsiasi puntatore a un `InternalNode` può essere castato direttamente a un puntatore alla porzione `LeafNode` sottostante del nodo, consentendo al codice di agire genericamente sulla foglia e sui nodi interni senza dover nemmeno controllare a quale dei due punta un puntatore.
///
/// Questa proprietà è abilitata dall'uso di `repr(C)`.
///
#[repr(C)]
// gdb_providers.py utilizza questo nome di tipo per l'introspezione.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// I puntatori ai figli di questo nodo.
    /// `len + 1` di questi sono considerati inizializzati e validi, tranne che verso la fine, mentre l'albero è tenuto tramite prestito di tipo `Dying`, alcuni di questi puntatori sono penzoloni.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Crea un nuovo `InternalNode` in box.
    ///
    /// # Safety
    /// Un invariante dei nodi interni è che hanno almeno uno edge inizializzato e valido.
    /// Questa funzione non imposta tale edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Abbiamo solo bisogno di inizializzare i dati;i bordi sono ForseUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Puntatore gestito, non nullo a un nodo.Questo è un puntatore di proprietà a `LeafNode<K, V>` o un puntatore di proprietà a `InternalNode<K, V>`.
///
/// Tuttavia, `BoxedNode` non contiene informazioni su quale dei due tipi di nodi contiene effettivamente e, in parte a causa di questa mancanza di informazioni, non è un tipo separato e non ha distruttore.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Il nodo radice di un albero di proprietà.
///
/// Notare che questo non ha un distruttore e deve essere cancellato manualmente.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Restituisce un nuovo albero di proprietà, con il proprio nodo radice inizialmente vuoto.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` non deve essere zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mutuamente prende in prestito il nodo radice di proprietà.
    /// A differenza di `reborrow_mut`, questo è sicuro perché il valore restituito non può essere utilizzato per distruggere la radice e non possono esserci altri riferimenti all'albero.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Prende in prestito in modo leggermente mutevole il nodo radice di proprietà.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Transizioni irreversibili a un riferimento che consente l'attraversamento e offre metodi distruttivi e poco altro.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Aggiunge un nuovo nodo interno con un singolo edge che punta al nodo radice precedente, rende quel nuovo nodo il nodo radice e lo restituisce.
    /// Ciò aumenta l'altezza di 1 ed è l'opposto di `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, tranne che abbiamo appena dimenticato di essere interni ora:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Rimuove il nodo radice interno, utilizzando il suo primo figlio come nuovo nodo radice.
    /// Poiché è concepito per essere chiamato solo quando il nodo radice ha un solo figlio, non viene eseguita alcuna pulizia su nessuna delle chiavi, valori e altri figli.
    ///
    /// Ciò riduce l'altezza di 1 ed è l'opposto di `push_internal_level`.
    ///
    /// Richiede l'accesso esclusivo all'oggetto `Root` ma non al nodo radice;
    /// non invaliderà altri handle o riferimenti al nodo radice.
    ///
    /// Panics se non esiste un livello interno, cioè se il nodo radice è una foglia.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SICUREZZA: abbiamo affermato di essere interni.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SICUREZZA: abbiamo preso in prestito esclusivamente `self` e il suo tipo di prestito è esclusivo.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SICUREZZA: il primo edge è sempre inizializzato.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` è sempre covariante in `K` e `V`, anche quando `BorrowType` è `Mut`.
// Questo è tecnicamente sbagliato, ma non può comportare alcuna insicurezza a causa dell'uso interno di `NodeRef` perché rimaniamo completamente generici su `K` e `V`.
//
// Tuttavia, ogni volta che un tipo pubblico esegue il wrapping di `NodeRef`, assicurarsi che abbia la varianza corretta.
//
/// Un riferimento a un nodo.
///
/// Questo tipo ha una serie di parametri che controlla il modo in cui agisce:
/// - `BorrowType`: Un tipo fittizio che descrive il tipo di prestito e dura una vita.
///    - Quando questo è `Immut<'a>`, `NodeRef` si comporta più o meno come `&'a Node`.
///    - Quando questo è `ValMut<'a>`, `NodeRef` si comporta più o meno come `&'a Node` per quanto riguarda le chiavi e la struttura ad albero, ma consente anche la coesistenza di molti riferimenti mutabili ai valori in tutto l'albero.
///    - Quando questo è `Mut<'a>`, `NodeRef` si comporta più o meno come `&'a mut Node`, sebbene i metodi di inserimento consentano la coesistenza di un puntatore mutabile a un valore.
///    - Quando questo è `Owned`, `NodeRef` si comporta più o meno come `Box<Node>`, ma non ha un distruttore e deve essere ripulito manualmente.
///    - Quando questo è `Dying`, `NodeRef` si comporta ancora più o meno come `Box<Node>`, ma ha metodi per distruggere l'albero bit per bit, e metodi ordinari, sebbene non contrassegnati come non sicuri da chiamare, possono invocare UB se chiamati in modo errato.
///
///   Poiché qualsiasi `NodeRef` consente la navigazione attraverso l'albero, `BorrowType` si applica effettivamente all'intero albero, non solo al nodo stesso.
/// - `K` e `V`: questi sono i tipi di chiavi e valori memorizzati nei nodi.
/// - `Type`: Può essere `Leaf`, `Internal` o `LeafOrInternal`.
/// Quando questo è `Leaf`, `NodeRef` punta a un nodo foglia, quando questo è `Internal` `NodeRef` punta a un nodo interno e quando questo è `LeafOrInternal` `NodeRef` potrebbe puntare a entrambi i tipi di nodo.
///   `Type` è denominato `NodeType` se utilizzato al di fuori di `NodeRef`.
///
/// Sia `BorrowType` che `NodeType` limitano i metodi che implementiamo per sfruttare l'indipendenza dai tipi statici.Esistono limitazioni nel modo in cui possiamo applicare tali restrizioni:
/// - Per ogni parametro di tipo, possiamo definire solo un metodo genericamente o per un tipo particolare.
/// Ad esempio, non possiamo definire un metodo come `into_kv` genericamente per tutto `BorrowType`, o una volta per tutti i tipi che hanno una durata, perché vogliamo che restituisca riferimenti `&'a`.
///   Pertanto, lo definiamo solo per il tipo meno potente `Immut<'a>`.
/// - Non possiamo ottenere la coercizione implicita da dire `Mut<'a>` a `Immut<'a>`.
///   Pertanto, dobbiamo chiamare esplicitamente `reborrow` su un `NodeRef` più potente per raggiungere un metodo come `into_kv`.
///
/// Tutti i metodi su `NodeRef` che restituiscono una sorta di riferimento, o:
/// - Prendi `self` per valore e restituisci la durata di `BorrowType`.
///   A volte, per invocare un tale metodo, dobbiamo chiamare `reborrow_mut`.
/// - Prendi `self` per riferimento e (implicitly) restituisce la durata di quel riferimento, invece della durata trasportata da `BorrowType`.
/// In questo modo, il controllo del prestito garantisce che l `NodeRef` rimanga preso in prestito fintanto che viene utilizzato il riferimento restituito.
///   I metodi che supportano l'inserimento piegano questa regola restituendo un puntatore grezzo, cioè un riferimento senza durata.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Il numero di livelli che separano il nodo e il livello delle foglie, una costante del nodo che non può essere interamente descritta da `Type` e che il nodo stesso non memorizza.
    /// Abbiamo solo bisogno di memorizzare l'altezza del nodo radice e da esso derivare l'altezza di ogni altro nodo.
    /// Deve essere zero se `Type` è `Leaf` e diverso da zero se `Type` è `Internal`.
    ///
    ///
    height: usize,
    /// Il puntatore alla foglia o al nodo interno.
    /// La definizione di `InternalNode` garantisce che il puntatore sia valido in entrambi i casi.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Decomprimere un riferimento al nodo che è stato impacchettato come `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Espone i dati di un nodo interno.
    ///
    /// Restituisce un ptr grezzo per evitare di invalidare altri riferimenti a questo nodo.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SICUREZZA: il tipo di nodo statico è `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Prende in prestito l'accesso esclusivo ai dati di un nodo interno.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Trova la lunghezza del nodo.Questo è il numero di chiavi o valori.
    /// Il numero di bordi è `len() + 1`.
    /// Si noti che, nonostante sia sicuro, chiamare questa funzione può avere l'effetto collaterale di invalidare i riferimenti modificabili creati dal codice non sicuro.
    ///
    pub fn len(&self) -> usize {
        // Fondamentalmente, accediamo solo al campo `len` qui.
        // Se BorrowType è marker::ValMut, potrebbero esserci riferimenti mutabili in sospeso a valori che non dobbiamo invalidare.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Restituisce il numero di livelli separati dal nodo e dalle foglie.
    /// Altezza zero significa che il nodo è una foglia stessa.
    /// Se immagini alberi con la radice in alto, il numero indica a quale elevazione appare il nodo.
    /// Se immagini alberi con foglie in cima, il numero indica quanto in alto si estende l'albero sopra il nodo.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Elimina temporaneamente un altro riferimento immutabile allo stesso nodo.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Espone la porzione foglia di qualsiasi foglia o nodo interno.
    ///
    /// Restituisce un ptr grezzo per evitare di invalidare altri riferimenti a questo nodo.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Il nodo deve essere valido almeno per la porzione LeafNode.
        // Questo non è un riferimento nel tipo NodeRef perché non sappiamo se dovrebbe essere univoco o condiviso.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Trova il genitore del nodo corrente.
    /// Restituisce `Ok(handle)` se il nodo corrente ha effettivamente un genitore, dove `handle` punta a edge del genitore che punta al nodo corrente.
    ///
    /// Restituisce `Err(self)` se il nodo corrente non ha un genitore, restituendo l `NodeRef` originale.
    ///
    /// Il nome del metodo presuppone che si visualizzano alberi con il nodo radice in cima.
    ///
    /// `edge.descend().ascend().unwrap()` e `node.ascend().unwrap().descend()` dovrebbero entrambi, in caso di successo, non fare nulla.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Dobbiamo utilizzare puntatori non elaborati ai nodi perché, se BorrowType è marker::ValMut, potrebbero esserci riferimenti mutabili in sospeso a valori che non dobbiamo invalidare.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Notare che `self` deve essere non vuoto.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Notare che `self` deve essere non vuoto.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Espone la porzione foglia di qualsiasi foglia o nodo interno in un albero immutabile.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SICUREZZA: non possono esserci riferimenti mutabili in questo albero preso in prestito come `Immut`.
        unsafe { &*ptr }
    }

    /// Prende in prestito una vista nelle chiavi archiviate nel nodo.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Simile a `ascend`, ottiene un riferimento al nodo padre di un nodo, ma rilascia anche il nodo corrente nel processo.
    /// Questo non è sicuro perché il nodo corrente sarà ancora accessibile nonostante sia stato deallocato.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Afferma in modo non sicuro al compilatore l'informazione statica che questo nodo è un `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Afferma in modo non sicuro al compilatore l'informazione statica che questo nodo è un `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Elimina temporaneamente un altro riferimento modificabile allo stesso nodo.Attenzione, poiché questo metodo è molto pericoloso, doppiamente poiché potrebbe non apparire immediatamente pericoloso.
    ///
    /// Poiché i puntatori mutabili possono vagare ovunque intorno all'albero, il puntatore restituito può essere facilmente utilizzato per rendere il puntatore originale penzolante, fuori dai limiti o non valido in base alle regole di prestito in pila.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) prendere in considerazione l'aggiunta di un altro parametro di tipo a `NodeRef` che limita l'uso dei metodi di navigazione sui puntatori reintegrati, prevenendo questa insicurezza.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Prende in prestito l'accesso esclusivo alla porzione foglia di qualsiasi foglia o nodo interno.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SICUREZZA: abbiamo accesso esclusivo all'intero nodo.
        unsafe { &mut *ptr }
    }

    /// Offre l'accesso esclusivo alla porzione foglia di qualsiasi foglia o nodo interno.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SICUREZZA: abbiamo accesso esclusivo all'intero nodo.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Prende in prestito l'accesso esclusivo a un elemento dell'area di archiviazione delle chiavi.
    ///
    /// # Safety
    /// `index` è nei limiti di 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SICUREZZA: il chiamante non sarà in grado di chiamare ulteriori metodi su se stesso
        // fino a quando il riferimento alla fetta chiave non viene eliminato, poiché abbiamo un accesso univoco per la durata del prestito.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Prende in prestito l'accesso esclusivo a un elemento o una porzione dell'area di archiviazione del valore del nodo.
    ///
    /// # Safety
    /// `index` è nei limiti di 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SICUREZZA: il chiamante non sarà in grado di chiamare ulteriori metodi su se stesso
        // fino a quando il riferimento alla sezione del valore non viene eliminato, poiché abbiamo accesso univoco per la durata del prestito.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Prende in prestito l'accesso esclusivo a un elemento o una porzione dell'area di archiviazione del nodo per i contenuti edge.
    ///
    /// # Safety
    /// `index` è nei limiti di 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SICUREZZA: il chiamante non sarà in grado di chiamare ulteriori metodi su se stesso
        // fino a quando il riferimento alla slice edge non viene eliminato, poiché abbiamo un accesso univoco per la durata del prestito.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Il nodo ha più di elementi inizializzati `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Creiamo solo un riferimento all'elemento che ci interessa, per evitare aliasing con riferimenti in sospeso ad altri elementi, in particolare quelli restituiti al chiamante nelle iterazioni precedenti.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Dobbiamo forzare a puntatori di array non dimensionati a causa del problema Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Prende in prestito l'accesso esclusivo alla lunghezza del nodo.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Imposta il collegamento del nodo al suo genitore edge, senza invalidare altri riferimenti al nodo.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Cancella il collegamento della radice al suo genitore edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Aggiunge una coppia chiave-valore alla fine del nodo.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ogni elemento restituito da `range` è un indice edge valido per il nodo.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Aggiunge una coppia chiave-valore e un edge per andare a destra di quella coppia, alla fine del nodo.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Verifica se un nodo è un nodo `Internal` o un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Un riferimento a una coppia chiave-valore specifica o edge all'interno di un nodo.
/// Il parametro `Node` deve essere un `NodeRef`, mentre `Type` può essere `KV` (che indica un handle su una coppia chiave-valore) o `Edge` (che indica un handle su un edge).
///
/// Notare che anche i nodi `Leaf` possono avere handle `Edge`.
/// Invece di rappresentare un puntatore a un nodo figlio, questi rappresentano gli spazi in cui i puntatori figlio andrebbero tra le coppie chiave-valore.
/// Ad esempio, in un nodo con lunghezza 2, ci sarebbero 3 possibili posizioni edge, una a sinistra del nodo, una tra le due coppie e una a destra del nodo.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Non abbiamo bisogno della generalità completa di `#[derive(Clone)]`, poiché l'unica volta in cui `Node` sarà `Clone` è quando è un riferimento immutabile e quindi `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Recupera il nodo che contiene la edge o la coppia chiave-valore a cui punta questo handle.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Restituisce la posizione di questa maniglia nel nodo.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Crea un nuovo handle per una coppia chiave-valore in `node`.
    /// Non sicuro perché il chiamante deve assicurarsi che `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Potrebbe essere un'implementazione pubblica di PartialEq, ma utilizzata solo in questo modulo.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Elimina temporaneamente un'altra maniglia immutabile nella stessa posizione.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Non possiamo usare Handle::new_kv o Handle::new_edge perché non conosciamo il nostro tipo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Asserisce in modo non sicuro al compilatore l'informazione statica che il nodo dell'handle è un `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tira fuori temporaneamente un'altra maniglia modificabile nella stessa posizione.
    /// Attenzione, poiché questo metodo è molto pericoloso, doppiamente poiché potrebbe non apparire immediatamente pericoloso.
    ///
    ///
    /// Per i dettagli, vedere `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Non possiamo usare Handle::new_kv o Handle::new_edge perché non conosciamo il nostro tipo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Crea un nuovo handle per un edge in `node`.
    /// Non sicuro perché il chiamante deve assicurarsi che `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Dato un indice edge dove vogliamo inserire in un nodo pieno di capacità, calcola un indice KV sensibile di uno split point e dove effettuare l'inserimento.
///
/// L'obiettivo del punto di divisione è che la sua chiave e il suo valore finiscano in un nodo genitore;
/// le chiavi, i valori e i bordi a sinistra del punto di divisione diventano il figlio sinistro;
/// le chiavi, i valori e i bordi a destra del punto di divisione diventano il figlio destro.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Problema Rust #74834 cerca di spiegare queste regole simmetriche.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nuova coppia chiave-valore tra le coppie chiave-valore a destra e sinistra di questo edge.
    /// Questo metodo presuppone che ci sia spazio sufficiente nel nodo per l'adattamento della nuova coppia.
    ///
    /// Il puntatore restituito punta al valore inserito.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nuova coppia chiave-valore tra le coppie chiave-valore a destra e sinistra di questo edge.
    /// Questo metodo divide il nodo se non c'è abbastanza spazio.
    ///
    /// Il puntatore restituito punta al valore inserito.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Corregge il puntatore e l'indice padre nel nodo figlio a cui si collega questo edge.
    /// Questo è utile quando l'ordine dei bordi è stato modificato,
    fn correct_parent_link(self) {
        // Crea backpointer senza invalidare altri riferimenti al nodo.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inserisce una nuova coppia chiave-valore e una edge che andrà a destra di quella nuova coppia tra questa edge e la coppia chiave-valore a destra di questa edge.
    /// Questo metodo presuppone che ci sia spazio sufficiente nel nodo per l'adattamento della nuova coppia.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Inserisce una nuova coppia chiave-valore e una edge che andrà a destra di quella nuova coppia tra questa edge e la coppia chiave-valore a destra di questa edge.
    /// Questo metodo divide il nodo se non c'è abbastanza spazio.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inserisce una nuova coppia chiave-valore tra le coppie chiave-valore a destra e sinistra di questo edge.
    /// Questo metodo divide il nodo se non c'è abbastanza spazio e cerca di inserire la parte divisa nel nodo padre in modo ricorsivo, fino a raggiungere la radice.
    ///
    ///
    /// Se il risultato restituito è un `Fit`, il nodo del suo handle può essere il nodo di questo edge o un antenato.
    /// Se il risultato restituito è un `Split`, il campo `left` sarà il nodo radice.
    /// Il puntatore restituito punta al valore inserito.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Trova il nodo puntato da questo edge.
    ///
    /// Il nome del metodo presuppone che si visualizzano alberi con il nodo radice in cima.
    ///
    /// `edge.descend().ascend().unwrap()` e `node.ascend().unwrap().descend()` dovrebbero entrambi, in caso di successo, non fare nulla.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Dobbiamo utilizzare puntatori non elaborati ai nodi perché, se BorrowType è marker::ValMut, potrebbero esserci riferimenti mutabili in sospeso a valori che non dobbiamo invalidare.
        // Non ci sono problemi ad accedere al campo altezza perché quel valore viene copiato.
        // Attenzione che, una volta che il puntatore del nodo è stato dereferenziato, accediamo all'array di bordi con un riferimento (Rust problema #73987) e invalidiamo qualsiasi altro riferimento ao all'interno dell'array, dovrebbe esserci intorno.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Non possiamo chiamare metodi chiave e valore separati, perché la chiamata del secondo invalida il riferimento restituito dal primo.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Sostituisci la chiave e il valore a cui fa riferimento l'handle KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Aiuta le implementazioni di `split` per un particolare `NodeType`, prendendosi cura dei dati foglia.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Divide il nodo sottostante in tre parti:
    ///
    /// - Il nodo viene troncato per contenere solo le coppie chiave-valore a sinistra di questo handle.
    /// - La chiave e il valore a cui punta questo handle vengono estratti.
    /// - Tutte le coppie chiave-valore a destra di questo handle vengono inserite in un nodo appena allocato.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Rimuove la coppia chiave-valore indicata da questo handle e la restituisce, insieme allo edge in cui è collassata la coppia chiave-valore.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Divide il nodo sottostante in tre parti:
    ///
    /// - Il nodo viene troncato per contenere solo i bordi e le coppie chiave-valore a sinistra di questa maniglia.
    /// - La chiave e il valore a cui punta questo handle vengono estratti.
    /// - Tutti i bordi e le coppie chiave-valore a destra di questo handle vengono inseriti in un nodo appena allocato.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Rappresenta una sessione per la valutazione e l'esecuzione di un'operazione di bilanciamento attorno a una coppia chiave-valore interna.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Sceglie un contesto di bilanciamento che coinvolge il nodo da bambino, quindi tra il KV immediatamente a sinistra oa destra nel nodo padre.
    /// Restituisce un `Err` se non è presente alcun genitore.
    /// Panics se il genitore è vuoto.
    ///
    /// Preferisce il lato sinistro, per essere ottimale se il nodo dato è in qualche modo insufficiente, il che significa solo che qui ha meno elementi del fratello sinistro e del fratello destro, se esistono.
    /// In tal caso, l'unione con il fratello sinistro è più veloce, poiché dobbiamo solo spostare gli N elementi del nodo, invece di spostarli a destra e spostare più di N elementi davanti.
    /// Anche rubare al fratello sinistro è in genere più veloce, poiché dobbiamo solo spostare gli N elementi del nodo a destra, invece di spostare almeno N degli elementi del fratello a sinistra.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Restituisce se l'unione è possibile, cioè se c'è abbastanza spazio in un nodo per combinare il KV centrale con entrambi i nodi figli adiacenti.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Esegue un'unione e lascia che una chiusura decida cosa restituire.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SICUREZZA: l'altezza dei nodi da unire è una sotto l'altezza
                // del nodo di questo edge, quindi sopra lo zero, quindi sono interni.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Unisce la coppia chiave-valore del genitore ed entrambi i nodi figlio adiacenti nel nodo figlio sinistro e restituisce il nodo genitore ridotto.
    ///
    ///
    /// Panics a meno che non `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Unisce la coppia chiave-valore del genitore ed entrambi i nodi figlio adiacenti nel nodo figlio sinistro e restituisce quel nodo figlio.
    ///
    ///
    /// Panics a meno che non `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Unisce la coppia chiave-valore del genitore ed entrambi i nodi figlio adiacenti nel nodo figlio sinistro e restituisce l'handle edge in quel nodo figlio dove è finito il figlio monitorato edge,
    ///
    ///
    /// Panics a meno che non `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Rimuove una coppia chiave-valore dal figlio sinistro e la inserisce nell'archivio valori-chiave del genitore, mentre inserisce la vecchia coppia chiave-valore genitore nel figlio destro.
    ///
    /// Restituisce un handle a edge nel figlio destro corrispondente a dove è finito lo edge originale specificato da `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Rimuove una coppia chiave-valore dal figlio di destra e la inserisce nella memoria del valore-chiave del genitore, mentre spinge la vecchia coppia chiave-valore del genitore sul figlio di sinistra.
    ///
    /// Restituisce un handle a edge nel figlio sinistro specificato da `track_left_edge_idx`, che non si è spostato.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Questo ruba in modo simile a `steal_left` ma ruba più elementi contemporaneamente.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assicurati che possiamo rubare in sicurezza.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Spostare i dati foglia.
            {
                // Fai spazio agli elementi rubati nel bambino giusto.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Sposta gli elementi dal figlio sinistro a quello destro.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Sposta la coppia più a sinistra rubata al genitore.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Sposta la coppia chiave-valore del genitore nel figlio di destra.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Fai spazio ai bordi rubati.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ruba i bordi.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Il clone simmetrico di `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Assicurati che possiamo rubare in sicurezza.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Spostare i dati foglia.
            {
                // Sposta la coppia più a destra rubata al genitore.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Sposta la coppia chiave-valore del genitore nel figlio sinistro.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Sposta gli elementi dal figlio destro a quello sinistro.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Riempi il vuoto dove si trovavano gli elementi rubati.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ruba i bordi.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Riempi lo spazio dove erano i bordi rubati.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Rimuove tutte le informazioni statiche che affermano che questo nodo è un nodo `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Rimuove tutte le informazioni statiche che affermano che questo nodo è un nodo `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Verifica se il nodo sottostante è un nodo `Internal` o un nodo `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Sposta il suffisso dopo `self` da un nodo all'altro.`right` deve essere vuoto.
    /// Il primo edge di `right` rimane invariato.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Risultato dell'inserimento, quando un nodo aveva bisogno di espandersi oltre la sua capacità.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodo modificato nell'albero esistente con elementi e bordi che appartengono alla sinistra di `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Qualche chiave e valore separati, da inserire altrove.
    pub kv: (K, V),
    // Nuovo nodo di proprietà, non collegato, con elementi e bordi che appartengono a destra di `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Indica se i riferimenti ai nodi di questo tipo di prestito consentono il passaggio ad altri nodi dell'albero.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // L'attraversamento non è necessario, avviene utilizzando il risultato di `borrow_mut`.
        // Disabilitando l'attraversamento e creando solo nuovi riferimenti alle radici, sappiamo che ogni riferimento del tipo `Owned` è a un nodo radice.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Inserisce un valore in una porzione di elementi inizializzati seguita da un elemento non inizializzato.
///
/// # Safety
/// Lo slice ha più di `idx` elementi.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Rimuove e restituisce un valore da una sezione di tutti gli elementi inizializzati, lasciando un elemento finale non inizializzato.
///
///
/// # Safety
/// Lo slice ha più di `idx` elementi.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Sposta gli elementi in una porzione `distance` posizioni a sinistra.
///
/// # Safety
/// Lo slice ha almeno `distance` elementi.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Sposta gli elementi in una porzione `distance` posizioni a destra.
///
/// # Safety
/// Lo slice ha almeno `distance` elementi.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Sposta tutti i valori da una sezione di elementi inizializzati a una sezione di elementi non inizializzati, lasciando `src` come tutto non inizializzato.
///
/// Funziona come `dst.copy_from_slice(src)` ma non richiede che `T` sia `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;