use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modella un reborrow di qualche riferimento univoco, quando sai che il reborrow e tutti i suoi discendenti (cioè, tutti i puntatori e i riferimenti derivati da esso) non saranno più usati a un certo punto, dopodiché vuoi usare di nuovo il riferimento unico originale .
///
///
/// Il controllo dei prestiti di solito gestisce questo impilamento dei prestiti per te, ma alcuni flussi di controllo che realizzano questo impilamento sono troppo complicati per il compilatore da seguire.
/// Un `DormantMutRef` ti consente di controllare il prestito da solo, pur esprimendo la sua natura impilata e incapsulando il codice del puntatore grezzo necessario per farlo senza un comportamento indefinito.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Acquisisci un prestito unico e lo riprendi immediatamente.
    /// Per il compilatore, la durata del nuovo riferimento è la stessa della durata del riferimento originale, ma prometti di usarlo per un periodo più breve.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SICUREZZA: tratteniamo il prestito per tutta l 'a tramite `_marker`, e lo esponiamo
        // solo questo riferimento, quindi è unico.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Ripristina il prestito univoco inizialmente catturato.
    ///
    /// # Safety
    ///
    /// Il reborrow deve essere terminato, ovvero il riferimento restituito da `new` e tutti i puntatori e riferimenti da esso derivati non devono più essere utilizzati.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SICUREZZA: le nostre condizioni di sicurezza implicano che questo riferimento sia di nuovo unico.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;