use core::intrinsics;
use core::mem;
use core::ptr;

/// Ciò sostituisce il valore dietro il riferimento univoco `v` chiamando la funzione pertinente.
///
///
/// Se si verifica uno panic nella chiusura dell `change`, l'intero processo verrà interrotto.
#[allow(dead_code)] // conservare come illustrazione e per uso future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Questo sostituisce il valore dietro il riferimento univoco `v` chiamando la funzione pertinente e restituisce un risultato ottenuto lungo il percorso.
///
///
/// Se si verifica uno panic nella chiusura dell `change`, l'intero processo verrà interrotto.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}