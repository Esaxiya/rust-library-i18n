use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Aggiunge tutte le coppie chiave-valore dall'unione di due iteratori ascendenti, incrementando una variabile `length` lungo il percorso.Quest'ultimo rende più facile per il chiamante evitare una perdita quando un gestore di drop va in panico.
    ///
    /// Se entrambi gli iteratori producono la stessa chiave, questo metodo elimina la coppia dall'iteratore sinistro e aggiunge la coppia dall'iteratore destro.
    ///
    /// Se vuoi che l'albero finisca in un ordine rigorosamente ascendente, come per un `BTreeMap`, entrambi gli iteratori dovrebbero produrre chiavi in ordine rigorosamente crescente, ciascuna maggiore di tutte le chiavi dell'albero, comprese le chiavi già presenti nell'albero al momento dell'ingresso.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ci prepariamo a unire `left` e `right` in una sequenza ordinata in tempo lineare.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Nel frattempo, costruiamo un albero dalla sequenza ordinata in tempo lineare.
        self.bulk_push(iter, length)
    }

    /// Spinge tutte le coppie chiave-valore alla fine dell'albero, incrementando una variabile `length` lungo il percorso.
    /// Quest'ultimo rende più facile per il chiamante evitare una perdita quando l'iteratore va in panico.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Scorri tutte le coppie chiave-valore, inserendole nei nodi al livello corretto.
        for (key, value) in iter {
            // Prova a inserire la coppia chiave-valore nel nodo foglia corrente.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Non c'è più spazio, sali e spingi lì.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Trovato un nodo con spazio rimasto, premi qui.
                                open_node = parent;
                                break;
                            } else {
                                // Risalire.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Siamo in cima, creiamo un nuovo nodo radice e spingiamolo lì.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Spingere la coppia chiave-valore e la nuova sottostruttura destra.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Scendi di nuovo sulla foglia più a destra.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Aumenta la lunghezza ad ogni iterazione, per assicurarti che la mappa lasci cadere gli elementi aggiunti anche se si fa avanzare il panico dell'iteratore.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Un iteratore per unire due sequenze ordinate in una
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Se due chiavi sono uguali, restituisce la coppia chiave-valore dalla sorgente corretta.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}