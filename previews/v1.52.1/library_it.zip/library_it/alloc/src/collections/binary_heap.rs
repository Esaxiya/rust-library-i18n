//! Una coda prioritaria implementata con un heap binario.
//!
//! L'inserimento e lo scoppio dell'elemento più grande hanno una complessità temporale *O*(log(*n*)).
//! Il controllo dell'elemento più grande è *O*(1).La conversione di un vector in un heap binario può essere eseguita sul posto e ha una complessità *O*(*n*).
//! Un heap binario può anche essere convertito in un vector ordinato sul posto, consentendo di utilizzarlo per un heap *O*(*n*\*log(* n*)) sul posto.
//!
//! # Examples
//!
//! Questo è un esempio più ampio che implementa [Dijkstra's algorithm][dijkstra] per risolvere [shortest path problem][sssp] su [directed graph][dir_graph].
//!
//! Mostra come utilizzare [`BinaryHeap`] con i tipi personalizzati.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // La coda di priorità dipende da `Ord`.
//! // Implementa esplicitamente trait in modo che la coda diventi un min-heap invece di un max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Si noti che capovolgiamo l'ordinamento sui costi.
//!         // In caso di parità confrontiamo le posizioni, questo passaggio è necessario per rendere coerenti le implementazioni di `PartialEq` e `Ord`.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` deve anche essere implementato.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Ogni nodo è rappresentato come un `usize`, per un'implementazione più breve.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algoritmo del cammino minimo di Dijkstra.
//!
//! // Inizia da `start` e usa `dist` per tracciare la distanza più breve corrente da ciascun nodo.Questa implementazione non è efficiente in termini di memoria in quanto potrebbe lasciare nodi duplicati nella coda.
//! //
//! // Utilizza anche `usize::MAX` come valore sentinella, per un'implementazione più semplice.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nodo]=distanza più breve corrente da `start` a `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Siamo a `start`, a costo zero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Esamina prima la frontiera con i nodi di costo inferiore (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // In alternativa avremmo potuto continuare a trovare tutti i percorsi più brevi
//!         if position == goal { return Some(cost); }
//!
//!         // Importante perché potremmo aver già trovato un modo migliore
//!         if cost > dist[position] { continue; }
//!
//!         // Per ogni nodo che possiamo raggiungere, vedi se riusciamo a trovare un modo con un costo inferiore che passa attraverso questo nodo
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // In tal caso, aggiungilo alla frontiera e continua
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Rilassamento, ora abbiamo trovato un modo migliore
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Obiettivo non raggiungibile
//!     None
//! }
//!
//! fn main() {
//!     // Questo è il grafico diretto che useremo.
//!     // I numeri dei nodi corrispondono ai diversi stati e i pesi edge simboleggiano il costo del passaggio da un nodo all'altro.
//!     //
//!     // Nota che i bordi sono unidirezionali.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Il grafico è rappresentato come un elenco di adiacenza in cui ogni indice, corrispondente a un valore di nodo, ha un elenco di archi in uscita.
//!     // Scelto per la sua efficienza.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nodo 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nodo 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nodo 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nodo 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nodo 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Una coda prioritaria implementata con un heap binario.
///
/// Questo sarà un max-heap.
///
/// È un errore logico che un articolo venga modificato in modo tale che l'ordinamento dell'articolo relativo a qualsiasi altro articolo, come determinato da `Ord` trait, cambi mentre si trova nell'heap.
///
/// Ciò è normalmente possibile solo tramite `Cell`, `RefCell`, stato globale, I/O o codice non sicuro.
/// Il comportamento risultante da un tale errore logico non è specificato, ma non si tradurrà in un comportamento indefinito.
/// Ciò potrebbe includere panics, risultati errati, interruzioni, perdite di memoria e mancata terminazione.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // L'inferenza del tipo ci consente di omettere una firma di tipo esplicita (che sarebbe `BinaryHeap<i32>` in questo esempio).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Possiamo usare l'anteprima per guardare l'elemento successivo nell'heap.
/// // In questo caso, non ci sono ancora elementi, quindi otteniamo Nessuno.
/// assert_eq!(heap.peek(), None);
///
/// // Aggiungiamo alcuni punteggi ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Ora l'anteprima mostra l'elemento più importante nell'heap.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Possiamo controllare la lunghezza di un mucchio.
/// assert_eq!(heap.len(), 3);
///
/// // Possiamo iterare sugli elementi nell'heap, sebbene vengano restituiti in ordine casuale.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Se invece inseriamo questi punteggi, dovrebbero tornare in ordine.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Possiamo liberare il mucchio di tutti gli elementi rimanenti.
/// heap.clear();
///
/// // L'heap dovrebbe ora essere vuoto.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// È possibile utilizzare `std::cmp::Reverse` o un'implementazione `Ord` personalizzata per rendere `BinaryHeap` un min-heap.
/// Questo fa sì che `heap.pop()` restituisca il valore più piccolo invece di quello più grande.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Avvolgi i valori in `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Se inseriamo ora questi punteggi, dovrebbero tornare nell'ordine inverso.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Complessità temporale
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Il valore per `push` è un costo previsto;la documentazione del metodo fornisce un'analisi più dettagliata.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struttura che avvolge un riferimento mutevole al più grande elemento su un `BinaryHeap`.
///
///
/// Questo `struct` viene creato con il metodo [`peek_mut`] su [`BinaryHeap`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SICUREZZA: PeekMut viene istanziato solo per gli heap non vuoti.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SICURO: PeekMut viene istanziato solo per gli heap non vuoti
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SICURO: PeekMut viene istanziato solo per gli heap non vuoti
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Rimuove il valore visualizzato dall'heap e lo restituisce.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Crea un `BinaryHeap<T>` vuoto.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Crea un `BinaryHeap` vuoto come max-heap.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Crea un `BinaryHeap` vuoto con una capacità specifica.
    /// Questo prealloca memoria sufficiente per gli elementi `capacity`, in modo che l `BinaryHeap` non debba essere riallocato finché non contiene almeno quel numero di valori.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Restituisce un riferimento modificabile all'elemento più grande nell'heap binario o `None` se è vuoto.
    ///
    /// Note: Se il valore `PeekMut` viene perso, l'heap potrebbe trovarsi in uno stato incoerente.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Complessità temporale
    ///
    /// Se l'elemento viene modificato, la complessità temporale del caso peggiore è *O*(log(*n*)), altrimenti è *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Rimuove l'elemento più grande dall'heap binario e lo restituisce, o `None` se è vuoto.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Complessità temporale
    ///
    /// Il costo nel caso peggiore di `pop` su un heap contenente *n* elementi è *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SICUREZZA: !self.is_empty() significa che self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Inserisce un elemento nell'heap binario.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Complessità temporale
    ///
    /// Il costo previsto di `push`, mediato su ogni possibile ordinamento degli elementi da spingere e su un numero sufficientemente elevato di spinte, è *O*(1).
    ///
    /// Questa è la metrica di costo più significativa quando si inseriscono elementi che *non* sono già presenti in uno schema ordinato.
    ///
    /// La complessità temporale degrada se gli elementi vengono spinti in ordine prevalentemente crescente.
    /// Nel peggiore dei casi, gli elementi vengono inseriti in ordine crescente e il costo ammortizzato per push è *O*(log(*n*)) rispetto a un heap contenente *n* elementi.
    ///
    /// Il costo del caso peggiore di una *singola* chiamata a `push` è *O*(*n*).Il caso peggiore si verifica quando la capacità è esaurita e necessita di un ridimensionamento.
    /// Il costo di ridimensionamento è stato ammortizzato nelle figure precedenti.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SICUREZZA: dal momento che abbiamo inserito un nuovo articolo, significa questo
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Consuma `BinaryHeap` e restituisce un vector nell'ordine (ascending) ordinato.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SICUREZZA: `end` passa da `self.len() - 1` a 1 (entrambi inclusi),
            //  quindi è sempre un indice valido per l'accesso.
            //  È sicuro accedere all'indice 0 (cioè `ptr`), perché
            //  1 <=end <self.len(), che significa self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SICUREZZA: `end` passa da `self.len() - 1` a 1 (entrambi inclusi) quindi:
            //  0 <1 <=fine <= self.len(), 1 <self.len() Che significa 0 <fine e fine <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Le implementazioni di sift_up e sift_down utilizzano blocchi non sicuri per spostare un elemento fuori da vector (lasciando dietro di sé un buco), spostarsi lungo gli altri e riportare l'elemento rimosso nello vector nella posizione finale del foro.
    //
    // Il tipo `Hole` viene utilizzato per rappresentarlo e assicurarsi che il foro sia riempito alla fine del suo ambito, anche su panic.
    // L'uso di un buco riduce il fattore costante rispetto all'utilizzo di scambi, che comporta il doppio delle mosse.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Il chiamante deve garantire che `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Prendi il valore su `pos` e crea un buco.
        // SICUREZZA: il chiamante garantisce che pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SICUREZZA: hole.pos()> start>=0, che significa hole.pos()> 0
            //  e quindi hole.pos(), non posso underflow.
            //  Questo garantisce che genitore <hole.pos() quindi è un indice valido e anche!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SICUREZZA: come sopra
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Prendi un elemento in `pos` e spostalo verso il basso, mentre i suoi figli sono più grandi.
    ///
    ///
    /// # Safety
    ///
    /// Il chiamante deve garantire che `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SICUREZZA: il chiamante garantisce che pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariante ciclo: figlio==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // confronta con il maggiore dei due figli SICUREZZA: figlio <fine, 1 <self.len() e figlio + 1 <fine <= self.len(), quindi sono indici validi.
            //
            //  figlio==2 *hole.pos() + 1!= hole.pos() e figlio + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 o 2* hole.pos() + 2 potrebbe traboccare se T è uno ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // se siamo già in ordine, fermati.
            // SICUREZZA: il bambino ora è il bambino vecchio o il bambino anziano + 1
            //  Abbiamo già dimostrato che entrambi sono <self.len() e!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SICUREZZA: come sopra.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SICUREZZA: &&cortocircuito, il che significa che in
        //  seconda condizione è già vero che child==end, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SICUREZZA: il bambino ha già dimostrato di essere un indice valido e
            //  figlio==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Il chiamante deve garantire che `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SICUREZZA: pos <len è garantita dal chiamante e
        //  ovviamente len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Prendi un elemento in `pos` e spostalo fino in fondo nel mucchio, quindi setaccialo fino alla sua posizione.
    ///
    ///
    /// Note: Questo è più veloce quando l'elemento è noto per essere grande/dovrebbe essere più vicino al fondo.
    ///
    /// # Safety
    ///
    /// Il chiamante deve garantire che `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SICUREZZA: il chiamante garantisce che pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariante ciclo: figlio==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SICUREZZA: bambino <fine, 1 <self.len() e
            //  child + 1 <end <= self.len(), quindi sono indici validi.
            //  figlio==2 *hole.pos() + 1!= hole.pos() e figlio + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 o 2* hole.pos() + 2 potrebbe traboccare se T è uno ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SICUREZZA: come sopra
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SICUREZZA: child==end, 1 <self.len(), quindi è un indice valido
            //  e figlio==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SICUREZZA: pos è la posizione nel foro ed è stata già provata
        //  essere un indice valido.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SICUREZZA: n parte da self.len()/2 e scende a 0.
            //  L'unico caso in cui! (N <self.len()) è se self.len() ==0, ma è escluso dalla condizione del ciclo.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Sposta tutti gli elementi di `other` in `self`, lasciando `other` vuoto.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` prende le operazioni O(len1 + len2) e circa 2 *(len1 + len2) confronti nel caso peggiore mentre `extend` esegue le operazioni O(len2* log(len1)) e circa 1 *len2* log_2(len1) confronti nel caso peggiore, assumendo len1>= len2.
        // Per cumuli più grandi, il punto di crossover non segue più questo ragionamento ed è stato determinato empiricamente.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Restituisce un iteratore che recupera gli elementi in ordine di heap.
    /// Gli elementi recuperati vengono rimossi dall'heap originale.
    /// Gli elementi rimanenti verranno rimossi al rilascio in ordine di heap.
    ///
    /// Note:
    /// * `.drain_sorted()` è *O*(*n*\*log(* n*)); molto più lento di `.drain()`.
    ///   Dovresti usare quest'ultimo per la maggior parte dei casi.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // rimuove tutti gli elementi in ordine di heap
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Conserva solo gli elementi specificati dal predicato.
    ///
    /// In altre parole, rimuovere tutti gli elementi `e` in modo tale che `f(&e)` restituisca `false`.
    /// Gli elementi vengono visitati in ordine non ordinato (e non specificato).
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // mantieni solo i numeri pari
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Restituisce un iteratore che visita tutti i valori nel sottostante vector, in ordine arbitrario.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Stampa 1, 2, 3, 4 in ordine arbitrario
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Restituisce un iteratore che recupera gli elementi in ordine di heap.
    /// Questo metodo utilizza l'heap originale.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Restituisce l'elemento più grande nell'heap binario o `None` se è vuoto.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Complessità temporale
    ///
    /// Il costo è *O*(1) nel peggiore dei casi.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Restituisce il numero di elementi che l'heap binario può contenere senza riallocare.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Si riserva la capacità minima per `additional` esattamente più elementi da inserire nel dato `BinaryHeap`.
    /// Non fa nulla se la capacità è già sufficiente.
    ///
    /// Notare che l'allocatore può dare alla raccolta più spazio di quanto richiede.
    /// Pertanto non si può fare affidamento sulla capacità esattamente minima.
    /// Preferisci [`reserve`] se sono previsti inserimenti future.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `usize`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Riserva capacità per almeno `additional` più elementi da inserire nell `BinaryHeap`.
    /// La collezione può riservare più spazio per evitare frequenti riallocazioni.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `usize`.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Scarta quanta più capacità aggiuntiva possibile.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Scarta la capacità con un limite inferiore.
    ///
    /// La capacità rimarrà grande almeno quanto la lunghezza e il valore fornito.
    ///
    ///
    /// Se la capacità attuale è inferiore al limite inferiore, non è possibile.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Consuma `BinaryHeap` e restituisce vector sottostante in ordine arbitrario.
    ///
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Verrà stampato in un certo ordine
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Restituisce la lunghezza dell'heap binario.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Controlla se l'heap binario è vuoto.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Cancella l'heap binario, restituendo un iteratore sugli elementi rimossi.
    ///
    /// Gli elementi vengono rimossi in ordine arbitrario.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Elimina tutti gli elementi dall'heap binario.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Hole rappresenta un buco in una sezione, ovvero un indice senza valore valido (perché è stato spostato o duplicato).
///
/// In drop, `Hole` ripristinerà la fetta riempiendo la posizione del foro con il valore che era stato originariamente rimosso.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Crea un nuovo `Hole` all'indice `pos`.
    ///
    /// Non sicuro perché pos deve essere all'interno della sezione di dati.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SICURO: il pos dovrebbe essere all'interno della fetta
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Restituisce un riferimento all'elemento rimosso.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Restituisce un riferimento all'elemento in `index`.
    ///
    /// Non sicuro perché l'indice deve essere all'interno della sezione di dati e non uguale a pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Sposta il foro in una nuova posizione
    ///
    /// Non sicuro perché l'indice deve essere all'interno della sezione di dati e non uguale a pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // riempire di nuovo il buco
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Un iteratore sugli elementi di un `BinaryHeap`.
///
/// Questo `struct` è stato creato da [`BinaryHeap::iter()`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Rimuovi a favore di `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Un iteratore proprietario sugli elementi di un `BinaryHeap`.
///
/// Questo `struct` è creato da [`BinaryHeap::into_iter()`] (fornito da `IntoIterator` trait).
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Un iteratore drenante sugli elementi di un `BinaryHeap`.
///
/// Questo `struct` è stato creato da [`BinaryHeap::drain()`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Un iteratore drenante sugli elementi di un `BinaryHeap`.
///
/// Questo `struct` è stato creato da [`BinaryHeap::drain_sorted()`].
/// Vedere la sua documentazione per ulteriori informazioni.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Rimuove gli elementi di heap in ordine di heap.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Converte un `Vec<T>` in un `BinaryHeap<T>`.
    ///
    /// Questa conversione avviene sul posto e ha una complessità temporale *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Converte un `BinaryHeap<T>` in un `Vec<T>`.
    ///
    /// Questa conversione non richiede spostamento o allocazione dei dati e ha una complessità temporale costante.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Crea un iteratore di consumo, ovvero uno che sposta ogni valore fuori dall'heap binario in ordine arbitrario.
    /// L'heap binario non può essere utilizzato dopo averlo chiamato.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Stampa 1, 2, 3, 4 in ordine arbitrario
    /// for x in heap.into_iter() {
    ///     // x ha il tipo i32, non &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}