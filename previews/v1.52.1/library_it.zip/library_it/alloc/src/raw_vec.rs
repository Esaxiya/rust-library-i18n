#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Il contenuto della nuova memoria non è inizializzato.
    Uninitialized,
    /// La nuova memoria è garantita per essere azzerata.
    Zeroed,
}

/// Un'utilità di basso livello per allocare, riallocare e deallocare in modo più ergonomico un buffer di memoria nell'heap senza doversi preoccupare di tutti i casi d'angolo coinvolti.
///
/// Questo tipo è eccellente per costruire le proprie strutture di dati come Vec e VecDeque.
/// In particolare:
///
/// * Produce `Unique::dangling()` su tipi di dimensioni zero.
/// * Produce `Unique::dangling()` su allocazioni di lunghezza zero.
/// * Evita di liberare `Unique::dangling()`.
/// * Cattura tutti gli overflow nei calcoli di capacità (li promuove a "capacity overflow" panics).
/// * Protegge dai sistemi a 32 bit che allocano più di isize::MAX byte.
/// * Protegge dal traboccare della tua lunghezza.
/// * Chiama `handle_alloc_error` per allocazioni fallibili.
/// * Contiene un `ptr::Unique` e quindi fornisce all'utente tutti i vantaggi correlati.
/// * Utilizza l'eccedenza restituita dall'allocatore per utilizzare la maggiore capacità disponibile.
///
/// Questo tipo non ispeziona comunque la memoria che gestisce.Quando viene rilasciato *libererà* la sua memoria, ma *non* tenterà di eliminare il suo contenuto.
/// Spetta all'utente di `RawVec` gestire le cose effettive *memorizzate* all'interno di un `RawVec`.
///
/// Nota che l'eccesso di un tipo di dimensione zero è sempre infinito, quindi `capacity()` restituisce sempre `usize::MAX`.
/// Ciò significa che è necessario fare attenzione quando si esegue il round trip di questo tipo con un `Box<[T]>`, poiché `capacity()` non produrrà la lunghezza.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Questo esiste perché `#[unstable]` `const fn`s non ha bisogno di essere conforme a `min_const_fn` e quindi non possono essere chiamati neanche in`min_const_fn`s.
    ///
    /// Se modifichi `RawVec<T>::new` o le dipendenze, fai attenzione a non introdurre nulla che possa violare veramente `min_const_fn`.
    ///
    /// NOTE: Potremmo evitare questo hack e controllare la conformità con alcuni attributi `#[rustc_force_min_const_fn]` che richiedono la conformità con `min_const_fn` ma non consentono necessariamente di chiamarlo in `stable(...) const fn`/codice utente che non abilita `foo` quando `#[rustc_const_unstable(feature = "foo", issue = "01234")]` è presente.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Crea il più grande `RawVec` possibile (sull'heap di sistema) senza allocare.
    /// Se `T` ha dimensioni positive, allora questo fa un `RawVec` con capacità `0`.
    /// Se `T` è di dimensione zero, crea un `RawVec` con capacità `usize::MAX`.
    /// Utile per implementare l'allocazione ritardata.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Crea un `RawVec` (sull'heap di sistema) con esattamente i requisiti di capacità e allineamento per un `[T; capacity]`.
    /// Ciò equivale a chiamare `RawVec::new` quando `capacity` è `0` o `T` è di dimensione zero.
    /// Nota che se `T` è di dimensione zero significa che *non* otterrai un `RawVec` con la capacità richiesta.
    ///
    /// # Panics
    ///
    /// Panics se la capacità richiesta supera `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Si interrompe su OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Come `with_capacity`, ma garantisce che il buffer sia azzerato.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Ricostituisce un `RawVec` da un puntatore e capacità.
    ///
    /// # Safety
    ///
    /// L `ptr` deve essere allocato (sull'heap di sistema) e con l `capacity` specificato.
    /// `capacity` non può superare `isize::MAX` per i tipi dimensionati.(solo una preoccupazione sui sistemi a 32 bit).
    /// ZST vectors può avere una capacità fino a `usize::MAX`.
    /// Se `ptr` e `capacity` provengono da un `RawVec`, questo è garantito.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // I piccoli Vec sono stupidi.Saltare a:
    // - 8 se la dimensione dell'elemento è 1, perché è probabile che qualsiasi allocatore di heap arrotondi una richiesta inferiore a 8 byte ad almeno 8 byte.
    //
    // - 4 se gli elementi sono di dimensioni moderate (<=1 KiB).
    // - 1 altrimenti, per evitare di sprecare troppo spazio per Vec molto brevi.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Come `new`, ma parametrizzato sulla scelta dell'allocatore per l `RawVec` restituito.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` significa "unallocated".i tipi a dimensione zero vengono ignorati.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Come `with_capacity`, ma parametrizzato sulla scelta dell'allocatore per l `RawVec` restituito.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Come `with_capacity_zeroed`, ma parametrizzato sulla scelta dell'allocatore per l `RawVec` restituito.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Converte un `Box<[T]>` in un `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Converte l'intero buffer in `Box<[MaybeUninit<T>]>` con l `len` specificato.
    ///
    /// Notare che ciò ricostituirà correttamente qualsiasi modifica `cap` che potrebbe essere stata eseguita.(Vedere la descrizione del tipo per i dettagli.)
    ///
    /// # Safety
    ///
    /// * `len` deve essere maggiore o uguale alla capacità richiesta più di recente e
    /// * `len` deve essere minore o uguale a `self.capacity()`.
    ///
    /// Si noti che la capacità richiesta e `self.capacity()` potrebbero differire, in quanto un allocatore potrebbe sovrallocare e restituire un blocco di memoria maggiore di quello richiesto.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Verifica della sanità mentale una metà dei requisiti di sicurezza (non possiamo controllare l'altra metà).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Evitiamo `unwrap_or_else` qui perché aumenta la quantità di IR LLVM generato.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Ricostituisce un `RawVec` da un puntatore, capacità e allocatore.
    ///
    /// # Safety
    ///
    /// L `ptr` deve essere allocato (tramite il dato allocatore `alloc`) e con il dato `capacity`.
    /// `capacity` non può superare `isize::MAX` per i tipi dimensionati.
    /// (solo una preoccupazione sui sistemi a 32 bit).
    /// ZST vectors può avere una capacità fino a `usize::MAX`.
    /// Se `ptr` e `capacity` provengono da un `RawVec` creato tramite `alloc`, ciò è garantito.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Ottiene un puntatore non elaborato all'inizio dell'allocazione.
    /// Nota che questo è `Unique::dangling()` se `capacity == 0` o `T` è di dimensione zero.
    /// Nel primo caso, devi stare attento.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Ottiene la capacità dell'allocazione.
    ///
    /// Sarà sempre `usize::MAX` se `T` è di dimensione zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Restituisce un riferimento condiviso all'allocatore che supporta questo `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Abbiamo una porzione di memoria allocata, quindi possiamo ignorare i controlli di runtime per ottenere il layout corrente.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Assicura che il buffer contenga almeno spazio sufficiente per contenere gli elementi `len + additional`.
    /// Se non ha già una capacità sufficiente, riallocherà spazio sufficiente più spazio libero comodo per ottenere un comportamento *O*(1) ammortizzato.
    ///
    /// Limiterà questo comportamento se si causasse inutilmente panic.
    ///
    /// Se `len` supera `self.capacity()`, potrebbe non riuscire ad allocare effettivamente lo spazio richiesto.
    /// Questo non è veramente pericoloso, ma il codice pericoloso *che* scrivi che si basa sul comportamento di questa funzione potrebbe non funzionare.
    ///
    /// Questo è l'ideale per implementare un'operazione di bulk push come `extend`.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Si interrompe su OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve si sarebbe interrotto o sarebbe andato in panico se il len avesse superato `isize::MAX`, quindi è sicuro farlo deselezionato ora.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Lo stesso di `reserve`, ma restituisce errori invece di farsi prendere dal panico o interrompere.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Assicura che il buffer contenga almeno spazio sufficiente per contenere gli elementi `len + additional`.
    /// Se non lo fa già, riallocherà la quantità minima possibile di memoria necessaria.
    /// Generalmente questa sarà esattamente la quantità di memoria necessaria, ma in linea di principio l'allocatore è libero di restituire più di quanto abbiamo chiesto.
    ///
    ///
    /// Se `len` supera `self.capacity()`, potrebbe non riuscire ad allocare effettivamente lo spazio richiesto.
    /// Questo non è veramente pericoloso, ma il codice pericoloso *che* scrivi che si basa sul comportamento di questa funzione potrebbe non funzionare.
    ///
    /// # Panics
    ///
    /// Panics se la nuova capacità supera `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Si interrompe su OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Lo stesso di `reserve_exact`, ma restituisce errori invece di farsi prendere dal panico o interrompere.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Riduce l'allocazione fino all'importo specificato.
    /// Se l'importo specificato è 0, in realtà viene completamente deallocato.
    ///
    /// # Panics
    ///
    /// Panics se la quantità specificata è *maggiore* della capacità corrente.
    ///
    /// # Aborts
    ///
    /// Si interrompe su OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Restituisce se il buffer deve crescere per soddisfare la capacità aggiuntiva necessaria.
    /// Utilizzato principalmente per rendere possibili chiamate di riserva in linea senza `grow` in linea.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Questo metodo viene solitamente istanziato molte volte.Quindi vogliamo che sia il più piccolo possibile, per migliorare i tempi di compilazione.
    // Ma vogliamo anche che la maggior parte dei suoi contenuti sia calcolabile staticamente possibile, per rendere il codice generato più veloce.
    // Pertanto, questo metodo è scritto con cura in modo che tutto il codice che dipende da `T` sia al suo interno, mentre la maggior parte del codice che non dipende da `T` il più possibile si trova in funzioni che non sono generiche su `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Ciò è garantito dai contesti chiamanti.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Poiché restituiamo una capacità di `usize::MAX` quando `elem_size` è
            // 0, arrivare a qui significa necessariamente che l `RawVec` è troppo pieno.
            return Err(CapacityOverflow);
        }

        // Niente che possiamo fare per questi controlli, purtroppo.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Questo garantisce una crescita esponenziale.
        // Il raddoppio non può eccedere perché `cap <= isize::MAX` e il tipo di `cap` è `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non è generico su `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // I vincoli di questo metodo sono più o meno gli stessi di quelli di `grow_amortized`, ma di solito questo metodo viene istanziato meno spesso, quindi è meno critico.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Poiché restituiamo una capacità di `usize::MAX` quando la dimensione del tipo è
            // 0, arrivare a qui significa necessariamente che l `RawVec` è troppo pieno.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` non è generico su `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Questa funzione è esterna a `RawVec` per ridurre al minimo i tempi di compilazione.Vedere il commento sopra `RawVec::grow_amortized` per i dettagli.
// (Il parametro `A` non è significativo, perché il numero di diversi tipi `A` visti nella pratica è molto inferiore al numero di tipi `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Verificare qui l'errore per ridurre al minimo le dimensioni di `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // L'allocatore verifica l'uguaglianza di allineamento
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Libera la memoria posseduta dall `RawVec`*senza* tentare di eliminare il suo contenuto.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funzione centrale per la gestione degli errori di riserva.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Dobbiamo garantire quanto segue:
// * Non allochiamo mai oggetti di dimensione byte `> isize::MAX`.
// * Non sovraccarichiamo `usize::MAX` e in realtà allochiamo troppo poco.
//
// Su 64 bit dobbiamo solo controllare l'overflow poiché il tentativo di allocare byte `> isize::MAX` fallirà sicuramente.
// Su 32 bit e 16 bit dobbiamo aggiungere una protezione extra per questo nel caso in cui stiamo funzionando su una piattaforma che può utilizzare tutti i 4 GB nello spazio utente, ad esempio PAE o x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Una funzione centrale responsabile della segnalazione degli overflow di capacità.
// Ciò assicurerà che la generazione di codice relativa a questi panics sia minima in quanto c'è solo una posizione in cui panics è piuttosto che un gruppo in tutto il modulo.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}