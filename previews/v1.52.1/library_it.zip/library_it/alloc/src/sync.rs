#![stable(feature = "rust1", since = "1.0.0")]

//! Puntatori per il conteggio dei riferimenti thread-safe.
//!
//! Vedere la documentazione di [`Arc<T>`][Arc] per maggiori dettagli.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Un limite morbido alla quantità di riferimenti che possono essere fatti a un `Arc`.
///
/// Superare questo limite interromperà il programma (anche se non necessariamente) ai riferimenti _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer non supporta i recinti della memoria.
// Per evitare false segnalazioni positive nell'implementazione Arc/Weak, utilizzare invece carichi atomici per la sincronizzazione.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Puntatore per il conteggio dei riferimenti thread-safe.'Arc' sta per "Atomically Reference Counted".
///
/// Il tipo `Arc<T>` fornisce la proprietà condivisa di un valore di tipo `T`, allocato nell'heap.Invocare [`clone`][clone] su `Arc` produce una nuova istanza `Arc`, che punta alla stessa allocazione nell'heap dell `Arc` di origine, aumentando al contempo un conteggio dei riferimenti.
/// Quando l'ultimo puntatore `Arc` a una determinata allocazione viene distrutto, viene eliminato anche il valore memorizzato in tale allocazione (spesso indicato come "inner value").
///
/// I riferimenti condivisi in Rust non consentono la mutazione per impostazione predefinita e `Arc` non fa eccezione: generalmente non è possibile ottenere un riferimento modificabile a qualcosa all'interno di un `Arc`.Se è necessario mutare tramite un `Arc`, utilizzare [`Mutex`][mutex], [`RwLock`][rwlock] o uno dei tipi [`Atomic`][atomic].
///
/// ## Sicurezza del filo
///
/// A differenza di [`Rc<T>`], `Arc<T>` utilizza operazioni atomiche per il conteggio dei riferimenti.Ciò significa che è thread-safe.Lo svantaggio è che le operazioni atomiche sono più costose dei normali accessi alla memoria.Se non si condividono allocazioni conteggiate per riferimento tra thread, considerare l'utilizzo di [`Rc<T>`] per un sovraccarico inferiore.
/// [`Rc<T>`] è un valore predefinito sicuro, perché il compilatore rileverà qualsiasi tentativo di inviare un [`Rc<T>`] tra i thread.
/// Tuttavia, una libreria potrebbe scegliere `Arc<T>` per offrire agli utenti della libreria una maggiore flessibilità.
///
/// `Arc<T>` implementerà [`Send`] e [`Sync`] fintanto che `T` implementerà [`Send`] e [`Sync`].
/// Perché non puoi inserire un tipo `T` non thread-safe in un `Arc<T>` per renderlo thread-safe?All'inizio potrebbe essere un po 'controintuitivo: dopotutto, non è il punto di `Arc<T>` thread safety?La chiave è questa: `Arc<T>` rende thread safe avere più proprietà degli stessi dati, ma non aggiunge thread safety ai suoi dati.
///
/// Considera "Arc <" [`RefCell<T>`]`>`.
/// [`RefCell<T>`] non è [`Sync`], e se `Arc<T>` è sempre stato [`Send`], `Arc <` [`RefCell<T>`]`>`sarebbe anche.
/// Ma poi avremmo un problema:
/// [`RefCell<T>`] non è thread-safe;tiene traccia del conteggio dei prestiti utilizzando operazioni non atomiche.
///
/// Alla fine, questo significa che potrebbe essere necessario accoppiare `Arc<T>` con una sorta di tipo [`std::sync`], di solito [`Mutex<T>`][mutex].
///
/// ## Cicli di rottura con `Weak`
///
/// Il metodo [`downgrade`][downgrade] può essere utilizzato per creare un puntatore [`Weak`] non proprietario.Un puntatore [`Weak`] può essere [`upgrade`][upgrade] d a un `Arc`, ma questo restituirà [`None`] se il valore memorizzato nell'allocazione è già stato eliminato.
/// In altre parole, i puntatori `Weak` non mantengono vivo il valore all'interno dell'allocazione;tuttavia,*mantengono* viva l'allocazione (l'archivio di supporto per il valore).
///
/// Un ciclo tra i puntatori `Arc` non verrà mai deallocato.
/// Per questo motivo, [`Weak`] viene utilizzato per interrompere i cicli.Ad esempio, un albero potrebbe avere forti puntatori `Arc` dai nodi padre ai figli e puntatori [`Weak`] dai figli ai loro genitori.
///
/// # Riferimenti di clonazione
///
/// La creazione di un nuovo riferimento da un puntatore conteggio dei riferimenti esistente viene eseguita utilizzando `Clone` trait implementato per [`Arc<T>`][Arc] e [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Le due sintassi seguenti sono equivalenti.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b e foo sono tutti archi che puntano alla stessa posizione di memoria
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` dereferenzia automaticamente a `T` (tramite [`Deref`][deref] trait), quindi puoi chiamare i metodi di `T` su un valore di tipo `Arc<T>`.Per evitare conflitti di nome con i metodi di `T`, i metodi di `Arc<T>` stesso sono funzioni associate, chiamate usando [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Le implementazioni di traits come `Clone` possono anche essere chiamate utilizzando una sintassi completamente qualificata.
/// Alcune persone preferiscono utilizzare una sintassi completamente qualificata, mentre altre preferiscono utilizzare la sintassi della chiamata al metodo.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintassi della chiamata al metodo
/// let arc2 = arc.clone();
/// // Sintassi completamente qualificata
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] non esegue la dereferenziazione automatica a `T`, perché il valore interno potrebbe essere già stato eliminato.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Condivisione di alcuni dati immutabili tra i thread:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Nota che **non** eseguiamo questi test qui.
// I builder windows diventano super scontenti se un thread sopravvive al thread principale e poi esce allo stesso tempo (qualcosa si blocca), quindi lo evitiamo completamente non eseguendo questi test.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Condivisione di un mutabile [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Vedere [`rc` documentation][rc_examples] per ulteriori esempi di conteggio dei riferimenti in generale.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` è una versione di [`Arc`] che contiene un riferimento non proprietario all'allocazione gestita.
/// Si accede all'assegnazione chiamando [`upgrade`] sul puntatore `Weak`, che restituisce un [`Option`]`<`[`Arc`] `<T>>`.
///
/// Poiché un riferimento `Weak` non viene conteggiato ai fini della proprietà, non impedirà l'eliminazione del valore memorizzato nell'allocazione e `Weak` stesso non garantisce che il valore sia ancora presente.
///
/// Quindi può restituire [`None`] quando [`upgrade`] d.
/// Si noti tuttavia che un riferimento `Weak`*impedisce* la deallocazione dell'allocazione stessa (l'archivio di supporto).
///
/// Un puntatore `Weak` è utile per mantenere un riferimento temporaneo all'allocazione gestita da [`Arc`] senza impedire che il suo valore interno venga eliminato.
/// Viene anche utilizzato per evitare riferimenti circolari tra i puntatori [`Arc`], poiché i riferimenti di proprietà reciproca non consentirebbero mai di eliminare nessuno dei due [`Arc`].
/// Ad esempio, un albero potrebbe avere forti puntatori [`Arc`] dai nodi padre ai figli e puntatori `Weak` dai figli ai loro genitori.
///
/// Il modo tipico per ottenere un puntatore `Weak` è chiamare [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Questo è un `NonNull` per consentire l'ottimizzazione della dimensione di questo tipo in enumerazioni, ma non è necessariamente un puntatore valido.
    //
    // `Weak::new` lo imposta su `usize::MAX` in modo che non sia necessario allocare spazio sull'heap.
    // Questo non è un valore che un puntatore reale avrà mai perché RcBox ha almeno 2 allineamenti.
    // Questo è possibile solo quando `T: Sized`;`T` non dimensionato non penzola mai.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Questo è repr(C) a future a prova di possibile riordino sul campo, che interferirebbe con [into|from]_raw() altrimenti sicuro di tipi interni trasmutabili.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // il valore usize::MAX funge da sentinella per "locking" temporaneamente la capacità di aggiornare i puntatori deboli o declassare quelli forti;questo è usato per evitare gare in `make_mut` e `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Costruisce un nuovo `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Inizia il conteggio del puntatore debole come 1 che è il puntatore debole che è tenuto da tutti i puntatori forti (kinda), vedi std/rc.rs per maggiori informazioni
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Costruisce un nuovo `Arc<T>` utilizzando un riferimento debole a se stesso.
    /// Il tentativo di aggiornare il riferimento debole prima che questa funzione ritorni risulterà in un valore `None`.
    /// Tuttavia, il riferimento debole può essere clonato liberamente e archiviato per essere utilizzato in un secondo momento.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Costruisci l'interno nello stato "uninitialized" con un singolo riferimento debole.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // È importante non rinunciare alla proprietà del puntatore debole, altrimenti la memoria potrebbe essere liberata nel momento in cui `data_fn` ritorna.
        // Se volessimo davvero passare la proprietà, potremmo creare un ulteriore puntatore debole per noi stessi, ma ciò comporterebbe aggiornamenti aggiuntivi al conteggio dei riferimenti deboli che potrebbero non essere necessari altrimenti.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ora possiamo inizializzare correttamente il valore interno e trasformare il nostro riferimento debole in un riferimento forte.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // La scrittura di cui sopra nel campo dati deve essere visibile a tutti i thread che osservano un conteggio forte diverso da zero.
            // Pertanto abbiamo bisogno almeno di un ordine "Release" per sincronizzarci con `compare_exchange_weak` in `Weak::upgrade`.
            //
            // "Acquire" l'ordinazione non è richiesta.
            // Quando si considerano i possibili comportamenti di `data_fn`, dobbiamo solo guardare a cosa potrebbe fare con un riferimento a un `Weak` non aggiornabile:
            //
            // - Può *clonare* l `Weak`, aumentando il conteggio dei riferimenti deboli.
            // - Può eliminare quei cloni, diminuendo il conteggio dei riferimenti deboli (ma mai a zero).
            //
            // Questi effetti collaterali non hanno alcun impatto su di noi e nessun altro effetto collaterale è possibile con il solo codice sicuro.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // I riferimenti forti dovrebbero possedere collettivamente un riferimento debole condiviso, quindi non eseguire il distruttore per il nostro vecchio riferimento debole.
        //
        mem::forget(weak);
        strong
    }

    /// Costruisce un nuovo `Arc` con contenuti non inizializzati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Costruisce un nuovo `Arc` con contenuti non inizializzati, con la memoria riempita con byte `0`.
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Costruisce un nuovo `Pin<Arc<T>>`.
    /// Se `T` non implementa `Unpin`, `data` verrà bloccato in memoria e non potrà essere spostato.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Costruisce un nuovo `Arc<T>`, restituendo un errore se l'allocazione fallisce.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Inizia il conteggio del puntatore debole come 1 che è il puntatore debole che è tenuto da tutti i puntatori forti (kinda), vedi std/rc.rs per maggiori informazioni
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Costruisce un nuovo `Arc` con contenuti non inizializzati, restituendo un errore se l'allocazione fallisce.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Costruisce un nuovo `Arc` con contenuti non inizializzati, con la memoria riempita con byte `0`, restituendo un errore se l'allocazione fallisce.
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Restituisce il valore interno, se `Arc` ha esattamente un riferimento forte.
    ///
    /// In caso contrario, viene restituito un [`Err`] con lo stesso `Arc` passato.
    ///
    ///
    /// Ciò riuscirà anche se ci sono riferimenti deboli in sospeso.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Crea un puntatore debole per ripulire il riferimento forte-debole implicito
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Costruisce una nuova sezione con conteggio dei riferimenti atomici con contenuti non inizializzati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializzazione differita:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Costruisce una nuova sezione con conteggio dei riferimenti atomici con contenuti non inizializzati, con la memoria riempita con `0` byte.
    ///
    ///
    /// Vedere [`MaybeUninit::zeroed`][zeroed] per esempi di utilizzo corretto e non corretto di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Converte in `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Come con [`MaybeUninit::assume_init`], spetta al chiamante garantire che il valore interno sia realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento immediato non definito.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inizializzazione differita:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Converte in `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Come con [`MaybeUninit::assume_init`], spetta al chiamante garantire che il valore interno sia realmente in uno stato inizializzato.
    ///
    /// Chiamarlo quando il contenuto non è ancora completamente inizializzato provoca un comportamento immediato non definito.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inizializzazione differita:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Consuma `Arc`, restituendo il puntatore avvolto.
    ///
    /// Per evitare una perdita di memoria, il puntatore deve essere riconvertito in un `Arc` utilizzando [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Fornisce un puntatore non elaborato ai dati.
    ///
    /// I conteggi non vengono influenzati in alcun modo e l `Arc` non viene consumato.
    /// Il puntatore è valido fintanto che ci sono conteggi forti nell `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SICUREZZA: questo non può passare attraverso Deref::deref o RcBoxPtr::inner perché
        // questo è necessario per mantenere la provenienza raw/mut in modo tale che ad es
        // `get_mut` può scrivere tramite il puntatore dopo che Rc è stato ripristinato tramite `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Costruisce un `Arc<T>` da un puntatore grezzo.
    ///
    /// Il puntatore non elaborato deve essere stato precedentemente restituito da una chiamata a [`Arc<U>::into_raw`][into_raw], dove `U` deve avere la stessa dimensione e allineamento di `T`.
    /// Questo è banalmente vero se `U` è `T`.
    /// Nota che se `U` non è `T` ma ha la stessa dimensione e allineamento, questo è fondamentalmente come trasmettere riferimenti di diversi tipi.
    /// Vedere [`mem::transmute`][transmute] per ulteriori informazioni su quali limitazioni si applicano in questo caso.
    ///
    /// L'utente di `from_raw` deve assicurarsi che un valore specifico di `T` venga eliminato solo una volta.
    ///
    /// Questa funzione non è sicura perché un uso improprio può portare alla sicurezza della memoria, anche se non si accede mai all `Arc<T>` restituito.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Converti di nuovo in un `Arc` per evitare perdite.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ulteriori chiamate a `Arc::from_raw(x_ptr)` non sarebbero sicure per la memoria.
    /// }
    ///
    /// // La memoria è stata liberata quando `x` è uscito dall'ambito di cui sopra, quindi `x_ptr` ora penzola!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Invertire l'offset per trovare l'ArcInner originale.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Crea un nuovo puntatore [`Weak`] a questa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Questo Rilassato va bene perché stiamo controllando il valore nel CAS sottostante.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // controlla se il contatore debole è attualmente "locked";se è così, gira.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: questo codice attualmente ignora la possibilità di overflow
            // in usize::MAX;in generale, sia Rc che Arc devono essere regolati per far fronte all'overflow.
            //

            // A differenza di Clone(), abbiamo bisogno che questa sia una lettura Acquire per sincronizzarsi con la scrittura proveniente da `is_unique`, in modo che gli eventi precedenti a quella scrittura avvengano prima di questa lettura.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Assicurati di non creare un debole penzolante
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Ottiene il numero di puntatori [`Weak`] a questa allocazione.
    ///
    /// # Safety
    ///
    /// Questo metodo di per sé è sicuro, ma utilizzarlo correttamente richiede un'attenzione particolare.
    /// Un altro thread può modificare il conteggio debole in qualsiasi momento, incluso potenzialmente tra la chiamata di questo metodo e l'azione sul risultato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Questa affermazione è deterministica perché non abbiamo condiviso `Arc` o `Weak` tra i thread.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Se il conteggio debole è attualmente bloccato, il valore del conteggio era 0 appena prima di prendere il blocco.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Ottiene il numero di puntatori (`Arc`) efficaci a questa allocazione.
    ///
    /// # Safety
    ///
    /// Questo metodo di per sé è sicuro, ma utilizzarlo correttamente richiede un'attenzione particolare.
    /// Un altro thread può modificare il conteggio forte in qualsiasi momento, incluso potenzialmente tra la chiamata di questo metodo e l'azione sul risultato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Questa affermazione è deterministica perché non abbiamo condiviso l `Arc` tra i thread.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Incrementa di uno il conteggio dei riferimenti forti sull `Arc<T>` associato al puntatore fornito.
    ///
    /// # Safety
    ///
    /// Il puntatore deve essere stato ottenuto tramite `Arc::into_raw` e l'istanza `Arc` associata deve essere valida (ad es
    /// il conteggio forte deve essere almeno 1) per la durata di questo metodo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Questa affermazione è deterministica perché non abbiamo condiviso l `Arc` tra i thread.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Mantieni Arc, ma non toccare refcount avvolgendo ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Ora aumenta il conteggio dei ref, ma non eliminare neanche il nuovo conteggio
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Diminuisce di uno il conteggio dei riferimenti forti sull `Arc<T>` associato al puntatore fornito.
    ///
    /// # Safety
    ///
    /// Il puntatore deve essere stato ottenuto tramite `Arc::into_raw` e l'istanza `Arc` associata deve essere valida (ad es
    /// il conteggio forte deve essere almeno 1) quando si richiama questo metodo.
    /// Questo metodo può essere utilizzato per rilasciare l `Arc` finale e l'archiviazione di backup, ma **non dovrebbe** essere chiamato dopo il rilascio dell `Arc` finale.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Queste affermazioni sono deterministiche perché non abbiamo condiviso l `Arc` tra i thread.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Questa insicurezza va bene perché mentre questo arco è attivo, ci viene garantito che il puntatore interno è valido.
        // Inoltre, sappiamo che la struttura `ArcInner` stessa è `Sync` perché anche i dati interni sono `Sync`, quindi stiamo bene a prestare un puntatore immutabile a questi contenuti.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Parte non inline di `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Distruggi i dati in questo momento, anche se potremmo non liberare l'allocazione della casella stessa (potrebbero esserci ancora punti deboli in giro).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Elimina l'arbitro debole tenuto collettivamente da tutti i riferimenti forti
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Restituisce `true` se i due "Arc" puntano alla stessa allocazione (in una vena simile a [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alloca un `ArcInner<T>` con spazio sufficiente per un valore interno possibilmente non dimensionato in cui il valore ha il layout fornito.
    ///
    /// La funzione `mem_to_arcinner` viene chiamata con il puntatore dati e deve restituire un puntatore (potenzialmente fat) per `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Calcola il layout utilizzando il layout del valore specificato.
        // In precedenza, il layout veniva calcolato sull'espressione `&*(ptr as* const ArcInner<T>)`, ma ciò creava un riferimento disallineato (vedere #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alloca un `ArcInner<T>` con spazio sufficiente per un valore interno possibilmente non dimensionato in cui il valore ha il layout fornito, restituendo un errore se l'allocazione fallisce.
    ///
    ///
    /// La funzione `mem_to_arcinner` viene chiamata con il puntatore dati e deve restituire un puntatore (potenzialmente fat) per `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Calcola il layout utilizzando il layout del valore specificato.
        // In precedenza, il layout veniva calcolato sull'espressione `&*(ptr as* const ArcInner<T>)`, ma ciò creava un riferimento disallineato (vedere #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inizializza ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alloca un `ArcInner<T>` con spazio sufficiente per un valore interno non dimensionato.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Allocare per `ArcInner<T>` utilizzando il valore fornito.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Copia il valore come byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Libera l'assegnazione senza farne cadere il contenuto
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alloca un `ArcInner<[T]>` con la lunghezza data.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Copia gli elementi dalla slice nell'Arco appena allocato <\[T\]>
    ///
    /// Non sicuro perché il chiamante deve assumere la proprietà o associare `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Costruisce un `Arc<[T]>` da un iteratore noto per essere di una certa dimensione.
    ///
    /// Il comportamento non è definito se la dimensione è sbagliata.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic protegge durante la clonazione degli elementi T.
        // In caso di panic, gli elementi che sono stati scritti nel nuovo ArcInner verranno eliminati, quindi la memoria verrà liberata.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Puntatore al primo elemento
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Tutto chiaro.Dimentica la guardia in modo che non liberi il nuovo ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializzazione trait usata per `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Crea un clone del puntatore `Arc`.
    ///
    /// Questo crea un altro puntatore alla stessa allocazione, aumentando il conteggio dei riferimenti forti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // L'uso di un ordinamento rilassato va bene qui, poiché la conoscenza del riferimento originale impedisce ad altri thread di eliminare erroneamente l'oggetto.
        //
        // Come spiegato in [Boost documentation][1], è sempre possibile aumentare il contatore dei riferimenti con memory_order_relaxed: i nuovi riferimenti a un oggetto possono essere formati solo da un riferimento esistente e il passaggio di un riferimento esistente da un thread a un altro deve già fornire la sincronizzazione richiesta.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tuttavia, dobbiamo proteggerci da massicci conteggi nel caso in cui qualcuno stia `mem: : dimentichi` Arcs.
        // Se non lo facciamo, il conteggio può traboccare e gli utenti useranno-after gratuitamente.
        // Ci saturiamo in modo razziale a `isize::MAX` supponendo che non ci siano miliardi di thread ~2 che incrementano il conteggio dei riferimenti contemporaneamente.
        //
        // Questo branch non sarà mai preso in nessun programma realistico.
        //
        // Interrompiamo perché un programma del genere è incredibilmente degenerato e non ci interessa sostenerlo.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Crea un riferimento mutabile nel dato `Arc`.
    ///
    /// Se sono presenti altri puntatori `Arc` o [`Weak`] alla stessa allocazione, `make_mut` creerà una nuova allocazione e richiamerà [`clone`][clone] sul valore interno per garantire la proprietà univoca.
    /// Questo è anche indicato come clone-on-write.
    ///
    /// Notare che questo differisce dal comportamento di [`Rc::make_mut`] che dissocia tutti i rimanenti puntatori `Weak`.
    ///
    /// Vedi anche [`get_mut`][get_mut], che fallirà invece di clonare.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Non clonerà nulla
    /// let mut other_data = Arc::clone(&data); // Non clonerà i dati interni
    /// *Arc::make_mut(&mut data) += 1;         // Clona i dati interni
    /// *Arc::make_mut(&mut data) += 1;         // Non clonerà nulla
    /// *Arc::make_mut(&mut other_data) *= 2;   // Non clonerà nulla
    ///
    /// // Ora `data` e `other_data` puntano a diverse allocazioni.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Notare che abbiamo sia un riferimento forte che un riferimento debole.
        // Pertanto, rilasciare solo il nostro forte riferimento non causerà, di per sé, la deallocazione della memoria.
        //
        // Usa Acquire per assicurarti di vedere eventuali scritture su `weak` che avvengono prima delle scritture di rilascio (cioè decrementi) su `strong`.
        // Dato che abbiamo un conteggio debole, non c'è alcuna possibilità che lo stesso ArcInner possa essere deallocato.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Esiste un altro puntatore forte, quindi dobbiamo clonare.
            // Pre-allocare la memoria per consentire la scrittura diretta del valore clonato.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Rilassato è sufficiente in quanto sopra perché questa è fondamentalmente un'ottimizzazione: corriamo sempre con puntatori deboli che vengono lasciati cadere.
            // Nel peggiore dei casi, finiamo per assegnare un nuovo Arc inutilmente.
            //

            // Abbiamo rimosso l'ultimo riferimento forte, ma ci sono altri arbitri deboli rimanenti.
            // Sposteremo il contenuto in un nuovo Arc e invalideremo gli altri ref deboli.
            //

            // Si noti che non è possibile che la lettura di `weak` restituisca usize::MAX (cioè bloccato), poiché il conteggio debole può essere bloccato solo da un thread con un riferimento forte.
            //
            //

            // Materializza il nostro puntatore debole implicito, in modo che possa ripulire ArcInner secondo necessità.
            //
            let _weak = Weak { ptr: this.ptr };

            // Posso solo rubare i dati, tutto ciò che resta è Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Eravamo l'unico riferimento di entrambi i tipi;ripristinare il forte conteggio ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Come con `get_mut()`, l'insicurezza va bene perché il nostro riferimento era univoco all'inizio o lo è diventato dopo la clonazione dei contenuti.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Restituisce un riferimento modificabile nel dato `Arc`, se non ci sono altri puntatori `Arc` o [`Weak`] alla stessa allocazione.
    ///
    ///
    /// In caso contrario, restituisce [`None`], poiché non è sicuro modificare un valore condiviso.
    ///
    /// Vedi anche [`make_mut`][make_mut], che [`clone`][clone] sarà il valore interno quando ci sono altri puntatori.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Questa insicurezza va bene perché siamo garantiti che il puntatore restituito è il *solo* puntatore che verrà mai restituito a T.
            // Il nostro conteggio dei riferimenti è garantito essere 1 a questo punto, e abbiamo richiesto che l'Arco stesso fosse `mut`, quindi stiamo restituendo l'unico riferimento possibile ai dati interni.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Restituisce un riferimento modificabile nel dato `Arc`, senza alcun controllo.
    ///
    /// Vedi anche [`get_mut`], che è sicuro e fa i controlli appropriati.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Qualsiasi altro puntatore `Arc` o [`Weak`] alla stessa allocazione non deve essere dereferenziato per la durata del prestito restituito.
    ///
    /// Questo è banalmente il caso se non esistono tali puntatori, ad esempio immediatamente dopo `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Stiamo attenti a *non* creare un riferimento che copra i campi "count", poiché questo sarebbe alias con accesso simultaneo ai conteggi dei riferimenti (ad es.
        // di `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Determina se questo è il riferimento univoco (inclusi i riferimenti deboli) ai dati sottostanti.
    ///
    ///
    /// Si noti che ciò richiede il blocco del conteggio ref debole.
    fn is_unique(&mut self) -> bool {
        // blocca il conteggio del puntatore debole se sembriamo essere l'unico titolare del puntatore debole.
        //
        // L'etichetta di acquisizione qui garantisce una relazione "accade prima" con qualsiasi scrittura su `strong` (in particolare in `Weak::upgrade`) prima del decremento del conteggio `weak` (tramite `Weak::drop`, che utilizza il rilascio).
        // Se l'arbitro debole aggiornato non è mai stato eliminato, il CAS qui non funzionerà, quindi non ci interessa sincronizzare.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Deve essere un `Acquire` per sincronizzarsi con il decremento del contatore `strong` in `drop`, l'unico accesso che si verifica quando viene eliminato uno qualsiasi tranne l'ultimo riferimento.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // La scrittura di rilascio qui si sincronizza con una lettura in `downgrade`, impedendo efficacemente che la lettura precedente di `strong` avvenga dopo la scrittura.
            //
            //
            self.inner().weak.store(1, Release); // rilasciare il blocco
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Elimina l `Arc`.
    ///
    /// Ciò diminuirà il conteggio dei riferimenti forti.
    /// Se il conteggio dei riferimenti forti raggiunge lo zero, gli unici altri riferimenti (se presenti) sono [`Weak`], quindi `drop` è il valore interno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Non stampa nulla
    /// drop(foo2);   // Stampa "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Poiché `fetch_sub` è già atomico, non è necessario sincronizzarsi con altri thread a meno che non si elimini l'oggetto.
        // Questa stessa logica si applica al conteggio `fetch_sub` inferiore al conteggio `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Questa barriera è necessaria per impedire il riordino dell'utilizzo dei dati e la cancellazione dei dati.
        // Poiché è contrassegnato con `Release`, la diminuzione del conteggio dei riferimenti si sincronizza con questo fence `Acquire`.
        // Ciò significa che l'utilizzo dei dati avviene prima di diminuire il conteggio dei riferimenti, il che avviene prima di questo fence, il che avviene prima della cancellazione dei dati.
        //
        // Come spiegato nell [Boost documentation][1],
        //
        // > È importante imporre ogni possibile accesso all'oggetto in uno
        // > thread (tramite un riferimento esistente)*che avvenga prima* dell'eliminazione
        // > l'oggetto in un thread diverso.Ciò è ottenuto da un "release"
        // > operazione dopo aver rilasciato un riferimento (qualsiasi accesso all'oggetto
        // > attraverso questo riferimento deve ovviamente accadere prima), e un
        // > "acquire" operazione prima di eliminare l'oggetto.
        //
        // In particolare, mentre i contenuti di un Arc sono solitamente immutabili, è possibile avere scritture interne su qualcosa come un Mutex<T>.
        // Poiché un Mutex non viene acquisito quando viene eliminato, non possiamo fare affidamento sulla sua logica di sincronizzazione per rendere visibili le scritture nel thread A a un distruttore in esecuzione nel thread B.
        //
        //
        // Si noti inoltre che la barriera di acquisizione qui potrebbe essere probabilmente sostituita con un carico di acquisizione, che potrebbe migliorare le prestazioni in situazioni molto contese.Vedi [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Tenta di abbattere l `Arc<dyn Any + Send + Sync>` su un tipo concreto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Costruisce un nuovo `Weak<T>`, senza allocare memoria.
    /// Chiamare [`upgrade`] sul valore di ritorno fornisce sempre [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Tipo di supporto per consentire l'accesso ai conteggi dei riferimenti senza fare affermazioni sul campo dati.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Restituisce un puntatore grezzo all'oggetto `T` puntato da questo `Weak<T>`.
    ///
    /// Il puntatore è valido solo se ci sono dei riferimenti forti.
    /// Il puntatore può essere sospeso, non allineato o addirittura [`null`] in caso contrario.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Entrambi puntano allo stesso oggetto
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Il forte qui lo tiene in vita, quindi possiamo ancora accedere all'oggetto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ma non più.
    /// // Possiamo fare weak.as_ptr(), ma l'accesso al puntatore porterebbe a un comportamento indefinito.
    /// // assert_eq! ("ciao", non sicuro {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Se il puntatore penzola, restituiamo direttamente la sentinella.
            // Questo non può essere un indirizzo di payload valido, poiché il payload è allineato almeno quanto ArcInner (usize).
            ptr as *const T
        } else {
            // SICUREZZA: se is_dangling restituisce false, il puntatore è dereferenziabile.
            // Il carico utile può essere eliminato a questo punto e dobbiamo mantenere la provenienza, quindi usa la manipolazione del puntatore grezzo.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Consuma l `Weak<T>` e lo trasforma in un puntatore grezzo.
    ///
    /// Questo converte il puntatore debole in un puntatore grezzo, pur conservando la proprietà di un riferimento debole (il conteggio debole non viene modificato da questa operazione).
    /// Può essere trasformato di nuovo nell `Weak<T>` con [`from_raw`].
    ///
    /// Si applicano le stesse restrizioni di accesso alla destinazione del puntatore come con [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Converte un puntatore non elaborato precedentemente creato da [`into_raw`] in `Weak<T>`.
    ///
    /// Questo può essere utilizzato per ottenere in sicurezza un riferimento forte (chiamando [`upgrade`] in seguito) o per deallocare il conteggio debole rilasciando `Weak<T>`.
    ///
    /// Prende la proprietà di un riferimento debole (ad eccezione dei puntatori creati da [`new`], poiché questi non possiedono nulla; il metodo funziona ancora su di essi).
    ///
    /// # Safety
    ///
    /// Il puntatore deve aver avuto origine dall [`into_raw`] e deve ancora possedere il suo potenziale riferimento debole.
    ///
    /// È consentito che il conteggio forte sia 0 al momento della chiamata.
    /// Tuttavia, questo assume la proprietà di un riferimento debole attualmente rappresentato come un puntatore grezzo (il conteggio debole non viene modificato da questa operazione) e quindi deve essere accoppiato con una precedente chiamata a [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Diminuisci l'ultimo conteggio debole.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Vedere Weak::as_ptr per il contesto su come viene derivato il puntatore di input.

        let ptr = if is_dangling(ptr as *mut T) {
            // Questo è un debole penzolante.
            ptr as *mut ArcInner<T>
        } else {
            // Altrimenti, ci viene garantito che il puntatore proviene da un debole non intricato.
            // SICUREZZA: data_offset è sicuro da chiamare, poiché ptr fa riferimento a un T.
            let offset = unsafe { data_offset(ptr) };
            // Quindi, invertiamo l'offset per ottenere l'intero RcBox.
            // SICUREZZA: il puntatore ha avuto origine da un debole, quindi questo offset è sicuro.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SICUREZZA: ora abbiamo recuperato il puntatore debole originale, quindi possiamo creare il debole.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Tenta di aggiornare il puntatore `Weak` a un [`Arc`], ritardando l'eliminazione del valore interno in caso di successo.
    ///
    ///
    /// Restituisce [`None`] se il valore interno è stato successivamente eliminato.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Distruggi tutti i puntatori forti.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Usiamo un ciclo CAS per incrementare il conteggio forte invece di un fetch_add poiché questa funzione non dovrebbe mai portare il conteggio dei riferimenti da zero a uno.
        //
        //
        let inner = self.inner()?;

        // Carico rilassato perché qualsiasi scrittura di 0 che possiamo osservare lascia il campo in uno stato permanentemente zero (quindi una lettura "stale" di 0 va bene) e qualsiasi altro valore viene confermato tramite il CAS sottostante.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Vedere i commenti in `Arc::clone` per sapere perché lo facciamo (per `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Rilassato va bene per il caso fallito perché non abbiamo aspettative sul nuovo stato.
            // Acquire è necessario affinché il caso di successo si sincronizzi con `Arc::new_cyclic`, quando il valore interno può essere inizializzato dopo che i riferimenti `Weak` sono già stati creati.
            // In tal caso, ci aspettiamo di osservare il valore completamente inizializzato.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null verificato sopra
                Err(old) => n = old,
            }
        }
    }

    /// Ottiene il numero di puntatori (`Arc`) potenti che puntano a questa allocazione.
    ///
    /// Se `self` è stato creato utilizzando [`Weak::new`], restituirà 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Ottiene un'approssimazione del numero di puntatori `Weak` che puntano a questa allocazione.
    ///
    /// Se `self` è stato creato utilizzando [`Weak::new`], o se non ci sono puntatori forti rimanenti, questo restituirà 0.
    ///
    /// # Accuracy
    ///
    /// A causa dei dettagli di implementazione, il valore restituito può essere disattivato di 1 in entrambe le direzioni quando altri thread stanno manipolando qualsiasi "Arc" o "Debole" che punta alla stessa allocazione.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Poiché abbiamo osservato che c'era almeno un puntatore forte dopo aver letto il conteggio debole, sappiamo che il riferimento debole implicito (presente ogni volta che sono presenti riferimenti forti) era ancora presente quando abbiamo osservato il conteggio debole, e possiamo quindi sottrarlo senza problemi.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Restituisce `None` quando il puntatore è sospeso e non è presente alcun `ArcInner` allocato, (ovvero, quando questo `Weak` è stato creato da `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Stiamo attenti a *non* creare un riferimento che copra il campo "data", poiché il campo potrebbe essere modificato contemporaneamente (ad esempio, se l'ultimo `Arc` viene eliminato, il campo dati verrà rilasciato sul posto).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Restituisce `true` se i due "Debole" puntano alla stessa allocazione (simile a [`ptr::eq`]), o se entrambi non puntano ad alcuna allocazione (perché sono stati creati con `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Poiché questo confronta i puntatori, significa che `Weak::new()` sarà uguale a vicenda, anche se non punta ad alcuna allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Confrontando `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Crea un clone del puntatore `Weak` che punta alla stessa allocazione.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Vedere i commenti in Arc::clone() per sapere perché questo è rilassato.
        // Questo può usare un fetch_add (ignorando il blocco) perché il conteggio debole è bloccato solo dove *non ci sono altri* puntatori deboli esistenti.
        //
        // (Quindi non possiamo eseguire questo codice in questo caso).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Vedere i commenti in Arc::clone() per il motivo per cui lo facciamo (per mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Costruisce un nuovo `Weak<T>`, senza allocare memoria.
    /// Chiamare [`upgrade`] sul valore di ritorno fornisce sempre [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Rilascia il puntatore `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Non stampa nulla
    /// drop(foo);        // Stampa "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Se scopriamo di essere l'ultimo puntatore debole, è tempo di deallocare completamente i dati.Vedere la discussione in Arc::drop() sull'ordinamento della memoria
        //
        // Non è necessario verificare lo stato di blocco qui, perché il conteggio debole può essere bloccato solo se c'era esattamente un riferimento debole, il che significa che la caduta potrebbe essere eseguita solo successivamente su quel riferimento debole rimanente, il che può avvenire solo dopo che il blocco è stato rilasciato.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Stiamo facendo questa specializzazione qui, e non come un'ottimizzazione più generale su `&T`, perché altrimenti aggiungerebbe un costo a tutti i controlli di uguaglianza sui ref.
/// Partiamo dal presupposto che gli `Arc`s siano usati per memorizzare valori grandi, che sono lenti da clonare, ma anche pesanti per verificare l'uguaglianza, facendo sì che questo costo si ripaghi più facilmente.
///
/// È anche più probabile che abbia due cloni `Arc`, che puntano allo stesso valore, rispetto a due `&T`.
///
/// Possiamo farlo solo quando `T: Eq` come `PartialEq` potrebbe essere deliberatamente irriflessivo.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Uguaglianza per due "Arc".
    ///
    /// Due "Arc" sono uguali se i loro valori interni sono uguali, anche se sono memorizzati in un'allocazione diversa.
    ///
    /// Se `T` implementa anche `Eq` (implicando riflessività di uguaglianza), due `Arc` che puntano alla stessa allocazione sono sempre uguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Disuguaglianza per due "Arc".
    ///
    /// Due "Arc" sono disuguali se i loro valori interni non sono uguali.
    ///
    /// Se `T` implementa anche `Eq` (che implica riflessività di uguaglianza), due `Arc` che puntano allo stesso valore non sono mai disuguali.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Confronto parziale per due `Arc`s.
    ///
    /// I due vengono confrontati chiamando `partial_cmp()` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Meno di confronto per due "Arc".
    ///
    /// I due vengono confrontati chiamando `<` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Confronto "Minore o uguale a" per due "Arc".
    ///
    /// I due vengono confrontati chiamando `<=` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Confronto maggiore di per due "Arc".
    ///
    /// I due vengono confrontati chiamando `>` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Confronto "Maggiore o uguale a" per due "Arc".
    ///
    /// I due vengono confrontati chiamando `>=` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Confronto per due `Arc`s.
    ///
    /// I due vengono confrontati chiamando `cmp()` sui loro valori interni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Crea un nuovo `Arc<T>`, con il valore `Default` per `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Alloca una fetta contata come riferimento e riempila clonando gli elementi di "v".
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Assegna un `str` conteggio dei riferimenti e copia `v` al suo interno.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Assegna un `str` conteggio dei riferimenti e copia `v` al suo interno.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Spostare un oggetto boxed in una nuova allocazione con conteggio dei riferimenti.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alloca uno slice contato per riferimento e sposta gli elementi di "v" al suo interno.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Consenti al Vec di liberare la sua memoria, ma non distruggere il suo contenuto
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Prende ogni elemento nell `Iterator` e lo raccoglie in un `Arc<[T]>`.
    ///
    /// # Caratteristiche di performance
    ///
    /// ## Il caso generale
    ///
    /// Nel caso generale, la raccolta in `Arc<[T]>` viene eseguita raccogliendo prima in `Vec<T>`.Cioè, quando si scrive quanto segue:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// questo si comporta come se scrivessimo:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // La prima serie di allocazioni avviene qui.
    ///     .into(); // Una seconda allocazione per `Arc<[T]>` avviene qui.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Questo allocherà tante volte quante sono necessarie per costruire l `Vec<T>` e poi allocherà una volta per trasformare l `Vec<T>` nell `Arc<[T]>`.
    ///
    ///
    /// ## Iteratori di lunghezza nota
    ///
    /// Quando il tuo `Iterator` implementa `TrustedLen` ed è di una dimensione esatta, verrà effettuata una singola allocazione per `Arc<[T]>`.Per esempio:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Qui avviene solo una singola allocazione.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializzazione trait utilizzata per la raccolta in `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Questo è il caso di un iteratore `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SICUREZZA: Dobbiamo assicurarci che l'iteratore abbia una lunghezza esatta e l'abbiamo.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Torna alla normale implementazione.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Ottieni l'offset all'interno di un `ArcInner` per il carico utile dietro un puntatore.
///
/// # Safety
///
/// Il puntatore deve puntare a (e disporre di metadati validi per) un'istanza precedentemente valida di T, ma è consentito eliminare T.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Allinea il valore non dimensionato alla fine di ArcInner.
    // Poiché RcBox è repr(C), sarà sempre l'ultimo campo in memoria.
    // SICUREZZA: poiché gli unici tipi non dimensionati possibili sono gli slice, trait oggetti,
    // ed extern, il requisito di sicurezza dell'ingresso è attualmente sufficiente per soddisfare i requisiti di align_of_val_raw;questo è un dettaglio di implementazione del linguaggio su cui non si può fare affidamento al di fuori di std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}