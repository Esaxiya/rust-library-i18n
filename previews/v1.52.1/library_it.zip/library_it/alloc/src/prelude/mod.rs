//! Il file alloc Prelude
//!
//! Lo scopo di questo modulo è alleviare le importazioni di elementi di uso comune di `alloc` crate aggiungendo un'importazione glob all'inizio dei moduli:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;