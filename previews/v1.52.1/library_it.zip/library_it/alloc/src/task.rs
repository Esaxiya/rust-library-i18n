#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipi e Traits per lavorare con attività asincrone.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// L'implementazione del risveglio di un'attività su un esecutore.
///
/// Questo trait può essere utilizzato per creare un [`Waker`].
/// Un esecutore può definire un'implementazione di questo trait e usarla per costruire un Waker da passare alle attività che vengono eseguite su quell'esecutore.
///
/// Questo trait è un'alternativa ergonomica e sicura per la memoria alla costruzione di un [`RawWaker`].
/// Supporta la progettazione esecutiva comune in cui i dati utilizzati per riattivare un'attività sono archiviati in un [`Arc`].
/// Alcuni esecutori (specialmente quelli per sistemi embedded) non possono utilizzare questa API, motivo per cui [`RawWaker`] esiste come alternativa per quei sistemi.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Una funzione `block_on` di base che prende un future e lo esegue fino al completamento sul thread corrente.
///
/// **Note:** Questo esempio scambia la correttezza con la semplicità.
/// Per evitare deadlock, le implementazioni di livello di produzione dovranno anche gestire chiamate intermedie a `thread::unpark` e invocazioni annidate.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Un waker che risveglia il thread corrente quando viene chiamato.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Esegui future fino al completamento sul thread corrente.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin future in modo che possa essere interrogato.
///     let mut fut = Box::pin(fut);
///
///     // Crea un nuovo contesto da passare a future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Esegui future fino al completamento.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Sveglia questo compito.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Riattiva questo compito senza consumare il risveglio.
    ///
    /// Se un esecutore supporta un modo più economico per svegliarsi senza consumare il waker, dovrebbe sovrascrivere questo metodo.
    /// Per impostazione predefinita, clona [`Arc`] e chiama [`wake`] sul clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SICUREZZA: questo è sicuro perché raw_waker costruisce in modo sicuro
        // un RawWaker di Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Questa funzione privata per costruire un RawWaker viene utilizzata, anziché
// incorporandolo nell `From<Arc<W>> for RawWaker` impl, per garantire che la sicurezza di `From<Arc<W>> for Waker` non dipenda dall'invio corretto di trait, invece entrambi gli impl chiamano questa funzione direttamente ed esplicitamente.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Aumentare il conteggio dei riferimenti dell'arco per clonarlo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Wake by value, spostando l'Arco nella funzione Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Sveglia per riferimento, avvolgi il waker in ManuallyDrop per evitare di farlo cadere
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Diminuire il conteggio dei riferimenti dell'arco in caduta
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}