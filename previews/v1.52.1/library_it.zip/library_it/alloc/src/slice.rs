//! Una vista di dimensioni dinamiche in una sequenza contigua, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Le sezioni sono una vista in un blocco di memoria rappresentato come un puntatore e una lunghezza.
//!
//! ```
//! // affettare un Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // costringere un array a uno slice
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Le sezioni sono modificabili o condivise.
//! Il tipo di slice condiviso è `&[T]`, mentre il tipo di slice modificabile è `&mut [T]`, dove `T` rappresenta il tipo di elemento.
//! Ad esempio, puoi modificare il blocco di memoria a cui punta una porzione modificabile:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Ecco alcune delle cose che questo modulo contiene:
//!
//! ## Structs
//!
//! Esistono diverse strutture utili per le sezioni, come [`Iter`], che rappresenta l'iterazione su una sezione.
//!
//! ## Implementazioni Trait
//!
//! Esistono diverse implementazioni di traits comuni per gli slice.Alcuni esempi includono:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], per le sezioni il cui tipo di elemento è [`Eq`] o [`Ord`].
//! * [`Hash`] - per le sezioni il cui tipo di elemento è [`Hash`].
//!
//! ## Iteration
//!
//! Le sezioni implementano `IntoIterator`.L'iteratore restituisce riferimenti agli elementi slice.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! La sezione modificabile produce riferimenti mutabili agli elementi:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Questo iteratore fornisce riferimenti mutabili agli elementi della sezione, quindi mentre il tipo di elemento della sezione è `i32`, il tipo di elemento dell'iteratore è `&mut i32`.
//!
//!
//! * [`.iter`] e [`.iter_mut`] sono i metodi espliciti per restituire gli iteratori predefiniti.
//! * Ulteriori metodi che restituiscono iteratori sono [`.split`], [`.splitn`], [`.chunks`], [`.windows`] e altri.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Molti degli utilizzi in questo modulo vengono utilizzati solo nella configurazione di prova.
// È più semplice disattivare l'avviso unused_imports piuttosto che risolverli.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Metodi di estensione delle sezioni di base
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) necessario per l'implementazione della macro `vec!` durante il test NB, vedere il modulo `hack` in questo file per maggiori dettagli.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) necessario per l'implementazione di `Vec::clone` durante il test NB, vedere il modulo `hack` in questo file per maggiori dettagli.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Con cfg(test) `impl [T]` non è disponibile, queste tre funzioni sono in realtà metodi che si trovano in `impl [T]` ma non in `core::slice::SliceExt`, dobbiamo fornire queste funzioni per il test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Non dovremmo aggiungere l'attributo inline a questo dato che è usato principalmente nella macro `vec!` e causa la regressione perf.
    // Vedi #71204 per discussioni e risultati perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // gli elementi sono stati contrassegnati come inizializzati nel ciclo seguente
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) è necessario affinché LLVM rimuova i controlli dei limiti e ha un codegen migliore di zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // il vec è stato assegnato e inizializzato sopra almeno per questa lunghezza.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // allocato sopra con la capacità di `s` e inizializzato su `s.len()` in ptr::copy_to_non_overlapping di seguito.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Ordina la fetta.
    ///
    /// Questo ordinamento è stabile (cioè, non riordina elementi uguali) e *O*(*n*\*log(* n*)) caso peggiore.
    ///
    /// Quando applicabile, è preferibile l'ordinamento instabile perché è generalmente più veloce dell'ordinamento stabile e non alloca memoria ausiliaria.
    /// Vedi [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è un merge sort adattivo e iterativo ispirato a [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// È progettato per essere molto veloce nei casi in cui la sezione è quasi ordinata o consiste di due o più sequenze ordinate concatenate una dopo l'altra.
    ///
    ///
    /// Inoltre, alloca una memoria temporanea della metà delle dimensioni di `self`, ma per le sezioni brevi viene utilizzato invece un ordinamento di inserzione non allocante.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Ordina la sezione con una funzione di confronto.
    ///
    /// Questo ordinamento è stabile (cioè, non riordina elementi uguali) e *O*(*n*\*log(* n*)) caso peggiore.
    ///
    /// La funzione di confronto deve definire un ordinamento totale per gli elementi nella sezione.Se l'ordine non è totale, l'ordine degli elementi non è specificato.
    /// Un ordine è un ordine totale se è (per tutti i modelli `a`, `b` e `c`):
    ///
    /// * totale e antisimmetrico: esattamente uno tra `a < b`, `a == b` o `a > b` è vero, e
    /// * transitivo, `a < b` e `b < c` implica `a < c`.Lo stesso deve valere sia per `==` che per `>`.
    ///
    /// Ad esempio, mentre [`f64`] non implementa [`Ord`] perché `NaN != NaN`, possiamo usare `partial_cmp` come nostra funzione di ordinamento quando sappiamo che lo slice non contiene `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Quando applicabile, è preferibile l'ordinamento instabile perché è generalmente più veloce dell'ordinamento stabile e non alloca memoria ausiliaria.
    /// Vedi [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è un merge sort adattivo e iterativo ispirato a [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// È progettato per essere molto veloce nei casi in cui la sezione è quasi ordinata o consiste di due o più sequenze ordinate concatenate una dopo l'altra.
    ///
    /// Inoltre, alloca una memoria temporanea della metà delle dimensioni di `self`, ma per le sezioni brevi viene utilizzato invece un ordinamento di inserzione non allocante.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // smistamento inverso
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Ordina la fetta con una funzione di estrazione chiave.
    ///
    /// Questo ordinamento è stabile (cioè, non riordina elementi uguali) e *O*(*m*\* * n *\* log(*n*)) caso peggiore, dove la funzione chiave è *O*(*m*).
    ///
    /// Per funzioni chiave costose (es
    /// funzioni che non sono semplici accessi a proprietà o operazioni di base), è probabile che [`sort_by_cached_key`](slice::sort_by_cached_key) sia significativamente più veloce, poiché non ricalcola le chiavi degli elementi.
    ///
    ///
    /// Quando applicabile, è preferibile l'ordinamento instabile perché è generalmente più veloce dell'ordinamento stabile e non alloca memoria ausiliaria.
    /// Vedi [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è un merge sort adattivo e iterativo ispirato a [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// È progettato per essere molto veloce nei casi in cui la sezione è quasi ordinata o consiste di due o più sequenze ordinate concatenate una dopo l'altra.
    ///
    /// Inoltre, alloca una memoria temporanea della metà delle dimensioni di `self`, ma per le sezioni brevi viene utilizzato invece un ordinamento di inserzione non allocante.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Ordina la fetta con una funzione di estrazione chiave.
    ///
    /// Durante l'ordinamento, la funzione chiave viene chiamata solo una volta per elemento.
    ///
    /// Questo ordinamento è stabile (cioè, non riordina elementi uguali) e *O*(*m*\* * n *+* n *\* log(*n*)) caso peggiore, dove la funzione chiave è *O*(*m*) .
    ///
    /// Per semplici funzioni chiave (ad esempio, funzioni che sono accessi a proprietà o operazioni di base), [`sort_by_key`](slice::sort_by_key) è probabilmente più veloce.
    ///
    /// # Attuale implementazione
    ///
    /// L'attuale algoritmo è basato su [pattern-defeating quicksort][pdqsort] di Orson Peters, che combina il caso medio veloce di quicksort randomizzato con il caso peggiore veloce di heaport, ottenendo il tempo lineare su slice con determinati pattern.
    /// Usa un po 'di randomizzazione per evitare casi degeneri, ma con un seed fisso per fornire sempre un comportamento deterministico.
    ///
    /// Nel peggiore dei casi, l'algoritmo alloca la memoria temporanea in un `Vec<(K, usize)>` la lunghezza della fetta.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Macro di supporto per l'indicizzazione del nostro vector del tipo più piccolo possibile, per ridurre l'allocazione.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Gli elementi di `indices` sono unici, poiché sono indicizzati, quindi qualsiasi tipo sarà stabile rispetto allo slice originale.
                // Usiamo `sort_unstable` qui perché richiede meno allocazione di memoria.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Copia `self` in un nuovo `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Qui, `s` e `x` possono essere modificati indipendentemente.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Copia `self` in un nuovo `Vec` con un allocatore.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Qui, `s` e `x` possono essere modificati indipendentemente.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, vedere il modulo `hack` in questo file per maggiori dettagli.
        hack::to_vec(self, alloc)
    }

    /// Converte `self` in vector senza cloni o allocazioni.
    ///
    /// Lo vector risultante può essere riconvertito in una casella tramite `Vec<T>metodo `into_boxed_slice` di ''.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` non può più essere utilizzato perché è stato convertito in `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, vedere il modulo `hack` in questo file per maggiori dettagli.
        hack::into_vec(self)
    }

    /// Crea un vector ripetendo uno slice `n` volte.
    ///
    /// # Panics
    ///
    /// Questa funzione panic se la capacità andasse in overflow.
    ///
    /// # Examples
    ///
    /// Utilizzo di base:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// Un panic in caso di overflow:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Se `n` è maggiore di zero, può essere diviso come `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` è il numero rappresentato dal bit '1' più a sinistra di `n` e `rem` è la parte rimanente di `n`.
        //
        //

        // Utilizzo di `Vec` per accedere a `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` la ripetizione viene eseguita raddoppiando `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Se `m > 0`, ci sono bit rimanenti fino all '1' più a sinistra.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ha una capacità di `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) la ripetizione viene eseguita copiando le prime ripetizioni `rem` dallo stesso `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Questo non si sovrappone a partire da `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` è uguale a `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Appiattisce una porzione di `T` in un singolo valore `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Appiattisce una fetta di `T` in un singolo valore `Self::Output`, inserendo un dato separatore tra ciascuno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Appiattisce una fetta di `T` in un singolo valore `Self::Output`, inserendo un dato separatore tra ciascuno.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Restituisce un vector contenente una copia di questa slice in cui ogni byte è mappato al suo equivalente in maiuscolo ASCII.
    ///
    ///
    /// Le lettere ASCII da 'a' a 'z' vengono mappate da 'A' a 'Z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per inserire il valore in lettere maiuscole, utilizzare [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Restituisce un vector contenente una copia di questa slice in cui ogni byte è mappato al suo equivalente in minuscolo ASCII.
    ///
    ///
    /// Le lettere ASCII da 'A' a 'Z' vengono mappate da 'a' a 'z', ma le lettere non ASCII rimangono invariate.
    ///
    /// Per minuscolo il valore sul posto, utilizzare [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Estensione traits per sezioni su tipi di dati specifici
////////////////////////////////////////////////////////////////////////////////

/// Helper trait per [`[T]: : concat`](slice::concat).
///
/// Note: il parametro di tipo `Item` non viene utilizzato in questo trait, ma consente a impls di essere più generico.
/// Senza di esso, otteniamo questo errore:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Questo perché potrebbero esistere tipi `V` con più implement `Borrow<[_]>`, in modo tale da applicare più tipi `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Il tipo risultante dopo la concatenazione
    type Output;

    /// Implementazione di [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait per [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Il tipo risultante dopo la concatenazione
    type Output;

    /// Implementazione di [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementazioni trait standard per le sezioni
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // rilascia qualsiasi cosa nella destinazione che non verrà sovrascritta
        target.truncate(self.len());

        // target.len <= self.len a causa del troncamento sopra, quindi le sezioni qui sono sempre in-bound.
        //
        let (init, tail) = self.split_at(target.len());

        // riutilizzare i valori contenuti allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Inserisce `v[0]` nella sequenza preordinata `v[1..]` in modo che l'intero `v[..]` venga ordinato.
///
/// Questa è la subroutine integrale dell'ordinamento per inserzione.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Ci sono tre modi per implementare l'inserimento qui:
            //
            // 1. Scambia gli elementi adiacenti fino a quando il primo non arriva alla sua destinazione finale.
            //    Tuttavia, in questo modo copiamo i dati più del necessario.
            //    Se gli elementi sono strutture grandi (costose da copiare), questo metodo sarà lento.
            //
            // 2. Ripeti fino a trovare il posto giusto per il primo elemento.
            // Quindi sposta gli elementi successivi per fargli spazio e infine posizionalo nel foro rimanente.
            // Questo è un buon metodo.
            //
            // 3. Copia il primo elemento in una variabile temporanea.Ripeti finché non trovi il posto giusto.
            // Mentre procediamo, copia ogni elemento attraversato nello slot che lo precede.
            // Infine, copia i dati dalla variabile temporanea nel foro rimanente.
            // Questo metodo è molto buono.
            // I benchmark hanno dimostrato prestazioni leggermente migliori rispetto al secondo metodo.
            //
            // Tutti i metodi sono stati confrontati e il 3° ha mostrato i migliori risultati.Quindi abbiamo scelto quello.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Lo stato intermedio del processo di inserimento è sempre tracciato da `hole`, che ha due scopi:
            // 1. Protegge l'integrità di `v` da panics in `is_less`.
            // 2. Alla fine riempie il buco rimanente in `v`.
            //
            // Sicurezza Panic:
            //
            // Se `is_less` panics in qualsiasi momento durante il processo, `hole` verrà lasciato cadere e riempirà il buco in `v` con `tmp`, assicurandosi così che `v` trattiene ancora ogni oggetto inizialmente tenuto esattamente una volta.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` viene lasciato cadere e quindi copia `tmp` nel foro rimanente in `v`.
        }
    }

    // Quando viene rilasciato, copia da `src` a `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Unisce le esecuzioni non decrescenti `v[..mid]` e `v[mid..]` utilizzando `buf` come memoria temporanea e memorizza il risultato in `v[..]`.
///
/// # Safety
///
/// Le due sezioni devono essere non vuote e `mid` deve essere nei limiti.
/// Il buffer `buf` deve essere sufficientemente lungo da contenere una copia della sezione più corta.
/// Inoltre, `T` non deve essere un tipo di dimensione zero.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Il processo di unione copia prima la corsa più breve in `buf`.
    // Quindi traccia la corsa appena copiata e la corsa più lunga in avanti (o all'indietro), confrontando i loro successivi elementi non consumati e copiando quello minore (o maggiore) in `v`.
    //
    // Non appena la corsa più breve è completamente consumata, il processo è terminato.Se la corsa più lunga viene consumata per prima, dobbiamo copiare ciò che resta della corsa più breve nel foro rimanente in `v`.
    //
    // Lo stato intermedio del processo è sempre tracciato da `hole`, che ha due scopi:
    // 1. Protegge l'integrità di `v` da panics in `is_less`.
    // 2. Riempie il buco rimanente in `v` se la corsa più lunga viene consumata per prima.
    //
    // Sicurezza Panic:
    //
    // Se `is_less` panics in qualsiasi momento durante il processo, `hole` verrà lasciato cadere e riempirà il buco in `v` con l'intervallo non consumato in `buf`, assicurando così che `v` trattiene ancora ogni oggetto inizialmente tenuto esattamente una volta.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // La corsa a sinistra è più breve.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Inizialmente, questi puntatori puntano all'inizio dei loro array.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Consuma il lato minore.
            // Se uguale, preferisci la corsa a sinistra per mantenere la stabilità.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // La corsa giusta è più breve.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Inizialmente, questi puntatori puntano oltre le estremità dei loro array.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Consuma il lato migliore.
            // Se uguale, preferisci la corsa giusta per mantenere la stabilità.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Infine, `hole` viene abbandonato.
    // Se la corsa più breve non è stata completamente consumata, ciò che ne rimane verrà ora copiato nel foro in `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Quando viene rilasciato, copia l'intervallo `start..end` in `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` non è un tipo di dimensione zero, quindi va bene dividere per la sua dimensione.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Questo tipo di unione prende in prestito alcune (ma non tutte) idee da TimSort, che è descritto in dettaglio [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// L'algoritmo identifica le sottosequenze rigorosamente discendenti e non discendenti, chiamate sequenze naturali.C'è una pila di esecuzioni in sospeso ancora da unire.
/// Ogni nuova serie trovata viene inserita nella pila, quindi alcune coppie di sequenze adiacenti vengono unite fino a quando queste due invarianti non sono soddisfatte:
///
/// 1. per ogni `i` in `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. per ogni `i` in `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Gli invarianti assicurano che il tempo di esecuzione totale sia *O*(*n*\*log(* n*)) caso peggiore.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Le sezioni fino a questa lunghezza vengono ordinate utilizzando l'ordinamento per inserzione.
    const MAX_INSERTION: usize = 20;
    // Esecuzioni molto brevi vengono estese utilizzando l'ordinamento per inserzione per estendere almeno questo numero di elementi.
    const MIN_RUN: usize = 10;

    // L'ordinamento non ha un comportamento significativo sui tipi di dimensione zero.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Gli array brevi vengono ordinati sul posto tramite l'ordinamento per inserzione per evitare allocazioni.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Alloca un buffer da utilizzare come memoria di lavoro.Manteniamo la lunghezza 0 in modo da poter mantenere copie superficiali del contenuto di `v` senza rischiare che i dtors funzionino su copie se `is_less` panics.
    //
    // Quando si uniscono due analisi ordinate, questo buffer contiene una copia della corsa più breve, che avrà sempre una lunghezza al massimo `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Per identificare i percorsi naturali in `v`, lo attraversiamo all'indietro.
    // Potrebbe sembrare una decisione strana, ma considera il fatto che le fusioni più spesso vanno nella direzione opposta (forwards).
    // Secondo i benchmark, l'unione in avanti è leggermente più veloce della fusione all'indietro.
    // Per concludere, l'identificazione delle corse attraversando all'indietro migliora le prestazioni.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Trova la prossima corsa naturale e invertiscila se è rigorosamente discendente.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Inserisci altri elementi nella corsa se è troppo breve.
        // L'ordinamento per inserzione è più veloce dell'ordinamento per unione su sequenze brevi, quindi migliora notevolmente le prestazioni.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Spingi questa corsa in pila.
        runs.push(Run { start, len: end - start });
        end = start;

        // Unisci alcune coppie di sequenze adiacenti per soddisfare gli invarianti.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Infine, esattamente una corsa deve rimanere nella pila.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Esamina la pila di esecuzioni e identifica la successiva coppia di esecuzioni da unire.
    // Più specificamente, se viene restituito `Some(r)`, significa che `runs[r]` e `runs[r + 1]` devono essere uniti successivamente.
    // Se invece l'algoritmo deve continuare a creare una nuova corsa, viene restituito `None`.
    //
    // TimSort è famigerato per le sue implementazioni buggate, come descritto qui:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Il succo della storia è: dobbiamo applicare gli invarianti nelle prime quattro serie dello stack.
    // Applicarli solo ai primi tre non è sufficiente per garantire che gli invarianti continueranno a valere per *tutte* le esecuzioni nello stack.
    //
    // Questa funzione controlla correttamente gli invarianti per le prime quattro serie.
    // Inoltre, se l'esecuzione superiore inizia dall'indice 0, richiederà sempre un'operazione di unione fino a quando lo stack non sarà completamente compresso, al fine di completare l'ordinamento.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}