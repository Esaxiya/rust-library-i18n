# Contribuire a stdarch

L `stdarch` crate è più che disposto ad accettare contributi!Per prima cosa probabilmente vorrai controllare il repository e assicurarti che i test passino per te:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Dove `<your-target-arch>` è la tripla di destinazione utilizzata da `rustup`, ad esempio `x86_x64-unknown-linux-gnu` (senza `nightly-` precedente o simile).
Ricorda anche che questo repository richiede il canale notturno di Rust!
I test precedenti richiedono infatti che rust notturno sia l'impostazione predefinita sul sistema, per impostare l'utilizzo di `rustup default nightly` (e `rustup default stable` per il ripristino).

Se uno qualsiasi dei passaggi precedenti non funziona, [please let us know][new]!

Successivamente puoi aiutare [find an issue][issues], ne abbiamo selezionati alcuni con i tag [`help wanted`][help] e [`impl-period`][impl] che potrebbero in particolare utilizzare un po 'di aiuto. 
Potresti essere più interessato a [#40][vendor], che implementa tutti gli elementi intrinseci del fornitore su x86.Questo problema ha alcune buone indicazioni su dove iniziare!

Se hai domande generali, sentiti libero su [join us on gitter][gitter] e chiedi in giro!Sentiti libero di inviare domande a@BurntSushi o@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Come scrivere esempi per gli intrinseci stdarch

Ci sono alcune funzionalità che devono essere abilitate affinché l'intrinseco dato funzioni correttamente e l'esempio deve essere eseguito da `cargo test --doc` solo quando la funzione è supportata dalla CPU.

Di conseguenza, l `fn main` predefinito generato da `rustdoc` non funzionerà (nella maggior parte dei casi).
Considera l'idea di utilizzare quanto segue come guida per assicurarti che il tuo esempio funzioni come previsto.

```rust
/// # // Abbiamo bisogno di cfg_target_feature per assicurarci che l'esempio sia solo
/// # // eseguito da `cargo test --doc` quando la CPU supporta la funzione
/// # #![feature(cfg_target_feature)]
/// # // Abbiamo bisogno di target_feature affinché l'intrinsic funzioni
/// # #![feature(target_feature)]
/// #
/// # // rustdoc di default usa `extern crate stdarch`, ma abbiamo bisogno del file
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // La vera funzione principale
/// # fn main() {
/// #     // Eseguilo solo se `<target feature>` è supportato
/// #     se cfg_feature_enabled! ("<target feature>"){
/// #         // Crea una funzione `worker` che verrà eseguita solo se la funzione di destinazione
/// #         // è supportato e assicurati che `target_feature` sia abilitato per il tuo lavoratore
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         unsafe fn worker() {
/// // Scrivi qui il tuo esempio.Le caratteristiche intrinseche specifiche funzioneranno qui!Scatenati!
///
/// #         }
///
/// #         non sicuro { worker(); }
/// #     }
/// # }
```

Se alcune delle sintassi precedenti non sembrano familiari, la sezione [Documentation as tests] di [Rust Book] descrive abbastanza bene la sintassi di `rustdoc`.
Come sempre, sentiti libero su [join us on gitter][gitter] e chiedici se riscontri problemi e grazie per aver contribuito a migliorare la documentazione di `stdarch`!

# Istruzioni di test alternative

In genere si consiglia di utilizzare `ci/run.sh` per eseguire i test.
Tuttavia questo potrebbe non funzionare per te, ad esempio se sei su Windows.

In tal caso puoi tornare a eseguire `cargo +nightly test` e `cargo +nightly test --release -p core_arch` per testare la generazione del codice.
Nota che questi richiedono l'installazione della toolchain notturna e che `rustc` sappia della tripla di destinazione e della sua CPU.
In particolare è necessario impostare la variabile d'ambiente `TARGET` come faresti per `ci/run.sh`.
Inoltre è necessario impostare `RUSTCFLAGS` (è necessario `C`) per indicare le caratteristiche di destinazione, ad es `RUSTCFLAGS="-C -target-features=+avx2"`.
Puoi anche impostare `-C -target-cpu=native` se stai sviluppando "just" sulla tua attuale CPU.

Tieni presente che quando usi queste istruzioni alternative, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ad es
i test di generazione delle istruzioni potrebbero non riuscire perché il disassemblatore li ha denominati in modo diverso, ad es
può generare istruzioni `vaesenc` invece di `aesenc` nonostante si comportino allo stesso modo.
Inoltre queste istruzioni eseguono meno test di quanto sarebbe normalmente fatto, quindi non sorprenderti se alla fine richiedi pull alcuni errori potrebbero essere visualizzati per i test non trattati qui.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






