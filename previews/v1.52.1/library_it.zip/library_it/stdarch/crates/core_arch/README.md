`core::arch` - Elementi intrinseci specifici dell'architettura della libreria principale di Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Il modulo `core::arch` implementa elementi intrinseci dipendenti dall'architettura (ad esempio SIMD).

# Usage 

`core::arch` è disponibile come parte di `libcore` ed è riesportato da `libstd`.Preferisco usarlo tramite `core::arch` o `std::arch` piuttosto che tramite questo crate.
Le funzionalità instabili sono spesso disponibili in Rust notturno tramite `feature(stdsimd)`.

L'utilizzo di `core::arch` tramite questo crate richiede Rust notturno e può (e si interrompe) spesso.Gli unici casi in cui dovresti considerare di utilizzarlo tramite questo crate sono:

* se è necessario ricompilare `core::arch` da soli, ad esempio con particolari funzionalità di destinazione abilitate che non sono abilitate per `libcore`/`libstd`.
Note: se hai bisogno di ricompilarlo per un target non standard, preferisci usare `xargo` e ricompilare `libcore`/`libstd` come appropriato invece di usare questo crate.
  
* utilizzando alcune funzionalità che potrebbero non essere disponibili anche dietro funzionalità Rust instabili.Cerchiamo di mantenerli al minimo.
Se è necessario utilizzare alcune di queste funzionalità, aprire un numero in modo da poterle esporre in Rust notturno e utilizzarle da lì.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` è distribuito principalmente sotto i termini sia della licenza MIT che della licenza Apache (versione 2.0), con parti coperte da varie licenze simili a BSD.

Vedere LICENSE-APACHE e LICENSE-MIT per i dettagli.

# Contribution

A meno che tu non dichiari esplicitamente diversamente, qualsiasi contributo da te presentato intenzionalmente per l'inclusione in `core_arch`, come definito nella licenza Apache-2.0, sarà concesso in doppia licenza come sopra, senza termini o condizioni aggiuntivi.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












