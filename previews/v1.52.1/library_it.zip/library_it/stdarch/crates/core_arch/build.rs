use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Usato per dire alle nostre annotazioni `#[assert_instr]` che tutti gli intrinseci simd sono disponibili per testare il loro codegen, poiché alcuni sono controllati dietro un `-Ctarget-feature=+unimplemented-simd128` extra che non ha alcun equivalente in `#[target_feature]` in questo momento.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}