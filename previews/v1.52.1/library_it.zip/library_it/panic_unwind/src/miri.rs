//! Svolgimento di panics per Miri.
use alloc::boxed::Box;
use core::any::Any;

// Il tipo di carico utile che il motore Miri propaga durante lo svolgimento per noi.
// Deve avere le dimensioni di un puntatore.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funzione esterna fornita da Miri per iniziare a rilassarsi.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Il payload che passiamo a `miri_start_panic` sarà esattamente l'argomento che otteniamo in `cleanup` di seguito.
    // Quindi lo inscatoliamo solo una volta, per ottenere qualcosa delle dimensioni di un puntatore.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Recupera l `Box` sottostante.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}