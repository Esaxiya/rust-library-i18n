//! Implementazione di panics supportata da libgcc/libunwind (in qualche forma).
//!
//! Per informazioni generali sulla gestione delle eccezioni e sullo svolgimento della pila, vedere "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) e documenti collegati da esso.
//! Anche queste sono buone letture:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Un breve riassunto
//!
//! La gestione delle eccezioni avviene in due fasi: una fase di ricerca e una fase di pulizia.
//!
//! In entrambe le fasi lo svolgitore percorre gli stack frame dall'alto verso il basso utilizzando le informazioni dalle sezioni di svolgimento dello stack frame dei moduli del processo corrente ("module" qui si riferisce a un modulo del sistema operativo, cioè un eseguibile o una libreria dinamica).
//!
//!
//! Per ogni stack frame, richiama l "personality routine" associato, il cui indirizzo è anche memorizzato nella sezione informativa sullo svolgimento.
//!
//! Nella fase di ricerca, il compito di una routine della personalità è esaminare l'oggetto eccezione lanciato e decidere se deve essere catturato in quel frame dello stack.Una volta identificato il frame del gestore, inizia la fase di pulizia.
//!
//! Nella fase di pulizia, lo svolgitore richiama di nuovo ogni routine della personalità.
//! Questa volta decide quale codice di pulizia (se presente) deve essere eseguito per lo stack frame corrente.In tal caso, il controllo viene trasferito a uno speciale branch nel corpo della funzione, l "landing pad", che richiama i distruttori, libera la memoria, ecc.
//! Alla fine della piattaforma di atterraggio, il controllo viene ritrasferito allo svolgitore e lo svolgimento riprende.
//!
//! Una volta che lo stack è stato svolto fino al livello del frame del conduttore, lo svolgimento si ferma e l'ultima routine della personalità trasferisce il controllo al blocco di cattura.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identificatore della classe di eccezione di Rust.
// Viene utilizzato dalle routine della personalità per determinare se l'eccezione è stata generata dal proprio runtime.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-fornitore, lingua
    0x4d4f5a_00_52555354
}

// Gli ID dei registri sono stati estratti da TargetLowering::getExceptionPointerRegister() e TargetLowering::getExceptionSelectorRegister() di LLVM per ciascuna architettura, quindi mappati ai numeri di registro DWARF tramite tabelle di definizione dei registri (in genere<arch>RegisterInfo.td, cerca "DwarfRegNum").
//
// Vedi anche http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Il codice seguente è basato sulle routine di personalità C e C++ di GCC.Per riferimento, vedere:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Routine della personalità EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS utilizza invece la routine predefinita poiché utilizza lo svolgimento di SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // I backtrace su ARM chiameranno la routine della personalità con lo stato==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // In questi casi vogliamo continuare a srotolare lo stack, altrimenti tutti i nostri backtrace finirebbero in __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // Lo svolgitore DWARF presuppone che_Unwind_Context contenga elementi come la funzione ei puntatori LSDA, tuttavia ARM EHABI li inserisce nell'oggetto eccezione.
            // Per preservare le firme di funzioni come _Unwind_GetLanguageSpecificData(), che accettano solo il puntatore di contesto, le routine di personalità GCC nascondono un puntatore a exception_object nel contesto, utilizzando la posizione riservata per "scratch register" (r12) di ARM.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Un approccio più basato sui principi sarebbe fornire la definizione completa di_Unwind_Context di ARM nei nostri collegamenti libunwind e recuperare i dati richiesti direttamente da lì, bypassando le funzioni di compatibilità DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI richiede che la routine della personalità aggiorni il valore SP nella cache barriera dell'oggetto eccezione.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Su ARM EHABI la routine della personalità è responsabile dell'effettivo svolgimento di un singolo stack frame prima del ritorno (ARM EHABI Sez.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // definito in libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Routine della personalità predefinita, che viene utilizzata direttamente sulla maggior parte dei target e indirettamente su Windows x86_64 tramite SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Sulle destinazioni x86_64 MinGW, il meccanismo di svolgimento è SEH, tuttavia i dati del gestore di svolgimento (noti anche come LSDA) utilizzano la codifica compatibile con GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // La routine della personalità per la maggior parte dei nostri obiettivi.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // L'indirizzo di ritorno punta 1 byte oltre l'istruzione di chiamata, che potrebbe trovarsi nel successivo intervallo IP nella tabella degli intervalli LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Registrazione delle informazioni di svolgimento del telaio
//
// L'immagine di ogni modulo contiene una sezione informativa sullo svolgimento del frame (solitamente ".eh_frame").Quando un modulo è loaded/unloaded nel processo, lo svolgitore deve essere informato sulla posizione di questa sezione in memoria.I metodi per ottenerlo variano a seconda della piattaforma.
// Su alcuni (ad esempio, Linux), lo svolgitore può scoprire da solo le sezioni di informazioni di svolgimento (enumerando dinamicamente i moduli attualmente caricati tramite dl_iterate_phdr() API and finding their ".eh_frame" sections); Altri, come Windows, richiedono ai moduli di registrare attivamente le sezioni di informazioni di svolgimento tramite l'API di svolgimento.
//
//
// Questo modulo definisce due simboli che vengono referenziati e chiamati da rsbegin.rs per registrare le nostre informazioni con il runtime GCC.
// L'implementazione dello svolgimento dello stack è (per ora) rimandata a libgcc_eh, tuttavia Rust crates utilizza questi punti di ingresso specifici di Rust per evitare potenziali conflitti con qualsiasi runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}