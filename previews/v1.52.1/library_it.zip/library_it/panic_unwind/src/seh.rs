//! Windows SEH
//!
//! Su Windows (attualmente solo su MSVC), il meccanismo di gestione delle eccezioni predefinito è la gestione delle eccezioni strutturata (SEH).
//! Questo è abbastanza diverso dalla gestione delle eccezioni basata su Dwarf (ad esempio, quello che usano le altre piattaforme unix) in termini di interni del compilatore, quindi LLVM deve avere una buona dose di supporto extra per SEH.
//!
//! In poche parole, quello che succede qui è:
//!
//! 1. La funzione `panic` chiama la funzione Windows standard `_CxxThrowException` per lanciare un'eccezione simile a C++ , attivando il processo di svolgimento.
//! 2.
//! Tutti i landing pad generati dal compilatore utilizzano la funzione di personalità `__CxxFrameHandler3`, una funzione nel CRT, e il codice di svolgimento in Windows utilizzerà questa funzione di personalità per eseguire tutto il codice di pulizia sullo stack.
//!
//! 3. Tutte le chiamate generate dal compilatore a `invoke` hanno un pad di atterraggio impostato come istruzione `cleanuppad` LLVM, che indica l'inizio della routine di pulizia.
//! La personalità (nel passaggio 2, definita nel CRT) è responsabile dell'esecuzione delle routine di pulizia.
//! 4. Alla fine il codice "catch" nell'intrinseco `try` (generato dal compilatore) viene eseguito e indica che il controllo dovrebbe tornare a Rust.
//! Questo viene fatto tramite un'istruzione `catchswitch` più un'istruzione `catchpad` in termini IR LLVM, restituendo infine il controllo normale al programma con un'istruzione `catchret`.
//!
//! Alcune differenze specifiche rispetto alla gestione delle eccezioni basata su gcc sono:
//!
//! * Rust non ha una funzione di personalizzazione personalizzata, è invece *sempre*`__CxxFrameHandler3`.Inoltre, non viene eseguito alcun filtro aggiuntivo, quindi finiamo per rilevare eventuali eccezioni C++ che sembrano simili al tipo che stiamo lanciando.
//! Nota che lanciare un'eccezione in Rust è comunque un comportamento indefinito, quindi dovrebbe andare bene.
//! * Abbiamo alcuni dati da trasmettere attraverso il confine di svolgimento, in particolare un `Box<dyn Any + Send>`.Come con le eccezioni di Dwarf, questi due puntatori vengono memorizzati come payload nell'eccezione stessa.
//! Su MSVC, tuttavia, non è necessaria un'allocazione di heap aggiuntiva perché lo stack di chiamate viene conservato durante l'esecuzione delle funzioni di filtro.
//! Ciò significa che i puntatori vengono passati direttamente a `_CxxThrowException` che vengono poi recuperati nella funzione di filtro per essere scritti nello stack frame dell'intrinseco di `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Questa deve essere un'opzione perché catturiamo l'eccezione per riferimento e il suo distruttore viene eseguito dal runtime C++ .
    // Quando togliamo Box fuori dall'eccezione, dobbiamo lasciare l'eccezione in uno stato valido affinché il suo distruttore funzioni senza rilasciare due volte il Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Innanzitutto, un sacco di definizioni di tipo.Ci sono alcune stranezze specifiche della piattaforma qui, e molte sono semplicemente copiate palesemente da LLVM.Lo scopo di tutto ciò è implementare la funzione `panic` di seguito tramite una chiamata a `_CxxThrowException`.
//
// Questa funzione accetta due argomenti.Il primo è un puntatore ai dati che stiamo passando, che in questo caso è il nostro oggetto trait.Abbastanza facile da trovare!Il prossimo, tuttavia, è più complicato.
// Questo è un puntatore a una struttura `_ThrowInfo` e generalmente è inteso solo per descrivere l'eccezione generata.
//
// Attualmente la definizione di questo tipo [1] è un po 'complicata, e la principale stranezza (e la differenza dall'articolo online) è che a 32 bit i puntatori sono puntatori ma a 64 bit i puntatori sono espressi come offset a 32 bit dal Simbolo `__ImageBase`.
//
// Le macro `ptr_t` e `ptr!` nei moduli seguenti vengono utilizzate per esprimere questo.
//
// Anche il labirinto di definizioni dei tipi segue da vicino ciò che LLVM emette per questo tipo di operazione.Ad esempio, se compili questo codice C++ su MSVC ed emetti l'IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          lanciare un;}
//
// Questo è essenzialmente ciò che stiamo cercando di emulare.La maggior parte dei valori costanti di seguito sono stati semplicemente copiati da LLVM,
//
// In ogni caso, queste strutture sono tutte costruite in modo simile, ed è solo un po 'prolisso per noi.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Nota che qui ignoriamo intenzionalmente le regole di modifica dei nomi: non vogliamo che C++ sia in grado di catturare Rust panics semplicemente dichiarando un `struct rust_panic`.
//
//
// Durante la modifica, assicurati che la stringa del nome del tipo corrisponda esattamente a quella utilizzata in `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Il byte `\x01` iniziale qui è in realtà un segnale magico a LLVM per *non* applicare altre alterazioni come il prefisso con un carattere `_`.
    //
    //
    // Questo simbolo è la tabella v usata da `std::type_info` di C++ .
    // Gli oggetti di tipo `std::type_info`, descrittori di tipo, hanno un puntatore a questa tabella.
    // I descrittori di tipo sono referenziati dalle strutture C++ EH definite sopra e che costruiamo di seguito.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Questo descrittore di tipo viene utilizzato solo quando viene generata un'eccezione.
// La parte catch viene gestita dall'intrinseco try, che genera il proprio TypeDescriptor.
//
// Questo va bene poiché il runtime MSVC utilizza il confronto di stringhe sul nome del tipo per abbinare TypeDescriptors piuttosto che l'uguaglianza del puntatore.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor utilizzato se il codice C++ decide di catturare l'eccezione e rilasciarla senza propagarla.
// La parte catch dell'intrinseco try imposterà la prima parola dell'oggetto eccezione a 0 in modo che venga saltata dal distruttore.
//
// Si noti che x86 Windows utilizza la convenzione di chiamata "thiscall" per le funzioni membro C++ invece della convenzione di chiamata "C" predefinita.
//
// La funzione exception_copy è un po 'speciale qui: viene invocata dal runtime MSVC sotto un blocco try/catch e lo panic che generiamo qui verrà utilizzato come risultato della copia dell'eccezione.
//
// Viene utilizzato dal runtime C++ per supportare l'acquisizione di eccezioni con std::exception_ptr, che non possiamo supportare perché Box<dyn Any>non è clonabile.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException viene eseguito interamente su questo stack frame, quindi non è necessario trasferire altrimenti `data` nell'heap.
    // Passiamo semplicemente un puntatore allo stack a questa funzione.
    //
    // ManuallyDrop è necessario qui poiché non vogliamo che l'eccezione venga eliminata durante lo svolgimento.
    // Verrà invece eliminato da exception_cleanup che viene richiamato dal runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Questo ... può sembrare sorprendente, e giustamente.Su MSVC a 32 bit i puntatori tra queste strutture sono proprio questo, puntatori.
    // Su MSVC a 64 bit, tuttavia, i puntatori tra le strutture sono piuttosto espressi come offset a 32 bit da `__ImageBase`.
    //
    // Di conseguenza, su MSVC a 32 bit possiamo dichiarare tutti questi puntatori nel `static`s sopra.
    // Su MSVC a 64 bit, dovremmo esprimere la sottrazione di puntatori in statica, cosa che Rust attualmente non consente, quindi non possiamo farlo effettivamente.
    //
    // La prossima cosa migliore, quindi, è riempire queste strutture in fase di esecuzione (il panico è già l "slow path" comunque).
    // Quindi qui reinterpretiamo tutti questi campi puntatore come numeri interi a 32 bit e quindi memorizziamo il valore pertinente in esso (atomicamente, poiché potrebbe verificarsi panics simultaneo).
    //
    // Tecnicamente il runtime probabilmente eseguirà una lettura non atomica di questi campi, ma in teoria non hanno mai letto il valore *sbagliato*, quindi non dovrebbe essere troppo male ...
    //
    // In ogni caso, fondamentalmente abbiamo bisogno di fare qualcosa di simile fino a quando non possiamo esprimere più operazioni in statica (e forse non saremo mai in grado di farlo).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Un payload NULL qui significa che siamo arrivati qui dalla cattura (...) di __rust_try.
    // Ciò accade quando viene rilevata un'eccezione esterna non Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Questo è richiesto dal compilatore per esistere (ad esempio, è un elemento lang), ma non viene mai effettivamente chiamato dal compilatore perché __C_specific_handler o_except_handler3 è la funzione della personalità che viene sempre utilizzata.
//
// Quindi questo è solo uno stub abortito.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}