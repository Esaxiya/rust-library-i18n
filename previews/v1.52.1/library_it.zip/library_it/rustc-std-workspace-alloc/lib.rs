#![feature(no_core)]
#![no_core]

// Vedere rustc-std-workspace-core per scoprire perché è necessario questo crate.

// Rinomina crate per evitare conflitti con il modulo alloc in liballoc.
extern crate alloc as foo;

pub use foo::*;