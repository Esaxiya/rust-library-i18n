//! Una libreria di supporto per gli autori di macro durante la definizione di nuove macro.
//!
//! Questa libreria, fornita dalla distribuzione standard, fornisce i tipi consumati nelle interfacce delle definizioni di macro definite proceduralmente come le macro di tipo funzione `#[proc_macro]`, gli attributi macro `#[proc_macro_attribute]` e gli attributi di derivazione personalizzati`#[proc_macro_derive]`.
//!
//!
//! Vedi [the book] per ulteriori informazioni.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Determina se proc_macro è stato reso accessibile al programma attualmente in esecuzione.
///
/// Il proc_macro crate è inteso solo per l'uso all'interno dell'implementazione di macro procedurali.Tutte le funzioni in questo crate panic se invocate dall'esterno di una macro procedurale, come da uno script di compilazione o da uno unit test o da un normale binario Rust.
///
/// Tenendo conto delle librerie Rust progettate per supportare i casi d'uso sia macro che non macro, `proc_macro::is_available()` fornisce un modo senza panico per rilevare se l'infrastruttura richiesta per utilizzare l'API di proc_macro è attualmente disponibile.
/// Restituisce true se invocato dall'interno di una macro procedurale, false se invocato da qualsiasi altro binario.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Il tipo principale fornito da questo crate, che rappresenta un flusso astratto di tokens o, più specificamente, una sequenza di alberi token.
/// Il tipo fornisce interfacce per l'iterazione su quegli alberi token e, al contrario, per raccogliere un numero di alberi token in un flusso.
///
///
/// Questo è sia l'input che l'output delle definizioni `#[proc_macro]`, `#[proc_macro_attribute]` e `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Errore restituito da `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Restituisce un `TokenStream` vuoto che non contiene alberi token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Controlla se questo `TokenStream` è vuoto.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Tenta di suddividere la stringa in token e di analizzare tali token in un flusso token.
/// Potrebbe non riuscire per una serie di motivi, ad esempio, se la stringa contiene delimitatori sbilanciati o caratteri non esistenti nella lingua.
///
/// Tutti gli tokens nel flusso analizzato ottengono intervalli `Span::call_site()`.
///
/// NOTE: alcuni errori possono causare panics invece di restituire `LexError`.Ci riserviamo il diritto di modificare questi errori in "LexError" in seguito.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Stampa il flusso token come una stringa che dovrebbe essere convertibile senza perdita di dati nello stesso flusso token (moduli di estensione), ad eccezione di "TokenTree: : Group" con delimitatori `Delimiter::None` e valori letterali numerici negativi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Stampa token in una forma conveniente per il debug.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Crea un flusso token contenente un singolo albero token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Raccoglie un numero di alberi token in un unico flusso.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Un'operazione "flattening" sui flussi token raccoglie alberi token da più flussi token in un unico flusso.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Utilizzare un'implementazione ottimizzata if/when possibile.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Dettagli di implementazione pubblica per il tipo `TokenStream`, come gli iteratori.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Un iteratore su `TokenStream` di`TokenTree`.
    /// L'iterazione è "shallow", ad esempio, l'iteratore non ricorre in gruppi delimitati e restituisce interi gruppi come alberi token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accetta tokens arbitrario e si espande in un `TokenStream` che descrive l'input.
/// Ad esempio, `quote!(a + b)` produrrà un'espressione che, una volta valutata, costruisce `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// L'annullamento delle quotazioni viene eseguito con `$` e funziona prendendo la singola identità successiva come termine non quotato.
/// Per citare `$` stesso, usa `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Una regione del codice sorgente, insieme alle informazioni sull'espansione delle macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Crea un nuovo `Diagnostic` con il dato `message` nello span `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Un intervallo che si risolve nel sito di definizione delle macro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// L'intervallo di invocazione dell'attuale macro procedurale.
    /// Gli identificatori creati con questo intervallo verranno risolti come se fossero scritti direttamente nella posizione della chiamata della macro (igiene del sito di chiamata) e anche altro codice nel sito della chiamata della macro sarà in grado di fare riferimento a loro.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Un intervallo che rappresenta l'igiene di `macro_rules` e talvolta si risolve nel sito di definizione delle macro (variabili locali, etichette, `$crate`) e talvolta nel sito di chiamata delle macro (tutto il resto).
    ///
    /// La posizione dello span è presa dal call-site.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Il file sorgente originale in cui punta questo intervallo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// L `Span` per tokens nella precedente espansione della macro da cui è stato generato `self`, se presente.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// L'intervallo per il codice sorgente di origine da cui è stato generato `self`.
    /// Se questo `Span` non è stato generato da altre espansioni macro, il valore restituito è lo stesso di `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Ottiene l line/column iniziale nel file di origine per questo intervallo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Ottiene l line/column finale nel file di origine per questo intervallo.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Crea un nuovo intervallo che comprende `self` e `other`.
    ///
    /// Restituisce `None` se `self` e `other` provengono da file diversi.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Crea un nuovo intervallo con le stesse informazioni line/column di `self` ma che risolve i simboli come se fosse in `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Crea un nuovo intervallo con lo stesso comportamento di risoluzione dei nomi di `self` ma con le informazioni line/column di `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Confronta gli intervalli per vedere se sono uguali.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Restituisce il testo di origine dietro un intervallo.
    /// Ciò preserva il codice sorgente originale, inclusi spazi e commenti.
    /// Restituisce un risultato solo se lo span corrisponde al codice sorgente reale.
    ///
    /// Note: Il risultato osservabile di una macro dovrebbe basarsi solo su tokens e non su questo testo di origine.
    ///
    /// Il risultato di questa funzione è uno sforzo migliore da utilizzare solo per la diagnostica.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Stampa un intervallo in una forma conveniente per il debug.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Una coppia riga-colonna che rappresenta l'inizio o la fine di un `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// La riga con indice 1 nel file di origine in cui lo span inizia o finisce (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// La colonna indicizzata 0 (in caratteri UTF-8) nel file di origine in cui lo span inizia o finisce (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Il file sorgente di un determinato `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Ottiene il percorso di questo file di origine.
    ///
    /// ### Note
    /// Se l'intervallo di codice associato a questo `SourceFile` è stato generato da una macro esterna, questa macro, potrebbe non essere un percorso effettivo sul file system.
    /// Usa [`is_real`] per controllare.
    ///
    /// Si noti inoltre che anche se `is_real` restituisce `true`, se `--remap-path-prefix` è stato passato sulla riga di comando, il percorso fornito potrebbe non essere effettivamente valido.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Restituisce `true` se questo file sorgente è un file sorgente reale e non è generato dall'espansione di una macro esterna.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Questo è un trucco fino a quando non vengono implementati gli intervalli di intercrate e possiamo avere file sorgente reali per gli intervalli generati in macro esterne.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Un singolo token o una sequenza delimitata di alberi token (ad esempio, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Un flusso token circondato da delimitatori di parentesi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Un identificatore.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Un singolo carattere di punteggiatura ("+", `,`, `$`, ecc.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Un carattere letterale (`'a'`), stringa (`"hello"`), numero (`2.3`) e così via.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Restituisce lo span di questo albero, delegando al metodo `span` del token contenuto o un flusso delimitato.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Configura l'intervallo per *solo questo token*.
    ///
    /// Si noti che se questo token è un `Group`, questo metodo non configurerà l'intervallo di ciascuno degli token interni, ma verrà semplicemente delegato al metodo `set_span` di ciascuna variante.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Stampa l'albero token in una forma comoda per il debug.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ognuno di questi ha il nome nel tipo di struttura nel debug derivato, quindi non preoccuparti di un ulteriore livello di riferimento indiretto
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Stampa l'albero token come una stringa che dovrebbe essere convertibile senza perdite nello stesso albero token (modulo spans), eccetto forse `TokenTree: : Group`s con delimitatori `Delimiter::None` e valori letterali numerici negativi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Un flusso token delimitato.
///
/// Un `Group` contiene internamente un `TokenStream` circondato da `Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Descrive come viene delimitata una sequenza di alberi token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Un delimitatore implicito, che può, ad esempio, apparire intorno a tokens proveniente da un "macro variable" `$var`.
    /// È importante preservare le priorità dell'operatore in casi come `$var * 3` dove `$var` è `1 + 2`.
    /// I delimitatori impliciti potrebbero non sopravvivere al roundtrip di un flusso token attraverso una stringa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Crea un nuovo `Group` con il delimitatore specificato e il flusso token.
    ///
    /// Questo costruttore imposterà l'intervallo per questo gruppo su `Span::call_site()`.
    /// Per modificare l'intervallo è possibile utilizzare il metodo `set_span` di seguito.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Restituisce il delimitatore di questo `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Restituisce `TokenStream` di tokens che sono delimitati in questo `Group`.
    ///
    /// Si noti che il flusso token restituito non include il delimitatore restituito sopra.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Restituisce l'intervallo per i delimitatori di questo flusso token, che copre l'intero `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Restituisce lo span che punta al delimitatore di apertura di questo gruppo.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Restituisce lo span che punta al delimitatore di chiusura di questo gruppo.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Configura l'intervallo per i delimitatori di questo `Gruppo`, ma non il suo tokens interno.
    ///
    /// Questo metodo **non** imposterà l'intervallo di tutti gli token interni inclusi in questo gruppo, ma piuttosto imposterà solo l'intervallo del delimitatore tokens a livello di `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa il gruppo come una stringa che dovrebbe essere riconvertibile senza perdite nello stesso gruppo (modulo si estende), ad eccezione di "TokenTree: : Group" con delimitatori `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Un `Punct` è un singolo carattere di punteggiatura come `+`, `-` o `#`.
///
/// Gli operatori multi-carattere come `+=` sono rappresentati come due istanze di `Punct` con diverse forme di `Spacing` restituite.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Se un `Punct` è seguito immediatamente da un altro `Punct` o seguito da un altro token o spazi bianchi.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ad esempio, `+` è `Alone` in `+ =`, `+ident` o `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ad esempio, `+` è `Joint` in `+=` o `'#`.
    /// Inoltre, virgolette singole `'` possono unirsi a identificatori per formare durate `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Crea un nuovo `Punct` dal carattere e dalla spaziatura specificati.
    /// L'argomento `ch` deve essere un carattere di punteggiatura valido consentito dalla lingua, altrimenti la funzione sarà panic.
    ///
    /// L `Punct` restituito avrà lo span predefinito di `Span::call_site()` che può essere ulteriormente configurato con il metodo `set_span` di seguito.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Restituisce il valore di questo carattere di punteggiatura come `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Restituisce la spaziatura di questo carattere di punteggiatura, indicando se è immediatamente seguito da un altro `Punct` nel flusso token, quindi possono potenzialmente essere combinati in un operatore multi-carattere (`Joint`), o è seguito da qualche altro token o spazi bianchi (`Alone`), quindi l'operatore ha sicuramente conclusa.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Restituisce l'intervallo per questo carattere di punteggiatura.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura l'intervallo per questo carattere di punteggiatura.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa il carattere di punteggiatura come una stringa che dovrebbe essere riconvertibile senza perdite nello stesso carattere.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Un identificatore (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Crea un nuovo `Ident` con l `string` specificato e l `span` specificato.
    /// L'argomento `string` deve essere un identificatore valido consentito dalla lingua (comprese le parole chiave, ad esempio `self` o `fn`).Altrimenti, la funzione sarà panic.
    ///
    /// Si noti che `span`, attualmente in rustc, configura le informazioni sull'igiene per questo identificatore.
    ///
    /// A partire da questo momento `Span::call_site()` opta esplicitamente per l'igiene "call-site", il che significa che gli identificatori creati con questo intervallo verranno risolti come se fossero scritti direttamente nella posizione della chiamata macro e sarà possibile fare riferimento ad altro codice nel sito della chiamata macro anche loro.
    ///
    ///
    /// Intervalli successivi come `Span::def_site()` consentiranno di opt-in per l'igiene "definition-site", il che significa che gli identificatori creati con questo intervallo verranno risolti nella posizione della definizione della macro e altro codice sul sito di chiamata macro non sarà in grado di fare riferimento a loro.
    ///
    /// A causa dell'attuale importanza dell'igiene, questo costruttore, a differenza di altri tokens, richiede che un `Span` sia specificato al momento della costruzione.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Come `Ident::new`, ma crea un identificatore non elaborato (`r#ident`).
    /// L'argomento `string` è un identificatore valido consentito dalla lingua (comprese le parole chiave, ad esempio `fn`).
    /// Parole chiave utilizzabili in segmenti di percorso (es
    /// `self`, `super`) non sono supportati e causeranno un errore panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Restituisce l'intervallo di questo `Ident`, che comprende l'intera stringa restituita da [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura la durata di questo `Ident`, eventualmente modificandone il contesto igienico.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa l'identificatore come una stringa che dovrebbe essere riconvertibile senza perdite nello stesso identificatore.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Una stringa letterale (`"hello"`), una stringa di byte (`b"hello"`), un carattere (`'a'`), un carattere di byte (`b'a'`), un numero intero o in virgola mobile con o senza suffisso ("1", `1u8`, `2.3`, `2.3f32`).
///
/// I letterali booleani come `true` e `false` non appartengono a questo punto, sono `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un nuovo valore letterale intero con suffisso con il valore specificato.
        ///
        /// Questa funzione creerà un numero intero come `1u32` dove il valore intero specificato è la prima parte di token e anche l'integrale è suffisso alla fine.
        /// I valori letterali creati da numeri negativi potrebbero non sopravvivere a round trip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e valore letterale positivo).
        ///
        ///
        /// I valori letterali creati tramite questo metodo hanno l'estensione `Span::call_site()` per impostazione predefinita, che può essere configurata con il metodo `set_span` di seguito.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Crea un nuovo valore letterale intero senza suffisso con il valore specificato.
        ///
        /// Questa funzione creerà un numero intero come `1` dove il valore intero specificato è la prima parte di token.
        /// Nessun suffisso è specificato su questo token, il che significa che invocazioni come `Literal::i8_unsuffixed(1)` sono equivalenti a `Literal::u32_unsuffixed(1)`.
        /// I letterali creati da numeri negativi potrebbero non sopravvivere a rountrip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e letterale positivo).
        ///
        ///
        /// I valori letterali creati tramite questo metodo hanno l'estensione `Span::call_site()` per impostazione predefinita, che può essere configurata con il metodo `set_span` di seguito.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Crea un nuovo valore letterale a virgola mobile senza suffisso.
    ///
    /// Questo costruttore è simile a quelli come `Literal::i8_unsuffixed` in cui il valore del float viene emesso direttamente in token ma non viene utilizzato alcun suffisso, quindi si può dedurre che sia un `f64` più avanti nel compilatore.
    ///
    /// I letterali creati da numeri negativi potrebbero non sopravvivere a rountrip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e letterale positivo).
    ///
    /// # Panics
    ///
    /// Questa funzione richiede che il float specificato sia finito, ad esempio se è infinito o NaN questa funzione sarà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nuovo valore letterale a virgola mobile con suffisso.
    ///
    /// Questo costruttore creerà un valore letterale come `1.0f32` dove il valore specificato è la parte precedente di token e `f32` è il suffisso di token.
    /// Questo token verrà sempre dedotto come `f32` nel compilatore.
    /// I letterali creati da numeri negativi potrebbero non sopravvivere a rountrip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e letterale positivo).
    ///
    ///
    /// # Panics
    ///
    /// Questa funzione richiede che il float specificato sia finito, ad esempio se è infinito o NaN questa funzione sarà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Crea un nuovo valore letterale a virgola mobile senza suffisso.
    ///
    /// Questo costruttore è simile a quelli come `Literal::i8_unsuffixed` in cui il valore del float viene emesso direttamente in token ma non viene utilizzato alcun suffisso, quindi si può dedurre che sia un `f64` più avanti nel compilatore.
    ///
    /// I letterali creati da numeri negativi potrebbero non sopravvivere a rountrip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e letterale positivo).
    ///
    /// # Panics
    ///
    /// Questa funzione richiede che il float specificato sia finito, ad esempio se è infinito o NaN questa funzione sarà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Crea un nuovo valore letterale a virgola mobile con suffisso.
    ///
    /// Questo costruttore creerà un valore letterale come `1.0f64` dove il valore specificato è la parte precedente di token e `f64` è il suffisso di token.
    /// Questo token verrà sempre dedotto come `f64` nel compilatore.
    /// I letterali creati da numeri negativi potrebbero non sopravvivere a rountrip tramite `TokenStream` o stringhe e possono essere suddivisi in due tokens (`-` e letterale positivo).
    ///
    ///
    /// # Panics
    ///
    /// Questa funzione richiede che il float specificato sia finito, ad esempio se è infinito o NaN questa funzione sarà panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Stringa letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Carattere letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte stringa letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Restituisce l'intervallo che comprende questo valore letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Configura l'intervallo associato per questo valore letterale.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Restituisce un `Span` che è un sottoinsieme di `self.span()` contenente solo i byte di origine nell'intervallo `range`.
    /// Restituisce `None` se lo span che potrebbe essere tagliato è al di fuori dei limiti di `self`.
    ///
    // FIXME(SergioBenitez): controlla che l'intervallo di byte inizi e termini al limite UTF-8 della sorgente.
    // in caso contrario, è probabile che un panic si verifichi altrove quando viene stampato il testo di origine.
    // FIXME(SergioBenitez): non c'è modo per l'utente di sapere a cosa è effettivamente associato `self.span()`, quindi questo metodo può essere attualmente chiamato solo alla cieca.
    // Ad esempio, `to_string()` per il carattere 'c' restituisce "'\u{63}'";non c'è modo per l'utente di sapere se il testo di origine era 'c' o se era '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) qualcosa di simile a `Option::cloned`, ma per `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, il bridge prevede solo `to_string`, implementare `fmt::Display` basandosi su di esso (il contrario del solito rapporto tra i due).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa il valore letterale come una stringa che dovrebbe essere riconvertibile senza perdite nello stesso valore letterale (ad eccezione del possibile arrotondamento per i valori letterali in virgola mobile).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Accesso tracciato alle variabili d'ambiente.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Recupera una variabile di ambiente e aggiungila per creare informazioni sulle dipendenze.
    /// Il sistema di compilazione che esegue il compilatore saprà che è stato eseguito l'accesso alla variabile durante la compilazione e sarà in grado di rieseguire la compilazione quando il valore di quella variabile cambia.
    ///
    /// Oltre al rilevamento delle dipendenze, questa funzione dovrebbe essere equivalente a `env::var` dalla libreria standard, tranne per il fatto che l'argomento deve essere UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}