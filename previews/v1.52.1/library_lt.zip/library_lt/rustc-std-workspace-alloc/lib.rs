#![feature(no_core)]
#![no_core]

// Žr. " rustc-std-workspace-core`, kodėl reikalingas šis " crate`.

// Pervardykite crate, kad išvengtumėte konflikto su paskirstymo moduliu liballoc.
extern crate alloc as foo;

pub use foo::*;