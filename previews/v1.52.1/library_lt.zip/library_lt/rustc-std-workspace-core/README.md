# " `rustc-std-workspace-core` crate`

Šis " crate`yra tuščias ir tuščias " crate`, kuris tiesiog priklauso nuo " `libcore` ir reeksportuoja visą jo turinį.
" crate`yra esmė, suteikiant standartinei bibliotekai galimybę priklausyti nuo " crates` iš " crates.io

Crates crates.io, kad standartinė biblioteka priklauso nuo poreikio priklausyti nuo X0 `rustc-std-workspace-core` crate iš crates.io, kuris yra tuščias.

Mes naudojame `[patch]`, kad nepaisytume šios crate šioje saugykloje.
Dėl to crates crates.io atkurs priklausomybę edge nuo `libcore`, šioje saugykloje apibrėžtos versijos.
Tai turėtų nubrėžti visas priklausomybės briaunas, kad Cargo sėkmingai sukurtų crates!

Atkreipkite dėmesį, kad " crates crates.io turi priklausyti nuo šio " crate` su vardu `core`, kad viskas veiktų teisingai.Norėdami tai padaryti, jie gali naudoti:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Naudojant klavišą `package`, " crate`pervadinamas į " `core`, tai reiškia, kad jis atrodys

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kai Cargo iškviečia kompiliatorių, tenkina numanomą `extern crate core` direktyvą, kurią įvedė kompiliatorius.




