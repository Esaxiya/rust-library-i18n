// rsbegin.o ir rsend.o yra vadinamieji "compiler runtime startup objects".
// Juose yra kodas, reikalingas teisingam inicializuoti kompiliatoriaus vykdymo laiką.
//
// Susiejus vykdomąjį arba dylib vaizdą, visi vartotojo kodai ir bibliotekos yra "sandwiched" tarp šių dviejų objektų failų, todėl rsbegin.o kodas ar duomenys tampa pirmi atitinkamuose vaizdo skyriuose, o kodas ir duomenys iš rsend.o tampa paskutiniai.
// Šis efektas gali būti naudojamas simboliams įdėti sekcijos pradžioje arba pabaigoje, taip pat įterpti reikalingas antraštes ar poraštes.
//
// Atkreipkite dėmesį, kad tikrasis modulio įvesties taškas yra C vykdymo laiko paleisties objekte (paprastai vadinamas `crtX.o`), kuris tada iškviečia kitų vykdymo laiko komponentų (užregistruotų per dar vieną specialų vaizdų skyrių) inicijavimo skambučius.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Pažymi kamino rėmo atsukimo informacijos skilties pradžią
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Įbrėžimų vieta atsuktuvo vidinei buhalterijai tvarkyti.
    // Tai apibrėžiama kaip `struct object`, esanti $ GCC/unfind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Atsipalaiduokite informacijos registration/deregistration rutinose.
    // Žr. Libpanic_unwind dokumentus.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // užregistruokite išsisukimo informaciją paleisdami modulį
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // išregistruoti išjungus
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // " MinGW`skirta " init/uninit įprasta registracija
    pub mod mingw_init {
        // " MinGW` paleisties objektai (crt0.o/dllcrt0.o) paleidimo ir išėjimo metu pakvies pasaulinius konstruktorius .ctors ir .dtors sekcijose.
        // DLL atveju tai daroma, kai DLL yra pakraunamas ir iškraunamas.
        //
        // Linkeris rūšiuos skyrius, o tai užtikrina, kad mūsų atgaliniai skambučiai būtų sąrašo gale.
        // Kadangi konstruktoriai vykdomi atvirkštine tvarka, tai užtikrina, kad mūsų atgaliniai skambučiai yra pirmieji ir paskutiniai.
        //
        //

        #[link_section = ".ctors.65535"] // .aktoriai. *: C inicijavimo atgaliniai skambučiai
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .gydytojai. *: C nutraukimo skambučiai
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}