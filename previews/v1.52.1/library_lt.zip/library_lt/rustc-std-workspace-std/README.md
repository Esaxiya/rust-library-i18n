# " `rustc-std-workspace-std` crate`

Žr. " `rustc-std-workspace-core` crate` dokumentaciją.