//! Nuolaidus " panics`, skirtas " Miri`.
use alloc::boxed::Box;
use core::any::Any;

// Naudingosios apkrovos, kurią " Miri` variklis platina mums atsukdamas, tipas.
// Turi būti žymiklio dydžio.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// " Miri` teikiama išorinė funkcija, skirta pradėti atsukti.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Naudingoji apkrova, kurią perduodame " `miri_start_panic`, bus būtent tas argumentas, kurį gausime toliau pateiktame " `cleanup`.
    // Taigi mes tiesiog pakuojame vieną kartą, kad gautume kažką žymeklio dydžio.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Atkurkite pagrindinį " `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}