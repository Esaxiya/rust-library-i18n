//! " panics` įgyvendinimas, palaikomas libgcc/libunwind (tam tikra forma).
//!
//! Išimčių tvarkymo ir kamino išvyniojimo fono ieškokite "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ir su juo susijusiuose dokumentuose.
//! Tai taip pat gerai skaitoma:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Trumpa santrauka
//!
//! Išimčių tvarkymas vyksta dviem etapais: paieškos ir valymo etapais.
//!
//! Abiejuose etapuose atvyniotojas eina rietuvių rėmelius iš viršaus į apačią, naudodamas informaciją iš dabartinio proceso modulių rietuvių ridenimo sekcijų ("module" čia nurodo OS modulį, ty vykdomąjį arba dinaminę biblioteką).
//!
//!
//! Kiekvienam rietuvės rėmui jis iškviečia susietą " "personality routine", kurio adresas taip pat yra saugomas informacijos skyriuje.
//!
//! Paieškos etape asmenybės rutinos užduotis yra ištirti išmetamą išimties objektą ir nuspręsti, ar jis turėtų būti užfiksuotas ties tuo kamino rėmu.Nustačius prižiūrėtojo rėmą, prasideda valymo etapas.
//!
//! Valymo etape atsukimo priemonė vėl iškviečia kiekvieną asmenybės rutiną.
//! Šį kartą jis nusprendžia, kurį (jei yra) valymo kodą reikia paleisti dabartiniam kamino rėmui.Jei taip, valdiklis perkeliamas į specialų branch funkcijos kūne-"landing pad", kuris iškviečia destruktorius, atlaisvina atmintį ir kt.
//! Nusileidimo aikštelės pabaigoje valdymas vėl perkeliamas į atsukimo įrenginį, o atsukimas atnaujinamas.
//!
//! Kai kaminas bus išvyniotas iki prižiūrėtojo rėmo lygio, atvyniojimas sustoja ir paskutinė asmenybės rutina perkelia valdymą į fiksavimo bloką.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust išimčių klasės identifikatorius.
// Tai naudoja asmenybės įpročiai, norėdami nustatyti, ar išimtį išmetė jų pačių vykdymo laikas.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-pardavėjas, kalba
    0x4d4f5a_00_52555354
}

// Kiekvienos architektūros registrų ID buvo panaikinti iš LLVM TargetLowering::getExceptionPointerRegister() ir TargetLowering::getExceptionSelectorRegister(), tada per registro apibrėžimo lenteles priskirti DWARF registrų numeriams (paprastai<arch>RegisterInfo.td, ieškokite "DwarfRegNum").
//
// Taip pat žiūrėkite " http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Šis kodas yra pagrįstas GCC C ir C++ asmenybės rutina.Norėdami sužinoti, žr .:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI asmenybės rutina.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS vietoj to naudoja numatytąją tvarką, nes ji naudoja SjLj atsukimą.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM " backtraces` vadins asmenybės rutiną būsena==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Tais atvejais mes norime tęsti rietuvės išvyniojimą, nes priešingu atveju visi mūsų pėdsakai pasibaigtų ties __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF atsuktuvas daro prielaidą, kad_Unwind_Context turi tokius dalykus kaip funkcija ir LSDA rodyklės, tačiau ARM EHABI juos įtraukia į išimties objektą.
            // Norint išsaugoti tokių funkcijų kaip " _Unwind_GetLanguageSpecificData() parašus, kuriems reikalingas tik konteksto žymeklis, asmenybės GCC įprasta kontekste pažymi žymeklį į kivétel_objektą, naudodama vietą, rezervuotą ARM "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Principiškesnis požiūris būtų pateikti pilną ARM_Unwind_Context apibrėžimą mūsų libunwind susiejimuose ir iš ten tiesiogiai gauti reikiamus duomenis, apeinant DWARF suderinamumo funkcijas.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI reikalauja asmenybės rutinos, kad būtų galima atnaujinti SP reikšmę išimties objekto kliūties talpykloje.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // " ARM EHABI` asmenybė yra atsakinga už tai, kad prieš grąžinant iš tikrųjų atsuktų vieno kamino rėmą (ARM EHABI sek.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // apibrėžta libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Numatytoji asmenybės rutina, kuri naudojama tiesiogiai daugeliui taikinių ir netiesiogiai Windows x86_64 per SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // " x86_64 MinGW` taikiniuose atsukimo mechanizmas yra SEH, tačiau atsukimo tvarkytuvų duomenys (dar žinomi kaip LSDA) naudoja su GCC suderinamą kodavimą.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Asmenybės rutina daugumai mūsų tikslų.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Grąžinimo adresas nurodo 1 baitą po skambučio nurodymo, kuris gali būti kitame IP diapazone LSDA diapazono lentelėje.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Rėmelio atsukimo informacijos registracija
//
// Kiekvieno modulio paveikslėlyje yra rėmelio atsukimo informacijos skiltis (paprastai ".eh_frame").Kai modulis yra loaded/unloaded procese, atsuktuvui reikia pranešti apie šio skyriaus vietą atmintyje.Metodai, kaip tai pasiekti, skiriasi pagal platformą.
// Kai kuriuose (pvz., " Linux) atsukimo įrenginys gali pats atrasti išsisukimo informacijos skiltis (dinamiškai surašydamas šiuo metu įkeltus modulius per " dl_iterate_phdr() API and finding their ".eh_frame" sections); kiti, pvz., " Windows, reikalauja, kad moduliai aktyviai užregistruotų savo išvyniojimo informacijos skiltis per atvyniojimo API.
//
//
// Šis modulis apibrėžia du simbolius, į kuriuos yra nuoroda ir kurie iškviečiami iš rsbegin.rs, kad mūsų informacija būtų užregistruota vykdant GCC.
// Kamino išvyniojimo įgyvendinimas (kol kas) atidėtas libgcc_eh, tačiau Rust crates naudoja šiuos konkrečius Rust įėjimo taškus, kad išvengtų galimų susidūrimų su bet kokiu GCC vykdymo laiku.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}