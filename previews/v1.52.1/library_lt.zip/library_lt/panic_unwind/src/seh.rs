//! Windows SEH
//!
//! " Windows(šiuo metu tik " MSVC`) numatytasis išimčių tvarkymo mechanizmas yra " Structured Exception Handling (SEH).
//! Kompiliatoriaus vidinės pusės atžvilgiu tai visiškai skiriasi nuo nykštukinio išimčių tvarkymo (pvz., Ką naudoja kitos unix platformos), todėl reikalaujama, kad LLVM turėtų daug papildomo palaikymo SEH.
//!
//! Trumpai tariant, kas vyksta čia:
//!
//! 1. " `panic` funkcija iškviečia standartinę " Windows funkciją " `_CxxThrowException`, kad išmestų į C++ panašią išimtį ir suaktyvintų išsivyniojimo procesą.
//! 2.
//! Visose kompiliatoriaus sugeneruotose nusileidimo aikštelėse naudojama asmenybės funkcija `__CxxFrameHandler3`, CRT funkcija, o Windows atsukimo kodas naudos šią asmenybės funkciją, kad įvykdytų visus šūsnies valymo kodus.
//!
//! 3. Visuose kompiliatorių sugeneruotuose skambučiuose į " `invoke` yra nukreipimo aikštelė, nustatyta kaip `cleanuppad` LLVM instrukcija, nurodanti valymo tvarkos pradžią.
//! Asmenybė (2 veiksme, apibrėžta CRT) yra atsakinga už valymo tvarkos vykdymą.
//! 4. Galų gale `try` vidiniame `try` (sukurtas kompiliatoriaus) kodas yra vykdomas ir rodo, kad valdymas turėtų grįžti į Rust.
//! Tai daroma naudojant " `catchswitch` ir " `catchpad` instrukcijas LLVM IR sąlygomis, pagaliau grąžinant įprastą valdymą programai su `catchret` instrukcija.
//!
//! Keli konkretūs gcc pagrindu veikiančių išimčių tvarkymo skirtumai yra šie:
//!
//! * Rust neturi pasirinktinės asmenybės funkcijos, ji yra *visada*`__CxxFrameHandler3`.Be to, papildomas filtravimas neatliekamas, todėl galų gale sulauksime bet kokių C++ išimčių, kurios atrodo panašios į mūsų išmestas.
//! Atkreipkite dėmesį, kad išimties išmetimas į Rust vis tiek yra neapibrėžtas elgesys, todėl tai turėtų būti gerai.
//! * Mes turime duomenų, kuriuos reikia perduoti per atsukamą ribą, ypač " `Box<dyn Any + Send>`.Kaip ir nykštukų išimtimis, šie du žymekliai yra saugomi kaip naudingoji apkrova pačioje išimtyje.
//! Tačiau MSVC nereikia papildomai kaupti, nes skambučių krūva išsaugoma vykdant filtro funkcijas.
//! Tai reiškia, kad žymekliai yra tiesiogiai perduodami " `_CxxThrowException`, kurie tada atkuriami filtro funkcijoje ir įrašomi į vidinio " `try` rietuvės rėmą.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Tai turi būti Option, nes mes gaudome išimtį remdamiesi nuoroda ir jos naikintuvą vykdo C++ vykdymo laikas.
    // Kai mes išimame langelį iš išimties, turime palikti išimtį tinkamoje būsenoje, kad jos destruktorius veiktų nedvejodamas lašo.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Pirmiausia visa krūva tipų apibrėžimų.Čia yra keletas platformai būdingų keistenybių ir daugybė, ką tiesiog akivaizdžiai nukopijuota iš LLVM.Viso to tikslas yra įdiegti žemiau esančią `panic` funkciją per skambutį į `_CxxThrowException`.
//
// Šiai funkcijai reikia dviejų argumentų.Pirmasis yra duomenų, kuriuos mes perduodame, žymeklis, kuris šiuo atveju yra mūsų objektas trait.Gana lengva rasti!Tačiau kitas yra sudėtingesnis.
// Tai yra žymeklis į `_ThrowInfo` struktūrą, ir jis paprastai skirtas tik apibūdinti išmetamą išimtį.
//
// Šiuo metu šio tipo [1] apibrėžimas yra šiek tiek plaukuotas, o pagrindinis keistenumas (ir skirtumas nuo internetinio straipsnio) yra tas, kad 32 bitų rodyklės yra rodyklės, bet 64 bitų rodyklės yra išreikštos kaip 32 bitų poslinkiai iš `__ImageBase` simbolis.
//
// Tam išreikšti naudojamos toliau pateiktuose moduliuose esančios makrokomandos `ptr_t` ir `ptr!`.
//
// Tipo apibrėžimų labirintas taip pat atidžiai seka, ką LLVM skleidžia tokio tipo operacijoms.Pvz., Jei sukompiliuosite šį C++ kodą MSVC ir išleisite LLVM IR:
//
//      #include <stdint.h>
//
//      strukt rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      niekinis foo() { rust_panic a = {0, 1};
//          mesti a;}
//
// Iš esmės tai ir bandome mėgdžioti.Dauguma toliau pateiktų pastovių verčių buvo tiesiog nukopijuotos iš LLVM,
//
// Bet kokiu atveju, visos šios struktūros yra sukonstruotos panašiai, ir mums tai tik šiek tiek verdi.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Atkreipkite dėmesį, kad čia tyčia nepaisome vardų tvarkymo taisyklių: nenorime, kad C++ galėtų sugauti Rust panics paprasčiausiai deklaruodamas `struct rust_panic`.
//
//
// Keisdami įsitikinkite, kad tipo pavadinimo eilutė tiksliai atitinka tą, kuri buvo naudojama `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Čia pirmaujantis `\x01` baitas yra stebuklingas signalas LLVM, kad *nebūtų* taikomas kitas valdymas, pavyzdžiui, priešdėlis su `_` simboliu.
    //
    //
    // Šis simbolis yra " Vable`, kurį naudoja " C++ ` `std::type_info`.
    // `std::type_info` tipo objektai, tipų aprašai, turi šios lentelės žymeklį.
    // Tipų aprašus nurodo aukščiau apibrėžtos C++ EH struktūros, kurias mes sukonstruojame žemiau.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Šis tipo aprašas naudojamas tik metant išimtį.
// Gaudymo dalį vykdo " try intrinsic`, kuri sukuria savo " TypeDescriptor`.
//
// Tai gerai, nes MSVC vykdymo laikas naudoja eilutės palyginimą tipo pavadinime, kad atitiktų " TypeDescriptors`, o ne rodyklių lygybę.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktorius naudojamas, jei C++ kodas nusprendžia užfiksuoti išimtį ir mesti ją neplatindamas.
// " Try intrinsic` gaudymo dalis nustatys pirmąjį išimties objekto žodį į 0, kad destruktorius jį praleistų.
//
// Atkreipkite dėmesį, kad " x86 Windows naudoja "thiscall" skambinimo tvarką C++ narių funkcijoms, o ne numatytajai "C" skambinimo tvarkai.
//
// Funkcija " kivétel_copy` čia yra šiek tiek ypatinga: ją iškviečia MSVC vykdymo laikas pagal try/catch bloką, o čia sukurtas panic bus naudojamas kaip išimties kopijos rezultatas.
//
// Tai naudoja C++ vykdymo laikas palaikyti išimčių fiksavimą naudojant std::exception_ptr, kurių mes negalime palaikyti, nes " Box`<dyn Any>nėra klonuojamas.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // " _CxxThrowException`vykdoma visiškai šiame rietuvės rėmelyje, todėl nereikia kitaip perkelti " `data` į kaupą.
    // Mes tiesiog perduodame kamino žymeklį šiai funkcijai.
    //
    // Čia reikalingas " ManuallyDrop`, nes mes nenorime, kad išimtis būtų atmetama atsukant.
    // Vietoj to jis bus atmestas išimties_valymas, kurį iškvies C++ vykdymo laikas.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Tai ... gali atrodyti stebėtinai ir pagrįstai.32 bitų MSVC rodyklės tarp šių struktūrų yra būtent tokios, rodyklės.
    // Tačiau 64 bitų MSVC rodyklės tarp struktūrų yra labiau išreikštos kaip 32 bitų `__ImageBase` poslinkiai.
    //
    // Taigi 32 bitų MSVC mes galime deklaruoti visus šiuos rodiklius aukščiau esančiuose " statiniuose`.
    // Naudodami 64 bitų MSVC, statikoje turėtume išreikšti rodyklių atimtis, o šiuo metu Rust neleidžia, todėl iš tikrųjų to negalime padaryti.
    //
    // Kitas geriausias dalykas yra užpildyti šias struktūras vykdymo metu (panika vis tiek jau yra " "slow path").
    // Taigi čia mes iš naujo interpretuojame visus šiuos žymeklio laukus kaip 32 bitų sveikus skaičius ir tada išsaugome atitinkamą vertę (atomiškai, nes tuo pačiu metu gali vykti panics).
    //
    // Techniškai vykdymo laikas tikriausiai atliks netatominį šių laukų skaitymą, tačiau teoriškai jie niekada neskaitė *neteisingos* vertės, todėl neturėtų būti labai blogai ...
    //
    // Bet kokiu atveju, iš esmės turime daryti kažką panašaus, kol statikoje negalime išreikšti daugiau operacijų (ir galbūt niekada negalėsime).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL naudingoji apkrova čia reiškia, kad mes čia patekome iš __rust_try gaudymo (...).
    // Taip nutinka, kai pagaunama ne Rust užsienio išimtis.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Kompiliatorius reikalauja, kad tai egzistuotų (pvz., Tai yra " lang` elementas), tačiau kompiliatorius to niekada nevadina, nes __C_specific_handler arba_except_handler3 yra asmenybės funkcija, kuri visada naudojama.
//
// Vadinasi, tai tik nutrūktgalvis.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}