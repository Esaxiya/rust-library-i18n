//! DWARF koduotų duomenų srautų analizavimo priemonės.
//! Žr. <http://www.dwarfstd.org>, DWARF-4 standartą, 7 skyrių, "Data Representation"
//!

// Šį modulį kol kas naudoja tik x86_64-pc-windows-gnu, tačiau mes jį kaupiame visur, kad išvengtume regresijos.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF srautai yra supakuoti, taigi, pvz., " u32 nebūtinai bus sulygiuotas ant 4 baitų ribos.
    // Tai gali sukelti problemų platformose, kuriose taikomi griežti derinimo reikalavimai.
    // Apvyniodami duomenis "packed" struktūroje, mes liepiame programinei įrangai generuoti "misalignment-safe" kodą.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 ir SLEB128 koduotės yra apibrėžtos 7.6, "Variable Length Data" skyriuose.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}