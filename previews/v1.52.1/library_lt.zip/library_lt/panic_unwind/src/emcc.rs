//! Atsipalaidavimas taikant *emscripten*.
//!
//! Nors įprastas " Rust Unix platformų išsisukinėjimas tiesiogiai kreipiasi į " libunwind` API, " Emscripten` mes vietoj to kreipiamės į C++ išvyniojimo API.
//! Tai tik tikslingumas, nes " Emscripten`vykdymo laikas visada įgyvendina tas API ir neįgyvendina " libunwind`.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Tai atitinka std::type_info išdėstymą C++ formatu
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Čia pirmaujantis `\x01` baitas yra stebuklingas signalas LLVM, kad *nebūtų* taikomas kitas valdymas, pavyzdžiui, priešdėlis su `_` simboliu.
    //
    //
    // Šis simbolis yra " Vable`, kurį naudoja " C++ ` `std::type_info`.
    // `std::type_info` tipo objektai, tipų aprašai, turi šios lentelės žymeklį.
    // Tipų aprašus nurodo aukščiau apibrėžtos C++ EH struktūros, kurias mes sukonstruojame žemiau.
    //
    // Atkreipkite dėmesį, kad tikrasis dydis yra didesnis nei 3, tačiau mums reikia tik rodyti trečiąjį elementą.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info rust_panic klasei
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Paprastai mes naudosime " .as_ptr().add(2), bet tai neveikia " const` kontekste.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Tai sąmoningai nenaudoja įprastos pavadinimo tvarkymo schemos, nes nenorime, kad C++ galėtų gaminti ar sugauti Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Tai yra būtina, nes C++ kodas gali užfiksuoti mūsų vykdymą naudodamas std::exception_ptr ir perrašyti jį kelis kartus, galbūt net kitoje gijoje.
    //
    //
    caught: AtomicBool,

    // Tai turi būti " Option`, nes objekto tarnavimo laikas atitinka C++ semantiką: kai " catch_unwind` perkelia langelį iš išimties, jis vis tiek turi palikti išimties objektą tinkamoje būsenoje, nes jo destruktorių vis dar iškvies __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try iš tikrųjų duoda mums nuorodą į šią struktūrą.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Kadangi " cleanup() neleidžiama naudoti " panic`, mes tiesiog nutraukiame.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}