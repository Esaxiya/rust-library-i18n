//! Palaikymo biblioteka makrokomandų autoriams apibrėžiant naujas makrokomandas.
//!
//! Ši biblioteka, kurią teikia standartinis paskirstymas, pateikia tipus, naudojamus procedūriniu būdu apibrėžtų makrokomandų sąsajose, pvz., Į funkcijas panašias makrokomandas `#[proc_macro]`, makrokomandų atributus `#[proc_macro_attribute]` ir pasirinktinius išvestinius atributus "#[proc_macro_derive]".
//!
//!
//! Norėdami pamatyti daugiau, žiūrėkite " [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Nustato, ar proc_macro buvo pasiekiama šiuo metu vykdomoje programoje.
///
/// " Proc_macro crate`skirtas naudoti tik įgyvendinant procedūrines makrokomandas.Visos šios " crate` funkcijos " panic` yra iškeltos iš procedūrinės makrokomandos ribų, pvz., Iš sukūrimo scenarijaus ar vieneto bandymo ar įprasto dvejetainio Rust.
///
/// Atsižvelgiant į " Rust`bibliotekas, sukurtas palaikyti tiek makrokomandų, tiek makrokomandų naudojimo atvejus, " `proc_macro::is_available()` suteikia nepanikuojantį būdą nustatyti, ar infrastruktūra, reikalinga norint naudoti proc_macro API, šiuo metu yra.
/// Grąžina tiesą, jei ji iškviečiama iš procedūrinės makrokomandos, klaidinga, jei iškviečiama iš bet kurio kito dvejetainio failo.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Pagrindinis šio crate tipas, vaizduojantis abstraktų tokens srautą, arba, tiksliau, token medžių seką.
/// Tipas teikia sąsajas, kad būtų galima kartoti tuos token medžius ir, priešingai, surinkti keletą token medžių į vieną srautą.
///
///
/// Tai yra įvestis ir išvestis iš `#[proc_macro]`, `#[proc_macro_attribute]` ir `#[proc_macro_derive]` apibrėžimų.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Iš `TokenStream::from_str` grąžinta klaida.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Pateikia tuščią `TokenStream`, kuriame nėra token medžių.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Patikrina, ar šis `TokenStream` tuščias.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Bandymai suskaidyti eilutę į tokens ir tuos tokens išanalizuoti į token srautą.
/// Gali nepavykti dėl daugelio priežasčių, pavyzdžiui, jei eilutėje yra nesubalansuotų ribotuvų ar simbolių, kurių nėra kalboje.
///
/// Visi analizuojamo srauto tokens gauna `Span::call_site()` intervalus.
///
/// NOTE: kai kurios klaidos gali sukelti panics, o ne grąžinti `LexError`.Mes pasiliekame teisę vėliau šias klaidas pakeisti į " LexError`.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Spausdina " token`srautą kaip eilutę, kuri turėtų būti be nuostolių konvertuojama atgal į tą patį " token` srautą (modulio apimtis), išskyrus galbūt " TokenTree: : Group` su `Delimiter::None` atribotais ir neigiamais skaitmeniniais litrais.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Spausdina token patogia derinti forma.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Sukuria token srautą, kuriame yra vienas token medis.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Surenka keletą token medžių į vieną srautą.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// "flattening" operacija naudojant token srautus renka token medžius iš kelių token srautų į vieną srautą.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Naudokite optimizuotą if/when diegimą.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Informacija apie viešą `TokenStream` tipo diegimą, pvz., Iteratoriai.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// " TokenStream`" TokenTree` kartotojas.
    /// Kartojimas yra "shallow", pvz., Iteratorius nebepasikartoja į atskirtas grupes ir grąžina visas grupes kaip token medžius.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` priima savavališką tokens ir išsiplečia į `TokenStream`, apibūdinantį įvestį.
/// Pavyzdžiui, `quote!(a + b)` sukurs išraišką, kuri, įvertinus, sukurs `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Nekotiravimas atliekamas naudojant " `$` ir veikia taip, kad nekomijuojamas terminas būtų vienas kitas identifikatorius.
/// Norėdami pacituoti patį " `$`, naudokite " `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Šaltinio kodo regionas kartu su makro išplėtimo informacija.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Sukuria naują `Diagnostic` su duotu `message` `self` diapazone.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Diapazonas, kuris išsisprendžia makrokomandų apibrėžimo vietoje.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Dabartinės procedūrinės makrokomandos iškvietimo intervalas.
    /// Pagal šį intervalą sukurti identifikatoriai bus išspręsti taip, tarsi jie būtų parašyti tiesiai makrokomandos skambučio vietoje (skambučio vietos higiena), o kitas makrokomandos skambučio kodas taip pat galės juos nurodyti.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` higieną atspindintis intervalas, kuris kartais išsiskiria makrokomandų apibrėžimo vietoje (vietiniai kintamieji, etiketės, `$crate`) ir kartais makrokomandų skambučių svetainėje (visa kita).
    ///
    /// Atstumo vieta imama iš skambučio vietos.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Originalus šaltinio failas, į kurį nukreipta ši atkarpa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span`, skirtas tokens ankstesniame makrokomandos plėtinyje, iš kurio buvo sukurtas `self`, jei toks buvo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Kilmės šaltinio kodo, iš kurio sugeneruotas `self`, diapazonas.
    /// Jei šis `Span` nebuvo sugeneruotas iš kitų makrokomandų išplėtimų, grąžinimo vertė yra tokia pati kaip `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Gauna pradinį line/column šaltinio faile šiam laikotarpiui.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Gauna pabaigos line/column šaltinio faile šiam laikotarpiui.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Sukuria naują diapazoną, apimantį `self` ir `other`.
    ///
    /// Pateikia `None`, jei `self` ir `other` yra iš skirtingų failų.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Sukuria naują intervalą su ta pačia line/column informacija kaip ir `self`, tačiau tai išsprendžia simbolius taip, lyg būtų `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Sukuria naują diapazoną su ta pačia pavadinimo skiriamosios gebos elgsena kaip ir " `self`, bet su " `other` informacija apie line/column.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Palyginamas su tarpatramiais, norint sužinoti, ar jie lygūs.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Grąžina šaltinio tekstą už intervalo.
    /// Taip išsaugomas pradinis šaltinio kodas, įskaitant tarpus ir komentarus.
    /// Rezultatas pateikiamas tik tuo atveju, jei diapazonas atitinka tikrąjį šaltinio kodą.
    ///
    /// Note: Stebimas makrokomandos rezultatas turėtų remtis tik tokens, o ne šiuo šaltinio tekstu.
    ///
    /// Šios funkcijos rezultatas yra geriausia pastanga, skirta naudoti tik diagnostikai.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Spausdina sritį forma, patogia derinti.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Linijos ir stulpelio pora, žyminti `Span` pradžią arba pabaigą.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// 1 indeksuota eilutė šaltinio faile, kurioje prasideda arba baigiasi (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0 indeksuotas stulpelis (UTF-8 simboliais) šaltinio faile, kuriame prasideda arba baigiasi (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Nurodyto `Span` šaltinio failas.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Gauna kelią į šį šaltinio failą.
    ///
    /// ### Note
    /// Jei su šiuo `SourceFile` susietą kodo diapazoną sugeneravo išorinė makrokomanda, ši makrokomanda gali būti ne tikrasis failų sistemos kelias.
    /// Norėdami patikrinti, naudokite [`is_real`].
    ///
    /// Taip pat atkreipkite dėmesį, kad net jei `is_real` grąžina `true`, jei `--remap-path-prefix` buvo perduotas komandinėje eilutėje, nurodytas kelias gali būti netinkamas.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Pateikia `true`, jei šis šaltinio failas yra tikrasis šaltinio failas, o ne sugeneruotas išorinės makrokomandos išplėtimo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Tai yra įsilaužimas, kol bus įdiegti tarpkryptiniai diapazonai ir galėsime turėti tikrus šaltinių failus, kurie bus sukurti išorinėse makrokomandose.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Viena token arba atskira token medžių seka (pvz., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// token srautas, kurį supa skliaustų ribotuvai.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikatorius.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Vienas skyrybos ženklas (" +`, `,`, `$` ir kt.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Pažodinis simbolis (`'a'`), eilutė (`"hello"`), skaičius (`2.3`) ir kt.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Grąžina šio medžio atkarpą, priskirdamas `span` metodą esančiam token arba atskirtam srautui.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigūruoja diapazoną *tik šiam token*.
    ///
    /// Atkreipkite dėmesį, kad jei šis " token`yra " `Group`, šis metodas nekonfigūruos kiekvieno vidinio " tokens` intervalo, tai paprasčiausiai bus perduota kiekvieno varianto `set_span` metodui.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Spausdina token medį patogia derinti forma.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kiekvienas iš jų turi struktūros tipo pavadinimą išvestiniame derinime, todėl nesijaudinkite dėl papildomo nukreipimo sluoksnio
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Spausdina token medį kaip eilutę, kuri turėtų būti be nuostolių konvertuojama atgal į tą patį token medį (modulio apimtis), išskyrus galbūt " TokenTree: : Group` su `Delimiter::None` atribotais ir neigiamais skaitmeniniais litrais.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Apribotas token srautas.
///
/// " `Group` viduje yra " `TokenStream`, kurį supa " Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Aprašoma, kaip atribojama token medžių seka.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Netiesioginis ribotuvas, kuris, pavyzdžiui, gali atsirasti aplink tokens, gaunamą iš "macro variable" `$var`.
    /// Svarbu išsaugoti operatoriaus prioritetus tokiais atvejais kaip `$var * 3`, kai `$var` yra `1 + 2`.
    /// Netiesioginiai ribotuvai gali neišgyventi iš token srauto per eilutę.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Sukuria naują `Group` su nurodytu atskyrikliu ir token srautu.
    ///
    /// Šis konstruktorius nustatys šios grupės diapazoną į `Span::call_site()`.
    /// Norėdami pakeisti diapazoną, galite naudoti toliau pateiktą `set_span` metodą.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Grąžina šio `Group` ribotuvą
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Pateikia tokens `TokenStream`, kuris yra atribotas šiame `Group`.
    ///
    /// Atkreipkite dėmesį, kad į grąžintą token srautą neįtrauktas aukščiau pateiktas ribotuvas.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Grąžina šio token srauto ribotuvų diapazoną, aprėpiantį visą `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Grąžina intervalą, nukreipiantį į šios grupės pradinį skiriamąjį elementą.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Grąžina intervalą, nurodantį šios grupės uždarymo ribotuvą.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigūruoja šios " grupės` ribotuvų diapazoną, bet ne vidinius tokens.
    ///
    /// Šis metodas ** nenustatys visų vidinių tokens diapazonų, kuriuos apėmė ši grupė, bet jis nustatys tik ribotuvo tokens diapazoną `Group` lygyje.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Spausdina grupę kaip eilutę, kurią be nuostolių galima konvertuoti atgal į tą pačią grupę (modulio apimtis), išskyrus galbūt " TokenTree: : Group` su `Delimiter::None` skyrikliais.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` yra vienas skyrybos ženklas, pvz., `+`, `-` arba `#`.
///
/// Daugelio simbolių operatoriai, pvz., `+=`, vaizduojami kaip du `Punct` egzemplioriai su skirtingomis `Spacing` formomis.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ar po `Punct` iškart seka kitas `Punct`, ar kitas token, ar tarpas.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// pvz., `+` yra `Alone` `+ =`, `+ident` arba `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// pvz., `+` yra `Joint`, esantis `+=` arba `'#`.
    /// Be to, viena citata `'` gali prisijungti prie identifikatorių ir sudaryti `'ident` gyvenimo trukmę.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Sukuria naują `Punct` iš nurodyto simbolio ir tarpų.
    /// `ch` argumentas turi būti galiojantis skyrybos ženklas, kurį leidžia kalba, kitaip funkcija bus panic.
    ///
    /// Grąžintame " `Punct` numatytasis diapazonas yra " `Span::call_site()`, kurį galima toliau sukonfigūruoti naudojant toliau pateiktą `set_span` metodą.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Pateikia šio skyrybos simbolio vertę kaip `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Grąžina šio skyrybos ženklo tarpą, nurodydamas, ar iškart po jo seka kitas `Punct` sraute token, kad juos būtų galima sujungti į daugybinių ženklų operatorių (`Joint`), arba po jo-kitas token arba tarpas (`Alone`), todėl operatorius tikrai pasibaigė.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Grąžina šio skyrybos simbolio intervalą.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigūruokite šio skyrybos ženklo intervalą.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Skyrybos ženklą išspausdina kaip eilutę, kuri turėtų būti be nuostolių konvertuojama atgal į tą patį simbolį.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikatorius (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Sukuria naują `Ident` su nurodytu `string` ir nurodytu `span`.
    /// `string` argumentas turi būti galiojantis kalbos leidžiamas identifikatorius (įskaitant raktinius žodžius, pvz., `self` arba `fn`).Kitu atveju funkcija bus panic.
    ///
    /// Atminkite, kad `span`, šiuo metu esanti rustc, konfigūruoja šio identifikatoriaus higienos informaciją.
    ///
    /// Nuo to laiko " `Span::call_site()` aiškiai pasirenka " "call-site" higieną, o tai reiškia, kad identifikatoriai, sukurti naudojant šį intervalą, bus išspręsti taip, tarsi jie būtų parašyti tiesiogiai makrokomandos skambučio vietoje, o kitas makrokomandos skambučio kodas galės nurodyti juos taip pat.
    ///
    ///
    /// Vėliau, pvz., " `Span::def_site()`, bus leidžiama pasirinkti " "definition-site" higieną, o tai reiškia, kad identifikatoriai, sukurti naudojant šį intervalą, bus išspręsti makrokomandos apibrėžimo vietoje, o kitas makrokomandos skambučio kodas negalės į juos kreiptis.
    ///
    /// Dėl dabartinės higienos svarbos šiam konstruktoriui, skirtingai nei kitiems " tokens`, reikia, kad statyboje būtų nurodytas `Span`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Tas pats kaip `Ident::new`, bet sukuria neapdorotą identifikatorių (`r#ident`).
    /// `string` argumentas turi būti galiojantis kalbos leidžiamas identifikatorius (įskaitant raktinius žodžius, pvz., `fn`).
    /// Raktiniai žodžiai, kurie gali būti naudojami kelio segmentuose (pvz.,
    /// `self`, " super`) nepalaikomi ir sukels panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Grąžina šio `Ident` intervalą, apimantį visą [`to_string`](Self::to_string) grąžintą eilutę.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigūruoja šio `Ident` diapazoną, galbūt pakeisdamas jo higienos kontekstą.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Spausdina identifikatorių kaip eilutę, kurią galima be nuostolių konvertuoti atgal į tą patį identifikatorių.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Pažodinė eilutė (`"hello"`), baitų eilutė (`b"hello"`), simbolis (`'a'`), baito simbolis (`b'a'`), sveikasis skaičius arba slankiojo kablelio skaičius su galūne arba be jos (" 1`, `1u8`, `2.3`, `2.3f32`).
///
/// Būlio literalai, tokie kaip `true` ir `false`, čia nepriklauso, jie yra " Ident`.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Sukuria naują pridedamą sveiko skaičiaus pažodį su nurodyta verte.
        ///
        /// Ši funkcija sukurs tokį sveiką skaičių kaip `1u32`, kur nurodyta sveiko skaičiaus reikšmė yra pirmoji token dalis, o integralas taip pat pridedamas prie galo.
        /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi pirmyn ir atgal per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamą pažodinį).
        ///
        ///
        /// Naudojant šį metodą sukurtuose literaluose pagal numatytuosius nustatymus yra `Span::call_site()` diapazonas, kurį galima sukonfigūruoti taikant toliau pateiktą `set_span` metodą.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Sukuria naują nepridėtą sveiko skaičiaus pažodį su nurodyta verte.
        ///
        /// Ši funkcija sukurs sveiką skaičių, pvz., `1`, kur nurodyta sveiko skaičiaus reikšmė yra pirmoji token dalis.
        /// Šiame token nenurodoma jokia priesaga, o tai reiškia, kad tokios iškvietos kaip `Literal::i8_unsuffixed(1)` yra lygiavertės `Literal::u32_unsuffixed(1)`.
        /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamas pažodinis).
        ///
        ///
        /// Naudojant šį metodą sukurtuose literaluose pagal numatytuosius nustatymus yra `Span::call_site()` diapazonas, kurį galima sukonfigūruoti taikant toliau pateiktą `set_span` metodą.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Sukuria naują nepritvirtintą slankiojo kablelio pažodį.
    ///
    /// Šis konstruktorius yra panašus į tokius, kaip `Literal::i8_unsuffixed`, kur plūdės vertė yra išspaudžiama tiesiai į token, tačiau nenaudojama priesaga, todėl vėliau kompiliatoriuje gali būti daroma išvada, kad tai `f64`.
    ///
    /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamas pažodinis).
    ///
    /// # Panics
    ///
    /// Ši funkcija reikalauja, kad nurodytas plūdė būtų baigtinis, pavyzdžiui, jei ji yra begalybė arba NaN, ši funkcija bus panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Sukuria naują priesagą slankiojo kablelio pažodžiui.
    ///
    /// Šis konstruktorius sukurs tokį pažodį kaip `1.0f32`, kur nurodyta reikšmė yra ankstesnė token dalis, o `f32` yra token priesaga.
    /// Kompiliatoriuje visada bus daroma išvada, kad šis token yra `f32`.
    /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamas pažodinis).
    ///
    ///
    /// # Panics
    ///
    /// Ši funkcija reikalauja, kad nurodytas plūdė būtų baigtinis, pavyzdžiui, jei ji yra begalybė arba NaN, ši funkcija bus panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Sukuria naują nepritvirtintą slankiojo kablelio pažodį.
    ///
    /// Šis konstruktorius yra panašus į tokius, kaip `Literal::i8_unsuffixed`, kur plūdės vertė yra išspaudžiama tiesiai į token, tačiau nenaudojama priesaga, todėl vėliau kompiliatoriuje gali būti daroma išvada, kad tai `f64`.
    ///
    /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamas pažodinis).
    ///
    /// # Panics
    ///
    /// Ši funkcija reikalauja, kad nurodytas plūdė būtų baigtinis, pavyzdžiui, jei ji yra begalybė arba NaN, ši funkcija bus panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Sukuria naują priesagą slankiojo kablelio pažodžiui.
    ///
    /// Šis konstruktorius sukurs tokį pažodį kaip `1.0f64`, kur nurodyta reikšmė yra ankstesnė token dalis, o `f64` yra token priesaga.
    /// Kompiliatoriuje visada bus daroma išvada, kad šis token yra `f64`.
    /// Literatūra, sukurta iš neigiamų skaičių, negali išgyventi per `TokenStream` ar eilutes ir gali būti suskaidyta į dvi tokens (`-` ir teigiamas pažodinis).
    ///
    ///
    /// # Panics
    ///
    /// Ši funkcija reikalauja, kad nurodytas plūdė būtų baigtinis, pavyzdžiui, jei ji yra begalybė arba NaN, ši funkcija bus panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Styginis pažodinis.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Simbolis pažodinis.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Baitų eilutės pažodinis.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Pateikia diapazoną, apimantį šį pažodį.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigūruoja šiam literalui susietą diapazoną.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Pateikia `Span`, kuris yra `self.span()` pogrupis, kuriame yra tik `range` diapazono šaltinio baitai.
    /// Pateikia `None`, jei numatoma apkarpymo riba yra už `self` ribų.
    ///
    // FIXME(SergioBenitez): patikrinkite, ar baitų diapazonas prasideda ir baigiasi ties UTF-8 šaltinio riba.
    // priešingu atveju tikėtina, kad spausdinant šaltinio tekstą panic atsiras kitur.
    // FIXME(SergioBenitez): vartotojas niekaip negali žinoti, su kuo iš tikrųjų susieja " `self.span()`, todėl šiuo metu šį metodą galima vadinti tik aklai.
    // Pavyzdžiui, `to_string()` simboliui 'c' grąžina "'\u{63}'";vartotojas niekaip negali žinoti, ar šaltinio tekstas buvo 'c', ar '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) kažkas panašaus į `Option::cloned`, bet skirtas `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, tiltas teikia tik " `to_string`, jo pagrindu įgyvendinkite " `fmt::Display` (atvirkštinis įprastas abiejų santykis).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Spausdina pažodį kaip eilutę, kurią be nuostolių galima konvertuoti atgal į tą patį literalą (išskyrus galimą slankiojo kablelio literalų apvalinimą).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Stebima prieiga prie aplinkos kintamųjų.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Gaukite aplinkos kintamąjį ir pridėkite jį, kad sukurtumėte priklausomybės informaciją.
    /// Kompiliatorių vykdanti " Build` sistema žinos, kad kintamasis buvo pasiektas kompiliavimo metu, ir galės iš naujo paleisti kūrinį, kai pasikeis to kintamojo vertė.
    ///
    /// Be priklausomybės stebėjimo, ši funkcija turėtų būti lygi `env::var` iš standartinės bibliotekos, išskyrus tai, kad argumentas turi būti UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}