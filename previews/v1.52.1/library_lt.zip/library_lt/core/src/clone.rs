//! " `Clone` trait`tipams, kurių negalima " netiesiogiai nukopijuoti`.
//!
//! Programoje Rust kai kurie paprasti tipai yra "implicitly copyable" ir, kai juos priskiriate arba perduodate kaip argumentus, imtuvas gaus kopiją, palikdamas pradinę vertę vietoje.
//! Šiems tipams nereikia paskirstymo, kad būtų galima kopijuoti, ir neturi baigiamųjų programų (ty juose nėra priklausančių langelių ar " [`Drop`]), todėl kompiliatorius mano, kad juos pigu ir saugu kopijuoti.
//!
//! Kitų tipų kopijos turi būti daromos aiškiai pagal susitarimą, įgyvendinantį " [`Clone`] trait`ir paskambinus metodu " [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Pagrindinis naudojimo pavyzdys:
//!
//! ```
//! let s = String::new(); // Styginiai tipo klonai
//! let copy = s.clone(); // kad galėtume jį klonuoti
//! ```
//!
//! Norėdami lengvai įdiegti " Clone trait`, taip pat galite naudoti " `#[derive(Clone)]`.Pavyzdys:
//!
//! ```
//! #[derive(Clone)] // prie Morfėjo struktūros pridedame kloną trait
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ir dabar mes galime jį klonuoti!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Paprastas trait, skirtas galimybei aiškiai kopijuoti objektą.
///
/// Skiriasi nuo " [`Copy`] tuo, kad " [`Copy`] yra numanomas ir labai nebrangus, o " `Clone` visada yra aiškus ir gali būti brangus, o gal ir nebrangus.
/// Norint užtikrinti šias charakteristikas, Rust neleidžia iš naujo įdiegti [`Copy`], tačiau galite iš naujo įdiegti `Clone` ir paleisti savavališką kodą.
///
/// Kadangi " `Clone` yra bendresnis nei " [`Copy`], galite automatiškai padaryti viską, kad [`Copy`] būtų ir `Clone`.
///
/// ## Derivable
///
/// Šį " trait`galima naudoti su `#[derive]`, jei visi laukai yra `Clone`." Išvestinis` [`Clone`] įgyvendinimas iškviečia [`clone`] kiekviename lauke.
///
/// [`clone`]: Clone::clone
///
/// Jei reikia bendros struktūros, `#[derive]` sąlygiškai įgyvendina `Clone`, pridėdamas susietą `Clone` apie bendruosius parametrus.
///
/// ```
/// // `derive` įgyvendina skaitymo kloną<T>kai T yra klonas.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kaip galiu įdiegti " `Clone`?
///
/// [`Copy`] tipai turėtų būti nereikšmingi `Clone`.Oficialiau:
/// jei `T: Copy`, `x: T` ir `y: &T`, tai `let x = y.clone();` yra lygiavertis `let x = *y;`.
/// Rankinis diegimas turėtų būti atsargus, kad būtų išlaikytas šis nekintamasis;tačiau nesaugus kodas neturi juo remtis užtikrinant atminties saugumą.
///
/// Pavyzdys yra bendrasis rodinys, turintis funkcijos rodyklę.Tokiu atveju `Clone` diegimo negalima " išvesti`, bet jis gali būti įgyvendinamas kaip:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Papildomi įgyvendintojai
///
/// Be " [implementors listed below][impls], šie tipai taip pat įdiegia " `Clone`:
///
/// * Funkcijų elementų tipai (ty kiekvienai funkcijai nustatyti atskiri tipai)
/// * Funkcijos žymeklio tipai (pvz., `fn() -> i32`)
/// * Visų dydžių masyvo tipai, jei elemento tipas taip pat įdiegia `Clone` (pvz., `[i32; 123456]`)
/// * Tuple tipai, jei kiekvienas komponentas taip pat įdiegia `Clone` (pvz., `()`, `(i32, bool)`)
/// * Uždarymo tipai, jei jie nepriima jokios aplinkos vertės arba jei visos tokios užfiksuotos vertės pačios įgyvendina " `Clone`.
///   Atminkite, kad kintamieji, užfiksuoti naudojant bendrą nuorodą, visada įgyvendina `Clone` (net jei referentas to nepadaro), o kintamosios nuorodos užfiksuoti kintamieji niekada neįgyvendina `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Grąžina vertės kopiją.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str įgyvendina Kloną
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Atlieka kopijavimo užduotį iš `source`.
    ///
    /// `a.clone_from(&b)` yra lygiavertis " `a = b.clone()` funkcionalumui, tačiau gali būti pakeistas norint pakartotinai naudoti " `a` išteklius, kad būtų išvengta nereikalingų paskirstymų.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Išveskite makrokomandą, generuojančią trait `Clone` implikaciją.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): šias struktūras naudoja tik#[darinys], norėdamas teigti, kad kiekvienas tipo komponentas įgyvendina kloną arba kopiją.
//
//
// Šios struktūros niekada neturėtų būti rodomos vartotojo kode.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` įgyvendinimas primityviems tipams.
///
/// Diegimai, kurių negalima aprašyti programoje Rust, yra įdiegiami `traits::SelectionContext::copy_clone_conditions()` sistemoje `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Bendras nuorodas galima klonuoti, bet kintamos nuorodos *negali*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Bendras nuorodas galima klonuoti, bet kintamos nuorodos *negali*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}