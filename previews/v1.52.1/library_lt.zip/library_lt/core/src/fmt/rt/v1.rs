//! Tai yra vidinis modulis, kurį naudoja " ifmt!vykdymo laikas.Šios struktūros yra išleidžiamos į statinius masyvus, kad iš anksto būtų galima kompiliuoti formato eilutes.
//!
//! Šie apibrėžimai yra panašūs į jų `ct` ekvivalentus, tačiau skiriasi tuo, kad juos galima statiškai priskirti ir šiek tiek optimizuoti vykdymo metu
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Galimi sulyginimai, kurių galima paprašyti kaip formatavimo direktyvos dalį.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Nurodymas, kad turinys turi būti sulygiuotas kairėje.
    Left,
    /// Nurodymas, kad turinys turi būti sulygiuotas dešinėn.
    Right,
    /// Nurodymas, kad turinys turi būti sulygiuotas centre.
    Center,
    /// Neprašyta derinti.
    Unknown,
}

/// Naudoja " [width](https://doc.rust-lang.org/std/fmt/#width) ir " [precision](https://doc.rust-lang.org/std/fmt/#precision) specifikacijos.
#[derive(Copy, Clone)]
pub enum Count {
    /// Nurodytas pažodiniu skaičiumi, išsaugo vertę
    Is(usize),
    /// Nurodytas naudojant `$` ir `*` sintakses, indeksas saugomas `args`
    Param(usize),
    /// Nenurodyta
    Implied,
}