use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Apklija, neleidžianti kompiliatoriui automatiškai iškviesti " T` destruktoriaus.
/// Šis įvyniojimas yra 0 kainos.
///
/// `ManuallyDrop<T>` yra ta pati maketo optimizacija kaip ir `T`.
/// Dėl to jis neturi *įtakos* prielaidoms, kurias kompiliatorius daro dėl savo turinio.
/// Pavyzdžiui, `ManuallyDrop<&mut T>` inicijavimas naudojant [`mem::zeroed`] yra neapibrėžtas elgesys.
/// Jei jums reikia tvarkyti neinicijuotus duomenis, vietoj to naudokite " [`MaybeUninit<T>`].
///
/// Atminkite, kad pasiekti vertę `ManuallyDrop<T>` viduje yra saugu.
/// Tai reiškia, kad " `ManuallyDrop<T>`, kurio turinys buvo atmestas, negalima rodyti per viešai saugų API.
/// Atitinkamai `ManuallyDrop::drop` yra nesaugus.
///
/// # `ManuallyDrop` ir atsisakyti tvarkos.
///
/// Rust turi tiksliai apibrėžtas [drop order] reikšmes.
/// Norėdami įsitikinti, kad laukai ar vietiniai gyventojai yra išmesti tam tikra tvarka, pertvarkykite deklaracijas taip, kad numanomoji numetimo tvarka būtų teisinga.
///
/// Galima naudoti " `ManuallyDrop`, kad būtų galima valdyti numetimo tvarką, tačiau tam reikalingas nesaugus kodas ir sunku teisingai atlikti, jei atsukama.
///
///
/// Pvz., Jei norite įsitikinti, kad konkretus laukas numestas po kitų, paverskite jį paskutiniu struktūros lauku:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bus atsisakyta po `children`.
///     // Rust garantuoja, kad laukai bus atmesti deklaravimo tvarka.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Apvyniokite vertę, kurią norite numesti rankiniu būdu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Vis tiek galite saugiai valdyti vertę
    /// assert_eq!(*x, "Hello");
    /// // Bet " `Drop` čia nebus paleistas
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Išgauna vertę iš " `ManuallyDrop` talpyklos.
    ///
    /// Tai leidžia vėl mesti vertę.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Tai numeta " `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Išimama `ManuallyDrop<T>` talpyklos vertė.
    ///
    /// Šis metodas pirmiausia yra skirtas vertėms perkelti į kritimą.
    /// Užuot naudoję " [`ManuallyDrop::drop`] rankiniu būdu numesti vertę, galite naudoti šį metodą, norėdami paimti vertę ir naudoti ją taip, kaip norite.
    ///
    /// Kai tik įmanoma, geriau naudoti " [`into_inner`][`ManuallyDrop::into_inner`], kuris neleidžia dubliuoti " `ManuallyDrop<T>` turinio.
    ///
    ///
    /// # Safety
    ///
    /// Ši funkcija semantiškai perkelia esančią vertę, netrukdydama tolesniam naudojimui, palikdama šio konteinerio būseną nepakitusią.
    /// Jūs esate atsakingas už tai, kad šis `ManuallyDrop` nebūtų naudojamas pakartotinai.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAUGA: skaitome iš nuorodos, kuri yra garantuota
        // kad galioja skaitymams.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Rankiniu būdu numeta nurodytą vertę.Tai tiksliai prilygsta [`ptr::drop_in_place`] iškvietimui su rodikliu į nurodytą vertę.
    /// Išskyrus atvejus, kai turima reikšmė yra supakuota struktūra, destruktorius bus vadinamas vietoje, nepajudinant vertės, taigi jis gali būti naudojamas saugiai išmesti [pinned] duomenis.
    ///
    /// Jei turite vertės nuosavybę, galite naudoti " [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ši funkcija paleidžia ribojamos vertės naikintuvą.
    /// Išskyrus paties destruktoriaus atliktus pakeitimus, atmintis lieka nepakitusi, ir kiek tai susiję su kompiliatoriumi, vis tiek turi bitų modelį, kuris galioja `T` tipui.
    ///
    ///
    /// Tačiau šiai "zombie" reikšmei neturėtų būti taikomas saugus kodas ir ši funkcija neturėtų būti vadinama daugiau nei vieną kartą.
    /// Jei naudosite vertę po to, kai ji bus numesta, arba kelis kartus nukritus, tai gali sukelti neapibrėžtą elgesį (priklausomai nuo to, ką veikia " `drop`).
    /// Paprastai to neleidžia tipo sistema, tačiau " `ManuallyDrop` vartotojai privalo garantuoti šias garantijas be kompiliatoriaus pagalbos.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SAUGA: mes metame vertę, nurodytą kintama nuoroda
        // kuris garantuotai galioja rašant.
        // Skambintojas turi įsitikinti, kad " `slot` vėl nebus numestas.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}