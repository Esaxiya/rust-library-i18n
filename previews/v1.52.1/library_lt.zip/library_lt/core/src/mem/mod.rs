//! Pagrindinės funkcijos, susijusios su atmintimi.
//!
//! Šiame modulyje yra funkcijos, susijusios su tipų dydžio ir derinimo užklausomis, inicializavimu ir manipuliavimu atmintimi.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Prisiima nuosavybės teisę ir "forgets" apie vertę **, nenaudodamas jos naikintuvo**.
///
/// Visi ištekliai, kuriuos valdo vertė, pvz., Kaupimo atmintis ar failo rankena, amžinai išliks nepasiekiamoje būsenoje.Tačiau tai negarantuoja, kad nuorodos į šią atmintį išliks tinkamos.
///
/// * Jei norite nutekinti atmintį, žr. [`Box::leak`].
/// * Jei norite gauti neapdorotą atminties rodyklę, žr. [`Box::into_raw`].
/// * Jei norite tinkamai išmesti vertę, paleisdami jos naikintuvą, žr. [`mem::drop`].
///
/// # Safety
///
/// `forget` nėra pažymėtas kaip `unsafe`, nes Rust saugumo garantijose nėra garantijos, kad destruktoriai visada veiks.
/// Pvz., Programa gali sukurti etaloninį ciklą naudodama [`Rc`][rc], arba paskambinti [`process::exit`][exit], kad išeitų neveikiant destruktoriams.
/// Taigi leidimas " `mem::forget` naudoti saugiu kodu iš esmės nepakeičia " Rust` saugumo garantijų.
///
/// Be to, nutekėti išteklius, tokius kaip atmintis ar I/O objektai, paprastai nepageidautina.
/// Kai kuriais specializuotais atvejais reikia naudoti FFI ar nesaugų kodą, tačiau net ir tada pirmenybė teikiama " [`ManuallyDrop`].
///
/// Kadangi vertę pamiršti leidžiama, bet koks jūsų parašytas `unsafe` kodas turi leisti šią galimybę.Negalite grąžinti vertės ir tikėtis, kad skambinantysis būtinai paleis vertės naikintuvą.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanoninis saugus " `mem::forget` naudojimas yra apeiti `Drop` trait įdiegtą vertės naikintuvą.Pavyzdžiui, tai nutekins " `File`, t
/// susigrąžinti kintamojo užimamą vietą, bet niekada neuždaryti pagrindinio sistemos ištekliaus:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Tai naudinga, kai pagrindinio ištekliaus nuosavybė anksčiau buvo perkelta į kodą už Rust ribų, pavyzdžiui, perduodant neapdorotų failų aprašą į C kodą.
///
/// # Ryšys su `ManuallyDrop`
///
/// Nors " `mem::forget` taip pat gali būti naudojamas *atminties* nuosavybės perdavimui, tai daroma linkus į klaidas.
/// [`ManuallyDrop`] turėtų būti naudojamas vietoj jų.Apsvarstykite, pavyzdžiui, šį kodą:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Sukurkite `String` naudodami `v` turinį
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // nutekėti `v`, nes jo atmintį dabar tvarko `s`
/// mem::forget(v);  // KLAIDA, v yra neteisinga ir jos negalima perduoti funkcijai
/// assert_eq!(s, "Az");
/// // `s` yra numanomas, o jo atmintis yra paskirstyta.
/// ```
///
/// Pirmiau pateiktame pavyzdyje yra dvi problemos:
///
/// * Jei tarp `String` sukūrimo ir `mem::forget()` iškvietimo būtų pridėta daugiau kodo, jame esantis panic sukeltų dvigubą laisvą laisvę, nes tą pačią atmintį tvarko ir `v`, ir `s`.
/// * Paskambinus `v.as_mut_ptr()` ir perduodant duomenų nuosavybės teisę į `s`, `v` reikšmė yra neteisinga.
/// Net kai vertė yra tiesiog perkelta į `mem::forget` (kuri jos netikrins), kai kurių tipų vertėms taikomi griežti reikalavimai, dėl kurių jos tampa negaliojančios, kai jos kabo arba nebeturi.
/// Bet koks netinkamų reikšmių naudojimas, įskaitant jų perdavimą funkcijoms ar jų grąžinimą, yra neapibrėžtas elgesys ir gali sulaužyti kompiliatoriaus prielaidas.
///
/// Perėjus į " `ManuallyDrop` išvengiama abiejų problemų:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Prieš išardydami `v` į neapdorotas dalis, įsitikinkite, kad jis nenukris!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Dabar išardykite `v`.Šios operacijos negali būti " panic`, todėl negali būti nuotėkio.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Galiausiai sukurkite " `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` yra numanomas, o jo atmintis yra paskirstyta.
/// ```
///
/// `ManuallyDrop` tvirtai apsaugo nuo dvigubo nemokamumo, nes prieš ką nors darydami išjungiame " v` destruktorių.
/// `mem::forget()` to neleidžia, nes sunaudoja savo argumentą ir privertė mus jį vadinti tik tada, kai iš " `v` ištraukėme viską, ko mums reikėjo.
/// Net jei tarp " `ManuallyDrop` sukūrimo ir eilutės sukūrimo būtų įvestas " panic` (kas negali atsitikti kode, kaip parodyta), tai sukeltų nutekėjimą, o ne dvigubą laisvą.
/// Kitaip tariant, `ManuallyDrop` klysta dėl nutekėjimo pusės, užuot suklydęs (dvigubo) nuleidimo pusėje.
///
/// Be to, " `ManuallyDrop` neleidžia mums naudotis " "touch" `v`, perleidus nuosavybės teisę į " `s`-visiškai išvengiama paskutinio sąveikos su " `v` žingsnio, kad ją pašalintumėte neveikdami jo naikintuvo.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Kaip ir " [`forget`], bet taip pat priima nedidelis vertes.
///
/// Ši funkcija yra tik tarpinė, kurią reikia pašalinti, kai stabilizuojasi " `unsized_locals` funkcija.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Grąžina tipo dydį baitais.
///
/// Tiksliau tariant, tai yra baitų skirtumas tarp masyvo einančių elementų su to elemento tipu, įskaitant derinimo užpildą.
///
/// Taigi bet kokio tipo `T` ir ilgio `n` atveju `[T; n]` dydis yra `n * size_of::<T>()`.
///
/// Paprastai tipo dydis nėra stabilus visuose rinkiniuose, tačiau konkretūs tipai, tokie kaip primityvai, yra.
///
/// Šioje lentelėje nurodomas primityvų dydis.
///
/// Tipas |dydis: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 simboliai |4
///
/// Be to, " `usize` ir " `isize` turi tą patį dydį.
///
/// Visi `*const T`, `&T`, `Box<T>`, `Option<&T>` ir `Option<Box<T>>` tipai yra vienodo dydžio.
/// Jei " `T` yra dydžio, visų šių tipų dydis yra toks pat kaip " `usize`.
///
/// Rodyklės kintamumas nekeičia jo dydžio.Taigi, " `&T` ir " `&mut T` turi tą patį dydį.
/// Taip pat ir " `*const T` ir " `* mut T`.
///
/// # `#[repr(C)]` elementų dydis
///
/// `C` elementų atvaizdavimas turi apibrėžtą išdėstymą.
/// Naudojant šį išdėstymą, elementų dydis taip pat yra stabilus, jei visi laukai yra stabilaus dydžio.
///
/// ## Struktūrų dydis
///
/// " `structs` dydis nustatomas pagal šį algoritmą.
///
/// Kiekvienam struktūros laukui, išdėstytam deklaracijos tvarka:
///
/// 1. Pridėkite lauko dydį.
/// 2. Suapvalinkite dabartinį dydį iki artimiausio kito lauko [alignment] kartotinio.
///
/// Galiausiai suapvalinkite struktūros dydį iki artimiausio jo [alignment] kartotinio.
/// Struktūros lygiavimas paprastai yra didžiausias visų jo laukų lygiavimas;tai galima pakeisti naudojant `repr(align(N))`.
///
/// Skirtingai nuo " `C`, nulio dydžio struktūros nėra suapvalintos iki vieno baito dydžio.
///
/// ## Enums dydis
///
/// Sumos, kuriose nėra jokių kitų duomenų, išskyrus diskriminantą, yra tokio pat dydžio kaip C enums platformoje, kuriai jie yra sudaryti.
///
/// ## Sąjungos dydis
///
/// Sąjungos dydis yra didžiausio jos lauko dydis.
///
/// Skirtingai nuo " `C`, nulio dydžio sąjungos nėra suapvalintos iki vieno baito dydžio.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Kai kurie primityvūs
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Kai kurie masyvai
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Rodyklės dydžio lygybė
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Naudojant " `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Pirmojo lauko dydis yra 1, todėl prie dydžio pridėkite 1.Dydis yra 1.
/// // Antrojo lauko lygiuotė yra 2, todėl pridėkite 1 prie užpildo dydžio.Dydis yra 2.
/// // Antrojo lauko dydis yra 2, todėl prie dydžio pridėkite 2.Dydis yra 4.
/// // Trečiojo lauko lygiuotė yra 1, todėl pridėkite 0 prie užpildo dydžio.Dydis yra 4.
/// // Trečiojo lauko dydis yra 1, todėl prie dydžio pridėkite 1.Dydis yra 5.
/// // Galiausiai struktūros lygiavimas yra 2 (nes didžiausias jo laukų lygiavimas yra 2), todėl pridėkite 1 prie užpildymo dydžio.
/// // Dydis yra 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple struktūros laikosi tų pačių taisyklių.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Atminkite, kad pertvarkius laukus, dydis gali sumažėti.
/// // Abiejų užpildymo baitus galime pašalinti įdėdami `third` prieš `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Sąjungos dydis yra didžiausio lauko dydis.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Grąžina nurodytos vertės dydį baitais.
///
/// Paprastai tai yra tas pats, kas " `size_of::<T>()`.
/// Tačiau kai `T`*neturi* statiškai žinomo dydžio, pvz., [`[T]`][slice] arba [trait object] griežinėlio, tada norint gauti dinamiškai žinomą dydį, galima naudoti `size_of_val`.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SAUGUMAS: `val` yra nuoroda, todėl tai yra tinkamas neapdorotas žymeklis
    unsafe { intrinsics::size_of_val(val) }
}

/// Grąžina nurodytos vertės dydį baitais.
///
/// Paprastai tai yra tas pats, kas " `size_of::<T>()`.Tačiau, kai `T` * neturi statiškai žinomo dydžio, pvz., [`[T]`][slice] arba [trait object] griežinėlio, tada norint gauti dinamiškai žinomą dydį, galima naudoti `size_of_val_raw`.
///
/// # Safety
///
/// Šia funkcija saugu skambinti tik tuo atveju, jei yra šios sąlygos:
///
/// - Jei " `T` yra " `Sized`, šią funkciją visada saugu skambinti.
/// - Jei nedidelis " `T` uodega yra:
///     - [slice], tada gabalo uodegos ilgis turi būti inicializuotas sveikasis skaičius, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi tilpti į `isize`.
///     - " [trait object], tada rodomoji rodiklio dalis turi būti nukreipta į galiojantį " vtable`, įgytą nedidinant prievartos, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi atitikti `isize`.
///
///     - (unstable) [extern type], tada šią funkciją visada saugu skambinti, tačiau ji gali panic ar kitaip grąžinti neteisingą vertę, nes išorinio tipo išdėstymas nėra žinomas.
///     Tai yra tas pats elgesys kaip [`size_of_val`], kai nuoroda į tipą su išorinio tipo uodega.
///     - kitaip konservatyviai negalima skambinti šia funkcija.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAUGA: skambinantysis turi pateikti galiojantį neapdorotą rodyklę
    unsafe { intrinsics::size_of_val(val) }
}

/// Grąžina reikalaujamą minimalų tipo sulyginimą [ABI].
///
/// Kiekviena nuoroda į `T` tipo vertę turi būti šio skaičiaus kartotinė.
///
/// Tai yra lygiavimas, naudojamas struktūriniams laukams.Jis gali būti mažesnis nei pageidaujamas lygiavimas.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Grąžina [ABI] reikalaujamą minimalų vertės, į kurią nukreipia `val`, tipo išlyginimą.
///
/// Kiekviena nuoroda į `T` tipo vertę turi būti šio skaičiaus kartotinė.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAUGA: val yra nuoroda, todėl tai yra tinkamas neapdorotas rodyklė
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Grąžina reikalaujamą minimalų tipo sulyginimą [ABI].
///
/// Kiekviena nuoroda į `T` tipo vertę turi būti šio skaičiaus kartotinė.
///
/// Tai yra lygiavimas, naudojamas struktūriniams laukams.Jis gali būti mažesnis nei pageidaujamas lygiavimas.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Grąžina [ABI] reikalaujamą minimalų vertės, į kurią nukreipia `val`, tipo išlyginimą.
///
/// Kiekviena nuoroda į `T` tipo vertę turi būti šio skaičiaus kartotinė.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SAUGA: val yra nuoroda, todėl tai yra tinkamas neapdorotas rodyklė
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Grąžina [ABI] reikalaujamą minimalų vertės, į kurią nukreipia `val`, tipo išlyginimą.
///
/// Kiekviena nuoroda į `T` tipo vertę turi būti šio skaičiaus kartotinė.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Šia funkcija saugu skambinti tik tuo atveju, jei yra šios sąlygos:
///
/// - Jei " `T` yra " `Sized`, šią funkciją visada saugu skambinti.
/// - Jei nedidelis " `T` uodega yra:
///     - [slice], tada gabalo uodegos ilgis turi būti inicializuotas sveikasis skaičius, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi tilpti į `isize`.
///     - " [trait object], tada rodomoji rodiklio dalis turi būti nukreipta į galiojantį " vtable`, įgytą nedidinant prievartos, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi atitikti `isize`.
///
///     - (unstable) [extern type], tada šią funkciją visada saugu skambinti, tačiau ji gali panic ar kitaip grąžinti neteisingą vertę, nes išorinio tipo išdėstymas nėra žinomas.
///     Tai yra tas pats elgesys kaip [`align_of_val`], kai nuoroda į tipą su išorinio tipo uodega.
///     - kitaip konservatyviai negalima skambinti šia funkcija.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SAUGA: skambinantysis turi pateikti galiojantį neapdorotą rodyklę
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Grąžina `true`, jei svarbios kritimo `T` tipo vertės.
///
/// Tai tik optimizavimo užuomina ir gali būti įgyvendinama konservatyviai:
/// jis gali grąžinti `true` tipams, kurių iš tikrųjų nereikia mesti.
/// Visada grąžinamas `true` būtų tinkamas šios funkcijos įgyvendinimas.Tačiau jei ši funkcija iš tikrųjų grąžina `false`, tada galite būti tikri, kad `T` nuleidimas neturi šalutinio poveikio.
///
/// Žemo lygio dalykų, pvz., Kolekcijų, kuriems reikia rankiniu būdu mesti duomenis, įgyvendinimas turėtų naudoti šią funkciją, kad būtų išvengta nereikalingo bandymo išmesti visą jų turinį, kai jie sunaikinami.
///
/// Tai gali neturėti jokio skirtumo leidimų versijose (kai kilpa, neturinti šalutinių poveikių, lengvai aptinkama ir pašalinama), tačiau dažnai tai yra didelis derinimo derinių laimėjimas.
///
/// Atkreipkite dėmesį, kad " [`drop_in_place`] jau atlieka šį patikrinimą, taigi, jei jūsų darbo krūvį galima sumažinti iki nedidelio skaičiaus " [`drop_in_place`] skambučių, tai naudoti nereikia.
/// Visų pirma atkreipkite dėmesį, kad galite [`drop_in_place`] gabalėlį, ir tai atliks vieną visų reikmių patikrinimą needs_drop.
///
/// Tokie tipai, kaip " Vec`, todėl tiesiog naudoja " `drop_in_place(&mut self[..])`, aiškiai nenaudodami " `needs_drop`.
/// Kita vertus, tokie tipai kaip " [`HashMap`] turi mesti vertes po vieną ir turėtų naudoti šią API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Štai pavyzdys, kaip kolekcija gali naudoti " `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // numesti duomenis
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Pateikia `T` tipo vertę, išreikštą visų nulių baitų šablonu.
///
/// Tai reiškia, kad, pavyzdžiui, " `(u8, u16)` užpildymo baitas nebūtinai yra nulis.
///
/// Nėra jokios garantijos, kad visų nulių baitų modelis atspindi galiojančią kai kurių tipų `T` vertę.
/// Pvz., Viso nulio baito modelis nėra tinkama nuoroda tipų (" &T`, `&mut T`) ir funkcijų rodyklių reikšmė.
/// Naudojant `zeroed` tokiems tipams, [undefined behavior][ub] atsiranda nedelsiant, nes [the Rust compiler assumes][inv], kad kintamajame, kurį jis laiko inicijuotu, visada yra teisinga reikšmė.
///
///
/// Tai turi tą patį efektą kaip ir " [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Kartais tai naudinga FFI, tačiau paprastai jos reikėtų vengti.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Teisingas šios funkcijos naudojimas: inicijuojamas sveikasis skaičius su nuliu.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Neteisingas* šios funkcijos naudojimas: inicijuojant nuorodą su nuline.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Neapibrėžtas elgesys!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ir vėl!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAUGUMAS: skambinantysis turi garantuoti, kad " `T` galioja nulinė vertė.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Apeina įprastus " Rust` atminties inicializavimo patikrinimus, apsimesdamas `T` tipo reikšme ir nieko nedarydamas.
///
/// **Ši funkcija nebenaudojama.** Vietoj to naudokite " [`MaybeUninit<T>`].
///
/// Nebeveikimo priežastis yra ta, kad funkcija iš esmės negali būti naudojama teisingai: ji turi tą patį poveikį kaip ir [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kaip paaiškina " [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv], kurios reikšmės tinkamai inicijuojamos.
/// Dėl to paskambinus, pvz
/// `mem::uninitialized::<bool>()` sukelia nedelsiant neapibrėžtą elgesį grąžinant `bool`, kuris tikrai nėra nei `true`, nei `false`.
/// Blogesnė, tikrai neinicijuota atmintis, tokia kaip čia grąžinama, yra ypatinga tuo, kad kompiliatorius žino, kad ji neturi fiksuotos vertės.
/// Tai daro neapibrėžtą elgesį, jei kintamajame yra neinicijuotų duomenų, net jei tas kintamasis yra sveiko skaičiaus tipas.
/// (Atkreipkite dėmesį, kad taisyklės, susijusios su neinicijuotais sveikaisiais skaičiais, dar nėra baigtos, tačiau iki jų patartina jų vengti.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SAUGUMAS: skambinantysis turi garantuoti, kad `T` galioja vieninga vertė.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Keičia reikšmes dviejose kintamose vietose, deinicializuodami nė vieną.
///
/// * Jei norite pakeisti numatytąją arba manekeno vertę, žr. [`take`].
/// * Jei norite pakeisti sukauptą reikšmę, grąžindami senąją vertę, žr. [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SAUGA: neapdoroti rodyklės buvo sukurtos iš saugių kintamų nuorodų, tenkinančių visus
    // `ptr::swap_nonoverlapping_one` apribojimai
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` pakeičiama numatytąja `T` verte, grąžinant ankstesnę `dest` vertę.
///
/// * Jei norite pakeisti dviejų kintamųjų reikšmes, žr. [`swap`].
/// * Jei norite pakeisti perduota verte, o ne pagal numatytąją vertę, žr. [`replace`].
///
/// # Examples
///
/// Paprastas pavyzdys:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` leidžia perimti nuosavybės teisę į struktūrinį lauką pakeičiant jį "empty" reikšme.
/// Be " `take` galite susidurti su tokiais klausimais:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Atminkite, kad " `T` nebūtinai įdiegia " [`Clone`], todėl jis net negali klonuoti ir iš naujo nustatyti " `self.buf`.
/// Tačiau `take` galima naudoti norint atskirti pradinę `self.buf` vertę nuo `self`, leidžiant ją grąžinti:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Perkelia `src` į nurodytą `dest`, grąžinant ankstesnę `dest` vertę.
///
/// Nei viena, nei kita vertė nėra numesta.
///
/// * Jei norite pakeisti dviejų kintamųjų reikšmes, žr. [`swap`].
/// * Jei norite pakeisti numatytąja verte, žr. [`take`].
///
/// # Examples
///
/// Paprastas pavyzdys:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` leidžia vartoti struktūrinį lauką pakeičiant jį kita verte.
/// Be " `replace` galite susidurti su tokiais klausimais:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Atkreipkite dėmesį, kad " `T` nebūtinai įdiegia " [`Clone`], todėl mes net negalime klonuoti " `self.buf[i]`, kad išvengtume judėjimo.
/// Tačiau `replace` galima naudoti norint atskirti pradinę to indekso vertę nuo `self`, leidžiant ją grąžinti:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SAUGA: Mes skaitėme iš `dest`, bet po to tiesiogiai įrašėme `src`,
    // tokia, kad senoji vertė nebūtų dubliuojama.
    // Niekas nėra numestas ir nieko čia negali panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disponuoja vertybe.
///
/// Tai daroma paskambinus argumento [`Drop`][drop] įgyvendinimu.
///
/// Tai iš tikrųjų nieko nedaro tipams, kurie įdiegia " `Copy`, pvz
/// integers.
/// Tokios vertės nukopijuojamos ir _then_ perkeliama į funkciją, todėl po šio funkcijos iškvietimo vertė išlieka.
///
///
/// Ši funkcija nėra magija;jis pažodžiui apibrėžiamas kaip
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Kadangi `_x` yra perkeltas į funkciją, jis automatiškai nuleidžiamas, kol funkcija vėl negrįžta.
///
/// [drop]: Drop
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // aiškiai numeskite vector
/// ```
///
/// Kadangi " [`RefCell`] vykdo skolinimosi taisykles vykdymo metu, " `drop` gali išleisti " [`RefCell`] paskolą:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // atsisakyti kintamos paskolos šiame lizde
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// `drop` neturi įtakos sveikiems skaičiams ir kitiems tipams, naudojantiems [`Copy`].
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` kopija perkeliama ir numetama
/// drop(y); // `y` kopija perkeliama ir numetama
///
/// println!("x: {}, y: {}", x, y.0); // vis dar galimas
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretuoja `src` kaip `&U` tipą, tada nuskaito `src`, nejudindamas nustatytos vertės.
///
/// Ši funkcija nesaugiai manys, kad žymeklis `src` galioja [`size_of::<U>`][size_of] baitams, pakeičiant `&T` į `&U` ir perskaičius `&U` (išskyrus tai, kad tai daroma teisingai, net jei `&U` nustato griežtesnius lygiavimo reikalavimus nei `&T`).
/// Taip pat nesaugiai sukurs turimos vertės kopiją, užuot išsikėlęs iš " `src`.
///
/// Tai nėra kompiliavimo laiko klaida, jei " `T` ir " `U` dydžiai skiriasi, tačiau labai rekomenduojama šią funkciją naudoti tik ten, kur " `T` ir " `U` yra vienodo dydžio.Ši funkcija suaktyvina [undefined behavior][ub], jei `U` yra didesnis nei `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Nukopijuokite duomenis iš 'foo_array' ir traktuokite kaip 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Keisti nukopijuotus duomenis
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // " 'foo_array' turinys neturėjo pasikeisti
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Jei U reikalingas didesnis lygiavimo reikalavimas, src gali būti netinkamai išlygintas.
    if align_of::<U>() > align_of::<T>() {
        // SAUGA: `src` yra nuoroda, kuri garantuotai galioja skaitant.
        // Skambinantysis turi garantuoti, kad tikrasis transmutavimas yra saugus.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SAUGA: `src` yra nuoroda, kuri garantuotai galioja skaitant.
        // Mes ką tik patikrinome, ar " `src as *const U` buvo tinkamai sulygiuotas.
        // Skambinantysis turi garantuoti, kad tikrasis transmutavimas yra saugus.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Nepermatomas tipas, žymintis enum diskriminantą.
///
/// Norėdami sužinoti daugiau informacijos, žiūrėkite šio modulio funkciją [`discriminant`].
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Šios " trait` versijos neįmanoma gauti, nes mes nenorime, kad T. būtų ribota.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Pateikia reikšmę, unikaliai identifikuojančią `v` enum variantą.
///
/// Jei " `T` nėra sąrašas, iškviečiant šią funkciją, elgesys nebus apibrėžtas, tačiau grąžinimo vertė nenurodyta.
///
///
/// # Stability
///
/// " Enum`varianto diskriminantas gali pasikeisti, jei keičiasi " Enum` apibrėžtis.
/// Kai kurių variantų diskriminantas nesikeis tarp kompiliacijų su tuo pačiu kompiliatoriumi.
///
/// # Examples
///
/// Tai galima naudoti norint palyginti duomenis, kuriuose yra duomenų, neatsižvelgiant į faktinius duomenis:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Pateikia `T` tipo enum variantų skaičių.
///
/// Jei " `T` nėra sąrašas, iškviečiant šią funkciją, elgesys nebus apibrėžtas, tačiau grąžinimo vertė nenurodyta.
/// Lygiai taip pat, jei `T` yra enumas, turintis daugiau variantų nei `usize::MAX`, grąžinimo vertė nenurodyta.
/// Bus skaičiuojami negyvenami variantai.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}