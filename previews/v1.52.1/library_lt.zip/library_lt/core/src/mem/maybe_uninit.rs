use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Apvyniojimo tipas, skirtas sukurti neinicijuotus `T` egzempliorius.
///
/// # Inicijavimas nekintamas
///
/// Kompiliatorius paprastai daro prielaidą, kad kintamasis yra tinkamai inicializuotas pagal kintamojo tipo reikalavimus.Pavyzdžiui, referencinio tipo kintamasis turi būti sulygiuotas ir ne NULL.
/// Tai nekintamas asmuo, kurio *visada* reikia laikytis, net ir nesaugiu kodu.
/// Todėl nulinio inicializavimo tipo referencinis kintamasis sukelia momentinį [undefined behavior][ub], nesvarbu, ar ši nuoroda kada nors naudojama prieigai prie atminties:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // neapibrėžtas elgesys!⚠️
/// // Ekvivalentiškas kodas su `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // neapibrėžtas elgesys!⚠️
/// ```
///
/// Kompiliatorius tai naudoja įvairioms optimizavimo priemonėms, pvz., Vykdymo laiko patikrinimui ir `enum` išdėstymo optimizavimui.
///
/// Panašiai visiškai neinicijuota atmintis gali turėti bet kokį turinį, o " `bool` visada turi būti " `true` arba " `false`.Taigi, neinicijuoto " `bool` sukūrimas yra neapibrėžtas elgesys:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // neapibrėžtas elgesys!⚠️
/// // Ekvivalentiškas kodas su `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // neapibrėžtas elgesys!⚠️
/// ```
///
/// Be to, neinicijuota atmintis yra ypatinga tuo, kad ji neturi fiksuotos vertės ("fixed" reiškia "it won't change without being written to").Kelis kartus skaitant tą patį neinicijuotą baitą, galima gauti skirtingus rezultatus.
/// Tai daro neapibrėžtą elgesį neinicijuotus duomenis kintamajame, net jei tas kintamasis yra sveiko skaičiaus tipas, kuris kitu atveju gali turėti bet kokį *fiksuotą* bitų modelį:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // neapibrėžtas elgesys!⚠️
/// // Ekvivalentiškas kodas su `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // neapibrėžtas elgesys!⚠️
/// ```
/// (Atkreipkite dėmesį, kad taisyklės, susijusios su neinicijuotais sveikaisiais skaičiais, dar nėra baigtos, tačiau iki jų patartina jų vengti.)
///
/// Be to, nepamirškite, kad dauguma tipų turi papildomų invariantų, išskyrus tai, kad jie laikomi inicijuotais tipo lygiu.
/// Pvz., " 1`inicijuotas " [`Vec<T>`] laikomas inicializuotu (pagal dabartinį diegimą; tai nėra stabili garantija), nes vienintelis kompiliatoriaus žinomas reikalavimas yra tai, kad duomenų žymeklis turi būti nulis.
/// Sukūrus tokį " `Vec<T>`, nesukeliama *tiesioginė* neapibrėžta elgsena, tačiau neapibrėžtas elgesys bus vykdomas atliekant daugumą saugių operacijų (įskaitant jo atsisakymą).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` padeda nesaugiam kodui tvarkyti neinicijuotus duomenis.
/// Tai yra signalas kompiliatoriui, nurodantis, kad duomenys čia gali būti *ne* inicializuoti:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Sukurkite aiškiai neinicijuotą nuorodą.
/// // Kompiliatorius žino, kad `MaybeUninit<T>` viduje esantys duomenys gali būti neteisingi, taigi tai nėra UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Nustatykite galiojančią vertę.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Ištraukite inicializuotus duomenis-tai leidžiama tik *tinkamai* inicializavus " `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Tada kompiliatorius žino, kad šiame kode negalima daryti neteisingų prielaidų ar optimizavimo.
///
/// Galite manyti, kad " `MaybeUninit<T>` yra šiek tiek panašus į " `Option<T>`, tačiau be vykdymo laiko stebėjimo ir be jokių saugumo patikrinimų.
///
/// ## out-pointers
///
/// Galite naudoti " `MaybeUninit<T>`, kad įgyvendintumėte " "out-pointers": užuot grąžinę duomenis iš funkcijos, perduokite žymeklį į kai kurias (uninitialized) atmintines, kad įdėtumėte rezultatą.
/// Tai gali būti naudinga, kai skambinančiajam svarbu kontroliuoti, kaip paskirstoma atmintis, kurioje saugomi rezultatai, ir norite išvengti nereikalingų judesių.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nenumeta seno turinio, o tai yra svarbu.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Dabar mes žinome, kad `v` yra inicijuotas!Tai taip pat užtikrina, kad vector bus tinkamai nuleistas.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Masyvo inicijavimas elementais po elementų
///
/// `MaybeUninit<T>` galima naudoti norint inicijuoti didelį elementų masyvą:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Sukurkite neinicijuotą `MaybeUninit` masyvą.
///     // " `assume_init` yra saugus, nes tipas, kurį mes tvirtiname inicializavę, yra daugybė " VarbUninit`, kuriems nereikia inicializuoti.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Nuleidę " `MaybeUninit` nieko nedarote.
///     // Taigi, naudojant neapdorotą žymeklio priskyrimą vietoj `ptr::write`, senoji neinicijuota vertė nenukrenta.
/////
///     // Taip pat, jei šios linijos metu yra panic, turime atminties nutekėjimą, tačiau nėra jokios atminties problemos.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Viskas inicijuojama.
///     // Pakeiskite masyvą į inicializuotą tipą.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Taip pat galite dirbti su iš dalies inicijuotais masyvais, kuriuos galima rasti žemo lygio duomenų struktūrose.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Sukurkite neinicijuotą `MaybeUninit` masyvą.
/// // " `assume_init` yra saugus, nes tipas, kurį mes tvirtiname inicializavę, yra daugybė " VarbUninit`, kuriems nereikia inicializuoti.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Suskaičiuokite mums priskirtų elementų skaičių.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Kiekvienam masyvo elementui meskite, jei jį paskirstėme.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicijuojamas struktūros laukas
///
/// Norėdami inicijuoti struktų lauką pagal lauką, galite naudoti " `MaybeUninit<T>` ir " [`std::ptr::addr_of_mut`] makrokomandas:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicijuojamas laukas `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` lauko inicijavimas Jei čia yra panic, tada `list` lauke X02 nuteka.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Visi laukai yra inicializuoti, todėl mes paskambiname `assume_init`, kad gautume inicializuotą " Foo`.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` garantuojama, kad jo dydis, išlygiavimas ir ABI bus tokie patys kaip `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Tačiau atminkite, kad tipas *, kuriame yra*`MaybeUninit<T>`, nebūtinai yra tas pats išdėstymas;" Rust`apskritai negarantuoja, kad " `Foo<T>` laukų eilės tvarka yra tokia pati kaip " `Foo<U>`, net jei " `T` ir " `U` yra tokio pat dydžio ir lygiaverčio.
///
/// Be to, kadangi bet kokia " `MaybeUninit<T>` bitų reikšmė galioja, kompiliatorius negali pritaikyti " non-zero/niche-filling optimizavimo, todėl gali būti didesnis dydis:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Jei " `T` yra saugus FFI, tai yra ir " `MaybeUninit<T>`.
///
/// Nors " `MaybeUninit` yra " `#[repr(transparent)]` (nurodant, kad jis garantuoja tą patį dydį, lygiavimą ir ABI, kaip ir " `T`), tai * nekeičia nė vieno ankstesnio įspėjimo.
/// `Option<T>` ir `Option<MaybeUninit<T>>` vis tiek gali būti skirtingų dydžių, o tipai, kuriuose yra `T` tipo laukas, gali būti išdėstyti (ir dydžiu) kitaip nei tuo atveju, jei tas laukas būtų `MaybeUninit<T>`.
/// `MaybeUninit` yra sąjungos tipas, o sąjungose esantis `#[repr(transparent)]` yra nestabilus (žr. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Laikui bėgant, tikslios " `#[repr(transparent)]` garantijos sąjungoms gali išsivystyti, o " `MaybeUninit` gali ir nebūti " `#[repr(transparent)]`.
/// Be to, " `MaybeUninit<T>`*visada* garantuos, kad jo dydis, išlygiavimas ir ABI yra tokie patys kaip " `T`;tiesiog gali pasikeisti tai, kaip `MaybeUninit` įgyvendina tą garantiją.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang elementas, kad galėtume į jį suvynioti kitus tipus.Tai naudinga generatoriams.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Neskambinę į " `T::clone()` negalime žinoti, ar esame pakankamai inicijuoti tam.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Sukuria naują `MaybeUninit<T>`, inicijuojamą pagal nurodytą vertę.
    /// Galite saugiai paskambinti [`assume_init`] pagal šios funkcijos grąžinimo vertę.
    ///
    /// Atminkite, kad numetus " `MaybeUninit<T>`, niekada nebus iškviečiamas " T` metimo kodas.
    /// Jūs esate atsakingas, kad `T` būtų numestas, jei jis būtų inicijuotas.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Sukuria naują `MaybeUninit<T>` neinicijuotą būseną.
    ///
    /// Atminkite, kad numetus " `MaybeUninit<T>`, niekada nebus iškviečiamas " T` metimo kodas.
    /// Jūs esate atsakingas, kad `T` būtų numestas, jei jis būtų inicijuotas.
    ///
    /// Keletą pavyzdžių ieškokite " [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Sukurkite naują `MaybeUninit<T>` elementų masyvą, neinicijuotą būseną.
    ///
    /// Note: future Rust versijoje šis metodas gali tapti nereikalingas, kai masyvo pažodinė sintaksė leidžia [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Toliau pateiktame pavyzdyje galima naudoti " `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Grąžina (galbūt mažesnį) duomenų fragmentą, kuris buvo iš tikrųjų perskaitytas
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAUGA: Neinicijuotas `[MaybeUninit<_>; LEN]` galioja.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Sukuria naują `MaybeUninit<T>` neinicijuotą būseną, o atmintis užpildyta `0` baitais.Ar tai jau leidžia tinkamai inicijuoti, priklauso nuo " `T`.
    ///
    /// Pvz., `MaybeUninit<usize>::zeroed()` yra inicializuotas, tačiau `MaybeUninit<&'static i32>::zeroed()` nėra todėl, kad nuorodos neturi būti nulinės.
    ///
    /// Atminkite, kad numetus " `MaybeUninit<T>`, niekada nebus iškviečiamas " T` metimo kodas.
    /// Jūs esate atsakingas, kad `T` būtų numestas, jei jis būtų inicijuotas.
    ///
    /// # Example
    ///
    /// Teisingas šios funkcijos naudojimas: inicijuojant struktūrą su nuliu, kur visi struktūros laukai gali laikyti bitų šabloną 0 kaip galiojančią vertę.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Neteisingas* šios funkcijos naudojimas: skambinama į `x.zeroed().assume_init()`, kai `0` nėra tinkamas tipo bitų šablonas:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Poroje sukuriame `NotZero`, kuriame nėra galiojančio diskriminanto.
    /// // Tai neapibrėžtas elgesys.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAUGUMAS: `u.as_mut_ptr()` taškai skiriamos atminties.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nustatoma " `MaybeUninit<T>` vertė.
    /// Tai perrašo bet kurią ankstesnę vertę, jos neišmesdama, todėl būkite atsargūs ir nenaudokite jos du kartus, nebent norite praleisti destruktoriaus paleidimą.
    ///
    /// Jūsų patogumui tai taip pat pateikia kintamą nuorodą į (dabar saugiai inicializuotą) " `self` turinį.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAUGA: Mes ką tik inicijavome šią vertę.
        unsafe { self.assume_init_mut() }
    }

    /// Gauna rodyklę į esančią vertę.
    /// Skaitymas iš šio žymiklio arba jo pavertimas nuoroda yra neapibrėžtas elgesys, nebent `MaybeUninit<T>` inicializuotas.
    /// Rašymas į atmintį, kurį nurodo šis žymeklis (non-transitively), yra neapibrėžtas elgesys (išskyrus `UnsafeCell<T>` viduje).
    ///
    /// # Examples
    ///
    /// Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Sukurkite nuorodą į " `MaybeUninit<T>`.Tai gerai, nes mes jį inicijavome.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Neteisingas* šio metodo naudojimas:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Mes sukūrėme nuorodą į neinicijuotą vector!Tai neapibrėžtas elgesys.⚠️
    /// ```
    ///
    /// (Atkreipkite dėmesį, kad taisyklės, susijusios su nuorodomis į neinicijuotus duomenis, dar nėra galutinai parengtos, tačiau patartina jų vengti.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ir `ManuallyDrop` yra `repr(transparent)`, todėl galime mesti rodyklę.
        self as *const _ as *const T
    }

    /// Gauna keičiamą rodyklę į nurodytą vertę.
    /// Skaitymas iš šio žymiklio arba jo pavertimas nuoroda yra neapibrėžtas elgesys, nebent `MaybeUninit<T>` inicializuotas.
    ///
    /// # Examples
    ///
    /// Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Sukurkite nuorodą į " `MaybeUninit<Vec<u32>>`.
    /// // Tai gerai, nes mes jį inicijavome.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Neteisingas* šio metodo naudojimas:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Mes sukūrėme nuorodą į neinicijuotą vector!Tai neapibrėžtas elgesys.⚠️
    /// ```
    ///
    /// (Atkreipkite dėmesį, kad taisyklės, susijusios su nuorodomis į neinicijuotus duomenis, dar nėra galutinai parengtos, tačiau patartina jų vengti.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ir `ManuallyDrop` yra `repr(transparent)`, todėl galime mesti rodyklę.
        self as *mut _ as *mut T
    }

    /// Išgauna vertę iš " `MaybeUninit<T>` talpyklos.Tai puikus būdas užtikrinti, kad duomenys bus išmesti, nes gautam " `T` taikomas įprastas kritimo tvarkymas.
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad " `MaybeUninit<T>` iš tikrųjų yra inicializuota būsena.Tai paskambinus, kai turinys dar nėra visiškai inicializuotas, kyla neatidėliotinas elgesys.
    /// " [type-level documentation][inv] yra daugiau informacijos apie šį pradinį keitimą.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Be to, nepamirškite, kad dauguma tipų turi papildomų invariantų, išskyrus tai, kad jie laikomi inicijuotais tipo lygiu.
    /// Pvz., " 1`inicijuotas " [`Vec<T>`] laikomas inicializuotu (pagal dabartinį diegimą; tai nėra stabili garantija), nes vienintelis kompiliatoriaus žinomas reikalavimas yra tai, kad duomenų žymeklis turi būti nulis.
    ///
    /// Sukūrus tokį " `Vec<T>`, nesukeliama *tiesioginė* neapibrėžta elgsena, tačiau neapibrėžtas elgesys bus vykdomas atliekant daugumą saugių operacijų (įskaitant jo atsisakymą).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Neteisingas* šio metodo naudojimas:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` dar nebuvo inicijuotas, todėl ši paskutinė eilutė sukėlė neapibrėžtą elgesį.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` bus inicijuotas.
        // Tai taip pat reiškia, kad `self` turi būti `value` variantas.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Nuskaitoma vertė iš " `MaybeUninit<T>` talpyklos.Gautam " `T` taikomas įprastas lašų apdorojimas.
    ///
    /// Kai tik įmanoma, geriau naudoti " [`assume_init`], kuris neleidžia dubliuoti " `MaybeUninit<T>` turinio.
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad " `MaybeUninit<T>` iš tikrųjų yra inicializuota būsena.Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, atsiranda neapibrėžtas elgesys.
    /// " [type-level documentation][inv] yra daugiau informacijos apie šį pradinį keitimą.
    ///
    /// Be to, tai palieka tų pačių duomenų kopiją " `MaybeUninit<T>`.
    /// Kai naudojate kelias duomenų kopijas (skambindami `assume_init_read` kelis kartus arba pirmiausia skambindami į `assume_init_read`, tada [`assume_init`]), esate atsakingi už tai, kad tie duomenys iš tikrųjų gali būti dubliuojami.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` yra `Copy`, todėl galime skaityti kelis kartus.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` vertės kopijavimas yra tinkamas, todėl galime skaityti kelis kartus.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Neteisingas* šio metodo naudojimas:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Dabar mes sukūrėme dvi to paties " vector` kopijas, kurios duoda dvigubą nemokamą ⚠️, kai jos abi nukrenta!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` bus inicijuotas.
        // Skaityti iš " `self.as_ptr()` yra saugu, nes " `self` reikia inicijuoti.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Numeta ribinę vertę į vietą.
    ///
    /// Jei turite " `MaybeUninit` nuosavybės teisę, galite naudoti " [`assume_init`].
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad " `MaybeUninit<T>` iš tikrųjų yra inicializuota būsena.Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, atsiranda neapibrėžtas elgesys.
    ///
    /// Be to, visi papildomi `T` tipo invariantai turi būti patenkinti, nes tuo gali pasikliauti `T` (arba jo narių) `Drop` įgyvendinimas.
    /// Pvz., " 1`inicijuotas " [`Vec<T>`] laikomas inicializuotu (pagal dabartinį diegimą; tai nėra stabili garantija), nes vienintelis kompiliatoriaus žinomas reikalavimas yra tai, kad duomenų žymeklis turi būti nulis.
    ///
    /// Tačiau numetus tokį " `Vec<T>`, elgesys bus neapibrėžtas.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` bus inicijuotas ir
        // tenkina visus `T` invariantus.
        // Jei taip yra, mesti vertę vietoje yra saugu.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Gauna bendrą nuorodą į esančią vertę.
    ///
    /// Tai gali būti naudinga, kai norime pasiekti `MaybeUninit`, kuris buvo inicijuotas, bet neturime `MaybeUninit` nuosavybės teisės (neleidžiama naudoti `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, kyla neapibrėžtas elgesys: skambintojas turi garantuoti, kad " `MaybeUninit<T>` iš tikrųjų yra inicializuota būsena.
    ///
    ///
    /// # Examples
    ///
    /// ### Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicijuoti " `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Dabar, kai žinoma, kad mūsų " `MaybeUninit<_>` yra inicializuotas, gerai sukurti bendrą nuorodą į jį:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAUGA: `x` buvo inicijuotas.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Neteisingas* šio metodo naudojimas:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Mes sukūrėme nuorodą į neinicijuotą vector!Tai neapibrėžtas elgesys.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializuokite " `MaybeUninit` naudodami " `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Nuoroda į neinicijuotą " `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` bus inicijuotas.
        // Tai taip pat reiškia, kad `self` turi būti `value` variantas.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Gauna kintamą (unique) nuorodą į esančią vertę.
    ///
    /// Tai gali būti naudinga, kai norime pasiekti `MaybeUninit`, kuris buvo inicijuotas, bet neturime `MaybeUninit` nuosavybės teisės (neleidžiama naudoti `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, kyla neapibrėžtas elgesys: skambintojas turi garantuoti, kad " `MaybeUninit<T>` iš tikrųjų yra inicializuota būsena.
    /// Pavyzdžiui, `.assume_init_mut()` negalima naudoti norint inicijuoti `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Teisingas šio metodo naudojimas:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicijuoja *visus* įvesties buferio baitus.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicijuoti " `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Dabar mes žinome, kad " `buf` buvo inicijuotas, todėl galėtume jį " `.assume_init()`.
    /// // Tačiau naudojant `.assume_init()` gali suaktyvinti 2048 baitų `memcpy`.
    /// // Norėdami tvirtinti, kad buferis buvo inicijuotas jo nekopijuojant, mes atnaujiname `&mut MaybeUninit<[u8; 2048]>` į `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SAUGA: `buf` buvo inicijuotas.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Dabar " `buf` galime naudoti kaip įprastą pjūvį:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Neteisingas* šio metodo naudojimas:
    ///
    /// Negalite naudoti `.assume_init_mut()`, kad inicijuotumėte vertę:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Mes sukūrėme (mutable) nuorodą į neinicijuotą `bool`!
    ///     // Tai neapibrėžtas elgesys.⚠️
    /// }
    /// ```
    ///
    /// Pavyzdžiui, negalite [`Read`] įtraukti į neinicijuotą buferį:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) nuoroda į neinicijuotą atmintį!
    ///                             // Tai neapibrėžtas elgesys.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Taip pat negalite naudoti tiesioginės prieigos prie lauko laipsniškam laukų inicijavimui:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) nuoroda į neinicijuotą atmintį!
    ///                  // Tai neapibrėžtas elgesys.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) nuoroda į neinicijuotą atmintį!
    ///                  // Tai neapibrėžtas elgesys.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Šiuo metu mes remiamės tuo, kad aukščiau pateikta informacija yra neteisinga, ty turime nuorodų į neinicijuotus duomenis (pvz., `libcore/fmt/float.rs`).
    // Prieš stabilizavimą turėtume priimti galutinį sprendimą dėl taisyklių.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` bus inicijuotas.
        // Tai taip pat reiškia, kad `self` turi būti `value` variantas.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Išgauna reikšmes iš `MaybeUninit` sudėtinių rodinių masyvo.
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad visi masyvo elementai yra inicializuotos būsenos.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SAUGA: Dabar saugu, kai inicijuojame visus elementus
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Skambinantysis garantuoja, kad visi masyvo elementai bus inicijuoti
        // * `MaybeUninit<T>` ir T turi tą patį išdėstymą
        // * Galbūt " Unint` nenukrenta, todėl nėra dvigubų atlaisvinimų. Taigi konversija yra saugi
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Darant prielaidą, kad visi elementai yra inicializuoti, gaukite jų dalį.
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad `MaybeUninit<T>` elementai iš tikrųjų yra inicializuotos būsenos.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, atsiranda neapibrėžtas elgesys.
    ///
    /// Daugiau informacijos ir pavyzdžių ieškokite [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAUGA: gabaliuko gabalėlis į `*const [T]` yra saugus, nes skambinantysis tai garantuoja
        // `slice` yra inicializuotas, o garantuojama, kad " MayUninit` išdėstymas bus toks pat kaip `T`.
        // Gautas žymeklis yra galiojantis, nes jis nurodo atmintį, priklausančią `slice`, kuri yra nuoroda ir todėl garantuojama, kad ji galioja skaitant.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Darant prielaidą, kad visi elementai yra inicializuoti, gaukite jiems keičiamą dalį.
    ///
    /// # Safety
    ///
    /// Skambintojas turi garantuoti, kad `MaybeUninit<T>` elementai iš tikrųjų yra inicializuotos būsenos.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicijuotas, atsiranda neapibrėžtas elgesys.
    ///
    /// Daugiau informacijos ir pavyzdžių ieškokite [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAUGA: panaši į `slice_get_ref` saugos pastabas, tačiau turime
        // kintama nuoroda, kuri taip pat garantuotai galioja rašant.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Gauna žymeklį į pirmąjį masyvo elementą.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Gauna keičiamą rodyklę į pirmąjį masyvo elementą.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Nukopijuoja elementus iš `src` į `this`, grąžinant kintamą nuorodą į dabar inicializuotą `this` turinį.
    ///
    /// Jei `T` neįdiegia `Copy`, naudokite [`write_slice_cloned`]
    ///
    /// Tai panašu į " [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ši funkcija bus panic, jei abu skiltelės yra skirtingo ilgio.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAUGA: mes ką tik nukopijavome visus " len` elementus į nepanaudotus pajėgumus
    /// // pirmieji senieji src.len() elementai galioja dabar.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAUGA: &[T] ir&[galbūtUninit<T>] turi tą patį išdėstymą
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAUGA: Galiojantys elementai ką tik nukopijuoti į `this`, todėl jis yra inicializuotas
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonuoja elementus nuo `src` iki `this`, grąžinant kintamą nuorodą į dabar inicializuotą `this` turinį.
    /// Visi jau inicializuoti elementai nebus išmesti.
    ///
    /// Jei `T` įgyvendina `Copy`, naudokite [`write_slice`]
    ///
    /// Tai panašu į " [`slice::clone_from_slice`], tačiau esami elementai nenumetami.
    ///
    /// # Panics
    ///
    /// Ši funkcija bus panic, jei abu skiltelės yra skirtingo ilgio arba jei įgyvendinama `Clone` panics.
    ///
    /// Jei yra panic, jau klonuoti elementai bus išmesti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAUGA: mes ką tik klonavome visus " len` elementus į nepanaudotus pajėgumus
    /// // pirmieji senieji src.len() elementai galioja dabar.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Skirtingai nuo copy_from_slice, tai nevadina clone_from_slice ruože, nes `MaybeUninit<T: Clone>` neįdiegia Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAUGA: šiame neapdorotame gabale bus tik inicializuoti objektai
                // todėl leidžiama jį mesti.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Turime aiškiai juos supjaustyti tuo pačiu ilgiu
        // kad ribų tikrinimas būtų pašalintas, ir optimizatorius sugeneruos memcpy paprastiems atvejams (pavyzdžiui, T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // reikalinga apsauga b/c panic gali atsitikti klono metu
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAUGA: Tinkami elementai ką tik buvo įrašyti į " `this`, todėl jis yra inicializuotas
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}