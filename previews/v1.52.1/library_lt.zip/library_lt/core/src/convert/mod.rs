//! Traits konversijoms tarp tipų.
//!
//! Šio modulio " traits` suteikia galimybę konvertuoti iš vieno tipo į kitą.
//! Kiekvienam trait naudojamas skirtingas tikslas:
//!
//! - Įdiekite " [`AsRef`] trait`, kad galėtumėte atlikti pigias nuorodų į nuorodas konversijas
//! - Įdiekite " [`AsMut`] trait`, kad galėtumėte pigiai keisti iš kintamųjų
//! - Įdiekite " [`From`] trait` vertės ir vertės konversijoms sunaudoti
//! - Įdiekite " [`Into`] trait` vertės ir vertės konversijoms sunaudoti į tipus, kurie nėra dabartiniai crate
//! - " [`TryFrom`] ir " [`TryInto`] traits` elgiasi kaip " [`From`] ir " [`Into`], tačiau juos reikia įdiegti, kai konversija gali nepavykti.
//!
//! Šiame modulyje esantys traits dažnai naudojami kaip trait bounds bendrosioms funkcijoms, kad būtų palaikomi kelių tipų argumentai.Pavyzdžių rasite kiekvieno trait dokumentacijoje.
//!
//! Kaip bibliotekos autorius, visada turėtumėte teikti pirmenybę [`From<T>`][`From`] arba [`TryFrom<T>`][`TryFrom`], o ne [`Into<U>`][`Into`] ar [`TryInto<U>`][`TryInto`], nes [`From`] ir [`TryFrom`] suteikia didesnį lankstumą ir siūlo lygiavertes [`Into`] arba [`TryInto`] versijas nemokamai dėl standartinės bibliotekos pagrindinio diegimo.
//! Taikant versiją, ankstesnę nei " Rust 1.41, gali prireikti tiesiogiai įdiegti " [`Into`] arba " [`TryInto`], kai konvertuojama į tipą, kuris nėra dabartinis " crate`.
//!
//! # Bendrieji diegimai
//!
//! - [`AsRef`] ir [`AsMut`] automatinis nukrypimas, jei vidinis tipas yra nuoroda
//! - [" Nuo`] " <U>T` reiškia [" Į`]`</u><T><U>už U`</u>
//! - [" TryFrom`] " <U>T` reiškia [" TryInto`]`</u><T><U>už U`</u>
//! - [`From`] ir [`Into`] yra refleksiniai, o tai reiškia, kad visi tipai gali patys `into` ir patys `from`
//!
//! Naudojimo pavyzdžių rasite kiekviename trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Tapatybės funkcija.
///
/// Apie šią funkciją svarbu atkreipti dėmesį į du dalykus:
///
/// - Tai ne visada prilygsta uždarymui, tokiam kaip `|x| x`, nes uždarymas gali priversti `x` naudoti kitą tipą.
///
/// - Jis perkelia funkcijai perduotą įvestį `x`.
///
/// Nors gali atrodyti keista turėti funkciją, kuri tik grąžina įvestį, yra keletas įdomių naudojimo būdų.
///
///
/// # Examples
///
/// `identity` naudojimas nieko nedarant kitų įdomių funkcijų sekoje:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Apsimeskime, kad vienos pridėjimas yra įdomi funkcija.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Naudojant " `identity` kaip " "do nothing" pagrindinį atvejį su sąlyga:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Atlikite daugiau įdomių dalykų ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `identity` naudojimas norint išlaikyti `Option<T>` iteratoriaus `Some` variantus:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Naudojamas norint atlikti pigią nuorodos į nuorodą konversiją.
///
/// Šis " trait`yra panašus į " [`AsMut`], kuris naudojamas konvertuoti tarp kintamų nuorodų.
/// Jei jums reikia atlikti brangų konversiją, geriau įdiegti " [`From`] su " `&T` tipu arba parašyti pasirinktinę funkciją.
///
/// `AsRef` turi tą patį parašą kaip " [`Borrow`], tačiau " [`Borrow`] skiriasi keliais aspektais:
///
/// - Skirtingai nei " `AsRef`, " [`Borrow`] turi bet kokį " `T` priedą ir gali būti naudojamas priimant nuorodą arba vertę.
/// - [`Borrow`] taip pat reikalaujama, kad skolintos vertės [`Hash`], [`Eq`] ir [`Ord`] būtų lygiavertės turimai vertei.
/// Dėl šios priežasties, jei norite pasiskolinti tik vieną struktūros lauką, galite įdiegti " `AsRef`, bet ne " [`Borrow`].
///
/// **Note: Šis trait neturi sugesti **.Jei konversija nepavyksta, naudokite specialų metodą, kuris grąžina [`Option<T>`] arba [`Result<T, E>`].
///
/// # Bendrieji diegimai
///
/// - `AsRef` automatinės nuorodos, jei vidinis tipas yra nuoroda arba kintama nuoroda (pvz .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Naudodami trait bounds galime priimti įvairių tipų argumentus, jei tik juos galima konvertuoti į nurodytą `T` tipą.
///
/// Pvz .: Sukurdami bendrą funkciją, kuri ima `AsRef<str>`, išreiškiame, kad norime priimti visas nuorodas, kurias galima konvertuoti į [`&str`], kaip argumentą.
/// Kadangi tiek [`String`], tiek [`&str`] įgyvendina `AsRef<str>`, abu galime priimti kaip įvesties argumentą.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Atlieka konversiją.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Naudojamas norint atlikti pigų kintamų į kintamų nuorodų konversiją.
///
/// Šis " trait`yra panašus į " [`AsRef`], bet naudojamas konvertuoti tarp kintamų nuorodų.
/// Jei jums reikia atlikti brangų konversiją, geriau įdiegti " [`From`] su " `&mut T` tipu arba parašyti pasirinktinę funkciją.
///
/// **Note: Šis trait neturi sugesti **.Jei konversija nepavyksta, naudokite specialų metodą, kuris grąžina [`Option<T>`] arba [`Result<T, E>`].
///
/// # Bendrieji diegimai
///
/// - `AsMut` auto-dereferences, jei vidinis tipas yra kintama nuoroda (pvz .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Naudodami `AsMut` kaip trait bound bendrai funkcijai, galime priimti visas kintamas nuorodas, kurias galima konvertuoti į `&mut T` tipą.
/// Kadangi [`Box<T>`] įgyvendina `AsMut<T>`, mes galime parašyti funkciją `add_one`, kurioje pateikiami visi argumentai, kuriuos galima konvertuoti į `&mut u64`.
/// Kadangi [`Box<T>`] įgyvendina `AsMut<T>`, `add_one` priima ir `&mut Box<u64>` tipo argumentus:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Atlieka konversiją.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Vertės ir vertės konversija, kuri sunaudoja įvesties vertę.[`From`] priešingybė.
///
/// Reikėtų vengti diegti " [`Into`] ir vietoje to įdiegti " [`From`].
/// " [`From`] įdiegimas automatiškai suteikia " [`Into`] diegimą dėl standartinės bibliotekos bendrosios įdiegimo.
///
/// Pageidautina naudoti " [`Into`], o ne " [`From`], kai bendrojoje funkcijoje nurodoma " trait`, " bounds`, kad būtų galima naudoti ir tipus, kurie įgyvendina tik " [`Into`].
///
/// **Note: Šis trait neturi sugesti **.Jei konversija nepavyksta, naudokite [`TryInto`].
///
/// # Bendrieji diegimai
///
/// - [" Nuo`]<T>už U` reiškia `Into<U> for T`
/// - [`Into`] yra refleksinis, o tai reiškia, kad `Into<T> for T` yra įdiegtas
///
/// # [`Into`] diegimas konversijoms į išorinius tipus senose Rust versijose
///
/// Jei paskirties tipas nebuvo dabartinio " crate`dalis, prieš " Rust 1.41 negalėjote tiesiogiai įdiegti " [`From`].
/// Pavyzdžiui, paimkite šį kodą:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// To nepavyks surinkti senesnėse kalbos versijose, nes anksčiau " Rust` našlaičių taisyklės buvo šiek tiek griežtesnės.
/// Norėdami tai apeiti, galite tiesiogiai įdiegti " [`Into`]:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Svarbu suprasti, kad [`Into`] nepateikia [`From`] įgyvendinimo (kaip tai daro [`From`] su [`Into`]).
/// Todėl visada turėtumėte pabandyti įdiegti " [`From`] ir grįžti prie " [`Into`], jei " [`From`] neįmanoma įdiegti.
///
/// # Examples
///
/// [`String`] įgyvendina [" Į`] " <` [" Vec`] " <` [" u8`] " >>`:
///
/// Norint išreikšti, kad norime, kad bendroji funkcija imtų visus argumentus, kuriuos galima konvertuoti į nurodytą `T` tipą, galime naudoti [Into] trait bound reikšmę<T>".
///
/// Pvz .: Funkcija `is_hello` apima visus argumentus, kuriuos galima konvertuoti į [" Vec`] " <` [" u8`]`> `.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Atlieka konversiją.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Naudojamas konvertuojant vertę į vertę, o sunaudojant įvesties vertę.Tai yra abipusis [`Into`].
///
/// Visada reikėtų teikti pirmenybę " `From`, o ne " [`Into`], nes įgyvendinant " `From` automatiškai užtikrinamas " [`Into`] įgyvendinimas dėl standartinės bibliotekos bendrosios įdiegimo.
///
///
/// " [`Into`] įgyvendinkite tik tada, kai taikote į versiją, ankstesnę nei " Rust 1.41, ir konvertuojate į tipą, kuris nėra dabartinis " crate`.
/// `From` negalėjo atlikti tokio tipo konversijų ankstesnėse versijose dėl " Rust` našlaičių taisyklių.
/// Norėdami sužinoti daugiau, žr. [`Into`].
///
/// Pirmenybę naudokite [`Into`], o ne `From`, kai bendrojoje funkcijoje nurodote trait bounds.
/// Tokiu būdu tipai, tiesiogiai įgyvendinantys " [`Into`], taip pat gali būti naudojami kaip argumentai.
///
/// `From` taip pat labai naudingas atliekant klaidų tvarkymą.Kuriant funkciją, kuri gali sugesti, grąžinimo tipas paprastai bus `Result<T, E>` formos.
/// " `From` trait` supaprastina klaidų tvarkymą leisdamas funkcijai grąžinti vieną klaidos tipą, apimančią kelis klaidų tipus.Norėdami gauti daugiau informacijos, žiūrėkite skyrių "Examples" ir [the book][book].
///
/// **Note: Šis trait neturi sugesti **.Jei konversija nepavyksta, naudokite [`TryFrom`].
///
/// # Bendrieji diegimai
///
/// - `From<T> for U` reiškia [" į`] " <U>T`</u>
/// - `From` yra refleksinis, o tai reiškia, kad `From<T> for T` yra įdiegtas
///
/// # Examples
///
/// [`String`] padargai `From<&str>`:
///
/// Aiškus konversija iš `&str` į eilutę atliekama taip:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Atliekant klaidų tvarkymą, dažnai naudinga įdiegti " `From` savo klaidų tipui.
/// Konvertuodami pagrindinius klaidų tipus į savo pasirinktinį klaidos tipą, kuris apima pagrindinį klaidos tipą, galime grąžinti vieną klaidos tipą neprarasdami informacijos apie pagrindinę priežastį.
/// Operatorius '?' automatiškai konvertuoja pagrindinį klaidos tipą į mūsų pasirinktą klaidos tipą, paskambindamas į `Into<CliError>::into`, kuris automatiškai pateikiamas įgyvendinant `From`.
/// Tada kompiliatorius daro išvadą, kuris `Into` diegimas turėtų būti naudojamas.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Atlieka konversiją.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Bandytas konversijos procesas, kuris sunaudoja " `self`, kuris gali būti brangus, o gal ir ne.
///
/// Bibliotekos autoriai paprastai neturėtų tiesiogiai įgyvendinti šio " trait`, tačiau turėtų teikti pirmenybę " [`TryFrom`] trait` diegimui, kuris siūlo didesnį lankstumą ir suteikia lygiavertį " `TryInto` diegimą nemokamai dėl standartinės bibliotekos bendrosios įdiegimo.
/// Norėdami gauti daugiau informacijos apie tai, žr. " [`Into`] dokumentaciją.
///
/// # `TryInto` diegimas
///
/// Tam taikomi tie patys apribojimai ir argumentai, kaip ir diegiant " [`Into`]. Išsamesnės informacijos ieškokite ten.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Tipas grąžintas įvykus konversijos klaidai.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Atlieka konversiją.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Paprastos ir saugios konversijos, kurios tam tikromis aplinkybėmis gali nepavykti valdant.Tai yra abipusis [`TryInto`].
///
/// Tai naudinga, kai atliekate tipo keitimą, kuris gali būti nereikšmingas, tačiau taip pat gali prireikti specialaus tvarkymo.
/// Pavyzdžiui, jokiu būdu negalima konvertuoti [`i64`] į [`i32`] naudojant [`From`] trait, nes [`i64`] gali būti reikšmė, kurios [`i32`] negali atstovauti, todėl konversija prarastų duomenis.
///
/// Tai gali būti padaryta sutrumpinant [`i64`] iki [`i32`] (iš esmės suteikiant [i64`] reikšmę modulo [`i32::MAX`]) arba paprasčiausiai grąžinant [`i32::MAX`], arba kitu būdu.
/// " [`From`] trait`yra skirtas tobuloms konversijoms, todėl " `TryFrom` trait` praneša programuotojui, kai tipo konversija gali sugesti, ir leidžia jiems nuspręsti, kaip su tuo elgtis.
///
/// # Bendrieji diegimai
///
/// - `TryFrom<T> for U` reiškia [`TryInto`]`<U>už T`</u>
/// - [`try_from`] yra refleksinis, o tai reiškia, kad `TryFrom<T> for T` yra įdiegtas ir negali sugesti-susietas `Error` tipas, paskambinant `T::try_from()` pagal `T` tipo vertę, yra [`Infallible`].
/// Kai [`!`] tipas stabilizuojamas, [`Infallible`] ir [`!`] bus lygiaverčiai.
///
/// `TryFrom<T>` galima įgyvendinti taip:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kaip aprašyta, " [`i32`] įgyvendina " TryFrom <` [" i64`]`>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Tyliai sutrumpina `big_number`, reikia aptikti ir tvarkyti sutrumpinimą.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Pateikiama klaida, nes `big_number` yra per didelis, kad tilptų į `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Grąžina `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Tipas grąžintas įvykus konversijos klaidai.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Atlieka konversiją.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// BENDRI POVEIKIAI
////////////////////////////////////////////////////////////////////////////////

// Kai pakyla ir
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Keldamas per &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// " FIXME (#45742): pakeiskite anksčiau pateiktus&/&mut implus tokiu bendresniu:
// // Kaip pakyla virš Derefo
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Dydis> AsRef <U>D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// " AsMut` pakelia virš &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): pakeiskite aukščiau nurodytą " &mut implą tokiu bendresniu:
// // " AsMut`pakelia virš " DerefMut`
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Dydis> AsMut <U>D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Iš reiškia Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (taigi ir Into) yra refleksinis
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Pastaba dėl stabilumo:** Šio impliko dar nėra, bet mes esame "reserving space", kad jį pridėtume prie future.
/// Išsamesnės informacijos ieškokite [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): vietoj to atlikite principinį pataisymą.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// " TryFrom`reiškia " TryInto`
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Neklystančios konversijos semantiškai prilygsta klaidingoms konversijoms su negyvenamu klaidos tipu.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONINIAI POVEIKIAI
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// KLAIDOS BE KLAIDOS TIPAS
////////////////////////////////////////////////////////////////////////////////

/// Klaidų, kurios niekada negali įvykti, tipas.
///
/// Kadangi šis sąrašas neturi varianto, tokio tipo vertė niekada negali egzistuoti.
/// Tai gali būti naudinga bendroms API, kurios naudoja [`Result`] ir parametrizuoja klaidos tipą, nurodydamos, kad rezultatas visada yra [`Ok`].
///
/// Pvz., " [`TryFrom`] trait` (konversija, kuri pateikia [`Result`]) turi visų tipų, kur yra atvirkštinis [`Into`], įgyvendinimą.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # " Future` suderinamumas
///
/// Šis " enum`vaidina tą patį vaidmenį kaip ir " [the `!`“never”type][never], kuris šioje " Rust` versijoje yra nestabilus.
/// Kai " `!` bus stabilizuotas, planuojame padaryti " `Infallible` tipo slapyvardį:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ir galiausiai nebeveikia " `Infallible`.
///
/// Tačiau yra vienas atvejis, kai `!` sintaksę galima naudoti, kol `!` stabilizuojamas kaip visavertis tipas: funkcijos grąžinimo tipo padėtyje.
/// Tiksliau, galima įgyvendinti du skirtingus funkcijų rodyklių tipus:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Kadangi " `Infallible` yra " enum`, šis kodas galioja.
/// Tačiau kai `Infallible` taps never type slapyvardžiu, abu implai pradės sutapti, todėl kalbos trait darnos taisyklės neleis.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}