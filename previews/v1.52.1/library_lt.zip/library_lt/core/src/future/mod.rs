#![stable(feature = "futures_api", since = "1.36.0")]

//! Asinchroninės vertės.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Šio tipo reikia, nes:
///
/// a) Generatoriai negali įdiegti `for<'a, 'b> Generator<&'a mut Context<'b>>`, todėl turime perduoti neapdorotą rodyklę (žr. <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Neapdoroti žymekliai ir `NonNull` nėra `Send` ar `Sync`, todėl tai padarytų ir kiekvieną future non-Send/Sync, ir mes to nenorime.
///
/// Tai taip pat supaprastina HIR `.await` nuleidimą.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Apvyniokite generatorių future.
///
/// Ši funkcija pateikia `GenFuture` apačioje, bet slepia ją `impl Trait`, kad būtų pateikti geresni klaidų pranešimai (`impl Future`, o ne `GenFuture<[closure.....]>`).
///
// Tai yra " `const`, kad būtų išvengta papildomų klaidų, kai atsigauname iš " `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Mes remiamės faktu, kad " async/await futures` yra nepajudinamas, kad sukurtume į save orientacinius pasiskolinimus pagrindiniame generatoriuje.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SAUGA: saugu, nes esame !Unpin + !Drop, ir tai tik lauko projekcija.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Atnaujinkite generatorių, paversdami `&mut Context` į neapdorotą `NonNull` rodyklę.
            // " `.await` nuleidimas jį saugiai grąžins į " `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAUGUMAS: skambinantysis turi garantuoti, kad `cx.0` yra galiojantis rodyklė
    // kuris atitinka visus kintamos nuorodos reikalavimus.
    unsafe { &mut *cx.0.as_ptr().cast() }
}