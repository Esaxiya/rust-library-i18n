#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future reiškia asinchroninį skaičiavimą.
///
/// " future` yra reikšmė, kurios skaičiavimas dar nebaigtas.
/// Toks " "asynchronous value" suteikia galimybę gijai tęsti naudingą darbą, kol laukiama, kol vertė bus pasiekiama.
///
///
/// # `poll` metodas
///
/// Pagrindinis future, `poll` metodas *bando* išskaidyti future į galutinę vertę.
/// Šis metodas neužblokuojamas, jei vertė neparengta.
/// Vietoj to, planuojama pažadinti dabartinę užduotį, kai bus galima padaryti tolesnę pažangą dar kartą " apklausiant`.
/// `context`, perduotas metodui `poll`, gali suteikti [`Waker`], kuris yra rankena, skirta pažadinti dabartinę užduotį.
///
/// Kai naudojate " future`, paprastai tiesiogiai neskambinsite į " `poll`, o verčiau " `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Vertės tipas, gautas baigus.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pabandykite išspręsti " future` reikšmę iki galutinės vertės, užregistruodami dabartinę užduotį pabudimui, jei reikšmė dar nėra.
    ///
    /// # Grąžinimo vertė
    ///
    /// Ši funkcija grąžina:
    ///
    /// - [`Poll::Pending`] jei future dar neparuoštas
    /// - [`Poll::Ready(val)`] su šio future rezultatu `val`, jei jis sėkmingai baigtas.
    ///
    /// Kai " future` bus baigtas, klientai neturėtų jo dar kartą naudoti `poll`.
    ///
    /// Kai " future` dar nėra paruoštas, `poll` grąžina `Poll::Pending` ir saugo [`Waker`] kloną, nukopijuotą iš dabartinio [`Context`].
    /// Tada šis " [`Waker`] pažadinamas, kai " future` gali padaryti pažangą.
    /// Pvz., " future`, laukiantis, kol lizdas taps įskaitomas, [`Waker`] iškvies `.clone()` ir jį išsaugos.
    /// Kai kitur ateina signalas, rodantis, kad lizdas yra įskaitomas, iškviečiama [`Waker::wake`] ir pažadinama lizdo future užduotis.
    /// Kai užduotis bus pažadinta, ji turėtų vėl bandyti `poll` " future`, o tai gali arba nesukurs galutinės vertės.
    ///
    /// Atkreipkite dėmesį, kad keliems skambučiams į " `poll`, tik [`Waker`] iš [`Context`], perduoto naujausiam skambučiui, turėtų būti suplanuotas priimti pažadinimą.
    ///
    /// # Veikimo laiko charakteristikos
    ///
    /// Vien Futures yra *inertiški*;jie turi būti *aktyviai* apklausti, kad būtų pasiekta pažanga, o tai reiškia, kad kiekvieną kartą pažadinus dabartinę užduotį, ji turėtų aktyviai iš naujo " apklausti`, kol laukia futures, kuriuo ji vis dar domisi.
    ///
    /// `poll` funkcija nėra pakartotinai iškviečiama per trumpą ciklą-vietoj to ją reikia iškviesti tik tada, kai future rodo, kad ji yra pasirengusi daryti pažangą (paskambindama į `wake()`).
    /// Jei esate susipažinę su " `poll(2)` arba " `select(2)` sisteminiais skambučiais sistemoje " Unix, verta paminėti, kad " futures` paprastai *ne* kenčia nuo tų pačių " "all wakeups must poll all events" problemų;jie labiau panašūs į `epoll(4)`.
    ///
    /// " `poll` diegimas turėtų stengtis greitai grįžti ir neturėtų blokuoti.Greitas grąžinimas apsaugo nuo nereikalingo gniaužtų gijų ar įvykių kilpų.
    /// Jei iš anksto žinoma, kad skambutis į `poll` gali šiek tiek užtrukti, darbas turėtų būti perkeltas į gijų grupę (ar kažką panašaus), kad būtų užtikrinta, jog " `poll` gali greitai grįžti.
    ///
    /// # Panics
    ///
    /// Kai " future`bus baigtas (grąžino `Ready` iš `poll`), vėl iškviečiant jo `poll` metodą, panic gali amžinai blokuoti ar sukelti kitokių problemų;" `Future` trait` nereikalauja jokių reikalavimų tokio skambučio padariniams.
    /// Tačiau, kadangi `poll` metodas nėra pažymėtas `unsafe`, galioja įprastos Rust taisyklės: skambučiai niekada neturi sukelti neapibrėžto elgesio (atminties sugadinimo, neteisingo `unsafe` funkcijų naudojimo ar pan.), Neatsižvelgiant į future būseną.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}