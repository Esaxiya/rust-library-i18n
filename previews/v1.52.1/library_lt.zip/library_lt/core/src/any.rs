//! Šis modulis įgyvendina " `Any` trait`, kuris leidžia dinamiškai rinkti bet kokio tipo " `'static` tipus per vykdymo laiką.
//!
//! `Any` pati gali būti naudojama norint gauti " `TypeId` ir turi daugiau funkcijų, kai naudojama kaip " trait` objektas.
//! Kaip `&dyn Any` (pasiskolintas trait objektas), jis turi `is` ir `downcast_ref` metodus, norėdamas patikrinti, ar esama vertė yra tam tikro tipo, ir gauti nuorodą į vidinę vertę kaip tipą.
//! Kaip `&mut dyn Any`, taip pat yra `downcast_mut` metodas, skirtas gauti kintamą nuorodą į vidinę vertę.
//! `Box<dyn Any>` prideda `downcast` metodą, kuris bando konvertuoti į `Box<T>`.
//! Išsamią informaciją rasite [`Box`] dokumentacijoje.
//!
//! Atkreipkite dėmesį, kad " `&dyn Any` apsiriboja tik bandymu, ar vertė yra konkretaus tipo, ir jo negalima naudoti norint patikrinti, ar tipas įgyvendina " trait`.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Išmanieji rodyklės ir " `dyn Any`
//!
//! Vienas elgesio elementas, į kurį reikia atsižvelgti naudojant `Any` kaip trait objektą, ypač naudojant tokius tipus kaip `Box<dyn Any>` arba `Arc<dyn Any>`, yra tas, kad paprasčiausiai iškvietus `.type_id()` į vertę, gaunamas *konteinerio*`TypeId`, o ne pagrindinio trait objekto.
//!
//! To galima išvengti paverčiant išmanųjį žymeklį į `&dyn Any`, kuris grąžins objekto `TypeId`.
//! Pavyzdžiui:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Greičiau to norėsite:
//! let actual_id = (&*boxed).type_id();
//! // ... nei tai:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Apsvarstykite situaciją, kai norime atsijungti nuo funkcijos perduotos vertės.
//! Mes žinome vertę, kuria dirbame, įdiegia derinimą, bet nežinome jos konkretaus tipo.Tam tikriems tipams norime suteikti specialų režimą: šiuo atveju išspausdinti eilutės reikšmių ilgį prieš jų vertę.
//! Mes nežinome konkretaus savo vertės tipo kompiliavimo metu, todėl vietoj to turime naudoti vykdymo laiko atspindžius.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger funkcija bet kokiam tipui, kuris įdiegia derinimą.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Pabandykite konvertuoti mūsų vertę į `String`.
//!     // Jei pasiseks, mes norime pateikti stygos ilgį ir vertę.
//!     // Jei ne, tai kitoks tipas: tiesiog atsispausdinkite jį be papuošimo.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ši funkcija nori atjungti savo parametrą prieš atlikdama su ja darbą.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... atlikti kitus darbus
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Bet koks trait
///////////////////////////////////////////////////////////////////////////////

/// " trait`, kad būtų imituojamas dinaminis spausdinimas.
///
/// Daugelis tipų įdiegia " `Any`.Tačiau bet kokio tipo, kuriame yra ne " statinė` nuoroda, nėra.
/// Norėdami gauti daugiau informacijos, žiūrėkite " [module-level documentation][mod].
///
/// [mod]: crate::any
// Šis " trait`nėra nesaugus, nors mes nesaugiame kode (pvz., `downcast`) remiamės jo vienintelio impliko `type_id` funkcijos specifika.Paprastai tai būtų problema, tačiau kadangi vienintelis " `Any` tikslas yra visuotinis diegimas, joks kitas kodas negali įgyvendinti " `Any`.
//
// Galėtume patikimai paversti šį " trait`nesaugiu-tai nesukeltų gedimų, nes mes kontroliuojame visus diegimus, tačiau nusprendžiame to nedaryti, nes to ir nereikia, ir galime suklaidinti vartotojus dėl nesaugių " traits` ir nesaugių metodų (ty " `type_id` vis tiek būtų saugu skambinti, tačiau tikriausiai norėtume tai nurodyti dokumentuose).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Gauna `self` iš `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Bet kokių trait objektų išplėtimo metodai.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Įsitikinkite, kad, pavyzdžiui, siūlų sujungimo rezultatas gali būti atspausdintas ir naudojamas kartu su " `unwrap`.
// Galų gale nebereikės, jei siuntimas veikia su upcastingu.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Grąžina `true`, jei langelio tipas sutampa su `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Gaukite `TypeId` tokio tipo, su kuriuo ši funkcija yra sukurta.
        let t = TypeId::of::<T>();

        // Gaukite `TypeId` tipą objekte trait (`self`).
        let concrete = self.type_id();

        // Palyginkite abu " TypeId` apie lygybę.
        t == concrete
    }

    /// Pateikia tam tikrą nuorodą į langelyje nurodytą vertę, jei ji yra `T` tipo, arba `None`, jei ji nėra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAUGA: tiesiog patikrinome, ar nurodome teisingą tipą, ir galime pasikliauti
            // kad patikrinkite atminties saugumą, nes mes įdiegėme bet kurį visų tipų;negali egzistuoti jokios kitos implikacijos, nes jos prieštarautų mūsų implikacijai.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Pateikia pakeistą nuorodą į langelį pažymėtą vertę, jei ji yra `T` tipo, arba `None`, jei ji nėra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAUGA: tiesiog patikrinome, ar nurodome teisingą tipą, ir galime pasikliauti
            // kad patikrinkite atminties saugumą, nes mes įdiegėme bet kurį visų tipų;negali egzistuoti jokios kitos implikacijos, nes jos prieštarautų mūsų implikacijai.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Pirmyn į metodą, apibrėžtą tipui `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ir jo metodai
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` reiškia visuotinai unikalų tipo identifikatorių.
///
/// Kiekvienas " `TypeId` yra nepermatomas objektas, kuris neleidžia patikrinti, kas yra viduje, tačiau leidžia atlikti pagrindines operacijas, tokias kaip klonavimas, palyginimas, spausdinimas ir rodymas.
///
///
/// " `TypeId` šiuo metu yra tik tiems tipams, kurie priskiriami " `'static`, tačiau šis apribojimas gali būti pašalintas iš " future`.
///
/// Nors " `TypeId` įgyvendina " `Hash`, " `PartialOrd` ir " `Ord`, verta paminėti, kad maišos ir užsakymas skirsis tarp " Rust` leidimų.
/// Saugokitės pasikliauti jais savo kodo viduje!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Pateikia `TypeId` tipą, su kuriuo buvo sukurta bendra funkcija.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Grąžina tipo pavadinimą kaip eilutės pjūvį.
///
/// # Note
///
/// Tai skirta naudoti diagnostikai.
/// Tikslus grąžintos eilutės turinys ir formatas nenurodomi, išskyrus tai, kad tipo aprašymas yra geriausias būdas.
/// Pavyzdžiui, tarp eilučių, kurias gali grąžinti `type_name::<Option<String>>()`, yra `"Option<String>"` ir `"std::option::Option<std::string::String>"`.
///
///
/// Grąžinta eilutė neturi būti laikoma unikaliu tipo identifikatoriumi, nes keli tipai gali susieti su to paties tipo pavadinimu.
/// Panašiai nėra jokios garantijos, kad visos tipo dalys bus rodomos grąžinamoje eilutėje: pavyzdžiui, viso laiko specifikatoriai šiuo metu nėra įtraukti.
/// Be to, išvestis gali keistis tarp kompiliatoriaus versijų.
///
/// Dabartinis diegimas naudoja tą pačią infrastruktūrą kaip kompiliatoriaus diagnostika ir derinimo informacija, tačiau tai nėra garantuota.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Grąžina nurodytos vertės tipo pavadinimą kaip eilutės pjūvį.
/// Tai tas pats, kas `type_name::<T>()`, bet gali būti naudojamas, kai kintamojo tipas nėra lengvai prieinamas.
///
/// # Note
///
/// Tai skirta naudoti diagnostikai.Tikslus eilutės turinys ir formatas nenurodomi, išskyrus tai, kad tipo aprašymas yra geriausias.
/// Pavyzdžiui, `type_name_of_val::<Option<String>>(None)` gali grąžinti `"Option<String>"` arba `"std::option::Option<std::string::String>"`, bet ne `"foobar"`.
///
/// Be to, išvestis gali keistis tarp kompiliatoriaus versijų.
///
/// Ši funkcija neišsprendžia trait objektų, o tai reiškia, kad `type_name_of_val(&7u32 as &dyn Debug)` gali grąžinti `"dyn Debug"`, bet ne `"u32"`.
///
/// Tipo pavadinimas neturėtų būti laikomas unikaliu tipo identifikatoriumi;
/// keli tipai gali turėti tą patį pavadinimą.
///
/// Dabartinis diegimas naudoja tą pačią infrastruktūrą kaip kompiliatoriaus diagnostika ir derinimo informacija, tačiau tai nėra garantuota.
///
/// # Examples
///
/// Spausdina numatytuosius sveiko skaičiaus ir plūduriuojančius tipus.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}