//! `str` Trait` diegimas.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Įgyvendina eilių eiliškumą.
///
/// Stygos yra išdėstytos [lexicographically](Ord#lexicographical-comparison) pagal jų baitų vertes.
/// Tai užsako " Unicode` kodo taškus pagal jų pozicijas kodų diagramose.
/// Tai nebūtinai sutampa su "alphabetical" tvarka, kuri skiriasi pagal kalbą ir lokalę.
/// Rūšiuojant eilutes pagal kultūroje priimtus standartus, reikalingi lokalės duomenys, kurie nepatenka į `str` tipą.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Įgyvendina stygų palyginimo operacijas.
///
/// Stygos lyginamos [lexicographically](Ord#lexicographical-comparison) pagal jų baitų vertes.
/// Tai palygina " Unicode` kodo taškus pagal jų pozicijas kodų diagramose.
/// Tai nebūtinai sutampa su "alphabetical" tvarka, kuri skiriasi pagal kalbą ir lokalę.
/// Stygų palyginimui pagal kultūroje priimtus standartus reikalingi lokalės duomenys, kurie nepatenka į `str` tipą.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[..]` arba `&mut self[..]`.
///
/// Grąžina visos eilutės dalį, ty pateikia `&self` arba `&mut self`.Atitinka `&self [0 ..
/// len] `arba`&mut self [0 ..
/// len]`.
/// Skirtingai nuo kitų indeksavimo operacijų, tai niekada negali būti panic.
///
/// Ši operacija yra *O*(1).
///
/// Iki 1.20.0 šios indeksavimo operacijos vis dar buvo palaikomos tiesiogiai įgyvendinant `Index` ir `IndexMut`.
///
/// Atitinka `&self[0 .. len]` arba `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[begin .. end]` arba `&mut self[begin .. end]`.
///
/// Grąžina nurodytos eilutės pjūvį iš baitų diapazono [`pradėti`, `end`).
///
/// Ši operacija yra *O*(1).
///
/// Iki 1.20.0 šios indeksavimo operacijos vis dar buvo palaikomos tiesiogiai įgyvendinant `Index` ir `IndexMut`.
///
/// # Panics
///
/// Panics, jei `begin` arba `end` nenurodo simbolio pradinio baito poslinkio (kaip apibrėžta `is_char_boundary`), jei `begin > end` arba `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // tai bus panic:
/// // 2 baitas yra `ö`:
/// // &s [2 ..3];
///
/// // 8 baitas slypi `老`&s [1 ..
/// // 8];
///
/// // 100 baitas yra už eilutės&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAUGA: ką tik patikrinote, ar `start` ir `end` yra ant char char ribos,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            // Mes taip pat patikrinome char simbolius, todėl tai galioja UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAUGUMAS: tiesiog patikrinkite, ar `start` ir `end` yra ant char char ribos.
            // Mes žinome, kad rodyklė yra unikali, nes ją gavome iš " `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAUGUMAS: skambinantysis garantuoja, kad `self` yra `slice` ribose
        // kuris atitinka visas `add` sąlygas.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAUGA: žr. `get_unchecked` komentarus.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary tikrina, ar indeksas yra [0, .len()] negali pakartotinai naudoti `get`, kaip nurodyta aukščiau, dėl NLL problemų
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAUGA: ką tik patikrinote, ar `start` ir `end` yra ant char char ribos,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[.. end]` arba `&mut self[.. end]`.
///
/// Grąžina nurodytos eilutės pjūvį iš baitų diapazono [" 0`, `end`).
/// Atitinka `&self[0 .. end]` arba `&mut self[0 .. end]`.
///
/// Ši operacija yra *O*(1).
///
/// Iki 1.20.0 šios indeksavimo operacijos vis dar buvo palaikomos tiesiogiai įgyvendinant `Index` ir `IndexMut`.
///
/// # Panics
///
/// Panics, jei `end` nenurodo simbolio pradinio baito poslinkio (kaip apibrėžta `is_char_boundary`), arba jei `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAUGA: ką tik patikrinote, ar `end` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SAUGA: ką tik patikrinote, ar `end` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SAUGA: ką tik patikrinote, ar `end` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[begin ..]` arba `&mut self[begin ..]`.
///
/// Grąžina nurodytos eilutės pjūvį iš baitų diapazono [`pradėti`, `len`).Lygiavertis `&self [prasideda ..
/// len] `arba`&mut self [prasideda ..
/// len]`.
///
/// Ši operacija yra *O*(1).
///
/// Iki 1.20.0 šios indeksavimo operacijos vis dar buvo palaikomos tiesiogiai įgyvendinant `Index` ir `IndexMut`.
///
/// # Panics
///
/// Panics, jei `begin` nenurodo simbolio pradinio baito poslinkio (kaip apibrėžta `is_char_boundary`), arba jei `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAUGA: ką tik patikrinote, ar `start` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SAUGA: ką tik patikrinote, ar `start` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SAUGUMAS: skambinantysis garantuoja, kad `self` yra `slice` ribose
        // kuris atitinka visas `add` sąlygas.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SAUGA: identiška `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SAUGA: ką tik patikrinote, ar `start` yra ant char char,
            // ir mes pateikiame saugią nuorodą, todėl grąžinimo vertė taip pat bus viena.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[begin ..= end]` arba `&mut self[begin ..= end]`.
///
/// Grąžina pateiktos eilutės pjūvį iš baitų diapazono [`begin`, `end`].Atitinka `&self [begin .. end + 1]` arba `&mut self[begin .. end + 1]`, išskyrus atvejus, kai `end` yra didžiausia `usize` vertė.
///
/// Ši operacija yra *O*(1).
///
/// # Panics
///
/// Panics, jei `begin` nenurodo simbolio pradinio baito poslinkio (kaip apibrėžta `is_char_boundary`), jei `end` nenurodo ženklo pabaigos baito poslinkio (`end + 1` yra arba pradinio baito poslinkis, arba lygus `len`), jei `begin > end`, arba jei `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAUGUMAS: skambinantysis privalo laikytis " `get_unchecked` saugos sutarties.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAUGUMAS: skambinantysis privalo laikytis " `get_unchecked_mut` saugos sutarties.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Įgyvendina pogrupių pjaustymą naudojant sintaksę `&self[..= end]` arba `&mut self[..= end]`.
///
/// Grąžina pateiktos eilutės pjūvį iš baitų diapazono [0, `end`].
/// Ekvivalentiškas `&self [0 .. end + 1]`, išskyrus atvejus, kai `end` yra didžiausia `usize` vertė.
///
/// Ši operacija yra *O*(1).
///
/// # Panics
///
/// Panics, jei `end` nenurodo simbolio pabaigos baito poslinkio (`end + 1` yra arba pradinio baito poslinkis, kaip apibrėžta `is_char_boundary`, arba lygus `len`), arba jei `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SAUGUMAS: skambinantysis privalo laikytis " `get_unchecked` saugos sutarties.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SAUGUMAS: skambinantysis privalo laikytis " `get_unchecked_mut` saugos sutarties.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizuokite reikšmę iš eilutės
///
/// " FromStr [`from_str`] metodas dažnai naudojamas netiesiogiai, naudojant " [str`] [`parse`] metodą.
/// Pavyzdžių rasite [" parse`] dokumentuose.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` neturi viso gyvenimo parametro, todėl galite analizuoti tik tuos tipus, kuriuose nėra viso gyvenimo parametro.
///
/// Kitaip tariant, galite analizuoti " `i32` su " `FromStr`, bet ne " `&i32`.
/// Galite analizuoti struktūrą, kurioje yra `i32`, bet ne tą, kurioje yra `&i32`.
///
/// # Examples
///
/// Pagrindinis " `FromStr` diegimas `Point` tipo pavyzdyje:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Susijusi klaida, kurią galima pateikti analizuojant.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizuoja eilutę `s`, kad būtų grąžinta šio tipo vertė.
    ///
    /// Jei analizuoti pavyksta, grąžinkite reikšmę [`Ok`] viduje, kitaip, kai eilutė yra netinkamai suformatuota, pateikite klaidą, būdingą vidiniam [`Err`].
    /// Klaidos tipas būdingas trait įgyvendinimui.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas su " [`i32`], tipas, įgyvendinantis " `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Išanalizuokite `bool` iš eilutės.
    ///
    /// Gauna " `Result<bool, ParseBoolError>`, nes " `s` iš tikrųjų gali būti analizuojamas arba ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Atkreipkite dėmesį, kad daugeliu atvejų `.parse()` metodas naudojant `str` yra tinkamesnis.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}