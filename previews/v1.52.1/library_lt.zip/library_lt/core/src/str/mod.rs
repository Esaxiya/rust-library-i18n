//! Stygų manipuliavimas.
//!
//! Norėdami gauti daugiau informacijos, žr. [`std::str`] modulį.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. už ribų
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. pradžia <=pabaiga
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. simbolio riba
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // rasti personažą
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` turi būti mažesnė nei lenas ir char riba
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Pateikia `self` ilgį.
    ///
    /// Šis ilgis nurodomas baitais, o ne [char) ar grafemomis.
    /// Kitaip tariant, tai gali būti ne tai, ką žmogus laiko stygos ilgiu.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // išgalvotas f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Pateikia `true`, jei `self` ilgis yra nulis baitų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tikrina, ar " index`-asis baitas yra pirmasis baitas UTF-8 kodo taškų sekoje arba eilutės pabaiga.
    ///
    ///
    /// Eilutės pradžia ir pabaiga (kai `index== self.len()`) laikomi ribomis.
    ///
    /// Pateikia `false`, jei `index` yra didesnis nei `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` pradžia
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // antrasis " `ö` baitas
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // trečiasis " `老` baitas
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ir len visada gerai.
        // Tikrinkite 0, kad būtų galima lengvai optimizuoti patikrą ir praleisti to atvejo eilutės duomenų skaitymą.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Tai šiek tiek magija, atitinkanti: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Konvertuoja eilutės pjūvį į baitą.
    /// Norėdami konvertuoti baito pjūvį atgal į eilutės pjūvį, naudokite funkciją [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SAUGA: const garsas, nes mes transliuojame du tipus su tuo pačiu išdėstymu
        unsafe { mem::transmute(self) }
    }

    /// Keičiamą eilutės pjūvį paverčia kintamu baitu.
    ///
    /// # Safety
    ///
    /// Skambinantysis turi įsitikinti, kad gabalo turinys yra galiojantis UTF-8 prieš pasibaigiant paskolai ir naudojant pagrindinę `str`.
    ///
    ///
    /// " `str`, kurio turinys negalioja, naudojimas " UTF-8 yra neapibrėžtas elgesys.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SAUGUMAS: nuo `&str` iki `&[u8]` aktoriai yra saugūs nuo `str`
        // turi tą patį išdėstymą kaip ir `&[u8]` (šią garantiją gali suteikti tik libstd).
        // Nukreipimas iš žymeklio yra saugus, nes jis gaunamas iš kintamos nuorodos, kuri garantuotai galioja rašant.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konvertuoja eilutės pjūvį į neapdorotą rodyklę.
    ///
    /// Kadangi eilutės pjūviai yra baitų dalis, neapdorotas žymeklis rodo [`u8`].
    /// Šis žymeklis bus nukreiptas į pirmąjį eilutės gabalo baitą.
    ///
    /// Skambinantysis turi užtikrinti, kad grąžintas rodyklė niekada nebūtų parašyta.
    /// Jei jums reikia pakeisti eilutės pjūvio turinį, naudokite [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konvertuoja keičiamą eilutės pjūvį į neapdorotą rodyklę.
    ///
    /// Kadangi eilutės pjūviai yra baitų dalis, neapdorotas žymeklis rodo [`u8`].
    /// Šis žymeklis bus nukreiptas į pirmąjį eilutės gabalo baitą.
    ///
    /// Jūsų pareiga yra įsitikinti, kad eilutės dalis keičiama tik taip, kad ji išliktų galiojančia UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Pateikia `str` poskyrį.
    ///
    /// Tai nėra panikos " `str` indeksavimo alternatyva.
    /// Grąžina [`None`], kai lygiavertė indeksavimo operacija būtų panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeksai nėra UTF-8 sekos ribose
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // už ribų
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Pateikia kintamą `str` poskyrį.
    ///
    /// Tai nėra panikos " `str` indeksavimo alternatyva.
    /// Grąžina [`None`], kai lygiavertė indeksavimo operacija būtų panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // teisingas ilgis
    /// assert!(v.get_mut(0..5).is_some());
    /// // už ribų
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Pateikia nepažymėtą `str` poskyrį.
    ///
    /// Tai yra netikrinta `str` indeksavimo alternatyva.
    ///
    /// # Safety
    ///
    /// Šios funkcijos skambinantieji atsako už tai, kad būtų įvykdytos šios prielaidos:
    ///
    /// * Pradinis indeksas neturi viršyti pabaigos indekso;
    /// * Indeksai turi būti ribose nuo pradinio gabalo;
    /// * Indeksai turi būti ant UTF-8 sekos ribų.
    ///
    /// To nepadarius, grąžinta eilutės dalis gali nurodyti netinkamą atmintį arba pažeisti `str` tipo perduotus invariantus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SAUGUMAS: skambinantysis privalo laikytis `get_unchecked` saugos sutarties;
        // gabalas yra nenurodomas, nes `self` yra saugi nuoroda.
        // Grąžintas žymeklis yra saugus, nes `SliceIndex` implantai turi garantuoti, kad jis yra.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Pateikia kintamą, nepažymėtą `str` poskyrį.
    ///
    /// Tai yra netikrinta `str` indeksavimo alternatyva.
    ///
    /// # Safety
    ///
    /// Šios funkcijos skambinantieji atsako už tai, kad būtų įvykdytos šios prielaidos:
    ///
    /// * Pradinis indeksas neturi viršyti pabaigos indekso;
    /// * Indeksai turi būti ribose nuo pradinio gabalo;
    /// * Indeksai turi būti ant UTF-8 sekos ribų.
    ///
    /// To nepadarius, grąžinta eilutės dalis gali nurodyti netinkamą atmintį arba pažeisti `str` tipo perduotus invariantus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SAUGUMAS: skambinantysis turi laikytis `get_unchecked_mut` saugos sutarties;
        // gabalas yra nenurodomas, nes `self` yra saugi nuoroda.
        // Grąžintas žymeklis yra saugus, nes `SliceIndex` implantai turi garantuoti, kad jis yra.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Sukuriamas eilutės gabalas iš kito eilutės gabalo, apeinant saugos patikrinimus.
    ///
    /// Tai paprastai nerekomenduojama, naudokite atsargiai!Saugios alternatyvos ieškokite [`str`] ir [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Šis naujas pjūvis eina nuo `begin` iki `end`, įskaitant `begin`, išskyrus `end`.
    ///
    /// Jei norite gauti keičiamą eilutės pjūvį, žr. [`slice_mut_unchecked`] metodą.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Šios funkcijos skambintojai atsako už tai, kad būtų įvykdytos trys prielaidos:
    ///
    /// * `begin` neturi viršyti `end`.
    /// * `begin` ir `end` turi būti baitų pozicijos eilutės pjūvyje.
    /// * `begin` ir `end` turi būti ant UTF-8 sekos ribų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SAUGUMAS: skambinantysis privalo laikytis `get_unchecked` saugos sutarties;
        // gabalas yra nenurodomas, nes `self` yra saugi nuoroda.
        // Grąžintas žymeklis yra saugus, nes `SliceIndex` implantai turi garantuoti, kad jis yra.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Sukuriamas eilutės gabalas iš kito eilutės gabalo, apeinant saugos patikrinimus.
    /// Tai paprastai nerekomenduojama, naudokite atsargiai!Saugios alternatyvos ieškokite [`str`] ir [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Šis naujas pjūvis eina nuo `begin` iki `end`, įskaitant `begin`, išskyrus `end`.
    ///
    /// Jei norite gauti nekintamą eilutės pjūvį, žr. [`slice_unchecked`] metodą.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Šios funkcijos skambintojai atsako už tai, kad būtų įvykdytos trys prielaidos:
    ///
    /// * `begin` neturi viršyti `end`.
    /// * `begin` ir `end` turi būti baitų pozicijos eilutės pjūvyje.
    /// * `begin` ir `end` turi būti ant UTF-8 sekos ribų.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SAUGUMAS: skambinantysis turi laikytis `get_unchecked_mut` saugos sutarties;
        // gabalas yra nenurodomas, nes `self` yra saugi nuoroda.
        // Grąžintas žymeklis yra saugus, nes `SliceIndex` implantai turi garantuoti, kad jis yra.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Padalinkite vieną eilutės pjūvį į dvi rodykle.
    ///
    /// Argumentas " `mid` turėtų būti baito poslinkis nuo eilutės pradžios.
    /// Jis taip pat turi būti ant UTF-8 kodo taško ribos.
    ///
    /// Dvi grąžintos griežinėliai eina nuo eilutės pjūvio pradžios iki `mid` ir nuo `mid` iki eilutės pjūvio pabaigos.
    ///
    /// Norėdami gauti kintamų eilutės griežinėlių, žr. [`split_at_mut`] metodą.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, jei `mid` nėra ant UTF-8 kodo taško ribos arba jei jis yra už paskutinio eilutės pjūvio kodo taško pabaigos.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary patikrina, ar indeksas yra [0, .len()]
        if self.is_char_boundary(mid) {
            // SAUGA: ką tik patikrinote, ar `mid` yra ant char char ribos.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Padalinkite vieną kintamą eilutės pjūvį į dvi rodykle.
    ///
    /// Argumentas " `mid` turėtų būti baito poslinkis nuo eilutės pradžios.
    /// Jis taip pat turi būti ant UTF-8 kodo taško ribos.
    ///
    /// Dvi grąžintos griežinėliai eina nuo eilutės pjūvio pradžios iki `mid` ir nuo `mid` iki eilutės pjūvio pabaigos.
    ///
    /// Norėdami gauti nekintamas eilutės dalis, žr. [`split_at`] metodą.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, jei `mid` nėra ant UTF-8 kodo taško ribos arba jei jis yra už paskutinio eilutės pjūvio kodo taško pabaigos.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary patikrina, ar indeksas yra [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SAUGA: ką tik patikrinote, ar `mid` yra ant char char ribos.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Grąžina eilutės pjūvio [" char`] s iteratorių.
    ///
    /// Kadangi eilutės pjūvį sudaro galiojantis UTF-8, galime pakartoti eilutės pjūvį [`char`].
    /// Šis metodas pateikia tokį iteratorių.
    ///
    /// Svarbu atsiminti, kad [`char`] reiškia " Unicode`skaliarinę vertę ir gali neatitikti jūsų idėjos, kas yra " 'character'.
    ///
    /// Kartojimas per grafemų grupes gali būti tai, ko jūs iš tikrųjų norite.
    /// Šios funkcijos neteikia " Rust`standartinė biblioteka, vietoj jos pažymėkite " crates.io.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Atminkite, kad " char` gali neatitikti jūsų intuicijos apie simbolius:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ne 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Grąžina eilutės pjūvio [" char`] ir jų pozicijų kartotoją.
    ///
    /// Kadangi eilutės pjūvį sudaro galiojantis UTF-8, galime pakartoti eilutės pjūvį [`char`].
    /// Šis metodas pateikia šių [char'ų], taip pat jų baitų pozicijų, iteratorių.
    ///
    /// Kartotojas duoda rinkinius.Pozicija yra pirma, [`char`] yra antra.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Atminkite, kad " char` gali neatitikti jūsų intuicijos apie simbolius:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ne (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // atkreipkite dėmesį į 3 čia, paskutinis simbolis užėmė du baitus
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Kartotinis eilutės pjūvio baituose.
    ///
    /// Kadangi eilutės pjūvis susideda iš baitų sekos, galime kartoti eilutės pjūvį pagal baitą.
    /// Šis metodas pateikia tokį iteratorių.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Padalija eilutės pjūvį tarpais.
    ///
    /// Grąžintas iteratorius grąžins eilutės pjūvius, kurie yra pirminio eilutės pjūvio pjūviai, atskirti bet kokiu tarpu.
    ///
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    /// Jei norite atskirti tik ASCII tarpus, naudokite " [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Laikomos visų rūšių spragos:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Padalija eilutės pjūvį pagal ASCII tarpą.
    ///
    /// Pateiktas iteratorius grąžins eilutės pjūvius, kurie yra pirminio eilutės pjūvio pjūviai, atskirti bet kokiu ASCII tarpų kiekiu.
    ///
    ///
    /// Jei norite padalyti pagal " Unicode `Whitespace`, naudokite " [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Laikomos visos ASCII tarpų rūšys:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iteratorius per eilutės eilutes kaip eilutės pjūviai.
    ///
    /// Linijos baigiamos " newline (`\n`) arba vežimo grįžimu su " (`\r\n`) linijos tiekimu.
    ///
    /// Galutinė eilutės pabaiga yra neprivaloma.
    /// Eilutė, kuri baigiasi paskutinės eilutės pabaiga, grąžins tas pačias eilutes kaip kitaip identiška eilutė be paskutinės eilutės pabaigos.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Galutinės eilutės pabaigos nereikia:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iteratorius per eilutės eilutes.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Pateikia `u16` iteratorių per eilutę, užkoduotą kaip UTF-16.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Pateikia `true`, jei nurodytas raštas sutampa su šios eilutės pjūvio dalimi.
    ///
    /// Grąžina `false`, jei ne.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Grąžina `true`, jei pateiktas raštas sutampa su šios eilutės gabalo priešdėliu.
    ///
    /// Grąžina `false`, jei ne.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Grąžina `true`, jei pateiktas raštas sutampa su šios eilutės pjūvio galūne.
    ///
    /// Grąžina `false`, jei ne.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Grąžina pirmojo šios eilutės pjūvio simbolio, atitinkančio šabloną, baitų indeksą.
    ///
    /// Pateikia [`None`], jei modelis nesutampa.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Sudėtingesni modeliai, naudojant stilių be užduočių ir uždarymus:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Nerandate modelio:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Grąžina pirmojo simbolio, esančio dešiniajame šablono atitikties šablone, simbolį.
    ///
    /// Pateikia [`None`], jei modelis nesutampa.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Sudėtingesni modeliai su uždarymo elementais:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Nerandate modelio:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iteratorius virš šios eilutės pjūvio pakraščių, atskirtas simboliais, suderintais su šablonu.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius bus [`DoubleEndedIterator`], jei šablonas leidžia atlikti atvirkštinę paiešką, o forward/reverse paieška suteikia tuos pačius elementus.
    /// Tai galioja, pvz., " [`char`], bet ne " `&str`.
    ///
    /// Jei šablonas leidžia atlikti atvirkštinę paiešką, tačiau jo rezultatai gali skirtis nuo pirmyn, galima naudoti [`rsplit`] metodą.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Jei modelis yra simbolių dalis, padalykite kiekvieną simbolį:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Jei eilutėje yra keli gretimi separatoriai, išvestyje galų gale tuščios eilutės:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Gretimus separatorius skiria tuščia eilutė.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Skyrikliai eilutės pradžioje ar pabaigoje yra šalia tuščių eilučių.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Kai tuščia eilutė naudojama kaip skiriamasis elementas, ji atskiria kiekvieną eilutės simbolį, taip pat eilutės pradžią ir pabaigą.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Gretimi separatoriai gali sukelti galbūt stebinantį elgesį, kai kaip separatorius naudojama tarpai.Šis kodas yra teisingas:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// " _not_ suteikia jums:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Šiam elgesiui naudokite [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iteratorius virš šios eilutės pjūvio pakraščių, atskirtas simboliais, suderintais su šablonu.
    /// Skiriasi nuo iteratoriaus, kurį gamina `split`, tuo atveju, kai `split_inclusive` palieka suderintą dalį kaip substrato terminatorių.
    ///
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Jei bus suderintas paskutinis eilutės elementas, tas elementas bus laikomas ankstesnės eilutės užbaigikliu.
    /// Ši eilutė bus paskutinė iteratoriaus grąžinta prekė.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iteratorius virš nurodytos eilutės pjūvio pakraščių, atskirtas simboliais, suderintais su šablonu ir gaunamas atvirkštine tvarka.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintam iteratoriui reikia, kad šablonas palaikytų atvirkštinę paiešką, ir tai bus [`DoubleEndedIterator`], jei forward/reverse paieška duos tuos pačius elementus.
    ///
    ///
    /// Norint kartoti iš priekio, galima naudoti [`split`] metodą.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iteratorius virš nurodytos eilutės pjūvio pakraščių, atskirtas simboliais, suderintais su šablonu.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Atitinka [`split`], išskyrus tai, kad galinė eilutė praleista, jei ji tuščia.
    ///
    /// [`split`]: str::split
    ///
    /// Šis metodas gali būti naudojamas eilutės duomenims, kurie yra _terminated_, o ne _separated_ pagal modelį.
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius bus [`DoubleEndedIterator`], jei šablonas leidžia atlikti atvirkštinę paiešką, o forward/reverse paieška suteikia tuos pačius elementus.
    /// Tai galioja, pvz., " [`char`], bet ne " `&str`.
    ///
    /// Jei šablonas leidžia atlikti atvirkštinę paiešką, tačiau jo rezultatai gali skirtis nuo pirmyn, galima naudoti [`rsplit_terminator`] metodą.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iteratorius virš `self` pogrupių, atskirtas simboliais, suderintais su modeliu ir gaunamas atvirkštine tvarka.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Atitinka [`split`], išskyrus tai, kad galinė eilutė praleista, jei ji tuščia.
    ///
    /// [`split`]: str::split
    ///
    /// Šis metodas gali būti naudojamas eilutės duomenims, kurie yra _terminated_, o ne _separated_ pagal modelį.
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintam iteratoriui reikia, kad šablonas palaikytų atvirkštinę paiešką, ir jis bus dvigubas, jei forward/reverse paieška suteiks tuos pačius elementus.
    ///
    ///
    /// Norint kartoti iš priekio, galima naudoti [`split_terminator`] metodą.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iteratorius virš nurodytos eilutės pjūvio pogrupių, atskirtas šablonu, apribotas grąžinant daugiausia `n` elementus.
    ///
    /// Jei grąžinamos `n` eilutės, paskutinėje eilutėje (" n`-ojoje eilutėje) bus likusi eilutės dalis.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius nebus dvigubas, nes jį palaikyti nėra efektyvu.
    ///
    /// Jei modelis leidžia atlikti atvirkštinę paiešką, galima naudoti metodą [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iteratorius virš šios eilutės pjūvio pogrupių, atskirtas šablonu, pradedant nuo eilutės pabaigos, apribotas grąžinant daugiausia `n` elementus.
    ///
    ///
    /// Jei grąžinamos `n` eilutės, paskutinėje eilutėje (" n`-ojoje eilutėje) bus likusi eilutės dalis.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius nebus dvigubas, nes jį palaikyti nėra efektyvu.
    ///
    /// Skaldant iš priekio, galima naudoti [`splitn`] metodą.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Padalija eilutę pirmą kartą nurodytam atributui ir pateikia priešdėlį prieš atribotoją, o priesagą-po atribiklio.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Paskirsto eilutę pagal paskutinį nurodyto skiriamojo elemento atvejį ir grąžina prieš skiriamąjį priešdėlį, o po atribiklio-galūnę.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Kartotinis, susijęs su nederinamomis modelio atitiktimis pateiktoje eilutės skiltyje.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius bus [`DoubleEndedIterator`], jei šablonas leidžia atlikti atvirkštinę paiešką, o forward/reverse paieška suteikia tuos pačius elementus.
    /// Tai galioja, pvz., " [`char`], bet ne " `&str`.
    ///
    /// Jei šablonas leidžia atlikti atvirkštinę paiešką, tačiau jo rezultatai gali skirtis nuo pirmyn, galima naudoti [`rmatches`] metodą.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Kartotinis, susijęs su šio eilutės griežinyje esančių modelio nesutarimais, buvo pateiktas atvirkštine tvarka.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintam iteratoriui reikia, kad šablonas palaikytų atvirkštinę paiešką, ir tai bus [`DoubleEndedIterator`], jei forward/reverse paieška duos tuos pačius elementus.
    ///
    ///
    /// Norint kartoti iš priekio, galima naudoti [`matches`] metodą.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Kartotinis šio eilutės gabalo modelio nesutartinių atitikčių ir indekso, nuo kurio prasideda rungtynės, kartotojas.
    ///
    /// `pat` rungtyse `self`, kurios sutampa, grąžinami tik indeksai, atitinkantys pirmąją atitiktį.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintas iteratorius bus [`DoubleEndedIterator`], jei šablonas leidžia atlikti atvirkštinę paiešką, o forward/reverse paieška suteikia tuos pačius elementus.
    /// Tai galioja, pvz., " [`char`], bet ne " `&str`.
    ///
    /// Jei šablonas leidžia atlikti atvirkštinę paiešką, tačiau jo rezultatai gali skirtis nuo pirmyn, galima naudoti [`rmatch_indices`] metodą.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // tik pirmasis `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// " `self` modelio nesusijusių atitikčių pakartotinis rezultatas buvo pateiktas atvirkštine tvarka kartu su atitikties indeksu.
    ///
    /// `pat` rungtyse `self`, kurios sutampa, grąžinami tik indeksai, atitinkantys paskutinę atitiktį.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoriaus elgesys
    ///
    /// Grąžintam iteratoriui reikia, kad šablonas palaikytų atvirkštinę paiešką, ir tai bus [`DoubleEndedIterator`], jei forward/reverse paieška duos tuos pačius elementus.
    ///
    ///
    /// Norint kartoti iš priekio, galima naudoti [`match_indices`] metodą.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // tik paskutinis `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Grąžina eilutės pjūvį, iš kurio pašalinta priekinė ir galinė tarpai.
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Grąžina eilutės pjūvį, kuriame pašalinta priekinė tarpai.
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// `start` šiame kontekste reiškia pirmąją tos baito eilutės poziciją;kalboms iš kairės į dešinę, pvz., anglų ar rusų, tai bus kairė, o iš dešinės į kairę kalbų, tokių kaip arabų ar hebrajų, tai bus dešinė pusė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Grąžina eilutės pjūvį su pašalintu galu.
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// `end` šiame kontekste reiškia paskutinę tos baito eilutės poziciją;kalboms iš kairės į dešinę, pvz., anglų ar rusų, tai bus dešinė, o iš dešinės į kairę kalbų, pavyzdžiui, arabų ar hebrajų, tai bus kairė pusė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Grąžina eilutės pjūvį, kuriame pašalinta priekinė tarpai.
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// 'Left' šiame kontekste reiškia pirmąją tos baito eilutės poziciją;tokioms kalboms kaip arabų ar hebrajų kalba, kurios yra " dešinės į kairę`, o ne " iš kairės į dešinę`, tai bus _right_ pusė, o ne kairė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Grąžina eilutės pjūvį su pašalintu galu.
    ///
    /// 'Whitespace' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `White_Space` sąlygas.
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// 'Right' šiame kontekste reiškia paskutinę tos baito eilutės poziciją;tokioms kalboms kaip arabų ar hebrajų kalba yra " dešinė į kairę`, o ne " iš kairės į dešinę`, tai bus _left_ pusė, o ne dešinė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Grąžina eilutės pjūvį su visais priešdėliais ir priesagomis, atitinkančiomis pakartotinai pašalintą šabloną.
    ///
    /// " [pattern] gali būti " [`char`], " " char `] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Prisiminkite ankstyviausias žinomas rungtynes, jei pataisėte, žemiau
            // paskutinės rungtynės yra kitokios
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAUGA: Žinoma, kad `Searcher` pateikia galiojančius indeksus.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Grąžina eilutės pjūvį su visais priešdėliais, kurie atitinka pakartotinai pašalintą šabloną.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// `start` šiame kontekste reiškia pirmąją tos baito eilutės poziciją;kalboms iš kairės į dešinę, pvz., anglų ar rusų, tai bus kairė, o iš dešinės į kairę kalbų, tokių kaip arabų ar hebrajų, tai bus dešinė pusė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SAUGA: Žinoma, kad `Searcher` pateikia galiojančius indeksus.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Grąžina eilutės pjūvį su pašalintu priešdėliu.
    ///
    /// Jei eilutė prasideda šablonu `prefix`, po prefikso pateikia apatinę eilutę, suvyniotą į `Some`.
    /// Skirtingai nei " `trim_start_matches`, šis metodas priešdėlį pašalina tiksliai vieną kartą.
    ///
    /// Jei eilutė prasideda ne `prefix`, grąžina `None`.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Grąžina eilutės pjūvį su pašalinta galūne.
    ///
    /// Jei eilutė baigiasi šablonu `suffix`, grąžina posekį prieš priesagą, suvyniotą į `Some`.
    /// Skirtingai nuo " `trim_end_matches`, šis metodas priesagą pašalina tiksliai vieną kartą.
    ///
    /// Jei eilutė nesibaigia `suffix`, grąžina `None`.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Grąžina eilutės pjūvį su visomis priesagomis, atitinkančiomis pakartotinai pašalintą šabloną.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// `end` šiame kontekste reiškia paskutinę tos baito eilutės poziciją;kalboms iš kairės į dešinę, pvz., anglų ar rusų, tai bus dešinė, o iš dešinės į kairę kalbų, pavyzdžiui, arabų ar hebrajų, tai bus kairė pusė.
    ///
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SAUGA: Žinoma, kad `Searcher` pateikia galiojančius indeksus.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Grąžina eilutės pjūvį su visais priešdėliais, kurie atitinka pakartotinai pašalintą šabloną.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// 'Left' šiame kontekste reiškia pirmąją tos baito eilutės poziciją;tokioms kalboms kaip arabų ar hebrajų kalba, kurios yra " dešinės į kairę`, o ne " iš kairės į dešinę`, tai bus _right_ pusė, o ne kairė.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Grąžina eilutės pjūvį su visomis priesagomis, atitinkančiomis pakartotinai pašalintą šabloną.
    ///
    /// " [pattern] gali būti " `&str`, " [`char`], " " char`] dalis arba funkcija ar uždarymas, nustatantis, ar simbolis sutampa.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Teksto kryptingumas
    ///
    /// Stygos yra baitų seka.
    /// 'Right' šiame kontekste reiškia paskutinę tos baito eilutės poziciją;tokioms kalboms kaip arabų ar hebrajų kalba yra " dešinė į kairę`, o ne " iš kairės į dešinę`, tai bus _left_ pusė, o ne dešinė.
    ///
    ///
    /// # Examples
    ///
    /// Paprasti modeliai:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Sudėtingesnis modelis, naudojant uždarymą:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analizuoja šią eilutės dalį į kitą tipą.
    ///
    /// Kadangi " `parse` yra toks bendras, jis gali sukelti problemų dėl tipo išvadų.
    /// Taigi " `parse` yra vienas iš nedaugelio kartų, kai pamatysite sintaksę, meiliai vadinamą " 'turbofish': `::<>`.
    ///
    /// Tai padeda išvadų algoritmui suprasti, kurį tipą bandote analizuoti.
    ///
    /// `parse` gali analizuoti bet kokio tipo, kuris įgyvendina " [`FromStr`] trait`.
    ///

    /// # Errors
    ///
    /// Grąžins [`Err`], jei neįmanoma išanalizuoti šios eilutės pjūvio į norimą tipą.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// " 'turbofish' naudojimas, o ne " `four` anotavimas:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Nepavyko išanalizuoti:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Tikrina, ar visi šios eilutės simboliai yra ASCII diapazone.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Čia mes galime traktuoti kiekvieną baitą kaip simbolį: visi daugiabačiai simboliai prasideda baitu, kuris nėra ascii diapazone, todėl mes jau sustosime.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Patikrina, ar dvi eilutės atitinka ASCII mažąsias ir mažąsias raides.
    ///
    /// Tas pats, kas " `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, bet nepriskiriant ir nekopijuojant laikinų elementų.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Konvertuoja šią eilutę į ASCII didžiųjų raidžių ekvivalentą vietoje.
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Norėdami grąžinti naują didžiosios vertės reikšmę nekeisdami esamos, naudokite [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SAUGA: saugu, nes mes transliuojame du tipus tuo pačiu išdėstymu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Konvertuoja šią eilutę į savo ASCII mažąsias raides, lygiavertes vietoje.
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite grąžinti naują mažosios raidės vertę nekeisdami esamos, naudokite [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SAUGA: saugu, nes mes transliuojame du tipus tuo pačiu išdėstymu.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Grąžinkite iteratorių, kuris išvengia visų `self` simbolių su [`char::escape_debug`].
    ///
    ///
    /// Note: bus išvengta tik išplėstinių grafemos taškų, prasidedančių eile.
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Grąžinkite iteratorių, kuris išvengia visų `self` simbolių su [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Grąžinkite iteratorių, kuris išvengia visų `self` simbolių su [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Sukuria tuščią str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Sukuria tuščią kintamą eilutę
    #[inline]
    fn default() -> Self {
        // SAUGA: Tuščia eilutė galioja UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Vardinis, klonuojamas fn tipas
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SAUGA: nėra saugu
        unsafe { from_utf8_unchecked(bytes) }
    };
}