//! `str` sukūrimo iš baitų pjūvio būdai.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konvertuoja baitų pjūvį į eilutės pjūvį.
///
/// Styginių pjūvis ([`&str`]) yra pagamintas iš ([`u8`]) baitų, o baitas ([`&[u8]`][byteslice])-iš baitų, todėl ši funkcija konvertuojama tarp dviejų.
/// Ne visi baitai yra tinkami eilutės gabalai, tačiau: [`&str`] reikalauja, kad jis būtų galiojantis UTF-8.
/// `from_utf8()` patikrina, ar baitai yra tinkami UTF-8, ir atlieka konversiją.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Jei esate tikri, kad baito skiltis yra tinkama " UTF-8, ir nenorite patirti tinkamumo patikrinimo pridėtinės sumos, yra nesaugi šios funkcijos " [`from_utf8_unchecked`] versija, kuri elgiasi taip pat, bet praleidžia patikrinimą.
///
///
/// Jei jums reikia " `String`, o ne " `&str`, apsvarstykite " [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Kadangi galite sukrauti " `[u8; N]` ir galite jį paimti iš " [`&[u8]`][byteslice], ši funkcija yra vienas iš būdų, kaip turėti rietuvėms skirtą eilutę.Tai yra pavyzdys žemiau esančiame pavyzdžių skyriuje.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Pateikia `Err`, jei gabalas nėra UTF-8, kartu su aprašymu, kodėl pateiktas gabalas nėra UTF-8.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::str;
///
/// // kai kurie baitai, vektoriuje
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Mes žinome, kad šie baitai galioja, todėl tiesiog naudokite " `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Neteisingi baitai:
///
/// ```
/// use std::str;
///
/// // kai kurie negaliojantys baitai vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Norėdami sužinoti daugiau apie klaidų rūšis, kurias galima grąžinti, žr. " [`Utf8Error`] dokumentus.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // kai kurie baitai, kamino skirtame masyve
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Mes žinome, kad šie baitai galioja, todėl tiesiog naudokite " `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAUGA: ką tik atliktas patvirtinimas.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konvertuoja kintamą baitų skiltį į kintamą eilutės pjūvį.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kaip kintamas vektorius
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Kadangi žinome, kad šie baitai galioja, galime naudoti " `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Neteisingi baitai:
///
/// ```
/// use std::str;
///
/// // Kai kurie neteisingi baitai kintamame vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Norėdami sužinoti daugiau apie klaidų rūšis, kurias galima grąžinti, žr. " [`Utf8Error`] dokumentus.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAUGA: ką tik atliktas patvirtinimas.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konvertuoja baitų gabalą į eilutės pjūvį, netikrindamas, ar eilutėje yra galiojantis UTF-8.
///
/// Norėdami gauti daugiau informacijos, žiūrėkite saugią versiją " [`from_utf8`].
///
/// # Safety
///
/// Ši funkcija yra nesaugi, nes ji netikrina, ar jai perduoti baitai yra tinkami UTF-8.
/// Pažeidus šį suvaržymą, atsiranda neapibrėžtas elgesys, nes likusioje Rust dalyje daroma prielaida, kad [&str`] galioja UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::str;
///
/// // kai kurie baitai, vektoriuje
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAUGUMAS: skambinantysis turi garantuoti, kad `v` baitai galioja UTF-8.
    // Taip pat remiasi tuo pačiu išdėstymu `&str` ir `&[u8]`.
    unsafe { mem::transmute(v) }
}

/// Konvertuoja baitų gabalą į eilutės gabalą, netikrindamas, ar eilutėje yra galiojantis UTF-8;kintama versija.
///
///
/// Norėdami gauti daugiau informacijos, žiūrėkite nekintamą versiją [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SAUGA: skambinantysis turi garantuoti, kad baitai `v`
    // yra galiojantys UTF-8, todėl perdavimas į `*mut str` yra saugus.
    // Be to, žymeklio nukrypimas yra saugus, nes rodyklė gaunama iš nuorodos, kuri garantuotai galioja rašant.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}