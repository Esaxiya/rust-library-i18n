use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Pateikia `true`, jei rodyklė yra nulinė.
    ///
    /// Atkreipkite dėmesį, kad nedideli tipai turi daug galimų nulinių rodyklių, nes atsižvelgiama tik į neapdorotų duomenų rodyklę, o ne į jų ilgį, matomą ir pan.
    /// Todėl du rodikliai, kurie yra niekiniai, vis tiek negali būti lygūs vienas kitam.
    ///
    /// ## Elgesys vertinant konst
    ///
    /// Kai ši funkcija naudojama vykdant " const` vertinimą, ji gali grąžinti `false` rodyklėms, kurios vykdymo metu pasirodo nulinės.
    /// Tiksliau, kai kai kurios atminties rodyklė bus perkelta už jos ribų taip, kad gautas žymeklis būtų nulis, funkcija vis tiek grąžins `false`.
    ///
    /// CTFE negali žinoti absoliučios tos atminties padėties, todėl negalime pasakyti, ar rodyklė yra nulinė, ar ne.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Palyginkite per gipsą su plonu žymikliu, todėl riebūs rodyklės mano, kad jų "data" dalis yra niekinė.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Perduodama į kito tipo rodyklę.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Išskaidykite (galbūt plačią) žymeklį į adreso ir metaduomenų komponentus.
    ///
    /// Vėliau žymeklį galima atkurti naudojant " [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Grąžina `None`, jei rodyklė yra nulinė, arba grąžina bendrą nuorodą į vertę, įvyniotą į `Some`.Jei reikšmė gali būti neinicijuota, vietoj jos reikia naudoti [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad *rodyklė yra NULL* arba * visi šie duomenys yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Žymeklis turi nukreipti į inicijuotą `T` egzempliorių.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    /// (Dalis apie inicijavimą dar nėra visiškai nuspręsta, tačiau kol to nepadarys, vienintelis saugus būdas yra užtikrinti, kad jie iš tikrųjų būtų inicijuoti.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nieko nepatikrinta versija
    ///
    /// Jei esate tikri, kad rodyklė niekada negali būti nulinė ir ieškote kažkokio `as_ref_unchecked`, kuris grąžina `&T`, o ne `Option<&T>`, žinokite, kad galite tiesiogiai nukreipti žymeklį.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `self` galioja
        // nuoroda, jei ji nėra nulinė.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Grąžina `None`, jei rodyklė yra nulinė, arba grąžina bendrą nuorodą į vertę, įvyniotą į `Some`.
    /// Priešingai nei " [`as_ref`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad *rodyklė yra NULL* arba * visi šie duomenys yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // reikalavimai nuorodai.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Skaičiuoja poslinkį iš rodyklės.
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Pažeidus bet kurią iš šių sąlygų, rezultatas yra neapibrėžtas elgesys:
    ///
    /// * Tiek pradinis, tiek gautas žymeklis turi būti ribos arba vienas baitas už to paties paskirto objekto pabaigos.
    /// Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// * Apskaičiuotas poslinkis **baitais** negali perpildyti `isize`.
    ///
    /// * Ribinis poslinkis negali pasikliauti "wrapping around" adreso erdve.Tai reiškia, kad begalinio tikslumo suma **baitais** turi tilpti į usize.
    ///
    /// Kompiliatorius ir standartinė biblioteka paprastai stengiasi užtikrinti, kad paskirstymai niekada nepasiektų tokio dydžio, koks turėtų būti kompensuojamas.
    /// Pavyzdžiui, " `Vec` ir " `Box` užtikrina, kad niekada neskiria daugiau nei `isize::MAX` baitų, todėl " `vec.as_ptr().add(vec.len())` visada yra saugu.
    ///
    /// Dauguma platformų iš esmės net negali sukurti tokio paskirstymo.
    /// Pavyzdžiui, jokia žinoma 64 bitų platforma niekada negali pateikti užklausos dėl 2 <sup>63</sup> baitų dėl puslapio lentelės apribojimų ar adreso vietos padalijimo.
    /// Tačiau kai kurios 32 ir 16 bitų platformos gali sėkmingai įvykdyti daugiau nei `isize::MAX` baitų užklausą, pvz., Fizinio adreso plėtinį.
    ///
    /// Atmintis, tiesiogiai gauta iš paskirstytojų, arba atminties susietų failų * gali būti per didelė, kad būtų galima naudoti šią funkciją.
    ///
    /// Apsvarstykite galimybę naudoti " [`wrapping_offset`], jei šiuos apribojimus sunku įvykdyti.
    /// Vienintelis šio metodo privalumas yra tai, kad jis leidžia agresyviau optimizuoti kompiliatorius.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `offset` saugos sutarties.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Apskaičiuoja poslinkį iš rodyklės, naudodama apvyniojimo aritmetiką.
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Ši operacija visada yra saugi, tačiau naudojant gautą rodyklę-ne.
    ///
    /// Gautas žymeklis lieka prijungtas prie to paties paskirto objekto, į kurį nurodo `self`.
    /// Jis negali būti *naudojamas* norint pasiekti kitą priskirtą objektą.Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// Kitaip tariant, `let z = x.wrapping_offset((y as isize) - (x as isize))` * nepadaro `z` to paties, kas `y`, net jei manome, kad `T` turi `1` dydį ir nėra perpildymo: `z` vis tiek yra pritvirtintas prie objekto, prie kurio yra pritvirtintas `x`, ir jo nukrypimas yra neapibrėžtas elgesys, nebent `x` `y` taškas į tą patį priskirtą objektą.
    ///
    /// Palyginti su [`offset`], šis metodas iš esmės atideda reikalavimą likti tame pačiame priskirtame objekte: [`offset`] yra neatidėliotinas neapibrėžtas elgesys, kai kertama objekto ribos;`wrapping_offset` sukuria žymeklį, bet vis tiek veda prie neapibrėžto elgesio, jei rodyklė yra nukreipiama, kai ji yra už objekto, prie kurio jis pritvirtintas, ribų.
    /// [`offset`] galima geriau optimizuoti ir todėl pageidautina, jei kodai yra jautrūs.
    ///
    /// Atidėtas patikrinimas atsižvelgia tik į rodiklio vertę, kuri buvo nurodyta, o ne į tarpines vertes, naudojamas apskaičiuojant galutinį rezultatą.
    /// Pavyzdžiui, " `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` visada yra tas pats, kas " `x`.Kitaip tariant, leidžiama palikti paskirtą objektą ir vėliau jį vėl įvesti.
    ///
    /// Jei reikia kirsti objekto ribas, perkelkite rodyklę į sveiką skaičių ir atlikite aritmetiką.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // Kartokite naudodami neapdorotą rodyklę po du elementus
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ši kilpa spausdina "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SAUGUMAS: " `arith_offset` nėra būtinų sąlygų būti iškviestiems.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Apskaičiuoja atstumą tarp dviejų rodyklių.Grąžinta vertė yra T vienetais: atstumas baitais padalijamas iš `mem::size_of::<T>()`.
    ///
    /// Ši funkcija yra atvirkštinė [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Pažeidus bet kurią iš šių sąlygų, rezultatas yra neapibrėžtas elgesys:
    ///
    /// * Tiek pradinis, tiek kitas žymeklis turi būti ribos arba vienas baitas už to paties paskirto objekto pabaigos.
    /// Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// * Abu rodyklės turi būti *išvestos iš* to paties objekto rodyklės.
    ///   (Žr. Toliau pateiktą pavyzdį.)
    ///
    /// * Atstumas tarp rodyklių baitais turi būti tikslus `T` dydžio kartotinis.
    ///
    /// * Atstumas tarp rodyklių **baitais** negali perpildyti `isize`.
    ///
    /// * Ribos atstumas negali būti pagrįstas "wrapping around" adreso erdve.
    ///
    /// " Rust`tipai niekada nėra didesni nei " `isize::MAX`, o " Rust` paskirstymai niekada nesisuka aplink adreso erdvę, todėl du žymekliai, esantys tam tikros vertės bet kuriame Rust `T` tipe, visada atitiks dvi paskutines sąlygas.
    ///
    /// Standartinė biblioteka taip pat paprastai užtikrina, kad asignavimai niekada nepasiektų tokio dydžio, kuris kelia susirūpinimą dėl kompensacijos.
    /// Pavyzdžiui, " `Vec` ir " `Box` užtikrina, kad niekada neskiria daugiau nei `isize::MAX` baitų, todėl " `ptr_into_vec.offset_from(vec.as_ptr())` visada atitinka dvi paskutines sąlygas.
    ///
    /// Dauguma platformų iš esmės net negali sukurti tokio didelio paskirstymo.
    /// Pavyzdžiui, jokia žinoma 64 bitų platforma niekada negali pateikti užklausos dėl 2 <sup>63</sup> baitų dėl puslapio lentelės apribojimų ar adreso vietos padalijimo.
    /// Tačiau kai kurios 32 ir 16 bitų platformos gali sėkmingai įvykdyti daugiau nei `isize::MAX` baitų užklausą, pvz., Fizinio adreso plėtinį.
    /// Atmintis, tiesiogiai gauta iš paskirstytojų, arba atminties susietų failų * gali būti per didelė, kad būtų galima naudoti šią funkciją.
    /// (Atkreipkite dėmesį, kad " [`offset`] ir " [`add`] taip pat turi panašų apribojimą, todėl jų negalima naudoti ir tokiems dideliems paskirstymams.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ši funkcija panics, jei `T` yra nulinio dydžio ("ZST") tipas.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Neteisingas* naudojimas:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Padarykite ptr2_other ptr2 "alias", bet gautą iš ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Kadangi " ptr2_other`ir " ptr2 yra kilę iš žymeklių į skirtingus objektus, jų poslinkio apskaičiavimas yra neapibrėžtas elgesys, net jei jie nurodo tą patį adresą!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Neapibrėžtas elgesys
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SAUGUMAS: skambinantysis privalo laikytis " `ptr_offset_from` saugos sutarties.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Grąžina, ar garantuojama, kad du rodyklės bus vienodi.
    ///
    /// Vykdymo metu ši funkcija veikia kaip `self == other`.
    /// Tačiau kai kuriuose kontekstuose (pvz., Kompiliavimo laiko vertinimas) ne visada įmanoma nustatyti dviejų rodyklių lygybę, todėl ši funkcija gali neteisingai grąžinti `false` rodyklėms, kurios vėliau iš tikrųjų pasirodo lygios.
    ///
    /// Bet kai grąžinama `true`, rodyklės garantuojamos vienodos.
    ///
    /// Ši funkcija yra " [`guaranteed_ne`] veidrodis, bet ne atvirkštinė.Yra žymeklių palyginimai, kurių abi funkcijos grąžina `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Grąžinimo vertė gali keistis priklausomai nuo kompiliatoriaus versijos, o nesaugus kodas gali nesikliauti šios funkcijos rezultatu.
    /// Šią funkciją siūloma naudoti tik optimizuojant našumą, kai netikros `false` grąžinimo vertės pagal šią funkciją daro įtaką ne rezultatui, o tik našumui.
    /// Šio metodo naudojimo vykdymo ir kompiliavimo laiko kodams skirtingos elgsenos pasekmės nebuvo ištirtos.
    /// Šis metodas neturėtų būti naudojamas įvedant tokius skirtumus, ir jis taip pat neturėtų būti stabilizuotas, kol geriau suprasime šią problemą.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Grąžina, ar du rodyklės yra nevienodos.
    ///
    /// Vykdymo metu ši funkcija veikia kaip `self != other`.
    /// Tačiau kai kuriuose kontekstuose (pvz., Kompiliavimo laiko vertinimas) ne visada įmanoma nustatyti dviejų rodyklių nelygybę, todėl ši funkcija gali neteisingai grąžinti `false` rodyklėms, kurios vėliau iš tikrųjų pasirodo esančios nelygios.
    ///
    /// Bet kai grąžinama `true`, rodyklės garantuojamos nevienodos.
    ///
    /// Ši funkcija yra " [`guaranteed_eq`] veidrodis, bet ne atvirkštinė.Yra žymeklių palyginimai, kurių abi funkcijos grąžina `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Grąžinimo vertė gali keistis priklausomai nuo kompiliatoriaus versijos, o nesaugus kodas gali nesikliauti šios funkcijos rezultatu.
    /// Šią funkciją siūloma naudoti tik optimizuojant našumą, kai netikros `false` grąžinimo vertės pagal šią funkciją daro įtaką ne rezultatui, o tik našumui.
    /// Šio metodo naudojimo vykdymo ir kompiliavimo laiko kodams skirtingos elgsenos pasekmės nebuvo ištirtos.
    /// Šis metodas neturėtų būti naudojamas įvedant tokius skirtumus, ir jis taip pat neturėtų būti stabilizuotas, kol geriau suprasime šią problemą.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Apskaičiuoja poslinkį iš rodyklės (patogumas `.offset(count as isize)`).
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Pažeidus bet kurią iš šių sąlygų, rezultatas yra neapibrėžtas elgesys:
    ///
    /// * Tiek pradinis, tiek gautas žymeklis turi būti ribos arba vienas baitas už to paties paskirto objekto pabaigos.
    /// Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// * Apskaičiuotas poslinkis **baitais** negali perpildyti `isize`.
    ///
    /// * Ribos poslinkis negali pasikliauti "wrapping around" adreso erdve.Tai reiškia, kad begalinio tikslumo suma turi tilpti į " `usize`.
    ///
    /// Kompiliatorius ir standartinė biblioteka paprastai stengiasi užtikrinti, kad paskirstymai niekada nepasiektų tokio dydžio, koks turėtų būti kompensuojamas.
    /// Pavyzdžiui, " `Vec` ir " `Box` užtikrina, kad niekada neskiria daugiau nei `isize::MAX` baitų, todėl " `vec.as_ptr().add(vec.len())` visada yra saugu.
    ///
    /// Dauguma platformų iš esmės net negali sukurti tokio paskirstymo.
    /// Pavyzdžiui, jokia žinoma 64 bitų platforma niekada negali pateikti užklausos dėl 2 <sup>63</sup> baitų dėl puslapio lentelės apribojimų ar adreso vietos padalijimo.
    /// Tačiau kai kurios 32 ir 16 bitų platformos gali sėkmingai įvykdyti daugiau nei `isize::MAX` baitų užklausą, pvz., Fizinio adreso plėtinį.
    ///
    /// Atmintis, tiesiogiai gauta iš paskirstytojų, arba atminties susietų failų * gali būti per didelė, kad būtų galima naudoti šią funkciją.
    ///
    /// Apsvarstykite galimybę naudoti " [`wrapping_add`], jei šiuos apribojimus sunku įvykdyti.
    /// Vienintelis šio metodo privalumas yra tai, kad jis leidžia agresyviau optimizuoti kompiliatorius.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `offset` saugos sutarties.
        unsafe { self.offset(count as isize) }
    }

    /// Skaičiuoja poslinkį iš rodyklės (patogumas `.offset ((skaičiuojamas kaip isize).wrapping_neg())`).
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Pažeidus bet kurią iš šių sąlygų, rezultatas yra neapibrėžtas elgesys:
    ///
    /// * Tiek pradinis, tiek gautas žymeklis turi būti ribos arba vienas baitas už to paties paskirto objekto pabaigos.
    /// Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// * Apskaičiuotas poslinkis negali viršyti `isize::MAX`**baitų**.
    ///
    /// * Ribinis poslinkis negali pasikliauti "wrapping around" adreso erdve.Tai yra, begalinio tikslumo suma turi tilpti į usize.
    ///
    /// Kompiliatorius ir standartinė biblioteka paprastai stengiasi užtikrinti, kad paskirstymai niekada nepasiektų tokio dydžio, koks turėtų būti kompensuojamas.
    /// Pavyzdžiui, " `Vec` ir " `Box` užtikrina, kad niekada neskiria daugiau nei `isize::MAX` baitų, todėl " `vec.as_ptr().add(vec.len()).sub(vec.len())` visada yra saugu.
    ///
    /// Dauguma platformų iš esmės net negali sukurti tokio paskirstymo.
    /// Pavyzdžiui, jokia žinoma 64 bitų platforma niekada negali pateikti užklausos dėl 2 <sup>63</sup> baitų dėl puslapio lentelės apribojimų ar adreso vietos padalijimo.
    /// Tačiau kai kurios 32 ir 16 bitų platformos gali sėkmingai įvykdyti daugiau nei `isize::MAX` baitų užklausą, pvz., Fizinio adreso plėtinį.
    ///
    /// Atmintis, tiesiogiai gauta iš paskirstytojų, arba atminties susietų failų * gali būti per didelė, kad būtų galima naudoti šią funkciją.
    ///
    /// Apsvarstykite galimybę naudoti " [`wrapping_sub`], jei šiuos apribojimus sunku įvykdyti.
    /// Vienintelis šio metodo privalumas yra tai, kad jis leidžia agresyviau optimizuoti kompiliatorius.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `offset` saugos sutarties.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Apskaičiuoja poslinkį iš rodyklės, naudodama apvyniojimo aritmetiką.
    /// (patogumas `.wrapping_offset(count as isize)`)
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Ši operacija visada yra saugi, tačiau naudojant gautą rodyklę-ne.
    ///
    /// Gautas žymeklis lieka prijungtas prie to paties paskirto objekto, į kurį nurodo `self`.
    /// Jis negali būti *naudojamas* norint pasiekti kitą priskirtą objektą.Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// Kitaip tariant, `let z = x.wrapping_add((y as usize) - (x as usize))` * nepadaro `z` to paties, kas `y`, net jei manome, kad `T` turi `1` dydį ir nėra perpildymo: `z` vis tiek yra pritvirtintas prie objekto, prie kurio yra pritvirtintas `x`, o jo nukrypimas yra neapibrėžtas elgesys, nebent `x` ir `y` taškas į tą patį priskirtą objektą.
    ///
    /// Palyginti su [`add`], šis metodas iš esmės atideda reikalavimą likti tame pačiame priskirtame objekte: [`add`] yra neatidėliotinas neapibrėžtas elgesys, kai kertama objekto ribos;`wrapping_add` sukuria žymeklį, bet vis tiek veda prie neapibrėžto elgesio, jei rodyklė yra nukreipiama, kai ji yra už objekto, prie kurio jis pritvirtintas, ribų.
    /// [`add`] galima geriau optimizuoti ir todėl pageidautina, jei kodai yra jautrūs.
    ///
    /// Atidėtas patikrinimas atsižvelgia tik į rodiklio vertę, kuri buvo nurodyta, o ne į tarpines vertes, naudojamas apskaičiuojant galutinį rezultatą.
    /// Pavyzdžiui, " `x.wrapping_add(o).wrapping_sub(o)` visada yra tas pats, kas " `x`.Kitaip tariant, leidžiama palikti paskirtą objektą ir vėliau jį vėl įvesti.
    ///
    /// Jei reikia kirsti objekto ribas, perkelkite rodyklę į sveiką skaičių ir atlikite aritmetiką.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // Kartokite naudodami neapdorotą rodyklę po du elementus
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ši kilpa spausdina "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Apskaičiuoja poslinkį iš rodyklės, naudodama apvyniojimo aritmetiką.
    /// (patogumas `.wrapping_offset ((skaičiuojamas kaip isize).wrapping_neg())`)
    ///
    /// `count` yra T vienetais;pvz., `count` iš 3 reiškia `3 * size_of::<T>()` baitų žymeklio poslinkį.
    ///
    /// # Safety
    ///
    /// Ši operacija visada yra saugi, tačiau naudojant gautą rodyklę-ne.
    ///
    /// Gautas žymeklis lieka prijungtas prie to paties paskirto objekto, į kurį nurodo `self`.
    /// Jis negali būti *naudojamas* norint pasiekti kitą priskirtą objektą.Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
    ///
    /// Kitaip tariant, `let z = x.wrapping_sub((x as usize) - (y as usize))` * nepadaro `z` to paties, kas `y`, net jei manome, kad `T` turi `1` dydį ir nėra perpildymo: `z` vis tiek yra pritvirtintas prie objekto, prie kurio yra pritvirtintas `x`, o jo nukrypimas yra neapibrėžtas elgesys, nebent `x` ir `y` taškas į tą patį priskirtą objektą.
    ///
    /// Palyginti su [`sub`], šis metodas iš esmės atideda reikalavimą likti tame pačiame priskirtame objekte: [`sub`] yra neatidėliotinas neapibrėžtas elgesys, kai kertama objekto ribos;`wrapping_sub` sukuria žymeklį, bet vis tiek veda prie neapibrėžto elgesio, jei rodyklė yra nukreipiama, kai ji yra už objekto, prie kurio jis pritvirtintas, ribų.
    /// [`sub`] galima geriau optimizuoti ir todėl pageidautina, jei kodai yra jautrūs.
    ///
    /// Atidėtas patikrinimas atsižvelgia tik į rodiklio vertę, kuri buvo nurodyta, o ne į tarpines vertes, naudojamas apskaičiuojant galutinį rezultatą.
    /// Pavyzdžiui, " `x.wrapping_add(o).wrapping_sub(o)` visada yra tas pats, kas " `x`.Kitaip tariant, leidžiama palikti paskirtą objektą ir vėliau jį vėl įvesti.
    ///
    /// Jei reikia kirsti objekto ribas, perkelkite rodyklę į sveiką skaičių ir atlikite aritmetiką.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // Kartokite naudodami neapdorotą žymeklį po du elementus (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ši kilpa spausdina "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nustato žymiklio vertę į `ptr`.
    ///
    /// Jei `self` yra (fat) žymeklis, kurio dydis nėra dydis, ši operacija paveiks tik žymiklio dalį, o (thin) žymekliams pagal dydžių tipus tai turi tą patį poveikį kaip paprastas priskyrimas.
    ///
    /// Gautas žymeklis turės `val` pradinę reikšmę, ty riebalų rodyklės atveju ši operacija yra semantiškai tokia pati kaip naujo riebalų rodyklės sukūrimas, kurio duomenų rodyklės vertė yra `val`, bet `self` metaduomenys.
    ///
    ///
    /// # Examples
    ///
    /// Ši funkcija pirmiausia naudinga norint leisti baito rodiklio aritmetiką potencialiai riebalų rodyklėms:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // atspausdins "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SAUGUMAS: Jei rodyklė yra plona, ši operacija yra identiška
        // į paprastą užduotį.
        // Riebalų rodyklės atveju, naudojant dabartinį riebalų rodyklių išdėstymo variantą, pirmasis tokio rodyklės laukas visada yra duomenų rodyklė, kuri taip pat priskiriama.
        //
        unsafe { *thin = val };
        self
    }

    /// Nuskaito vertę iš `self` jos nejudindamas.
    /// Tai paliks `self` atmintį nepakitusią.
    ///
    /// Saugos problemas ir pavyzdžius žr. [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `read` saugos sutarties.
        unsafe { read(self) }
    }

    /// Atlieka nepastovų vertės nuskaitymą iš `self`, jos nepajudindamas.Tai paliks `self` atmintį nepakitusią.
    ///
    /// Nepastovios operacijos yra skirtos veikti I/O atmintyje, ir garantuojama, kad kompiliatorius jų nepašalins ir nepersidės per kitas nepastovias operacijas.
    ///
    ///
    /// Saugos problemas ir pavyzdžius žr. [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `read_volatile` saugos sutarties.
        unsafe { read_volatile(self) }
    }

    /// Nuskaito vertę iš `self` jos nejudindamas.
    /// Tai paliks `self` atmintį nepakitusią.
    ///
    /// Skirtingai nei " `read`, žymeklis gali būti nesuderintas.
    ///
    /// Saugos problemas ir pavyzdžius žr. [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `read_unaligned` saugos sutarties.
        unsafe { read_unaligned(self) }
    }

    /// Nukopijuoja `count * size_of<T>` baitus iš `self` į `dest`.
    /// Šaltinis ir paskirties vieta gali sutapti.
    ///
    /// NOTE: tai turi tą pačią * argumentų tvarką kaip ir [`ptr::copy`].
    ///
    /// Saugos problemas ir pavyzdžius žr. [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `copy` saugos sutarties.
        unsafe { copy(self, dest, count) }
    }

    /// Nukopijuoja `count * size_of<T>` baitus iš `self` į `dest`.
    /// Šaltinis ir paskirties vieta gali * nesutapti.
    ///
    /// NOTE: tai turi tą pačią * argumentų tvarką kaip ir [`ptr::copy_nonoverlapping`].
    ///
    /// Saugos problemas ir pavyzdžius žr. [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `copy_nonoverlapping` saugos sutarties.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Apskaičiuoja poslinkį, kurį reikia taikyti žymekliui, kad jis būtų sulygintas su `align`.
    ///
    /// Jei žymeklio sulyginti neįmanoma, diegimas grąžina `usize::MAX`.
    /// Leidžiama, kad įgyvendinimas *visada* grąžintų `usize::MAX`.
    /// Tik jūsų algoritmo našumas gali priklausyti nuo to, ar čia gaunamas tinkamas kompensavimas, o ne jo teisingumas.
    ///
    /// Poslinkis išreiškiamas `T` elementų skaičiumi, o ne baitais.Grąžintą vertę galima naudoti naudojant `wrapping_add` metodą.
    ///
    /// Nėra jokių garantijų, kad rodyklės įskaitymas nebus perpildytas ar viršytas paskirstymas, kurį rodo rodyklė.
    ///
    /// Skambintojas turi įsitikinti, kad grąžinta kompensacija yra teisinga visais terminais, išskyrus derinimą.
    ///
    /// # Panics
    ///
    /// Funkcija panics, jei `align` nėra dviejų galia.
    ///
    /// # Examples
    ///
    /// Prieiga prie gretimo `u8` kaip `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // nors žymiklį galima sulygiuoti per `offset`, jis bus nukreiptas už paskirstymo ribų
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SAUGUMAS: patikrinta, ar `align` galia yra 2 aukščiau
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Grąžina neapdoroto gabalo ilgį.
    ///
    /// Grąžinta vertė yra **elementų** skaičius, o ne baitų skaičius.
    ///
    /// Ši funkcija yra saugi, net jei neapdoroto griežinėlio negalima perduoti į griežinėlio nuorodą, nes rodyklė yra nulinė arba nesuderinta.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SAUGA: tai yra saugu, nes " `*const [T]` ir " `FatPtr<T>` išdėstymas yra vienodas.
            // Šią garantiją gali suteikti tik " `std`.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Grąžina neapdorotą žymeklį į gabalo buferį.
    ///
    /// Tai prilygsta " `self` liejimui į " `*const T`, bet labiau saugu tipui.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Grąžina neapdorotą žymeklį prie elemento ar pogrupio, netikrindamas ribų.
    ///
    /// Kviesti šį metodą su ribų riba arba kai `self` negalima nustatyti, yra *[neapibrėžtas elgesys]*, net jei gautas žymeklis nenaudojamas.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SAUGUMAS: skambinantysis užtikrina, kad " `self` būtų galima naudoti, o " `index` būtų ribojamas.
        unsafe { index.get_unchecked(self) }
    }

    /// Grąžina `None`, jei rodyklė yra nulinė, arba grąžina bendrai naudojamą pjūvį į vertę, suvyniotą į `Some`.
    /// Priešingai nei " [`as_ref`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad *rodyklė yra NULL* arba * visi šie duomenys yra teisingi:
    ///
    /// * Norint nuskaityti `ptr.len() * mem::size_of::<T>()` daug baitų, žymeklis turi būti [valid] ir jis turi būti tinkamai sulygiuotas.Tai visų pirma reiškia:
    ///
    ///     * Visas šio gabalo atminties diapazonas turi būti vienas paskirtas objektas!
    ///       Skiltelės niekada negali apimti kelių paskirtų objektų.
    ///
    ///     * Žymeklis turi būti išlygintas net ir nulinio ilgio griežinėliams.
    ///     Viena to priežasčių yra ta, kad " enum` išdėstymo optimizavimas gali remtis tuo, kad nuorodos (įskaitant bet kokio ilgio gabalėlius) yra sulygiuotos ir nėra niekinės, kad jas būtų galima atskirti nuo kitų duomenų.
    ///
    ///     Naudodami [`NonNull::dangling()`], galite gauti žymeklį, kurį galima naudoti kaip `data` nulinio ilgio griežinėliams.
    ///
    /// * Bendras gabalo dydis `ptr.len() * mem::size_of::<T>()` neturi būti didesnis nei `isize::MAX`.
    ///   Žr. " [`pointer::offset`] saugos dokumentaciją.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// Taip pat žiūrėkite " [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SAUGUMAS: skambinantysis privalo laikytis " `as_uninit_slice` saugos sutarties.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Rodyklių lygybė
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Rodyklių palyginimas
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}