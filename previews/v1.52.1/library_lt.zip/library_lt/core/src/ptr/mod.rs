//! Rankiniu būdu valdykite atmintį naudodami neapdorotus rodiklius.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Daugelis šio modulio funkcijų neapdorotus rodiklius laiko argumentais ir skaito iš jų arba rašo jiems.Kad tai būtų saugu, šie rodyklės turi būti *galiojantys*.
//! Ar rodyklė galioja, priklauso nuo operacijos, kuriai jis naudojamas (skaityti ar rašyti), ir prieigos prie atminties apimties (ty kiek baitų yra read/written).
//! Daugelis funkcijų naudoja `*mut T` ir `* const T`, kad pasiektų tik vieną reikšmę, tokiu atveju dokumentacijoje praleidžiamas dydis ir netiesiogiai laikoma, kad tai yra `size_of::<T>()` baitai.
//!
//! Tikslios galiojimo taisyklės dar nėra nustatytos.Šiuo metu suteikiamos garantijos yra labai minimalios:
//!
//! * " [null] žymeklis *niekada* negalioja net ir prieigoms prie " [size zero][zst].
//! * Kad rodyklė būtų galiojanti, būtina, bet ne visada pakanka, kad rodyklė būtų *perduodama*: nurodyto dydžio atminties diapazonas, prasidedantis nuo žymiklio, turi būti vieno paskirto objekto ribose.
//!
//! Atkreipkite dėmesį, kad programoje Rust kiekvienas (stack-allocated) kintamasis laikomas atskiru paskirstytu objektu.
//! * Net atliekant operacijas " [size zero][zst], žymeklis neturi būti nukreiptas į paskirstytą atmintį, ty sandoris padaro žymeklį negaliojančiu net ir nulinio dydžio operacijoms.
//! Tačiau bet kurio nulis, kuris nėra nulinis sveikasis skaičius *pažodinis*, perkėlimas į rodyklę galioja nulinio dydžio prieigoms, net jei tuo adresu yra tam tikros atminties ir ji yra paskirstoma.
//! Tai atitinka jūsų paties paskirstytojo rašymą: nulio dydžio objektų paskirstymas nėra labai sunkus.
//! Kanoninis būdas gauti žymeklį, kuris galioja nulinio dydžio prieigoms, yra [`NonNull::dangling`].
//! * Visos prieigos, kurias atlieka šio modulio funkcijos, yra *ne atominės*[atomic operations] prasme, naudojamos sinchronizuoti tarp gijų.
//! Tai reiškia, kad neapibrėžta elgsena atlikti dvi tuo pačiu metu prieigas prie tos pačios vietos iš skirtingų gijų, nebent abi prieigos būtų skaitomos tik iš atminties.
//! Atkreipkite dėmesį, kad tai aiškiai apima [`read_volatile`] ir [`write_volatile`]: Nepastovios prieigos negali būti naudojamos tarpgijiniam sinchronizavimui.
//! * Nuorodos į rodyklę perdavimo rezultatas galioja tol, kol pagrindinis objektas yra gyvas, o prieigai prie tos pačios atminties nenaudojama jokia nuoroda (tik neapdoroti rodyklės).
//!
//! Šios aksiomos kartu su kruopščiu [`offset`] naudojimu žymeklio aritmetikai pakanka, kad teisingai įgyvendintumėte daug naudingų dalykų nesaugiame kode.
//! Galiausiai bus suteiktos griežtesnės garantijos, nes nustatomos [aliasing] taisyklės.
//! Norėdami gauti daugiau informacijos, žiūrėkite [book], taip pat [undefined behavior][ub] skirtos nuorodos skyrių.
//!
//! ## Alignment
//!
//! Tinkami neapdoroti rodyklės, kaip apibrėžta aukščiau, nebūtinai yra tinkamai sulygiuoti (kai "proper" lygiavimą apibrėžia pointee tipo, ty `*const T` turi būti sulygiuotas su `mem::align_of::<T>()`).
//! Tačiau daugumai funkcijų reikia, kad jų argumentai būtų tinkamai suderinti, ir šis reikalavimas bus aiškiai nurodytas jų dokumentuose.
//! Pažymėtinos šios išimtys yra " [`read_unaligned`] ir " [`write_unaligned`].
//!
//! Kai funkcijai reikia tinkamo derinimo, ji tai daro, net jei prieigos dydis 0, ty, net jei atmintis iš tikrųjų neliečiama.Tokiais atvejais apsvarstykite galimybę naudoti " [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Vykdo nurodytos vertės destruktorių (jei yra).
///
/// Tai semantiškai prilygsta [`ptr::read`] iškvietimui ir rezultato atmetimui, tačiau turi šiuos pranašumus:
///
/// * *Reikalinga* naudoti " `drop_in_place` norint išmesti nedideli tipus, pvz., " trait` objektus, nes jų negalima perskaityti į kaminą ir numesti paprastai.
///
/// * Optimizuotojui yra draugiškiau tai padaryti per [`ptr::read`], kai numeta rankiniu būdu paskirstytą atmintį (pvz., Įgyvendinant " `Box`/`Rc`/`Vec`), nes kompiliatorius neprivalo įrodyti, kad garsas išleidžiamas iš kopijos.
///
///
/// * Jį galima naudoti [pinned] duomenims mesti, kai `T` nėra `repr(packed)` (prisegtų duomenų negalima perkelti prieš juos numetant).
///
/// Nelygių reikšmių negalima išmesti vietoje, jas pirmiausia reikia nukopijuoti į sulygintą vietą naudojant [`ptr::read_unaligned`].Supakuotiems fragmentams šį žingsnį automatiškai atlieka kompiliatorius.
/// Tai reiškia, kad supakuotų konstrukcijų laukai nėra išmesti vietoje.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `to_drop` turi būti [valid] skaitant ir rašant.
///
/// * `to_drop` turi būti tinkamai išlyginti.
///
/// * `to_drop` taškų reikšmė turi būti tinkama numesti, o tai gali reikšti, kad ji turi palaikyti papildomus invariantus, tai priklauso nuo tipo.
///
/// Be to, jei " `T` nėra " [`Copy`], naudojant " point-to` vertę iškvietus `drop_in_place`, gali kilti neapibrėžtas elgesys.Atminkite, kad `*to_drop = foo` yra skaičiuojamas kaip naudojimas, nes dėl to vertė vėl sumažės.
/// [`write()`] gali būti naudojamas perrašyti duomenis, nesukeliant jų.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Neautomatiškai pašalinkite paskutinį elementą iš " vector`:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Gaukite neapdorotą žymeklį į paskutinį " `v` elementą.
///     let ptr = &mut v[1] as *mut _;
///     // Sutrumpinkite `v`, kad nenumestumėte paskutinio elemento.
///     // Pirmiausia tai darome, kad išvengtume problemų, jei " `drop_in_place` yra žemesnė nei " panics`.
///     v.set_len(1);
///     // Be skambučio `drop_in_place`, paskutinis daiktas niekada nebus numestas, o jo valdoma atmintis bus nutekėjusi.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Įsitikinkite, kad paskutinis elementas buvo numestas.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Atkreipkite dėmesį, kad kompiliatorius automatiškai atlieka šią kopiją, kai numeta supakuotas struktūras, ty jums paprastai nereikia rūpintis tokiomis problemomis, nebent skambinate `drop_in_place` rankiniu būdu.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kodas čia nesvarbu, jį kompiliatorius pakeičia tikrais kritimo klijais.
    //

    // SAUGA: žr. Komentarą aukščiau
    unsafe { drop_in_place(to_drop) }
}

/// Sukuria nulinį neapdorotą rodyklę.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Sukuriamas nulinis kintamas neapdorotas žymeklis.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Norint išvengti `T: Clone` susiejimo, reikalingas rankinis implantas.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Norint išvengti `T: Copy` susiejimo, reikalingas rankinis implantas.
impl<T> Copy for FatPtr<T> {}

/// Suformuoja neapdorotą gabalėlį iš rodyklės ir ilgio.
///
/// `len` argumentas yra **elementų** skaičius, o ne baitų skaičius.
///
/// Ši funkcija yra saugi, tačiau iš tikrųjų grąžinimo vertės naudojimas yra nesaugus.
/// Pjūvių saugos reikalavimus rasite [`slice::from_raw_parts`] dokumentacijoje.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // sukurkite pjūvio rodyklę, kai pradedate nuo pirmojo elemento žymeklio
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SAUGA: Prieiga prie vertės iš `Repr` sąjungos yra saugi, nes * const [T]
        //
        // ir " FatPtr` turi tuos pačius atminties išdėstymus.Šią garantiją gali suteikti tik std.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Atlieka tą patį funkcionalumą kaip ir " [`slice_from_raw_parts`], išskyrus tai, kad grąžinamas žalias nekintamas gabalas, priešingai nei neapdorotas nekeičiamas gabalas.
///
///
/// Norėdami gauti daugiau informacijos, žr. " [`slice_from_raw_parts`] dokumentaciją.
///
/// Ši funkcija yra saugi, tačiau iš tikrųjų grąžinimo vertės naudojimas yra nesaugus.
/// Žr. [`slice::from_raw_parts_mut`] dokumentaciją, kurioje rasite saugos reikalavimus.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // priskirkite vertę pjūvio rodyklėje
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SAUGA: Prieiga prie vertės iš `Repr` sąjungos yra saugi, nes * mut [T]
        // ir " FatPtr` turi tuos pačius atminties išdėstymus
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Keičia reikšmes dviejose to paties tipo kintamose vietose, deinicializuodami.
///
/// Tačiau šioms dviem išimtims ši funkcija semantiškai prilygsta [`mem::swap`]:
///
///
/// * Jis naudoja neapdorotus rodiklius, o ne nuorodas.
/// Kai yra nuorodų, pirmenybė turėtų būti teikiama [`mem::swap`].
///
/// * Dvi nurodytos vertės gali sutapti.
/// Jei reikšmės sutampa, bus naudojama `x` atminties sritis, kuri sutampa.
/// Tai parodyta antrame žemiau pateiktame pavyzdyje.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * Tiek skaitant, tiek rašant, `x` ir `y` turi būti [valid].
///
/// * Tiek `x`, tiek `y` turi būti tinkamai sulygiuoti.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklės turi būti ne NULL ir tinkamai sulygiuotos.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Dviejų nesutampančių regionų keitimas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // tai yra `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // tai yra `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Dviejų sutampančių regionų keitimas:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // tai yra `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // tai yra `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Skiltelės indeksai `1..3` sutampa su `x` ir `y`.
///     // Pagrįsti jų rezultatai būtų `[2, 3]`, taigi indeksai `0..3` yra `[1, 2, 3]` (`y` atitinka `swap`);arba kad jie būtų `[0, 1]`, kad indeksai `1..4` būtų `[0, 1, 2]` (prieš `swap` sutampa su `x`).
/////
///     // Šis įgyvendinimas apibrėžtas norint pasirinkti pastarąjį.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Duokite sau šiek tiek vietos dirbti.
    // Mums nereikia jaudintis dėl lašų: `MaybeUninit` numetęs nieko nedaro.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Atlikite apsikeitimo SAUGUMĄ: skambinantysis turi garantuoti, kad `x` ir `y` galioja rašant ir tinkamai sulygiuoti.
    // `tmp` negali sutapti nei `x`, nei `y`, nes `tmp` buvo tiesiog paskirtas rietuvėje kaip atskiras priskirtas objektas.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` ir `y` gali sutapti
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Pakeičia `count * size_of::<T>()` baitus tarp dviejų atminties regionų, prasidedančių `x` ir `y`.
/// Šie du regionai neturi sutapti.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * Tiek `x`, tiek `y` turi būti [valid] tiek skaitant, tiek rašant iš `count *
///   dydis: :<T>() `baitai.
///
/// * Tiek `x`, tiek `y` turi būti tinkamai sulygiuoti.
///
/// * Atminties sritis, prasidedanti `x`, kurios dydis yra " count` *
///   dydis: :<T>() `baitai neturi * sutapti su atminties sritimi, prasidedančia `y` ir to paties dydžio.
///
/// Atminkite, kad net jei efektyviai nukopijuotas dydis (`count * size_of: :<T>()`) yra `0`, žymekliai turi būti ne NULL ir tinkamai sulygiuoti.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SAUGUMAS: skambinantysis turi garantuoti, kad `x` ir `y` yra
    // galioja rašant ir tinkamai sulygiuota.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Tiems tipams, kurie yra mažesni už toliau pateiktą blokų optimizavimą, tiesiog pakeiskite juos tiesiogiai, kad išvengtumėte pesimizavimo kodegeno.
    //
    if mem::size_of::<T>() < 32 {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `x` ir `y` galioja
        // rašymams, tinkamai sulygiuoti ir nepersidengiantys.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SAUGUMAS: skambinantysis privalo laikytis " `swap_nonoverlapping` saugos sutarties.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Čia galima naudoti " simd`, norint efektyviai pakeisti " x&y`.
    // Išbandžius paaiškėja, kad " Intel Haswell E` procesoriams efektyviausia vienu metu pakeisti 32 arba 64 baitus.
    // LLVM gali geriau optimizuoti, jei struktūrai suteikiame #[repr(simd)], net jei iš tikrųjų nenaudojame šios struktūros tiesiogiai.
    //
    //
    // " FIXME repr(simd) sugedo ant emscripten ir redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Peržiūrėkite " x&y`, nukopijuodami juos po `Block` vienu metu. Daugelio tipų NB optimizatorius turėtų visiškai išvynioti kilpą
    // Negalime naudoti " for loop`, nes " `range` impl` iškviečia " `mem::swap` rekursyviai
    //
    let mut i = 0;
    while i + block_size <= len {
        // Sukurkite neinicijuotą atmintį kaip įbrėžimo vietą. Čia deklaravus `t`, reikia išvengti rietuvės lygiavimo, kai ši kilpa nenaudojama
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SAUGA: Kaip `i < len` ir kaip skambinantysis turi garantuoti, kad `x` ir `y` galioja
        // `len` baitams `x + i` ir `y + i` turi būti galiojantys adresai, kurie atitinka `add` saugos sutartį.
        //
        // Be to, skambinantysis turi garantuoti, kad `x` ir `y` galioja rašant, tinkamai sulygiuoti ir nepersidengia, o tai atitinka `copy_nonoverlapping` saugos sutartį.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Pakeiskite x&y baitų bloką naudodami t kaip laikiną buferį. Tai turėtų būti optimizuota efektyvioms SIMD operacijoms, jei įmanoma
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Pakeiskite likusius baitus
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SAUGA: žr. Ankstesnį saugos komentarą.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// `src` perkeliamas į smailųjį `dst`, grąžinant ankstesnę `dst` vertę.
///
/// Nei viena, nei kita vertė nėra numesta.
///
/// Ši funkcija semantiškai prilygsta [`mem::replace`], išskyrus tai, kad ji veikia neapdorotais rodyklėmis, o ne nuorodomis.
/// Kai yra nuorodų, pirmenybė turėtų būti teikiama [`mem::replace`].
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `dst` turi būti [valid] skaitant ir rašant.
///
/// * `dst` turi būti tinkamai išlyginti.
///
/// * `dst` turi nurodyti tinkamai inicijuotą `T` tipo vertę.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` turėtų tą patį efektą nereikalaujant nesaugaus blokavimo.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SAUGUMAS: skambinantysis turi garantuoti, kad `dst` galioja
    // perduota į kintamą nuorodą (galioja rašant, sulygiuota, inicializuota) ir negali sutapti su `src`, nes `dst` turi nukreipti į skirtą priskirtą objektą.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // negali sutapti
    }
    src
}

/// Nuskaito vertę iš `src` jos nejudindamas.Tai paliks `src` atmintį nepakitusią.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `src` turi būti [valid] skaitant.
///
/// * `src` turi būti tinkamai išlyginti.Jei taip nėra, naudokite " [`read_unaligned`].
///
/// * `src` turi nurodyti tinkamai inicijuotą `T` tipo vertę.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Rankiniu būdu įdiegti " [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Sukurkite bitų vertės `a` vertės kopiją `tmp`.
///         let tmp = ptr::read(a);
///
///         // Išėjus iš šio momento (tiesiogiai grąžinant arba iškviečiant funkciją, kurią panics) `tmp` reikšmė nukris, o ta pati reikšmė vis dar nurodoma `a`.
///         // Tai gali sukelti neapibrėžtą elgesį, jei `T` nėra `Copy`.
/////
/////
///
///         // Sukurkite bitų vertės `b` vertės kopiją `a`.
///         // Tai saugu, nes kintamos nuorodos negali būti slapyvardžiai.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kaip pirmiau, išėjimas čia gali sukelti neapibrėžtą elgesį, nes ta pati reikšmė nurodoma `a` ir `b`.
/////
///
///         // Perkelkite " `tmp` į " `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` buvo perkeltas (" `write` perima antrojo argumento nuosavybės teisę), todėl čia nieko nenumatyta.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Grąžintos vertės nuosavybė
///
/// `read` sukuria bitų `T` kopiją, neatsižvelgiant į tai, ar `T` yra [`Copy`].
/// Jei `T` nėra [`Copy`], naudojant grąžintą ir `*src` reikšmę galima pažeisti atminties saugumą.
/// Atminkite, kad priskyrimas `*src` skaičiuojamas kaip naudojimas, nes jis bandys sumažinti vertę ties `* src`.
///
/// [`write()`] gali būti naudojamas perrašyti duomenis, nesukeliant jų.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` dabar rodo tą pačią pagrindinę atmintį kaip ir " `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Priskyrus " `s2`, jo pradinė vertė sumažėja.
///     // Be šio taško, `s` nebegalima naudoti, nes pagrindinė atmintis buvo atlaisvinta.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Priskyrus " `s`, senoji reikšmė vėl bus atmesta, dėl to elgsena bus neapibrėžta.
/////
///     // s= String::from("bar");//KLAIDA
///
///     // `ptr::write` gali būti naudojamas perrašyti vertę, jos neišmetus.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAUGUMAS: skambinantysis turi garantuoti, kad `src` tinka skaitymams.
    // `src` negali sutapti su `tmp`, nes `tmp` buvo tiesiog paskirtas rietuvėje kaip atskiras priskirtas objektas.
    //
    //
    // Be to, kadangi mes ką tik įrašėme galiojančią vertę į " `tmp`, garantuojama, kad ji bus tinkamai inicijuota.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Nuskaito vertę iš `src` jos nejudindamas.Tai paliks `src` atmintį nepakitusią.
///
/// Skirtingai nuo " [`read`], " `read_unaligned` veikia su nesuderintomis rodyklėmis.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `src` turi būti [valid] skaitant.
///
/// * `src` turi nurodyti tinkamai inicijuotą `T` tipo vertę.
///
/// Kaip ir " [`read`], " `read_unaligned` sukuria `T` kopiją bitais, neatsižvelgiant į tai, ar " `T` yra " [`Copy`].
/// Jei `T` nėra [`Copy`], naudojant [violate memory safety][read-ownership] gali būti naudojama ir grąžinta, ir reikšmė `*src`.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, žymeklis turi būti NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Dėl `packed` struktūrų
///
/// Šiuo metu neįmanoma sukurti neapdorotų nuorodų į nesuderintus pakuotės struktūros laukus.
///
/// Bandant sukurti neapdorotą žymeklį į `unaligned` struktūros lauką su tokia išraiška kaip `&packed.unaligned as *const FieldType`, prieš paverčiant neapdorotu rodikliu, sukuriama tarpinė nelygi nuoroda.
///
/// Tai, kad ši nuoroda yra laikina ir tuoj pat perduota, neturi reikšmės, nes kompiliatorius visada tikisi, kad nuorodos bus tinkamai išlygintos.
/// Todėl naudojant " `&packed.unaligned as *const FieldType` jūsų programoje iškart atsiranda* neapibrėžtas elgesys *.
///
/// Pavyzdys, ko nedaryti ir kaip tai susiję su " `read_unaligned`, yra:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Čia bandome paimti 32 bitų sveikojo skaičiaus, kuris nėra sulygintas, adresą.
///     let unaligned =
///         // Čia sukuriama laikina nesuderinta nuoroda, dėl kurios elgsena yra neapibrėžta, neatsižvelgiant į tai, ar nuoroda naudojama, ar ne.
/////
///         &packed.unaligned
///         // Perdavimas į neapdorotą rodyklę nepadeda;klaida jau įvyko.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Tačiau nesaugių laukų prieiga tiesiogiai naudojant, pvz., " `packed.unaligned`, yra saugi.
///
///
///
///
///
///
// FIXME: Atnaujinkite dokumentus pagal " RFC #2582 ir draugų rezultatus.
/// # Examples
///
/// Perskaitykite " usize` vertę iš baito buferio:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SAUGUMAS: skambinantysis turi garantuoti, kad `src` tinka skaitymams.
    // `src` negali sutapti su `tmp`, nes `tmp` buvo tiesiog paskirtas rietuvėje kaip atskiras priskirtas objektas.
    //
    //
    // Be to, kadangi mes ką tik įrašėme galiojančią vertę į " `tmp`, garantuojama, kad ji bus tinkamai inicijuota.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Perrašo atminties vietą su duota verte, neskaitydamas ir neišmetęs senosios vertės.
///
/// `write` nenumeta `dst` turinio.
/// Tai yra saugu, tačiau tai gali nutekinti paskirstymą ar išteklius, todėl reikia stengtis neperrašyti objekto, kurį reikėtų mesti.
///
///
/// Be to, jis nenumeta `src`.Semantiniu požiūriu `src` yra perkeltas į vietą, kurią nurodo `dst`.
///
/// Tai tinka inicijuoti neinicijuotą atmintį arba perrašyti atmintį, iš kurios anksčiau buvo [`read`].
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `dst` turi būti [valid] rašant.
///
/// * `dst` turi būti tinkamai išlyginti.Jei taip nėra, naudokite " [`write_unaligned`].
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Rankiniu būdu įdiegti " [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Sukurkite bitų vertės `a` vertės kopiją `tmp`.
///         let tmp = ptr::read(a);
///
///         // Išėjus iš šio momento (tiesiogiai grąžinant arba iškviečiant funkciją, kurią panics) `tmp` reikšmė nukris, o ta pati reikšmė vis dar nurodoma `a`.
///         // Tai gali sukelti neapibrėžtą elgesį, jei `T` nėra `Copy`.
/////
/////
///
///         // Sukurkite bitų vertės `b` vertės kopiją `a`.
///         // Tai saugu, nes kintamos nuorodos negali būti slapyvardžiai.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kaip pirmiau, išėjimas čia gali sukelti neapibrėžtą elgesį, nes ta pati reikšmė nurodoma `a` ir `b`.
/////
///
///         // Perkelkite " `tmp` į " `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` buvo perkeltas (" `write` perima antrojo argumento nuosavybės teisę), todėl čia nieko nenumatyta.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Mes tiesiogiai skambiname į vidų, kad išvengtume funkcijų iškvietimų sugeneruotame kode, nes `intrinsics::copy_nonoverlapping` yra apvyniojimo funkcija.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SAUGUMAS: skambinantysis turi garantuoti, kad `dst` galioja rašant.
    // `dst` negali sutapti su `src`, nes skambinantysis turi keičiamą prieigą prie " `dst`, o " `src` priklauso šiai funkcijai.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Perrašo atminties vietą su duota verte, neskaitydamas ir neišmetęs senosios vertės.
///
/// Skirtingai nei " [`write()`], žymeklis gali būti nesuderintas.
///
/// `write_unaligned` nenumeta `dst` turinio.Tai yra saugu, tačiau tai gali nutekinti paskirstymą ar išteklius, todėl reikia stengtis neperrašyti objekto, kurį reikėtų mesti.
///
/// Be to, jis nenumeta `src`.Semantiniu požiūriu `src` yra perkeltas į vietą, kurią nurodo `dst`.
///
/// Tai tinka inicijuoti neinicijuotą atmintį arba perrašyti atmintį, kuri anksčiau buvo perskaityta naudojant " [`read_unaligned`].
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `dst` turi būti [valid] rašant.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, žymeklis turi būti NULL.
///
/// [valid]: self#safety
///
/// ## Dėl `packed` struktūrų
///
/// Šiuo metu neįmanoma sukurti neapdorotų nuorodų į nesuderintus pakuotės struktūros laukus.
///
/// Bandant sukurti neapdorotą žymeklį į `unaligned` struktūros lauką su tokia išraiška kaip `&packed.unaligned as *const FieldType`, prieš paverčiant neapdorotu rodikliu, sukuriama tarpinė nelygi nuoroda.
///
/// Tai, kad ši nuoroda yra laikina ir tuoj pat perduota, neturi reikšmės, nes kompiliatorius visada tikisi, kad nuorodos bus tinkamai išlygintos.
/// Todėl naudojant " `&packed.unaligned as *const FieldType` jūsų programoje iškart atsiranda* neapibrėžtas elgesys *.
///
/// Pavyzdys, ko nedaryti ir kaip tai susiję su " `write_unaligned`, yra:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Čia bandome paimti 32 bitų sveikojo skaičiaus, kuris nėra sulygintas, adresą.
///     let unaligned =
///         // Čia sukuriama laikina nesuderinta nuoroda, dėl kurios elgsena yra neapibrėžta, neatsižvelgiant į tai, ar nuoroda naudojama, ar ne.
/////
///         &mut packed.unaligned
///         // Perdavimas į neapdorotą rodyklę nepadeda;klaida jau įvyko.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Tačiau nesaugių laukų prieiga tiesiogiai naudojant, pvz., " `packed.unaligned`, yra saugi.
///
///
///
///
///
///
///
///
///
// FIXME: Atnaujinkite dokumentus pagal " RFC #2582 ir draugų rezultatus.
/// # Examples
///
/// Parašykite " usize` reikšmę baito buferiui:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SAUGUMAS: skambinantysis turi garantuoti, kad `dst` galioja rašant.
    // `dst` negali sutapti su `src`, nes skambinantysis turi keičiamą prieigą prie " `dst`, o " `src` priklauso šiai funkcijai.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Mes tiesiogiai skambiname į vidų, kad išvengtume funkcijų iškvietimų sugeneruotame kode.
        intrinsics::forget(src);
    }
}

/// Atlieka nepastovų vertės nuskaitymą iš `src`, jos nepajudindamas.Tai paliks `src` atmintį nepakitusią.
///
/// Nepastovios operacijos yra skirtos veikti I/O atmintyje, ir garantuojama, kad kompiliatorius jų nepašalins ir nepersidės per kitas nepastovias operacijas.
///
/// # Notes
///
/// Šiuo metu " Rust`neturi griežtai ir formaliai apibrėžto atminties modelio, todėl tiksli semantika, ką čia reiškia " "volatile", laikui bėgant gali keistis.
/// Tai sakant, beveik visada semantika bus gana panaši į [C11's definition of volatile][c11].
///
/// Kompiliatorius neturėtų keisti lakiosios atminties operacijų santykinės tvarkos ar skaičiaus.
/// Tačiau nepastovios atminties operacijos su nulio dydžio tipais (pvz., Jei nulinio dydžio tipas perduodamas `read_volatile`) yra ne viršuje ir jų gali būti nepaisoma.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `src` turi būti [valid] skaitant.
///
/// * `src` turi būti tinkamai išlyginti.
///
/// * `src` turi nurodyti tinkamai inicijuotą `T` tipo vertę.
///
/// Kaip ir " [`read`], " `read_volatile` sukuria `T` kopiją bitais, neatsižvelgiant į tai, ar " `T` yra " [`Copy`].
/// Jei `T` nėra [`Copy`], naudojant [violate memory safety][read-ownership] gali būti naudojama ir grąžinta, ir reikšmė `*src`.
/// Tačiau beveik [neteisingai] atmintyje laikyti ne [" Kopija`] tipus yra beveik neteisinga.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Kaip ir C atveju, operacijos nepastovumas neturi jokios įtakos klausimams, susijusiems su tuo pačiu metu iš kelių gijų.Nepastovios prieigos šiuo atžvilgiu elgiasi lygiai taip pat, kaip ir ne atominės.
///
/// Visų pirma, lenktynės tarp " `read_volatile` ir bet kokių rašymo operacijų toje pačioje vietoje yra neapibrėžtas elgesys.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Neišsigąskite, kad kodegenų poveikis būtų mažesnis.
        abort();
    }
    // SAUGUMAS: skambinantysis privalo laikytis " `volatile_load` saugos sutarties.
    unsafe { intrinsics::volatile_load(src) }
}

/// Atlieka nepastovų atminties vietos įrašymą su duota verte, neskaitant ir neišmetant senosios vertės.
///
/// Nepastovios operacijos yra skirtos veikti I/O atmintyje, ir garantuojama, kad kompiliatorius jų nepašalins ir nepersidės per kitas nepastovias operacijas.
///
/// `write_volatile` nenumeta `dst` turinio.Tai yra saugu, tačiau tai gali nutekinti paskirstymą ar išteklius, todėl reikia stengtis neperrašyti objekto, kurį reikėtų mesti.
///
/// Be to, jis nenumeta `src`.Semantiniu požiūriu `src` yra perkeltas į vietą, kurią nurodo `dst`.
///
/// # Notes
///
/// Šiuo metu " Rust`neturi griežtai ir formaliai apibrėžto atminties modelio, todėl tiksli semantika, ką čia reiškia " "volatile", laikui bėgant gali keistis.
/// Tai sakant, beveik visada semantika bus gana panaši į [C11's definition of volatile][c11].
///
/// Kompiliatorius neturėtų keisti lakiosios atminties operacijų santykinės tvarkos ar skaičiaus.
/// Tačiau nepastovios atminties operacijos su nulio dydžio tipais (pvz., Jei nulinio dydžio tipas perduodamas `write_volatile`) yra ne viršuje ir jų gali būti nepaisoma.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `dst` turi būti [valid] rašant.
///
/// * `dst` turi būti tinkamai išlyginti.
///
/// Atminkite, kad net jei " `T` dydis yra " `0`, rodyklė turi būti ne NULL ir tinkamai sulygiuota.
///
/// [valid]: self#safety
///
/// Kaip ir C atveju, operacijos nepastovumas neturi jokios įtakos klausimams, susijusiems su tuo pačiu metu iš kelių gijų.Nepastovios prieigos šiuo atžvilgiu elgiasi lygiai taip pat, kaip ir ne atominės.
///
/// Visų pirma, lenktynės tarp " `write_volatile` ir bet kurios kitos operacijos (skaitymo ar rašymo) toje pačioje vietoje yra neapibrėžtas elgesys.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Neišsigąskite, kad kodegenų poveikis būtų mažesnis.
        abort();
    }
    // SAUGUMAS: skambinantysis privalo laikytis " `volatile_store` saugos sutarties.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Sulygiuokite žymeklį `p`.
///
/// Apskaičiuokite poslinkį (atsižvelgiant į `stride` žingsnio elementus), kurį reikia pritaikyti žymekliui `p`, kad rodyklė `p` susilygintų su `a`.
///
/// Note: Šis diegimas buvo kruopščiai pritaikytas ne panic.Tai yra UB, kad panic.
/// Vienintelis realus pakeitimas, kurį galima atlikti, yra `INV_TABLE_MOD_16` ir susijusių konstantų pakeitimas.
///
/// Jei kada nors nuspręsime leisti " `a` vadinti esmę, kuri nėra " dviejų jėgos`, tikriausiai bus protingiau tiesiog pakeisti naivų įgyvendinimą, o ne bandyti tai pritaikyti, kad prisitaikytų prie šių pokyčių.
///
///
/// Bet kokie klausimai eina adresu@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Tiesioginis šių būdingų savybių naudojimas žymiai pagerina kodegeną opt lygiu <=
    // 1, kur šių operacijų metodo versijos nėra nubrėžtos.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Apskaičiuokite dauginamąją modulinę atvirkštinę `x` modulo `m` vertę.
    ///
    /// Šis diegimas pritaikytas " `align_offset` ir turi šias prielaidas:
    ///
    /// * `m` yra dviejų galia;
    /// * `x < m`; (jei `x ≥ m`, vietoj to perduokite `x % m`)
    ///
    /// Šios funkcijos įgyvendinimas neturi būti panic.Kada nors.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Daugybinė modulinė atvirkštinė lentelė modulo 2⁴=16.
        ///
        /// Atkreipkite dėmesį, kad šioje lentelėje nėra reikšmių, kur nėra atvirkštinio (pvz., `0⁻¹ mod 16`, `2⁻¹ mod 16` ir kt.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// " Modulo`, kuriam skirtas " `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SAUGA: `m` turi būti dviejų galia, taigi ne nulis.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Kartojame "up" pagal šią formulę:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // iki 2²ⁿ ≥ m.Tada galime sumažinti norimą `m`, paimdami rezultatą `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Atkreipkite dėmesį, kad vyniojimo operacijas čia naudojame tyčia-pirminėje formulėje naudojama, pvz., `mod n` atimtis.
                // Puikiai tinka daryti juos `mod usize::MAX`, nes vistiek paimsime rezultatą `mod n`.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SAUGUMAS: `a` yra dviejų galia, todėl nėra nulis.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Atveją galima paprasčiau apskaičiuoti per `-p (mod a)`, tačiau tai slopina LLVM galimybę pasirinkti tokias instrukcijas kaip `lea`.Vietoj to mes skaičiuojame
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // kuris paskirsto operacijas aplink apkrovą, tačiau pakankamai pesimizuodamas " `and`, kad LLVM galėtų panaudoti įvairias jai žinomas optimizacijas.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Jau sulygiuotas.Valio!
        return 0;
    } else if stride == 0 {
        // Jei rodyklė nėra sulygiuota ir elementas yra nulinio dydžio, tada elementų kiekis niekada nesuderins rodyklės.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SAUGA: a yra dviejų galia, taigi nulis.stride==0 atvejis nagrinėjamas aukščiau.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SAUGUMAS: " gcdpow`turi viršutinę ribą, kuri daugiausia yra bitų skaičius " usize`.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SAUGA: gcd visada yra didesnis arba lygus 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ši branch išsprendžia šią tiesinės kongruencijos lygtį:
        //
        // ` p + so = 0 mod a `
        //
        // `p` čia yra rodyklės vertė `s`, `T` žingsnis, `o` poslinkis " T` ir `a`, prašomas sulygiavimas.
        //
        // Jei `g = gcd(a, s)` ir pirmiau nurodyta sąlyga tvirtina, kad `p` taip pat dalijasi iš `g`, galime žymėti `a' = a/g`, `s' = s/g`, `p' = p/g`, tada tai tampa lygiavertė:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Pirmasis terminas yra "the relative alignment of `p` to `a`" (padalytas iš `g`), antrasis-"how does incrementing `p` by `s` bytes change the relative alignment of `p`" (vėl padalytas iš `g`).
        //
        // Skirstymas pagal `g` yra būtinas, kad atvirkštinė forma būtų gerai suformuota, jei `a` ir `s` nėra pirminiai.
        //
        // Be to, šio sprendimo rezultatas nėra "minimal", todėl būtina paimti rezultatą `o mod lcm(s, a)`." `lcm(s, a)` galime pakeisti tik " `a'`.
        //
        //
        //
        //
        //

        // SAUGUMAS: `gcdpow` viršutinė riba yra ne didesnė nei galinių 0 bitų skaičius `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SAUGA: `a2` nėra nulis.`a` perjungus `gcdpow`, negalima perkelti nė vieno iš nustatytų bitų
        // `a` (iš kurių jis turi tiksliai vieną).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SAUGUMAS: `gcdpow` viršutinė riba yra ne didesnė nei galinių 0 bitų skaičius `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SAUGUMAS: `gcdpow` viršutinė riba yra ne didesnė už galinių 0 bitų skaičių
        // `a`.
        // Be to, atimtis negali būti perpildyta, nes `a2 = a >> gcdpow` visada bus griežtai didesnis nei `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SAUGUMAS: " `a2` yra " dviejų galia`, kaip įrodyta aukščiau.`s2` yra griežtai mažesnis nei `a2`
        // nes `(s % a) >> gcdpow` yra griežtai mažesnis nei `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Visiškai negalima sulygiuoti.
    usize::MAX
}

/// Palygina neapdorotus lygybės patarimus.
///
/// Tai tas pats, kas naudojant `==` operatorių, bet ne toks bendras:
/// argumentai turi būti `*const T` neapdoroti rodyklės, o ne viskas, kas įgyvendina `PartialEq`.
///
/// Tai gali būti naudojama norint palyginti `&T` nuorodas (kurios netiesiogiai verčia `*const T`) pagal jų adresą, o ne lyginti reikšmes, į kurias jie nurodo (ką daro `PartialEq for &T` diegimas).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Skiltelės taip pat lyginamos pagal jų ilgį (riebalų rodyklės):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// " Traits` taip pat lyginami pagal jų įgyvendinimą:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Rodyklių adresai yra vienodi.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objektai turi vienodus adresus, tačiau " `Trait` turi skirtingus diegimus.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvertuojant nuorodą į `*const u8`, palyginama pagal adresą.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Nešvarus rodyklė.
///
/// Tai gali būti naudojama norint susieti `&T` nuorodą (kuri netiesiogiai priverčiama naudoti `*const T`) pagal savo adresą, o ne pagal vertę, į kurią jis nurodo (būtent tai daro " `Hash for &T` diegimas).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Funkcijų rodyklių reikšmės
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR reikalingas tarpinis vaidmuo, kurį naudojame
                // kad šaltinio funkcijos rodyklės adreso erdvė būtų išsaugota galutiniame funkcijos rodyklėje.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: AVR reikalingas tarpinis vaidmuo, kurį naudojame
                // kad šaltinio funkcijos rodyklės adreso erdvė būtų išsaugota galutiniame funkcijos rodyklėje.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Nėra variadinių funkcijų su 0 parametrais
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Sukurkite neapdorotą `const` žymeklį į vietą, nesukurdami tarpinės nuorodos.
///
/// Kurti nuorodą naudojant " `&`/`&mut` leidžiama tik tuo atveju, jei rodyklė tinkamai sulygiuota ir nukreipta į inicializuotus duomenis.
/// Tais atvejais, kai šie reikalavimai netenkinami, vietoj jų reikėtų naudoti neapdorotus rodiklius.
/// Tačiau " `&expr as *const _` sukuria nuorodą prieš perduodant ją į neapdorotą rodyklę, ir šiai nuorodai taikomos tos pačios taisyklės kaip ir visoms kitoms nuorodoms.
///
/// Ši makrokomanda gali sukurti neapdorotą žymeklį *, pirmiausia* nesukūrusi nuorodos.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` sukurtų nesuderintą nuorodą ir būtų neapibrėžtas elgesys!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Sukurkite neapdorotą `mut` žymeklį į vietą, nesukurdami tarpinės nuorodos.
///
/// Kurti nuorodą naudojant " `&`/`&mut` leidžiama tik tuo atveju, jei rodyklė tinkamai sulygiuota ir nukreipta į inicializuotus duomenis.
/// Tais atvejais, kai šie reikalavimai netenkinami, vietoj jų reikėtų naudoti neapdorotus rodiklius.
/// Tačiau " `&mut expr as *mut _` sukuria nuorodą prieš perduodant ją į neapdorotą rodyklę, ir šiai nuorodai taikomos tos pačios taisyklės kaip ir visoms kitoms nuorodoms.
///
/// Ši makrokomanda gali sukurti neapdorotą žymeklį *, pirmiausia* nesukūrusi nuorodos.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` sukurtų nesuderintą nuorodą ir būtų neapibrėžtas elgesys!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` verčia kopijuoti lauką, užuot sukūręs nuorodą.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}