use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` bet ne nulis ir kovariantas.
///
/// Tai dažnai yra teisinga, kai reikia kurti duomenų struktūras naudojant neapdorotus rodiklius, tačiau galiausiai yra pavojingiau naudoti dėl papildomų savybių.Jei nesate tikri, ar turėtumėte naudoti " `NonNull<T>`, tiesiog naudokite " `*mut T`!
///
/// Skirtingai nuo " `*mut T`, žymeklis visada turi būti nulis, net jei rodyklė niekada nenurodoma.Taip yra todėl, kad sąrašai gali naudoti šią draudžiamą vertę kaip diskriminantą-`Option<NonNull<T>>` yra tokio pat dydžio kaip `* mut T`.
/// Tačiau rodyklė vis tiek gali pakibti, jei nenurodyta.
///
/// Skirtingai nuo " `*mut T`, " `NonNull<T>` buvo pasirinktas kaip kovariantis su " `T`.Tai leidžia naudoti `NonNull<T>` kuriant kovarianto tipus, tačiau atsiranda netikrumo rizika, jei jis naudojamas tipui, kuris iš tikrųjų neturėtų būti kovariantas.
/// (`*mut T` buvo pasirinktas priešingas pasirinkimas, net jei techniškai netikrumą galėjo sukelti tik iškvietimas nesaugiomis funkcijomis.)
///
/// Kovariacija yra teisinga daugumai saugių abstrakcijų, tokių kaip `Box`, `Rc`, `Arc`, `Vec` ir `LinkedList`.Taip yra todėl, kad jie teikia viešą API, kuri laikosi įprastų Rust bendrų XOR keičiamų taisyklių.
///
/// Jei jūsų tipas negali būti saugus, turite įsitikinti, kad jame yra tam tikras papildomas laukas, kuris suteikia nekintamumą.Dažnai šis laukas bus [`PhantomData`] tipo, pvz., `PhantomData<Cell<T>>` arba `PhantomData<&'a mut T>`.
///
/// Atkreipkite dėmesį, kad `NonNull<T>` yra `From` egzempliorius, skirtas `&T`.Tačiau tai nekeičia fakto, kad mutavimas naudojant (rodyklę, gautą iš a) bendros nuorodos yra neapibrėžtas elgesys, nebent mutacija įvyksta [`UnsafeCell<T>`] viduje.Tas pats pasakytina apie kintamos nuorodos sukūrimą iš bendros nuorodos.
///
/// Kai naudojate šį `From` egzempliorių be `UnsafeCell<T>`, esate atsakingi už tai, kad `as_mut` niekada nebūtų iškviečiamas ir `as_ptr` niekada nebūtų naudojamas mutacijai.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` rodyklės nėra `Send`, nes jų nurodyti duomenys gali būti slapyvardžiai.
// NB, tai nereikalinga, tačiau turėtų pateikti geresnius klaidų pranešimus.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` rodyklės nėra `Sync`, nes jų nurodyti duomenys gali būti slapyvardžiai.
// NB, tai nereikalinga, tačiau turėtų pateikti geresnius klaidų pranešimus.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Sukuria naują kabantį, bet gerai sulygiuotą " `NonNull`.
    ///
    /// Tai naudinga inicijuojant tingiai paskirstomus tipus, kaip tai daro " `Vec::new`.
    ///
    /// Atminkite, kad žymeklio reikšmė gali būti tinkamas žymeklis į `T`, o tai reiškia, kad jo negalima naudoti kaip " "not yet initialized" kontrolinės vertės.
    /// Tingiai paskirstomi tipai turi sekti inicijavimą kitomis priemonėmis.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAUGUMAS: mem::align_of() pateikia ne nulio naudojimą, kuris tada perduodamas
        // iki * mut T.
        // Todėl " `ptr` nėra niekinis ir laikomasi sąlygų skambinti " new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Grąžina bendrąsias vertės nuorodas.Priešingai nei " [`as_ref`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// Kintamą atitikmenį žr. [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // reikalavimai nuorodai.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Pateikia unikalias vertės nuorodas.Priešingai nei " [`as_mut`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// Norėdami pamatyti bendrą atitikmenį, žr. [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///
    ///   Visų pirma, per visą šio laiko trukmės atmintį, į kurią nukreipia rodyklė, negalima pasiekti (skaityti ar rašyti) per bet kurį kitą rodyklę.
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // reikalavimai nuorodai.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Sukuria naują " `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` turi būti niekinis.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `ptr` nėra niekinis.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Sukuria naują `NonNull`, jei `ptr` nėra nulis.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAUGA: rodyklė jau patikrinta ir nėra nulinė
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Atlieka tą pačią funkciją kaip ir [`std::ptr::from_raw_parts`], išskyrus tai, kad grąžinamas `NonNull` žymeklis, o ne neapdorotas `*const` žymeklis.
    ///
    ///
    /// Norėdami gauti daugiau informacijos, žr. " [`std::ptr::from_raw_parts`] dokumentaciją.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SAUGA: `ptr::from::raw_parts_mut` rezultatas nėra nulinis, nes `data_address` yra.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Išskaidykite (galbūt plačią) žymeklį į adreso ir metaduomenų komponentus.
    ///
    /// Vėliau žymeklį galima atkurti naudojant " [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Gauna pagrindinį `*mut` žymeklį.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Grąžina bendrą nuorodą į vertę.Jei reikšmė gali būti neinicijuota, vietoj jos reikia naudoti [`as_uninit_ref`].
    ///
    /// Kintamą atitikmenį žr. [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Žymeklis turi nukreipti į inicijuotą `T` egzempliorių.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    /// (Dalis apie inicijavimą dar nėra visiškai nuspręsta, tačiau kol to nepadarys, vienintelis saugus būdas yra užtikrinti, kad jie iš tikrųjų būtų inicijuoti.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // reikalavimai nuorodai.
        unsafe { &*self.as_ptr() }
    }

    /// Grąžina unikalią vertės nuorodą.Jei reikšmė gali būti neinicijuota, vietoj jos reikia naudoti [`as_uninit_mut`].
    ///
    /// Norėdami pamatyti bendrą atitikmenį, žr. [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Rodyklė turi būti tinkamai išlyginta.
    ///
    /// * Tai turi būti "dereferencable" ta prasme, kuri apibrėžta [the module documentation].
    ///
    /// * Žymeklis turi nukreipti į inicijuotą `T` egzempliorių.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///
    ///   Visų pirma, per visą šio laiko trukmės atmintį, į kurią nukreipia rodyklė, negalima pasiekti (skaityti ar rašyti) per bet kurį kitą rodyklę.
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    /// (Dalis apie inicijavimą dar nėra visiškai nuspręsta, tačiau kol to nepadarys, vienintelis saugus būdas yra užtikrinti, kad jie iš tikrųjų būtų inicijuoti.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // kintamos nuorodos reikalavimai.
        unsafe { &mut *self.as_ptr() }
    }

    /// Perduodama į kito tipo rodyklę.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAUGUMAS: `self` yra `NonNull` žymeklis, kuris nebūtinai yra nulis
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Iš plonos žymeklio ir ilgio sukuria nenulinį neapdorotą pjūvį.
    ///
    /// `len` argumentas yra **elementų** skaičius, o ne baitų skaičius.
    ///
    /// Ši funkcija yra saugi, tačiau nukrypti nuo grąžinimo vertės yra nesaugu.
    /// Pjūvių saugos reikalavimus rasite [`slice::from_raw_parts`] dokumentacijoje.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // sukurkite pjūvio rodyklę, kai pradedate nuo pirmojo elemento žymeklio
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Atkreipkite dėmesį, kad šis pavyzdys dirbtinai parodo šio metodo naudojimą, tačiau "tegul pjūvis= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAUGUMAS: `data` yra `NonNull` žymeklis, kuris nebūtinai yra nulis
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Grąžina nenulinio neapdoroto gabalo ilgį.
    ///
    /// Grąžinta vertė yra **elementų** skaičius, o ne baitų skaičius.
    ///
    /// Ši funkcija yra saugi, net jei negalima nustatyti nulinės neapdorotos skiltelės dalies, nes rodyklė neturi galiojančio adreso.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Grąžina nenulinį rodyklę į gabalo buferį.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SAUGA: Mes žinome, kad `self` nėra niekinis.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Grąžina neapdorotą žymeklį į gabalo buferį.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Grąžina bendrą neinicijuotų verčių dalį.Priešingai nei " [`as_ref`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// Kintamą atitikmenį žr. [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Norint nuskaityti `ptr.len() * mem::size_of::<T>()` daug baitų, žymeklis turi būti [valid] ir jis turi būti tinkamai sulygiuotas.Tai visų pirma reiškia:
    ///
    ///     * Visas šio gabalo atminties diapazonas turi būti vienas paskirtas objektas!
    ///       Skiltelės niekada negali apimti kelių paskirtų objektų.
    ///
    ///     * Žymeklis turi būti išlygintas net ir nulinio ilgio griežinėliams.
    ///     Viena to priežasčių yra ta, kad " enum` išdėstymo optimizavimas gali remtis tuo, kad nuorodos (įskaitant bet kokio ilgio gabalėlius) yra sulygiuotos ir nėra niekinės, kad jas būtų galima atskirti nuo kitų duomenų.
    ///
    ///     Naudodami [`NonNull::dangling()`], galite gauti žymeklį, kurį galima naudoti kaip `data` nulinio ilgio griežinėliams.
    ///
    /// * Bendras gabalo dydis `ptr.len() * mem::size_of::<T>()` neturi būti didesnis nei `isize::MAX`.
    ///   Žr. " [`pointer::offset`] saugos dokumentaciją.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///   Visų pirma, per visą šio laikotarpio atmintį, į kurią nukreipia žymeklis, negalima mutuoti (išskyrus `UnsafeCell` vidų).
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// Taip pat žiūrėkite " [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SAUGUMAS: skambinantysis privalo laikytis " `as_uninit_slice` saugos sutarties.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Pateikia unikalią nuorodą į galbūt neinicijuotų reikšmių skiltį.Priešingai nei " [`as_mut`], tai nereikalauja, kad reikšmė būtų inicijuojama.
    ///
    /// Norėdami pamatyti bendrą atitikmenį, žr. [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Skambindami šiuo metodu, turite įsitikinti, kad visi šie reikalavimai yra teisingi:
    ///
    /// * Žymeklis turi būti [valid] skaitant ir rašant `ptr.len() * mem::size_of::<T>()` daug baitų, ir jis turi būti tinkamai sulygiuotas.Tai visų pirma reiškia:
    ///
    ///     * Visas šio gabalo atminties diapazonas turi būti vienas paskirtas objektas!
    ///       Skiltelės niekada negali apimti kelių paskirtų objektų.
    ///
    ///     * Žymeklis turi būti išlygintas net ir nulinio ilgio griežinėliams.
    ///     Viena to priežasčių yra ta, kad " enum` išdėstymo optimizavimas gali remtis tuo, kad nuorodos (įskaitant bet kokio ilgio gabalėlius) yra sulygiuotos ir nėra niekinės, kad jas būtų galima atskirti nuo kitų duomenų.
    ///
    ///     Naudodami [`NonNull::dangling()`], galite gauti žymeklį, kurį galima naudoti kaip `data` nulinio ilgio griežinėliams.
    ///
    /// * Bendras gabalo dydis `ptr.len() * mem::size_of::<T>()` neturi būti didesnis nei `isize::MAX`.
    ///   Žr. " [`pointer::offset`] saugos dokumentaciją.
    ///
    /// * Privalote laikytis Rust slapyvardžio taisyklių, nes grąžintas `'a` gyvenimo laikas yra pasirinktas savavališkai ir nebūtinai atspindi faktinį duomenų tarnavimo laiką.
    ///   Visų pirma, per visą šio laiko trukmės atmintį, į kurią nukreipia rodyklė, negalima pasiekti (skaityti ar rašyti) per bet kurį kitą rodyklę.
    ///
    /// Tai taikoma net jei šio metodo rezultatas nenaudojamas!
    ///
    /// Taip pat žiūrėkite " [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Tai yra saugu, nes " `memory` tinka daugelio baitų skaitymui ir rašymui.
    /// // Atminkite, kad skambinti " `memory.as_mut()` čia neleidžiama, nes turinys gali būti neinicijuotas.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SAUGUMAS: skambinantysis privalo laikytis " `as_uninit_slice_mut` saugos sutarties.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Grąžina neapdorotą žymeklį prie elemento ar pogrupio, netikrindamas ribų.
    ///
    /// Kviesti šį metodą su ribų riba arba kai `self` negalima nustatyti, yra *[neapibrėžtas elgesys]*, net jei gautas žymeklis nenaudojamas.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAUGUMAS: skambinantysis užtikrina, kad " `self` būtų galima naudoti, o " `index` būtų ribojamas.
        // Dėl to gautas žymeklis negali būti NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SAUGUMAS: unikalus žymeklis negali būti niekinis, todėl sąlygos
        // new_unchecked() yra gerbiami.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAUGA: kintama nuoroda negali būti niekinė.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SAUGUMAS: nuoroda negali būti niekinė, todėl sąlygos
        // new_unchecked() yra gerbiami.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}