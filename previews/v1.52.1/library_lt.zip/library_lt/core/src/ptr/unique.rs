use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Apvyniojimas aplink neapdorotą nenulinį " `*mut T`, kuris rodo, kad referentas priklauso šio įvyniojimo turėtojui.
/// Naudinga pastatų abstrakcijoms, tokioms kaip `Box<T>`, `Vec<T>`, `String` ir `HashMap<K, V>`.
///
/// Skirtingai nuo `*mut T`, `Unique<T>` elgiasi "as if", tai buvo `T` egzempliorius.
/// Jis įgyvendina `Send`/`Sync`, jei `T` yra `Send`/`Sync`.
/// Tai taip pat reiškia stiprių slapyvardžių garantijas, kurių gali tikėtis " `T` egzempliorius:
/// žymeklio referentas neturėtų būti modifikuojamas be unikalaus kelio į jo unikalųjį kelią.
///
/// Jei nesate tikri, ar teisinga naudoti " `Unique` savo tikslams, apsvarstykite galimybę naudoti " `NonNull`, kurio semantika silpnesnė.
///
///
/// Skirtingai nuo " `*mut T`, žymeklis visada turi būti nulis, net jei rodyklė niekada nenurodoma.
/// Taip yra todėl, kad sąrašai gali naudoti šią draudžiamą vertę kaip diskriminantą-" `Option<Unique<T>>` yra tokio pat dydžio kaip " `Unique<T>`.
/// Tačiau rodyklė vis tiek gali pakibti, jei nenurodyta.
///
/// Skirtingai nuo " `*mut T`, " `Unique<T>` yra kovarianti su " `T`.
/// Tai visada turėtų būti teisinga bet kokio tipo, kuris atitinka " Unique` slapyvardžio reikalavimus.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: šis žymeklis neturi įtakos dispersijai, tačiau yra būtinas
    // kad dropck suprastų, kad logiškai turime `T`.
    //
    // Išsamesnės informacijos ieškokite:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` žymekliai yra `Send`, jei `T` yra `Send`, nes jų nurodyti duomenys nėra slapyvardžiai.
/// Atkreipkite dėmesį, kad šio slapyvardžio invarianto tipo sistema neįtvirtina;abstrakcija naudojant `Unique` turi ją įgyvendinti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` žymekliai yra `Sync`, jei `T` yra `Sync`, nes jų nurodyti duomenys nėra slapyvardžiai.
/// Atkreipkite dėmesį, kad šio slapyvardžio invarianto tipo sistema neįtvirtina;abstrakcija naudojant `Unique` turi ją įgyvendinti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Sukuria naują kabantį, bet gerai sulygiuotą " `Unique`.
    ///
    /// Tai naudinga inicijuojant tingiai paskirstomus tipus, kaip tai daro " `Vec::new`.
    ///
    /// Atminkite, kad žymeklio reikšmė gali būti tinkamas žymeklis į `T`, o tai reiškia, kad jo negalima naudoti kaip " "not yet initialized" kontrolinės vertės.
    /// Tingiai paskirstomi tipai turi sekti inicijavimą kitomis priemonėmis.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAUGUMAS: mem::align_of() grąžina galiojantį rodiklį, kuris nėra nulis.The
        // taigi yra laikomasi sąlygų skambinti new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Sukuria naują " `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` turi būti niekinis.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAUGUMAS: skambinantysis turi garantuoti, kad `ptr` nėra niekinis.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Sukuria naują `Unique`, jei `ptr` nėra nulis.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAUGA: rodyklė jau patikrinta ir nėra nulinė.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Gauna pagrindinį `*mut` žymeklį.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Nukreipia turinį.
    ///
    /// Gautas gyvenimas yra susietas su savimi, todėl tai elgiasi "as if". Tai iš tikrųjų buvo T pasiskolintas pavyzdys.
    /// Jei reikia ilgesnio " (unbound) tarnavimo laiko, naudokite " `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // reikalavimai nuorodai.
        unsafe { &*self.as_ptr() }
    }

    /// Keičiamas turinys.
    ///
    /// Gautas gyvenimas yra susietas su savimi, todėl tai elgiasi "as if". Tai iš tikrųjų buvo T pasiskolintas pavyzdys.
    /// Jei reikia ilgesnio " (unbound) tarnavimo laiko, naudokite " `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SAUGUMAS: skambinantysis turi garantuoti, kad " `self` atitinka visus reikalavimus
        // kintamos nuorodos reikalavimai.
        unsafe { &mut *self.as_ptr() }
    }

    /// Perduodama į kito tipo rodyklę.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SAUGA: " Unique::new_unchecked() sukuria naują unikalumą ir poreikius
        // pateiktas rodyklė nėra nulinė.
        // Kadangi mes perduodame save kaip rodyklę, tai negali būti niekinis.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SAUGA: kintama nuoroda negali būti niekinė
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}