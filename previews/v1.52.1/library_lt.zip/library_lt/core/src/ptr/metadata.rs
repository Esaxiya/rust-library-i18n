#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Pateikia bet kokio tipo žymeklio metaduomenų tipą.
///
/// # Rodyklės metaduomenys
///
/// Neapdorotų rodyklių tipus ir " Rust` tipų tipus galima laikyti sudarytais iš dviejų dalių:
/// duomenų rodyklė, kurioje yra vertės atminties adresas ir kai kurie metaduomenys.
///
/// Teigiama, kad statinio dydžio tipams (įgyvendinantiems " `Sized` traits`), taip pat " `extern`, rodyklės yra " plonos`: metaduomenys yra nulinio dydžio, o jų tipas-`()`.
///
///
/// Sakoma, kad žymekliai į " [dynamically-sized types][dst] yra " platūs` arba " riebūs`, jie turi nulio dydžio metaduomenis:
///
/// * Struktūroms, kurių paskutinis laukas yra DST, metaduomenys yra paskutinio lauko metaduomenys
/// * `str` tipo metaduomenys yra ilgis baitais kaip `usize`
/// * Skiltelių tipams, pvz., `[T]`, metaduomenys yra ilgis elementais kaip `usize`
/// * Tokių trait objektų kaip `dyn SomeTrait` metaduomenys yra [`DynMetadata<Self>`][DynMetadata] (pvz., `DynMetadata<dyn SomeTrait>`)
///
/// future kalboje Rust kalba gali įgyti naujų tipų, turinčių skirtingus žymeklio metaduomenis.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # " `Pointee` trait`
///
/// Šio trait taškas yra su `Metadata` susijęs tipas, kuris yra `()`, `usize` arba `DynMetadata<_>`, kaip aprašyta aukščiau.
/// Jis automatiškai įgyvendinamas kiekvienam tipui.
/// Galima daryti prielaidą, kad jis įgyvendinamas bendrame kontekste, net ir be atitinkamų apribojimų.
///
/// # Usage
///
/// Neapdorotus rodiklius galima suskaidyti į duomenų adresus ir metaduomenų komponentus naudojant jų [`to_raw_parts`] metodą.
///
/// Arba vien tik metaduomenis galima išgauti naudojant funkciją [`metadata`].
/// Nuoroda gali būti perduota [`metadata`] ir netiesiogiai priversta.
///
/// (possibly-wide) žymeklį iš jo adreso ir metaduomenų galima sujungti naudojant [`from_raw_parts`] arba [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Metaduomenų tipas nuorodose ir nuorodose į `Self`.
    #[lang = "metadata_type"]
    // NOTE: Laikykite " trait bounds` `static_assert_expected_bounds_for_metadata`
    //
    // " `library/core/src/ptr/metadata.rs` sinchronizuojant su čia esančiais:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Nurodymai į tipus, įgyvendinančius šį trait slapyvardį, yra " ploni`.
///
/// Tai apima statinio dydžio dydžius ir `extern` tipus.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nestabilizuok to, kol trait slapyvardžiai nėra stabilūs kalboje?
pub trait Thin = Pointee<Metadata = ()>;

/// Ištraukite žymeklio metaduomenų komponentą.
///
/// `*mut T`, `&T` arba `&mut T` tipo vertės gali būti tiesiogiai perduodamos šiai funkcijai, nes jos netiesiogiai verčia `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SAUGA: Prieiga prie vertės iš `PtrRepr` sąjungos yra saugi, nes * const T
    // ir " PtrComponents`<T>turi tuos pačius atminties išdėstymus.
    // Šią garantiją gali suteikti tik std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Suformuoja (possibly-wide) neapdorotą žymeklį iš duomenų adreso ir metaduomenų.
///
/// Ši funkcija yra saugi, tačiau grąžinamas rodyklė nebūtinai yra saugi.
/// Pjūvius žr. [`slice::from_raw_parts`] dokumentacijoje dėl saugos reikalavimų.
/// Objektų trait metaduomenys turi būti gaunami iš žymeklio į tą patį pagrindinį ištrintą tipą.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SAUGA: Prieiga prie vertės iš `PtrRepr` sąjungos yra saugi, nes * const T
    // ir " PtrComponents`<T>turi tuos pačius atminties išdėstymus.
    // Šią garantiją gali suteikti tik std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Atlieka tą pačią funkciją kaip ir [`from_raw_parts`], išskyrus tai, kad grąžinamas neapdorotas `*mut` žymeklis, o ne neapdorotas `* const` žymeklis.
///
///
/// Norėdami gauti daugiau informacijos, žr. " [`from_raw_parts`] dokumentaciją.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SAUGA: Prieiga prie vertės iš `PtrRepr` sąjungos yra saugi, nes * const T
    // ir " PtrComponents`<T>turi tuos pačius atminties išdėstymus.
    // Šią garantiją gali suteikti tik std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Norint išvengti `T: Copy` susiejimo, reikalingas rankinis implantas.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Norint išvengti `T: Clone` susiejimo, reikalingas rankinis implantas.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait objekto tipo metaduomenys.
///
/// Tai yra " vtable` (virtualių skambučių lentelės) žymeklis, kuris atspindi visą reikalingą informaciją, kad būtų galima manipuliuoti betono tipu, saugomu trait objekte.
/// Pažymėtina, kad joje yra:
///
/// * tipo dydis
/// * tipo derinimas
/// * rodyklė į tipo " `drop_in_place` impl`(gali būti " no-op` paprastiems seniems duomenims)
/// * nurodo visus " trait` tipo įgyvendinimo metodus
///
/// Atkreipkite dėmesį, kad pirmieji trys yra ypatingi, nes jie yra būtini norint paskirstyti, išmesti ir paskirstyti bet kurį trait objektą.
///
/// Šią struktūrą galima pavadinti tipo parametru, kuris nėra objektas `dyn` trait (pvz., `DynMetadata<u64>`), bet negalima gauti prasmingos tos struktūros vertės.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Bendras visų vtabelių priešdėlis.Po jo pateikiami funkcijų rodikliai, skirti trait metodams.
///
/// Privati `DynMetadata::size_of` ir kt. Įgyvendinimo informacija
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Grąžina tipo, susieto su šiuo " vtable`, dydį.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Grąžina tipo, susieto su šiuo " vtable`, sulyginimą.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Pateikia dydį ir lygiavimą kaip `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAUGUMAS: kompiliatorius išleido šį vaizdą betono Rust tipui
        // žinoma, kad yra galiojantis išdėstymas.Tas pats loginis pagrindas kaip ir " `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Rankiniai implai reikalingi norint išvengti `Dyn: $Trait` ribų.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}