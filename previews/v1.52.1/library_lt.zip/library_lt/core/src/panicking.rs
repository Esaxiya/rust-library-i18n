//! Panic palaikymas " libcore`
//!
//! Pagrindinė biblioteka negali apibrėžti panikos, bet ji *deklaruoja* paniką.
//! Tai reiškia, kad funkcijos " libcore`viduje yra leidžiamos " panic`, tačiau norint, kad " libcore` būtų naudinga, prieš tai esanti crate turi apibrėžti paniką.
//! Dabartinė panikos sąsaja yra:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Šis apibrėžimas leidžia panikuoti bet kokiu bendru pranešimu, tačiau neleidžia žlugti naudojant `Box<Any>` vertę.
//! (" `PanicInfo` yra tik " `&(dyn Any + Send)`, kuriam " PanicInfo: : internal_constructor`užpildome manekeno vertę.) Taip yra todėl, kad " libcore` neleidžiama skirti.
//!
//!
//! Šiame modulyje yra kelios kitos panikos funkcijos, tačiau tai tik būtini kompiliatoriaus lango elementai.Visi panics yra nukreipiami per šią vieną funkciją.
//! Tikrasis simbolis nurodomas per `#[panic_handler]` atributą.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Pagrindinis " libcore` `panic!` makrokomandos įgyvendinimas, kai nenaudojamas formatavimas.
#[cold]
// niekada neįtraukite į eilę, nebent panic_immediate_abort, kad skambučių svetainėse nebūtų kuo labiau užpustytas kodas
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // reikalingas kodegenui panic ant perpildymo ir kitų `Assert` MIR terminatorių
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Jei norite sumažinti pridėtines išlaidas, naudokite " Arguments::new_v1, o ne format_args! (" {}`, Expr).
    // Formatas_argai!makrokomanda naudoja str's Display trait, kad parašytų išraišką, kuri iškviečia Formatter::pad, kuri turi sutalpinti eilučių sutrumpinimą ir užpildymą (nors nė viena čia nenaudojama).
    //
    // Naudojant Arguments::new_v1 kompiliatorius gali leisti praleisti Formatter::pad iš dvejetainio išvesties, sutaupydamas iki kelių kilobaitų.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // reikalinga konstatuojamiems panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // reikalingas kodegenui panic prieigai prie OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Kai naudojamas formatavimas, pagrindinis " libcore` `panic!` makrokomandos įgyvendinimas.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // PASTABA Ši funkcija niekada neperžengia FFI ribos;tai " Rust-to-Rust`skambutis, kurį išsprendžia " `#[panic_handler]` funkcija.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAUGUMAS: `panic_impl` yra apibrėžtas saugiu Rust kodu, todėl jį saugu skambinti.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Vidinė funkcija, skirta `assert_eq!` ir `assert_ne!` makrokomandoms
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}