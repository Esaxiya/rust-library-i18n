// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Pasuka diapazoną `[mid-left, mid+right)` taip, kad elementas `mid` taptų pirmuoju elementu.Atitinkamai pasuka diapazono `left` elementus į kairę arba `right` elementus į dešinę.
///
/// # Safety
///
/// Nurodytas diapazonas turi galioti skaitant ir rašant.
///
/// # Algorithm
///
/// 1 algoritmas naudojamas mažoms `left + right` reikšmėms arba didelėms `T`.
/// Elementai perkeliami į savo galutines pozicijas po vieną pradedant nuo `mid - left` ir judant `right` žingsniais modulo `left + right` taip, kad reikia tik vieno laikino.
/// Galų gale mes grįšime atgal į `mid - left`.
/// Tačiau jei " `gcd(left + right, right)` nėra 1, aukščiau nurodyti veiksmai praleido elementus.
/// Pavyzdžiui:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Laimei, praleistų elementų skaičius tarp užbaigtų elementų visada yra vienodas, todėl galime tiesiog atsverti savo pradinę padėtį ir atlikti daugiau ratų (bendras turų skaičius yra `gcd(left + right, right)` value).
///
/// Galutinis rezultatas yra tas, kad visi elementai yra baigiami vieną kartą.
///
/// 2 algoritmas naudojamas, jei `left + right` yra didelis, bet `min(left, right)` yra pakankamai mažas, kad tilptų ant kamino buferio.
/// `min(left, right)` elementai nukopijuojami ant buferio, `memmove` pritaikomi kitiems, o buferio elementai vėl perkeliami į skylę, esančią priešingoje pusėje nei jie atsirado.
///
/// Algoritmai, kuriuos galima vektorizuoti, pranoksta aukščiau išvardintus dalykus, kai " `left + right` tampa pakankamai didelis.
/// 1 algoritmą galima vektorizuoti suskaldant ir atliekant daugybę raundų vienu metu, tačiau vidutiniškai yra per mažai etapų, kol " `left + right` yra milžiniškas, o blogiausias vieno turo atvejis visada yra.
/// Vietoj to, 3 algoritmas naudoja pakartotinį `min(left, right)` elementų keitimą, kol lieka mažesnė pasukimo problema.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kai " `left < right` vietoj to keičiamasi iš kairės.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. Žemiau pateikti algoritmai gali nepavykti, jei šie atvejai nebus patikrinti
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // 1 algoritmo mikrobangų ženklai rodo, kad vidutinis atsitiktinių poslinkių našumas yra geresnis iki maždaug `left + right == 32`, tačiau blogiausiu atveju našumas nutrūksta net maždaug 16.
            // 24 buvo pasirinktas kaip vidurys.
            // Jei `T` dydis yra didesnis nei 4 " usize`, šis algoritmas pranoksta ir kitus algoritmus.
            //
            //
            let x = unsafe { mid.sub(left) };
            // pirmojo turo pradžia
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` galima rasti prieš ranka, apskaičiuojant `gcd(left + right, right)`, tačiau greičiau atlikti vieną kilpą, kuri apskaičiuoja gcd kaip šalutinį poveikį, tada padaryti likusį gabalą
            //
            //
            let mut gcd = right;
            // gairės atskleidžia, kad greičiau yra visą laiką pakeisti laikinus, o ne vieną laikiną skaityti, kopijuoti atgal ir tada tą laikiną parašyti pačioje pabaigoje.
            // Taip gali nutikti dėl to, kad pakeitus ar pakeičiant laikinus, cikle naudojamas tik vienas atminties adresas, o ne valdyti du.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // užuot padidinę `i` ir tada patikrinę, ar jis yra už ribų, mes patikriname, ar `i` išeis už ribų kito prieaugio metu.
                // Tai apsaugo nuo žymeklių ar `usize` apvyniojimo.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // pirmojo turo pabaiga
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ši sąlyga turi būti čia, jei `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // baigti gabalėlį su daugiau raundų
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nėra nulinio dydžio tipas, todėl skirstyti iš jo dydžio tinka.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // 2 algoritmas Čia `[T; 0]` turi užtikrinti, kad tai tinkamai suderinta su T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // 3 algoritmas Yra alternatyvus keitimo būdas, apimantis suradimą, kur būtų paskutinis šio algoritmo apsikeitimas, ir sukeisti naudojant tą paskutinį gabalą, užuot pakeitus gretimus gabalus, kaip tai daro šis algoritmas, tačiau šis būdas vis tiek yra greitesnis.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // 3 algoritmas, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}