//! Riekelių rūšiavimas
//!
//! Šiame modulyje yra rūšiavimo algoritmas, pagrįstas Orsono Peterso modelį nugalėjusiu " quicksort`, paskelbtu: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabilus rūšiavimas yra suderinamas su libcore, nes jis neskiria atminties, skirtingai nei mūsų stabilus rūšiavimo diegimas.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nukritus kopijoms iš `src` į `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SAUGA: Tai pagalbininkų klasė.
        //          Norėdami sužinoti teisingumą, žr. Jo naudojimą.
        //          Būtent, reikia būti tikriems, kad `src` ir `dst` nepersidengia, kaip reikalaujama pagal `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Pirmąjį elementą perkelia į dešinę, kol jis susiduria su didesniu ar lygiu elementu.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAUGUMAS: Žemiau nurodytos nesaugios operacijos apima indeksavimą be privalomo patikrinimo (`get_unchecked` ir `get_unchecked_mut`)
    // ir kopijuojant atmintį (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksavimas:
    //  1. Masyvo dydį patikrinome iki>=2.
    //  2. Visas indeksavimas, kurį atliksime, yra daugiausia tarp {0 <= index < len}.
    //
    // b.Atminties kopijavimas
    //  1. Gauname nuorodas, kurios garantuoja, kad jos galios.
    //  2. Jie negali sutapti, nes mes gauname nuorodas į skirtumo indeksus.
    //     Būtent, " `i` ir " `i-1`.
    //  3. Jei pjūvis tinkamai sulygiuotas, elementai yra tinkamai sulygiuoti.
    //     Skambintojo pareiga yra įsitikinti, ar pjūvis tinkamai sulygiuotas.
    //
    // Norėdami sužinoti daugiau, žiūrėkite toliau pateiktus komentarus.
    unsafe {
        // Jei pirmieji du elementai neveikia ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Perskaitykite pirmąjį elementą į kamino skirtą kintamąjį.
            // Jei ši palyginimo operacija panics, `hole` nukris ir automatiškai įrašys elementą atgal į skiltį.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Perkelkite " i`-ąjį elementą viena vieta į kairę, taip perkeldami skylę į dešinę.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` nukrenta ir taip nukopijuoja `tmp` į likusią skylę `v`.
        }
    }
}

/// Pastumkite paskutinį elementą į kairę, kol jis susidurs su mažesniu ar lygiu elementu.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SAUGUMAS: Žemiau nurodytos nesaugios operacijos apima indeksavimą be privalomo patikrinimo (`get_unchecked` ir `get_unchecked_mut`)
    // ir kopijuojant atmintį (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksavimas:
    //  1. Masyvo dydį patikrinome iki>=2.
    //  2. Visas indeksavimas, kurį atliksime, yra daugiausia tarp `0 <= index < len-1`.
    //
    // b.Atminties kopijavimas
    //  1. Gauname nuorodas, kurios garantuoja, kad jos galios.
    //  2. Jie negali sutapti, nes mes gauname nuorodas į skirtumo indeksus.
    //     Būtent, " `i` ir " `i+1`.
    //  3. Jei pjūvis tinkamai sulygiuotas, elementai yra tinkamai sulygiuoti.
    //     Skambintojo pareiga yra įsitikinti, ar pjūvis tinkamai sulygiuotas.
    //
    // Norėdami sužinoti daugiau, žiūrėkite toliau pateiktus komentarus.
    unsafe {
        // Jei du paskutiniai elementai yra netinkami ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Perskaitykite paskutinį elementą į kamino skirtą kintamąjį.
            // Jei ši palyginimo operacija panics, `hole` nukris ir automatiškai įrašys elementą atgal į skiltį.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Perkelkite i-ąjį elementą viena vieta į dešinę, tokiu būdu perkeldami skylę į kairę.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` nukrenta ir taip nukopijuoja `tmp` į likusią skylę `v`.
        }
    }
}

/// Iš dalies surūšiuoja gabalėlį, perkeliant aplink kelis netinkamus elementus.
///
/// Pateikia `true`, jei dalis yra rūšiuojama pabaigoje.Ši funkcija yra *O*(*n*) blogiausiu atveju.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Didžiausias gretimų nesutvarkytų porų, kurios bus perkeltos, skaičius.
    const MAX_STEPS: usize = 5;
    // Jei gabalas yra trumpesnis nei šis, neperkelkite jokių elementų.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SAUGA: Mes jau aiškiai atlikome privalomą patikrinimą naudodami " `i < len`.
        // Vėlesnis mūsų indeksavimas yra tik `0 <= index < len` diapazone
        unsafe {
            // Raskite kitą gretimų elementų, kurie nėra tvarkingi, porą.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Ar mes baigėme?
        if i == len {
            return true;
        }

        // Neperkelkite elementų ant trumpų matricų, o tai kainuoja našumą.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Pakeiskite rastą porą elementų.Tai juos nustato teisinga tvarka.
        v.swap(i - 1, i);

        // Mažesnį elementą perkelkite į kairę.
        shift_tail(&mut v[..i], is_less);
        // Didesnį elementą perkelkite į dešinę.
        shift_head(&mut v[i..], is_less);
    }

    // Nepavyko surūšiuoti pjūvio per ribotą žingsnių skaičių.
    false
}

/// Rūšiuoti pjūvį naudojant įterpimo rūšiavimą, kuris yra *O*(*n*^ 2) blogiausiu atveju.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Rūšiuoja `v` naudojant " heapsort`, kuris garantuoja *O*(*n*\*log(* n*)) blogiausiu atveju).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Šis dvejetainis kaupas gerbia nekintantį `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` vaikai:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Pasirinkite didesnį vaiką.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Sustokite, jei invariantas laikosi ties `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Pakeiskite `node` su didesniu vaiku, judėkite vienu žingsniu žemyn ir tęskite sijojimą.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Sukurkite krūvą tiesiniu laiku.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop iš maksimalaus elementų.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Padalykite `v` į elementus, mažesnius nei `pivot`, o paskui elementus, didesnius ar lygius `pivot`.
///
///
/// Pateikia mažesnį nei `pivot` elementų skaičių.
///
/// Padalijimas atliekamas po bloką, siekiant sumažinti šakojimo operacijų kainą.
/// Ši idėja pristatoma [BlockQuicksort][pdf] dokumente.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Elementų skaičius tipiniame bloke.
    const BLOCK: usize = 128;

    // Padalijimo algoritmas pakartoja šiuos veiksmus iki pabaigos:
    //
    // 1. Atsekite bloką iš kairės pusės, kad nustatytumėte elementus, didesnius arba lygius šarnyrui.
    // 2. Dešinėje pusėje atsekite bloką, kad būtų nustatyti elementai, mažesni už pasukimą.
    // 3. Keiskite nustatytus elementus kairėje ir dešinėje.
    //
    // Elementų blokui laikome šiuos kintamuosius:
    //
    // 1. `block` - Bloko elementų skaičius.
    // 2. `start` - Pradėkite žymeklį į `offsets` masyvą.
    // 3. `end` - Galinis žymeklis į `offsets` masyvą.
    // 4. `ofsetai, iš eilės neatitinkančių elementų indeksai.

    // Dabartinis blokas kairėje pusėje (nuo `l` iki `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Dešinėje pusėje esantis blokas (iš `r.sub(block_r)` to `r`).
    // SAUGUMAS: .add() dokumentuose konkrečiai paminėta, kad `vec.as_ptr().add(vec.len())` visada yra saugus
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kai gausime VLA, pabandykite sukurti vieną masyvą, kurio ilgis `min(v.len(), 2 * BLOCK)
    // nei dvi fiksuoto dydžio masyvos, kurių ilgis `BLOCK`.VLA gali būti efektyvesnė talpykloje.

    // Grąžina elementų skaičių tarp žymeklių `l` (inclusive) ir `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Kai " `l` ir " `r` labai priartėja, dalijimasis vyksta po blokus.
        // Tada mes atliekame kai kuriuos pataisymo darbus, kad likusius elementus padalintume tarp jų.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Likusių elementų skaičius (vis dar nėra lyginamas su pasukamuoju elementu).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Sureguliuokite blokų dydžius taip, kad kairysis ir dešinysis blokai nepersidengtų, bet būtų visiškai išlyginti, kad padengtų visą likusį tarpą.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // " `block_l` elementus atsekti iš kairės pusės.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SAUGA: Žemiau nurodytos nesaugios operacijos apima " `offset` naudojimą.
                //         Pagal funkcijos reikalaujamas sąlygas mes jas tenkiname, nes:
                //         1. `offsets_l` yra sukrautas kaminu ir todėl laikomas atskiru paskirstytu objektu.
                //         2. Funkcija `is_less` pateikia `bool`.
                //            " `bool` perdavimas niekada neperpildys `isize`.
                //         3. Mes garantavome, kad `block_l` bus `<= BLOCK`.
                //            Be to, iš pradžių " `end_l` buvo nustatytas į " `offsets_` pradžios žymeklį, kuris buvo nurodytas ant kamino.
                //            Taigi mes žinome, kad net ir blogiausiu atveju (visi `is_less` iškvietimai pateikia klaidingą rezultatą) mes praleisime tik 1 baitą.
                //        Čia dar viena nesaugi operacija yra `elem` išskyrimas.
                //        Tačiau iš pradžių " `elem` buvo pradinis rodiklis, rodantis gabalėlį, kuris visada galioja.
                unsafe {
                    // Šakų palyginimas.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // " `block_r` elementus atsekti iš dešinės pusės.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SAUGA: Žemiau nurodytos nesaugios operacijos apima " `offset` naudojimą.
                //         Pagal funkcijos reikalaujamas sąlygas mes jas tenkiname, nes:
                //         1. `offsets_r` yra sukrautas kaminu ir todėl laikomas atskiru paskirstytu objektu.
                //         2. Funkcija `is_less` pateikia `bool`.
                //            " `bool` perdavimas niekada neperpildys `isize`.
                //         3. Mes garantavome, kad `block_r` bus `<= BLOCK`.
                //            Be to, iš pradžių " `end_r` buvo nustatytas į " `offsets_` pradžios žymeklį, kuris buvo nurodytas ant kamino.
                //            Taigi, mes žinome, kad net ir blogiausiu atveju (visi `is_less` iškvietimai bus teisingi) mes praleisime tik 1 baitą.
                //        Čia dar viena nesaugi operacija yra `elem` išskyrimas.
                //        Tačiau `elem` iš pradžių buvo `1 *sizeof(T)` peržengęs pabaigą, ir mes prieš jį pasiekdami, jį sumažinome `1* sizeof(T)`.
                //        Be to, teigiama, kad `block_r` yra mažesnis nei `BLOCK`, todėl `elem` daugiausia nurodys pjūvio pradžią.
                unsafe {
                    // Šakų palyginimas.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Iš kairės ir dešinės pusės pakeičiamų elementų, kurių užsakymas netinkamas, skaičius.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Užuot tuo pačiu metu pakeitus vieną porą, efektyviau atlikti ciklinę permutaciją.
            // Tai nėra griežtai tolygus keitimui, tačiau gaunamas panašus rezultatas naudojant mažiau atminties operacijų.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Visi kairėje esančiame bloke esantys netinkami elementai buvo perkelti.Pereiti prie kito bloko.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Visi netinkami elementai dešiniajame bloke buvo perkelti.Pereiti prie ankstesnio bloko.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Dabar belieka daugiausia vienas blokas (kairysis arba dešinysis) su elementais, kurie nėra tvarkoje, kuriuos reikia perkelti.
    // Tokius likusius elementus galima paprasčiausiai perkelti į savo bloką.
    //

    if start_l < end_l {
        // Kairysis blokas lieka.
        // Perkelkite likusius nesutvarkytus elementus į kraštutinę dešinę.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Teisingas blokas lieka.
        // Perkelkite likusius nesutvarkytus elementus į kairę.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Daugiau nieko nedaryti, mes baigėme.
        width(v.as_mut_ptr(), l)
    }
}

/// Padalykite `v` į elementus, mažesnius nei `v[pivot]`, o paskui elementus, didesnius ar lygius `v[pivot]`.
///
///
/// Pateikia kelis:
///
/// 1. Mažesnių nei `v[pivot]` elementų skaičius.
/// 2. Tiesa, jei " `v` jau buvo padalytas.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Padėkite šarnyrą pjūvio pradžioje.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Efektyvumui perskaitykite šarnyrą į kamino skirtą kintamąjį.
        // Jei atliksite šią palyginimo operaciją panics, pasukimas bus automatiškai įrašytas atgal į skiltį.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Raskite pirmąją netvarkingų elementų porą.
        let mut l = 0;
        let mut r = v.len();

        // SAUGA: Žemiau pateiktas nesaugumas susijęs su masyvo indeksavimu.
        // Pirmajam: mes jau atliekame ribas tikrindami čia naudodami " `l < r`.
        // Antrasis: iš pradžių mes turime `l == 0` ir `r == v.len()` ir patikrinome tą `l < r` kiekvienoje indeksavimo operacijoje.
        //                     Iš čia mes žinome, kad `r` turi būti bent `r == l`, kuris pasirodė esąs galiojantis nuo pirmojo.
        unsafe {
            // Raskite pirmąjį elementą, kuris yra didesnis arba lygus šarnyrui.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Raskite paskutinį elementą, mažesnį už pasukamą.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` išeina iš taikymo srities ir rašo šarnyrą (kuris yra kamino priskirtas kintamasis) atgal į tą dalį, kurioje buvo iš pradžių.
        // Šis žingsnis yra labai svarbus užtikrinant saugumą!
        //
    };

    // Įdėkite šarnyrą tarp dviejų pertvarų.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Padalinkite `v` į elementus, lygius `v[pivot]`, po kurių eina didesni nei `v[pivot]` elementai.
///
/// Grąžina elementų skaičių, lygų posūkiui.
/// Manoma, kad `v` nėra elementų, mažesnių už pasukimą.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Padėkite šarnyrą pjūvio pradžioje.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Efektyvumui perskaitykite šarnyrą į kamino skirtą kintamąjį.
    // Jei atliksite šią palyginimo operaciją panics, pasukimas bus automatiškai įrašytas atgal į skiltį.
    // SAUGA: Čia esantis žymeklis galioja, nes jis gaunamas iš nuorodos į gabalėlį.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Dabar padalykite skiltelę.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SAUGA: Žemiau pateiktas nesaugumas susijęs su masyvo indeksavimu.
        // Pirmajam: mes jau atliekame ribas tikrindami čia naudodami " `l < r`.
        // Antrasis: iš pradžių mes turime `l == 0` ir `r == v.len()` ir patikrinome tą `l < r` kiekvienoje indeksavimo operacijoje.
        //                     Iš čia mes žinome, kad `r` turi būti bent `r == l`, kuris pasirodė esąs galiojantis nuo pirmojo.
        unsafe {
            // Raskite pirmąjį elementą, didesnį už pasukimą.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Raskite paskutinį elementą, lygų sukimui.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Ar mes baigėme?
            if l >= r {
                break;
            }

            // Pakeiskite rastą porą netinkamų elementų.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Radome `l` elementus, lygius sukimui.Pridėkite 1 prie paties sukimo taško.
    l + 1

    // `_pivot_guard` išeina iš taikymo srities ir rašo šarnyrą (kuris yra kamino priskirtas kintamasis) atgal į tą dalį, kurioje buvo iš pradžių.
    // Šis žingsnis yra labai svarbus užtikrinant saugumą!
}

/// Sklaido kai kuriuos elementus aplink bandydami sulaužyti modelius, kurie gali sukelti nesubalansuotą skaidinių greitį.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George'o Marsaglia sukurtas slapyvardžių skaičių generatorius iš "Xorshift RNGs" popieriaus.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Paimkite atsitiktinius skaičius modulo šį skaičių.
        // Skaičius tinka `usize`, nes `len` nėra didesnis nei `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Kai kurie pagrindiniai kandidatai bus netoliese šio indekso.Pasirinkime juos atsitiktinai.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Sukurkite atsitiktinį skaičių modulo `len`.
            // Tačiau, kad išvengtume brangių operacijų, pirmiausia imame jį dviejų galia modulo, o tada sumažiname `len`, kol jis patenka į `[0, len - 1]` diapazoną.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` garantuojamas mažesnis nei `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Pasirenka suvestinę `v` ir grąžina indeksą bei `true`, jei tikėtina, kad pjūvis jau yra surūšiuotas.
///
/// `v` elementai gali būti pertvarkyti proceso metu.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimalus ilgis, norint pasirinkti mediana-mediana metodą.
    // Trumpesnėse griežinėlėse naudojamas paprastas mediana iš trijų metodas.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Didžiausias apsikeitimų skaičius, kurį galima atlikti naudojant šią funkciją.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trys indeksai, šalia kurių mes ketiname pasirinkti šarnyrą.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Skaičiuoja visą apsikeitimo sandorių skaičių, kurį ketiname atlikti rūšiuodami indeksus.
    let mut swaps = 0;

    if len >= 8 {
        // Keičia indeksus taip, kad `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Keičia indeksus taip, kad `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Randa `v[a - 1], v[a], v[a + 1]` medianą ir išsaugo indeksą `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Raskite medianus `a`, `b` ir `c` apylinkėse.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Raskite mediana tarp `a`, `b` ir `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Buvo atliktas maksimalus apsikeitimo sandorių skaičius.
        // Yra tikimybė, kad griežinėlis mažėja arba dažniausiai mažėja, todėl važiavimas atgal greičiausiai padės greičiau jį rūšiuoti.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Rūšiuoja `v` rekursyviai.
///
/// Jei gabalas turėjo pirmtaką pirminiame masyve, jis nurodomas kaip `pred`.
///
/// `limit` yra leidžiamų nesubalansuotų skaidinių skaičius prieš pereinant prie `heapsort`.
/// Jei nulis, ši funkcija iškart pereis į " heapsort`.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Iki tokio ilgio skiltelės rūšiuojamos naudojant įterpimo rūšiavimą.
    const MAX_INSERTION: usize = 20;

    // Tiesa, jei paskutinis skaidymas buvo pakankamai subalansuotas.
    let mut was_balanced = true;
    // Tiesa, jei paskutinis skaidymas nesumaišė elementų (dalis jau buvo padalinta).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Labai trumpi griežinėliai rūšiuojami naudojant įterpimo rūšiavimą.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Jei buvo pasirinkta per daug blogų " pivot`pasirinkimų, paprasčiausiai grįžkite į " heapsort`, kad garantuotumėte " `O(n * log(n))` blogiausią atvejį.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Jei paskutinis skaidymas buvo nesubalansuotas, pabandykite sulaužyti gabalo modelius, sumaišydami kai kuriuos elementus.
        // Tikimės, kad šį kartą pasirinksime geresnį pasukimą.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Pasirinkite posūkį ir pabandykite atspėti, ar gabalas jau yra rūšiuojamas.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Jei paskutinis skaidymas buvo tinkamai subalansuotas ir nesimaišė elementų, ir jei suvestinis pasirinkimas numato, kad dalis tikriausiai jau yra rūšiuojama ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Pabandykite nustatyti kelis elementus, kurie nėra tvarkingi, ir perkelti juos į teisingas pozicijas.
            // Jei pjūvis bus visiškai išrūšiuotas, mes baigsime.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Jei pasirinktas šarnyras yra lygus pirmtakui, tai yra mažiausias pjūvio elementas.
        // Padalykite skiltį į elementus, lygius ir didesnius už pasukimą.
        // Šis atvejis dažniausiai būna tada, kai pjūvyje yra daugybė pasikartojančių elementų.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Tęskite elementų, kurie yra didesni už pasukimą, rūšiavimą.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Padalykite skiltelę.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Padalykite skiltį į `left`, `pivot` ir `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Pasikartokite tik trumpesnėje pusėje, kad sumažintumėte bendrą rekursinių skambučių skaičių ir sunaudotumėte mažiau vietos rietuvėje.
        // Tada tiesiog tęskite ilgesnę pusę (tai panašu į uodegos rekursiją).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Rūšiuoja `v` naudodamas šabloną nenaudojantį greitį, kuris yra *O*(*n*\*log(* n*)) blogiausiu atveju.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Rūšiavimas neturi prasmingo elgesio su nulio dydžio tipais.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Apribokite nesubalansuotų skaidinių skaičių iki `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Iki tokio ilgio griežinėliams greičiausiai paprasčiau juos tiesiog išrūšiuoti.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pasirinkite pasukimą
        let (pivot, _) = choose_pivot(v, is_less);

        // Jei pasirinktas šarnyras yra lygus pirmtakui, tai yra mažiausias pjūvio elementas.
        // Padalykite skiltį į elementus, lygius ir didesnius už pasukimą.
        // Šis atvejis dažniausiai būna tada, kai pjūvyje yra daugybė pasikartojančių elementų.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jei mes išlaikėme savo indeksą, tada mes esame geri.
                if mid > index {
                    return;
                }

                // Kitu atveju tęskite elementų, didesnių nei ašis, rūšiavimą.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Padalykite skiltį į `left`, `pivot` ir `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Jei vidurys==indeksas, tada mes baigėme, nes partition() garantavo, kad visi elementai po vidurio yra didesni arba lygūs viduriui.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Rūšiavimas neturi prasmingo elgesio su nulio dydžio tipais.Nieko nedaryk.
    } else if index == v.len() - 1 {
        // Raskite maksimalų elementą ir padėkite jį paskutinėje masyvo pozicijoje.
        // Čia galime laisvai naudoti " `unwrap()`, nes žinome, kad v neturi būti tuščias.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Raskite min elementą ir padėkite jį į pirmąją masyvo poziciją.
        // Čia galime laisvai naudoti " `unwrap()`, nes žinome, kad v neturi būti tuščias.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}