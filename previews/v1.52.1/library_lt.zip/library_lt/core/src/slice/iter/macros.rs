//! Makrokomandas, kurias naudoja pjūvio iteratoriai.

// Įterpimas " is_empty`ir " len` daro didžiulį skirtumą
macro_rules! is_empty {
    // Tai, kaip koduojame ZST iteratoriaus ilgį, tai tinka ir ZST, ir ne ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Norėdami atsikratyti kai kurių ribinių patikrinimų (žr. `position`), ilgį apskaičiuojame kiek netikėtai.
// (Išbandyta " codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // mes kartais naudojami nesaugiame bloke

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Šis " _cannot_ naudoja " `unchecked_sub`, nes mes priklausome nuo vyniojimo, kad parodytume ilgų ZST pjūvių iteratorių ilgį.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Mes žinome, kad " `start <= end` gali padaryti geriau nei " `offset_from`, kurį reikia spręsti pasirašius.
            // Čia nustatydami tinkamas vėliavas, mes galime tai pasakyti LLVM, o tai padeda pašalinti ribinius patikrinimus.
            // SAUGA: pagal invarianto tipą, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Taip pat pasakęs LLVM, kad žymekliai yra atskirti nuo tikslaus tipo dydžio kartotinio, jis gali optimizuoti `len() == 0` iki `start == end`, o ne `(end - start) < size`.
            //
            // SAUGUMAS: Pagal tipo nekintantįjį rodyklės sulyginamos taip, kad
            //         atstumas tarp jų turi būti taškinio dydžio kartotinis
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Bendras " `Iter` ir " `IterMut` iteratorių apibrėžimas
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Grąžina pirmąjį elementą ir perkelia iteratoriaus pradžią į priekį 1.
        // Labai pagerina našumą, palyginti su įterptine funkcija.
        // Kartotojas negali būti tuščias.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Grąžina paskutinį elementą ir iteratoriaus galą perkelia atgal 1.
        // Labai pagerina našumą, palyginti su įterptine funkcija.
        // Kartotojas negali būti tuščias.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Sutraukia iteratorių, kai T yra ZST, perkeliant iteratoriaus galą atgal `n`.
        // `n` neturi viršyti `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pagalbinė funkcija norint sukurti atkartojimą iš iteratoriaus.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAUGUMAS: iteratorius buvo sukurtas iš gabalo su rodykle
                // `self.ptr` ir ilgis `len!(self)`.
                // Tai garantuoja, kad visos būtinos " `from_raw_parts` sąlygos yra įvykdytos.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Pagalbinė funkcija, norint perkelti iteratoriaus pradžią į priekį `offset` elementais, grąžinant senąją pradžią.
            //
            // Nesaugu, nes poslinkis neturi viršyti `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SAUGUMAS: skambinantysis garantuoja, kad `offset` neviršija `self.len()`,
                    // taigi šis naujas žymeklis yra " `self` viduje ir taip garantuojamas, kad jis nebus nulinis.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pagalbinė funkcija, leidžianti perkelti iteratoriaus galą atgal `offset` elementais, grąžinant naują galą.
            //
            // Nesaugu, nes poslinkis neturi viršyti `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SAUGUMAS: skambinantysis garantuoja, kad `offset` neviršija `self.len()`,
                    // kuris garantuotai neperpildys `isize`.
                    // Be to, gautas žymeklis yra `slice` ribose, kuri atitinka kitus `offset` reikalavimus.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // būtų galima įgyvendinti su griežinėliais, tačiau taip išvengiama ribų tikrinimo

                // SAUGUMAS: " `assume` skambučiai yra saugūs, nes dalies pradžios rodyklė
                // turi būti ne nulinis, o ne ZST skiltyse taip pat turi būti ne nulinis pabaigos žymeklis.
                // Skambinimas į " `next_unchecked!` yra saugus, nes pirmiausia patikriname, ar iteratorius tuščias.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Šis iteratorius dabar tuščias.
                    if mem::size_of::<T>() == 0 {
                        // Turime tai padaryti taip, nes `ptr` niekada negali būti 0, bet `end` gali būti (dėl įvyniojimo).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SAUGA: pabaiga negali būti 0, jei T nėra ZST, nes ptr nėra 0, o pabaiga>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SAUGA: Mes esame ribose." `post_inc_start` teisingai veikia net ir ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            // Be to, " `assume` išvengia ribų tikrinimo.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SAUGUMAS: mes garantuojame, kad būsimos invarianto ribos:
                        // kai `i >= n`, `self.next()` grąžina `None` ir kilpa nutrūksta.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Mes nepaisome numatytojo diegimo, kuris naudoja " `try_fold`, nes šis paprastas diegimas sukuria mažiau LLVM IR ir yra greičiau kompiliuojamas.
            // Be to, " `assume` išvengia ribų tikrinimo.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SAUGUMAS: `i` turi būti mažesnis nei `n`, nes jis prasideda nuo `n`
                        // ir tik mažėja.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SAUGUMAS: skambinantysis turi garantuoti, kad `i` yra ribose
                // pagrindinį pjūvį, todėl `i` negali perpildyti `isize`, o grąžinamos nuorodos yra garantuojamos kaip nuorodos į griežinėlio elementą ir taip galioja.
                //
                // Taip pat atkreipkite dėmesį, kad skambinantysis taip pat garantuoja, kad mums niekada nebebus skambinama su tuo pačiu indeksu ir kad nebus naudojami jokie kiti metodai, kurie pasieks šią poskyrį, todėl galioja, jei grąžinama nuoroda yra kintama, jei
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // būtų galima įgyvendinti su griežinėliais, tačiau taip išvengiama ribų tikrinimo

                // SAUGA: " `assume` skambučiai yra saugūs, nes ruožo pradžios žymeklis turi būti ne nulinis,
                // o ne ZST skiltyse taip pat turi būti nulis nulinis rodyklė.
                // Skambinimas į " `next_back_unchecked!` yra saugus, nes pirmiausia patikriname, ar iteratorius tuščias.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Šis iteratorius dabar tuščias.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SAUGA: Mes esame ribose." `pre_dec_end` teisingai veikia net ir ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}