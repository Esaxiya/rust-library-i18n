//! Operacijos su ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Tikrina, ar visi šio gabalo baitai yra ASCII diapazone.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Patikrina, ar dvi skiltelės atitinka ASCII mažąsias ir mažąsias raides.
    ///
    /// Tas pats, kas " `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, bet nepriskiriant ir nekopijuojant laikinų elementų.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konvertuoja šį gabalą į jo ASCII didžiųjų raidžių ekvivalentą vietoje.
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Norėdami grąžinti naują didžiosios vertės reikšmę nekeisdami esamos, naudokite [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konvertuoja šią dalį į savo ASCII mažąsias raides, lygiavertes vietoje.
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite grąžinti naują mažosios raidės vertę nekeisdami esamos, naudokite [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Pateikia `true`, jei bet kuris žodžio `v` baitas yra nonascii (>=128).
/// Snarfed iš `../str/mod.rs`, kuris daro kažką panašaus patvirtindamas utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimizuotas ASCII testas, kuriame bus naudojamos operacijos " naudoti vienu metu`, o ne " byte-a-time` operacijos (kai įmanoma).
///
/// Čia naudojamas algoritmas yra gana paprastas.Jei " `s` yra per trumpas, mes tiesiog patikriname kiekvieną baitą ir atliksime tai.Kitu atveju:
///
/// - Perskaitykite pirmąjį žodį su nesuderinta apkrova.
/// - Sulygiuokite žymeklį, perskaitykite tolesnius žodžius iki galo su išlygintomis apkrovomis.
/// - Perskaitykite paskutinį " `usize` iš " `s` su nesuderinta apkrova.
///
/// Jei kuri nors iš šių apkrovų sukuria tai, kam `contains_nonascii` (above) grąžina tiesą, tada žinome, kad atsakymas yra klaidingas.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Jei nieko nepadarytume įgyvendindami žodį vienu metu, grįžkite prie skaliarinės linijos.
    //
    // Tai darome ir architektūrose, kur " `size_of::<usize>()` nepakanka " `usize` sulygiavimui, nes tai keistas " edge` atvejis.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Pirmąjį žodį mes visada skaitome nesuderinti, o tai reiškia, kad `align_offset` yra
    // 0, mes vėl perskaitytume tą pačią sulyginto skaitymo vertę.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SAUGA: Mes patikriname `len < USIZE_SIZE` aukščiau.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Mes tai netiesiogiai patikrinome aukščiau.
    // Atkreipkite dėmesį, kad `offset_to_aligned` yra `align_offset` arba `USIZE_SIZE`, abu jie yra aiškiai pažymėti aukščiau.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAUGA: " word_ptr`yra (tinkamai sulygiuotas) " usize` ptr, kurį naudojame skaitydami
    // vidurinis gabalėlio gabalas.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` yra `word_ptr` baitų indeksas, naudojamas kilpos pabaigos patikrinimams.
    let mut byte_pos = offset_to_aligned;

    // Paranoja tikrina derinimą, nes mes ruošiamės atlikti daugybę nesuderintų krovinių.
    // Praktiškai tai turėtų būti neįmanoma, tačiau neįmanoma pašalinti `align_offset` klaidos.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Skaitykite tolesnius žodžius iki paskutinio sulyginto žodžio, išskyrus paskutinį sulygiuotą žodį, kurį reikia atlikti vėliau tikrinant uodegą, kad įsitikintumėte, jog uodega visada yra ne daugiau kaip viena `usize` iki papildomo branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sveikas protas patikrina, ar perskaityta ribų
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ir kad mūsų prielaidos apie `byte_pos` galioja.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SAUGA: Mes žinome, kad `word_ptr` yra tinkamai sulygiuotas (dėl
        // `align_offset`), ir mes žinome, kad tarp `word_ptr` ir pabaigos turime pakankamai baitų
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SAUGA: Mes žinome tą " `byte_pos <= len - USIZE_SIZE`, o tai reiškia
        // po šio " `add`" `word_ptr` bus ne daugiau kaip vienas.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sveikatingumo patikrinimas siekiant įsitikinti, kad iš tikrųjų liko tik vienas " `usize`.
    // Tai turėtų garantuoti mūsų ciklo būklė.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAUGUMAS: Tai priklauso nuo " `len >= USIZE_SIZE`, kurį patikriname pradžioje.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}