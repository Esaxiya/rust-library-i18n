// Originalus įgyvendinimas paimtas iš rust-memchr.
// Autorių teisės 2015 m. Andrew Gallantas, blusas ir Nicolasas Kochas

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Naudokite sutrumpinimą.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Pateikia `true`, jei `x` yra bet koks nulis baitas.
///
/// Iš *Matters Computational*, J. Arndtas:
///
/// " Idėja yra atimti vieną iš kiekvieno baito ir tada ieškoti baitų, kur paskola paskleista iki reikšmingiausio.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Pateikia pirmąjį indeksą, atitinkantį `x` baitą `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Greitas kelias mažoms griežinėlėms
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Nuskaitykite vieno baito vertę, vienu metu skaitydami du `usize` žodžius.
    //
    // Suskirstykite " `text` į tris dalis
    // - nelyginta pradinė dalis, prieš pirmąjį žodį sulygiuotą adresą tekste
    // - kūnas, nuskaitykite po 2 žodžius vienu metu
    // - paskutinė likusi dalis, <2 žodžių dydis

    // ieškoti iki išlygintos ribos
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ieškoti tekste
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SAUGUMAS: " predikatas` garantuoja mažiausiai 2 * usize_baitų atstumą
        // tarp pjūvio poslinkio ir pabaigos.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pertrauka, jei yra atitinkantis baitas
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Raskite baitą po to, kai kūno kilpa sustojo.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Pateikia paskutinį indeksą, atitinkantį `text` baitą `x`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Nuskaitykite vieno baito vertę, vienu metu skaitydami du `usize` žodžius.
    //
    // " Split `text` padalykite į tris dalis:
    // - neišlyginta uodega, po paskutinio žodžio sulygiuoto adreso tekste,
    // - kūnas, nuskaitytas 2 žodžiais vienu metu,
    // - pirmieji likę baitai, <2 žodžių dydis.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Mes tai vadiname tik tam, kad gautume priešdėlio ir priesagos ilgį.
        // Viduryje mes visada apdorojame du gabalus vienu metu.
        // SAUGUMAS: perdaryti `[u8]` į `[usize]` yra saugu, išskyrus dydžių skirtumus, kuriuos tvarko `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Ieškokite teksto tekste ir įsitikinkite, kad neperžengėme min_aligned_offset.
    // poslinkis visada išlygintas, todėl pakanka tik išbandyti `>` ir išvengti galimo perpildymo.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SAUGA: poslinkis prasideda nuo len, suffix.len(), jei jis didesnis nei
        // min_aligned_offset (prefix.len()) likęs atstumas yra mažiausiai 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Pertrauka, jei yra atitinkantis baitas.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Raskite baitą prieš tai, kai kūno kilpa sustojo.
    text[..offset].iter().rposition(|elt| *elt == x)
}