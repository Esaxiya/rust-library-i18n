//! Nemokamos funkcijos sukurti `&[T]` ir `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Suformuoja gabalėlį iš rodyklės ir ilgio.
///
/// `len` argumentas yra **elementų** skaičius, o ne baitų skaičius.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `data` turi būti [valid] skaitant `len * mem::size_of::<T>()` daug baitų, ir jis turi būti tinkamai sulygiuotas.Tai visų pirma reiškia:
///
///     * Visas šio gabalo atminties diapazonas turi būti vienas paskirtas objektas!
///       Skiltelės niekada negali apimti kelių paskirtų objektų.Netinkamai neatsižvelgiant į tai, žr. [below](#incorrect-usage) pavyzdį.
///     * `data` turi būti nulis ir lygus net ir nulinio ilgio griežinėliams.
///     Viena to priežasčių yra ta, kad " enum` išdėstymo optimizavimas gali remtis tuo, kad nuorodos (įskaitant bet kokio ilgio gabalėlius) yra sulygiuotos ir nėra niekinės, kad jas būtų galima atskirti nuo kitų duomenų.
///     Naudodami [`NonNull::dangling()`], galite gauti žymeklį, kurį galima naudoti kaip `data` nulinio ilgio griežinėliams.
///
/// * `data` turi nurodyti `len` iš eilės tinkamai inicijuotas `T` tipo reikšmes.
///
/// * Atminties, į kurią nurodoma grąžinama dalis, negalima mutuoti visą `'a` naudojimo laiką, išskyrus `UnsafeCell`.
///
/// * Bendras gabalo dydis `len * mem::size_of::<T>()` neturi būti didesnis nei `isize::MAX`.
///   Žr. " [`pointer::offset`] saugos dokumentaciją.
///
/// # Caveat
///
/// Grąžinto griežinėlio gyvenimo trukmė nustatoma pagal jo naudojimą.
/// Siekiant užkirsti kelią atsitiktiniam piktnaudžiavimui, siūloma susieti gyvenimą su tuo šaltiniu, kuris šiame kontekste yra saugus, pvz., Teikiant pagalbinę funkciją, atsižvelgiant į pagrindinės vertės gyvavimo laiką, arba aiškią anotaciją.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // atskleisti vieno elemento pjūvį
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Netinkamas naudojimas
///
/// Ši `join_slices` funkcija yra **netiksli** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Aukščiau pateiktas teiginys užtikrina, kad `fst` ir `snd` yra gretimos, tačiau jos vis tiek gali būti _different allocated objects_, tokiu atveju šio gabalo sukūrimas nėra apibrėžtas elgesys.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ir `b` yra skirtingi objektai ...
///     let a = 42;
///     let b = 27;
///     // ... kuri vis dėlto gali būti išdėstyta greta atmintyje: a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAUGUMAS: skambinantysis privalo laikytis " `from_raw_parts` saugos sutarties.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Atlieka tą pačią funkciją kaip ir " [`from_raw_parts`], išskyrus tai, kad grąžinama keičiama dalis.
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `data` turi būti [valid] tiek skaitant, tiek rašant `len * mem::size_of::<T>()` daug baitų, ir jis turi būti tinkamai sulygiuotas.Tai visų pirma reiškia:
///
///     * Visas šio gabalo atminties diapazonas turi būti vienas paskirtas objektas!
///       Skiltelės niekada negali apimti kelių paskirtų objektų.
///     * `data` turi būti nulis ir lygus net ir nulinio ilgio griežinėliams.
///     Viena to priežasčių yra ta, kad " enum` išdėstymo optimizavimas gali remtis tuo, kad nuorodos (įskaitant bet kokio ilgio gabalėlius) yra sulygiuotos ir nėra niekinės, kad jas būtų galima atskirti nuo kitų duomenų.
///
///     Naudodami [`NonNull::dangling()`], galite gauti žymeklį, kurį galima naudoti kaip `data` nulinio ilgio griežinėliams.
///
/// * `data` turi nurodyti `len` iš eilės tinkamai inicijuotas `T` tipo reikšmes.
///
/// * Atmintimi, į kurią nurodoma grąžinama dalis, negalima naudotis per kitą rodyklę (nesusijusią su grąžinimo verte) visą `'a` naudojimo laiką.
///   Tiek skaitymo, tiek rašymo prieigos yra draudžiamos.
///
/// * Bendras gabalo dydis `len * mem::size_of::<T>()` neturi būti didesnis nei `isize::MAX`.
///   Žr. " [`pointer::offset`] saugos dokumentaciją.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SAUGUMAS: skambinantysis privalo laikytis " `from_raw_parts_mut` saugos sutarties.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Nuorodą į T paverčia 1 ilgio riekele (be kopijavimo).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Nuorodą į T paverčia 1 ilgio riekele (be kopijavimo).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}