#![stable(feature = "core_hint", since = "1.27.0")]

//! Užuominos kompiliatoriui, turinčios įtakos kodo išleidimui ar optimizavimui.
//! Užuominos gali būti kompiliavimo laikas arba vykdymo laikas.

use crate::intrinsics;

/// Informuoja kompiliatorių, kad šis kodo taškas nepasiekiamas, todėl galima toliau optimizuoti.
///
/// # Safety
///
/// Šios funkcijos pasiekimas yra visiškai neapibrėžtas elgesys * (UB).Visų pirma, kompiliatorius daro prielaidą, kad visi UB niekada neturi įvykti, todėl pašalins visas šakas, pasiekiančias skambutį į `unreachable_unchecked()`.
///
/// Kaip ir visi UB atvejai, jei ši prielaida pasirodys neteisinga, ty `unreachable_unchecked()` iškvietimas iš tikrųjų pasiekiamas tarp visų galimų valdymo srautų, kompiliatorius pritaikys neteisingą optimizavimo strategiją ir kartais gali net sugadinti, atrodytų, nesusijusį kodą, sukeldamas sudėtingas derinti problemas.
///
///
/// Naudokite šią funkciją tik tada, kai galite įrodyti, kad kodas niekada jos nepavadins.
/// Kitu atveju apsvarstykite galimybę naudoti " [`unreachable!`] makrokomandą, kuri neleidžia optimizuoti, tačiau vykdydama panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` visada yra teigiamas (ne nulis), todėl `checked_div` niekada negrąžins `None`.
/////
///     // Todėl kitas branch nepasiekiamas.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SAUGA: `intrinsics::unreachable` saugos sutartis turi būti
    // būti palaikomas skambinančiojo.
    unsafe { intrinsics::unreachable() }
}

/// Skleidžia mašinos instrukciją, kad praneštų procesoriui, kad jis veikia užimto laukimo sukimosi cikle (" sukimosi užraktas`).
///
/// Gavęs nugaros kilpos signalą, procesorius gali optimizuoti savo elgseną, pavyzdžiui, taupydamas energiją arba perjungdamas hyper gijas.
///
/// Ši funkcija skiriasi nuo " [`thread::yield_now`], kuri tiesiogiai suteikiama sistemos tvarkaraščiui, o " `spin_loop` nesąveikauja su operacine sistema.
///
/// " `spin_loop` įprastas naudojimo atvejis yra riboto optimistinio verpimo įgyvendinimas CAS cikle sinchronizavimo primityvuose.
/// Norint išvengti tokių problemų kaip prioritetinė inversija, labai svarbu, kad sukimo ciklas būtų nutrauktas atlikus baigtinį iteracijų skaičių ir atlikus atitinkamą blokavimo sistemos skambutį.
///
///
/// **Pastaba**: platformose, kurios nepalaiko " spin-loop` užuominų, ši funkcija visiškai nieko nedaro.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Bendra atominė vertė, kurią gijos naudos koordinuodamos
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Fono gijoje mes galiausiai nustatysime vertę
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Atlikite šiek tiek darbo, tada gyvenkite vertę
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Grįždami į dabartinę giją, laukiame, kol bus nustatyta vertė
/// while !live.load(Ordering::Acquire) {
///     // " Spin loop` yra užuomina į procesorių, kurio laukiame, bet tikriausiai neilgai
/////
///     hint::spin_loop();
/// }
///
/// // Dabar vertė nustatyta
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SAUGUMAS: " `cfg` attr`užtikrina, kad tai vykdysime tik taikydami " x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SAUGUMAS: " `cfg` attr`užtikrina, kad tai vykdysime tik taikydami " x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SAUGUMAS: " `cfg` attr`užtikrina, kad tai vykdysime tik taikydami " aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SAUGUMAS: " `cfg` attr` užtikrina, kad tai vykdysime tik ant rankos taikinių
            // palaikant v6 funkciją.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Tapatybės funkcija, kuri *__ užuomina __* sudarytojui, kad ji būtų maksimaliai pesimistinė dėl to, ką gali padaryti " `black_box`.
///
/// Skirtingai nuo [`std::convert::identity`], Rust kompiliatorius yra skatinamas manyti, kad `black_box` gali naudoti `dummy` bet kokiu galimu būdu, kuriam leidžiama Rust kodui, neįvedant neapibrėžto elgesio į skambinimo kodą.
///
/// Ši savybė daro " `black_box` naudingą rašant kodą, kuriame nereikia tam tikrų optimizavimų, tokių kaip etalonai.
///
/// Tačiau atkreipkite dėmesį, kad " `black_box` yra (ir gali būti) tik " "best-effort" pagrindu.Tai, kiek jis gali blokuoti optimizavimą, gali skirtis priklausomai nuo naudojamos platformos ir " code-gen` programos.
/// Programos jokiu būdu negali pasikliauti " `black_box` dėl *teisingumo*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Tam tikru būdu turime "use" argumentą, kad LLVM negalėtų patirti savęs, o tikslams, kurie jį palaiko, paprastai galime panaudoti tiesioginį surinkimą.
    // LLVM aiškina inline surinkimą, kad tai yra juoda dėžutė.
    // Tai nėra pats didžiausias įgyvendinimas, nes jis tikriausiai deoptimizuoja daugiau nei mes norime, bet kol kas pakankamai geras.
    //
    //

    #[cfg(not(miri))] // Tai tik užuomina, todėl gerai praleisti " Miri`.
    // SAUGA: vidinis mazgas yra draudžiamas.
    unsafe {
        // FIXME: Negalima naudoti `asm!`, nes jis nepalaiko MIPS ir kitų architektūrų.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}