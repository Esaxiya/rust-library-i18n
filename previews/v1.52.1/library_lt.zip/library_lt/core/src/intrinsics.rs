//! Sudarytojo esmė.
//!
//! Atitinkami apibrėžimai yra `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Atitinkami konstatų diegimai yra `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const vidus
//!
//! Note: apie bet kokius būdingumo pokyčius reikėtų aptarti su kalbos komanda.
//! Tai apima konstantos stabilumo pokyčius.
//!
//! Norint, kad vidinis elementas būtų naudojamas kompiliavimo metu, reikia nukopijuoti diegimą iš <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> į `compiler/rustc_mir/src/interpret/intrinsics.rs` ir pridėti vidinį `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
//!
//!
//! Jei manoma, kad vidinis elementas naudojamas iš `const fn` su `rustc_const_stable` atributu, vidinis atributas taip pat turi būti `rustc_const_stable`.
//! Tokio pakeitimo nereikėtų atlikti be " T-lang` konsultacijos, nes jis įkala į kalbą funkciją, kurios negalima atkartoti vartotojo kode be kompiliatoriaus palaikymo.
//!
//! # Volatiles
//!
//! Nepastovūs vidiniai elementai teikia operacijas, skirtas veikti I/O atmintyje, kurių kompiliatorius garantuotai neperorganizuos kitose nepastoviose savybėse.Žr. LLVM dokumentaciją apie " [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atominės savybės suteikia bendras atomines operacijas su mašininiais žodžiais, su daugybe galimų atminties tvarkų.Jie laikosi tos pačios semantikos, kaip ir C++ 11.Žr. LLVM dokumentaciją apie " [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Greitas atminties užsakymo atnaujinimas:
//!
//! * Įsigykite kliūtį spynai įsigyti.Vėlesni skaitymai ir rašymai vyksta po užtvaros.
//! * Atlaisvinimas, užtvara užrakto atleidimui.Ankstesni skaitymai ir rašymai vyksta prieš kliūtį.
//! * Garantuojama, kad nuosekliai, nuosekliai nuosekliai atliekamos operacijos bus vykdomos eilės tvarka.Tai yra standartinis darbo su atomų tipais režimas ir yra lygiavertis " Java` `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Šie importai naudojami siekiant supaprastinti " doc` ryšius
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SAUGA: žr. `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, šie dalykai naudoja neapdorotus rodiklius, nes jie mutuoja slapyvardį, kuris negalioja nei `&`, nei `&mut`.
    //

    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipuose naudojant `compare_exchange` metodą, perduodant [`Ordering::SeqCst`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipuose naudojant `compare_exchange` metodą, perduodant [`Ordering::Acquire`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::Release`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::AcqRel`] kaip `success` ir [`Ordering::Acquire`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipuose naudojant `compare_exchange` metodą, perduodant [`Ordering::Relaxed`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::SeqCst`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::SeqCst`] kaip `success` ir [`Ordering::Acquire`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::Acquire`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange` metodą, perduodant [`Ordering::AcqRel`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šios būdingos versijos versija yra prieinama [`atomic`] tipams naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::SeqCst`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipuose naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::Acquire`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::Release`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipams naudojant `compare_exchange_weak` metodą, [`Ordering::AcqRel`] kaip `success` ir [`Ordering::Acquire`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipuose naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::Relaxed`] kaip `success` ir `failure` parametrus.
    ///
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuotą šios savybės versiją galima įsigyti [`atomic`] tipams naudojant `compare_exchange_weak` metodą, [`Ordering::SeqCst`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::SeqCst`] kaip `success` ir [`Ordering::Acquire`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::Acquire`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Vertė saugoma, jei dabartinė vertė sutampa su `old` verte.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `compare_exchange_weak` metodą, perduodant [`Ordering::AcqRel`] kaip `success` ir [`Ordering::Relaxed`] kaip `failure` parametrus.
    /// Pavyzdžiui, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Įkelia dabartinę rodyklės vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `load` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Įkelia dabartinę rodyklės vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `load` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Įkelia dabartinę rodyklės vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `load` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Vertė saugoma nurodytoje atminties vietoje.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `store` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Vertė saugoma nurodytoje atminties vietoje.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `store` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Vertė saugoma nurodytoje atminties vietoje.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `store` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Vertė saugoma nurodytoje atminties vietoje, grąžinant senąją vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `swap` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vertė saugoma nurodytoje atminties vietoje, grąžinant senąją vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `swap` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vertė saugoma nurodytoje atminties vietoje, grąžinant senąją vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `swap` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vertė saugoma nurodytoje atminties vietoje, grąžinant senąją vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `swap` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Vertė saugoma nurodytoje atminties vietoje, grąžinant senąją vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `swap` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_add` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_add` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_add` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_add` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_add` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Atimkite iš dabartinės vertės, grąžindami ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_sub` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atimkite iš dabartinės vertės, grąžindami ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_sub` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atimkite iš dabartinės vertės, grąžindami ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_sub` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atimkite iš dabartinės vertės, grąžindami ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_sub` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Atimkite iš dabartinės vertės, grąžindami ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_sub` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitais ir su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_and` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais ir su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_and` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais ir su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_and` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais ir su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_and` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais ir su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_and` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitai nand su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`AtomicBool`] tipui naudojant `fetch_nand` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitai nand su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`AtomicBool`] tipui naudojant `fetch_nand` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitai nand su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`AtomicBool`] tipui naudojant `fetch_nand` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitai nand su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`AtomicBool`] tipui naudojant `fetch_nand` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitai nand su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`AtomicBool`] tipui naudojant `fetch_nand` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitais arba su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_or` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais arba su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_or` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais arba su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_or` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais arba su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_or` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitais arba su dabartine verte, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_or` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dydis xor arba dabartinė vertė, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_xor` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dydis xor arba dabartinė vertė, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_xor` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dydis xor arba dabartinė vertė, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_xor` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dydis xor arba dabartinė vertė, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_xor` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dydis xor arba dabartinė vertė, grąžinant ankstesnę vertę.
    ///
    /// Stabilizuota šio vidinio varianto versija yra prieinama [`atomic`] tipams naudojant `fetch_xor` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Didžiausia su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_max` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_max` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_max` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_max` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_max` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mažiausias su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_min` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_min` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_min` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra prieinama [`atomic`] pasirašytų sveikųjų skaičių tipams naudojant `fetch_min` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant pasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] pasirašytų sveikųjų skaičių tipų, naudojant `fetch_min` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Mažiausias su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_min` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_min` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_min` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_min` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Mažiausias su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic`] nepasirašytų sveikųjų skaičių tipuose naudojant `fetch_min` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Didžiausia su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_max` metodą, perduodant [`Ordering::SeqCst`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_max` metodą, perduodant [`Ordering::Acquire`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_max` metodą, perduodant [`Ordering::Release`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_max` metodą, perduodant [`Ordering::AcqRel`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Didžiausia su dabartine verte, naudojant nepasirašytą palyginimą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`atomic`] nepasirašytų sveikųjų skaičių tipų, naudojant `fetch_max` metodą, perduodant [`Ordering::Relaxed`] kaip `order`.
    /// Pavyzdžiui, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Vidinis " `prefetch` yra užuomina į kodų generatorių įterpti išankstinio nurodymo komandą, jei ji palaikoma;priešingu atveju tai yra draudimas.
    /// Prefetch'ai neturi jokios įtakos programos elgsenai, tačiau gali pakeisti jos veikimo charakteristikas.
    ///
    /// `locality` argumentas turi būti pastovus sveikasis skaičius ir yra laikinas lokalumo specifikatorius, svyruojantis nuo (0), be vietovės, iki (3), ypač lokalus laikymas talpykloje.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Vidinis " `prefetch` yra užuomina į kodų generatorių įterpti išankstinio nurodymo komandą, jei ji palaikoma;priešingu atveju tai yra draudimas.
    /// Prefetch'ai neturi jokios įtakos programos elgsenai, tačiau gali pakeisti jos veikimo charakteristikas.
    ///
    /// `locality` argumentas turi būti pastovus sveikasis skaičius ir yra laikinas lokalumo specifikatorius, svyruojantis nuo (0), be vietovės, iki (3), ypač lokalus laikymas talpykloje.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Vidinis " `prefetch` yra užuomina į kodų generatorių įterpti išankstinio nurodymo komandą, jei ji palaikoma;priešingu atveju tai yra draudimas.
    /// Prefetch'ai neturi jokios įtakos programos elgsenai, tačiau gali pakeisti jos veikimo charakteristikas.
    ///
    /// `locality` argumentas turi būti pastovus sveikasis skaičius ir yra laikinas lokalumo specifikatorius, svyruojantis nuo (0), be vietovės, iki (3), ypač lokalus laikymas talpykloje.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Vidinis " `prefetch` yra užuomina į kodų generatorių įterpti išankstinio nurodymo komandą, jei ji palaikoma;priešingu atveju tai yra draudimas.
    /// Prefetch'ai neturi jokios įtakos programos elgsenai, tačiau gali pakeisti jos veikimo charakteristikas.
    ///
    /// `locality` argumentas turi būti pastovus sveikasis skaičius ir yra laikinas lokalumo specifikatorius, svyruojantis nuo (0), be vietovės, iki (3), ypač lokalus laikymas talpykloje.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atominė tvora.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::fence`] versijoje, perduodant [`Ordering::SeqCst`] kaip `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atominė tvora.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::fence`] versijoje, perduodant [`Ordering::Acquire`] kaip `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atominė tvora.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::fence`] versijoje, perduodant [`Ordering::Release`] kaip `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atominė tvora.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::fence`] versijoje, perduodant [`Ordering::AcqRel`] kaip `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Tik kompiliatorių atminties barjeras.
    ///
    /// Kompiliatorius niekada nepertvarkys atminties prieigų per šią kliūtį, tačiau jokios instrukcijos jai nebus išleistos.
    /// Tai tinka atliekant operacijas su ta pačia gija, kurios galima išvengti, pavyzdžiui, bendraujant su signalo tvarkytuvais.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::compiler_fence`] versijoje, perduodant [`Ordering::SeqCst`] kaip `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Tik kompiliatorių atminties barjeras.
    ///
    /// Kompiliatorius niekada nepertvarkys atminties prieigų per šią kliūtį, tačiau jokios instrukcijos jai nebus išleistos.
    /// Tai tinka atliekant operacijas su ta pačia gija, kurios galima išvengti, pavyzdžiui, bendraujant su signalo tvarkytuvais.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::compiler_fence`] versijoje, perduodant [`Ordering::Acquire`] kaip `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Tik kompiliatorių atminties barjeras.
    ///
    /// Kompiliatorius niekada nepertvarkys atminties prieigų per šią kliūtį, tačiau jokios instrukcijos jai nebus išleistos.
    /// Tai tinka atliekant operacijas su ta pačia gija, kurios galima išvengti, pavyzdžiui, bendraujant su signalo tvarkytuvais.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::compiler_fence`] versijoje, perduodant [`Ordering::Release`] kaip `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Tik kompiliatorių atminties barjeras.
    ///
    /// Kompiliatorius niekada nepertvarkys atminties prieigų per šią kliūtį, tačiau jokios instrukcijos jai nebus išleistos.
    /// Tai tinka atliekant operacijas su ta pačia gija, kurios galima išvengti, pavyzdžiui, bendraujant su signalo tvarkytuvais.
    ///
    /// Stabilizuotą šios vidinės versijos versiją galima įsigyti [`atomic::compiler_fence`] versijoje, perduodant [`Ordering::AcqRel`] kaip `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Stebuklinga magija, savo prasmę gaunanti iš prie funkcijos pridedamų atributų.
    ///
    /// Pavyzdžiui, duomenų srautas naudoja tai statiniams teiginiams įvesti, kad " `rustc_peek(potentially_uninitialized)` iš tikrųjų dar kartą patikrintų, ar duomenų srautas iš tikrųjų apskaičiavo, kad jis neinicializuotas tame valdymo srauto taške.
    ///
    ///
    /// Šios savybės nereikėtų naudoti už kompiliatoriaus ribų.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Nutraukia proceso vykdymą.
    ///
    /// Patogesnė ir stabilesnė šios operacijos versija yra " [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informuoja optimizatorių, kad šis kodo taškas nepasiekiamas, todėl galima toliau optimizuoti.
    ///
    /// NB, tai labai skiriasi nuo " `unreachable!()` makrokomandos: skirtingai nei makrokomanda, kurią vykdant panics, ji yra *neapibrėžta elgsena*, kad pasiektumėte šia funkcija pažymėtą kodą.
    ///
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informuoja optimizatorių, kad sąlyga visada teisinga.
    /// Jei sąlyga yra klaidinga, elgesys nėra apibrėžtas.
    ///
    /// Šiam būdingam kodui nėra sukurtas kodas, tačiau optimizatorius bandys išsaugoti jį (ir jo būklę) tarp leidimų, o tai gali trukdyti optimizuoti aplinkinį kodą ir sumažinti našumą.
    /// Jo nereikėtų naudoti, jei nekintantį variantą optimizatorius gali atrasti pats arba jei jis neleidžia reikšmingai optimizuoti.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Užuominos kompiliatoriui, kad branch sąlyga greičiausiai bus teisinga.
    /// Grąžina jam perduotą vertę.
    ///
    /// Bet koks naudojimas, išskyrus `if` sakinius, greičiausiai neturės įtakos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Užuominos kompiliatoriui, kad branch sąlyga greičiausiai yra klaidinga.
    /// Grąžina jam perduotą vertę.
    ///
    /// Bet koks naudojimas, išskyrus `if` sakinius, greičiausiai neturės įtakos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Vykdo pertraukimo taško gaudyklę, kurią tikrins derintojas.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn breakpoint();

    /// Tipo dydis baitais.
    ///
    /// Tiksliau tariant, tai yra baitų skirtumas tarp vienas po kito einančių to paties tipo elementų, įskaitant išlyginimo užpildymą.
    ///
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Mažiausias tipo sulyginimas.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Pageidaujamas tipo sulyginimas.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Nurodytos vertės dydis baitais.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Būtinas nurodytos vertės sulyginimas.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Gauna statinį eilutės pjūvį, kuriame yra tipo pavadinimas.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Gauna identifikatorių, kuris yra unikalus nurodytam tipui.
    /// Ši funkcija grąžins tą pačią tipo vertę, nepriklausomai nuo to, kuriame crate jis bus naudojamas.
    ///
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Apsauga nuo nesaugių funkcijų, kurių niekada negalima vykdyti, jei `T` nėra apgyvendinta:
    /// Tai statiškai pakeis " panic` arba nieko nedarys.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Saugumas nesaugioms funkcijoms, kurių niekada negalima vykdyti, jei " `T` neleidžia inicijuoti nulio: tai statiškai arba " panic`, arba nieko nedarys.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn assert_zero_valid<T>();

    /// Saugumas nesaugioms funkcijoms, kurių niekada negalima vykdyti, jei " `T` yra netinkamų bitų modelių: tai statiškai atliks " panic` arba nieko nedarys.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn assert_uninit_valid<T>();

    /// Gauna nuorodą į statinį `Location`, nurodantį, kur jis buvo vadinamas.
    ///
    /// Apsvarstykite galimybę naudoti " [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Perkelia vertę iš taikymo srities, nenaudojant lašų klijų.
    ///
    /// Tai egzistuoja tik " [`mem::forget_unsized`];normalus `forget` vietoj to naudoja `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Iš naujo interpretuoja vieno tipo vertės bitus kaip kitus tipus.
    ///
    /// Abiejų tipų dydis turi būti vienodas.
    /// Nei originalas, nei rezultatas negali būti " [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` semantiškai prilygsta bitų judėjimui vieno tipo į kitą.Jis nukopijuoja bitus iš šaltinio vertės į paskirties vertę, tada pamiršta originalą.
    /// Tai prilygsta C " `memcpy` po gaubtu, kaip ir " `transmute_copy`.
    ///
    /// Kadangi `transmute` yra pagal vertę atliekama operacija, pačių *transmutuotų reikšmių* sulyginimas nerūpi.
    /// Kaip ir bet kuri kita funkcija, kompiliatorius jau užtikrina, kad ir `T`, ir `U` būtų tinkamai sulygiuoti.
    /// Tačiau transmutuodamas reikšmes, kurios *nurodo kitur*(pvz., Rodykles, nuorodas, langelius ...), skambinantysis turi užtikrinti tinkamą nurodytų verčių derinimą.
    ///
    /// `transmute` yra **nepaprastai** nesaugu.Yra daugybė būdų, kaip šią funkciją sukelti [undefined behavior][ub].`transmute` turėtų būti absoliuti paskutinė išeitis.
    ///
    /// " [nomicon](../../nomicon/transmutes.html) turi papildomą dokumentaciją.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Yra keli dalykai, kuriems " `transmute` tikrai naudinga.
    ///
    /// Žymeklio pavertimas funkcijos rodykle.Tai nėra * nešiojama mašinoms, kurių funkcijų rodyklės ir duomenų rodyklės yra skirtingo dydžio.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Pratęsti visą gyvenimą arba sutrumpinti nekintamą gyvenimą.Tai pažangus, labai nesaugus Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Nenusiminkite: daugelį " `transmute` galima panaudoti kitomis priemonėmis.
    /// Žemiau pateikiamos įprastos `transmute` programos, kurias galima pakeisti saugesnėmis konstrukcijomis.
    ///
    /// Žalios bytes(`&[u8]`) pavertimas `u32`, `f64` ir kt .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // vietoj to naudokite `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // arba naudokite `u32::from_le_bytes` arba `u32::from_be_bytes`, norėdami nurodyti endianumą
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Žymeklio pavertimas " `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Vietoj to naudokite " `as` liejinį
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// " `*mut T` pavertimas " `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Vietoj to naudokite paskolą
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// " `&mut T` pavertimas " `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Dabar, sujungę " `as` ir iš naujo skolindamiesi, atkreipkite dėmesį, kad " `as` sujungimas " `as` nėra tranzityvus
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// " `&str` pavertimas " `&[u8]`:
    ///
    /// ```
    /// // tai nėra geras būdas tai padaryti.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Galėtumėte naudoti " `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Arba tiesiog naudokite baitų eilutę, jei galite valdyti eilutės pažodį
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// " `Vec<&T>` pavertimas " `Vec<Option<&T>>`.
    ///
    /// Norėdami pakeisti vidinį konteinerio turinio tipą, turite nepažeisti nė vieno konteinerio invarianto.
    /// " `Vec` tai reiškia, kad vidinių tipų dydis *ir lygiavimas* turi sutapti.
    /// Kiti konteineriai gali priklausyti nuo tipo dydžio, išlyginimo ar net " `TypeId`. Tokiu atveju transmutuoti visiškai neįmanoma nepažeidžiant konteinerių invariantų.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonuokite vector, nes vėliau juos panaudosime pakartotinai
    /// let v_clone = v_orig.clone();
    ///
    /// // Transmute naudojimas: tai priklauso nuo nenurodyto `Vec` duomenų išdėstymo, o tai yra bloga idėja ir gali sukelti neapibrėžtą elgesį.
    /////
    /// // Tačiau tai nėra kopija.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tai yra siūlomas, saugus būdas.
    /// // Vis dėlto jis nukopijuoja visą vector į naują masyvą.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Tai yra tinkamas " "transmuting" a `Vec` be kopijavimo būdas, nesaugus, nesikliaujant duomenų išdėstymu.
    /// // Užuot pažodžiui iškvietę `transmute`, mes atliekame rodyklę, tačiau kalbant apie pradinio vidinio tipo (`&i32`) pavertimą nauju (`Option<&i32>`), tai turi visas tas pačias išlygas.
    /////
    /// // Be pirmiau pateiktos informacijos, taip pat skaitykite [`from_raw_parts`] dokumentus.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Atnaujinkite, kai stabilizuojamas vec_into_raw_parts.
    ///     // Įsitikinkite, kad originalus vector nėra numestas.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// " `split_at_mut` diegimas:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Yra keli būdai, kaip tai padaryti, ir yra daug problemų dėl šio (transmute) būdo.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // pirma: transmutas nėra saugus;tikrina tik tai, kad T ir
    ///         // U yra vienodo dydžio.
    ///         // Antra, čia jūs turite dvi kintamas nuorodas, nukreipiančias į tą pačią atmintį.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tai pašalina tipo saugos problemas;`&mut *` duos jums tik `&mut T` iš `&mut T` arba `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // tačiau jūs vis dar turite dvi kintamas nuorodas, nukreipiančias į tą pačią atmintį.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tai daro standartinė biblioteka.
    /// // Tai yra geriausias būdas, jei jums reikia padaryti kažką panašaus
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dabar tai turi tris keičiamas nuorodas, nukreiptas į tą pačią atmintį.`slice`, vertė ret.0 ir vertė ret.1.
    ///         // `slice` niekada nenaudojamas po " `let ptr = ...`, todėl galima laikyti jį kaip " "dead", todėl jūs turite tik du tikrus keičiamus gabalėlius.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Nors tai daro vidinę konstantą stabilią, konst. Fn turime tam tikrą pasirinktinį kodą
    // patikrinimai, neleidžiantys jo naudoti per `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Pateikia `true`, jei faktiniam tipui, nurodytam kaip `T`, reikia lašų klijų;grąžina `false`, jei tikrasis `T` pateiktas tipas įgyvendina `Copy`.
    ///
    ///
    /// Jei tikram tipui nereikalingi klijų lašai ir jis neįgyvendina `Copy`, tada šios funkcijos grąžinimo vertė nenurodyta.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Skaičiuoja poslinkį iš rodyklės.
    ///
    /// Tai įgyvendinama kaip savaime, kad būtų išvengta keitimo į sveiką skaičių ir iš jo, nes atlikus konversiją būtų išmesta slapyvardžio informacija.
    ///
    /// # Safety
    ///
    /// Pradinis ir gaunamas žymeklis turi būti ribos arba vienas baitas už paskirto objekto pabaigos.
    /// Jei kuris nors rodyklė yra ribų arba įvyksta aritmetinis perpildymas, bet koks tolesnis grąžinamos vertės naudojimas sukels neapibrėžtą elgesį.
    ///
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Apskaičiuoja poslinkį iš žymeklio, kuris gali būti apvyniotas.
    ///
    /// Tai įgyvendinama kaip savaime išvengiama konversijos į sveiką skaičių ir iš jo, nes konversija slopina tam tikrus optimizavimus.
    ///
    /// # Safety
    ///
    /// Skirtingai nuo " `offset` vidinės savybės, ši savybė neapriboja gauto rodyklės rodomo į paskirtą objektą ar vieno baito už paskirto objekto pabaigos ir apgaubia dviejų komplemento aritmetika.
    /// Gauta reikšmė nebūtinai galioja norint iš tikrųjų pasiekti atmintį.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Lygiavertis atitinkamam vidiniam " `llvm.memcpy.p0i8.0i8.*`, kurio dydis yra `count`*`size_of::<T>()` ir išlyginimas
    ///
    /// `min_align_of::<T>()`
    ///
    /// Nepastovus parametras nustatytas kaip `true`, todėl jis nebus optimizuotas, nebent dydis bus lygus nuliui.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Lygiavertis atitinkamam vidiniam `llvm.memmove.p0i8.0i8.*`, kurio dydis `count* size_of::<T>()` ir išlygiavimas
    ///
    /// `min_align_of::<T>()`
    ///
    /// Nepastovus parametras nustatytas kaip `true`, todėl jis nebus optimizuotas, nebent dydis bus lygus nuliui.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Lygiavertis atitinkamam vidiniam `llvm.memset.p0i8.*`, kurio dydis yra `count* size_of::<T>()` ir išlyginimas `min_align_of::<T>()`.
    ///
    ///
    /// Nepastovus parametras nustatytas kaip `true`, todėl jis nebus optimizuotas, nebent dydis bus lygus nuliui.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Atlieka nepastovią apkrovą iš žymiklio `src`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Atlieka nepastovią `dst` žymeklio saugyklą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Atlieka nepastovią apkrovą iš žymiklio `src`. Rodyklės nereikia lyginti.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Atlieka nepastovią `dst` žymeklio saugyklą.
    /// Žymeklio nereikia lyginti.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Pateikia `f32` kvadratinę šaknį
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Pateikia `f64` kvadratinę šaknį
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` padidina iki sveiko skaičiaus.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` padidina iki sveiko skaičiaus.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Pateikia `f32` sinusą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Pateikia `f64` sinusą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Pateikia `f32` kosinusą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Pateikia `f64` kosinusą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// " `f32` pakelia į " `f32` galią.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// " `f64` pakelia į " `f64` galią.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Pateikia `f32` eksponentą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Pateikia `f64` eksponentą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Grąžina 2 pakeltus į `f32` galią.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Grąžina 2 pakeltus į `f64` galią.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Pateikia natūralų `f32` logaritmą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Pateikia natūralų `f64` logaritmą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Pateikia bazinį `f32` logaritmą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Pateikia `f64` bazinį 10 logaritmų.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Pateikia `f32` bazinį 2 logaritmą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Pateikia `f64` bazinį 2 logaritmą.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Pateikia `f32` reikšmes `a * b + c`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Pateikia `f64` reikšmes `a * b + c`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Pateikia absoliučią `f32` vertę.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Pateikia absoliučią `f64` vertę.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Pateikia mažiausias dvi `f32` reikšmes.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Pateikia mažiausias dvi `f64` reikšmes.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Pateikia maksimalias dvi `f32` reikšmes.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Pateikia maksimalias dvi `f64` reikšmes.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Nukopijuoja `f32` reikšmių ženklą iš `y` į `x`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Nukopijuoja `f64` reikšmių ženklą iš `y` į `x`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Pateikia didžiausią sveiką skaičių, mažesnį arba lygų `f32`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Pateikia didžiausią sveiką skaičių, mažesnį arba lygų `f64`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Pateikia mažiausią sveiką skaičių, didesnį už `f32` arba lygų jam.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Pateikia mažiausią sveiką skaičių, didesnį už `f64` arba lygų jam.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Grąžina sveiką `f32` dalį.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Grąžina sveiką `f64` dalį.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Grąžina artimiausią sveikąjį skaičių iki `f32`.
    /// Gali sukelti netikslią slankiojo kablelio išimtį, jei argumentas nėra sveikasis skaičius.
    pub fn rintf32(x: f32) -> f32;
    /// Grąžina artimiausią sveikąjį skaičių iki `f64`.
    /// Gali sukelti netikslią slankiojo kablelio išimtį, jei argumentas nėra sveikasis skaičius.
    pub fn rintf64(x: f64) -> f64;

    /// Grąžina artimiausią sveikąjį skaičių iki `f32`.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Grąžina artimiausią sveikąjį skaičių iki `f64`.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Grąžina artimiausią sveikąjį skaičių iki `f32`.Pusės kelio atvejus apvalina nuo nulio.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Grąžina artimiausią sveikąjį skaičių iki `f64`.Pusės kelio atvejus apvalina nuo nulio.
    ///
    /// Stabilizuota šios vidinės versijos versija yra
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Plūduriuojantis papildymas, leidžiantis optimizuoti remiantis algebrinėmis taisyklėmis.
    /// Gali manyti, kad įvestys yra ribotos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Plūdinė atimtis, leidžianti optimizuoti remiantis algebrinėmis taisyklėmis.
    /// Gali manyti, kad įvestys yra ribotos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Plūdinis dauginimas, leidžiantis optimizuoti remiantis algebrinėmis taisyklėmis.
    /// Gali manyti, kad įvestys yra ribotos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// " Float` padalijimas, leidžiantis optimizuoti remiantis algebrinėmis taisyklėmis.
    /// Gali manyti, kad įvestys yra ribotos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// " Float` likutis, leidžiantis optimizuoti remiantis algebrinėmis taisyklėmis.
    /// Gali manyti, kad įvestys yra ribotos.
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertuokite naudodami " LLVM` fptoui/fptosi, kuris reikšmes, esančių už diapazono ribų, gali grąžinti undef
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizuota kaip [`f32::to_int_unchecked`] ir [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Pateikia `T` tipo sveikojo skaičiaus nustatytų bitų skaičių
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `count_ones` metodą.
    /// Pavyzdžiui,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Grąžina sveikųjų skaičių `T` pirmaujančių nenustatytų bitų skaičių (zeroes).
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `leading_zeros` metodą.
    /// Pavyzdžiui,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x`, kurio vertė `0`, grąžins `T` bitų plotį.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Kaip ir `ctlz`, bet ypač nesaugus, nes jis grąžina `undef`, kai jam suteikiama `0` vertė `0`.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Gauna sveikųjų skaičių `T` galinių nenustatytų bitų skaičių (zeroes).
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `trailing_zeros` metodą.
    /// Pavyzdžiui,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x`, kurio vertė `0`, grąžins `T` bitų plotį:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Kaip ir `cttz`, bet ypač nesaugus, nes jis grąžina `undef`, kai jam suteikiama `x`, kurios vertė `0`.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Pakeičia `T` tipo sveiko skaičiaus baitus.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `swap_bytes` metodą.
    /// Pavyzdžiui,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Apversia sveiko skaičiaus `T` bitus.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `reverse_bits` metodą.
    /// Pavyzdžiui,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Atlieka patikrintą sveikojo skaičiaus pridėjimą.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `overflowing_add` metodą.
    /// Pavyzdžiui,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Atlieka patikrintą sveikojo skaičiaus atėmimą
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `overflowing_sub` metodą.
    /// Pavyzdžiui,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Atlieka patikrintą sveikojo skaičiaus dauginimą
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `overflowing_mul` metodą.
    /// Pavyzdžiui,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Atlieka tikslų dalijimąsi, todėl elgesys neapibrėžtas, kai `x % y != 0` arba `y == 0` arba `x == T::MIN && y == -1`
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Atlieka nepatikrintą dalijimąsi, todėl neapibrėžtas elgesys, kai `y == 0` arba `x == T::MIN && y == -1`
    ///
    ///
    /// Naudojant `checked_div` metodą, sveiki skaičiai primityviuose elementuose yra saugūs.
    /// Pavyzdžiui,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Pateikia likusią nepažymėto padalijimo dalį, dėl kurios `y == 0` arba `x == T::MIN && y == -1` elgesys yra neapibrėžtas
    ///
    ///
    /// Naudojant `checked_rem` metodą, sveiki skaičiai primityviuose elementuose yra saugūs.
    /// Pavyzdžiui,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Atlieka nepatikrintą kairįjį poslinkį, o tai lemia neapibrėžtą elgesį, kai `y < 0` arba `y >= N`, kur N yra T plotis bitais.
    ///
    ///
    /// Naudojant `checked_shl` metodą, sveiki skaičiai primityviuose elementuose yra saugūs.
    /// Pavyzdžiui,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Atlieka nepatikrintą dešinįjį poslinkį, o tai lemia neapibrėžtą elgesį, kai `y < 0` arba `y >= N`, kur N yra T plotis bitais.
    ///
    ///
    /// Naudojant `checked_shr` metodą, sveiki skaičiai primityviuose elementuose yra saugūs.
    /// Pavyzdžiui,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Pateikia nepatikrinto pridėjimo rezultatą, dėl kurio `x + y > T::MAX` arba `x + y < T::MIN` elgsena yra neapibrėžta.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Pateikia nepatikrinto atimties rezultatą, o tai lemia neapibrėžtą elgesį, kai `x - y > T::MAX` arba `x - y < T::MIN`.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Pateikia nepatikrinto daugybos rezultatą, dėl kurio `x *y > T::MAX` arba `x* y < T::MIN` elgsena yra neapibrėžta.
    ///
    ///
    /// Tai savaime neturi stabilaus atitikmens.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Atlieka pasukimą į kairę.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `rotate_left` metodą.
    /// Pavyzdžiui,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Atlieka pasukimą į dešinę.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `rotate_right` metodą.
    /// Pavyzdžiui,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Grąžina (a + b) mod 2 <sup>N</sup>, kur N yra T plotis bitais.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `wrapping_add` metodą.
    /// Pavyzdžiui,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Grąžina (a, b) mod 2 <sup>N</sup>, kur N yra T plotis bitais.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `wrapping_sub` metodą.
    /// Pavyzdžiui,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Grąžina (a * b) mod 2 <sup>N</sup>, kur N yra T plotis bitais.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `wrapping_mul` metodą.
    /// Pavyzdžiui,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Apskaičiuoja `a + b`, prisotinant prie skaitinių ribų.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `saturating_add` metodą.
    /// Pavyzdžiui,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Apskaičiuoja `a - b`, prisotinant prie skaitinių ribų.
    ///
    /// Stabilizuotas šio vidinio varianto versijas galima gauti sveikųjų skaičių primityvuose naudojant `saturating_sub` metodą.
    /// Pavyzdžiui,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Pateikia 'v' varianto diskriminanto vertę;
    /// jei `T` neturi diskriminanto, pateikia `0`.
    ///
    /// Stabilizuota šios vidinės versijos versija yra [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Grąžina `T` tipo variantų skaičių į `usize`;
    /// jei `T` neturi variantų, pateikia `0`.Bus skaičiuojami negyvenami variantai.
    ///
    /// Stabilizuojama šio vidinio varianto versija yra " [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// " Rust` "try catch" konstrukcija, iškviečianti funkcijos rodyklę `try_fn` su duomenų rodykle `data`.
    ///
    /// Trečiasis argumentas yra funkcija, vadinama, jei įvyksta panic.
    /// Ši funkcija perkelia duomenų žymeklį ir žymeklį į tikslinės išimties objektą, kuris buvo sugautas.
    ///
    /// Norėdami gauti daugiau informacijos, žiūrėkite kompiliatoriaus šaltinį ir " std` sugavimo įgyvendinimą.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Pagal LLVM skleidžia `!nontemporal` parduotuvę (žr. Jų dokumentus).
    /// Tikriausiai niekada netaps stabilus.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Išsamesnės informacijos ieškokite " `<*const T>::offset_from` dokumentacijoje.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Išsamesnės informacijos ieškokite " `<*const T>::guaranteed_eq` dokumentacijoje.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Išsamesnės informacijos ieškokite " `<*const T>::guaranteed_ne` dokumentacijoje.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Paskirstyti kompiliavimo metu.Negalima skambinti vykdymo metu.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Kai kurios funkcijos yra apibrėžtos čia, nes jos netyčia tapo prieinamos šiame modulyje stabiliai.
// Žr. " <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` taip pat priklauso šiai kategorijai, tačiau jo negalima apvynioti patikrinus, ar `T` ir `U` yra vienodo dydžio.)
//

/// Tikrina, ar `ptr` tinkamai sulygiuotas su `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Nukopijuoja `count *size_of::<T>()` baitus iš `src` į `dst`.Šaltinis ir paskirties vieta* neturi * sutapti.
///
/// Atminties regionams, kurie gali sutapti, naudokite [`copy`].
///
/// `copy_nonoverlapping` yra semantiškai ekvivalentiškas C [`memcpy`], tačiau argumentų tvarka keičiama.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `src` turi būti [valid], kai skaitomi `count * size_of::<T>()` baitai.
///
/// * `dst` turi būti [valid] rašant `count * size_of::<T>()` baitus.
///
/// * Tiek `src`, tiek `dst` turi būti tinkamai sulygiuoti.
///
/// * Atminties sritis, prasidedanti `src`, kurios dydis yra " count` *
///   dydis: :<T>() `baitai neturi * sutapti su atminties sritimi, prasidedančia `dst` ir to paties dydžio.
///
/// Kaip ir " [`read`], " `copy_nonoverlapping` sukuria `T` kopiją bitais, neatsižvelgiant į tai, ar " `T` yra " [`Copy`].
/// Jei `T` nėra [`Copy`], naudodami *abu*, reikšmės regione, prasidedančiame `*src`, ir regione, prasidedančiame `* dst`, gali [violate memory safety][read-ownership].
///
///
/// Atminkite, kad net jei efektyviai nukopijuotas dydis (`count * size_of: :<T>()`) yra `0`, žymekliai turi būti ne NULL ir tinkamai sulygiuoti.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Rankiniu būdu įdiegti " [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Visi `src` elementai perkeliami į `dst`, paliekant `src` tuščią.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Įsitikinkite, kad " `dst` turi pakankamai talpos visam " `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Kvietimas atskaityti visada yra saugus, nes `Vec` niekada neskirs daugiau nei `isize::MAX` baitų.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Sutrumpinkite `src` neišmesdami jo turinio.
///         // Pirmiausia tai darome, kad išvengtume problemų, jei kas nors toliau būtų žemiau panics.
///         src.set_len(0);
///
///         // Šie du regionai negali sutapti, nes kintamos nuorodos neturi slapyvardžių, o du skirtingi vektoriai negali turėti tos pačios atminties.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Praneškite " `dst`, kad dabar jame yra " `src` turinys.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Šiuos patikrinimus atlikite tik vykdymo metu
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Neišsigąskite, kad kodegenų poveikis būtų mažesnis.
        abort();
    }*/

    // SAUGA: `copy_nonoverlapping` saugos sutartis turi būti
    // palaikė skambinantysis.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Nukopijuoja `count * size_of::<T>()` baitus iš `src` į `dst`.Šaltinis ir paskirties vieta gali sutapti.
///
/// Jei šaltinis ir paskirties vieta * niekada nesutaps, vietoj jo galima naudoti " [`copy_nonoverlapping`].
///
/// `copy` yra semantiškai ekvivalentiškas C [`memmove`], tačiau argumentų tvarka keičiama.
/// Kopijavimas vyksta taip, tarsi baitai būtų nukopijuoti iš `src` į laikiną masyvą ir tada nukopijuoti iš masyvo į `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `src` turi būti [valid], kai skaitomi `count * size_of::<T>()` baitai.
///
/// * `dst` turi būti [valid] rašant `count * size_of::<T>()` baitus.
///
/// * Tiek `src`, tiek `dst` turi būti tinkamai sulygiuoti.
///
/// Kaip ir " [`read`], " `copy` sukuria `T` kopiją bitais, neatsižvelgiant į tai, ar " `T` yra " [`Copy`].
/// Jei `T` nėra [`Copy`], naudodami abi reikšmes regione, prasidedančiame `*src`, ir regione, prasidedančiame `* dst`, galite [violate memory safety][read-ownership].
///
///
/// Atminkite, kad net jei efektyviai nukopijuotas dydis (`count * size_of: :<T>()`) yra `0`, žymekliai turi būti ne NULL ir tinkamai sulygiuoti.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efektyviai sukurkite Rust vector iš nesaugaus buferio:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` turi būti teisingai sulygiuotas pagal savo tipą ir nulis.
/// /// * `ptr` turi galioti skaitant `elts` gretimus `T` tipo elementus.
/// /// * Šie elementai negali būti naudojami iškvietus šią funkciją, nebent `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAUGA: Mūsų išankstinė sąlyga užtikrina šaltinio suderinimą ir teisingumą,
///     // ir `Vec::with_capacity` užtikrina, kad turime pakankamai vietos jiems parašyti.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SAUGA: Mes sukūrėme jį su tokiu pajėgumu anksčiau,
///     // ir ankstesnė " `copy` inicializavo šiuos elementus.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Šiuos patikrinimus atlikite tik vykdymo metu
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Neišsigąskite, kad kodegenų poveikis būtų mažesnis.
        abort();
    }*/

    // SAUGA: `copy` saugos sutartį turi palaikyti skambinantysis.
    unsafe { copy(src, dst, count) }
}

/// Nustatomi atminties `count * size_of::<T>()` baitai, prasidedantys nuo `dst` iki `val`.
///
/// `write_bytes` yra panašus į C [`memset`], tačiau `count * size_of::<T>()` baitus nustato į `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Elgesys nėra apibrėžtas, jei pažeidžiama kuri nors iš šių sąlygų:
///
/// * `dst` turi būti [valid] rašant `count * size_of::<T>()` baitus.
///
/// * `dst` turi būti tinkamai išlyginti.
///
/// Be to, skambinantysis turi užtikrinti, kad užrašius `count * size_of::<T>()` baitus į nurodytą atminties sritį, gaunama galiojanti `T` reikšmė.
/// Atminties srities, įvestos kaip `T`, naudojimas, kuriame yra neteisinga `T` reikšmė, nėra apibrėžta elgsena.
///
/// Atminkite, kad net jei efektyviai nukopijuotas dydis (`count * size_of: :<T>()`) yra `0`, žymeklis turi būti ne NULL ir tinkamai sulygiuotas.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Neteisingos vertės sukūrimas:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Nutekina anksčiau turėtą vertę, perrašant " `Box<T>` su nuliniu rodikliu.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Šiuo metu naudojant ar numetant " `v`, elgesys yra neapibrėžtas.
/// // drop(v); // ERROR
///
/// // Net tai nutekina " `v` "uses" ir tai nėra apibrėžtas elgesys.
/// // mem::forget(v); // ERROR
///
/// // Tiesą sakant, `v` yra neteisingas pagal pagrindinio tipo išdėstymo invariantus, todėl *bet kuri* operacija, palietusi jį, yra neapibrėžtas elgesys.
/////
/// // tegul v2 =v;//KLAIDA
///
/// unsafe {
///     // Vietoj to nurodykime galiojančią vertę
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Dabar dėžutė yra gerai
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAUGA: `write_bytes` saugos sutartį turi palaikyti skambinantysis.
    unsafe { write_bytes(dst, val, count) }
}