#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Komunalinės paslaugos, susijusios su svetimų funkcijų sąsaja (FFI).

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Atitinka C `void` tipą, kai naudojamas kaip [pointer].
///
/// Iš esmės `*const c_void` yra lygiavertis C `const void*`, o `*mut c_void`-C `void*`.
/// Tai reiškia, kad tai *ne* tas pats, kas C `void` grąžinimo tipas, kuris yra Rust `()` tipas.
///
/// Norėdami modeliuoti neskaidrių tipų rodiklius FFI, kol `extern type` stabilizuosis, rekomenduojama naudoti newtype apvalkalą aplink tuščią baitų masyvą.
///
/// Išsamesnės informacijos ieškokite " [Nomicon].
///
/// Galima naudoti " `std::os::raw::c_void`, jei jie nori palaikyti seną " Rust` kompiliatorių iki 1.1.0.
/// Po " Rust 1.30.0 jis buvo reeksportuotas pagal šį apibrėžimą.
/// Norėdami gauti daugiau informacijos, skaitykite [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, kad LLVM atpažintų tuštumos žymeklio tipą ir pagal išplėtimo funkcijas, tokias kaip malloc(), LLVM bitų kode turime turėti ją kaip i8 *.
// Čia naudojamas " enum`tai užtikrina ir neleidžia netinkamai naudoti " "raw" tipą, turint tik privačius variantus.
// Mums reikia dviejų variantų, nes kitaip kompiliatorius skundžiasi atributu " repr`ir mums reikia bent vieno varianto, nes priešingu atveju " enum` būtų negyvenamas ir bent jau tokių nuorodų darymas būtų UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Pagrindinis " `va_list` diegimas.
// Pavadinimas yra WIP, kol kas naudojamas `VaListImpl`.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Variantas per `'f`, todėl kiekvienas `VaListImpl<'f>` objektas yra susietas su funkcijos, kurioje ji apibrėžta, sritimi
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 " XI `va_list`` ABI diegimas.
/// Norėdami gauti daugiau informacijos, žiūrėkite " [AArch64 Procedure Call Standard].
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC " XI `va_list`` ABI diegimas.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 " XI `va_list`` ABI diegimas.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// " `va_list` apvalkalas
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertuokite `VaListImpl` į `VaList`, kuris yra dvejetainis suderinamas su C `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Konvertuokite `VaListImpl` į `VaList`, kuris yra dvejetainis suderinamas su C `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// " VaArgSafe trait`reikia naudoti viešosiose sąsajose, tačiau negalima leisti, kad pats " trait` būtų naudojamas už šio modulio ribų.
// Leidimas vartotojams įdiegti " trait`naujam tipui (tokiu būdu leidžiant vidinį " va_arg` naudoti naujam tipui) gali sukelti neapibrėžtą elgesį.
//
// FIXME(dlrobertson): Norint " VaArgSafe trait`naudoti viešojoje sąsajoje, bet taip pat užtikrinti, kad jo negalima naudoti kitur, " trait` turi būti viešas privačiame modulyje.
// Įdiegus " RFC 2145`, reikia tai patobulinti.
//
//
//
//
mod sealed_trait {
    /// Trait, leidžiantis naudoti leistinus tipus su [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Pereiti prie kito argumento.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SAUGUMAS: skambinantysis turi laikytis `va_arg` saugos sutarties.
        unsafe { va_arg(self) }
    }

    /// Nukopijuoja " `va_list` dabartinėje vietoje.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SAUGUMAS: skambinantysis privalo laikytis " `va_end` saugos sutarties.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SAUGUMAS: rašome į `MaybeUninit`, taigi jis yra inicializuotas, o `assume_init` yra teisėtas
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: tai turėtų skambinti " `va_end`, tačiau nėra jokio švaraus būdo
        // garantuokite, kad " `drop` visada bus įtrauktas į skambintoją, todėl " `va_end` bus tiesiogiai iškviestas iš tos pačios funkcijos kaip ir atitinkamas " `va_copy`.
        // `man va_end` teigia, kad C to reikalauja, o LLVM iš esmės vadovaujasi C semantika, todėl turime įsitikinti, kad `va_end` visada iškviečiama iš tos pačios funkcijos kaip ir `va_copy`.
        //
        // Daugiau detalių, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Tai kol kas veikia, nes " `va_end` neveikia visų dabartinių LLVM taikinių.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Sunaikinkite arlistą `ap` po inicijavimo naudojant `va_start` arba `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Nukopijuoja dabartinę arglisto `src` vietą į arglistą `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Įkelia `T` tipo argumentą iš `va_list` `ap` ir padidina argumentą, į kurį nurodo `ap`.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}