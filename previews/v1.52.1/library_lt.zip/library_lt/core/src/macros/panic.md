Panics dabartinė gija.

Tai leidžia programą nedelsiant nutraukti ir pateikti atsiliepimą programos skambinančiajam.
`panic!` turėtų būti naudojamas, kai programa pasiekia neatkuriamą būseną.

Ši makrokomanda yra puikus būdas patvirtinti sąlygas kodo pavyzdyje ir bandymuose.
`panic!` yra glaudžiai susijęs su `unwrap` ir [`Result`][runwrap] sąrašų `unwrap` metodu.
Abi realizacijos iškviečia `panic!`, kai joms nustatomi [`None`] arba [`Err`] variantai.

Naudodami " `panic!()` galite nurodyti eilutės naudingąją apkrovą, sukurtą naudojant [`format!`] sintaksę.
Ta naudingoji apkrova naudojama įpurškiant " panic`į skambinantį " Rust` siūlą, todėl siūlas tampa visiškai " panic`.

Numatytojo " `std` hook` elgesys, t
kodas, paleidžiamas iškart po to, kai iškviečiama " panic`, turi išspausdinti pranešimo naudingąją apkrovą į `stderr` kartu su `panic!()` skambučio informacija file/line/column.

Galite nepaisyti panic hook naudodami [`std::panic::set_hook()`].
" hook`viduje galima pasiekti " panic` kaip " `&dyn Any + Send`, kuriame yra " `&str` arba " `String`, skirtas įprastoms " `panic!()` iškvietoms.
panic, kurio vertė yra kito tipo, galima naudoti [`panic_any`].

[`Result`] " enum`dažnai yra geresnis sprendimas norint atkurti klaidas nei naudojant " `panic!` makrokomandą.
Ši makrokomanda turėtų būti naudojama norint išvengti neteisingų verčių, pvz., Iš išorinių šaltinių, naudojimo.
Išsami informacija apie klaidų tvarkymą yra [book].

Taip pat žiūrėkite makrokomandą [`compile_error!`], kurioje pateikiamos klaidos kompiliavimo metu.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Dabartinis įgyvendinimas

Jei pagrindinis " panics` siūlas nutrauks visas jūsų gijas ir užbaigs jūsų programą kodu `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





