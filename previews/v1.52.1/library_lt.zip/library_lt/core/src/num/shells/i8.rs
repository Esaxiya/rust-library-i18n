//! 8 bitų pasirašyto sveikojo skaičiaus tipo konstantos.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! Naujas kodas turėtų naudoti susijusias konstantas tiesiai į primityvų tipą.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }