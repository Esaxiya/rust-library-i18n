//! Žymeklio dydžio pasirašyto sveikojo skaičiaus tipo konstantos.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Naujas kodas turėtų naudoti susijusias konstantas tiesiai į primityvų tipą.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }