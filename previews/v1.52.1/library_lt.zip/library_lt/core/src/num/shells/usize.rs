//! Žymeklio dydžio nepasirašyto sveikojo skaičiaus tipo konstantos.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Naujas kodas turėtų naudoti susijusias konstantas tiesiai į primityvų tipą.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }