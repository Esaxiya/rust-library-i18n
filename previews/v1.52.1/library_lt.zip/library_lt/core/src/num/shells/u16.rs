//! Pastovi 16 bitų nepasirašyto sveikojo skaičiaus tipas.
//!
//! *[See also the `u16` primitive type][u16].*
//!
//! Naujas kodas turėtų naudoti susijusias konstantas tiesiai į primityvų tipą.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u16`"
)]

int_module! { u16 }