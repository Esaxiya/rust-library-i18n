macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Mažiausia reikšmė, kurią galima pateikti naudojant šį sveiko skaičiaus tipą.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Didžiausia reikšmė, kurią gali pateikti šis sveiko skaičiaus tipas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Šio sveiko skaičiaus tipo dydis bitais.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konvertuoja eilutės pjūvį tam tikroje bazėje į sveiką skaičių.
        ///
        /// Tikimasi, kad eilutė bus pasirinktinis `+` ženklas, po kurio bus skaitmenys.
        ///
        /// Pirmaujanti ir galinė tarpai reiškia klaidą.
        /// Skaičiai yra šių simbolių pogrupis, atsižvelgiant į `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ši funkcija panics, jei `radix` nėra diapazone nuo 2 iki 36.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Pateikia vienetų skaičių dvejetainiame `self` vaizde.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Grąžina nulių skaičių dvejetainiu `self` vaizdu.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Pateikia pirmaujančių nulių skaičių dvejetainiame `self` vaizde.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Pateikia galinių nulių skaičių dvejetainiu `self` vaizdu.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Pateikia pirmaujančių skaičių dvejetainiame `self` vaizde.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Pateikia galinių skaičių dvejetainiame `self` vaizde.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Perkelia bitus į kairę nurodytu dydžiu, `n`, sutrumpintus bitus apvyniodamas gauto sveiko skaičiaus galu.
        ///
        ///
        /// Atkreipkite dėmesį, kad tai nėra tas pats veiksmas kaip " `<<` perjungimo operatoriui!
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Perkelia bitus į dešinę nurodytu dydžiu, `n`, sutrumpintus bitus apgaubdami gauto sveiko skaičiaus pradžia.
        ///
        ///
        /// Atkreipkite dėmesį, kad tai nėra tas pats veiksmas kaip " `>>` perjungimo operatoriui!
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Pakeičia sveiko skaičiaus baitų tvarką.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tegul m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Pakeičia skaičių skaičiaus bitų eiliškumą.
        /// Mažiausiai reikšmingas bitas tampa reikšmingiausiu, antras mažiausiai reikšmingas bitas tampa antru reikšmingiausiu ir kt.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// tegul m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konvertuoja sveiko skaičiaus iš didžiosios galūnės į taikinio endianumą.
        ///
        /// Didžiuoju galu tai yra draudimas.
        /// Mažame endiane baitai keičiami.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jei cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } Kitas {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konvertuoja sveiko skaičiaus iš mažojo endiano į taikinio endianumą.
        ///
        /// Dėl mažo endiano tai yra draudimas.
        /// Didžiuoju galu baitai keičiami.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jei cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } Kitas {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` paverčia dideliu endianu iš taikinio endianumo.
        ///
        /// Didžiuoju galu tai yra draudimas.
        /// Mažame endiane baitai keičiami.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jei cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } dar { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ar nebūti?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` paverčia mažu endianu iš taikinio endianumo.
        ///
        /// Dėl mažo endiano tai yra draudimas.
        /// Didžiuoju galu baitai keičiami.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// jei cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } dar { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Patikrintas sveiko skaičiaus papildymas.
        /// Apskaičiuoja `self + rhs`, grąžindamas `None`, jei įvyko perpildymas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepatikrintas sveiko skaičiaus pridėjimas.Apskaičiuoja `self + rhs`, darant prielaidą, kad perpildymas negali įvykti.
        /// Tai lemia neapibrėžtą elgesį, kai
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SAUGUMAS: skambinantysis privalo laikytis " `unchecked_add` saugos sutarties.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Patikrinta sveikojo skaičiaus atimtis.
        /// Apskaičiuoja `self - rhs`, grąžindamas `None`, jei įvyko perpildymas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepažymėtas sveiko skaičiaus atimimas.Apskaičiuoja `self - rhs`, darant prielaidą, kad perpildymas negali įvykti.
        /// Tai lemia neapibrėžtą elgesį, kai
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SAUGUMAS: skambinantysis privalo laikytis " `unchecked_sub` saugos sutarties.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Patikrintas sveiko skaičiaus dauginimas.
        /// Apskaičiuoja `self * rhs`, grąžindamas `None`, jei įvyko perpildymas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepažymėtas sveiko skaičiaus dauginimas.Apskaičiuoja `self * rhs`, darant prielaidą, kad perpildymas negali įvykti.
        /// Tai lemia neapibrėžtą elgesį, kai
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SAUGUMAS: skambinantysis privalo laikytis " `unchecked_mul` saugos sutarties.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Patikrintas sveikojo skaičiaus padalijimas.
        /// Skaičiuoja `self / rhs`, grąžindamas `None`, jei `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAUGUMAS: aukščiau buvo pažymėta dalyba iš nulio, o nepasirašytieji tipai neturi kito
                // gedimo režimai dalijimui
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Patikrino Euklido padalijimą.
        /// Skaičiuoja `self.div_euclid(rhs)`, grąžindamas `None`, jei `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Patikrinta likusi sveikojo skaičiaus dalis.
        /// Skaičiuoja `self % rhs`, grąžindamas `None`, jei `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SAUGUMAS: aukščiau buvo pažymėta dalyba iš nulio, o nepasirašytieji tipai neturi kito
                // gedimo režimai dalijimui
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Patikrintas Euklido modulis.
        /// Skaičiuoja `self.rem_euclid(rhs)`, grąžindamas `None`, jei `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Patikrinta neigimas.Apskaičiuoja `-self`, grąžinant `None`, nebent `self==
        /// 0`.
        ///
        /// Atminkite, kad neigiant bet kokį teigiamą sveikąjį skaičių bus perpildyta.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Patikrinta pamaina kairėn.
        /// Apskaičiuoja `self << rhs`, grąžindamas `None`, jei `rhs` yra didesnis arba lygus `self` bitų skaičiui.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Patikrinta poslinkis į dešinę.
        /// Apskaičiuoja `self >> rhs`, grąžindamas `None`, jei `rhs` yra didesnis arba lygus `self` bitų skaičiui.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Patikrintas eksponavimas.
        /// Apskaičiuoja `self.pow(exp)`, grąžindamas `None`, jei įvyko perpildymas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // kadangi exp!=0, galiausiai exp turi būti 1.
            // Galutinį eksponento bitą spręskite atskirai, nes pagrindo kvadratas vėliau nėra būtinas ir gali sukelti nereikalingą perpildymą.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Sotinamasis sveikasis skaičius.
        /// Skaičiuoja `self + rhs`, prisotindamas skaitmenines ribas, o ne perpildydamas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Sotinamasis sveikojo skaičiaus atimimas.
        /// Skaičiuoja `self - rhs`, prisotindamas skaitmenines ribas, o ne perpildydamas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Sotinamasis sveikojo skaičiaus dauginimas.
        /// Skaičiuoja `self * rhs`, prisotindamas skaitmenines ribas, o ne perpildydamas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Sotinamasis sveikasis skaičius.
        /// Skaičiuoja `self.pow(exp)`, prisotindamas skaitmenines ribas, o ne perpildydamas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) papildymas.
        /// Apskaičiuoja `self + rhs`, apjuosdamas tipo ribą.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) atimties apvyniojimas.
        /// Apskaičiuoja `self - rhs`, apjuosdamas tipo ribą.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) daugybos suvyniojimas.
        /// Apskaičiuoja `self * rhs`, apjuosdamas tipo ribą.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// Atminkite, kad šis pavyzdys yra bendrų skaičių skaičius.
        /// Tai paaiškina, kodėl čia naudojamas " `u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Apvyniojimas (modular) padalijimas.Skaičiuoja `self / rhs`.
        /// Apvyniotas dalijimasis be pasirašytų tipų yra tik įprastas dalijimas.
        /// Jokiu būdu neįvyniojimas niekada negalėtų įvykti.
        /// Ši funkcija egzistuoja, todėl visos operacijos yra apskaitomos vyniojimo operacijose.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Euklido padalijimas.Skaičiuoja `self.div_euclid(rhs)`.
        /// Apvyniotas dalijimasis be pasirašytų tipų yra tik įprastas dalijimas.
        /// Jokiu būdu neįvyniojimas niekada negalėtų įvykti.
        /// Ši funkcija egzistuoja, todėl visos operacijos yra apskaitomos vyniojimo operacijose.
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, tai lygu `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) likutis.Skaičiuoja `self % rhs`.
        /// Apskaitytas likęs neparašytų tipų skaičiavimas yra tik įprastas likęs skaičiavimas.
        ///
        /// Jokiu būdu neįvyniojimas niekada negalėtų įvykti.
        /// Ši funkcija egzistuoja, todėl visos operacijos yra apskaitomos vyniojimo operacijose.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Euklido modulio apvyniojimas.Skaičiuoja `self.rem_euclid(rhs)`.
        /// Apvyniotas modulio skaičiavimas nepasirašytiems tipams yra tik įprastas likęs skaičiavimas.
        /// Jokiu būdu neįvyniojimas niekada negalėtų įvykti.
        /// Ši funkcija egzistuoja, todėl visos operacijos yra apskaitomos vyniojimo operacijose.
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, tai lygu `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) neigimo įvyniojimas.
        /// Apskaičiuoja `-self`, apjuosdamas tipo ribą.
        ///
        /// Kadangi nepasirašyti tipai neturi neigiamų ekvivalentų, visos šios funkcijos programos bus apvyniotos (išskyrus `-0`).
        /// Vertėms, kurios yra mažesnės už didžiausią atitinkamo pasirašyto tipo maksimalų rezultatą, rezultatas yra tas pats, kas perduoti atitinkamą pasirašytą vertę.
        ///
        /// Bet kurios didesnės vertės yra lygiavertės `MAX + 1 - (val - MAX - 1)`, kur `MAX` yra atitinkamo pasirašyto tipo maksimumas.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// Atminkite, kad šis pavyzdys yra bendrų skaičių skaičius.
        /// Tai paaiškina, kodėl čia naudojamas " `i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// " Panic` be paleidimo kairėn;
        /// gaunamas `self << mask(rhs)`, kur `mask` pašalina visus aukštos eilės `rhs` bitus, dėl kurių poslinkis viršys tipo bitų plotį.
        ///
        /// Atkreipkite dėmesį, kad tai *nėra* tas pats, kas pasukti į kairę;apvyniojimo kairės pusės RHS apsiriboja tipo diapazonu, o ne iš LHS pasislinkę bitai grąžinami į kitą galą.
        /// Visi primityvieji sveikųjų skaičių tipai įgyvendina [`rotate_left`](Self::rotate_left) funkciją, kurios galbūt norėsite.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SAUGUMAS: užmaskavimas pagal bitų dydį užtikrina, kad mes nepasislinktume
            // už ribų
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// " Panic` be paleidimo dešinėn;
        /// gaunamas `self >> mask(rhs)`, kur `mask` pašalina visus aukštos eilės `rhs` bitus, dėl kurių poslinkis viršys tipo bitų plotį.
        ///
        /// Atkreipkite dėmesį, kad tai *nėra* tas pats, kas pasukti į dešinę;apvyniojimo dešinės pusės RHS apsiriboja tipo diapazonu, o ne iš LHS pasislinkę bitai grąžinami į kitą galą.
        /// Visi primityvieji sveikųjų skaičių tipai įgyvendina [`rotate_right`](Self::rotate_right) funkciją, kurios galbūt norėsite.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SAUGUMAS: užmaskavimas pagal bitų dydį užtikrina, kad mes nepasislinktume
            // už ribų
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) eksponavimo suvyniojimas.
        /// Apskaičiuoja `self.pow(exp)`, apjuosdamas tipo ribą.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // kadangi exp!=0, galiausiai exp turi būti 1.
            // Galutinį eksponento bitą spręskite atskirai, nes pagrindo kvadratas vėliau nėra būtinas ir gali sukelti nereikalingą perpildymą.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Apskaičiuoja `self` + `rhs`
        ///
        /// Pateikia pridėjimo porą kartu su logine reikšme, nurodant, ar atsiras aritmetinis perpildymas.
        /// Jei būtų įvykęs perpildymas, sugrąžinta vertė bus grąžinta.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Skaičiuoja `self`, `rhs`
        ///
        /// Pateikia atimties porą kartu su logine reikšme, nurodant, ar atsiras aritmetinis perpildymas.
        /// Jei būtų įvykęs perpildymas, sugrąžinta vertė bus grąžinta.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Apskaičiuoja `self` ir `rhs` dauginimą.
        ///
        /// Pateikia daugybos kartotinį kartu su logine reikšme, nurodant, ar atsiras aritmetinis perpildymas.
        /// Jei būtų įvykęs perpildymas, sugrąžinta vertė bus grąžinta.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// Atminkite, kad šis pavyzdys yra bendrų skaičių skaičius.
        /// Tai paaiškina, kodėl čia naudojamas " `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Skaičiuoja daliklį, kai `self` padalijamas iš `rhs`.
        ///
        /// Pateikia daliklio paketą kartu su logine reikšme, nurodant, ar atsiras aritmetinis perpildymas.
        /// Atkreipkite dėmesį, kad nepasirašytų sveikųjų skaičių perpildymas niekada nevyksta, todėl antroji vertė visada yra `false`.
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Apskaičiuoja Euklido dalybos `self.div_euclid(rhs)` koeficientą.
        ///
        /// Pateikia daliklio paketą kartu su logine reikšme, nurodant, ar atsiras aritmetinis perpildymas.
        /// Atkreipkite dėmesį, kad nepasirašytų sveikųjų skaičių perpildymas niekada nevyksta, todėl antroji vertė visada yra `false`.
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, tai lygu `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Skaičiuoja likutį, kai `self` padalijamas iš `rhs`.
        ///
        /// Pateikia likutinės dalies po padalijimo kartu su logine reikšme, nurodantį, ar atsiras aritmetinis perpildymas.
        /// Atkreipkite dėmesį, kad nepasirašytų sveikųjų skaičių perpildymas niekada nevyksta, todėl antroji vertė visada yra `false`.
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Apskaičiuoja likusią `self.rem_euclid(rhs)` dalį lyg pagal Euklido padalijimą.
        ///
        /// Pateikęs modulo porą, padalijęs kartu su logine reikšme, nurodydamas, ar atsiras aritmetinis perpildymas.
        /// Atkreipkite dėmesį, kad nepasirašytų sveikųjų skaičių perpildymas niekada nevyksta, todėl antroji vertė visada yra `false`.
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, ši operacija yra tiksliai lygi `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Diskutuoja apie save perpildytu būdu.
        ///
        /// Grąžina `!self + 1` naudodamas įvyniojimo operacijas, kad grąžintų vertę, kuri reiškia šios nepasirašytos vertės paneigimą.
        /// Atkreipkite dėmesį, kad teigiamoms nepasirašytoms reikšmėms visada įvyksta perpildymas, tačiau neigiant 0 neperpildoma.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Persijungia iš savęs palikus `rhs` bitų.
        ///
        /// Grąžina perkeltos savęs versijos porą kartu su logine reikšme, nurodant, ar poslinkio vertė buvo didesnė ar lygi bitų skaičiui.
        /// Jei poslinkio vertė yra per didelė, tada vertė užmaskuojama (N-1), kur N yra bitų skaičius, ir tada ši vertė naudojama perėjimui atlikti.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// " `rhs` bitais persijungia į dešinę.
        ///
        /// Grąžina perkeltos savęs versijos porą kartu su logine reikšme, nurodant, ar poslinkio vertė buvo didesnė ar lygi bitų skaičiui.
        /// Jei poslinkio vertė yra per didelė, tada vertė užmaskuojama (N-1), kur N yra bitų skaičius, ir tada ši vertė naudojama perėjimui atlikti.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Naudodamas eksponentą kvadratu, padidina save iki `exp` galios.
        ///
        /// Pateikia eksponavimo porą kartu su bool, nurodydamas, ar įvyko perpildymas.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (Tiesa, 217));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Nubraižyta erdvė overflowing_mul rezultatams saugoti.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // kadangi exp!=0, galiausiai exp turi būti 1.
            // Galutinį eksponento bitą spręskite atskirai, nes pagrindo kvadratas vėliau nėra būtinas ir gali sukelti nereikalingą perpildymą.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Naudodamas eksponentą kvadratu, padidina save iki `exp` galios.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // kadangi exp!=0, galiausiai exp turi būti 1.
            // Galutinį eksponento bitą spręskite atskirai, nes pagrindo kvadratas vėliau nėra būtinas ir gali sukelti nereikalingą perpildymą.
            //
            //
            acc * base
        }

        /// Atlieka Euklido padalijimą.
        ///
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, tai lygu `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Apskaičiuoja mažiausią `self (mod rhs)` likutį.
        ///
        /// Kadangi teigiamų sveikųjų skaičių atveju visi bendrieji dalijimo apibrėžimai yra vienodi, tai lygu `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ši funkcija bus panic, jei `rhs` yra 0.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Pateikia `true` tik tada, jei `self == 2^k` kai kuriems `k`.
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Grąžina vienu mažiau nei kitą dviejų galingumą.
        // (8u8 atveju dviejų galia yra 8u8, o 6u8-8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Šis metodas negali būti perpildytas, nes `next_power_of_two` perpildymo atvejais galų gale jis grąžina maksimalią tipo vertę ir 0 gali grąžinti 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SAUGA: Kadangi " `p > 0`, jis negali susidaryti vien iš pagrindinių nulių.
            // Tai reiškia, kad poslinkis visada yra ribotas, o kai kurie procesoriai (pvz., " Intel pre-haswell`) turi efektyvesnes ctlz savybes, kai argumentas nėra nulis.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Pateikia mažiausią dviejų galingumą, didesnį už `self` arba lygų jam.
        ///
        /// Kai grąžinimo vertė perpildyta (ty `self > (1 << (N-1))` `uN` tipui), ji panics derinimo režimu, o grąžinimo vertė yra apvyniota iki 0, kai išleidimo režimas (vienintelė situacija, kai metodas gali grąžinti 0).
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Pateikia mažiausią dviejų galingumą, didesnį už `n` arba lygų jam.
        /// Jei kita dviejų galia yra didesnė už didžiausią tipo vertę, grąžinama `None`, priešingu atveju dviejų galia suvyniojama į `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Pateikia mažiausią dviejų galingumą, didesnį už `n` arba lygų jam.
        /// Jei kita dviejų galia yra didesnė už didžiausią tipo vertę, grąžinimo reikšmė įtraukiama į `0`.
        ///
        ///
        /// # Examples
        ///
        /// Pagrindinis naudojimas:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Grąžinkite šio sveiko skaičiaus atminties vaizdą kaip baitų masyvą didžiųjų (network) baitų tvarka.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Grąžinkite šio sveiko skaičiaus atminties vaizdą kaip baitų masyvą mažų galų baitų tvarka.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Grąžinkite šio sveiko skaičiaus atminties vaizdą kaip baitų masyvą gimtųjų baitų tvarka.
        ///
        /// Kadangi naudojamas tikslinės platformos gimtoji savybė, nešiojamasis kodas turėtų naudoti [`to_be_bytes`] arba [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     baitai, jei cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } Kitas {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAUGA: const garsas, nes sveiki skaičiai yra paprasti seni duomenų tipai, todėl mes visada galime
        // paversti juos baitų masyvais
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SAUGUMAS: sveiki skaičiai yra paprasti seni duomenų tipai, todėl mes visada galime juos pakeisti
            // baitų masyvai
            unsafe { mem::transmute(self) }
        }

        /// Grąžinkite šio sveiko skaičiaus atminties vaizdą kaip baitų masyvą gimtųjų baitų tvarka.
        ///
        ///
        /// [`to_ne_bytes`] turėtų būti teikiama pirmenybė, o ne.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// tegul baitai= num.as_ne_bytes();
        /// assert_eq!(
        ///     baitai, jei cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } Kitas {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SAUGUMAS: sveiki skaičiai yra paprasti seni duomenų tipai, todėl mes visada galime juos pakeisti
            // baitų masyvai
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Sukurkite savojo sveikojo sveiko skaičiaus reikšmę iš jos pateikimo kaip baito masyvą didžiajame endiane.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// naudoti std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * įvestis=poilsis;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Sukurkite gimtojo sveikojo skaičiaus vertę iš jos pateikimo kaip baitų masyvą mažame endiane.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// naudoti std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * įvestis=poilsis;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Sukurkite gimtojo endiano sveiko skaičiaus vertę iš jos atminties reprezentacijos kaip baitų masyvą gimtojoje endianse.
        ///
        /// Kadangi naudojamas tikslinės platformos gimtoji savybė, nešiojamasis kodas greičiausiai nori naudoti [`from_be_bytes`] arba [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } Kitas {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// naudoti std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * įvestis=poilsis;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SAUGA: const garsas, nes sveiki skaičiai yra paprasti seni duomenų tipai, todėl mes visada galime
        // perduoti jiems
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SAUGUMAS: sveiki skaičiai yra paprasti seni duomenų tipai, todėl mes visada galime juos pakeisti
            unsafe { mem::transmute(bytes) }
        }

        /// Naujas kodas turėtų būti naudingas
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Pateikia mažiausią vertę, kurią galima pateikti naudojant šį sveiko skaičiaus tipą.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Naujas kodas turėtų būti naudingas
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Pateikia didžiausią vertę, kurią galima pateikti naudojant šį sveiko skaičiaus tipą.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}