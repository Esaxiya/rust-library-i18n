//! `f64` dvigubo tikslumo slankiojo kablelio tipui būdingos konstantos.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! Matematiškai reikšmingi skaičiai pateikti `consts` submodule.
//!
//! Konstantoms, tiesiogiai apibrėžtoms šiame modulyje (skiriasi nuo tų, kurios apibrėžtos `consts` submodule), naujame kode turėtų būti naudojamos susietos konstantos, apibrėžtos tiesiogiai tipui `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` vidinio atvaizdavimo radiksas arba pagrindas.
/// Vietoj to naudokite " [`f64::RADIX`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // numatytu būdu
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// Reikšmingų skaitmenų skaičius 2 bazėje.
/// Vietoj to naudokite " [`f64::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // numatytu būdu
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// Apytikslis reikšmingų skaitmenų skaičius bazėje 10.
/// Vietoj to naudokite " [`f64::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // numatytu būdu
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` vertė.
/// Vietoj to naudokite " [`f64::EPSILON`].
///
/// Tai skirtumas tarp `1.0` ir kito didesnio atvaizduojamo skaičiaus.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // numatytu būdu
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// Mažiausia baigtinė `f64` reikšmė.
/// Vietoj to naudokite " [`f64::MIN`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // numatytu būdu
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// Mažiausia teigiama normali `f64` reikšmė.
/// Vietoj to naudokite " [`f64::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // numatytu būdu
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// Didžiausia baigtinė `f64` vertė.
/// Vietoj to naudokite " [`f64::MAX`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // numatytu būdu
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// Viena didesnė už mažiausią galimą 2 rodiklio normalią galią.
/// Vietoj to naudokite " [`f64::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // numatytu būdu
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// Didžiausia galima eksponento galia.
/// Vietoj to naudokite " [`f64::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // numatytu būdu
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// Mažiausias galimas 10 eksponento galingumas.
/// Vietoj to naudokite " [`f64::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // numatytu būdu
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// Didžiausia galima eksponento galia.
/// Vietoj to naudokite " [`f64::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // numatytu būdu
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// Ne numeris (NaN).
/// Vietoj to naudokite " [`f64::NAN`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // numatytu būdu
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// " Infinity (∞).
/// Vietoj to naudokite " [`f64::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // numatytu būdu
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// Neigiama begalybė (−∞).
/// Vietoj to naudokite " [`f64::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // nebenaudojamas būdas
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // numatytu būdu
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// Pagrindinės matematinės konstantos.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: pakeisti matematinėmis konstantomis iš cmath.

    /// Archimedo pastovioji (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// Viso apskritimo konstanta (τ)
    ///
    /// Lygus 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// Eulerio numeris (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` vidinio atvaizdavimo radiksas arba pagrindas.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Reikšmingų skaitmenų skaičius 2 bazėje.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// Apytikslis reikšmingų skaitmenų skaičius bazėje 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` vertė.
    ///
    /// Tai skirtumas tarp `1.0` ir kito didesnio atvaizduojamo skaičiaus.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// Mažiausia baigtinė `f64` reikšmė.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// Mažiausia teigiama normali `f64` reikšmė.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// Didžiausia baigtinė `f64` vertė.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// Viena didesnė už mažiausią galimą 2 rodiklio normalią galią.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// Didžiausia galima eksponento galia.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// Mažiausias galimas 10 eksponento galingumas.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// Didžiausia galima eksponento galia.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// Ne numeris (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// " Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// Neigiama begalybė (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// Pateikia `true`, jei ši vertė yra `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): " `abs` viešai nepasiekiama " libcore`, nes kyla abejonių dėl perkeliamumo, todėl šis diegimas yra skirtas asmeniniam naudojimui viduje.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// Pateikia `true`, jei ši reikšmė yra teigiama begalybė arba neigiama begalybė, o kitu atveju-`false`.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Pateikia `true`, jei šis skaičius nėra nei begalinis, nei `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN nereikia tvarkyti atskirai: jei aš pats esu NaN, palyginimas nėra teisingas, tiksliai taip, kaip norima.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Pateikia `true`, jei skaičius yra [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // Vertės tarp `0` ir `min` yra nenormalios.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Pateikia `true`, jei skaičius nėra nulis, begalinis, [subnormal] arba `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // Vertės tarp `0` ir `min` yra nenormalios.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Grąžina skaičiaus slankiojo kablelio kategoriją.
    /// Jei ketinama išbandyti tik vieną ypatybę, vietoj to greičiau naudoti konkretų predikatą.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Pateikia `true`, jei `self` turi teigiamą ženklą, įskaitant `+0.0`, " NaN` su teigiamo ženklo bitu ir teigiamą begalybę.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// Pateikia `true`, jei `self` turi neigiamą ženklą, įskaitant `-0.0`, " NaN` su neigiamo ženklo bitu ir neigiamą begalybę.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// Ima abipusį skaičių (inverse), `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// Konvertuoja radianus į laipsnius.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // Čia padalijimas yra teisingai suapvalintas, atsižvelgiant į tikrąją 180/π vertę.
        // (Tai skiriasi nuo f32, kur teisingai suapvalintam rezultatui užtikrinti reikia naudoti konstantą.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// Konvertuoja laipsnius į radianus.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// Pateikia maksimalų skaičių iš dviejų skaičių.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Jei vienas iš argumentų yra NaN, tada kitas argumentas grąžinamas.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// Grąžina mažiausią skaičių iš dviejų skaičių.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Jei vienas iš argumentų yra NaN, tada kitas argumentas grąžinamas.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// Apskritimas nulio link ir konvertuojamas į bet kokį primityvų sveikojo skaičiaus tipą, darant prielaidą, kad reikšmė yra baigtinė ir tinka tam tipui.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Vertė turi:
    ///
    /// * Nebūk `NaN`
    /// * Nebūk begalinis
    /// * Būkite atvaizduojamas grįžtamuoju `Int` tipu, nukirpus jo dalinę dalį
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SAUGUMAS: skambinantysis privalo laikytis " `FloatToInt::to_int_unchecked` saugos sutarties.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Neapdorotas transmutavimas į `u64`.
    ///
    /// Šiuo metu tai yra identiška " `transmute::<f64, u64>(self)` visose platformose.
    ///
    /// Norėdami sužinoti apie šios operacijos perkeliamumą, žr. `from_bits` (beveik nėra problemų).
    ///
    /// Atminkite, kad ši funkcija skiriasi nuo " `as` perdavimo, kai bandoma išsaugoti *skaitmeninę*, o ne bitų reikšmę.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() nėra liejimas!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // SAUGUMAS: `u64` yra paprastas senas duomenų tipas, todėl mes visada galime jį pakeisti
        unsafe { mem::transmute(self) }
    }

    /// Neapdorotas transmutavimas iš `u64`.
    ///
    /// Šiuo metu tai yra identiška " `transmute::<u64, f64>(v)` visose platformose.
    /// Pasirodo, tai yra neįtikėtinai nešiojama dėl dviejų priežasčių:
    ///
    /// * Plūdės ir skruzdės turi vienodą savybę visose palaikomose platformose.
    /// * IEEE-754 labai tiksliai nurodo plūdžių bitų išdėstymą.
    ///
    /// Tačiau yra vienas įspėjimas: iki 2008 m. IEEE-754 versijos iš tikrųjų nebuvo nurodyta, kaip interpretuoti NaN signalizacijos bitą.
    /// Dauguma platformų (ypač " x86 ir " ARM`) pasirinko aiškinimą, kuris galiausiai buvo standartizuotas 2008 m., Tačiau kai kurie to nepadarė (ypač MIPS).
    /// Todėl visi signalizuojantys NaN MIPS yra tylūs NaNs x86 ir atvirkščiai.
    ///
    /// Užuot bandžius išsaugoti signalizavimo tarpplatformį, šis diegimas palaiko tikslių bitų išsaugojimą.
    /// Tai reiškia, kad visos NaN užkoduotos naudingos apkrovos bus išsaugotos, net jei šio metodo rezultatas bus siunčiamas per tinklą iš " x86 mašinos į " MIPS.
    ///
    ///
    /// Jei šio metodo rezultatais manipuliuoja tik ta pati architektūra, kuri juos sukūrė, perkeliamumo nėra.
    ///
    /// Jei įvestis nėra NaN, perkėlimo problemų nėra.
    ///
    /// Jei jums nerūpi signalizavimas (labai tikėtina), tai nėra perkeliamumo rūpesčio.
    ///
    /// Atminkite, kad ši funkcija skiriasi nuo " `as` perdavimo, kai bandoma išsaugoti *skaitmeninę*, o ne bitų reikšmę.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // SAUGUMAS: `u64` yra paprastas senas duomenų tipas, todėl mes visada galime jį pakeisti
        // Pasirodo, sNaN saugumo klausimai buvo per daug išpūsti!Hurra!
        unsafe { mem::transmute(v) }
    }

    /// Grąžinkite šio slankiojo kablelio skaičiaus atminties vaizdą kaip baitų masyvą didžiųjų (network) baitų tvarka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// Grąžinkite šio slankiojo kablelio skaičiaus atminties vaizdą kaip baitų masyvą mažų galų baitų tvarka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// Grąžinkite šio slankiojo kablelio skaičiaus atminties vaizdą kaip baitų masyvą gimtąja baitų tvarka.
    ///
    /// Kadangi naudojamas tikslinės platformos gimtoji savybė, nešiojamasis kodas turėtų naudoti [`to_be_bytes`] arba [`to_le_bytes`].
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// Grąžinkite šio slankiojo kablelio skaičiaus atminties vaizdą kaip baitų masyvą gimtąja baitų tvarka.
    ///
    ///
    /// [`to_ne_bytes`] turėtų būti teikiama pirmenybė, o ne.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // SAUGUMAS: `f64` yra paprastas senas duomenų tipas, todėl mes visada galime jį pakeisti
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Sukurkite slankiojo kablelio vertę iš jos pateikimo kaip baitų masyvo didžiajame gale.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// Sukurkite slankiojo kablelio vertę pagal jos vaizdą kaip baitų masyvą mažu galu.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// Sukurkite slankiojo kablelio vertę iš jos, kaip baitų masyvo, gimtojoje endijos dalyje.
    ///
    /// Kadangi naudojamas tikslinės platformos gimtoji savybė, nešiojamasis kodas greičiausiai nori naudoti [`from_be_bytes`] arba [`from_le_bytes`].
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// Pateikia tvarką tarp savęs ir kitų vertybių.
    /// Skirtingai nuo standartinio dalinio slankiųjų kablelių skaičių palyginimo, šis palyginimas visada pateikia užsakymą pagal " totalOrder` predikatą, kaip apibrėžta IEEE 754 (2008 m. Redakcija) slankiojo kablelio standarte.
    /// Vertės išdėstomos tokia tvarka:
    /// - Neigiamas tylus NaN
    /// - Neigiamas signalas NaN
    /// - Neigiama begalybė
    /// - Neigiami skaičiai
    /// - Neigiami subnormalūs skaičiai
    /// - Neigiamas nulis
    /// - Teigiamas nulis
    /// - Teigiami nenormalūs skaičiai
    /// - Teigiami skaičiai
    /// - Teigiama begalybė
    /// - Teigiamas signalizuojantis NaN
    /// - Teigiamas tylus NaN
    ///
    /// Atminkite, kad ši funkcija ne visada sutampa su " `f64` [`PartialOrd`] ir [`PartialEq`] diegimais.Visų pirma, jie neigiamą ir teigiamą nulį laiko lygiais, o `total_cmp`-ne.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // Jei yra neiginių, apverskite visus bitus, išskyrus ženklą, kad gautumėte panašų išdėstymą kaip du papildantys sveikieji skaičiai
        //
        // Kodėl tai veikia?IEEE 754 plūdes sudaro trys laukai:
        // Ženklo bitai, eksponentas ir mantissa.Eksponentų ir mantisų laukų rinkinys kaip visuma turi savybę, kad jų bitų tvarka yra lygi skaitiniam dydžiui, kuriame apibrėžtas dydis.
        // Dydis paprastai nėra apibrėžtas pagal NaN reikšmes, tačiau IEEE 754 totalOrder taip pat nustato NaN reikšmes, kad jos būtų laikomasi bitų tvarka.Tai veda prie tvarkos, paaiškintos doc komentare.
        // Tačiau neigiamų ir teigiamų skaičių reikšmė yra vienoda-skiriasi tik ženklo bitas.
        // Norėdami lengvai palyginti plūdes, pažymėtus sveikaisiais skaičiais, turime apversti rodiklio ir mantisos bitus, jei neigiami skaičiai.
        // Mes efektyviai konvertuojame skaičius į "two's complement" formą.
        //
        // Norėdami atlikti vartymą, mes sukonstruojame kaukę ir XOR prieš ją.
        // Apskaičiuojame "all-ones except for the sign bit" kaukę iš neigiamai pasirašytų reikšmių: dešiniuoju poslinkiu ženklas pratęsia sveikąjį skaičių, taigi mes "fill" kaukę su ženklo bitais ir tada konvertuojame į nepasirašytą, kad paspaustume dar vieną nulio bitą.
        //
        // Vertinant teigiamas vertes, kaukė yra visi nuliai, taigi jos negalima.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// Apribokite vertę iki tam tikro intervalo, nebent ji būtų NaN.
    ///
    /// Pateikia `max`, jei `self` yra didesnis nei `max`, ir `min`, jei `self` yra mažesnis nei `min`.
    /// Kitu atveju grąžinama `self`.
    ///
    /// Atkreipkite dėmesį, kad ši funkcija pateikia NaN, jei pradinė vertė taip pat buvo NaN.
    ///
    /// # Panics
    ///
    /// Panics, jei `min > max`, `min` yra NaN, arba `max` yra NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}