//! Dešimtainės formos eilutės patvirtinimas ir suskaidymas:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Kitaip tariant, standartinė slankiojo kablelio sintaksė, išskyrus dvi išimtis: Nr ženklo ir "inf" bei "NaN" tvarkymo.Tai tvarko vairuotojo funkcija (super::dec2flt).
//!
//! Nors galiojančių įvesties atpažinimas yra gana lengvas, šis modulis taip pat turi atmesti daugybę negaliojančių variantų, niekada " panic`, ir atlikti daugybę patikrinimų, kuriais kiti moduliai remiasi, o ne " panic` (arba perpildymu).
//!
//! Blogiau, kad viskas, kas vyksta vienu įvedimu per įvestį.
//! Taigi, būkite atsargūs ką nors keisdami ir dar kartą patikrinkite su kitais moduliais.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Įdomios dešimtainės eilutės dalys.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Dešimtainis rodiklis, garantuojamas, kad bus mažiau nei 18 skaitmenų po kablelio.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Patikrina, ar įvesties eilutė yra galiojantis slankiojo kablelio skaičius, ir, jei taip, suraskite joje vientisąją dalį, trupmeninę dalį ir rodiklį.
/// Nevaldo ženklų.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Be 'e' skaitmenų nėra
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Mes reikalaujame bent vieno skaitmens prieš arba po taško.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Galinis šlamštas po trupmenos dalies
            }
        }
        _ => Invalid, // Galinis šlamštas po pirmos skaitmenų eilutės
    }
}

/// Išskiria dešimtainius skaitmenis iki pirmo ne skaitmenų simbolio.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Eksponento išskyrimas ir klaidų tikrinimas.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Galinis šlamštas po eksponento
    }
    if number.is_empty() {
        return Invalid; // Tuščias rodiklis
    }
    // Šiuo metu mes tikrai turime galiojančią skaitmenų eilutę.Gali būti per ilgai įdėti į " `i64`, bet jei jis toks didžiulis, įvestis tikrai lygi nuliui arba begalybė.
    // Kadangi kiekvienas nulis po dešimtainių skaitmenų koreguoja eksponentą tik +/-1, esant exp=10 ^ 18, įvestis turėtų būti 17 egzabaitų (!) nulių, kad būtų galima net nuotoliniu būdu priartėti prie baigtinio.
    //
    // Tai nėra tikslus atvejis, į kurį turime atsižvelgti.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}