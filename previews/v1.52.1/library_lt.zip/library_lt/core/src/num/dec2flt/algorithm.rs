//! Įvairūs darbo algoritmai.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Reikšminių bitų skaičius Fp
const P: u32 = 64;

// Mes paprasčiausiai saugome geriausią *visų* eksponentų apytikslį dydį, todėl kintamojo "h" ir susijusių sąlygų galima praleisti.
// Tai parduoda poros kilobaitų vietos našumą.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Daugumoje architektūrų slankiojo kablelio operacijos turi aiškų bitų dydį, todėl skaičiavimo tikslumas nustatomas pagal operaciją.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Naudojant " x86, x87 FPU naudojamas plūdinėms operacijoms, jei SSE/SSE2 plėtinių nėra.
// Pagal numatytuosius nustatymus " x87 FPU` veikia su 80 bitų tikslumu, o tai reiškia, kad operacijos suapvalės iki 80 bitų ir sukels dvigubą apvalinimą, kai reikšmės galiausiai pateikiamos kaip
//
// 32/64 bitų plūduriuojančios vertės.Norėdami tai įveikti, FPU kontrolinį žodį galima nustatyti taip, kad skaičiavimai būtų atliekami norimu tikslumu.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktūra, naudojama išsaugoti pradinę FPU kontrolinio žodžio vertę, kad ją būtų galima atkurti, kai struktūra numetama.
    ///
    ///
    /// " x87 FPU` yra 16 bitų registras, kurio laukai yra šie:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Visų laukų dokumentaciją galite rasti " IA-32 Architectures` programinės įrangos kūrėjo vadove (1 tomas).
    ///
    /// Vienintelis laukas, susijęs su šiuo kodu, yra kompiuteris, " Precision Control`.
    /// Šis laukas nustato FPU atliekamų operacijų tikslumą.
    /// Ją galima nustatyti:
    ///  - 0b00, vieno tikslumo, ty 32 bitai
    ///  - 0b10, dvigubas tikslumas, ty 64 bitai
    ///  - 0b11, dvigubai išplėstas tikslumas, ty 80 bitų (numatytoji būsena) 0b01 reikšmė yra rezervuota ir neturėtų būti naudojama.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SAUGUMAS: `fldcw` instrukcija buvo patikrinta, ar ji gali tinkamai veikti
        // bet koks " `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Mes naudojame ATT sintaksę palaikyti LLVM 8 ir LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Nustato FPU tikslumo lauką į `T` ir grąžina `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Apskaičiuokite tikslaus valdymo lauko reikšmę, tinkamą `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitai
            8 => 0x0200, // 64 bitai
            _ => 0x0300, // numatytasis, 80 bitų
        };

        // Gaukite pradinę kontrolinio žodžio vertę, kad ją atkurtumėte vėliau, kai bus atsisakyta `FPUControlWord` struktūros. SAUGUMAS: `fnstcw` instrukcija buvo patikrinta, kad galėtų tinkamai veikti su bet kuriuo `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Mes naudojame ATT sintaksę palaikyti LLVM 8 ir LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Nustatykite norimą tikslumo kontrolinį žodį.
        // Tai pasiekiama užmaskuojant seną tikslumą (8 ir 9 bitai, 0x300) ir pakeičiant aukščiau apskaičiuota tikslumo vėliava.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Greitas " Bellerophon` kelias naudojant mašinos dydžio sveikuosius skaičius ir plūdurius.
///
/// Tai išskleidžiama į atskirą funkciją, kad ją būtų galima bandyti prieš konstruojant bignumą.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Tikslią vertę lyginame su MAX_SIG netoli pabaigos, tai tik greitas ir pigus atmetimas (be to, likusį kodą atlaisvina nerimas dėl nepakankamo srauto).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Greitas kelias iš esmės priklauso nuo aritmetikos suapvalinimo iki teisingo bitų skaičiaus be jokio tarpinio apvalinimo.
    // Jei naudojate x86 (be SSE ar SSE2), reikia pakeisti x87 FPU kamino tikslumą, kad jis tiesiogiai suapvalintų iki 64/32 bitų.
    // " `set_precision` funkcija rūpinasi tikslumo nustatymu architektūrose, kurias reikia nustatyti pakeičiant visuotinę būseną (pvz., " x87 FPU` valdymo žodis).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Atvejo e <0 negalima sulankstyti į kitą branch.
    // Neigiamos galios sukelia kartotinę trupmeninę dvejetainės dalies dalį, kuri yra suapvalinta, o tai sukelia realias (o kartais ir gana reikšmingas!) Klaidas galutiniame rezultate.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Bellerophono algoritmas yra nereikšmingas kodas, pagrįstas ne trivialia skaitine analize.
///
/// Jis suapvalina " f` iki plūdės, turinčios 64 bitų reikšmę, ir padaugina ją iš geriausio `10^e` aproksimavimo (tuo pačiu slankiojo kablelio formatu).To dažnai pakanka norint gauti teisingą rezultatą.
/// Tačiau kai rezultatas yra beveik pusiaukelėje tarp dviejų gretimų (ordinary) plūdurų, sudėtinė apvalinimo klaida, padauginus du apytikslį dydį, reiškia, kad rezultatas gali būti išjungtas keliais bitais.
/// Kai taip atsitinka, iteracinis R algoritmas išsprendžia viską.
///
/// Rankomis banguotas "close to halfway" yra tikslus atlikus skaitinę analizę popieriuje.
/// Clingerio žodžiais:
///
/// > Nuolydis, išreikštas mažiausiai reikšmingo bito vienetais, yra klaidos privalomas
/// > sukauptas apskaičiuojant slankiojo kablelio artėjimą prie f * 10 ^ e.(Šlaitas yra
/// > nėra susijęs su tikra paklaida, bet riboja apytikslio z ir
/// > geriausiu įmanomu derinimu, kuriame naudojami p reikšmės bitai.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) atvejai yra fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ar nuolydis yra pakankamai didelis, kad galėtų skirtis apvalinant iki n bitų?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteracinis algoritmas, pagerinantis slankiojo kablelio aproksimavimą `f * 10^e`.
///
/// Kiekviena iteracija gauna po vieną vienetą paskutinėje vietoje arčiau, o tai, žinoma, užtrunka siaubingai ilgai, kol susilieja `z0`.
/// Laimei, kai naudojamas kaip atsarginis " Bellerophon`, pradinis apytikslis yra ne didesnis kaip vienas ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Raskite teigiamus sveikus skaičius `x`, `y`, kad `x / y` būtų tiksliai `(f *10^e) / (m* 2^k)`.
        // Tai ne tik vengia susidoroti su `e` ir `k` ženklais, bet ir pašaliname dviejų bendrų `10^e` ir `2^k` galią, kad skaičiai būtų mažesni.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Tai parašyta šiek tiek nepatogiai, nes mūsų bignumai nepalaiko neigiamų skaičių, todėl mes naudojame absoliučią vertę + ženklo informaciją.
        // Dauginimas su m_digits negali būti perpildytas.
        // Jei " `x` arba " `y` yra pakankamai dideli, kad mums reikia nerimauti dėl perpildymo, tai jie taip pat yra pakankamai dideli, kad " `make_ratio` sumažino dalį 2 ^ 64 ar daugiau kartų.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Nebereikia x, išsaugokite clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Vis dar reikia y, pasidarykite kopiją.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Atsižvelgiant į `x = f` ir `y = m`, kur `f`, kaip įprasta, reiškia įvesties dešimtainius skaitmenis, o `m` yra slankiojo kablelio aproksimacijos reikšmė, todėl `x / y` santykis yra lygus `(f *10^e) / (m* 2^k)`, galbūt sumažintas dviejų galių, abu turi bendrą.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, išskyrus tai, kad trupmeną sumažiname kažkokia dviejų galia.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Tai negali būti perpildyta, nes tam reikalingas teigiamas `e` ir neigiamas `k`, o tai gali atsitikti tik labai arti 1 reikšmių, o tai reiškia, kad `e` ir `k` bus palyginti mažos.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tai taip pat negali perpildyti, žr. aukščiau.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), vėl sumažinant bendrąja dviejų galia.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Koncepciniu požiūriu algoritmas M yra paprasčiausias būdas dešimtainį skaičių paversti plūdine.
///
/// Mes suformuojame santykį, kuris yra lygus `f * 10^e`, tada įmetame dviejų galių skaičių, kol jis suteiks pagrįstą plūduriuojančią reikšmę.
/// Dvejetainis rodiklis `k` yra kartų, kai padauginome skaitiklį arba vardiklį iš dviejų, ty, `f *10^e` visada lygus `(u / v)* 2^k`.
/// Sužinoję reikšmę, turime suapvalinti tik apžiūrėdami likusią dalybos dalį, kuri atliekama pagalbinėse funkcijose toliau.
///
///
/// Šis algoritmas yra labai lėtas, net naudojant `quick_start()` aprašytą optimizavimą.
/// Tačiau tai paprasčiausias algoritmas, pritaikytas perpildymui, nepakankamumui ir nenormaliems rezultatams gauti.
/// Šis diegimas perimamas, kai " Bellerophon`ir " Algorithm R` yra priblokšti.
/// Nustatyti perpildymą ir perpildymą yra lengva: santykis vis dar nėra diapazone esantis reikšmingumas, tačiau minimum/maximum rodiklis pasiektas.
/// Perpildymo atveju mes tiesiog grąžiname begalybę.
///
/// Tvarkyti nepakankamą srautą ir neįprastus įpročius yra sudėtingiau.
/// Viena didelė problema yra ta, kad naudojant minimalų rodiklį santykis vis tiek gali būti per didelis reikšmei.
/// Išsamesnės informacijos ieškokite underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Pataisyti galimą optimizavimą: apibendrinkite big_to_fp, kad čia galėtume atlikti fp_to_float(big_to_fp(u)) ekvivalentą, tik be dvigubo apvalinimo.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Turime sustoti ties minimaliu rodikliu, jei palauksime iki `k < T::MIN_EXP_INT`, tada mums bus du kartus.
            // Deja, tai reiškia, kad mes turime atskirais atvejais suskaičiuoti normalius skaičius su minimaliu rodikliu.
            // FIXME raskite elegantiškesnę formuluotę, tačiau atlikite " `tiny-pow10` testą, kad įsitikintumėte, jog jis tikrai teisingas!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Praleidžia daugumą M algoritmo iteracijų, patikrindamas bitų ilgį.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitų ilgis yra dviejų pagrindinių logaritmų įvertis, o log(u / v) = log(u), log(v).
    // Įvertinimas išjungtas ne daugiau kaip 1, bet visada per mažas, todėl log(u) ir log(v) klaida yra to paties ženklo ir panaikinama (jei abu yra dideli).
    // Todėl " log(u / v) klaida taip pat yra viena.
    // Tikslinis santykis yra tas, kur u/v yra diapazono reikšmėje.Taigi mūsų nutraukimo sąlyga yra tai, kad log2(u / v) yra reikšmingieji bitai, plus/minus vienas.
    // FIXME Pažvelgus į antrą bitą, būtų galima pagerinti sąmatą ir išvengti dar kelių padalijimų.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Nepakankamas arba nenormalus.Palikite tai pagrindinei funkcijai.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Perpildymas.Palikite tai pagrindinei funkcijai.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Santykis nėra diapazone esantis reikšminis ženklas su minimaliuoju rodikliu, todėl turime suapvalinti perteklinius bitus ir atitinkamai pakoreguoti rodiklį.
    // Tikroji vertė dabar atrodo taip:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(atstovaujamas remo)
    //
    // Todėl, kai suapvalinti bitai yra!= 0.5 ULP, jie apvalinimą nusprendžia patys.
    // Kai jos yra lygios, o likusi dalis nėra lygi nuliui, vertę vis tiek reikia suapvalinti.
    // Tik tada, kai suapvalinti bitai yra 1/2, o likusi dalis lygi nuliui, turime pusiau lygų situaciją.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Įprastas turas iki lygių, sutrumpintas dėl to, kad reikia apvalinti remiantis likusia dalybos dalimi.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}