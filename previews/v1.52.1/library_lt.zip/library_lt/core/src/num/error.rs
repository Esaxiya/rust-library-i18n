//! Klaidų tipai konvertuojant į integralinius tipus.

use crate::convert::Infallible;
use crate::fmt;

/// Klaidos tipas pateiktas, kai nepavyksta patikrinti integruoto tipo konversijos.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Rungtynės, o ne prievartos, kad įsitikintumėte, jog kodas, pvz., `From<Infallible> for TryFromIntError` aukščiau, veiks ir toliau, kai `Infallible` taps `!` slapyvardžiu.
        //
        //
        match never {}
    }
}

/// Klaida, kurią galima pateikti analizuojant sveiką skaičių.
///
/// Ši klaida naudojama kaip klaidos tipas `from_str_radix()` funkcijoms pirminiuose sveikųjų skaičių tipuose, pvz., [`i8::from_str_radix`].
///
/// # Galimos priežastys
///
/// Be kitų priežasčių, `ParseIntError` gali būti išmesta dėl eilutėje esančių ar besibaigiančių tarpų, pvz., Kai jis gaunamas iš standartinio įvesties.
///
/// Naudojant [`str::trim()`] metodą, užtikrinama, kad prieš analizuojant neliks tarpų.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// " Enum` saugo įvairių tipų klaidas, dėl kurių sveiko skaičiaus analizavimas gali nepavykti.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Analizuojama vertė tuščia.
    ///
    /// Be kitų priežasčių, šis variantas bus sukonstruotas analizuojant tuščią eilutę.
    Empty,
    /// Kontekste yra neteisingas skaitmuo.
    ///
    /// Be kitų priežasčių, šis variantas bus sukonstruotas analizuojant eilutę, kurioje yra ne ASCII simbolis.
    ///
    /// Šis variantas taip pat sukonstruojamas, kai `+` arba `-` yra neteisingai įdėtas į eilutę arba atskirai, arba skaičiaus viduryje.
    ///
    ///
    InvalidDigit,
    /// Sveikasis skaičius yra per didelis, kad būtų galima išsaugoti tikslinio sveiko skaičiaus tipą.
    PosOverflow,
    /// Sveikas skaičius yra per mažas, kad būtų galima išsaugoti tikslinio sveiko skaičiaus tipą.
    NegOverflow,
    /// Vertė buvo nulis
    ///
    /// Šis variantas bus išleistas, kai analizavimo eilutės vertė bus lygi nuliui, o tai būtų neteisėta ne nuliui tipams.
    ///
    Zero,
}

impl ParseIntError {
    /// Pateikiama išsami klaidingo sveiko skaičiaus analizavimo priežastis.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}