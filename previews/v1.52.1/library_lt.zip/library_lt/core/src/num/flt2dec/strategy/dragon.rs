//! Beveik tiesioginis (bet šiek tiek optimizuotas) " Greito ir tikslaus slankiojo kablelio numerių spausdinimo`[^ 1] 3 paveikslo vertimas " Rust`.
//!
//!
//! [^1]: Burger, RG and Dybvig, RK 1996. Slankiųjų kablelių skaičių spausdinimas
//!   greitai ir tiksliai.SIGPLAN Ne.31, 5 (1996 m. Gegužė), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// iš anksto apskaičiuoti 10 skaitmenų (skaitmenų) masyvai 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// galima naudoti tik tada, kai `x < 16 * scale`;`scaleN` turėtų būti `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Trumpiausias " Dragon` režimo įgyvendinimas.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // numeris `v` iki formato yra žinomas:
    // - lygus `mant * 2^exp`;
    // - prieš jį originalaus tipo `(mant - 2 *minus)* 2^exp`;ir
    // - po jo-originalaus tipo `(mant + 2 *plus)* 2^exp`.
    //
    // akivaizdu, kad `minus` ir `plus` negali būti lygūs nuliui.(begalybėms naudojame ne diapazono reikšmes.) Taip pat darome prielaidą, kad generuojamas bent vienas skaitmuo, ty `mant` taip pat negali būti nulis.
    //
    // tai taip pat reiškia, kad bet kuris skaičius tarp `low = (mant - minus)*2^exp` ir `high = (mant + plus)* 2^exp` atitiks šį tikslų slankiojo kablelio skaičių, įtraukiant ribas, kai pradinė mantissa buvo lygi (ty `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` yra `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // įvertinkite `k_0` pagal originalius įvestis, atitinkančius `10^(k_0-1) < high <= 10^(k_0+1)`.
    // sandariai sujungtas `k`, tenkinantis `10^(k-1) < high <= 10^k`, apskaičiuojamas vėliau.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konvertuoti `{mant, plus, minus} * 2^exp` į trupmeninę formą taip:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // padalykite `mant` iš `10^k`.dabar `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // taisymas, kai `mant + plus > scale` (arba `>=`).
    // mes iš tikrųjų nekeičiame `scale`, nes vietoj to galime praleisti pradinį dauginimą.
    // Dabar " `scale < mant + plus <= scale * 10` ir esame pasirengę generuoti skaitmenis.
    //
    // atkreipkite dėmesį, kad `d[0]` * gali būti nulis, kai `scale - plus < mant < scale`.
    // tokiu atveju suapvalinimo sąlyga (`up` žemiau) bus suaktyvinta nedelsiant.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // tolygus `scale` mastelio keitimui 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // talpykla `(2, 4, 8) * scale` skaitmenų generavimui.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariantai, kur `d[0..n-1]` yra iki šiol sugeneruoti skaitmenys:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (taigi `mant / scale < 10`), kur `d[i..j]` yra `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // sugeneruoti vieną skaitmenį: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // tai supaprastintas modifikuoto Drakono algoritmo aprašymas.
        // patogumo sumetimais praleista daug tarpinių darinių ir išsamumo argumentų.
        //
        // pradėkite nuo modifikuotų invariantų, nes mes atnaujinome " `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // Tarkime, kad `d[0..n-1]` yra trumpiausias vaizdavimas tarp `low` ir `high`, ty `d[0..n-1]` tenkina abu šiuos dalykus, tačiau `d[0..n-2]` neatitinka:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektyvumas: skaitmenys apvalūs iki `v`);ir
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (paskutinis skaitmuo yra teisingas).
        //
        // antroji sąlyga supaprastėja iki `2 * mant <= scale`.
        // sprendžiant invariantus pagal `mant`, `low` ir `high`, gaunama paprastesnė pirmosios sąlygos versija: `-plus < mant < minus`.
        // nuo `-plus < 0 <= mant`, mes turime teisingiausią trumpiausią vaizdą, kai `mant < minus` ir `2 * mant <= scale`.
        // (pirmoji tampa `mant <= minus`, kai pirminė mantissa yra lygi.)
        //
        // kai antroji nelaiko (" 2 * mant> skalė`), turime padidinti paskutinį skaitmenį.
        // to pakanka atkurti tą sąlygą: mes jau žinome, kad skaitmenų generavimas garantuoja " `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // šiuo atveju pirmoji sąlyga tampa `-plus < mant - scale < minus`.
        // nuo `mant < scale` po kartos mes turime `scale < mant + plus`.
        // (vėlgi, tai tampa `scale <= mant + plus`, kai pirminė mantissa yra lygi.)
        //
        // trumpai:
        // - sustokite ir suapvalinkite `down` (išsaugokite skaitmenis, kokie yra), kai `mant < minus` (arba `<=`).
        // - sustokite ir suapvalinkite `up` (padidinkite paskutinį skaitmenį), kai `scale < mant + plus` (arba `<=`).
        // - vis generuokite kitaip.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // mes turime trumpiausią vaizdą, pereikite prie apvalinimo

        // atkurti invariantus.
        // dėl to algoritmas visada baigiasi: `minus` ir `plus` visada didėja, tačiau `mant` yra apkarpytas modulo `scale` ir `scale` yra fiksuotas.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // suapvalinimas vyksta tada, kai i) suveikė tik suapvalinimo sąlyga, arba ii) suveikė abi sąlygos, o kaklaraiščio nutraukimas teikia pirmenybę apvalinimui.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // jei suapvalinus aukštyn keičiasi ilgis, turėtų keistis ir rodiklis.
        // panašu, kad šią sąlygą labai sunku patenkinti (galbūt neįmanoma), bet mes čia tiesiog saugūs ir nuoseklūs.
        //
        // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Tikslus ir fiksuoto " Dragon` režimo įgyvendinimas.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // Įvertinkite `k_0` iš originalių įvesties, atitinkančios `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // padalykite `mant` iš `10^k`.dabar `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // taisymas, kai `mant + plus >= scale`, kur `plus / scale = 10^-buf.len() / 2`.
    // norėdami išlaikyti fiksuoto dydžio bignumą, mes iš tikrųjų naudojame `mant + floor(plus) >= scale`.
    // mes iš tikrųjų nekeičiame `scale`, nes vietoj to galime praleisti pradinį dauginimą.
    // vėlgi naudojant trumpiausią algoritmą, `d[0]` gali būti nulis, bet galiausiai bus suapvalintas.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // tolygus `scale` mastelio keitimui 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // jei dirbame su paskutinių skaitmenų apribojimu, prieš faktinį atvaizdavimą turime sutrumpinti buferį, kad išvengtume dvigubo apvalinimo.
    //
    // atkreipkite dėmesį, kad mes turime dar kartą padidinti buferį, kai įvyksta apvalinimas!
    let mut len = if k < limit {
        // Oi, mes net negalime pagaminti *vieno* skaitmens.
        // tai įmanoma, kai, tarkime, turime kažką panašaus į " 9.5 ir jis suapvalinamas iki 10.
        // grąžiname tuščią buferį, išskyrus vėlesnį apvalinimo atvejį, kuris įvyksta, kai `k == limit` ir turi pateikti tiksliai vieną skaitmenį.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // talpykla `(2, 4, 8) * scale` skaitmenų generavimui.
        // (tai gali būti brangu, todėl neskaičiuokite jų, kai buferis tuščias.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // Šie skaitmenys yra visi nuliai, mes čia sustojame, o ne * bandykite atlikti apvalinimą!verčiau užpildykite likusius skaitmenis.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // suapvalinti aukštyn, jei sustojame skaitmenų viduryje, jei šie skaitmenys yra tiksliai 5000 ..., patikrinkite ankstesnį skaitmenį ir pabandykite suapvalinti iki lyginio (ty venkite suapvalinti aukštyn, kai ankstesnis skaitmuo yra lygus).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SAUGA: `buf[len-1]` inicijuojamas.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // jei suapvalinus aukštyn keičiasi ilgis, turėtų keistis ir rodiklis.
        // bet mums buvo paprašytas fiksuotas skaitmenų skaičius, todėl nekeiskite buferio ...
        // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... nebent mums būtų pareikalauta fiksuoto tikslumo.
            // taip pat turime patikrinti, ar, jei pradinis buferis buvo tuščias, papildomą skaitmenį galima pridėti tik tada, kai `k == limit` (edge atvejis).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}