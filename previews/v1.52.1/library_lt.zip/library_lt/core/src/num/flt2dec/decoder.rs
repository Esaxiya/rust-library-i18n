//! Dekoduoja slankiojo kablelio vertę į atskiras dalis ir klaidų diapazonus.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Iškoduota nepasirašyta baigtinė vertė, tokia:
///
/// - Pradinė vertė lygi `mant * 2^exp`.
///
/// - Bet koks skaičius nuo `(mant - minus)*2^exp` iki `(mant + plus)* 2^exp` bus suapvalintas iki pradinės vertės.
/// Diapazonas įskaičiuojamas tik tada, kai `inclusive` yra `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Sumažinta mantissa.
    pub mant: u64,
    /// Mažesnis klaidų diapazonas.
    pub minus: u64,
    /// Viršutinis klaidų diapazonas.
    pub plus: u64,
    /// Bendras 2 pagrindo rodiklis.
    pub exp: i16,
    /// Tiesa, kai klaidų diapazonas yra imtinai.
    ///
    /// IEEE 754, tai tiesa, kai pirminė mantissa buvo lygi.
    pub inclusive: bool,
}

/// Iškoduota nepasirašyta vertė.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Begalybės, teigiamos arba neigiamos.
    Infinite,
    /// Nulis, teigiamas arba neigiamas.
    Zero,
    /// Galutiniai skaičiai su toliau iššifruotais laukais.
    Finite(Decoded),
}

/// Slankiojo kablelio tipas, kurį galima " iššifruoti`.
pub trait DecodableFloat: RawFloat + Copy {
    /// Mažiausias teigiamas normalizuotas dydis.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Pateikia ženklą (tiesa, kai neigiamas) ir `FullDecoded` reikšmę iš nurodyto slankiojo kablelio skaičiaus.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // kaimynai: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode visada išsaugo eksponentą, todėl mantissa yra skirstoma į papročius.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // kaimynai: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kur maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // kaimynai: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}