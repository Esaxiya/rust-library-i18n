//! Rust pritaikymas Grisu3 algoritmui, aprašytam "Kintančiųjų skaičių greitai ir tiksliai spausdinant sveikaisiais skaičiais" [^ 1].
//! Jis naudoja apie 1 KB iš anksto apskaičiuotos lentelės, o savo ruožtu tai yra labai greita daugumai įvesties.
//!
//! [^1]: Florian Loitschas.2010. Greitai spausdami slankiojo kablelio skaičius ir
//!   tiksliai su sveikaisiais skaičiais.SIGPLAN Ne.45, 6 (2010 m. Birželio mėn.), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// Pažiūrėkite į `format_shortest_opt` pateiktus komentarus.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Duota `x > 0`, grąžina `(k, 10^k)`, kad `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Trumpiausias " Grisu` režimo įgyvendinimas.
///
/// Jis grąžina `None`, kai priešingu atveju pateiktų netikslų vaizdą.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // mums reikia mažiausiai trijų bitų papildomo tikslumo

    // pradėkite nuo normalizuotų reikšmių su bendruoju rodikliu
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // rasti bet kokį `cached = 10^minusk`, kad `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // kadangi `plus` yra normalizuotas, tai reiškia `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // atsižvelgiant į mūsų pasirinktus `ALPHA` ir `GAMMA` variantus, tai įtraukia `plus * cached` į `[4, 2^32)`.
    //
    // akivaizdžiai pageidautina maksimaliai padidinti `GAMMA - ALPHA`, kad mums nereikėtų daug talpykloje esančių 10 galių, tačiau yra keletas priežasčių:
    //
    //
    // 1. norime išlaikyti " `floor(plus * cached)` `u32`, nes jam reikia brangaus padalijimo.
    //    (to tikrai neišvengiama, tikslumui įvertinti reikalinga likusi dalis.)
    // 2.
    // likusi " `floor(plus * cached)` dalis pakartotinai padauginama iš 10 ir ji neturėtų perpildyti.
    //
    // pirmasis suteikia `64 + GAMMA <= 32`, o antrasis-`10 * 2^-ALPHA <= 2^64`;
    // -60 ir -32 yra maksimalus diapazonas su šiuo apribojimu, o V8 taip pat juos naudoja.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skalės fps.tai suteikia maksimalią 1 ulp paklaidą (įrodyta iš 5.1 teoremos).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-faktinis diapazonas minusas
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // virš `minus`, `v` ir `plus` yra *kiekybiniai* apytiksliai (paklaida <1 ulp).
    // kadangi mes nežinome, kad klaida yra teigiama ar neigiama, mes naudojame du apytikslius atstumus, išdėstytus vienodai, ir maksimali paklaida yra 2 ulps.
    //
    // "unsafe region" yra liberalus intervalas, kurį mes iš pradžių generuojame.
    // " "safe region" yra konservatyvus intervalas, kurį mes priimame tik.
    // mes pradedame nuo teisingo repr nesaugiame regione ir bandome rasti artimiausią repr iki `v`, kuris taip pat yra saugiame regione.
    // jei negalime, atsisakome.
    //
    let plus1 = plus.f + 1;
    // tegul plus0 = plus.f, 1;//tik paaiškinimui tegul minus0 = minus.f + 1;//tik paaiškinimui
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // bendras eksponentas

    // padalykite `plus1` į integralines ir trupmenines dalis.
    // sudėtinės dalys garantuotai tiks u32, nes talpyklos galia garantuoja `plus < 2^32`, o normalizuotas `plus.f` visada yra mažesnis nei `2^64 - 2^4` dėl tikslumo reikalavimo.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // apskaičiuokite didžiausią `10^max_kappa` ne daugiau kaip `plus1` (taigi `plus1 < 10^(max_kappa+1)`).
    // tai yra viršutinė `kappa` riba žemiau.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // 6.2 teorema: jei `k` yra didžiausias sveikasis skaičius
    // `0 <= y mod 10^k <= y - x`,              tada `V = floor(y / 10^k) * 10^k` yra `[x, y]` ir vienas iš trumpiausių to diapazono vaizdų (su minimaliu reikšmingų skaitmenų skaičiumi).
    //
    //
    // raskite `kappa` skaitmens ilgį tarp `(minus1, plus1)` pagal 6.2 teoremą.
    // 6.2 teorema gali būti taikoma norint išskirti `x`, vietoje to reikalaujant `y mod 10^k < y - x`.
    // (pvz., `x` =32000, `y` =32777; `kappa` =2, nes "y mod 10 ^ 3=777 <y, x=777".) Algoritmas remiasi vėlesne patikros faze, kad neįtrauktų `y`.
    //
    let delta1 = plus1 - minus1;
    // tegul delta1int=(delta1>> e) kaip naudoti;//tik paaiškinimui
    let delta1frac = delta1 & ((1 << e) - 1);

    // pateikiamos neatskiriamos dalys, tuo pat metu tikrinant kiekvieno žingsnio tikslumą.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // skaitmenys dar nepateikti
    loop {
        // mes visada turime bent vieną skaitmenį pateikti, kaip `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (iš to išplaukia, kad `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // padalykite `remainder` iš `10^kappa`.abu juos keičia `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; radome teisingą " `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skalė 10 ^ kappa atgal į bendrą rodiklį
            return round_and_weed(
                // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // pertraukite kilpą, kai pateiksime visus vientisus skaitmenis.
        // tikslus skaitmenų skaičius yra `max_kappa + 1` kaip `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // atkurti invariantus
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // perteikti trupmenines dalis, tikrinant kiekvieno žingsnio tikslumą.
    // šį kartą mes pasikliaujame pakartotiniais dauginimais, nes dalijimas praras tikslumą.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // kitas skaitmuo turėtų būti reikšmingas, nes mes išbandėme tai prieš išskirdami invariantus, kur `m = max_kappa + 1` (skaitmenų skaičius neatsiejamoje dalyje):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // neperpildys, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // padalykite `remainder` iš `10^kappa`.
        // abu juos keičia `2^e / 10^kappa`, todėl pastarasis čia yra numanomas.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // numanomas daliklis
            return round_and_weed(
                // SAUGUMAS: mes inicijavome tą atmintį aukščiau.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // atkurti invariantus
        kappa -= 1;
        remainder = r;
    }

    // sugeneravome visus reikšmingus " `plus1` skaitmenis, bet nežinome, ar tai optimaliausias.
    // Pavyzdžiui, jei `minus1` yra 3.14153 ... ir `plus1` yra 3.14158 ..., yra 5 skirtingi trumpiausi vaizdai nuo 3.14154 iki 3.14158, bet mes turime tik didžiausią.
    // mes turime nuosekliai mažinti paskutinį skaitmenį ir patikrinti, ar tai yra optimalus repr.
    // yra ne daugiau kaip 9 kandidatai (.1-..9), taigi tai gana greitai.("rounding" fazė)
    //
    // funkcija patikrina, ar šis "optimal" repr iš tikrųjų yra ulp diapazone, taip pat gali būti, kad "second-to-optimal" repr iš tikrųjų gali būti optimalus dėl apvalinimo klaidos.
    // bet kuriuo atveju tai grąžina `None`.
    // ("weeding" fazė)
    //
    // visi čia pateikti argumentai yra apskaičiuoti pagal bendrą (bet numanomą) vertę `k`, kad:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ir `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ir `threshold > plus1v` iš ankstesnių invariantų)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // 1.5 ulps atstatys du apytikslius `v` (iš tikrųjų `plus1 - v`) dydžius.
        // gautas vaizdavimas turėtų būti artimiausias abiem.
        //
        // čia naudojamas `plus1 - v`, nes skaičiavimai atliekami atsižvelgiant į `plus1`, kad būtų išvengta overflow/underflow (taigi, atrodo, sukeisti pavadinimai).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // sumažinkite paskutinį skaitmenį ir sustokite ties artimiausiu `v + 1 ulp` vaizdu.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // mes dirbame su apytiksliais skaitmenimis `w(n)`, kuris iš pradžių yra lygus `plus1 - plus1 % 10^kappa`.paleidus kilpos kūną `n` kartus, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // nustatome `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (taigi `likutis= plus1w(0)`), kad supaprastintume patikrinimus.
            // atkreipkite dėmesį, kad `plus1w(n)` visada didėja.
            //
            // turime tris sąlygas nutraukti.bet kuris iš jų padarys kilpą negalinčią tęsti, bet tada mes turime bent vieną galiojančią atstovybę, kuri vis tiek yra arčiausiai `v + 1 ulp`.
            // trumpumu juos žymėsime kaip TC1-TC3.
            //
            // TC1: `w(n) <= v + 1 ulp`, ty tai yra paskutinis repr, kuris gali būti artimiausias.
            // tai prilygsta `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kartu su TC2 (kuris tikrina, ar `w(n+1)` is valid), tai apsaugo nuo galimo `plus1w(n)` skaičiavimo perpildymo.
            //
            // TC2: `w(n+1) < minus1`, t. Y. Kitas repr tikrai neapvalinamas iki `v`.
            // tai prilygsta `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // kairė pusė gali perpildyti, bet mes žinome `threshold > plus1v`, taigi, jei TC1 yra klaidingas, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ir mes galime saugiai patikrinti, ar `threshold - plus1w(n) < 10^kappa`.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ty kitas repr yra
            // arčiau `v + 1 ulp` nei dabartinis repr.
            // atsižvelgiant į `z(n) = plus1v_up - plus1w(n)`, tai tampa `abs(z(n)) <= abs(z(n+1))`.dar kartą darant prielaidą, kad TC1 yra klaidinga, turime `z(n) > 0`.turime apsvarstyti du atvejus:
            //
            // - kai `z(n+1) >= 0`: TC3 tampa `z(n) <= z(n+1)`.
            // didėjant `plus1w(n)`, `z(n)` turėtų mažėti ir tai akivaizdžiai klaidinga.
            // - kai `z(n+1) < 0`:
            //   - TC3a: išankstinė sąlyga yra `plus1v_up < plus1w(n) + 10^kappa`.darant prielaidą, kad TC2 yra klaidingas, `threshold >= plus1w(n) + 10^kappa`, todėl jis negali perpildyti.
            //   - TC3b: TC3 tampa `z(n) <= -z(n+1)`, ty `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   paneigtas TC1 suteikia `plus1v_up > plus1w(n)`, todėl kartu su TC3a jis negali nei perpildyti, nei per mažai.
            //
            // todėl turėtume sustoti, kai `TC1 || TC2 || (TC3a && TC3b)`.tai yra lygi jos atvirkštinei, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // trumpiausias repr negali baigtis `0`
                plus1w += ten_kappa;
            }
        }

        // patikrinkite, ar šis atvaizdavimas taip pat yra artimiausias `v - 1 ulp`.
        //
        // tai tiesiog tas pats, kas `v + 1 ulp` pabaigos sąlygoms, vietoj to, kad visa `plus1v_up` būtų pakeista į `plus1v_down`.
        // vienodai galioja perpildymo analizė.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // Dabar mes turime artimiausią `v` vaizdą tarp `plus1` ir `minus1`.
        // vis dėlto tai yra per daug liberalu, todėl atmetame bet kokį `w(n)`, kuris nėra tarp `plus0` ir `minus0`, ty `plus1 - plus1w(n) <= minus0` arba `plus1 - plus1w(n) >= plus0`.
        // mes naudojame faktus, kad `threshold = plus1 - minus1` ir `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Trumpiausias " Grisu`su " Dragon` atsarginiu režimu įgyvendinimas.
///
/// Tai turėtų būti naudojama daugeliu atvejų.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SAUGUMAS: skolinimosi tikrintuvas nėra pakankamai protingas, kad leistų mums naudotis " `buf`
    // antrame " branch`, todėl mes čia plauname visą gyvenimą.
    // Bet mes vėl naudojame `buf` tik tuo atveju, jei `format_shortest_opt` grąžino `None`, taigi tai gerai.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Tikslus ir fiksuoto " Grisu` režimo įgyvendinimas.
///
/// Jis grąžina `None`, kai priešingu atveju pateiktų netikslų vaizdą.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // mums reikia mažiausiai trijų bitų papildomo tikslumo
    assert!(!buf.is_empty());

    // normalizuoti ir keisti mastelį `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // padalykite `v` į integralines ir trupmenines dalis.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // tiek senojo `v`, tiek naujojo `v` (mastelio dydis: `10^-k`) klaida yra <1 ulp (5.1 teorema).
    // kadangi mes nežinome, kad klaida yra teigiama ar neigiama, mes naudojame du apytikslius atstumus, išdėstytus vienodai, ir maksimali paklaida yra 2 ulpos (tas pats trumpiausiu atveju).
    //
    //
    // tikslas yra rasti tiksliai suapvalintas skaitmenų serijas, kurios yra bendros tiek `v - 1 ulp`, tiek `v + 1 ulp`, kad būtume maksimaliai įsitikinę.
    // jei tai neįmanoma, mes nežinome, kuris iš jų yra teisingas " `v` išvestis, todėl atsisakome ir krentame atgal.
    //
    // `err` čia apibrėžiamas kaip `1 ulp * 2^e` (tas pats, kas `vfrac` " ulp`), ir mes jį pakeisime, kai tik `v` bus keičiamas.
    //
    //
    //
    let mut err = 1;

    // apskaičiuokite didžiausią `10^max_kappa` ne daugiau kaip `v` (taigi `v < 10^(max_kappa+1)`).
    // tai yra viršutinė `kappa` riba žemiau.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jei dirbame su paskutinių skaitmenų apribojimu, prieš faktinį atvaizdavimą turime sutrumpinti buferį, kad išvengtume dvigubo apvalinimo.
    //
    // atkreipkite dėmesį, kad mes turime dar kartą padidinti buferį, kai įvyksta apvalinimas!
    let len = if exp <= limit {
        // Oi, mes net negalime pagaminti *vieno* skaitmens.
        // tai įmanoma, kai, tarkime, turime kažką panašaus į " 9.5 ir jis suapvalinamas iki 10.
        //
        // iš principo mes galime nedelsdami paskambinti `possibly_round` naudodami tuščią buferį, tačiau `max_ten_kappa << e` mastelio pakeitimas 10 gali sukelti perpildymą.
        //
        // taigi mes čia nerangūs ir padidiname klaidų diapazoną 10 kartų.
        // tai padidins klaidingai neigiamą rodiklį, bet tik labai,*labai* nežymiai;
        // tai gali pastebimai pasireikšti tik tada, kai mantissa yra didesnė nei 60 bitų.
        //
        // SAUGA: `len=0`, todėl pareiga inicijuoti šią atmintį yra nereikšminga.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // padaryti neatsiejamas dalis.
    // klaida yra dalinė, todėl šioje dalyje jos tikrinti nereikia.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // skaitmenys dar nepateikti
    loop {
        // mes visada turime bent vieną skaitmenį, kad padarytume invariantus:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (iš to išplaukia, kad `remainder = vint % 10^(kappa+1)`)
        //
        //

        // padalykite `remainder` iš `10^kappa`.abu juos keičia `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ar buferis pilnas?paleiskite apvalinamąjį leidimą su likusia dalimi.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SAUGUMAS: inicijavome `len` daug baitų.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // pertraukite kilpą, kai pateiksime visus vientisus skaitmenis.
        // tikslus skaitmenų skaičius yra `max_kappa + 1` kaip `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // atkurti invariantus
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // perduoti trupmenines dalis.
    //
    // iš esmės galime tęsti paskutinį turimą skaitmenį ir patikrinti tikslumą.
    // deja, mes dirbame su baigtinio dydžio sveikaisiais skaičiais, todėl mums reikia tam tikro kriterijaus, kad aptiktume perpildymą.
    // V8 naudoja `remainder > err`, kuris tampa klaidingas, kai skiriasi pirmieji reikšmingi `v - 1 ulp` ir `v` skaitmenys.
    // tačiau tai atmeta per daug kitu atveju galiojančio įvesties.
    //
    // kadangi vėlesniame etape yra teisingas perpildymo aptikimas, mes naudojame griežtesnį kriterijų:
    // mes tęsiame tol, kol `err` viršija `10^kappa / 2`, todėl diapazone tarp `v - 1 ulp` ir `v + 1 ulp` neabejotinai yra du ar daugiau suapvalintų vaizdų.
    //
    // tai tas pats, kas nuoroda į pirmuosius du " `possibly_round` palyginimus.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariantai, kur `m = max_kappa + 1` (skaitmenų skaičius neatsiejamoje dalyje):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // neperpildys, `2^e * 10 < 2^64`
        err *= 10; // neperpildys, `err * 10 < 2^e * 5 < 2^64`

        // padalykite `remainder` iš `10^kappa`.
        // abu juos keičia `2^e / 10^kappa`, todėl pastarasis čia yra numanomas.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // ar buferis pilnas?paleiskite apvalinamąjį leidimą su likusia dalimi.
        if i == len {
            // SAUGUMAS: inicijavome `len` daug baitų.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // atkurti invariantus
        remainder = r;
    }

    // tolesnis skaičiavimas yra nenaudingas (`possibly_round` tikrai nepavyksta), todėl mes atsisakome.
    return None;

    // sugeneravome visus prašomus `v` skaitmenis, kurie taip pat turėtų sutapti su atitinkamais `v - 1 ulp` skaitmenimis.
    // dabar mes patikriname, ar yra unikalus atvaizdavimas, kurį bendrai naudoja ir `v - 1 ulp`, ir `v + 1 ulp`;tai gali būti tas pats generuojamiems skaitmenims arba suapvalinta tų skaitmenų versija.
    //
    // jei diapazone yra keli to paties ilgio vaizdai, negalime būti tikri ir vietoj to turėtume grąžinti `None`.
    //
    // visi čia pateikti argumentai yra apskaičiuoti pagal bendrą (bet numanomą) vertę `k`, kad:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SAUGUMAS: pirmieji `len` baitai turi būti inicializuoti.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (nuoroda, punktyrinė linija nurodo tikslią galimų atvaizdų vertę nurodytu skaitmenų skaičiumi.)
        //
        //
        // klaida yra per didelė, kad tarp `v - 1 ulp` ir `v + 1 ulp` yra bent trys galimi vaizdai.
        // mes negalime nustatyti, kuris iš jų yra teisingas.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // tiesą sakant, 1/2 ulp pakanka pristatyti du galimus vaizdus.
        // (atminkite, kad mums reikalingas unikalus tiek `v - 1 ulp`, tiek " v + 1 ulp` atvaizdavimas.) tai neperpildys, nes `ulp < ten_kappa` nuo pirmo patikrinimo.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // jei `v + 1 ulp` yra arčiau suapvalinto paveikslo (kuris jau yra `buf`), tada galime saugiai grįžti.
        // atkreipkite dėmesį, kad `v - 1 ulp` * gali būti mažesnis už dabartinį vaizdą, tačiau kaip `1 ulp < 10^kappa / 2` šios sąlygos pakanka:
        // atstumas tarp `v - 1 ulp` ir dabartinio atvaizdavimo negali viršyti `10^kappa / 2`.
        //
        // sąlyga lygi `remainder + ulp < 10^kappa / 2`.
        // kadangi tai gali lengvai perpildyti, pirmiausia patikrinkite, ar " `remainder < 10^kappa / 2`.
        // mes jau patikrinome, ar " `ulp < 10^kappa / 2`, todėl kol " `10^kappa` vis dėlto neperpildė, antrasis patikrinimas yra tinkamas.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SAUGUMAS: mūsų skambintojas inicijavo tą atmintį.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------likusi dalis-- ----> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // kita vertus, jei " `v - 1 ulp` yra arčiau suapvalinto paveikslo, turėtume suapvalinti aukštyn ir grįžti.
        // dėl tos pačios priežasties mums nereikia tikrinti " `v + 1 ulp`.
        //
        // sąlyga lygi `remainder - ulp >= 10^kappa / 2`.
        // dar kartą pirmiausia patikriname, ar `remainder > ulp` (atkreipkite dėmesį, kad tai nėra `remainder >= ulp`, nes `10^kappa` niekada nėra nulis).
        //
        // taip pat atkreipkite dėmesį, kad `remainder - ulp <= 10^kappa`, todėl antrasis patikrinimas neperpildomas.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SAUGUMAS: mūsų skambintojas turi inicializuoti šią atmintį.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // Pridėkite papildomą skaitmenį tik tada, kai mums bus pareikalauta fiksuoto tikslumo.
                // taip pat turime patikrinti, ar, jei pradinis buferis buvo tuščias, papildomą skaitmenį galima pridėti tik tada, kai `exp == limit` (edge atvejis).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SAUGA: mes ir mūsų skambintojas inicializavome tą atmintį.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // kitaip mes esame pasmerkti (ty kai kurios vertės tarp `v - 1 ulp` ir `v + 1 ulp` apvalinamos žemyn, o kitos-didėja) ir atsisakome.
        //
        None
    }
}

/// Tikslus ir fiksuotas " Grisu`su " Dragon` atsarginiu režimu įgyvendinimas.
///
/// Tai turėtų būti naudojama daugeliu atvejų.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SAUGUMAS: skolinimosi tikrintuvas nėra pakankamai protingas, kad leistų mums naudotis " `buf`
    // antrame " branch`, todėl mes čia plauname visą gyvenimą.
    // Bet mes vėl naudojame `buf` tik tuo atveju, jei `format_exact_opt` grąžino `None`, taigi tai gerai.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}