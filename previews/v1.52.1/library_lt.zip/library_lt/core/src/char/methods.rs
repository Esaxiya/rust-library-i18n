//! impl simbolis {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Didžiausias galimas kodo taškas, kurį gali turėti " `char`.
    ///
    /// " `char` yra " [Unicode Scalar Value], o tai reiškia, kad tai yra " [Code Point], bet tik tam tikrame diapazone.
    /// `MAX` yra didžiausias galiojantis kodo taškas, galiojantis " [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () naudojamas " Unicode`, kad atspindėtų dekodavimo klaidą.
    ///
    /// Tai gali atsitikti, pavyzdžiui, suteikiant netinkamai suformuotus UTF-8 baitus " [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// " [Unicode](http://www.unicode.org/) versija, kuria remiasi " Unicode` `char` ir `str` metodų dalys.
    ///
    /// Reguliariai leidžiamos naujos " Unicode`versijos, vėliau atnaujinami visi standartinėje bibliotekoje esantys metodai, atsižvelgiant į " Unicode`.
    /// Todėl kai kurių `char` ir `str` metodų elgesys ir šios konstantos vertė laikui bėgant keičiasi.
    /// Tai *nėra* laikoma lūžiu.
    ///
    /// Versijų numeravimo schema paaiškinta [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Sukuria iteratorių per UTF-16 užkoduotus kodo taškus `iter`, grąžindamas neporinius pakaitalus kaip " Err`.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Nuostolų dekoderį galima gauti pakeitus `Err` rezultatus pakeičiančiu simboliu:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` paverčia `char`.
    ///
    /// Atkreipkite dėmesį, kad visi " char`ženklai galioja [" u32`] ir juos galima perduoti į vieną
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tačiau atvirkščiai nėra tiesa: ne visi galiojantys [`u32`] simboliai yra teisingi.
    /// `from_u32()` grąžins `None`, jei įvestis nėra tinkama `char` reikšmė.
    ///
    /// Norėdami sužinoti apie nesaugią šios funkcijos versiją, kuri nepaiso šių patikrinimų, žr. [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Grąžinama `None`, kai įvestis neteisinga `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konvertuoja `u32` į `char`, nepaisydamas galiojimo.
    ///
    /// Atkreipkite dėmesį, kad visi " char`ženklai galioja [" u32`] ir juos galima perduoti į vieną
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Tačiau atvirkščiai nėra tiesa: ne visi galiojantys [`u32`] simboliai yra teisingi.
    /// `from_u32_unchecked()` to nepaisys ir aklai persiųs į " `char`, galbūt sukurdamas netinkamą.
    ///
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi, nes gali sukonstruoti neteisingas `char` reikšmes.
    ///
    /// Norėdami sužinoti saugią šios funkcijos versiją, žr. [`from_u32`] funkciją.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SAUGUMAS: saugos sutartį privalo palaikyti skambinantysis.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konvertuoja nurodytos radikso skaitmenį į `char`.
    ///
    /// Čia 'radix' kartais dar vadinamas 'base'.
    /// Dviejų radiksas rodo dvejetainį skaičių, dešimtosios, dešimtosios ir šešiolikos, šešioliktainės, kad suteiktų kai kurias bendras reikšmes.
    ///
    /// Palaikomos savavališkos radiacijos.
    ///
    /// `from_digit()` grąžins `None`, jei įvestis nėra skaitmuo nurodytoje spindulyje.
    ///
    /// # Panics
    ///
    /// Panics, jei radiksas yra didesnis nei 36.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Dešimtainis skaičius yra 16 skaitmenų vienas skaitmuo
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` grąžinimas, kai įvestis nėra skaitmuo:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Perėjęs didelį radiksą, sukeldamas panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Tikrina, ar `char` yra skaitmuo nurodytame radikse.
    ///
    /// Čia 'radix' kartais dar vadinamas 'base'.
    /// Dviejų radiksas rodo dvejetainį skaičių, dešimtosios, dešimtosios ir šešiolikos, šešioliktainės, kad suteiktų kai kurias bendras reikšmes.
    ///
    /// Palaikomos savavališkos radiacijos.
    ///
    /// Palyginti su [`is_numeric()`], ši funkcija atpažįsta tik simbolius `0-9`, `a-z` ir `A-Z`.
    ///
    /// 'Digit' apibrėžiamas tik šie simboliai:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Norėdami išsamiau suprasti 'digit', žr. [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, jei radiksas yra didesnis nei 36.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Perėjęs didelį radiksą, sukeldamas panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` paverčia skaitmeniu nurodytoje spindulyje.
    ///
    /// Čia 'radix' kartais dar vadinamas 'base'.
    /// Dviejų radiksas rodo dvejetainį skaičių, dešimtosios, dešimtosios ir šešiolikos, šešioliktainės, kad suteiktų kai kurias bendras reikšmes.
    ///
    /// Palaikomos savavališkos radiacijos.
    ///
    /// 'Digit' apibrėžiamas tik šie simboliai:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Pateikia `None`, jei `char` nenurodo skaitmens nurodytame radikse.
    ///
    /// # Panics
    ///
    /// Panics, jei radiksas yra didesnis nei 36.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Perėjus ne skaitmenį, nepavyksta:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Perėjęs didelį radiksą, sukeldamas panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kodas yra padalintas čia, siekiant pagerinti vykdymo greitį tais atvejais, kai `radix` yra pastovus ir 10 ar mažesnis
        //
        let val = if likely(radix <= 10) {
            // Jei ne skaitmuo, bus sukurtas didesnis už radiksą skaičius.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Pateikia iteratorių, suteikiantį simbolio kaip " char`s` pabėgimą iš šešioliktainio " Unicode`.
    ///
    /// Tai išvengs simbolių su formos 0Rust sintakse `\u{NNNNNN}`, kur `NNNNNN` yra šešioliktainis simbolis.
    ///
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // arba " 1` užtikrina, kad jei c==0, kodas apskaičiuoja, kad turėtų būti atspausdintas vienas skaitmuo, ir (kas yra tas pats) išvengiama perpildymo (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // reikšmingiausio šešiaženklio indeksas
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Išplėstinė " `escape_debug` versija, kuri pasirinktinai leidžia išvengti " Extended Grapheme` kodo taškų.
    /// Tai leidžia mums geriau suformatuoti simbolius, pvz., Nesutampančius ženklus, kai jie yra eilutės pradžioje.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Pateikia iteratorių, kuris pateikia tiesioginį simbolio pabėgimo kodą kaip " char`.
    ///
    /// Tai išvengs simbolių, panašių į `Debug` `str` arba `char` diegimus.
    ///
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Pateikia iteratorių, kuris pateikia tiesioginį simbolio pabėgimo kodą kaip " char`.
    ///
    /// Numatytasis pasirinkimas pasirenkamas šališkai linkus gaminti pažodžiui, kuris yra legalus įvairiomis kalbomis, įskaitant C++ 11 ir panašias C šeimos kalbas.
    /// Tikslios taisyklės yra:
    ///
    /// * Skirtukas išvengtas kaip `\t`.
    /// * Vežimo grąžinimas išvengiamas kaip `\r`.
    /// * Linijos tiekimas išvengtas kaip `\n`.
    /// * Vienos citatos išvengta kaip `\'`.
    /// * Dviguba citata išvengta kaip `\"`.
    /// * Backslash yra išvengta kaip `\\`.
    /// * Nei vienas simbolis, esantis " spausdinamo ASCII` diapazone `0x20` .. `0x7e` imtinai, neištrinamas.
    /// * Visiems kitiems simboliams suteikiami šešioliktainiai " Unicode` pabėgimai;žr. [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Pateikia baitų, kurių prireiks `char`, jei užkoduotas UTF-8, skaičių.
    ///
    /// Šis baitų skaičius visada yra nuo 1 iki 4 imtinai.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// " `&str` tipas garantuoja, kad jo turinys yra " UTF-8, todėl galime palyginti ilgį, kurio prireiktų, jei kiekvienas kodo taškas būtų vaizduojamas kaip `char`, palyginti su pačiu `&str`:
    ///
    ///
    /// ```
    /// // kaip simboliai
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // abu gali būti pavaizduoti kaip trys baitai
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kaip &str, šie du yra užkoduoti UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // matome, kad jie užima iš viso šešis baitus ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... kaip ir " &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Pateikia 16 bitų kodo vienetų, kurių `char` prireiks, jei užkoduotas UTF-16, skaičių.
    ///
    ///
    /// Norėdami sužinoti daugiau apie šią koncepciją, žr. " [`len_utf8()`] dokumentaciją.
    /// Ši funkcija yra veidrodis, bet UTF-16 vietoj UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Užkoduoja šį simbolį kaip UTF-8 į pateiktą baitų buferį, tada grąžina buferio, kuriame yra užkoduotas simbolis, poskyrį.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jei buferis nėra pakankamai didelis.
    /// Keturių ilgių buferis yra pakankamai didelis, kad užkoduotų bet kurį " `char`.
    ///
    /// # Examples
    ///
    /// Abiejuose šiuose pavyzdžiuose 'ß' užkoduoti reikia dviejų baitų.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Per mažas buferis:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SAUGUMAS: `char` nėra pakaitalas, todėl tai galioja UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Užkoduoja šį simbolį kaip UTF-16 į pateiktą `u16` buferį, tada grąžina buferio, kuriame yra užkoduotas simbolis, poskyrį.
    ///
    ///
    /// # Panics
    ///
    /// Panics, jei buferis nėra pakankamai didelis.
    /// 2 ilgio buferis yra pakankamai didelis, kad užkoduotų bet kurį `char`.
    ///
    /// # Examples
    ///
    /// Abiejuose šiuose pavyzdžiuose '𝕊' užkoduoti reikia du " u16`.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Per mažas buferis:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Pateikia `true`, jei šis `char` turi ypatybę `Alphabetic`.
    ///
    /// `Alphabetic` yra aprašytas [Unicode Standard] 4 skyriuje (Simbolių ypatybės) ir nurodytas [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // meilė yra daug dalykų, tačiau ji nėra abėcėlės
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Pateikia `true`, jei šis `char` turi ypatybę `Lowercase`.
    ///
    /// `Lowercase` yra aprašytas [Unicode Standard] 4 skyriuje (Simbolių ypatybės) ir nurodytas [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Įvairūs kiniški scenarijai ir skyryba neturi didžiųjų ir mažųjų raidžių:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Pateikia `true`, jei `char` turi `Uppercase` ypatybę.
    ///
    /// `Uppercase` yra aprašytas [Unicode Standard] 4 skyriuje (Simbolių ypatybės) ir nurodytas [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Įvairūs kiniški scenarijai ir skyryba neturi didžiųjų ir mažųjų raidžių:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Pateikia `true`, jei šis `char` turi ypatybę `White_Space`.
    ///
    /// `White_Space` yra nurodytas [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // nepertraukiama erdvė
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Pateikia `true`, jei šis `char` atitinka [`is_alphabetic()`] arba [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Pateikia `true`, jei ši `char` turi bendrą valdymo kodų kategoriją.
    ///
    /// Valdymo kodai (kodo taškai su bendrąja `Cc` kategorija) yra aprašyti [Unicode Standard] 4 skyriuje (Simbolių ypatybės) ir nurodyti [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // U + 009C, VIRŠUTINIS TERMINATORIUS
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Pateikia `true`, jei šis `char` turi ypatybę `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` yra aprašytas [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ir nurodytas [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Pateikia `true`, jei šioje `char` yra viena iš bendrųjų skaičių kategorijų.
    ///
    /// Bendros skaičių kategorijos (`Nd`-dešimtainiai skaitmenys, `Nl`-raidinius skaitmeninius simbolius ir `No`-kiti skaitiniai simboliai) nurodytos [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Pateikia iteratorių, kuriame gaunamos šios `char` mažosios raidės kaip vienas ar daugiau
    /// `char`s.
    ///
    /// Jei šiame `char` nėra mažųjų atvaizdavimo, iteratorius pateikia tą patį `char`.
    ///
    /// Jei šis " `char` turi " vienas su vienu` mažųjų raidžių atvaizdavimą, pateiktą " [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratorius duoda tą `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jei šiam `char` reikalingi specialūs svarstymai (pvz., Keli " char`ženklai), iteratorius pateikia [`SpecialCasing.txt`] pateiktą " char`.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ši operacija atlieka besąlygišką kartografavimą be siuvimo.Tai yra, konversija nepriklauso nuo konteksto ir kalbos.
    ///
    /// " [Unicode Standard] 4 skyriuje (Simbolių ypatybės) aptariamas atvejų kartografavimas apskritai, o 3 skyriuje (Conformance)-numatytasis algoritmas atvejų konvertavimui.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Kartais rezultatas yra daugiau nei vienas simbolis:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Simboliai, kuriuose nėra didžiųjų ir mažųjų raidžių, paverčiami savimi.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Pateikia iteratorių, kuriame gaunamos šios `char` didžiosios raidės kaip vienas ar daugiau
    /// `char`s.
    ///
    /// Jei šis `char` neturi didžiųjų atvaizdų, iteratorius pateikia tą patį `char`.
    ///
    /// Jei šis `char` turi didelių raidžių susiejimą " vienas su vienu`, pateiktą " [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratorius duoda tą `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jei šiam `char` reikalingi specialūs svarstymai (pvz., Keli " char`ženklai), iteratorius pateikia [`SpecialCasing.txt`] pateiktą " char`.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ši operacija atlieka besąlygišką kartografavimą be siuvimo.Tai yra, konversija nepriklauso nuo konteksto ir kalbos.
    ///
    /// " [Unicode Standard] 4 skyriuje (Simbolių ypatybės) aptariamas atvejų kartografavimas apskritai, o 3 skyriuje (Conformance)-numatytasis algoritmas atvejų konvertavimui.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kaip iteratorius:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Tiesiogiai naudojant " `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Abu yra tolygūs:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Naudojant " `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Kartais rezultatas yra daugiau nei vienas simbolis:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Simboliai, kuriuose nėra didžiųjų ir mažųjų raidžių, paverčiami savimi.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Pastaba dėl lokalės
    ///
    /// Turkų kalba 'i' atitikmuo lotynų kalba turi penkias formas, o ne dvi:
    ///
    /// * 'Dotless': Aš/ı, kartais parašyta ï
    /// * 'Dotted': İ/i
    ///
    /// Atkreipkite dėmesį, kad mažosiomis raidėmis pažymėtas 'i' yra tas pats, kas lotyniškas.Todėl:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` reikšmė čia priklauso nuo teksto kalbos: jei esame `en-US`, tai turėtų būti `"I"`, bet jei `tr_TR`, tai turėtų būti `"İ"`.
    /// `to_uppercase()` į tai neatsižvelgia, taigi:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// galioja visose kalbose.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Tikrina, ar vertė yra ASCII diapazone.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Padaro vertės kopiją didžiosiomis raidėmis pagal ASCII.
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje didinti vertę, naudokite [`make_ascii_uppercase()`].
    ///
    /// Jei norite ne tik ASCII, bet ir ASCII simbolius, naudokite [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Padaro vertės kopiją mažosiomis ASCII raidėmis.
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje mažinti vertę, naudokite [`make_ascii_lowercase()`].
    ///
    /// Jei norite ne tik ASCII, bet ir ASCII simbolius, naudokite [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Patikrina, ar dvi reikšmės nesutampa su ASCII.
    ///
    /// Atitinka `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konvertuoja šį tipą į jo ASCII didžiųjų raidžių atitikmenį vietoje.
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Norėdami grąžinti naują didžiosios vertės reikšmę nekeisdami esamos, naudokite [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konvertuoja šį tipą į jo ASCII mažąsias raides, lygiavertes vietoje.
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite grąžinti naują mažosios raidės vertę nekeisdami esamos, naudokite [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Tikrina, ar reikšmė yra ASCII abėcėlės simbolis:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', arba
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Tikrina, ar reikšmė yra ASCII didžioji raidė:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Tikrina, ar reikšmė yra ASCII mažoji raidė:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Tikrina, ar vertė yra raidinis ir skaitinis ASCII simbolis:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', arba
    /// - U + 0061 'a' ..=U + 007A 'z', arba
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Tikrina, ar vertė yra ASCII dešimtainis skaitmuo:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Tikrina, ar vertė yra ASCII šešioliktainis skaitmuo:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', arba
    /// - U + 0041 'A' ..=U + 0046 'F', arba
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Tikrina, ar reikšmė yra ASCII skyrybos ženklas:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, arba
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, arba
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, arba
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Tikrina, ar reikšmė yra ASCII grafinis simbolis:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Tikrina, ar reikšmė yra ASCII tarpo simbolis:
    /// U + 0020 SPACE, U + 0009 HORIZONTALUS LENTELĖ, U + 000A LINE FEED, U + 000C FORMA FEED arba U + 000D VEŽIMO GRĄŽINIMAS.
    ///
    /// " Rust`naudoja " WhatWG Infra Standard` [definition of ASCII whitespace][infra-aw].Yra keletas kitų plačiai naudojamų apibrėžimų.
    /// Pavyzdžiui, [the POSIX locale][pct] apima U + 000B VERTICAL TAB, taip pat visus aukščiau nurodytus simbolius, tačiau iš tos pačios specifikacijos [numatytoji "field splitting" taisyklė Bourne shell][bfs] atsižvelgia tik į * SPACE, HORIZONTAL TAB ir EILUTINIS PAŠARAS kaip tarpas.
    ///
    ///
    /// Jei rašote programą, kuri apdoros esamą failo formatą, prieš naudodami šią funkciją patikrinkite, koks yra to formato baltosios erdvės apibrėžimas.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Tikrina, ar reikšmė yra ASCII valdymo simbolis:
    /// U + 0000 NUL ..=U + 001F VIENETŲ SKIRTUVAS arba U + 007F IŠTRINTI.
    /// Atminkite, kad dauguma ASCII tarpų yra kontroliniai simboliai, tačiau " SPACE` nėra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Užkoduoja neapdorotą u32 vertę kaip UTF-8 į pateiktą baitų buferį, tada grąžina buferio, kuriame yra užkoduotas simbolis, poskyrį.
///
///
/// Skirtingai nuo " `char::encode_utf8`, šis metodas taip pat tvarko pakaitalų diapazono kodo taškus.
/// (`char` sukūrimas pakaitiniame diapazone yra UB.) Rezultatas galioja [generalized UTF-8], bet negalioja UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, jei buferis nėra pakankamai didelis.
/// Keturių ilgių buferis yra pakankamai didelis, kad užkoduotų bet kurį " `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Užkoduoja neapdorotą u32 vertę kaip UTF-16 į pateiktą `u16` buferį, tada grąžina buferio, kuriame yra užkoduotas simbolis, poskyrį.
///
///
/// Skirtingai nuo " `char::encode_utf16`, šis metodas taip pat tvarko pakaitalų diapazono kodo taškus.
/// (`char` sukūrimas pakaitiniame diapazone yra UB.)
///
/// # Panics
///
/// Panics, jei buferis nėra pakankamai didelis.
/// 2 ilgio buferis yra pakankamai didelis, kad užkoduotų bet kurį `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAUGUMAS: kiekviena ranka patikrina, ar yra pakankamai bitų, kad galėtumėte įrašyti
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP krenta
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Papildomos plokštumos skyla į pakaitalus.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}