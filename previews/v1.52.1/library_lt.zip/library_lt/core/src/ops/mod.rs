//! Perkraunami operatoriai.
//!
//! Įdiegę šiuos " traits` galite perkrauti tam tikrus operatorius.
//!
//! Kai kuriuos iš šių " traits`importuoja " prelude`, todėl jie yra prieinami kiekvienoje " Rust`programoje.Perkrauti gali tik tie operatoriai, kuriuos remia " traits`.
//! Pvz., Papildymo operatorius (`+`) gali būti perkrautas per [`Add`] trait, tačiau kadangi priskyrimo operatorius (`=`) neturi pagrindo trait, jokiu būdu negalima perkrauti jo semantikos.
//! Be to, šiame modulyje nėra jokio mechanizmo, kaip sukurti naujus operatorius.
//! Jei reikalingas beprasmis perkrovimas ar pasirinktiniai operatoriai, turėtumėte ieškoti makrokomandų ar kompiliatoriaus įskiepių, kad išplėstumėte Rust sintaksę.
//!
//! Operatoriaus traits diegimas neturėtų nustebinti jų kontekstuose, turint omenyje jų įprastas reikšmes ir [operator precedence].
//! Pvz., Diegiant " [`Mul`], operacija turėtų būti šiek tiek panaši į dauginimą (ir dalytis tikėtinomis savybėmis, pvz., Asociatyvumu).
//!
//! Atkreipkite dėmesį, kad operatorių `&&` ir `||` trumpasis jungimas, ty jie vertina savo antrąjį operandą tik tuo atveju, jei tai prisideda prie rezultato.Kadangi traits šio elgesio neįmanoma įgyvendinti, `&&` ir `||` nepalaikomi kaip perkrovos operatoriai.
//!
//! Daugelis operatorių vertina savo operandus.Ne bendruose kontekstuose, susijusiuose su įmontuotais tipais, tai paprastai nėra problema.
//! Tačiau norint naudoti šias operacijas bendrame kode, reikia skirti tam tikrą dėmesį, o ne vertėms pakartotinai naudoti, o ne leisti operatoriams jas vartoti.Viena iš galimybių yra retkarčiais naudoti " [`clone`].
//! Kita galimybė yra pasikliauti tipais, teikiančiais papildomas operatoriaus diegimo nuorodas.
//! Pvz., Vartotojo apibrėžtam `T` tipui, kuris turėtų palaikyti papildymą, tikriausiai yra gera idėja, kad `T` ir `&T` įdiegtų traits [`Add<T>`][`Add`] ir [`Add<&T>`][`Add`], kad bendrąjį kodą būtų galima parašyti be nereikalingo klonavimo.
//!
//!
//! # Examples
//!
//! Šis pavyzdys sukuria `Point` struktūrą, kuri įgyvendina [`Add`] ir [`Sub`], ir tada parodo, kaip pridėti ir atimti du taškus.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Įgyvendinimo pavyzdį rasite kiekvieno " trait` dokumentacijoje.
//!
//! " [`Fn`], " [`FnMut`] ir " [`FnOnce`] traits` yra įgyvendinami pagal tipus, kuriuos galima naudoti kaip funkcijas.Atminkite, kad [`Fn`] užima `&self`, [`FnMut`] užima `&mut self`, o [`FnOnce`] užima `self`.
//! Tai atitinka trijų rūšių metodus, kuriais galima pasinaudoti egzemplioriuje: " call-by-reference`, call-by-mutable-reference ir call-by-value.
//! Dažniausias šių " traits` naudojimas yra veikti kaip ribos aukštesnio lygio funkcijoms, kurios funkcijas ar uždarymus laiko argumentais.
//!
//! [`Fn`] kaip parametras:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! [`FnMut`] kaip parametras:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! [`FnOnce`] kaip parametras:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` sunaudoja užfiksuotus kintamuosius, todėl jo negalima paleisti daugiau nei vieną kartą
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Bandant dar kartą iškviesti `func()`, `func` bus sukelta `use of moved value` klaida
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` šiuo metu nebegalima remtis
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;