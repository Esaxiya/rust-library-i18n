/// Skambučio operatoriaus versija, naudojanti nekintamą imtuvą.
///
/// `Fn` egzempliorius galima pakartotinai iškviesti be mutacijos būsenos.
///
/// *Šio " trait (`Fn`) negalima painioti su " [function pointers] (`fn`).*
///
/// `Fn` yra automatiškai įgyvendinamas uždarymo būdu, kuriame pateikiamos tik nekintamos nuorodos į užfiksuotus kintamuosius arba nieko neužfiksuojama, taip pat (safe) [function pointers] (su tam tikromis išlygomis daugiau informacijos rasite jų dokumentacijose).
///
/// Be to, bet kokiam `F` tipui, kuris įgyvendina `Fn`, `&F` taip pat įgyvendina `Fn`.
///
/// Kadangi ir [`FnMut`], ir [`FnOnce`] yra `Fn` supertranšetai, bet kuris `Fn` egzempliorius gali būti naudojamas kaip parametras, kur tikimasi [`FnMut`] arba [`FnOnce`].
///
/// Naudokite " `Fn` kaip įrištą, kai norite priimti panašaus į funkciją tipo parametrą ir turite jį iškviesti pakartotinai ir nemutuodami būsenos (pvz., Kai skambinate tuo pačiu metu).
/// Jei jums nereikia tokių griežtų reikalavimų, naudokite [`FnMut`] arba [`FnOnce`] kaip ribas.
///
/// Daugiau informacijos šia tema rasite " [chapter on closures in *The Rust Programming Language*][book].
///
/// Taip pat atkreiptinas dėmesys į specialią `Fn` traits sintaksę (pvz.,
/// `Fn(usize, bool) -> naudoti `).Tie, kurie domisi techninėmis detalėmis, gali kreiptis į " [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Skambinimas uždarymui
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametro naudojimas
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kad regex galėtų pasikliauti tuo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Atlieka skambučio operaciją.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Skambučio operatoriaus versija, naudojanti kintamą imtuvą.
///
/// " `FnMut` egzempliorius galima skambinti pakartotinai ir jie gali pakeisti būseną.
///
/// `FnMut` yra automatiškai įgyvendinamas uždarymo būdu, kuriame pateikiamos kintamos nuorodos į užfiksuotus kintamuosius, taip pat į visus tipus, kurie įgyvendina [`Fn`], pvz., (safe) [function pointers] (nes `FnMut` yra [`Fn`] supertaškas).
/// Be to, bet kokiam `F` tipui, kuris įgyvendina `FnMut`, `&mut F` taip pat įgyvendina `FnMut`.
///
/// Kadangi [`FnOnce`] yra `FnMut` supertaškas, galima naudoti bet kurį `FnMut` egzempliorių, kur tikimasi [`FnOnce`], o kadangi [`Fn`] yra `FnMut` subtranšatis, bet kurį [`Fn`] egzempliorių galima naudoti ten, kur tikimasi `FnMut`.
///
/// Naudokite " `FnMut` kaip įrištą, kai norite priimti panašaus į funkciją tipo parametrą ir turite jį pakartotinai iškviesti, leisdami jam mutuoti būseną.
/// Jei nenorite, kad parametras pakeistų būseną, naudokite [`Fn`] kaip susietą;jei jums nereikia skambinti pakartotinai, naudokite " [`FnOnce`].
///
/// Daugiau informacijos šia tema rasite " [chapter on closures in *The Rust Programming Language*][book].
///
/// Taip pat atkreiptinas dėmesys į specialią `Fn` traits sintaksę (pvz.,
/// `Fn(usize, bool) -> naudoti `).Tie, kurie domisi techninėmis detalėmis, gali kreiptis į " [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Skambinimas abejingai fiksuojančiu uždarymu
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametro naudojimas
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kad regex galėtų pasikliauti tuo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Atlieka skambučio operaciją.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Skambučio operatoriaus versija, kuri ima šalutinį imtuvą.
///
/// " `FnOnce` egzempliorius galima iškviesti, tačiau gali būti, kad jie nebus skambinami kelis kartus.Dėl to, jei apie tipą žinoma tik tai, kad jis įdiegia " `FnOnce`, jį galima iškviesti tik vieną kartą.
///
/// `FnOnce` yra automatiškai įgyvendinamas uždarymo priemonėmis, kurios gali sunaudoti užfiksuotus kintamuosius, taip pat visų tipų, įgyvendinančių [`FnMut`], pvz., (safe) [function pointers] (kadangi `FnOnce` yra [`FnMut`] supertaškas).
///
///
/// Kadangi tiek " [`Fn`], tiek " [`FnMut`] yra " `FnOnce` porūšiai, galima naudoti bet kokius [`Fn`] arba [`FnMut`] egzempliorius, kai tikimasi `FnOnce`.
///
/// Naudokite " `FnOnce` kaip susietą, kai norite priimti panašaus į funkciją tipo parametrą ir jums reikia jį iškviesti tik vieną kartą.
/// Jei jums reikia pakartotinai iškviesti parametrą, naudokite [`FnMut`] kaip susietą;jei jums taip pat reikia, kad būklė nebūtų mutuota, naudokite [`Fn`].
///
/// Daugiau informacijos šia tema rasite " [chapter on closures in *The Rust Programming Language*][book].
///
/// Taip pat atkreiptinas dėmesys į specialią `Fn` traits sintaksę (pvz.,
/// `Fn(usize, bool) -> naudoti `).Tie, kurie domisi techninėmis detalėmis, gali kreiptis į " [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametro naudojimas
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` sunaudoja užfiksuotus kintamuosius, todėl jo negalima paleisti daugiau nei vieną kartą.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Bandant dar kartą iškviesti `func()`, `func` bus sukelta `use of moved value` klaida.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` šiuo metu nebegalima remtis
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // kad regex galėtų pasikliauti tuo `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Grąžintas tipas po skambučio operatoriaus naudojimo.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Atlieka skambučio operaciją.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}