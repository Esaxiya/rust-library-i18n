use crate::marker::Unpin;
use crate::pin::Pin;

/// Generatoriaus atnaujinimo rezultatas.
///
/// Ši reikšmė grąžinama iš `Generator::resume` metodo ir nurodo galimas generatoriaus grąžinimo vertes.
/// Šiuo metu tai atitinka pakabos tašką (`Yielded`) arba galinį tašką (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generatorius pakabintas su verte.
    ///
    /// Ši būsena rodo, kad generatorius buvo sustabdytas ir paprastai atitinka `yield` sakinį.
    /// Šiame variante pateikta vertė atitinka išraišką, perduotą `yield`, ir leidžia generatoriams pateikti vertę kiekvieną kartą, kai duoda.
    ///
    ///
    Yielded(Y),

    /// Generatorius sukomplektuotas su grįžtamąja verte.
    ///
    /// Ši būsena rodo, kad generatorius baigė vykdyti nurodytą vertę.
    /// Generatoriui grąžinus `Complete`, laikoma, kad programuotojo klaida dar kartą paskambinti į `resume`.
    ///
    Complete(R),
}

/// " trait`, kurį įdiegė įmontuoti generatorių tipai.
///
/// Generatoriai, taip pat paprastai vadinami korutinais, šiuo metu yra eksperimentinė Rust kalbos funkcija.
/// Šiuo metu " [RFC 2033] pridėti generatoriai pirmiausia skirti sukurti async/await sintaksės pagrindą, tačiau greičiausiai bus išplėsti ir pateikti ergonomišką apibrėžimą iteratoriams ir kitiems primityviems elementams.
///
///
/// Generatorių sintaksė ir semantika yra nestabili, todėl stabilizavimui reikės dar vieno RFC.Tačiau šiuo metu sintaksė yra panaši į uždarymą:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Daugiau generatorių dokumentų galite rasti nestabilioje knygoje.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Vertės tipas, kurį suteikia šis generatorius.
    ///
    /// Šis susietas tipas atitinka `yield` išraišką ir reikšmes, kurias leidžiama grąžinti kiekvieną kartą, kai generatorius duoda.
    ///
    /// Pvz., Iteratorius kaip generatorius greičiausiai turės šį tipą kaip `T`, tipas bus kartojamas.
    ///
    type Yield;

    /// Vertės, kurią grąžina šis generatorius, tipas.
    ///
    /// Tai atitinka tipą, grąžintą iš generatoriaus su `return` sakiniu arba netiesiogiai kaip paskutinę generatoriaus pažodinio išraišką.
    /// Pvz., futures tai naudos kaip `Result<T, E>`, nes tai reiškia užbaigtą future.
    ///
    ///
    type Return;

    /// Atnaujinamas šio generatoriaus vykdymas.
    ///
    /// Ši funkcija atnaujins generatoriaus vykdymą arba pradės vykdyti, jei dar to nepadarė.
    /// Šis skambutis grįš į paskutinį generatoriaus sustabdymo tašką ir bus atnaujintas vykdant naujausią " `yield`.
    /// Generatorius tęs vykdymą, kol jis duos arba grįš, tada grįš ši funkcija.
    ///
    /// # Grąžinimo vertė
    ///
    /// `GeneratorState` enum, grąžintas iš šios funkcijos, nurodo, kurioje būsenoje generatorius yra grįžęs.
    /// Jei grąžinamas `Yielded` variantas, generatorius pasiekė pakabos tašką ir buvo išleista vertė.
    /// Šios būsenos generatoriai gali būti atnaujinti vėliau.
    ///
    /// Jei grąžinama `Complete`, generatorius visiškai baigė savo nurodytą vertę.Netinkama, jei generatorius vėl bus atnaujintas.
    ///
    /// # Panics
    ///
    /// Ši funkcija gali būti panic, jei ji iškviečiama po to, kai anksčiau buvo grąžintas `Complete` variantas.
    /// Nors generatoriaus pažodžiui ta kalba garantuojama, kad panic bus atnaujintas po `Complete`, tai nėra garantuota visoms " `Generator` trait` versijoms.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}