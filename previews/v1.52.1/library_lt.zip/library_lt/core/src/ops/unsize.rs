use crate::marker::Unsize;

/// Trait, nurodantis, kad tai yra rodyklė arba vieneto įvyniojimo priemonė, kur gali būti atliekamas dydžio sumažinimas.
///
/// Norėdami gauti daugiau informacijos, žiūrėkite " [DST coercion RFC][dst-coerce] ir " [the nomicon entry on coercion][nomicon-coerce].
///
/// Įtaisytų žymeklių tipams žymekliai į `T` privers rodiklius į `U`, jei `T: Unsize<U>`, konvertuojant iš plonos žymeklio į riebalų rodyklę.
///
/// Pasirinktinių tipų atveju prievarta čia veikia verčiant `Foo<T>` į `Foo<U>`, jei egzistuoja `CoerceUnsized<Foo<U>> for Foo<T>` implikacija.
/// Tokį impliką galima parašyti tik tuo atveju, jei `Foo<T>` turi tik vieną nefantomduomenų lauką, kuriame yra `T`.
/// Jei to lauko tipas yra `Bar<T>`, turi būti įdiegtas `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Prievarta veiks priverčiant `Bar<T>` lauką į `Bar<U>` ir užpildant likusius laukus nuo `Foo<T>`, kad būtų sukurtas `Foo<U>`.
/// Tai efektyviai išnagrinės rodyklės lauką ir priverstinai tai padarys.
///
/// Paprastai išmaniesiems rodyklėms įdiegsite " `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` su pasirinktiniu " `?Sized`, susietu su pačiu " `T`.
/// Jei naudojate apvalkalų tipus, kurie tiesiogiai įdeda " `T`, pvz., " `Cell<T>` ir " `RefCell<T>`, galite tiesiogiai įdiegti " `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Tai leis veikti tokio tipo prievartoms kaip " `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] yra naudojamas žymėti tipus, kurie gali būti verčiami DST, jei už rodyklių.Kompiliatorius ją įgyvendina automatiškai.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Tai naudojama objekto saugumui patikrinti, ar galima išsiųsti metodo imtuvo tipą.
///
/// trait įgyvendinimo pavyzdys:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}