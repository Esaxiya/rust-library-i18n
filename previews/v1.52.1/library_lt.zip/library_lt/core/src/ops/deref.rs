/// Naudojamas nekintamoms dereferencinėms operacijoms, pvz., `*v`.
///
/// Be to, kad `Deref` yra naudojamas aiškioms derybų operacijoms su (unary) `*` operatoriumi nekintamuose kontekstuose, kompiliatorius taip pat netiesiogiai naudoja daugeliu atvejų.
/// Šis mechanizmas vadinamas ['`Deref` coercion'][more].
/// Kintamuose kontekstuose naudojamas [`DerefMut`].
///
/// Įdiegus " `Deref`, skirtą išmaniesiems rodyklėms, patogu pasiekti prie jų esančius duomenis, todėl jie įdiegia " `Deref`.
/// Kita vertus, taisyklės, susijusios su " `Deref` ir " [`DerefMut`], buvo sukurtos specialiai tam, kad būtų pritaikytos išmaniesiems rodyklėms.
/// Dėl šios priežasties **" Deref` turėtų būti įdiegta tik išmaniesiems rodyklėms**, kad būtų išvengta painiavos.
///
/// Dėl panašių priežasčių **šis trait niekada neturėtų sugesti**.Nesėkmė atsiminimų metu gali būti labai painu, kai `Deref` yra kviečiama netiesiogiai.
///
/// # Daugiau apie `Deref` prievartą
///
/// Jei `T` įgyvendina `Deref<Target = U>`, o `x` yra `T` tipo vertė, tada:
///
/// * Nekintamuose kontekstuose `*x` (kur `T` nėra nei nuoroda, nei neapdorotas rodyklė) yra lygiavertis `* Deref::deref(&x)`.
/// * `&T` tipo vertės yra verčiamos į `&U` tipo vertes
/// * `T` netiesiogiai įgyvendina visus `U` tipo (immutable) metodus.
///
/// Norėdami gauti daugiau informacijos, apsilankykite [the chapter in *The Rust Programming Language*][book], taip pat [the dereference operator][ref-deref-op], [method resolution] ir [type coercions] skyriuose.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktūra, turinti vieną lauką, prieinamą nukrypstant nuo struktūros.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Gautas tipas po nukrypimo.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Nukreipia vertę.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Naudojamas kintamoms diferenciacijos operacijoms, pvz., Naudojant `*v = 1;`.
///
/// Be to, kad `DerefMut` yra naudojamas aiškioms derybų operacijoms su (unary) `*` operatoriumi kintančiuose kontekstuose, kompiliatorius taip pat netiesiogiai naudoja daugeliu atvejų.
/// Šis mechanizmas vadinamas ['`Deref` coercion'][more].
/// Nekintamuose kontekstuose naudojamas [`Deref`].
///
/// Įdiegus " `DerefMut`, skirtą išmaniesiems rodyklėms, patogu mutuoti už jų esančius duomenis, todėl jie įdiegia " `DerefMut`.
/// Kita vertus, taisyklės, susijusios su " [`Deref`] ir " `DerefMut`, buvo sukurtos specialiai tam, kad būtų pritaikytos išmaniesiems rodyklėms.
/// Dėl šios priežasties **" DerefMut` turėtų būti įdiegta tik išmaniesiems rodyklėms**, kad būtų išvengta painiavos.
///
/// Dėl panašių priežasčių **šis trait niekada neturėtų sugesti**.Nesėkmė atsiminimų metu gali būti labai painu, kai `DerefMut` yra kviečiama netiesiogiai.
///
/// # Daugiau apie `Deref` prievartą
///
/// Jei `T` įgyvendina `DerefMut<Target = U>`, o `x` yra `T` tipo vertė, tada:
///
/// * Kintamuose kontekstuose `*x` (kur `T` nėra nei nuoroda, nei neapdorotas rodyklė) yra lygiavertis `* DerefMut::deref_mut(&mut x)`.
/// * `&mut T` tipo vertės yra verčiamos į `&mut U` tipo vertes
/// * `T` netiesiogiai įgyvendina visus `U` tipo (mutable) metodus.
///
/// Norėdami gauti daugiau informacijos, apsilankykite [the chapter in *The Rust Programming Language*][book], taip pat [the dereference operator][ref-deref-op], [method resolution] ir [type coercions] skyriuose.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktūra, turinti vieną lauką, kurią galima modifikuoti nukrypstant nuo struktūros.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Keičiamai daro įtaką vertei.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Nurodo, kad struktūrą galima naudoti kaip metodų imtuvą be `arbitrary_self_types` funkcijos.
///
/// Tai įgyvendina " stdlib` žymeklių tipai, tokie kaip `Box<T>`, `Rc<T>`, `&T` ir `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}