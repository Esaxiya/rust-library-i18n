/// Tinkintas kodas sunaikintuve.
///
/// Kai reikšmė nebereikalinga, Rust paleidžia "destructor" ta verte.
/// Dažniausias būdas, kai vertė nebereikalinga, yra tada, kai ji išeina iš taikymo srities.Naikintojai vis tiek gali veikti kitomis aplinkybėmis, tačiau mes sutelksime dėmesį į pavyzdžių apimtį čia.
/// Norėdami sužinoti apie kai kuriuos tuos atvejus, žr. [the reference] skyrių apie naikintuvus.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Šis naikintuvas susideda iš dviejų komponentų:
/// - Skambinimas į `Drop::drop` dėl šios vertės, jei šis specialus `Drop` trait yra įdiegtas jo tipui.
/// - Automatiškai sugeneruotas " "drop glue", kuris rekursyviai iškviečia visų šios vertės laukų naikintuvus.
///
/// Kadangi " Rust`automatiškai iškviečia visų esančių laukų naikintuvus, daugeliu atvejų nereikia įdiegti " `Drop`.
/// Tačiau kai kuriais atvejais tai yra naudinga, pavyzdžiui, tiesiogiai išteklių valdantiems tipams.
/// Tas išteklius gali būti atmintis, failų aprašas, tinklo lizdas.
/// Kai tokio tipo reikšmė nebebus naudojama, ji turėtų "clean up" išteklius atlaisvindama atmintį arba uždarydama failą ar lizdą.
/// Tai yra destruktoriaus darbas, taigi ir " `Drop::drop` darbas.
///
/// ## Examples
///
/// Norėdami pamatyti, kaip veikia naikintuvai, pažvelkime į šią programą:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// " Rust`pirmiausia paskambins į " `Drop::drop`, skirtą " `_x`, tada-" `_x.one` ir " `_x.two`, tai reiškia, kad vykdant tai bus atspausdinta
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Net jei pašalinsime " `Drop` diegimą " `HasTwoDrop`, vis tiek iškviečiami jo laukų naikintuvai.
/// Tai sukeltų
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Negalite patys paskambinti " `Drop::drop`
///
/// Kadangi `Drop::drop` naudojamas reikšmei išvalyti, gali būti pavojinga naudoti šią reikšmę iškvietus metodą.
/// Kadangi " `Drop::drop` neprisiima nuosavybės teisių į savo įvestį, " Rust` apsaugo nuo netinkamo naudojimo neleisdamas tiesiogiai skambinti į " `Drop::drop`.
///
/// Kitaip tariant, jei bandėte aiškiai paskambinti `Drop::drop` aukščiau pateiktame pavyzdyje, gausite kompiliatoriaus klaidą.
///
/// Jei norite aiškiai iškviesti vertės naikintuvą, vietoj jo galima naudoti [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Užsakymo atsisakymas
///
/// Kuris iš mūsų dviejų " `HasDrop` nukrenta pirmiausia?Struktūroms taikoma ta pati tvarka, kokia jie deklaruojami: pirmiausia `one`, tada `two`.
/// Jei norite tai išbandyti patys, galite pakeisti " `HasDrop` aukščiau, kad jame būtų tam tikri duomenys, pvz., Sveikasis skaičius, ir tada juos naudoti X0 `println!` viduje `Drop`.
/// Tokį elgesį garantuoja kalba.
///
/// Skirtingai nuo struktų, vietiniai kintamieji metami atvirkštine tvarka:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Tai atspausdins
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Visas taisykles rasite [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` ir `Drop` yra išskirtiniai
///
/// Negalite įdiegti tiek " [`Copy`], tiek " `Drop` to paties tipo.`Copy` tipus kompiliatorius netiesiogiai dubliuoja, todėl labai sunku numatyti, kada ir kaip dažnai bus vykdomi destruktoriai.
///
/// Šie tipai negali turėti destruktorių.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Vykdo šio tipo destruktorių.
    ///
    /// Šis metodas vadinamas netiesiogiai, kai vertė išeina iš taikymo srities, ir jo negalima aiškiai iškviesti (tai kompiliatoriaus klaida [E0040]).
    /// Tačiau [`mem::drop`] funkciją prelude galima naudoti norint iškviesti argumento `Drop` įgyvendinimą.
    ///
    /// Kai šis metodas bus iškviestas, `self` dar nebuvo paskirstytas.
    /// Tai įvyksta tik pasibaigus metodui.
    /// Jei taip nebūtų, " `self` būtų kabanti nuoroda.
    ///
    /// # Panics
    ///
    /// Atsižvelgiant į tai, kad " [`panic!`] skambins " `drop`, kai jis išsisuks, bet koks " [`panic!`], esantis įgyvendinant " `drop`, greičiausiai nutrūks.
    ///
    /// Atkreipkite dėmesį, kad net jei ši panics, vertė laikoma nukritusia;
    /// neturite sukelti `drop` pakartotinio iškvietimo.
    /// Paprastai kompiliatorius tai tvarko automatiškai, tačiau naudojant nesaugų kodą kartais gali pasitaikyti netyčia, ypač naudojant " [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}