use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Sąsaja, susijusi su asinchroniniais iteratoriais.
///
/// Tai yra pagrindinis srautas trait.
/// Norėdami sužinoti daugiau apie srautų sąvoką, žr. " [module-level documentation].
/// Visų pirma, galbūt norėsite žinoti, kaip atlikti " [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Srauto gaunamų elementų tipas.
    type Item;

    /// Pabandykite ištraukti kitą šio srauto vertę, užregistruodami dabartinę užduotį pabudimui, jei reikšmė dar nėra, ir grąžinkite `None`, jei srautas yra išnaudotas.
    ///
    /// # Grąžinimo vertė
    ///
    /// Yra kelios galimos grąžinimo vertės, kurios kiekviena rodo skirtingą srauto būseną:
    ///
    /// - `Poll::Pending` reiškia, kad kita šio srauto vertė dar neparengta.Diegimai užtikrins, kad apie dabartinę užduotį bus pranešta, kai bus paruošta kita reikšmė.
    ///
    /// - `Poll::Ready(Some(val))` reiškia, kad srautas sėkmingai sukūrė vertę `val` ir gali generuoti kitas reikšmes vėlesniuose `poll_next` skambučiuose.
    ///
    /// - `Poll::Ready(None)` reiškia, kad srautas nutrūko, ir `poll_next` nereikėtų vėl naudoti.
    ///
    /// # Panics
    ///
    /// Srautui pasibaigus (grąžinus `Ready(None)` from `poll_next`), dar kartą iškviečiant jo `poll_next` metodą, panic gali amžinai blokuotis ar sukelti kitokių problemų; `Stream` trait netaikomi reikalavimai tokio skambučio poveikiui.
    ///
    /// Tačiau, kadangi `poll_next` metodas nėra pažymėtas `unsafe`, galioja įprastos Rust taisyklės: skambučiai niekada neturi sukelti neapibrėžto elgesio (atminties sugadinimo, neteisingo `unsafe` funkcijų naudojimo ar pan.), Nepaisant srauto būsenos.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Grąžina likusio srauto ilgio ribas.
    ///
    /// Tiksliau, `size_hint()` grąžina atkarpą, kur pirmasis elementas yra apatinė riba, o antrasis elementas yra viršutinė riba.
    ///
    /// Antroji grąžinamosios grupės pusė yra [" Variantas`] " <` [" naudoti`] " >`.
    /// [`None`] čia reiškia, kad arba nėra žinomos viršutinės ribos, arba viršutinė riba yra didesnė nei [`usize`].
    ///
    /// # Įgyvendinimo pastabos
    ///
    /// Nėra užtikrinta, kad srauto įgyvendinimas duoda deklaruotą elementų skaičių.Dėl bagio srauto elementų riba gali būti mažesnė nei apatinė arba viršutinė.
    ///
    /// `size_hint()` pirmiausia skirtas naudoti optimizavimui, pvz., rezervuoti vietą srauto elementams, tačiau juo negalima pasitikėti, pvz., nepraleidus riboto tikrinimo nesaugiame kode.
    /// Netinkamas " `size_hint()` diegimas neturėtų sukelti atminties saugumo pažeidimų.
    ///
    /// Be to, įgyvendinimas turėtų pateikti teisingą įvertinimą, nes kitaip tai būtų " trait` protokolo pažeidimas.
    ///
    /// Numatytasis įgyvendinimas pateikia " (0," [None`]``) `, kuris tinka bet kuriam srautui.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}