//! Suderinama asinchroninė iteracija.
//!
//! Jei futures yra asinchroninės vertės, tada srautai yra asinchroniniai iteratoriai.
//! Jei radote kažkokią asinchroninę kolekciją ir jums reikėjo atlikti operaciją su minėtos kolekcijos elementais, greitai pateksite į " 'streams'.
//! Srautai yra labai naudojami idiomatiniame asinchroniniame Rust kode, todėl verta su jais susipažinti.
//!
//! Prieš paaiškindami daugiau, pakalbėkime apie šio modulio struktūrą:
//!
//! # Organization
//!
//! Šis modulis daugiausia suskirstytas pagal tipą:
//!
//! * [Traits] yra pagrindinė dalis: šie " traits`apibrėžia, kokie srautai egzistuoja ir ką galite su jais daryti.Šių " traits` metodų verta skirti papildomo laiko studijoms.
//! * Funkcijos suteikia keletą naudingų būdų sukurti keletą pagrindinių srautų.
//! * Struktūros dažnai yra šio modulio traits įvairių metodų grąžinimo tipai.Paprastai norėtumėte atkreipti dėmesį į metodą, kuris sukuria " `struct`, o ne į patį " `struct`.
//! Norėdami sužinoti daugiau, kodėl, žr. " [Įdiegti srautą](#įgyvendinimo srautas)`.
//!
//! [Traits]: #traits
//!
//! Viskas!Įsigilinkime į upelius.
//!
//! # Stream
//!
//! Šio modulio širdis ir siela yra " [`Stream`] trait`." [`Stream`] šerdis atrodo taip:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Skirtingai nuo `Iterator`, `Stream` skiria [`poll_next`] metodą, kuris naudojamas įgyvendinant `Stream`, ir (to-be-implemented) `next` metodą, kuris naudojamas vartojant srautą.
//!
//! " `Stream` vartotojai turi atsižvelgti tik į " `next`, kuris, iškvietus, grąžina future, kuris duoda `Option<Stream::Item>`.
//!
//! " `next` grąžintas " future` duos `Some(Item)` tol, kol yra elementų, ir kai visi bus išnaudoti, bus `None`, rodantis, kad iteracija baigta.
//! Jei laukiame asinchroninio sprendimo, " future` lauks, kol srautas vėl bus paruoštas.
//!
//! Atskiri srautai gali nuspręsti atnaujinti kartojimą, todėl vėl paskambinus į `next`, `Some(Item)` vėl gali atsirasti arba ne, bet kada.
//!
//! Visas " [Stream`]` apibrėžimas apima ir daugybę kitų metodų, tačiau jie yra numatytieji metodai, sukurti ant " [`poll_next`], todėl juos galite gauti nemokamai.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # " Stream` įgyvendinimas
//!
//! Norėdami sukurti savo srautą, reikia atlikti du veiksmus: sukurti `struct`, kad būtų išlaikyta srauto būsena, ir tada įgyvendinti [`Stream`] šiam `struct`.
//!
//! Sukurkime srautą pavadinimu `Counter`, kuris skaičiuojamas nuo `1` iki `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Pirma, struktūra:
//!
//! /// Srautas, skaičiuojantis nuo vieno iki penkių
//! struct Counter {
//!     count: usize,
//! }
//!
//! // norime, kad mūsų skaičiavimas prasidėtų vienu, todėl pridėkime new() metodą, kuris padės.
//! // Tai nėra griežtai būtina, tačiau yra patogu.
//! // Atkreipkite dėmesį, kad " `count` pradedame nuo nulio, todėl `poll_next()`'s diegime pamatysime toliau.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Tada mes įdiegiame " `Stream` savo " `Counter`:
//!
//! impl Stream for Counter {
//!     // mes skaičiuosime su usize
//!     type Item = usize;
//!
//!     // poll_next() yra vienintelis reikalingas metodas
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Padidinkite mūsų skaičių.Štai kodėl mes pradėjome nuo nulio.
//!         self.count += 1;
//!
//!         // Patikrinkite, ar baigėme skaičiuoti, ar ne.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Srautai yra *tingūs*.Tai reiškia, kad vien tik sukūrus srautą, " _do_ nėra daug.Nieko iš tikrųjų nevyksta, kol nepaskambinsite į " `next`.
//! Tai kartais kelia painiavą kuriant srautą tik dėl jo šalutinių poveikių.
//! Kompiliatorius mus įspės apie tokį elgesį:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;