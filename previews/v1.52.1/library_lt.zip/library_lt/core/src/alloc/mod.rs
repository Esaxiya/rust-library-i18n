//! Atminties paskirstymo API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` klaida rodo paskirstymo gedimą, kurį gali sukelti išteklių išnaudojimas arba kažkas negerai, derinant pateiktus įvesties argumentus su šiuo paskirstytoju.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (mums to reikia pasroviui trait klaidos implikuoti)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` diegimas gali paskirstyti, auginti, mažinti ir paskirstyti savavališkus duomenų blokus, aprašytus per [`Layout`][].
///
/// `Allocator` yra sukurtas įgyvendinti ZST, nuorodose ar išmaniuosiuose rodikliuose, nes tokio paskirstytuvo, kaip `MyAlloc([u8; N])`, negalima perkelti, neatnaujinant rodyklių į skirtą atmintį.
///
/// Skirtingai nuo " [`GlobalAlloc`][], " `Allocator` leidžiami nulinio dydžio paskirstymai.
/// Jei pagrindinis paskirstytojas to nepalaiko (pvz., " Jemalloc`) arba pateikia nulinį rodyklę (pvz., `libc::malloc`), tai turi būti užfiksuotas įgyvendinime.
///
/// ### Šiuo metu skirta atmintis
///
/// Kai kurie metodai reikalauja, kad atminties blokas *šiuo metu būtų paskirstytas* per paskirstytoją.Tai reiškia, kad:
///
/// * to atminties bloko pradinį adresą anksčiau grąžino [`allocate`], [`grow`] arba [`shrink`] ir
///
/// * Vėliau atminties blokas nebuvo paskirstytas, kai blokai yra tiesiogiai paskirstomi perduodant [`deallocate`] arba buvo pakeisti perduodant [`grow`] arba [`shrink`], kuris grąžina `Ok`.
///
/// Jei `grow` arba `shrink` grąžino `Err`, perduotas rodyklė lieka galioti.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Atminties pritaikymas
///
/// Kai kurie metodai reikalauja, kad maketas *tilptų* į atminties bloką.
/// Tai, ką reiškia išdėstymas "fit", reiškia atminties blokas (arba lygiaverčiai, kai atminties blokas-"fit"-maketas) yra tai, kad turi atitikti šias sąlygas:
///
/// * Blokas turi būti priskirtas tokiu pačiu lygiavimu kaip ir [`layout.align()`], ir
///
/// * Pateiktas [`layout.size()`] turi patekti į `min ..= max` diapazoną, kur:
///   - `min` yra maketo dydis, kuris paskutiniu metu buvo naudojamas blokui priskirti, ir
///   - `max` yra paskutinis faktinis dydis, grąžintas iš [`allocate`], [`grow`] arba [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Iš paskirstytojo grąžinti atminties blokai turi nukreipti į galiojančią atmintį ir išlaikyti savo galiojimą, kol egzempliorius ir visi jo klonai bus išmesti,
///
/// * klonavimas ar perkėlimas neturi atimti atminties blokų, grąžintų iš šio skirstytuvo.Klonuotas paskirstytojas turi elgtis kaip tas pats paskirstytojas ir
///
/// * bet koks žymeklis į atminties bloką, kuris yra [*currently allocated*], gali būti perduotas bet kuriam kitam paskirstytojo metodui.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Bandymai skirti atminties bloką.
    ///
    /// Sėkmingai pateikia [`NonNull<[u8]>`][NonNull], atitinkantį `layout` dydžio ir derinimo garantijas.
    ///
    /// Grąžinto bloko dydis gali būti didesnis, nei nurodė " `layout.size()`, ir jo turinys gali būti inicializuotas.
    ///
    /// # Errors
    ///
    /// Grąžinimas `Err` rodo, kad atmintis yra išeikvota, arba `layout` neatitinka paskirstytojo dydžio ar lygiavimo apribojimų.
    ///
    /// Įgyvendinimas yra skatinamas grąžinti " `Err` dėl atminties išsekimo, o ne į paniką ar nutraukimą, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Elgiasi kaip " `allocate`, bet taip pat užtikrina, kad grąžinama atmintis būtų nulio inicializuota.
    ///
    /// # Errors
    ///
    /// Grąžinimas `Err` rodo, kad atmintis yra išeikvota, arba `layout` neatitinka paskirstytojo dydžio ar lygiavimo apribojimų.
    ///
    /// Įgyvendinimas yra skatinamas grąžinti " `Err` dėl atminties išsekimo, o ne į paniką ar nutraukimą, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAUGA: `alloc` pateikia galiojantį atminties bloką
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Paskirsto atmintį, nurodytą `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` per šį skirstytuvą turi žymėti atminties bloką [*currently allocated*] ir
    /// * `layout` turi [*fit*] tą atminties bloką.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Bandymai išplėsti atminties bloką.
    ///
    /// Pateikia naują [`NonNull<[u8]>`][NonNull], kuriame yra žymeklis ir tikrasis paskirstytos atminties dydis.Rodyklė tinka duomenims, aprašytiems `new_layout`, laikyti.
    /// Norėdami tai pasiekti, paskirstytojas gali išplėsti `ptr` nurodytą paskirstymą, kad jis atitiktų naują išdėstymą.
    ///
    /// Jei tai grąžina `Ok`, tada `ptr` nurodyto atminties bloko nuosavybės teisė buvo perduota šiam paskirstytojui.
    /// Atmintis gali būti išlaisvinta, bet gali būti laikoma netinkama naudoti, nebent ji vėl buvo grąžinta skambinančiajam per šio metodo grąžinimo vertę.
    ///
    /// Jei šis metodas grąžina `Err`, tada atminties bloko nuosavybės teisė nebuvo perduota šiam paskirstytojui ir atminties bloko turinys nepakito.
    ///
    /// # Safety
    ///
    /// * `ptr` per šį skirstytuvą turi žymėti atminties bloką [*currently allocated*].
    /// * `old_layout` turi [*fit*] tą atminties bloką (argumentas `new_layout` neturi jo tilpti.).
    /// * `new_layout.size()` turi būti didesnis arba lygus `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pateikia `Err`, jei naujas išdėstymas neatitinka paskirstytojo dydžio ir lygiuotojo apribojimų arba jei kitaip augti nepavyksta.
    ///
    /// Įgyvendinimas yra skatinamas grąžinti " `Err` dėl atminties išsekimo, o ne į paniką ar nutraukimą, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAUGA: nes `new_layout.size()` turi būti didesnis arba lygus
        // `old_layout.size()`, tiek senoji, tiek naujoji atminties paskirstymas galioja skaitant ir rašant `old_layout.size()` baitams.
        // Be to, kadangi senasis paskirstymas dar nebuvo paskirstytas, jis negali sutapti su " `new_ptr`.
        // Taigi skambutis į `copy_nonoverlapping` yra saugus.
        // `dealloc` saugos sutartį turi palaikyti skambinantysis.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Elgiasi kaip " `grow`, bet taip pat užtikrina, kad prieš grąžinant naują turinį bus nustatyta nulis.
    ///
    /// Po sėkmingo skambučio atminties bloke bus šis turinys
    /// `grow_zeroed`:
    ///   * Baitai `0..old_layout.size()` išsaugomi iš pradinio paskirstymo.
    ///   * Baitai `old_layout.size()..old_size` bus arba išsaugoti, arba nuliniai, priklausomai nuo paskirstytojo įgyvendinimo.
    ///   `old_size` reiškia atminties bloko dydį prieš `grow_zeroed` skambutį, kuris gali būti didesnis nei dydis, kurio iš pradžių buvo paprašyta, kai jis buvo paskirtas.
    ///   * Baitai `old_size..new_size` yra nuliniai.`new_size` reiškia atminties bloko dydį, kurį grąžina skambutis `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` per šį skirstytuvą turi žymėti atminties bloką [*currently allocated*].
    /// * `old_layout` turi [*fit*] tą atminties bloką (argumentas `new_layout` neturi jo tilpti.).
    /// * `new_layout.size()` turi būti didesnis arba lygus `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pateikia `Err`, jei naujas išdėstymas neatitinka paskirstytojo dydžio ir lygiuotojo apribojimų arba jei kitaip augti nepavyksta.
    ///
    /// Įgyvendinimas yra skatinamas grąžinti " `Err` dėl atminties išsekimo, o ne į paniką ar nutraukimą, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAUGA: nes `new_layout.size()` turi būti didesnis arba lygus
        // `old_layout.size()`, tiek senoji, tiek naujoji atminties paskirstymas galioja skaitant ir rašant `old_layout.size()` baitams.
        // Be to, kadangi senasis paskirstymas dar nebuvo paskirstytas, jis negali sutapti su " `new_ptr`.
        // Taigi skambutis į `copy_nonoverlapping` yra saugus.
        // `dealloc` saugos sutartį turi palaikyti skambinantysis.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Bandymai sumažinti atminties bloką.
    ///
    /// Pateikia naują [`NonNull<[u8]>`][NonNull], kuriame yra žymeklis ir tikrasis paskirstytos atminties dydis.Rodyklė tinka duomenims, aprašytiems `new_layout`, laikyti.
    /// Norėdami tai pasiekti, paskirstytojas gali sumažinti `ptr` nurodytą paskirstymą, kad atitiktų naują išdėstymą.
    ///
    /// Jei tai grąžina `Ok`, tada `ptr` nurodyto atminties bloko nuosavybės teisė buvo perduota šiam paskirstytojui.
    /// Atmintis gali būti išlaisvinta, bet gali būti laikoma netinkama naudoti, nebent ji vėl buvo grąžinta skambinančiajam per šio metodo grąžinimo vertę.
    ///
    /// Jei šis metodas grąžina `Err`, tada atminties bloko nuosavybės teisė nebuvo perduota šiam paskirstytojui ir atminties bloko turinys nepakito.
    ///
    /// # Safety
    ///
    /// * `ptr` per šį skirstytuvą turi žymėti atminties bloką [*currently allocated*].
    /// * `old_layout` turi [*fit*] tą atminties bloką (argumentas `new_layout` neturi jo tilpti.).
    /// * `new_layout.size()` turi būti mažesnė arba lygi `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pateikia `Err`, jei naujas išdėstymas neatitinka paskirstytojo dydžio ir lygiuotojo apribojimų arba jei kitaip susitraukti nepavyksta.
    ///
    /// Įgyvendinimas yra skatinamas grąžinti " `Err` dėl atminties išsekimo, o ne į paniką ar nutraukimą, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAUGA: nes `new_layout.size()` turi būti mažesnis arba lygus
        // `old_layout.size()`, tiek senoji, tiek naujoji atminties paskirstymas galioja skaitant ir rašant `new_layout.size()` baitams.
        // Be to, kadangi senasis paskirstymas dar nebuvo paskirstytas, jis negali sutapti su " `new_ptr`.
        // Taigi skambutis į `copy_nonoverlapping` yra saugus.
        // `dealloc` saugos sutartį turi palaikyti skambinantysis.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Sukuria "by reference" adapterį šiam `Allocator` egzemplioriui.
    ///
    /// Grąžintas adapteris taip pat įdiegia " `Allocator` ir paprasčiausiai tai pasiskolins.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAUGUMAS: saugos sutartį privalo palaikyti skambinantysis
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAUGUMAS: saugos sutartį privalo palaikyti skambinantysis
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAUGUMAS: saugos sutartį privalo palaikyti skambinantysis
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAUGUMAS: saugos sutartį privalo palaikyti skambinantysis
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}