use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Atminties skirstytuvas, kurį per `#[global_allocator]` atributą galima užregistruoti kaip standartinę bibliotekos numatytąją.
///
/// Kai kurie metodai reikalauja, kad atminties blokas *šiuo metu būtų paskirstytas* per paskirstytoją.Tai reiškia, kad:
///
/// * to atminties bloko pradinis adresas anksčiau buvo grąžintas atlikus ankstesnį skambutį paskirstymo metodui, tokiam kaip `alloc`, ir
///
/// * Vėliau atminties blokas nebuvo paskirstytas, kai blokai yra paskirstomi perduodant sandorio paskirstymo metodui, pvz., `dealloc`, arba perduodant perskirstymo metodui, kuris pateikia nulinį rodyklę.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// " `GlobalAlloc` trait`yra " `unsafe` trait` dėl daugelio priežasčių, todėl įgyvendintojai privalo užtikrinti, kad jie laikytųsi šių sutarčių:
///
/// * Tai nėra apibrėžta elgsena, jei pasauliniai paskirstytojai atsipalaiduoja.Šis apribojimas gali būti panaikintas future, tačiau šiuo metu panic iš bet kurios iš šių funkcijų gali sukelti atminties nesaugumą.
///
/// * `Layout` klausimai ir skaičiavimai apskritai turi būti teisingi.Skambinantiems šiuo " trait` leidžiama pasikliauti sutartimis, apibrėžtomis pagal kiekvieną metodą, o įgyvendintojai turi užtikrinti, kad tokios sutartys išliktų teisingos.
///
/// * Jūs negalite pasikliauti faktiškai vykstančiais paskirstymais, net jei šaltinyje yra aiškių krūvos paskirstymų.
/// Optimizavimo priemonė gali aptikti nepanaudotus paskirstymus, kuriuos gali visiškai pašalinti arba perkelti į kaminą ir taip niekada neprašyti paskirstytojo.
/// Optimizatorius taip pat gali daryti prielaidą, kad paskirstymas yra neklystantis, todėl kodas, kuris anksčiau sugedo dėl paskirstytojo gedimų, gali staiga veikti, nes optimizatorius išsprendė paskirstymo poreikį.
/// Konkrečiau kalbant, šis kodo pavyzdys yra nepagrįstas, neatsižvelgiant į tai, ar jūsų tinkintas paskirstytojas leidžia skaičiuoti, kiek paskirstymų įvyko.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Atkreipkite dėmesį, kad aukščiau paminėti optimizavimai nėra vienintelis pritaikomas optimizavimas.Paprastai negalite pasikliauti tuo, kad vyksta krūvos paskirstymai, jei juos galima pašalinti nekeičiant programos elgsenos.
///   Nesvarbu, ar paskirstymai įvyksta, ar ne, nėra programos elgesio dalis, net jei tai galima nustatyti per paskirstytoją, kuris seka paskirstymus spausdindamas ar kitaip turėdamas šalutinį poveikį.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Paskirkite atmintį, kaip aprašyta pateiktame `layout`.
    ///
    /// Grąžina žymeklį į naujai paskirstytą atmintį arba nulį, nurodantį paskirstymo triktį.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi, nes neapibrėžtas elgesys gali atsirasti, jei skambinantysis neužtikrins, kad " `layout` dydis nėra nulinis.
    ///
    /// (Plėtinių potrinkiai gali nustatyti konkretesnes elgesio ribas, pvz., Garantuoti kontrolinį adresą arba nulinį rodyklę atsakant į nulinio dydžio paskirstymo užklausą.)
    ///
    /// Paskirtas atminties blokas gali būti inicijuojamas arba ne.
    ///
    /// # Errors
    ///
    /// Grąžinus nulinį rodyklę nurodoma, kad atmintis yra išeikvota, arba `layout` neatitinka šio paskirstytojo dydžio ar išlyginimo apribojimų.
    ///
    /// Įgyvendinimas yra skatinamas, kai atmintis išeikvojama, o ne nutraukiama, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Paskirstykite atminties bloką prie nurodyto `ptr` žymiklio su nurodytu `layout`.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi, nes neapibrėžtas elgesys gali kilti, jei skambinantysis neužtikrina visų šių veiksmų:
    ///
    ///
    /// * `ptr` turi žymėti atminties bloką, šiuo metu paskirstytą per šį paskirstytoją,
    ///
    /// * `layout` turi būti tas pats išdėstymas, kuris buvo naudojamas tam atminties blokui priskirti.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Elgiasi kaip " `alloc`, bet taip pat užtikrina, kad prieš grąžinant turinys bus nustatytas į nulį.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi dėl tų pačių priežasčių, kaip ir " `alloc`.
    /// Tačiau garantuojama, kad paskirtas atminties blokas bus inicijuotas.
    ///
    /// # Errors
    ///
    /// Grąžinus nulinį rodyklę nurodoma, kad atmintis yra išeikvota, arba `layout` neatitinka paskirstytojo dydžio ar lygiavimo apribojimų, kaip ir `alloc`.
    ///
    /// Klientai, norintys nutraukti skaičiavimą atsakydami į paskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašiai.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SAUGA: `alloc` saugos sutartį turi palaikyti skambinantysis.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SAUGA: kai paskirstymas pavyko, regionas nuo `ptr`
            // `size` dydžio garantija galioja rašant.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Sumažinkite arba padidinkite atminties bloką iki nurodyto `new_size`.
    /// Bloką apibūdina pateiktas `ptr` žymeklis ir `layout`.
    ///
    /// Jei tai grąžina nenulinį rodyklę, tada `ptr` nurodyto atminties bloko nuosavybės teisė buvo perduota šiam paskirstytojui.
    /// Gali būti, kad atmintis nebuvo paskirstyta, ir ji turėtų būti laikoma netinkama naudoti (nebent, žinoma, ji vėl buvo grąžinta skambinančiajam per šio metodo grąžinimo vertę).
    /// Naujas atminties blokas priskiriamas `layout`, bet atnaujinus `size` iki `new_size`.
    /// Šis naujas išdėstymas turėtų būti naudojamas paskirstant naują atminties bloką su " `dealloc`.
    /// Garantuojama, kad naujojo atminties bloko diapazonas `0..min(layout.size(), new_size) `turi tas pačias reikšmes kaip ir pradinis blokas.
    ///
    /// Jei šis metodas grąžina nulį, tada atminties bloko nuosavybė šiam paskirstytojui nebuvo perduota ir atminties bloko turinys nepasikeitė.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi, nes neapibrėžtas elgesys gali kilti, jei skambinantysis neužtikrina visų šių veiksmų:
    ///
    /// * `ptr` šiuo metu turi būti paskirta per šį paskirstytoją,
    ///
    /// * `layout` turi būti toks pat išdėstymas, koks buvo naudojamas tam atminties blokui priskirti,
    ///
    /// * `new_size` turi būti didesnis nei nulis.
    ///
    /// * `new_size`, suapvalinus iki artimiausio `layout.align()` kartotinio, neturi perpildyti (ty suapvalinta vertė turi būti mažesnė nei `usize::MAX`).
    ///
    /// (Plėtinių potrinkiai gali nustatyti konkretesnes elgesio ribas, pvz., Garantuoti kontrolinį adresą arba nulinį rodyklę atsakant į nulinio dydžio paskirstymo užklausą.)
    ///
    /// # Errors
    ///
    /// Grąžina nulį, jei naujas išdėstymas neatitinka paskirstytojo dydžio ir lygiavimo apribojimų arba jei kitaip nepavyksta perskirstyti.
    ///
    /// Įgyvendinimas skatinamas grąžinti atmintį išeikvojus, o ne panikuoti ar nutraukti, tačiau tai nėra griežtas reikalavimas.
    /// (Tiksliau:*teisėta* įdiegti šią trait esančios vietinės paskirstymo bibliotekos viršuje, kuri nutraukia atminties išsekimą.)
    ///
    /// Klientai, norintys nutraukti skaičiavimą, reaguodami į perskirstymo klaidą, raginami skambinti funkcija [`handle_alloc_error`], o ne tiesiogiai kreiptis į `panic!` ar panašią.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAUGUMAS: skambinantysis turi užtikrinti, kad " `new_size` neperpildytų.
        // `layout.align()` ateina iš " `Layout` ir todėl garantuojama, kad jis galios.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SAUGA: skambinantysis turi užtikrinti, kad `new_layout` būtų didesnis nei nulis.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SAUGUMAS: anksčiau paskirtas blokas negali sutapti su naujai paskirtu bloku.
            // `dealloc` saugos sutartį turi palaikyti skambinantysis.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}