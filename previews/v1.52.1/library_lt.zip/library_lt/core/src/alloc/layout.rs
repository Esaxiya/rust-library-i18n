use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Nors ši funkcija naudojama vienoje vietoje ir jos įgyvendinimas galėtų būti aiškus, ankstesni bandymai tai padaryti rustc padarė lėčiau:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Atminties bloko išdėstymas.
///
/// `Layout` egzempliorius apibūdina tam tikrą atminties išdėstymą.
/// Sukuriate " `Layout` kaip įvestį, kurią galite skirti paskirstytojui.
///
/// Visi maketai turi susietą dydį ir dviejų galių lygiuotę.
///
/// (Atkreipkite dėmesį, kad maketams * neprivaloma turėti ne nulio dydžio, net jei `GlobalAlloc` reikalauja, kad visos atminties užklausos būtų ne nulinės.
/// Skambintojas turi arba užtikrinti, kad būtų įvykdytos tokios sąlygos, naudoti specialius skirstytuvus, kuriems keliami griežtesni reikalavimai, arba naudoti švelnesnę `Allocator` sąsają.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // prašomo atminties bloko dydis, matuojamas baitais.
    size_: usize,

    // prašomo atminties bloko išlyginimas, matuojamas baitais.
    // mes užtikriname, kad tai visada yra dviejų galia, nes API, pvz., `posix_memalign`, to reikia, ir tai yra pagrįstas suvaržymas, kurį reikia nustatyti maketo konstruktoriams.
    //
    //
    // (Tačiau analogiškai nereikalaujame `lygiuoti>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Sukuria `Layout` iš nurodytų `size` ir `align` arba grąžina `LayoutError`, jei nesilaikoma bet kurios iš šių sąlygų:
    ///
    /// * `align` neturi būti nulis,
    ///
    /// * `align` turi būti dviejų galia,
    ///
    /// * `size`, suapvalinus iki artimiausio `align` kartotinio, neturi perpildyti (ty suapvalinta vertė turi būti mažesnė arba lygi `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (dviejų galia reiškia lygiavimą!=0.)

        // Suapvalintas dydis yra:
        //   dydis_apvalintas_upas=(dydis + sulygiuoti, 1)&! (lygiuoti, 1);
        //
        // Iš viršaus žinome, kad lygiuotis!=0.
        // Jei pridėjus (sulygiuoti, 1) neperpildysi, apvalinimas bus puikus.
        //
        // Ir atvirkščiai,&užmaskavus! (Sulygiuokite, 1) atimsite tik žemos eilės bitus.
        // Taigi, jei perpildymas įvyksta su suma,&-mask negali atimti tiek, kad anuliuoti tą perpildymą.
        //
        //
        // Aukščiau nurodyta reiškia, kad sumavimo perpildymo tikrinimas yra būtinas ir pakankamas.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SAUGA: `from_size_align_unchecked` sąlygos buvo
        // patikrinta aukščiau.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Sukuriamas maketas, apeinant visus patikrinimus.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi, nes nepatikrina išankstinių sąlygų iš " [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SAUGA: skambinantysis turi užtikrinti, kad `align` būtų didesnis nei nulis.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Mažiausias šio išdėstymo atminties bloko dydis baitais.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Mažiausias šio išdėstymo atminties bloko baitų išlyginimas.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Sukonstruoja `Layout`, tinkamą laikyti `T` tipo vertę.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAUGUMAS: Rust garantuoja, kad lygiavimas bus dviejų ir
        // garantuojama, kad derinys " dydis + lygiuoti` tilps mūsų adresų erdvėje.
        // Dėl to čia naudokite nepatikrintą konstruktorių, kad išvengtumėte panics kodo įterpimo, jei jis nėra pakankamai gerai optimizuotas.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Parengia maketą, apibūdinantį įrašą, kurį galima naudoti paskirstant `T` pagrindinę struktūrą (tai gali būti trait ar kito dydžio, pvz., Gabalas).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAUGUMAS: žr. " `new` pagrindimą, kodėl naudojamas nesaugus variantas
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Parengia maketą, apibūdinantį įrašą, kurį galima naudoti paskirstant `T` pagrindinę struktūrą (tai gali būti trait ar kito dydžio, pvz., Gabalas).
    ///
    /// # Safety
    ///
    /// Šia funkcija saugu skambinti tik tuo atveju, jei yra šios sąlygos:
    ///
    /// - Jei " `T` yra " `Sized`, šią funkciją visada saugu skambinti.
    /// - Jei nedidelis " `T` uodega yra:
    ///     - [slice], tada gabalo uodegos ilgis turi būti intializuotas sveikasis skaičius, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi tilpti į `isize`.
    ///     - [trait object], tada rodomoji rodyklės dalis turi būti nukreipta į galiojantį `T` tipo vtable, įgytą neribojant koeriacijos, o *visos vertės* dydis (dinaminis uodegos ilgis + statinio dydžio priešdėlis) turi atitikti `isize`.
    ///
    ///     - (unstable) [extern type], tada šią funkciją visada saugu skambinti, tačiau ji gali panic ar kitaip grąžinti neteisingą vertę, nes išorinio tipo išdėstymas nėra žinomas.
    ///     Tai tokia pati elgsena kaip [`Layout::for_value`], kai nuoroda į išorinio tipo uodegą.
    ///     - kitaip konservatyviai negalima skambinti šia funkcija.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAUGA: mes perduodame skambintojui šių funkcijų prielaidas
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SAUGUMAS: žr. " `new` pagrindimą, kodėl naudojamas nesaugus variantas
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Sukuria kabantį, bet gerai pritaikytą šiam maketui `NonNull`.
    ///
    /// Atminkite, kad žymeklio reikšmė gali reikšti galiojantį rodyklę, o tai reiškia, kad jos negalima naudoti kaip "not yet initialized" sentinelio vertės.
    /// Tingiai paskirstomi tipai turi sekti inicijavimą kitomis priemonėmis.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SAUGUMAS: garantuojama, kad lygiavimas nebus nulinis
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Sukuriamas maketas, apibūdinantis įrašą, kuriame gali būti tokio paties išdėstymo vertė kaip `self`, bet kuris taip pat sulygiuotas su lygiu `align` (matuojamas baitais).
    ///
    ///
    /// Jei `self` jau atitinka nustatytą išlygiavimą, tada grąžina `self`.
    ///
    /// Atminkite, kad šis metodas neprideda jokio užpildo prie bendro dydžio, neatsižvelgiant į tai, ar grąžintame makete yra kitoks lygiavimas.
    /// Kitaip tariant, jei " `K` turi 16 dydį, " `K.align_to(32)`*vis tiek* bus 16 dydžio.
    ///
    /// Pateikia klaidą, jei `self.size()` ir nurodyto `align` derinys pažeidžia [`Layout::from_size_align`] išvardytas sąlygas.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Pateikia užpildymo kiekį, kurį turime įterpti po `self`, kad įsitikintume, jog nurodytas adresas tenkins `align` (matuojamas baitais).
    ///
    /// pvz., jei `self.size()` yra 9, tada `self.padding_needed_for(4)` grąžina 3, nes tai yra mažiausias užpildymo baitų skaičius, reikalingas norint gauti 4 lygiuotų adresų skaičių (darant prielaidą, kad atitinkamas atminties blokas prasideda 4 lygiuoju adresu).
    ///
    ///
    /// Grąžinama šios funkcijos vertė neturi reikšmės, jei `align` nėra dviejų galia.
    ///
    /// Atkreipkite dėmesį, kad grąžinamos vertės naudingumas reikalauja, kad `align` būtų mažesnis arba lygus viso paskirstyto atminties bloko pradinio adreso lygiavimui.Vienas iš būdų patenkinti šį apribojimą yra užtikrinti " `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Suapvalinta vertė yra:
        //   len_rounded_up=(len + lygiuoti, 1)&! (lygiuoti, 1);
        // tada grąžiname užpildymo skirtumą: `len_rounded_up - len`.
        //
        // Visur naudojame modulinę aritmetiką:
        //
        // 1. garantuojama, kad lygiavimas bus> 0, todėl sulygiuokite, 1 visada galioja.
        //
        // 2.
        // `len + align - 1` gali perpildyti ne daugiau kaip `align - 1`, todėl&-mask su `!(align - 1)` užtikrins, kad perpildymo atveju pati `len_rounded_up` bus 0.
        //
        //    Taigi grąžinamas kamšalas, pridedamas prie `len`, duoda 0, kuris trivialiai tenkina išlyginimą `align`.
        //
        // (Žinoma, bandymai paskirstyti atminties blokus, kurių dydis ir užpildymas perpildomi aukščiau nurodytu būdu, vis tiek turėtų sukelti klaidą.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Sukuria maketą suapvalindamas šio maketo dydį iki daugybės maketo lygiavimo.
    ///
    ///
    /// Tai tolygu `padding_needed_for` rezultato pridėjimui prie dabartinio maketo dydžio.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Tai negali perpildyti.Citata iš išdėstymo varianto:
        // > `size`, suapvalinus iki artimiausio `align` kartotinio,
        // > neturi būti perpildyta (ty suapvalinta vertė turi būti mažesnė nei
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Sukuriamas išdėstymas, apibūdinantis `self` egzempliorių `n` egzempliorių įrašą su tinkamu užpildų kiekiu tarp kiekvieno, kad būtų užtikrinta, jog kiekvienam egzemplioriui bus suteiktas reikalaujamas dydis ir lygiavimas.
    /// Sėkmingai pateikia `(k, offs)`, kur `k` yra masyvo išdėstymas, o `offs`-atstumas tarp kiekvieno masyvo elemento pradžios.
    ///
    /// Aritmetiniam perpildymui grąžinama `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Tai negali perpildyti.Citata iš išdėstymo varianto:
        // > `size`, suapvalinus iki artimiausio `align` kartotinio,
        // > neturi būti perpildyta (ty suapvalinta vertė turi būti mažesnė nei
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAUGUMAS: Jau žinoma, kad " self.align galioja, o " all_size` buvo
        // jau paminkštintas.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Sukuriamas išdėstymas, apibūdinantis įrašą " `self`, po kurio seka " `next`, įskaitant visus būtinus užpildus, kad būtų užtikrinta, jog " `next` bus tinkamai sulygiuotas, tačiau *nėra galinio užpildymo*.
    ///
    /// Norėdami suderinti C vaizdavimo išdėstymą `repr(C)`, turėtumėte paskambinti į `pad_to_align`, išplėtę išdėstymą su visais laukais.
    /// (Jokiu būdu negalima suderinti numatytojo Rust vaizdavimo išdėstymo `repr(Rust)`, as it is unspecified.)
    ///
    /// Atminkite, kad gautas maketas bus sulygiuojamas maksimaliai, lyginant su `self` ir `next`, kad būtų užtikrintas abiejų dalių sulygiavimas.
    ///
    /// Pateikia `Ok((k, offset))`, kur `k` yra sujungto įrašo išdėstymas, o `offset`-santykinė `next` pradžios vieta, įdėta susietame įraše, darant prielaidą, kad pats įrašas prasideda nuo 0 poslinkio).
    ///
    ///
    /// Aritmetiniam perpildymui grąžinama `LayoutError`.
    ///
    /// # Examples
    ///
    /// Norėdami apskaičiuoti `#[repr(C)]` struktūros išdėstymą ir laukų poslinkius pagal jos laukų maketus:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Nepamirškite baigti su `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // patikrinkite, ar jis veikia
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Sukuria maketą, apibūdinantį `self` egzempliorių `n` įrašą, be kiekvieno egzemplioriaus.
    ///
    /// Atminkite, kad, skirtingai nei `repeat`, `repeat_packed` negarantuoja, kad pakartotiniai `self` egzemplioriai bus tinkamai sulygiuoti, net jei tam tikras `self` egzempliorius yra tinkamai sulygiuotas.
    /// Kitaip tariant, jei masyvui priskirti naudojamas `repeat_packed` grąžintas maketas, negarantuojama, kad visi masyvo elementai bus tinkamai sulygiuoti.
    ///
    /// Aritmetiniam perpildymui grąžinama `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Sukuria išdėstymą, apibūdinantį " `self` įrašą, po kurio seka " `next`, be papildomo užpildymo tarp šių dviejų.
    /// Kadangi nėra įdėto užpildo, " `next` sulyginimas yra nesvarbus ir į gautą išdėstymą visiškai nėra įtrauktas *.
    ///
    ///
    /// Aritmetiniam perpildymui grąžinama `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Sukuria išdėstymą, apibūdinantį " `[T; n]` įrašą.
    ///
    /// Aritmetiniam perpildymui grąžinama `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` ar kitam `Layout` konstruktoriui pateikti parametrai netenkina jo dokumentuotų apribojimų.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (mums to reikia pasroviui trait klaidos implikuoti)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}