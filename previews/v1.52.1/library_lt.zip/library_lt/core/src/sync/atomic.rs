//! Atominiai tipai
//!
//! Atominiai tipai teikia primityvų bendrosios atminties ryšį tarp gijų ir yra kitų vienu metu esančių tipų blokai.
//!
//! Šis modulis apibrėžia pasirinktų primityvių tipų, įskaitant [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] ir kt., Atomines versijas.
//! " Atomic` tipuose pateikiamos operacijos, kurios, tinkamai naudojant, sinchronizuoja atnaujinimus tarp gijų.
//!
//! Kiekvienam metodui reikia [`Ordering`], kuris atspindi atminties barjero stiprumą šiai operacijai.Šie užsakymai yra tokie patys kaip " [C++20 atomic orderings][1].Norėdami gauti daugiau informacijos, žr. " [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atominius kintamuosius saugu dalytis tarp gijų (jie įgyvendina [`Sync`]), tačiau jie patys nesuteikia dalijimosi mechanizmo ir vadovaujasi Rust [threading model](../../../std/thread/index.html#the-threading-model).
//!
//! Dažniausias būdas dalytis atominiu kintamuoju yra įdėti jį į [`Arc`][arc] (atominės nuorodos skaičiuojamas bendras rodyklė).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomų tipai gali būti saugomi statiniuose kintamuosiuose, inicializuojami naudojant pastovius inicializatorius, pvz., [`AtomicBool::new`].Atoma statika dažnai naudojama tingiam globaliam inicijavimui.
//!
//! # Portability
//!
//! Garantuojama, kad visi šio modulio atomų tipai bus [lock-free], jei jų yra.Tai reiškia, kad jie viduje neįgyja globalaus mutekso.Garantuojama, kad atomų tipai ir operacijos nebus laukiamos.
//! Tai reiškia, kad tokios operacijos kaip `fetch_or` gali būti įgyvendinamos naudojant palyginimo ir keitimo kilpą.
//!
//! Atominės operacijos gali būti vykdomos instrukcijų sluoksnyje su didesnio dydžio atomika.Pavyzdžiui, kai kurios platformos naudoja 4 baitų atomines instrukcijas, kad įdiegtų " `AtomicI8`.
//! Atkreipkite dėmesį, kad ši emuliacija neturėtų turėti įtakos kodo teisingumui, tiesiog reikia žinoti apie tai.
//!
//! Šio modulio atomų tipai gali būti prieinami ne visose platformose.Vis dėlto atominiai tipai čia yra plačiai prieinami ir paprastai jais galima pasikliauti.Kai kurios žymios išimtys yra šios:
//!
//! * PowerPC ir MIPS platformose su 32 bitų rodyklėmis nėra `AtomicU64` arba `AtomicI64` tipų.
//! * ARM tokios platformos kaip `armv5te`, kurios nėra skirtos Linux, teikia tik `load` ir `store` operacijas ir nepalaiko (CAS) palyginimo ir keitimo operacijų, tokių kaip `swap`, `fetch_add` ir kt.
//! Be to, naudojant " Linux, šios CAS operacijos yra vykdomos per " [operating system support], už kurią gali būti skiriama bauda už našumą.
//! * ARM taikiniai su `thumbv6m` teikia tik `load` ir `store` operacijas ir nepalaiko (CAS) palyginimo ir keitimo operacijų, tokių kaip `swap`, `fetch_add` ir kt.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Atminkite, kad gali būti pridėtos future platformos, kurios taip pat nepalaiko kai kurių atominių operacijų.Maksimaliai perkeliamas kodas norės būti atsargus, kokie atomų tipai naudojami.
//! `AtomicUsize` ir " `AtomicIsize` dažniausiai yra patys nešiojami, tačiau net tada jų nėra visur.
//! `std` bibliotekai reikia žymeklio dydžio atomų, nors `core` to nereikia.
//!
//! Šiuo metu pirmiausia turėsite naudoti " `#[cfg(target_arch)]`, kad sąlygiškai sukompiluotumėte kodą su atomais.Taip pat yra nestabilus `#[cfg(target_has_atomic)]`, kuris gali būti stabilizuotas future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Paprastas " spinlock`:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Palaukite, kol kitas siūlas atlaisvins spyną
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Laikykite pasaulinį gyvų gijų skaičių:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Būlio tipas, kurį galima saugiai bendrinti tarp gijų.
///
/// Šis tipas atmintyje atvaizduoja tą patį kaip " [`bool`].
///
/// **Pastaba**: Šis tipas galimas tik platformose, palaikančiose atomines apkrovas ir `u8` saugyklas.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Sukuria `AtomicBool`, inicijuotą `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Siuntimas yra netiesiogiai įgyvendintas " AtomicBool`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Neapdorotas žymeklio tipas, kurį galima saugiai bendrinti tarp gijų.
///
/// Šis tipas atmintyje atvaizduoja tą patį kaip " `*mut T`.
///
/// **Pastaba**: Šis tipas galimas tik platformose, palaikančiose atomines apkrovas ir rodyklių atsargas.
/// Jo dydis priklauso nuo tikslinio rodyklės dydžio.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Sukuria nulinę `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atominės atminties tvarka
///
/// Atminties tvarka nurodo, kaip atominės operacijos sinchronizuoja atmintį.
/// Silpniausiu " [`Ordering::Relaxed`] sinchronizuojama tik operacijos metu tiesiogiai paliesta atmintis.
/// Kita vertus, " [`Ordering::SeqCst`] operacijų parduotuvės pakrovimo pora sinchronizuoja kitą atmintį, kartu išsaugodama bendrą tokių operacijų tvarką visose gijose.
///
///
/// " Rust` atminties tvarka yra [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Norėdami gauti daugiau informacijos, žiūrėkite " [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Jokių užsakymo apribojimų, atliekamos tik atominės operacijos.
    ///
    /// Atitinka [`memory_order_relaxed`], esant C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Kartu su parduotuve visos ankstesnės operacijos bus užsakomos prieš bet kokią šios vertės apkrovą užsakant [`Acquire`] (arba stipresnį).
    ///
    /// Visų pirma, visi ankstesni įrašai tampa matomi visoms gijoms, atliekančioms šios vertės [`Acquire`] (arba didesnę) apkrovą.
    ///
    /// Atkreipkite dėmesį, kad naudojant šį užsakymą operacijai, kuri sujungia apkrovas ir kaupia, atliekama [`Relaxed`] apkrovos operacija!
    ///
    /// Šis užsakymas taikomas tik operacijoms, kurios gali atlikti parduotuvę.
    ///
    /// Atitinka [`memory_order_release`], esant C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Kartu su apkrova, jei pakrauta vertė buvo užrašyta parduotuvės operacija su [`Release`] (arba stipresniu) užsakymu, tada visos tolesnės operacijos bus užsakomos po tos parduotuvės.
    /// Visų vėlesnių apkrovų duomenys matys įrašytus prieš parduotuvę.
    ///
    /// Atkreipkite dėmesį, kad naudojant šį užsakymą operacijai, kurioje derinamos apkrovos ir saugyklos, atliekama [`Relaxed`] parduotuvės operacija!
    ///
    /// Šis užsakymas taikomas tik operacijoms, kurios gali atlikti apkrovą.
    ///
    /// Atitinka [`memory_order_acquire`], esant C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Turi ir [`Acquire`], ir [`Release`] poveikį kartu:
    /// Kroviniams jis naudoja [`Acquire`] užsakymą.Parduotuvėms jis naudoja " [`Release`] užsakymą.
    ///
    /// Atkreipkite dėmesį, kad " `compare_and_swap` atveju gali būti, kad operacija neatlieka jokios parduotuvės, todėl ji tik užsako " [`Acquire`].
    ///
    /// Tačiau " `AcqRel` niekada neatliks " [`Relaxed`] prieigų.
    ///
    /// Šis užsakymas taikomas tik operacijoms, kurios sujungia tiek krovinius, tiek atsargas.
    ///
    /// Atitinka [`memory_order_acq_rel`], esant C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Panašiai kaip [" Įsigyti`]/[" Atleisti`]/[" " AcqRel `](atitinkamai atliekant įkėlimo, saugojimo ir įkėlimo su parduotuve operacijas) su papildoma garantija, kad visos gijos mato visas nuosekliai nuoseklias operacijas ta pačia tvarka .
    ///
    ///
    /// Atitinka [`memory_order_seq_cst`], esant C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] inicializuota į `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Sukuria naują " `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Pateikia kintamą nuorodą į pagrindinį [`bool`].
    ///
    /// Tai yra saugu, nes kintama nuoroda garantuoja, kad jokios kitos gijos tuo pačiu metu nepasiekia atominių duomenų.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SAUGUMAS: keičiama nuoroda garantuoja unikalią nuosavybę.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Gaukite atominę prieigą prie " `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SAUGA: keičiama nuoroda garantuoja unikalią nuosavybę ir
        // `bool` ir `Self` lygiavimas yra 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Suvartoja atomą ir grąžina esančią vertę.
    ///
    /// Tai yra saugu, nes perduodant `self` pagal vertę garantuojama, kad jokie kiti siūlai tuo pačiu metu nepasiekia atominių duomenų.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Įkelia vertę iš bool.
    ///
    /// `load` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Galimos vertės yra [`SeqCst`], [`Acquire`] ir [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jei `order` yra [`Release`] arba [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SAUGUMAS: atominės savybės ir neapdoroti duomenys užkerta kelią bet kokioms duomenų lenktynėms
        // pateiktas žymeklis galioja, nes jį gavome iš nuorodos.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Vertę saugo bool.
    ///
    /// `store` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Galimos vertės yra [`SeqCst`], [`Release`] ir [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jei `order` yra [`Acquire`] arba [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SAUGUMAS: atominės savybės ir neapdoroti duomenys užkerta kelią bet kokioms duomenų lenktynėms
        // pateiktas žymeklis galioja, nes jį gavome iš nuorodos.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Vertę saugo bool, grąžindama ankstesnę vertę.
    ///
    /// `swap` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Vertė įrašoma į [`bool`], jei dabartinė vertė yra tokia pati kaip `current`.
    ///
    /// Grąžinimo vertė visada yra ankstesnė.Jei ji lygi `current`, vertė buvo atnaujinta.
    ///
    /// `compare_and_swap` taip pat paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Atkreipkite dėmesį, kad net naudojant [`AcqRel`] operacija gali nepavykti, todėl tiesiog atlikite `Acquire` apkrovą, bet neturite `Release` semantikos.
    /// Naudojant [`Acquire`], parduotuvė tampa šios operacijos dalimi [`Relaxed`], jei taip atsitinka, o naudojant [`Release`], apkrovos dalis tampa [`Relaxed`].
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Pereinama į `compare_exchange` ir `compare_exchange_weak`
    ///
    /// `compare_and_swap` yra lygiavertis `compare_exchange` su tokiu atvaizdavimu atminties tvarka:
    ///
    /// Originalas |Sėkmė |Nesėkmė
    /// -------- | ------- | -------
    /// Atsipalaidavęs |Atsipalaidavęs |Atsipalaidavę įsigykiteĮsigyti |Įsigyti leidimąPaleisti |Atsipalaidavęs AcqRel |AcqRel |Įsigykite SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` leidžiama netinkamai sugesti net tada, kai palyginimas pavyksta, o tai leidžia kompiliatoriui sugeneruoti geresnį surinkimo kodą, kai palyginimas ir apsikeitimas naudojamas cikle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Vertė įrašoma į [`bool`], jei dabartinė vertė yra tokia pati kaip `current`.
    ///
    /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
    /// Sėkmingai ši vertė bus lygi `current`.
    ///
    /// `compare_exchange` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
    /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
    ///
    /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Vertė įrašoma į [`bool`], jei dabartinė vertė yra tokia pati kaip `current`.
    ///
    /// Skirtingai nei " [`AtomicBool::compare_exchange`], šiai funkcijai leidžiama netikrai sugesti net tada, kai pavyksta palyginti, o tai gali sukelti efektyvesnį kodą kai kuriose platformose.
    ///
    /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
    ///
    /// `compare_exchange_weak` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
    /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
    /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Loginis "and" su logine verte.
    ///
    /// Atlieka loginę "and" operaciją su esama reikšme ir argumentu `val` ir nustato naują reikšmę rezultatui.
    ///
    /// Grąžina ankstesnę vertę.
    ///
    /// `fetch_and` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Loginis "nand" su logine verte.
    ///
    /// Atlieka loginę "nand" operaciją su esama reikšme ir argumentu `val` ir nustato naują reikšmę rezultatui.
    ///
    /// Grąžina ankstesnę vertę.
    ///
    /// `fetch_nand` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Čia negalime naudoti " atomic_nand`, nes dėl to gali atsirasti bool su neteisinga verte.
        // Taip atsitinka todėl, kad atominė operacija atliekama naudojant 8 bitų sveikąjį skaičių, kuris nustatytų viršutinius 7 bitus.
        //
        // Taigi mes tiesiog naudojame " fetch_xor`arba " swap`.
        if val {
            // ! (x&true)== !x Turime apversti bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Mes turime nustatyti bool tiesą.
            //
            self.swap(true, order)
        }
    }

    /// Loginis "or" su logine verte.
    ///
    /// Atlieka loginę "or" operaciją su esama reikšme ir argumentu `val` ir nustato naują reikšmę rezultatui.
    ///
    /// Grąžina ankstesnę vertę.
    ///
    /// `fetch_or` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Loginis "xor" su logine verte.
    ///
    /// Atlieka loginę "xor" operaciją su esama reikšme ir argumentu `val` ir nustato naują reikšmę rezultatui.
    ///
    /// Grąžina ankstesnę vertę.
    ///
    /// `fetch_xor` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Grąžina kintamą rodyklę į pagrindinį [`bool`].
    ///
    /// Atominis skaitymas ir rašymas gautame sveikame skaičiuje gali būti duomenų lenktynės.
    /// Šis metodas dažniausiai naudingas FFI, kur funkcijos parašas vietoj `&AtomicBool` gali naudoti `*mut bool`.
    ///
    /// `*mut` žymeklio grąžinimas iš bendros nuorodos į šį atomą yra saugus, nes atomų tipai veikia su vidiniu kintamumu.
    /// Visi atomo modifikacijos keičia vertę naudodamiesi bendra nuoroda ir gali tai padaryti saugiai, jei tik naudojasi atominėmis operacijomis.
    /// Norint naudoti grąžinamą neapdorotą rodyklę, reikalingas `unsafe` blokas ir vis tiek turi būti laikomasi to paties apribojimo: operacijos su juo turi būti atominės.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Gauna vertę ir pritaiko jai funkciją, kuri grąžina pasirenkamą naują vertę.Gauna `Ok(previous_value)` iš `Ok(previous_value)`, jei funkcija grąžino `Some(_)`, kitu atveju `Err(previous_value)`.
    ///
    /// Note: Tai gali iškviesti funkciją kelis kartus, jei tuo tarpu vertė buvo pakeista iš kitų gijų, jei funkcija grąžina `Some(_)`, tačiau išsaugotai vertei funkcija bus pritaikyta tik vieną kartą.
    ///
    ///
    /// `fetch_update` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// Pirmame aprašomas reikalingas užsakymas, kai operacija pagaliau pavyksta, o antrasis-reikalingas krovinių užsakymas.
    /// Tai atitinka " [`AtomicBool::compare_exchange`] sėkmės ir nesėkmės užsakymus.
    ///
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`]-galutinis sėkmingas " [`Relaxed`] įkelimas.
    /// " (failed) užsakymas gali būti tik " [`SeqCst`], " [`Acquire`] arba " [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas naudojant " `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Sukuria naują " `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Grąžina kintamą nuorodą į pagrindinį rodyklę.
    ///
    /// Tai yra saugu, nes kintama nuoroda garantuoja, kad jokios kitos gijos tuo pačiu metu nepasiekia atominių duomenų.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Gaukite atominę prieigą prie rodyklės.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - kintama nuoroda garantuoja unikalią nuosavybę.
        //  - `*mut T` ir `Self` lygiavimas yra tas pats visose platformose, kurias palaiko rust, kaip patvirtinta aukščiau.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Suvartoja atomą ir grąžina esančią vertę.
    ///
    /// Tai yra saugu, nes perduodant `self` pagal vertę garantuojama, kad jokie kiti siūlai tuo pačiu metu nepasiekia atominių duomenų.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Įkelia vertę iš žymeklio.
    ///
    /// `load` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Galimos vertės yra [`SeqCst`], [`Acquire`] ir [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jei `order` yra [`Release`] arba [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Vertę įrašo į rodyklę.
    ///
    /// `store` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Galimos vertės yra [`SeqCst`], [`Release`] ir [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, jei `order` yra [`Acquire`] arba [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Vertę saugo žymeklyje, grąžindama ankstesnę vertę.
    ///
    /// `swap` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
    /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
    ///
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas rodyklėse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Vertę įrašo į rodyklę, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
    ///
    /// Grąžinimo vertė visada yra ankstesnė.Jei ji lygi `current`, vertė buvo atnaujinta.
    ///
    /// `compare_and_swap` taip pat paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
    /// Atkreipkite dėmesį, kad net naudojant [`AcqRel`] operacija gali nepavykti, todėl tiesiog atlikite `Acquire` apkrovą, bet neturite `Release` semantikos.
    /// Naudojant [`Acquire`], parduotuvė tampa šios operacijos dalimi [`Relaxed`], jei taip atsitinka, o naudojant [`Release`], apkrovos dalis tampa [`Relaxed`].
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas rodyklėse.
    ///
    /// # Pereinama į `compare_exchange` ir `compare_exchange_weak`
    ///
    /// `compare_and_swap` yra lygiavertis `compare_exchange` su tokiu atvaizdavimu atminties tvarka:
    ///
    /// Originalas |Sėkmė |Nesėkmė
    /// -------- | ------- | -------
    /// Atsipalaidavęs |Atsipalaidavęs |Atsipalaidavę įsigykiteĮsigyti |Įsigyti leidimąPaleisti |Atsipalaidavęs AcqRel |AcqRel |Įsigykite SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` leidžiama netinkamai sugesti net tada, kai palyginimas pavyksta, o tai leidžia kompiliatoriui sugeneruoti geresnį surinkimo kodą, kai palyginimas ir apsikeitimas naudojamas cikle.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Vertę įrašo į rodyklę, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
    ///
    /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
    /// Sėkmingai ši vertė bus lygi `current`.
    ///
    /// `compare_exchange` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
    /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
    ///
    /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas rodyklėse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Vertę įrašo į rodyklę, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
    ///
    /// Skirtingai nei " [`AtomicPtr::compare_exchange`], šiai funkcijai leidžiama netikrai sugesti net tada, kai pavyksta palyginti, o tai gali sukelti efektyvesnį kodą kai kuriose platformose.
    ///
    /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
    ///
    /// `compare_exchange_weak` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
    /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
    /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas rodyklėse.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SAUGA: Ši savybė yra nesaugi, nes ji veikia pagal neapdorotą rodyklę
        // bet mes tikrai žinome, kad rodyklė galioja (ką tik gavome iš `UnsafeCell`, kurią turime kaip nuorodą), o pati atominė operacija leidžia saugiai mutuoti `UnsafeCell` turinį.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Gauna vertę ir pritaiko jai funkciją, kuri grąžina pasirenkamą naują vertę.Gauna `Ok(previous_value)` iš `Ok(previous_value)`, jei funkcija grąžino `Some(_)`, kitu atveju `Err(previous_value)`.
    ///
    /// Note: Tai gali iškviesti funkciją kelis kartus, jei tuo tarpu vertė buvo pakeista iš kitų gijų, jei funkcija grąžina `Some(_)`, tačiau išsaugotai vertei funkcija bus pritaikyta tik vieną kartą.
    ///
    ///
    /// `fetch_update` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
    /// Pirmame aprašomas reikalingas užsakymas, kai operacija pagaliau pavyksta, o antrasis-reikalingas krovinių užsakymas.
    /// Tai atitinka " [`AtomicPtr::compare_exchange`] sėkmės ir nesėkmės užsakymus.
    ///
    /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`]-galutinis sėkmingas " [`Relaxed`] įkelimas.
    /// " (failed) užsakymas gali būti tik " [`SeqCst`], " [`Acquire`] arba " [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
    ///
    /// **Note:** Šis metodas galimas tik platformose, palaikančiose atomines operacijas rodyklėse.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` paverčia `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ši makrokomanda gali būti nenaudojama kai kuriose architektūrose.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Sveiko skaičiaus tipas, kurį galima saugiai bendrinti tarp gijų.
        ///
        /// Šis tipas atmintyje atvaizduoja tą patį, kaip ir pagrindinis sveikojo skaičiaus tipas ["
        ///
        #[doc = $s_int_type]
        /// `].
        /// Norėdami sužinoti daugiau apie atomų tipų ir ne atomų tipų skirtumus, taip pat informacijos apie šio tipo perkeliamumą, žr. [module-level documentation].
        ///
        ///
        /// **Note:** Šis tipas galimas tik platformose, palaikančiose atomines apkrovas ir [
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atomo sveikasis skaičius inicijuojamas iki `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Siuntimas yra netiesiogiai įgyvendintas.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Sukuria naują atominį skaičių.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Pateikia kintamą nuorodą į pagrindinį sveikąjį skaičių.
            ///
            /// Tai yra saugu, nes kintama nuoroda garantuoja, kad jokios kitos gijos tuo pačiu metu nepasiekia atominių duomenų.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// tegul mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - kintama nuoroda garantuoja unikalią nuosavybę.
                //  - `$int_type` ir `Self` lygiavimas yra toks pat, kaip žadėjo $cfg_align ir patvirtino aukščiau.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Suvartoja atomą ir grąžina esančią vertę.
            ///
            /// Tai yra saugu, nes perduodant `self` pagal vertę garantuojama, kad jokie kiti siūlai tuo pačiu metu nepasiekia atominių duomenų.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Įkelia vertę iš atomo sveikojo skaičiaus.
            ///
            /// `load` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
            /// Galimos vertės yra [`SeqCst`], [`Acquire`] ir [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, jei `order` yra [`Release`] arba [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Vertę įrašo į atomo sveikąjį skaičių.
            ///
            /// `store` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
            ///  Galimos vertės yra [`SeqCst`], [`Release`] ir [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, jei `order` yra [`Acquire`] arba [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Vertė įrašoma į atomo sveikąjį skaičių, grąžinant ankstesnę vertę.
            ///
            /// `swap` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Vertė įrašoma į atomo sveikąjį skaičių, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
            ///
            /// Grąžinimo vertė visada yra ankstesnė.Jei ji lygi `current`, vertė buvo atnaujinta.
            ///
            /// `compare_and_swap` taip pat paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.
            /// Atkreipkite dėmesį, kad net naudojant [`AcqRel`] operacija gali nepavykti, todėl tiesiog atlikite `Acquire` apkrovą, bet neturite `Release` semantikos.
            ///
            /// Naudojant [`Acquire`], parduotuvė tampa šios operacijos dalimi [`Relaxed`], jei taip atsitinka, o naudojant [`Release`], apkrovos dalis tampa [`Relaxed`].
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Pereinama į `compare_exchange` ir `compare_exchange_weak`
            ///
            /// `compare_and_swap` yra lygiavertis `compare_exchange` su tokiu atvaizdavimu atminties tvarka:
            ///
            /// Originalas |Sėkmė |Nesėkmė
            /// -------- | ------- | -------
            /// Atsipalaidavęs |Atsipalaidavęs |Atsipalaidavę įsigykiteĮsigyti |Įsigyti leidimąPaleisti |Atsipalaidavęs AcqRel |AcqRel |Įsigykite SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` leidžiama netinkamai sugesti net tada, kai palyginimas pavyksta, o tai leidžia kompiliatoriui sugeneruoti geresnį surinkimo kodą, kai palyginimas ir apsikeitimas naudojamas cikle.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Vertė įrašoma į atomo sveikąjį skaičių, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
            ///
            /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
            /// Sėkmingai ši vertė bus lygi `current`.
            ///
            /// `compare_exchange` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
            /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
            /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
            /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
            ///
            /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Vertė įrašoma į atomo sveikąjį skaičių, jei dabartinė vertė yra tokia pati kaip `current` reikšmė.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// šiai funkcijai leidžiama netikrai sugesti net tada, kai pavyksta palyginti, o tai gali sukelti efektyvesnį kodą kai kuriose platformose.
            /// Grąžinimo vertė yra rezultatas, nurodantis, ar naujoji vertė buvo parašyta ir kurioje buvo ankstesnė vertė.
            ///
            /// `compare_exchange_weak` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
            /// `success` aprašomas reikalingas skaitymo, modifikavimo ir rašymo operacijos užsakymas, kuris vyksta, jei pavyks palyginti su `current`.
            /// `failure` aprašomas reikalingas užsakymas apkrovos operacijai, kuri vyksta nepavykus palyginimui.
            /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`] sėkmingai įkeliama " [`Relaxed`].
            ///
            /// Gedimų užsakymas gali būti tik [`SeqCst`], [`Acquire`] arba [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// tegul mut senas= val.load(Ordering::Relaxed);
            /// kilpa {tegul nauja=sena * 2;
            ///     rungtynės val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Pridedama prie dabartinės vertės, grąžinant ankstesnę vertę.
            ///
            /// Ši operacija apgaubia perpildymą.
            ///
            /// `fetch_add` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Atima iš dabartinės vertės, grąžindama ankstesnę vertę.
            ///
            /// Ši operacija apgaubia perpildymą.
            ///
            /// `fetch_sub` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitai "and" su dabartine verte.
            ///
            /// Atlieka dabartinę vertę ir argumentą `val` bitų "and" operacija ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_and` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitai "nand" su dabartine verte.
            ///
            /// Atlieka dabartinę vertę ir argumentą `val` bitų "nand" operacija ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_nand` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 ir 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitai "or" su dabartine verte.
            ///
            /// Atlieka dabartinę vertę ir argumentą `val` bitų "or" operacija ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_or` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitai "xor" su dabartine verte.
            ///
            /// Atlieka dabartinę vertę ir argumentą `val` bitų "xor" operacija ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_xor` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Gauna vertę ir pritaiko jai funkciją, kuri grąžina pasirenkamą naują vertę.Gauna `Ok(previous_value)` iš `Ok(previous_value)`, jei funkcija grąžino `Some(_)`, kitu atveju `Err(previous_value)`.
            ///
            /// Note: Tai gali iškviesti funkciją kelis kartus, jei tuo tarpu vertė buvo pakeista iš kitų gijų, jei funkcija grąžina `Some(_)`, tačiau išsaugotai vertei funkcija bus pritaikyta tik vieną kartą.
            ///
            ///
            /// `fetch_update` reikia dviejų [`Ordering`] argumentų, apibūdinančių šios operacijos atminties tvarką.
            /// Pirmame aprašomas reikalingas užsakymas, kai operacija pagaliau pavyksta, o antrasis-reikalingas krovinių užsakymas.Tai atitinka " Sėkmės ir nesėkmės` užsakymus
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Naudojant " [`Acquire`] kaip sėkmingą užsakymą, parduotuvė tampa šios operacijos dalimi " [`Relaxed`], o naudojant " [`Release`]-galutinis sėkmingas " [`Relaxed`] įkelimas.
            /// " (failed) užsakymas gali būti tik " [`SeqCst`], " [`Acquire`] arba " [`Relaxed`] ir turi būti lygiavertis arba silpnesnis už sėkmingą užsakymą.
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (užsakymas: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (užsakymas: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Didžiausia su dabartine verte.
            ///
            /// Randa maksimalią dabartinę vertę ir argumentą `val` ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_max` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// tegul baras=42;
            /// tegul max_foo=foo.fetch_max (juosta, Ordering::SeqCst).max(bar);
            /// teigti! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimalus su dabartine verte.
            ///
            /// Randa mažiausią dabartinę vertę ir argumentą `val` ir nustato naują reikšmę rezultatui.
            ///
            /// Grąžina ankstesnę vertę.
            ///
            /// `fetch_min` paima [`Ordering`] argumentą, kuris apibūdina šios operacijos atminties tvarką.Galimi visi užsakymo režimai.
            /// Atminkite, kad naudojant [`Acquire`] parduotuvė tampa šios operacijos dalimi [`Relaxed`], o naudojant [`Release`] apkrovos dalis tampa [`Relaxed`].
            ///
            ///
            /// **Pastaba**: Šis metodas galimas tik platformose, palaikančiose atomines operacijas
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// tegul baras=12;
            /// tegul min_foo=foo.fetch_min (juosta, Ordering::SeqCst).min(bar);
            /// teigti_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SAUGUMAS: atominės savybės užkerta kelią duomenų lenktynėms.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Grąžina kintamą rodyklę į pagrindinį skaičių.
            ///
            /// Atominis skaitymas ir rašymas gautame sveikame skaičiuje gali būti duomenų lenktynės.
            /// Šis metodas dažniausiai naudingas FFI, kur gali būti naudojamas funkcijos parašas
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// `*mut` žymeklio grąžinimas iš bendros nuorodos į šį atomą yra saugus, nes atomų tipai veikia su vidiniu kintamumu.
            /// Visi atomo modifikacijos keičia vertę naudodamiesi bendra nuoroda ir gali tai padaryti saugiai, jei tik naudojasi atominėmis operacijomis.
            /// Norint naudoti grąžinamą neapdorotą rodyklę, reikalingas `unsafe` blokas ir vis tiek turi būti laikomasi to paties apribojimo: operacijos su juo turi būti atominės.
            ///
            ///
            /// # Examples
            ///
            /// " ignoruokite (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// išorinis "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SAUGA: saugu tol, kol `my_atomic_op` yra atominis.
            /// nesaugus {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_store` saugos sutarties.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_load` saugos sutarties.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_swap` saugos sutarties.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Grąžina ankstesnę vertę (pvz., __Sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_add` saugos sutarties.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Grąžina ankstesnę vertę (pvz., __Sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_sub` saugos sutarties.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_compare_exchange` saugos sutarties.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_compare_exchange_weak` saugos sutarties.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_and` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_nand` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_or` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_xor` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// grąžina maksimalią vertę (pasirašytas palyginimas)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_max` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// grąžina min. vertę (pasirašytas palyginimas)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_min` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// grąžina maksimalią vertę (nepasirašytas palyginimas)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_umax` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// grąžina minimalią vertę (nepasirašytas palyginimas)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAUGUMAS: skambinantysis privalo laikytis " `atomic_umin` saugos sutarties
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atominė tvora.
///
/// Priklausomai nuo nurodytos tvarkos, tvora neleidžia kompiliatoriui ir procesoriui pertvarkyti tam tikrų tipų atminties operacijų aplink jį.
/// Tai sukuria sinchronizavimo ryšius tarp jo ir atominių operacijų ar tvorų kitose gijose.
///
/// Tvora 'A', turinti (bent jau) [`Release`] užsakymo semantiką, sinchronizuojasi su tvora 'B' su (bent jau) [`Acquire`] semantika, jei ir tik tada, jei yra operacijos X ir Y, kurios abi veikia su kažkokiu atominiu objektu 'M' taip, kad A yra sekvenuota prieš tai X, Y sinchronizuojamas prieš B ir Y stebint pasikeitimą į M
/// Tai suteikia priklausomybę tarp įvykių prieš A ir B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atominės operacijos su [`Release`] arba [`Acquire`] semantika taip pat gali būti sinchronizuojamos su tvora.
///
/// Tvora, turinti [`SeqCst`] užsakymą, be [`Acquire`] ir [`Release`] semantikos, dalyvauja kitų [`SeqCst`] operacijų ir (arba) tvorų pasaulinėje programų tvarkoje.
///
/// Priima [`Acquire`], [`Release`], [`AcqRel`] ir [`SeqCst`] užsakymus.
///
/// # Panics
///
/// Panics, jei `order` yra [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Abipusės atskirties primityvumas, pagrįstas nugara.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Palaukite, kol senoji vertė bus `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ši tvora sinchronizuojama su " `unlock` parduotuve.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SAUGA: naudoti atominę tvorą yra saugu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Kompiliatoriaus atminties tvora.
///
/// `compiler_fence` neišleidžia jokio kompiuterio kodo, tačiau apriboja atminties rūšis, kurias leidžiama pertvarkyti kompiliatoriui.Konkrečiai, atsižvelgiant į pateiktą [`Ordering`] semantiką, kompiliatorius gali būti neleidžiamas perkelti skaitymų ar rašymų iš skambučio prieš skambutį ar po jo į kitą skambučio `compiler_fence` pusę.Atkreipkite dėmesį, kad tai **netrukdo* aparatinei įrangai * atlikti tokio pertvarkymo.
///
/// Tai nėra problema vieno gijos vykdymo kontekste, tačiau kai kitos gijos gali modifikuoti atmintį tuo pačiu metu, reikalingi stipresni sinchronizavimo primityvai, tokie kaip [`fence`].
///
/// Pertvarkymas, kurio trukdo skirtinga užsakymo semantika, yra:
///
///  - naudojant " [`SeqCst`], skaityti ir rašyti šiame punkte negalima.
///  - naudojant " [`Release`], ankstesnių skaitymų ir rašymų negalima perkelti iš vėlesnių įrašų.
///  - naudojant [`Acquire`], vėlesni skaitymai ir rašymai negali būti perkelti į priekį nuo ankstesnių skaitymų.
///  - naudojant " [`AcqRel`], abi minėtos taisyklės yra vykdomos.
///
/// `compiler_fence` paprastai yra naudingas tik norint užkirsti kelią siūlų lenktynėms *su savimi*.Tai yra, jei tam tikras siūlas vykdo vieną kodo dalį, o tada yra pertrauktas ir pradeda vykdyti kodą kitur (kol jis vis dar yra toje pačioje gijoje ir konceptualiai vis dar yra toje pačioje šerdyje).Tradicinėse programose tai gali atsitikti tik užregistravus signalo tvarkytuvą.
/// Žemesnio lygio kode tokios situacijos taip pat gali kilti tvarkant pertraukimus, diegiant žalias gijas su išankstine parinktimi ir kt.
/// Smalsūs skaitytojai raginami perskaityti Linux branduolio diskusiją apie [memory barriers].
///
/// # Panics
///
/// Panics, jei `order` yra [`Relaxed`].
///
/// # Examples
///
/// Be `compiler_fence`, `assert_eq!` pagal šį kodą nėra garantuotas, kad viskas pavyks, nepaisant to, kad viskas vyksta viena gija.
/// Norėdami sužinoti, kodėl, atminkite, kad kompiliatorius gali laisvai pakeisti parduotuves į `IMPORTANT_VARIABLE` ir `IS_READ`, nes jos abi yra `Ordering::Relaxed`.Jei tai įvyksta ir signalo tvarkytojas yra iškviečiamas iškart po to, kai atnaujinama `IS_READY`, signalo tvarkytojas matys `IS_READY=1`, bet `IMPORTANT_VARIABLE=0`.
/// " `compiler_fence` naudojimas ištaisys šią situaciją.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // užkirsti kelią ankstesniems rašymams peržengti šį tašką
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SAUGA: naudoti atominę tvorą yra saugu.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalizuoja procesorių, kad jis yra užimto laukimo sukimosi cikle (" sukimosi užraktas`).
///
/// Ši funkcija nebenaudojama " [`hint::spin_loop`] naudai.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}