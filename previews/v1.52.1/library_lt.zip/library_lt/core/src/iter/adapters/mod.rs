use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Šis trait suteikia tranzitinę prieigą prie šaltinio etapo interatoriaus-adapterio vamzdyne tokiomis sąlygomis
/// * iteratoriaus šaltinis `S` pats įgyvendina `SourceIter<Source = S>`
/// * yra deleguotas šio trait įgyvendinimas kiekvienam dujotiekio tarp šaltinio ir dujotiekio vartotojo adapteriui.
///
/// Kai šaltinis turi iteratoriaus struktūrą (paprastai vadinamą `IntoIter`), tai gali būti naudinga specializuojantis [`FromIterator`] diegimams arba atkuriant likusius elementus, kai iteratorius bus iš dalies išnaudotas.
///
///
/// Atminkite, kad diegimas nebūtinai turi suteikti prieigą prie vidinio dujotiekio šaltinio.Valstybinis tarpinis adapteris gali nekantriai įvertinti dujotiekio dalį ir parodyti jos vidinę atmintį kaip šaltinį.
///
/// " trait` yra nesaugus, nes diegėjai turi palaikyti papildomas saugos savybes.
/// Išsamesnės informacijos ieškokite [`as_inner`].
///
/// # Examples
///
/// Iš dalies sunaudoto šaltinio gavimas:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Šaltinio etapas iteratoriaus vamzdyne.
    type Source: Iterator;

    /// Gaukite iteratoriaus dujotiekio šaltinį.
    ///
    /// # Safety
    ///
    /// Įdiegus turi būti grąžinta ta pati kintama nuoroda per visą jų gyvenimą, nebent jas pakeis skambintojas.
    /// Skambintojai gali pakeisti nuorodą tik nutraukę iteraciją ir nuleidę iteratoriaus vamzdyną, ištraukę šaltinį.
    ///
    /// Tai reiškia, kad iteratoriaus adapteriai gali pasikliauti tuo, kad šaltinis nepakinta kartojant, tačiau jie negali juo pasikliauti įgyvendindami " Drop`.
    ///
    /// Šio metodo įgyvendinimas reiškia, kad adapteriai atsisako privačios prieigos prie savo šaltinio ir gali pasikliauti tik garantijomis, suteikiamomis remiantis metodų imtuvų tipais.
    /// Ribotos prieigos nebuvimas taip pat reikalauja, kad adapteriai turėtų išlaikyti šaltinio viešąją API, net jei jie turi prieigą prie jo vidinės dalies.
    ///
    /// Savo ruožtu skambintojai turi tikėtis, kad šaltinis bus bet kurioje būsenoje, atitinkančioje jo viešąją API, nes tarp jo ir šaltinio sėdintys adapteriai turi tą pačią prieigą.
    /// Visų pirma, adapteris galėjo sunaudoti daugiau elementų, nei būtina.
    ///
    /// Bendras šių reikalavimų tikslas-leisti vartotojui naudotis dujotiekiu
    /// * viskas, kas lieka šaltinyje po iteracijos pabaigos
    /// * atmintis, kuri tapo nepanaudota vartojant iteratorių
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Kartotuvo adapteris, kuris sukuria išvestį tol, kol pagrindinis iteratorius sukuria `Result::Ok` reikšmes.
///
///
/// Jei įvyksta klaida, iteratorius sustoja ir klaida išsaugoma.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Apdorokite pateiktą iteratorių taip, lyg gautumėte `T`, o ne `Result<T, _>`.
/// Bet kokios klaidos sustabdys vidinį iteratorių, o bendras rezultatas bus klaida.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}