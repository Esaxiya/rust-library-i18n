/// Konversija iš [`Iterator`].
///
/// Įdiegę tipui " `FromIterator`, jūs apibrėžiate, kaip jis bus sukurtas iš iteratoriaus.
/// Tai būdinga tipams, apibūdinantiems tam tikrą kolekciją.
///
/// [`FromIterator::from_iter()`] yra retai vadinamas aiškiai, o vietoj to naudojamas naudojant [`Iterator::collect()`] metodą.
///
/// Daugiau pavyzdžių rasite [`Iterator::collect()`]'s dokumentacijoje.
///
/// Taip pat žiūrėkite: [`IntoIterator`].
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// [`Iterator::collect()`] naudojimas netiesiogiai naudojant `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// " `FromIterator` diegimas jūsų tipui:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Mėginių kolekcija, tai tik " Vec` apvalkalas<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pateiksime keletą metodų, kad galėtume sukurti ir pridėti dalykų.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ir mes įdiegsime " FromIterator`
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Dabar galime sukurti naują iteratorių ...
/// let iter = (0..5).into_iter();
///
/// // ... ir padarykite iš jo " MyCollection`
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // rinkite ir darbus!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Iš iteratoriaus sukuria vertę.
    ///
    /// Norėdami sužinoti daugiau, žiūrėkite " [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konversija į [`Iterator`].
///
/// Įdiegę tipui " `IntoIterator`, jūs apibrėžiate, kaip jis bus konvertuojamas į iteratorių.
/// Tai būdinga tipams, apibūdinantiems tam tikrą kolekciją.
///
/// Vienas iš " `IntoIterator` diegimo pranašumų yra tas, kad jūsų tipas bus " [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Taip pat žiūrėkite: [`FromIterator`].
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// " `IntoIterator` diegimas jūsų tipui:
///
/// ```
/// // Mėginių kolekcija, tai tik " Vec` apvalkalas<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pateiksime keletą metodų, kad galėtume sukurti ir pridėti dalykų.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ir mes įdiegsime " IntoIterator`
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Dabar galime sukurti naują kolekciją ...
/// let mut c = MyCollection::new();
///
/// // ... pridėti į jį šiek tiek daiktų ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ir tada paverskite jį iteratoriumi:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Įprasta `IntoIterator` naudoti kaip trait bound.Tai leidžia pakeisti įvesties rinkinio tipą, jei jis vis dar yra iteratorius.
/// Papildomas ribas galima nurodyti apribojant
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Kartojamų elementų tipas.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Kokiu iteratoriumi mes tai paverčiame?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Iš vertės sukuria iteratorių.
    ///
    /// Norėdami sužinoti daugiau, žiūrėkite " [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Išplėskite kolekciją su iteratoriaus turiniu.
///
/// Iteratoriai sukuria vertybių seriją, o kolekcijas taip pat galima laikyti vertybių serijomis.
/// " `Extend` trait` užpildo šią spragą ir leidžia išplėsti kolekciją įtraukiant to iteratoriaus turinį.
/// Praplečiant rinkinį jau esančiu raktu, tas įrašas atnaujinamas arba, jei rinkiniai leidžia kelis įrašus su vienodais raktais, tas įrašas įterpiamas.
///
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// // Galite pratęsti eilutę keletu simbolių:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// " `Extend` diegimas:
///
/// ```
/// // Mėginių kolekcija, tai tik " Vec` apvalkalas<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Pateiksime keletą metodų, kad galėtume sukurti ir pridėti dalykų.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // kadangi " MyCollection`turi " i32` sąrašą, mes įgyvendiname " i32 skirtą " Extend`
/// impl Extend<i32> for MyCollection {
///
///     // Tai yra šiek tiek paprasčiau su konkretaus tipo parašu: galime skambinti išplėsti bet ką, kas gali būti paversta " Iterator`, suteikiančiu mums " i32`.
///     // Kadangi mums reikia " i32`, kad galėtume juos įdėti į " MyCollection`.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Įgyvendinimas yra labai paprastas: perjunkite iteratorių ir add() kiekvieną elementą sau.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // išplėskime savo kolekciją dar trimis skaičiais
/// c.extend(vec![1, 2, 3]);
///
/// // mes pridėjome šiuos elementus pabaigoje
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Išplečia kolekciją su iteratoriaus turiniu.
    ///
    /// Kadangi tai yra vienintelis reikalingas šio trait metodas, [trait-level] dokumentuose yra daugiau informacijos.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // Galite pratęsti eilutę keletu simbolių:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Išplečia kolekciją su tiksliai vienu elementu.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezerve talpa rezervuojama nurodytam papildomų elementų skaičiui.
    ///
    /// Numatytasis diegimas nieko nedaro.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}