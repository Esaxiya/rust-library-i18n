/// Kartotuvas, kuris visada išeikvoja `None`, kai jis yra išnaudotas.
///
/// Kai skambinsite paskui sujungtu iteratoriumi, kuris vieną kartą grąžino " `None`, garantuotai vėl bus grąžinta " [`None`].
/// Šį " trait`turėtų įgyvendinti visi taip besielgiantys iteratoriai, nes tai leidžia optimizuoti " [`Iterator::fuse()`].
///
///
/// Note: Apskritai neturėtumėte naudoti " `FusedIterator`, jei jums reikalingas sulietas iteratorius.
/// Vietoj to, jūs tiesiog turėtumėte paskambinti [`Iterator::fuse()`] iteratoriuje.
/// Jei iteratorius jau yra sujungtas, papildomas " [`Fuse`] įvyniojimas bus neveiksmingas ir nebus baudžiamas už našumą.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Kartotuvas, kuris pateikia tikslią ilgį naudodamas size_hint.
///
/// Kartotojas pateikia dydžio užuominą, kai ji yra tiksli (apatinė riba lygi viršutinei ribai) arba viršutinė riba yra [`None`].
///
/// Viršutinė riba turi būti [`None`] tik tuo atveju, jei tikrasis iteratoriaus ilgis yra didesnis nei [`usize::MAX`].
/// Tokiu atveju apatinė riba turi būti [`usize::MAX`], todėl X0 `(usize::MAX, None)` turi [`Iterator::size_hint()`].
///
/// Iteratorius turi pateikti tiksliai tiek elementų, apie kuriuos pranešė, arba skirtis, prieš pasiekdamas pabaigą.
///
/// # Safety
///
/// Šis " trait` gali būti įgyvendintas tik tada, kai bus laikomasi sutarties.
/// Šio trait vartotojai turi patikrinti [`Iterator::size_hint()`]’s viršutinę ribą.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Kartotinis, kuris duodamas elementą bus paėmęs bent vieną elementą iš jo pagrindinio [`SourceIter`].
///
/// Skambinimas bet kokiu iteratorių tobulinančiu metodu, pvz
/// [`next()`] arba [`try_fold()`], garantuoja, kad kiekviename etape bent viena iteratoriaus pagrindinio šaltinio vertė buvo perkelta ir iteratoriaus grandinės rezultatas galėtų būti įterptas į jo vietą, darant prielaidą, kad struktūriniai šaltinio apribojimai leidžia tokį įterpimą.
///
/// Kitaip tariant, šis trait rodo, kad iteratoriaus vamzdyną galima surinkti vietoje.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}