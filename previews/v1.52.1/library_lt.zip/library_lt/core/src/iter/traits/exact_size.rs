/// Iteratorius, kuris žino tikslų jo ilgį.
///
/// Daugelis [Iteratorių] nežino, kiek kartų jie kartosis, tačiau kai kurie-taip.
/// Jei kartotojas žino, kiek kartų jis gali kartoti, gali būti naudinga suteikti prieigą prie tos informacijos.
/// Pavyzdžiui, jei norite kartoti atgal, gera pradžia yra žinoti, kur yra pabaiga.
///
/// Įdiegdami " `ExactSizeIterator`, taip pat turite įdiegti " [`Iterator`].
/// Tai darant, [`Iterator::size_hint`]*įgyvendinimas turi* grąžinti tikslų iteratoriaus dydį.
///
/// [`len`] metodas yra numatytasis įgyvendinimas, todėl paprastai neturėtumėte jo įdiegti.
/// Tačiau galite pateikti efektyvesnį diegimą nei numatytasis, todėl šiuo atveju prasminga jį viršyti.
///
///
/// Atkreipkite dėmesį, kad šis trait yra saugus trait ir todėl jis *ne* ir * negali garantuoti, kad grąžintas ilgis yra teisingas.
/// Tai reiškia, kad `unsafe` kodas **neturi** remtis [`Iterator::size_hint`] teisingumu.
/// Nestabilus ir nesaugus " [`TrustedLen`](super::marker::TrustedLen) trait` suteikia šią papildomą garantiją.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// // baigtinis diapazonas tiksliai žino, kiek kartų jis kartosis
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// " [module-level docs] įdiegėme " [`Iterator`], `Counter`.
/// Įgyvendinkime ir " `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Mes galime lengvai apskaičiuoti likusį pakartojimų skaičių.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ir dabar mes galime tai naudoti!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Pateikia tikslų iteratoriaus ilgį.
    ///
    /// Įgyvendinimas užtikrina, kad iteratorius grąžins `len()` daugiau kartų, palyginti su [`Some(T)`] verte, prieš grąžindamas [`None`].
    ///
    /// Šis metodas yra numatytasis įgyvendinimas, todėl paprastai neturėtumėte jo tiesiogiai įgyvendinti.
    /// Tačiau jei galite užtikrinti efektyvesnį įgyvendinimą, galite tai padaryti.
    /// Pavyzdį rasite [trait-level] dokumentuose.
    ///
    /// Ši funkcija turi tas pačias saugumo garantijas kaip ir [`Iterator::size_hint`] funkcija.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // baigtinis diapazonas tiksliai žino, kiek kartų jis kartosis
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Šis teiginys yra pernelyg gynybinis, tačiau jis tikrina nekintantį
        // garantuoja trait.
        // Jei šis trait būtų rust-internal, galėtume naudoti debug_assert !;assert_eq!taip pat patikrins visus " Rust` vartotojo diegimus.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Pateikia `true`, jei iteratorius tuščias.
    ///
    /// Šis metodas yra numatytasis diegimas naudojant [`ExactSizeIterator::len()`], todėl jums nereikia jo įdiegti patiems.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}