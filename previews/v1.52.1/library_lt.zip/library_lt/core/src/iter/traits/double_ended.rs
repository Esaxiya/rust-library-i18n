use crate::ops::{ControlFlow, Try};

/// Kartotojas, galintis pateikti elementus iš abiejų galų.
///
/// Kažkas, kas įgyvendina " `DoubleEndedIterator`, turi vieną papildomą galimybę pritaikyti " [`Iterator`]: galimybę taip pat paimti elementus iš užpakalio ir priekio.
///
///
/// Svarbu pažymėti, kad ir pirmyn, ir atgal veikia tame pačiame diapazone ir nekerta: iteracija baigiasi, kai jie susitinka per vidurį.
///
/// Panašiai kaip " [`Iterator`] protokolas, kai " `DoubleEndedIterator` grąžina " [`None`] iš " [`next_back()`], paskambinus vėl, gali būti, kad niekada nebebus galima grąžinti " [`Some`].
/// [`next()`] ir [`next_back()`] šiuo tikslu yra keičiamos.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Pašalina ir grąžina elementą iš iteratoriaus galo.
    ///
    /// Grąžina `None`, kai nebėra elementų.
    ///
    /// [trait-level] dokumentuose yra daugiau informacijos.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// " DoubleEndedIterator`metodais gauti elementai gali skirtis nuo tų, kuriuos pateikia [" Iterator`] metodai:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` elementais išjudina iteratorių iš užpakalio.
    ///
    /// `advance_back_by` yra atvirkštinė " [`advance_by`] versija.Šis metodas nekantriai praleis `n` elementus, pradedant nuo užpakalio, skambinant [`next_back`] iki `n` kartų, kol bus pastebėtas [`None`].
    ///
    /// `advance_back_by(n)` grąžins [`Ok(())`], jei iteratorius sėkmingai žengs priekyje `n` elementais, arba [`Err(k)`], jei susidursite su [`None`], kur `k` yra elementų skaičius, kurį iteratorius yra išplėtojęs prieš baigiantis elementams (t. y.
    /// iteratoriaus ilgis).
    /// Atminkite, kad `k` visada yra mažesnis nei `n`.
    ///
    /// Paskambinus į `advance_back_by(0)`, elementai nevartojami ir visada grąžinama [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // tik `&3` buvo praleistas
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Pateikia `n`-ąjį elementą nuo iteratoriaus pabaigos.
    ///
    /// Iš esmės tai yra atvirkštinė " [`Iterator::nth()`] versija.
    /// Nors, kaip ir daugumoje indeksavimo operacijų, skaičiavimas prasideda nuo nulio, todėl `nth_back(0)` grąžina pirmąją reikšmę nuo pabaigos, `nth_back(1)`-antrą ir t.
    ///
    ///
    /// Atkreipkite dėmesį, kad bus sunaudoti visi elementai tarp pabaigos ir grąžinto elemento, įskaitant grąžintą elementą.
    /// Tai taip pat reiškia, kad kelis kartus iškvietus " `nth_back(0)` tuo pačiu iteratoriumi bus grąžinti skirtingi elementai.
    ///
    /// `nth_back()` grąžins [`None`], jei `n` bus didesnis arba lygus iteratoriaus ilgiui.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Kelis kartus skambinant į " `nth_back()`, iteratorius neatsukamas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Grąžinama `None`, jei elementų yra mažiau nei `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Tai atvirkštinė " [`Iterator::try_fold()`] versija: elementai imami nuo iteratoriaus galo.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Kadangi jis buvo trumpai sujungtas, likusius elementus vis tiek galima pasiekti per iteratorių.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratoriaus metodas, kuris iteratoriaus elementus sumažina iki vienos galutinės vertės, pradedant nuo užpakalinės pusės.
    ///
    /// Tai atvirkštinė " [`Iterator::fold()`] versija: elementai imami nuo iteratoriaus galo.
    ///
    /// `rfold()` paima du argumentus: pradinę vertę ir uždarymą su dviem argumentais: 'accumulator' ir elementu.
    /// Uždarymas grąžina vertę, kurią akumuliatorius turėtų turėti kitam kartojimui.
    ///
    /// Pradinė vertė yra vertė, kurią akumuliatorius turės per pirmąjį skambutį.
    ///
    /// Pritaikius šį uždarymą kiekvienam iteratoriaus elementui, `rfold()` grąžina akumuliatorių.
    ///
    /// Ši operacija kartais vadinama 'reduce' arba 'inject'.
    ///
    /// Sulankstymas yra naudingas, kai turite kažko kolekciją ir norite iš to sukurti vieną vertę.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // visų a elementų suma
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Šis pavyzdys sukuria eilutę, pradedant pradine verte ir tęsiant kiekvieną elementą nuo galo iki priekio:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ieško iteratoriaus elemento iš nugaros, kuris tenkina predikatą.
    ///
    /// `rfind()` užima uždarymą, kuris pateikia `true` arba `false`.
    /// Tai uždaro kiekvieną iteratoriaus elementą, pradedant nuo pabaigos, ir jei kuris nors iš jų grąžina `true`, tada `rfind()` grąžina [`Some(element)`].
    /// Jei visi jie grąžina `false`, jis grąžina [`None`].
    ///
    /// `rfind()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik uždarymas grąžins `true`.
    ///
    /// Kadangi " `rfind()` imasi nuorodos ir daugelis iteratorių kartojasi už nuorodas, tai gali sukelti painią situaciją, kai argumentas yra dviguba nuoroda.
    ///
    /// Šį efektą galite pamatyti toliau pateiktuose pavyzdžiuose su " `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Sustojimas prie pirmojo " `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}