// ignore-tidy-filelength Šis failas beveik išimtinai susideda iš `Iterator` apibrėžimo.
// Negalime to padalyti į kelis failus.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Sąsaja su iteratoriais.
///
/// Tai yra pagrindinis iteratorius trait.
/// Norėdami sužinoti daugiau apie iteratorių sąvoką, žr. [module-level documentation].
/// Visų pirma, galbūt norėsite žinoti, kaip atlikti " [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Kartojamų elementų tipas.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Pereina į iteratorių ir grąžina kitą vertę.
    ///
    /// Grąžina [`None`], kai baigsis iteracija.
    /// Individualūs iteratoriaus diegimai gali nuspręsti atnaujinti atkūrimą, todėl vėl paskambinus į `next()`, gali būti, kad ne, bet kada vėl bus galima grąžinti [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Skambinimas į next() grąžina kitą reikšmę ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ir tada nebėra, kai viskas baigsis.
    /// assert_eq!(None, iter.next());
    ///
    /// // Daugiau skambučių gali grąžinti " `None` arba ne.Čia jie visada tai padarys.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Grąžina likusio iteratoriaus ilgio ribas.
    ///
    /// Tiksliau, `size_hint()` grąžina atkarpą, kur pirmasis elementas yra apatinė riba, o antrasis elementas yra viršutinė riba.
    ///
    /// Antroji grąžinamosios grupės pusė yra [" Variantas`] " <` [" naudoti`] " >`.
    /// [`None`] čia reiškia, kad arba nėra žinomos viršutinės ribos, arba viršutinė riba yra didesnė nei [`usize`].
    ///
    /// # Įgyvendinimo pastabos
    ///
    /// Nereikalaujama, kad iteratoriaus diegimas gautų deklaruotą elementų skaičių.Bugiškas iteratorius gali gauti mažiau nei apatinė arba daugiau nei viršutinė elementų riba.
    ///
    /// `size_hint()` visų pirma skirtas naudoti optimizavimui, pvz., rezervuoti vietos iteratoriaus elementams, tačiau negalima patikėti, pvz., praleisti riboto tikrinimo nesaugiame kode.
    /// Netinkamas " `size_hint()` diegimas neturėtų sukelti atminties saugumo pažeidimų.
    ///
    /// Be to, įgyvendinimas turėtų pateikti teisingą įvertinimą, nes kitaip tai būtų " trait` protokolo pažeidimas.
    ///
    /// Numatytasis įgyvendinimas pateikia " (0," [None`]`)`, kuris tinka bet kuriam iteratoriui.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Sudėtingesnis pavyzdys:
    ///
    /// ```
    /// // Lyginiai skaičiai nuo nulio iki dešimties.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mes galime kartoti nuo nulio iki dešimties kartų.
    /// // Žinojimas, kad tiksliai penki, neįmanoma neįvykdžius " filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Pridėkime dar penkis skaičius su " chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // dabar abi ribos padidintos penkiais
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Grąžinus `None` viršutinei ribai:
    ///
    /// ```
    /// // begalinis iteratorius neturi viršutinės ribos ir maksimaliai įmanomos apatinės ribos
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Suvartoja iteratorių, suskaičiuoja pakartojimų skaičių ir grąžina jį.
    ///
    /// Šis metodas skambins [`next`] pakartotinai, kol bus pastebėtas [`None`], nurodant, kiek kartų jis matė [`Some`].
    /// Atkreipkite dėmesį, kad [`next`] reikia iškviesti bent kartą, net jei iteratoriuje nėra jokių elementų.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Perpildymo elgesys
    ///
    /// Šis metodas neapsaugo nuo perpildymo, todėl skaičiuojant iteratoriaus elementus, turinčius daugiau nei [`usize::MAX`] elementų, gaunamas neteisingas rezultatas arba panics.
    ///
    /// Jei įgalinti derinimo tvirtinimai, garantuojamas panic.
    ///
    /// # Panics
    ///
    /// Ši funkcija gali būti panic, jei iteratoriuje yra daugiau nei [`usize::MAX`] elementų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Vartoja iteratorių, grąžindamas paskutinį elementą.
    ///
    /// Šis metodas įvertins iteratorių, kol jis grąžins [`None`].
    /// Tai darydamas jis seka dabartinį elementą.
    /// Grąžinus " [`None`], " `last()` grąžins paskutinį matytą elementą.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Iškartoja iteratorių `n` elementais.
    ///
    /// Šis metodas noriai praleis `n` elementus, skambindamas [`next`] iki `n` kartų, kol bus pastebėtas [`None`].
    ///
    /// `advance_by(n)` grąžins [`Ok(())`][Ok], jei iteratorius sėkmingai žengs priekyje `n` elementais, arba [`Err(k)`][Err], jei susidursite su [`None`], kur `k` yra elementų skaičius, kurį iteratorius yra išplėtojęs prieš baigiantis elementams (t. y.
    /// iteratoriaus ilgis).
    /// Atminkite, kad `k` visada yra mažesnis nei `n`.
    ///
    /// Skambinant į `advance_by(0)`, elementai nevartojami ir visada grąžinama [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // tik `&4` buvo praleistas
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Grąžina " n` iteratoriaus elementą.
    ///
    /// Kaip ir daugumoje indeksavimo operacijų, skaičiavimas prasideda nuo nulio, todėl `nth(0)` grąžina pirmąją vertę, `nth(1)`-antrą ir t.
    ///
    /// Atkreipkite dėmesį, kad visi ankstesni elementai, taip pat grąžintas elementas, bus naudojami iš iteratoriaus.
    /// Tai reiškia, kad ankstesni elementai bus atmesti, taip pat tai, kad kelis kartus iškvietus `nth(0)` tuo pačiu iteratoriumi bus grąžinti skirtingi elementai.
    ///
    ///
    /// `nth()` grąžins [`None`], jei `n` bus didesnis arba lygus iteratoriaus ilgiui.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Kelis kartus skambinant į " `nth()`, iteratorius neatsukamas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Grąžinama `None`, jei elementų yra mažiau nei `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Sukuria iteratorių, prasidedantį tame pačiame taške, bet kiekvienoje iteracijoje žengiantį pagal nurodytą sumą.
    ///
    /// 1 pastaba: pirmasis iteratoriaus elementas visada bus grąžintas, neatsižvelgiant į atliktą žingsnį.
    ///
    /// 2 pastaba: Laikas, kuriuo traukiami ignoruojami elementai, nėra fiksuotas.
    /// `StepBy` elgiasi kaip seka `next(), nth(step-1), nth(step-1),…`, bet taip pat gali laisvai elgtis kaip seka
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Naudojamas būdas kai kuriems iteratoriams gali pasikeisti dėl našumo priežasčių.
    /// Antrasis būdas pakels iteratorių anksčiau ir gali sunaudoti daugiau daiktų.
    ///
    /// `advance_n_and_return_first` yra lygiavertis:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metodas bus panic, jei nurodytas žingsnis yra `0`.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Paima du iteratorius ir sukuria naują iteratorių per abu iš eilės.
    ///
    /// `chain()` grąžins naują iteratorių, kuris pirmiausia kartos reikšmes iš pirmojo iteratoriaus, o paskui per vertes iš antrojo iteratoriaus.
    ///
    /// Kitaip tariant, jis sujungia du iteratorius grandinėje.🔗
    ///
    /// [`once`] yra paprastai naudojamas pritaikyti vieną vertę į kitų rūšių iteraciją.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi argumentas `chain()` naudoja [`IntoIterator`], galime perduoti viską, ką galima konvertuoti į [`Iterator`], ne tik patį [`Iterator`].
    /// Pvz., (`&[T]`) skiltelės įgyvendina [`IntoIterator`], todėl jas galima tiesiogiai perduoti `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jei dirbate su " Windows API, galite konvertuoti " [`OsStr`] į " `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// " Pakelkite` du iteratorius į vieną porų iteratorių.
    ///
    /// `zip()` grąžina naują iteratorių, kuris kartos du kitus iteratorius, grąžindamas porą, kur pirmasis elementas gaunamas iš pirmojo iteratoriaus, o antrasis-iš antrojo iteratoriaus.
    ///
    ///
    /// Kitaip tariant, jis sujungia du iteratorius į vieną.
    ///
    /// Jei kuris nors iteratorius grąžins [`None`], [`next`] iš pridedamo iteratoriaus grąžins [`None`].
    /// Jei pirmasis iteratorius grąžins [`None`], `zip` bus trumpasis jungimas ir `next` nebus iškviestas į antrąjį iteratorių.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi argumentas `zip()` naudoja [`IntoIterator`], galime perduoti viską, ką galima konvertuoti į [`Iterator`], ne tik patį [`Iterator`].
    /// Pvz., (`&[T]`) skiltelės įgyvendina [`IntoIterator`], todėl jas galima tiesiogiai perduoti `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` dažnai naudojamas norint supakuoti begalinį iteratorių į baigtinį.
    /// Tai veikia, nes baigtinis iteratorius galiausiai grąžins [`None`], baigdamas užtrauktuką." `(0..)` suglaudinimas gali atrodyti panašiai kaip " [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Sukuria naują iteratorių, kuris įdeda `separator` kopiją tarp gretimų pradinio iteratoriaus elementų.
    ///
    /// Jei `separator` neįdiegia [`Clone`] arba jį reikia apskaičiuoti kiekvieną kartą, naudokite [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Pirmasis elementas iš " `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatorius.
    /// assert_eq!(a.next(), Some(&1));   // Kitas elementas iš " `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatorius.
    /// assert_eq!(a.next(), Some(&2));   // Paskutinis elementas iš " `a`.
    /// assert_eq!(a.next(), None);       // Kartotuvas baigtas.
    /// ```
    ///
    /// `intersperse` gali būti labai naudinga prisijungti prie iteratoriaus elementų naudojant bendrą elementą:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Sukuria naują iteratorių, kuris įdeda `separator` sugeneruotą elementą tarp gretimų pradinio iteratoriaus elementų.
    ///
    /// Uždarymas bus vadinamas tiksliai vieną kartą kiekvieną kartą, kai elementas dedamas tarp dviejų gretimų elementų iš pagrindinio iteratoriaus;
    /// uždarymas netaikomas, jei pagrindinis iteratorius duoda mažiau nei du elementus ir po to, kai pateikiamas paskutinis elementas.
    ///
    ///
    /// Jei iteratoriaus elemente įdiegta " [`Clone`], gali būti lengviau naudoti " [`intersperse`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Pirmasis elementas iš " `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatorius.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Kitas elementas iš " `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatorius.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Paskutinis elementas iš `v`.
    /// assert_eq!(it.next(), None);               // Kartotuvas baigtas.
    /// ```
    ///
    /// `intersperse_with` gali būti naudojamas tais atvejais, kai reikia apskaičiuoti separatorių:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Uždarymas abipusiai pasiskolina kontekstą, kad sukurtų elementą.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Uždaro ir sukuria iteratorių, kuris uždaro šį elementą kiekviename elemente.
    ///
    /// `map()` paverčia vieną iteratorių kitu savo argumentu:
    /// kažkas, kas įgyvendina [`FnMut`].Tai sukuria naują iteratorių, kuris uždaro kiekvieną pirminio iteratoriaus elementą.
    ///
    /// Jei gerai mąstote tipais, galite galvoti apie " `map()` taip:
    /// Jei turite iteratorių, kuriame pateikiami kažkokio tipo `A` elementai, ir norite, kad būtų kažkokio kito tipo `B`, galite naudoti `map()`, perduodami uždarymą, kuris užima `A` ir grąžina `B`.
    ///
    ///
    /// `map()` yra konceptualiai panašus į [`for`] kilpą.Tačiau, kadangi " `map()` yra tingus, jį geriausia naudoti, kai jau dirbate su kitais iteratoriais.
    /// Jei šalutiniam poveikiui darote tam tikrą ryšį, laikoma idiotiškiau naudoti " [`for`] nei " `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jei darote tam tikrą šalutinį poveikį, pirmenybę teikite [`for`], o ne `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nedaryk to:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // jis net nevykdys, nes yra tingus.Rust jus apie tai perspės.
    ///
    /// // Vietoj to naudokite:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Ragina uždaryti kiekvieną iteratoriaus elementą.
    ///
    /// Tai tolygu [`for`] kilpos naudojimui iteratoriuje, nors `break` ir `continue` negalima uždarius.
    /// Paprastai idiotiškiau naudoti `for` kilpą, tačiau `for_each` gali būti geriau įskaitomas apdorojant elementus ilgesnių iteratorių grandinių gale.
    ///
    /// Kai kuriais atvejais `for_each` taip pat gali būti greitesnis už kilpą, nes jis naudos vidinę iteriaciją tokiuose adapteriuose kaip `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Tokio mažo pavyzdžio atveju `for` kilpa gali būti švaresnė, tačiau `for_each` gali būti pageidautina išlaikyti funkcinį stilių su ilgesniais iteratoriais:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Sukuria iteratorių, kuris naudoja uždarymą, kad nustatytų, ar reikia pateikti elementą.
    ///
    /// Atsižvelgiant į elementą, uždarymas turi grąžinti `true` arba `false`.Grįžęs iteratorius pateiks tik tuos elementus, kurių uždarymas grįžta teisingai.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi " `filter()` perduotam uždarymui reikalinga nuoroda, o daugelis iteratorių kartojasi dėl nuorodų, tai gali sukelti painią situaciją, kai uždarymo tipas yra dviguba nuoroda:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // reikia dviejų *!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Įprasta vietoje argumento naudoti pertvarkymą, kad pašalintumėte vieną:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // abu ir *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// arba abu:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // du &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// šių sluoksnių.
    ///
    /// Atkreipkite dėmesį, kad `iter.filter(f).next()` yra lygiavertis `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Sukuria iteratorių, kuris filtruoja ir žemėlapius.
    ///
    /// Grąžintas iteratorius pateikia tik tas reikšmes, kurioms pateiktas uždarymas pateikia `Some(value)`.
    ///
    /// `filter_map` galima naudoti norint glaudesnes [`filter`] ir [`map`] grandines.
    /// Žemiau pateiktame pavyzdyje parodyta, kaip `map().filter().map()` galima sutrumpinti iki vieno skambučio į `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Čia yra tas pats pavyzdys, bet naudojant [`filter`] ir [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Sukuria iteratorių, kuris pateikia dabartinį iteracijų skaičių ir kitą vertę.
    ///
    /// Pateikus iteratorių, gaunamos poros `(i, val)`, kur `i` yra dabartinis iteracijos indeksas, o `val`-iteratoriaus grąžinta vertė.
    ///
    ///
    /// `enumerate()` išlaiko savo [`usize`] skaičių.
    /// Jei norite skaičiuoti pagal skirtingo dydžio sveikąjį skaičių, funkcija [`zip`] suteikia panašią funkciją.
    ///
    /// # Perpildymo elgesys
    ///
    /// Šis metodas neapsaugo nuo perpildymo, todėl surašius daugiau nei [`usize::MAX`] elementus gaunamas neteisingas rezultatas arba panics.
    /// Jei įgalinti derinimo tvirtinimai, garantuojamas panic.
    ///
    /// # Panics
    ///
    /// Grąžintas iteratorius gali būti panic, jei grąžintinas indeksas perpildys [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Sukuria iteratorių, kuris naudodamas [`peek`] gali pažvelgti į kitą iteratoriaus elementą jo nenaudodamas.
    ///
    /// Prie iteratoriaus pridedamas metodas [`peek`].Daugiau informacijos ieškokite jos dokumentuose.
    ///
    /// Atkreipkite dėmesį, kad pagrindinis iteratorius vis dar yra pažengęs, kai pirmą kartą iškviečiama [`peek`]: norint gauti kitą elementą, pagrindiniame iteratoriuje iškviečiamas [`next`], taigi ir visi šalutiniai poveikiai (t. Y.
    ///
    /// [`next`] metodo atsiras kas kita, išskyrus sekančios vertės gavimą).
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() leiskite mums pamatyti " future`
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // mes galime peek() kelis kartus, iteratorius nebus į priekį
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // pasibaigus iteratoriui, baigiasi ir peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Sukuria iteratorių, kurio elementai [praleisti `, remiantis predikatu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` kaip argumentą laiko uždarymą.Jis vadins šį uždarymą kiekvienam iteratoriaus elementui ir nepaisys elementų, kol jis grąžins `false`.
    ///
    /// Grąžinus " `false`, " `skip_while()`'s darbas bus baigtas, o kiti elementai bus pateikti.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi " `skip_while()` perduotam uždarymui reikalinga nuoroda ir daugelis iteratorių kartojasi dėl nuorodų, tai gali sukelti painią situaciją, kai uždarymo argumento tipas yra dviguba nuoroda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // reikia dviejų *!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sustojimas po pradinio `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // nors tai būtų buvę klaidinga, nes mes jau turime klaidingą informaciją, skip_while() daugiau nenaudojamas
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Sukuria iteratorių, kuriame gaunami elementai, pagrįsti predikatu.
    ///
    /// `take_while()` kaip argumentą laiko uždarymą.Tai vadins uždarymu kiekvienam iteratoriaus elementui ir duos elementus, kol jis grąžins `true`.
    ///
    /// Grąžinus " `false`, " `take_while()`'s užduotis baigta, o kiti elementai nepaisomi.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi " `take_while()` perduotam uždarymui reikalinga nuoroda, o daugelis iteratorių kartojasi dėl nuorodų, tai gali sukelti painią situaciją, kai uždarymo tipas yra dviguba nuoroda:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // reikia dviejų *!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sustojimas po pradinio `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Turime daugiau elementų, kurie yra mažiau nei nulis, tačiau kadangi mes jau turime klaidingą informaciją, take_while() daugiau nenaudojamas
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kadangi " `take_while()` turi pažvelgti į vertę, kad pamatytumėte, ar ji turėtų būti įtraukta, ar ne, vartojantys iteratoriai pamatys, kad ji pašalinta:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// " `3` nebėra, nes jis buvo sunaudotas norint sužinoti, ar iteracija turėtų sustoti, tačiau nebuvo įdėta atgal į iteratorių.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Sukuria iteratorių, kuris duoda elementus pagal predikatą ir žemėlapius.
    ///
    /// `map_while()` kaip argumentą laiko uždarymą.
    /// Tai vadins uždarymu kiekvienam iteratoriaus elementui ir duos elementus, kol jis grąžins [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Čia yra tas pats pavyzdys, bet naudojant [`take_while`] ir [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sustojimas po pradinio [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Turime daugiau elementų, kurie galėtų tilpti į u32 (4, 5), tačiau `map_while` grąžino `None` `-3` (kaip `predicate` grąžino `None`) ir `collect` sustoja pirmą kartą susidūrus `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Kadangi " `map_while()` turi pažvelgti į vertę, kad pamatytumėte, ar ji turėtų būti įtraukta, ar ne, vartojantys iteratoriai pamatys, kad ji pašalinta:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// " `-3` nebėra, nes jis buvo sunaudotas norint sužinoti, ar iteracija turėtų sustoti, tačiau nebuvo įdėta atgal į iteratorių.
    ///
    /// Atminkite, kad, kitaip nei " [`take_while`], šis iteratorius **nėra** sujungtas.
    /// Taip pat nenurodoma, ką šis iteratorius grąžina grąžinus pirmąjį " [`None`].
    /// Jei jums reikia sulydyto iteratoriaus, naudokite " [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Sukuria iteratorių, kuris praleidžia pirmuosius `n` elementus.
    ///
    /// Juos sunaudojus, gaunami likę elementai.
    /// Užuot nepaisę šio metodo tiesiogiai, nepaisykite `nth` metodo.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Sukuria iteratorių, kuris duoda pirmuosius `n` elementus.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` dažnai naudojamas su begaliniu iteratoriumi, kad jis būtų baigtinis:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Jei yra mažiau nei `n` elementų, `take` apsiribos pagrindinio iteratoriaus dydžiu:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Iteratoriaus adapteris, panašus į [`fold`], kuris palaiko vidinę būseną ir sukuria naują iteratorių.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` pateikia du argumentus: pradinę vertę, įvedančią vidinę būseną, ir uždarymą dviem argumentais, iš kurių pirmasis yra kintama nuoroda į vidinę būseną, o antrasis-iteratoriaus elementas.
    ///
    /// Uždarymas gali priskirti vidinę būseną dalytis būsena tarp iteracijų.
    ///
    /// Kartojant pakartojimą, uždarymas bus taikomas kiekvienam iteratoriaus elementui, o iteratorius duos grąžinimo vertę iš uždarymo [`Option`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // kiekvieną kartojimą būseną padauginsime iš elemento
    ///     *state = *state * x;
    ///
    ///     // tada mes pateiksime valstybės neigimą
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Sukuria iteratorių, kuris veikia kaip žemėlapis, bet išlygina įdėtą struktūrą.
    ///
    /// [`map`] adapteris yra labai naudingas, bet tik tada, kai uždarymo argumentas sukuria reikšmes.
    /// Jei vietoj to sukuriamas iteratorius, yra papildomas nukreipimo sluoksnis.
    /// `flat_map()` pats pašalins šį papildomą sluoksnį.
    ///
    /// Galite įsivaizduoti, kad `flat_map(f)` yra semantinis [" map`] pingo atitikmuo, o tada-" lyginti` kaip ir `map(f).flatten()`.
    ///
    /// Kitas mąstymo būdas apie `flat_map()`: [`map`] uždarymas grąžina po vieną elementą kiekvienam elementui, o `flat_map()`'s uždarymas pateikia kiekvieno elemento iteratorių.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pateikia iteratorių
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Sukuria iteratorių, kuris išlygina įdėtą struktūrą.
    ///
    /// Tai naudinga, kai turite iteratorių iteratorių arba daiktų, kuriuos galima paversti iteratoriais, iteratorių ir norite pašalinti vieną krypties lygį.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Žemėlapis ir tada išlyginimas:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pateikia iteratorių
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Taip pat galite perrašyti tai naudodami " [`flat_map()`], kuris šiuo atveju yra geresnis, nes jis aiškiau perteikia ketinimus:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() pateikia iteratorių
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Išlyginant vienu metu pašalinamas tik vienas lizdo lygis:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Čia matome, kad `flatten()` neatlieka "deep" išlyginimo.
    /// Vietoj to pašalinamas tik vienas lizdo lygis.Tai yra, jei `flatten()` pritaikysite trimatę masyvą, rezultatas bus dvimatis, o ne vienmatis.
    /// Norėdami gauti vieno matmens struktūrą, turite dar kartą prisijungti prie `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Sukuria iteratorių, kuris baigiasi po pirmojo " [`None`].
    ///
    /// Kai iteratorius grąžins [`None`], " future` skambučiai vėl gali suteikti [`Some(T)`] arba ne.
    /// `fuse()` pritaiko iteratorių, užtikrindamas, kad suteikus [`None`], jis visada grįš amžinai.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// // iteratorius, kuris kaitalioja tarp Kai ir Nieko
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // jei jis lygus, Some(i32), dar niekas
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // galime pamatyti, kaip mūsų iteratorius eina pirmyn ir atgal
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // tačiau, kai mes jį sujungsime ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // jis visada grąžins `None` po pirmo karto.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Ką nors daro su kiekvienu iteratoriaus elementu, perduodamas vertę.
    ///
    /// Kai naudojate iteratorius, dažnai sujungsite kelis iš jų.
    /// Dirbdami su tokiu kodu, galbūt norėsite sužinoti, kas vyksta įvairiose dujotiekio dalyse.Norėdami tai padaryti, įterpkite skambutį į `inspect()`.
    ///
    /// Dažniau `inspect()` naudojamas kaip derinimo įrankis, o ne esantis jūsų galutiniame kode, tačiau programoms gali būti naudinga tam tikrais atvejais, kai prieš išmetant klaidas reikia registruoti.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ši iteratoriaus seka yra sudėtinga.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // pridėkime keletą " inspect() skambučių, kad ištirtume, kas vyksta
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Tai atspausdins:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Prisijungimo klaidos prieš jas išmesdami:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Tai atspausdins:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Pasiskolina iteratorių, o ne vartoja.
    ///
    /// Tai naudinga, norint leisti taikyti iteratoriaus adapterius, išlaikant originalaus iteratoriaus nuosavybę.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // jei bandysime naudoti iter dar kartą, tai neveiks.
    /// // Šioje eilutėje pateikiama " klaida: perkeltos vertės naudojimas: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // pabandykime dar kartą
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Vietoj to, mes įtraukiame .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // dabar tai yra gerai:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Pertvarko iteratorių į kolekciją.
    ///
    /// `collect()` gali paimti viską, kas kartojama, ir paversti ją atitinkama kolekcija.
    /// Tai yra vienas iš galingesnių metodų standartinėje bibliotekoje, naudojamas įvairiuose kontekstuose.
    ///
    /// Pats pagrindinis modelis, kuriame naudojamas " `collect()`, yra vienos kolekcijos pavertimas kita.
    /// Imate kolekciją, paskambinate į ją [`iter`], atliekate daugybę transformacijų, o tada pabaigoje-`collect()`.
    ///
    /// `collect()` taip pat gali sukurti tipų, kurie nėra tipiškos kolekcijos, egzempliorius.
    /// Pvz., [`String`] galima sukurti iš [" char`], o [`Result<T, E>`][`Result`] elementų iteratorių galima surinkti į " `Result<Collection<T>, E>`.
    ///
    /// Žr. Toliau pateiktus pavyzdžius.
    ///
    /// Kadangi " `collect()` yra toks bendras, jis gali sukelti problemų dėl tipo išvadų.
    /// Taigi " `collect()` yra vienas iš nedaugelio kartų, kai pamatysite sintaksę, meiliai vadinamą " 'turbofish': `::<>`.
    /// Tai padeda išvadų algoritmui konkrečiai suprasti, į kurią kolekciją bandote rinkti.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Atkreipkite dėmesį, kad mums reikėjo " `: Vec<i32>` kairėje pusėje.Taip yra todėl, kad vietoje to galėtume surinkti į " [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// " 'turbofish' naudojimas, o ne " `doubled` anotavimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Kadangi " `collect()` rūpi tik tai, į ką renkatės, vis tiek galite naudoti dalinę " `_` tipo užuominą su turbofishu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] naudojimas naudojant `collect()`:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Jei turite sąrašą [`Rezultatas<T, E>`][`Rezultatas`] s, galite naudoti " `collect()`, kad patikrintumėte, ar kuris nors iš jų nepavyko:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // pateikia mums pirmąją klaidą
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // pateikia mums atsakymų sąrašą
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Naudoja iteratorių, sukuria iš jo dvi kolekcijas.
    ///
    /// `partition()` perduotas predikatas gali grąžinti `true` arba `false`.
    /// `partition()` pateikia porą, visus elementus, kuriems grąžino `true`, ir visus elementus, kuriems grąžino `false`.
    ///
    ///
    /// Taip pat žiūrėkite [`is_partitioned()`] ir [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Pertvarko šio iteratoriaus elementus *vietoje* pagal pateiktą predikatą taip, kad visi grįžtantys `true` būtų ankstesni už visus, kurie grąžina `false`.
    ///
    /// Pateikia rastų `true` elementų skaičių.
    ///
    /// Santykinė skaidytų elementų tvarka nėra išlaikoma.
    ///
    /// Taip pat žiūrėkite [`is_partitioned()`] ir [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Padalinkite vietoje tarp lygių ir koeficientų
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ar turėtume nerimauti dėl perpildyto skaičiaus?Vienintelis būdas turėti daugiau nei
        // `usize::MAX` kintamos nuorodos yra su ZST, kurios nėra naudingos skaidant ...

        // Šios uždaromos " "factory" funkcijos egzistuoja siekiant išvengti " `Self` bendrumo.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Pakartotinai raskite pirmąjį " `false` ir pakeiskite jį su paskutiniuoju " `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Tikrina, ar šio iteratoriaus elementai yra suskirstyti pagal nurodytą predikatą, kad visi grįžtantys `true` būtų ankstesni už visus, kurie grąžina `false`.
    ///
    ///
    /// Taip pat žiūrėkite [`partition()`] ir [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Arba visi elementai bando `true`, arba pirmasis punktas sustoja ties `false` ir mes patikriname, ar po to nebėra `true` elementų.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Iteratoriaus metodas, taikantis funkciją tol, kol ji sėkmingai grįžta, sukuriant vieną galutinę vertę.
    ///
    /// `try_fold()` paima du argumentus: pradinę vertę ir uždarymą su dviem argumentais: 'accumulator' ir elementu.
    /// Uždarymas arba sėkmingai grįžta su verte, kurią akumuliatorius turėtų turėti kitam kartojimui, arba grąžina gedimą, o klaidos reikšmė nedelsiant perduodama skambinančiajam (short-circuiting).
    ///
    ///
    /// Pradinė vertė yra vertė, kurią akumuliatorius turės per pirmąjį skambutį.Jei uždarymą pavyko atlikti kiekvienam iteratoriaus elementui, `try_fold()` grąžina galutinį akumuliatorių kaip sėkmingą.
    ///
    /// Sulankstymas yra naudingas, kai turite kažko kolekciją ir norite iš to sukurti vieną vertę.
    ///
    /// # Pastaba įgyvendintojams
    ///
    /// Keletas kitų (forward) metodų turi numatytąjį diegimą pagal šį metodą, todėl pabandykite tai aiškiai įgyvendinti, jei jis gali padaryti kažką geriau nei numatytasis `for` kilpos diegimas.
    ///
    /// Visų pirma pabandykite šį iškvietimą `try_fold()` rasti vidinėse dalyse, iš kurių sudarytas šis iteratorius.
    /// Jei reikia kelių skambučių, `?` operatorius gali būti patogus susieti grandinės akumuliatoriaus vertę, tačiau saugokitės bet kokių invariantų, kuriuos reikia palaikyti prieš ankstyvą grįžimą.
    /// Tai yra `&mut self` metodas, todėl paspaudus klaidą čia reikia atnaujinti iteraciją.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // patikrinta visų masyvo elementų suma
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ši suma perpildyta pridedant 100 elementų
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Kadangi jis buvo trumpai sujungtas, likusius elementus vis tiek galima pasiekti per iteratorių.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iteratoriaus metodas, kuris kiekvienam iteratoriaus elementui taiko klaidingą funkciją, sustoja ties pirmąja klaida ir grąžina tą klaidą.
    ///
    ///
    /// Tai taip pat gali būti laikoma klaidinga [`for_each()`] forma arba [`try_fold()`] versija be pilietybės.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Jis buvo trumpai sujungtas, todėl likę elementai vis dar yra iteratoriuje:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Sulenkia kiekvieną elementą į akumuliatorių, taikant operaciją, grąžinant galutinį rezultatą.
    ///
    /// `fold()` paima du argumentus: pradinę vertę ir uždarymą su dviem argumentais: 'accumulator' ir elementu.
    /// Uždarymas grąžina vertę, kurią akumuliatorius turėtų turėti kitam kartojimui.
    ///
    /// Pradinė vertė yra vertė, kurią akumuliatorius turės per pirmąjį skambutį.
    ///
    /// Pritaikius šį uždarymą kiekvienam iteratoriaus elementui, `fold()` grąžina akumuliatorių.
    ///
    /// Ši operacija kartais vadinama 'reduce' arba 'inject'.
    ///
    /// Sulankstymas yra naudingas, kai turite kažko kolekciją ir norite iš to sukurti vieną vertę.
    ///
    /// Note: " `fold()` ir panašūs metodai, kertantys visą iteratorių, gali būti nesibaigiantys begaliniams iteratoriams, net naudojant " traits`, kurio rezultatas nustatomas per ribotą laiką.
    ///
    /// Note: [`reduce()`] gali būti naudojamas kaip pirmasis elementas naudoti kaip pradinę vertę, jei akumuliatoriaus tipas ir elemento tipas yra vienodi.
    ///
    /// # Pastaba įgyvendintojams
    ///
    /// Keletas kitų (forward) metodų turi numatytąjį diegimą pagal šį metodą, todėl pabandykite tai aiškiai įgyvendinti, jei jis gali padaryti kažką geriau nei numatytasis `for` kilpos diegimas.
    ///
    ///
    /// Visų pirma pabandykite šį iškvietimą `fold()` rasti vidinėse dalyse, iš kurių sudarytas šis iteratorius.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // visų masyvo elementų suma
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Peržiūrėkime kiekvieną kartojimo žingsnį čia:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Taigi, mūsų galutinis rezultatas, `6`.
    ///
    /// Žmonėms, kurie daug nenaudojo iteratorių, įprasta naudoti `for` kilpą su dalykų sąrašu rezultatui sukurti.Jas galima paversti " `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // kilpai:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // jie tokie patys
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Sumažina elementus iki vieno, pakartotinai taikant redukcijos operaciją.
    ///
    /// Jei iteratorius tuščias, grąžina [`None`];priešingu atveju pateikia redukcijos rezultatą.
    ///
    /// Iteratoriams, turintiems bent vieną elementą, tai yra tas pats, kas [`fold()`], o pirmasis iteratoriaus elementas yra pradinė reikšmė, sulankstoma į jį visus paskesnius elementus.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Raskite didžiausią vertę:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testuoja, ar kiekvienas iteratoriaus elementas atitinka predikatą.
    ///
    /// `all()` užima uždarymą, kuris pateikia `true` arba `false`.Šis uždarymas taikomas kiekvienam iteratoriaus elementui, ir jei visi jie grąžina `true`, tai daro ir `all()`.
    /// Jei kuris nors iš jų grąžina `false`, jis grąžina `false`.
    ///
    /// `all()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik ras `false`, atsižvelgiant į tai, kad nesvarbu, kas dar nutiks, rezultatas taip pat bus `false`.
    ///
    ///
    /// Tuščias iteratorius pateikia `true`.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Sustojimas prie pirmojo " `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testuoja, ar kuris nors iteratoriaus elementas atitinka predikatą.
    ///
    /// `any()` užima uždarymą, kuris pateikia `true` arba `false`.Tai uždaro kiekvieną iteratoriaus elementą ir jei kuris nors iš jų grąžina `true`, tai daro ir `any()`.
    /// Jei visi jie grąžina `false`, jis grąžina `false`.
    ///
    /// `any()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik ras `true`, atsižvelgiant į tai, kad nesvarbu, kas dar nutiks, rezultatas taip pat bus `true`.
    ///
    ///
    /// Tuščias iteratorius pateikia `false`.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Sustojimas prie pirmojo " `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ieško iteratoriaus elemento, kuris tenkina predikatą.
    ///
    /// `find()` užima uždarymą, kuris pateikia `true` arba `false`.
    /// Tai uždaro kiekvieną iteratoriaus elementą ir jei kuris nors iš jų grąžina `true`, tada `find()` grąžina [`Some(element)`].
    /// Jei visi jie grąžina `false`, jis grąžina [`None`].
    ///
    /// `find()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik uždarymas grąžins `true`.
    ///
    /// Kadangi " `find()` imasi nuorodos ir daugelis iteratorių kartojasi už nuorodas, tai gali sukelti painią situaciją, kai argumentas yra dviguba nuoroda.
    ///
    /// Šį efektą galite pamatyti toliau pateiktuose pavyzdžiuose su " `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Sustojimas prie pirmojo " `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Atkreipkite dėmesį, kad `iter.find(f)` yra lygiavertis `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Taikoma funkcija iteratoriaus elementams ir pateikiamas pirmasis rezultatas, kurio nėra.
    ///
    ///
    /// `iter.find_map(f)` yra lygiavertis `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Taikoma funkcija iteratoriaus elementams ir pateikiamas pirmasis tikrasis rezultatas arba pirmoji klaida.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Ieško elemento iteratoriuje, grąžindamas jo indeksą.
    ///
    /// `position()` užima uždarymą, kuris pateikia `true` arba `false`.
    /// Šis uždarymas taikomas kiekvienam iteratoriaus elementui ir jei vienas iš jų grąžina `true`, tada `position()` grąžina [`Some(index)`].
    /// Jei visi jie grąžina `false`, jis grąžina [`None`].
    ///
    /// `position()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik ras `true`.
    ///
    /// # Perpildymo elgesys
    ///
    /// Šis metodas neapsaugo nuo perpildymo, taigi, jei yra daugiau nei [`usize::MAX`] neatitinkančių elementų, jis arba duoda neteisingą rezultatą, arba panics.
    ///
    /// Jei įgalinti derinimo tvirtinimai, garantuojamas panic.
    ///
    /// # Panics
    ///
    /// Ši funkcija gali būti panic, jei iteratoriuje yra daugiau nei `usize::MAX` neatitinkančių elementų.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Sustojimas prie pirmojo " `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Grąžintas indeksas priklauso nuo iteratoriaus būsenos
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Ieško iteratoriaus elemento iš dešinės, grąžindamas jo indeksą.
    ///
    /// `rposition()` užima uždarymą, kuris pateikia `true` arba `false`.
    /// Šis uždarymas taikomas kiekvienam iteratoriaus elementui, pradedant nuo pabaigos, ir jei vienas iš jų grąžina `true`, tada `rposition()` grąžina [`Some(index)`].
    ///
    /// Jei visi jie grąžina `false`, jis grąžina [`None`].
    ///
    /// `rposition()` yra trumpasis jungimas;kitaip tariant, jis nustos apdoroti, kai tik ras `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Sustojimas prie pirmojo " `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // mes vis dar galime naudoti `iter`, nes yra daugiau elementų.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Čia nereikia tikrinti perpildymo, nes `ExactSizeIterator` reiškia, kad elementų skaičius telpa į `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Grąžina didžiausią iteratoriaus elementą.
    ///
    /// Jei keli elementai yra vienodai maksimalūs, grąžinamas paskutinis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Pateikia minimalų iteratoriaus elementą.
    ///
    /// Jei keli elementai yra vienodai minimalūs, grąžinamas pirmasis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Grąžina elementą, kuris suteikia didžiausią reikšmę iš nurodytos funkcijos.
    ///
    ///
    /// Jei keli elementai yra vienodai maksimalūs, grąžinamas paskutinis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Grąžina elementą, kuris suteikia didžiausią vertę, atsižvelgiant į nurodytą palyginimo funkciją.
    ///
    ///
    /// Jei keli elementai yra vienodai maksimalūs, grąžinamas paskutinis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Grąžina elementą, kuris suteikia mažiausią reikšmę iš nurodytos funkcijos.
    ///
    ///
    /// Jei keli elementai yra vienodai minimalūs, grąžinamas pirmasis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Grąžina elementą, kuris suteikia mažiausią reikšmę nurodytos palyginimo funkcijos atžvilgiu.
    ///
    ///
    /// Jei keli elementai yra vienodai minimalūs, grąžinamas pirmasis elementas.
    /// Jei iteratorius tuščias, grąžinama [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Apvers iteratoriaus kryptį.
    ///
    /// Paprastai iteratoriai kartojasi iš kairės į dešinę.
    /// Panaudojus " `rev()`, iteratorius iteratuos iš dešinės į kairę.
    ///
    /// Tai įmanoma tik tuo atveju, jei iteratorius turi pabaigą, todėl " `rev()` veikia tik su [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konvertuoja porų kartotoją į konteinerių porą.
    ///
    /// `unzip()` sunaudoja visą porų kartotoją, sukurdamas dvi kolekcijas: vieną iš kairiųjų porų elementų ir vieną iš dešiniųjų elementų.
    ///
    ///
    /// Ši funkcija tam tikra prasme yra priešinga [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Sukuria iteratorių, kuris nukopijuoja visus jo elementus.
    ///
    /// Tai naudinga, kai turite iteratorių per " `&T`, bet jums reikia per " `T`.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // nukopijuotas yra tas pats, kas .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Sukuria iteratorių, kuris [klonuoja] visus jo elementus.
    ///
    /// Tai naudinga, kai turite iteratorių per " `&T`, bet jums reikia per " `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonuotas yra tas pats, kas .map(|&x| x), sveikiems skaičiams
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Be galo kartoja kartotoją.
    ///
    /// Vietoj to, kad sustotų ties [`None`], iteratorius bus paleistas iš naujo.Vėl kartojus, jis vėl prasidės iš pradžių.Ir vėl.
    /// Ir vėl.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Apibendrina iteratoriaus elementus.
    ///
    /// Paima kiekvieną elementą, sujungia juos ir grąžina rezultatą.
    ///
    /// Tuščias iteratorius pateikia nulinę tipo vertę.
    ///
    /// # Panics
    ///
    /// Skambinant į `sum()` ir grąžinamas primityvus sveiko skaičiaus tipas, šis metodas bus panic, jei įgalinti skaičiavimo perpildymai ir derinimo tvirtinimai.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Kartojasi per visą iteratorių, padaugindami visus elementus
    ///
    /// Tuščias iteratorius pateikia vieną tipo vertę.
    ///
    /// # Panics
    ///
    /// Skambinant `product()` ir grąžinamas primityvus sveiko skaičiaus tipas, metodas bus panic, jei skaičiavimo perpildymai ir derinimo tvirtinimai yra įjungti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) palygina šio [`Iterator`] elementus su kito elementais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) palygina šio [`Iterator`] elementus su kito elementais, atsižvelgiant į nurodytą palyginimo funkciją.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) palygina šio [`Iterator`] elementus su kito elementais.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) palygina šio [`Iterator`] elementus su kito elementais, atsižvelgiant į nurodytą palyginimo funkciją.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Nustato, ar šio [`Iterator`] elementai yra lygūs kito elementams.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Nustato, ar šios [`Iterator`] elementai yra lygūs kitų elementams, atsižvelgiant į nurodytą lygybės funkciją.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Nustato, ar šio [`Iterator`] elementai yra nelygūs kito elementai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Nustato, ar šio [`Iterator`] elementai yra [lexicographically](Ord#lexicographical-comparison) mažesni už kito elementus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Nustato, ar šio [`Iterator`] elementai yra [lexicographically](Ord#lexicographical-comparison) mažesni, ar lygūs kito elementams.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Nustato, ar šio [`Iterator`] elementai yra [lexicographically](Ord#lexicographical-comparison) didesni už kito elementus.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Nustato, ar šio [`Iterator`] elementai yra [lexicographically](Ord#lexicographical-comparison) didesni ar lygūs kito elementams.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Tikrina, ar šio iteratoriaus elementai yra rūšiuojami.
    ///
    /// Tai reiškia, kad kiekvienam elementui `a` ir jo sekančiam elementui `b` turi būti `a <= b`.Jei iteratorius duoda tiksliai nulį arba vieną elementą, grąžinama `true`.
    ///
    /// Atkreipkite dėmesį, kad jei `Self::Item` yra tik `PartialOrd`, bet ne `Ord`, aukščiau pateiktas apibrėžimas reiškia, kad ši funkcija pateikia `false`, jei bet kurie du vienas po kito einantys elementai nėra palyginami.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Tikrina, ar šio iteratoriaus elementai yra surūšiuoti naudojant nurodytą palyginamąją funkciją.
    ///
    /// Užuot naudojusi `PartialOrd::partial_cmp`, ši funkcija naudoja nurodytą `compare` funkciją, kad nustatytų dviejų elementų eiliškumą.
    /// Be to, jis prilygsta [`is_sorted`];daugiau informacijos rasite jos dokumentuose.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Tikrina, ar šio iteratoriaus elementai yra rūšiuojami naudojant nurodytą rakto ištraukimo funkciją.
    ///
    /// Užuot tiesiogiai lyginusi iteratoriaus elementus, ši funkcija lygina elementų raktus, nustatytus `f`.
    /// Be to, jis prilygsta [`is_sorted`];daugiau informacijos rasite jos dokumentuose.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Žr. " [TrustedRandomAccess]
    // Neįprastas pavadinimas yra vengti vardų susidūrimo skiriant metodą, žr. #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}