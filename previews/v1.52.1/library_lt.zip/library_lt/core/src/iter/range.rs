use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objektai, turintys sąvokas *įpėdinis* ir *pirmtakas*.
///
/// Operacija *įpėdinė* juda link didesnių verčių.
/// Operacija *pirmtakas* juda link verčių, kurios lyginamos mažiau.
///
/// # Safety
///
/// Šis " trait`yra " `unsafe`, nes jo įgyvendinimas turi būti teisingas, kad būtų užtikrinta " `unsafe trait TrustedLen` diegimo sauga, o kitu atveju " `unsafe` kodas gali patikėti šio " trait` naudojimo rezultatais, kad būtų teisingi ir įvykdyti išvardytus įsipareigojimus.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Grąžina *įpėdinių* žingsnių, reikalingų norint pereiti nuo `start` iki `end`, skaičių.
    ///
    /// Pateikia `None`, jei žingsnių skaičius perpildys `usize` (arba yra begalinis, arba jei `end` niekada nebus pasiektas).
    ///
    ///
    /// # Invariants
    ///
    /// Bet kokiems " `a`, " `b` ir " `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` tik tada, jei `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` tik tada, jei `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` tik jei `a <= b`
    ///   * Išvada: `steps_between(&a, &b) == Some(0)` tik tada, jei `a == b`
    ///   * Atkreipkite dėmesį, kad `a <= b` reiškia _not_ reiškia `steps_between(&a, &b) != None`;
    ///     tai yra tas atvejis, kai norint pasiekti `b` reikės daugiau nei `usize::MAX` žingsnių
    /// * `steps_between(&a, &b) == None` jei `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Grąžina vertę, kuri būtų gauta imant `self` `count` kartų *įpėdinį*.
    ///
    /// Jei tai perpildys `Self` palaikomų verčių diapazoną, grąžinama `None`.
    ///
    /// # Invariants
    ///
    /// Bet kokiems " `a`, " `n` ir " `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Visiems `a`, `n` ir `m`, kai `n + m` neperpildo:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Bet kokiems " `a` ir " `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Grąžina vertę, kuri būtų gauta imant `self` `count` kartų *įpėdinį*.
    ///
    /// Jei tai perpildytų `Self` palaikomų verčių diapazoną, ši funkcija leidžiama panic, apvynioti ar prisotinti.
    ///
    /// Siūloma elgsena panic, kai įgalinti derinimo teiginiai, ir kitaip apvynioti ar įsotinti.
    ///
    /// Nesaugus kodas neturėtų pasikliauti elgesio teisingumu po perpildymo.
    ///
    /// # Invariants
    ///
    /// Visiems `a`, `n` ir `m`, kai neperteka:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Visiems " `a` ir " `n`, kai neperteka:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Grąžina vertę, kuri būtų gauta imant `self` `count` kartų *įpėdinį*.
    ///
    /// # Safety
    ///
    /// Neapibrėžtas šios operacijos elgesys perpildo `Self` palaikomų verčių diapazoną.
    /// Jei negalite garantuoti, kad tai nebus perpildyta, vietoj to naudokite `forward` arba `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Bet kuriam " `a`:
    ///
    /// * jei yra `b`, toks kaip `b > a`, saugu skambinti į `Step::forward_unchecked(a, 1)`
    /// * jei yra `b`, `n`, toks kaip `steps_between(&a, &b) == Some(n)`, saugu skambinti `Step::forward_unchecked(a, m)` bet kuriam `m <= n`.
    ///
    ///
    /// Visiems " `a` ir " `n`, kai neperteka:
    ///
    /// * `Step::forward_unchecked(a, n)` yra lygiavertis `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Grąžina vertę, kuri būtų gauta imant *pirmtaką*`self` `count` kartus.
    ///
    /// Jei tai perpildys `Self` palaikomų verčių diapazoną, grąžinama `None`.
    ///
    /// # Invariants
    ///
    /// Bet kokiems " `a`, " `n` ir " `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Bet kokiems " `a` ir " `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Grąžina vertę, kuri būtų gauta imant *pirmtaką*`self` `count` kartus.
    ///
    /// Jei tai perpildytų `Self` palaikomų verčių diapazoną, ši funkcija leidžiama panic, apvynioti ar prisotinti.
    ///
    /// Siūloma elgsena panic, kai įgalinti derinimo teiginiai, ir kitaip apvynioti ar įsotinti.
    ///
    /// Nesaugus kodas neturėtų pasikliauti elgesio teisingumu po perpildymo.
    ///
    /// # Invariants
    ///
    /// Visiems `a`, `n` ir `m`, kai neperteka:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Visiems " `a` ir " `n`, kai neperteka:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Grąžina vertę, kuri būtų gauta imant *pirmtaką*`self` `count` kartus.
    ///
    /// # Safety
    ///
    /// Neapibrėžtas šios operacijos elgesys perpildo `Self` palaikomų verčių diapazoną.
    /// Jei negalite garantuoti, kad tai nebus perpildyta, vietoj to naudokite `backward` arba `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Bet kuriam " `a`:
    ///
    /// * jei yra `b`, toks kaip `b < a`, saugu skambinti į `Step::backward_unchecked(a, 1)`
    /// * jei yra `b`, `n`, toks kaip `steps_between(&b, &a) == Some(n)`, saugu skambinti `Step::backward_unchecked(a, m)` bet kuriam `m <= n`.
    ///
    ///
    /// Visiems " `a` ir " `n`, kai neperteka:
    ///
    /// * `Step::backward_unchecked(a, n)` yra lygiavertis `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Tai vis tiek sukuriama makrokomandomis, nes sveikojo skaičiaus pažodžiai skiriasi nuo skirtingų tipų.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SAUGUMAS: skambinantysis turi garantuoti, kad " `start + n` neperpildys.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SAUGUMAS: skambinantysis turi garantuoti, kad " `start - n` neperpildys.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Derinimo versijose suaktyvinkite panic perpildymą.
            // Tai turėtų būti visiškai optimizuota leidimo versijose.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Atlikite vyniojimo matematiką, kad pvz `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Derinimo versijose suaktyvinkite panic perpildymą.
            // Tai turėtų būti visiškai optimizuota leidimo versijose.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Atlikite vyniojimo matematiką, kad pvz `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tai priklauso nuo $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // jei n yra už diapazono ribų, taip pat yra ir `unsigned_start + n`
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // jei n yra už diapazono ribų, taip pat yra ir `unsigned_start - n`
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Tai priklauso nuo $i_narrower <=usize
                        //
                        // Liejimas norint padidinti dydį, išplečia plotį, tačiau išsaugo ženklą.
                        // Jei norite apskaičiuoti skirtumą, kuris gali netelpa į " isize`diapazoną, naudokite " wrapping_sub` " izize` erdvėje ir perduokite.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Apvyniojimas tvarko tokias bylas kaip " `Step::forward(-120_i8, 200) == Some(80_i8)`, nors " 200` neatitinka " i8 diapazono.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Priedas perpildytas
                            }
                        }
                        // Jei n yra už diapazono, pvz
                        // u8, tada jis yra didesnis nei visas " i8 diapazonas yra platus, todėl " `any_i8 + n` būtinai perpildo " i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Apvyniojimas tvarko tokias bylas kaip " `Step::forward(-120_i8, 200) == Some(80_i8)`, nors " 200` neatitinka " i8 diapazono.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Atimtis perpildyta
                            }
                        }
                        // Jei n yra už diapazono, pvz
                        // u8, tada jis yra didesnis nei visas " i8 diapazonas yra platus, todėl " `any_i8 - n` būtinai perpildo " i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Jei skirtumas yra per didelis, pvz
                            // i128, jis taip pat bus per didelis, kad būtų galima naudoti su mažiau bitų.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAUGA: res yra galiojantis unicode skalaras
            // (žemiau 0x110000, o ne 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAUGA: res yra galiojantis unicode skalaras
        // (žemiau 0x110000, o ne 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAUGUMAS: skambinantysis turi garantuoti, kad tai neperpildys
        // char reikšmių diapazonas.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SAUGUMAS: skambinantysis turi garantuoti, kad tai neperpildys
            // char reikšmių diapazonas.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SAUGA: dėl ankstesnės sutarties tai garantuojama
        // skambinančiojo, kad tai būtų galiojantis simbolis.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAUGUMAS: skambinantysis turi garantuoti, kad tai neperpildys
        // char reikšmių diapazonas.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SAUGUMAS: skambinantysis turi garantuoti, kad tai neperpildys
            // char reikšmių diapazonas.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SAUGA: dėl ankstesnės sutarties tai garantuojama
        // skambinančiojo, kad tai būtų galiojantis simbolis.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAUGA: tik patikrinta išankstinė sąlyga
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SAUGA: tik patikrinta išankstinė sąlyga
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Šios makrokomandos generuoja įvairių tipų `ExactSizeIterator` implus.
//
// * `ExactSizeIterator::len` reikalaujama visada pateikti tikslią `usize`, todėl nė vienas diapazonas negali būti ilgesnis nei `usize::MAX`.
//
// * `Range<_>` sveikųjų skaičių tipams tai yra siauresnių nei `usize` pločių tipai.
//   `RangeInclusive<_>` sveikųjų skaičių tipams tai yra tipai *griežtai siauresni* nei `usize`, nes pvz
//   `(0..=u64::MAX).len()` būtų `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Jie įtraukiami pagal aukščiau pateiktus argumentus, tačiau jų pašalinimas būtų nepalankus pokytis, nes jie stabilizavosi programoje Rust 1.0.0.
    // Taigi, pvz
    // `(0..66_000_u32).len()` pavyzdžiui, sukurs be klaidų ar įspėjimų 16 bitų platformose, bet ir toliau duos neteisingą rezultatą.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Jie įtraukiami pagal aukščiau pateiktus argumentus, tačiau jų pašalinimas būtų nepalankus pokytis, nes jie stabilizavosi programoje Rust 1.26.0.
    // Taigi, pvz
    // `(0..=u16::MAX).len()` pavyzdžiui, sukurs be klaidų ar įspėjimų 16 bitų platformose, bet ir toliau duos neteisingą rezultatą.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SAUGA: tik patikrinta išankstinė sąlyga
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SAUGA: tik patikrinta išankstinė sąlyga
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAUGA: tik patikrinta išankstinė sąlyga
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAUGA: tik patikrinta išankstinė sąlyga
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SAUGA: tik patikrinta išankstinė sąlyga
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SAUGA: tik patikrinta išankstinė sąlyga
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}