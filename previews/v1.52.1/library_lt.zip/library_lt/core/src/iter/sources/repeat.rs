use crate::iter::{FusedIterator, TrustedLen};

/// Sukuria naują iteratorių, kuris be galo kartoja vieną elementą.
///
/// `repeat()` funkcija pakartoja vieną vertę dar kartą.
///
/// Begaliniai iteratoriai, tokie kaip `repeat()`, dažnai naudojami su tokiais adapteriais kaip [`Iterator::take()`], kad jie būtų baigtiniai.
///
/// Jei reikalingo iteratoriaus elemento tipas neįdiegia " `Clone` arba nenorite pasikartojančio elemento laikyti atmintyje, galite naudoti funkciją " [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::iter;
///
/// // skaičius keturi 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, vis dar keturi
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// " [`Iterator::take()`] yra baigtinis:
///
/// ```
/// use std::iter;
///
/// // tas paskutinis pavyzdys buvo per daug ketverių.Turėkime tik keturis keturis.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ir dabar mes baigėme
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iteratorius, kuris be galo kartoja elementą.
///
/// Šį " `struct` sukuria " [`repeat()`] funkcija.Daugiau informacijos rasite jos dokumentacijoje.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}