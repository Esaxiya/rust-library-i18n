use crate::iter::{FusedIterator, TrustedLen};

/// Sukuria naują iteratorių, kuris be galo kartoja `A` tipo elementus, pritaikydamas pateiktą uždorį, kartotuvą, `F: FnMut() -> A`.
///
/// " `repeat_with()` funkcija pakartotinai iškviečia kartotuvą.
///
/// Begaliniai iteratoriai, tokie kaip `repeat_with()`, dažnai naudojami su tokiais adapteriais kaip [`Iterator::take()`], kad jie būtų baigtiniai.
///
/// Jei jums reikalingo iteratoriaus elemento tipas įgyvendina [`Clone`] ir gerai, jei šaltinio elementą norite laikyti atmintyje, turėtumėte naudoti funkciją [`repeat()`].
///
///
/// " `repeat_with()` sukurtas iteratorius nėra " [`DoubleEndedIterator`].
/// Jei jums reikia " `repeat_with()`, kad grąžintumėte " [`DoubleEndedIterator`], atidarykite " GitHub` problemą, paaiškindami savo naudojimo atvejį.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::iter;
///
/// // Tarkime, kad turime tam tikrą tipo vertę, kuri nėra " `Clone` arba kuri dar nenori turėti atmintyje, nes ji yra brangi:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // tam tikra vertybė amžinai:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Naudojant mutaciją ir einant ribotai:
///
/// ```rust
/// use std::iter;
///
/// // Nuo nulio iki trečios dviejų jėgos:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ir dabar mes baigėme
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iteratorius, kuris be galo kartoja `A` tipo elementus, pritaikydamas pateiktą uždarymo elementą `F: FnMut() -> A`.
///
///
/// Šį " `struct` sukuria " [`repeat_with()`] funkcija.
/// Daugiau informacijos rasite jos dokumentacijoje.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}