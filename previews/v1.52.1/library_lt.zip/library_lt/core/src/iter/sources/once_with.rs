use crate::iter::{FusedIterator, TrustedLen};

/// Sukuria iteratorių, kuris tingiai generuoja vertę tiksliai vieną kartą, pasinaudodamas pateiktu uždarymu.
///
/// Tai paprastai naudojama norint pritaikyti vienos vertės generatorių [`chain()`] kitos rūšies iteracijai.
/// Gal turite iteratorių, kuris apima beveik viską, bet jums reikia papildomo specialaus atvejo.
/// Gal turite funkciją, kuri veikia iteratoriuose, bet jums reikia apdoroti tik vieną vertę.
///
/// Skirtingai nei " [`once()`], ši funkcija tingiai sugeneruos vertę paprašius.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::iter;
///
/// // vienas yra vienišiausias skaičius
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // tik vienas, tiek ir gauname
/// assert_eq!(None, one.next());
/// ```
///
/// Grandinės kartu su kitu iteratoriumi.
/// Tarkime, kad mes norime kartoti kiekvieną `.foo` katalogo failą, bet ir konfigūracijos failą,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // turime konvertuoti iš " DirEntry-s`iteratoriaus į " PathBufs` iteratorių, todėl naudojame žemėlapį
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // Dabar mūsų iteratorius skirtas tik konfigūracijos failui
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // sujungkite du iteratorius į vieną didelį iteratorių
/// let files = dirs.chain(config);
///
/// // tai suteiks mums visus failus, esančius .foo, taip pat .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Kartotuvas, gaunantis vieną `A` tipo elementą pritaikant pateiktą uždarymo elementą `F: FnOnce() -> A`.
///
///
/// Šį " `struct` sukuria " [`once_with()`] funkcija.
/// Daugiau informacijos rasite jos dokumentacijoje.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}