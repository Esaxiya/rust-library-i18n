use crate::fmt;

/// Sukuria naują iteratorių, kuriame kiekviena iteracija vadina pateiktą uždarymą `F: FnMut() -> Option<T>`.
///
/// Tai leidžia sukurti pasirinktinį iteratorių bet kokiu elgesiu, nenaudojant išsamesnės sintaksės, sukuriant specialų tipą ir įgyvendinant jam " [`Iterator`] trait`.
///
/// Atkreipkite dėmesį, kad " `FromFn` iteratorius nedaro prielaidų apie uždarymo veikimą, todėl konservatyviai neįdiegia " [`FusedIterator`] ir nepaiso " [`Iterator::size_hint()`] pagal numatytąjį " `(0, None)`.
///
///
/// Uždarymas gali naudoti fiksavimus ir jo aplinką, kad būtų galima stebėti būseną kartojant.Priklausomai nuo to, kaip naudojamas iteratorius, uždaryme gali tekti nurodyti raktinį žodį [`move`].
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Iš naujo įdiegkime skaitiklio iteratorių iš " [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Padidinkite mūsų skaičių.Štai kodėl mes pradėjome nuo nulio.
///     count += 1;
///
///     // Patikrinkite, ar baigėme skaičiuoti, ar ne.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Kartotuvas, kuriame kiekviena iteracija vadina pateiktą uždarymą `F: FnMut() -> Option<T>`.
///
/// Šį " `struct` sukuria " [`iter::from_fn()`] funkcija.
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}