//! Suderinama išorinė iteracija.
//!
//! Jei radote kažkokią kolekciją ir jums reikėjo atlikti operaciją su minėtos kolekcijos elementais, greitai pateksite į " 'iterators'.
//! Iteratoriai yra labai naudojami idiomatiniame Rust kode, todėl verta su jais susipažinti.
//!
//! Prieš paaiškindami daugiau, pakalbėkime apie šio modulio struktūrą:
//!
//! # Organization
//!
//! Šis modulis daugiausia suskirstytas pagal tipą:
//!
//! * [Traits] yra pagrindinė dalis: šie " traits`apibrėžia, kokie iteratoriai egzistuoja ir ką galite su jais padaryti.Šių " traits` metodų verta skirti papildomo laiko studijoms.
//! * [Functions] pateikite keletą naudingų būdų sukurti keletą pagrindinių iteratorių.
//! * [Structs] dažnai yra šio modulio traits įvairių metodų grąžinimo tipai.Paprastai norėtumėte atkreipti dėmesį į metodą, kuris sukuria " `struct`, o ne į patį " `struct`.
//! Norėdami sužinoti daugiau, kodėl, žr. " [Iteratoriaus diegimas](#įgyvendinimo iteratorius)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Viskas!Įsigilinkime į iteratorius.
//!
//! # Iterator
//!
//! Šio modulio širdis ir siela yra " [`Iterator`] trait`." [`Iterator`] šerdis atrodo taip:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Kartotojas turi metodą [`next`], kuris iškviečiamas grąžina [" Option`]<Item>".
//! [`next`] grąžins [`Some(Item)`] tol, kol yra elementų, ir kai visi bus išnaudoti, grąžins `None`, nurodydamas, kad iteracija baigta.
//! Atskiri kartotojai gali nuspręsti atnaujinti atkūrimą, todėl vėl paskambinus į [`next`], tam tikru momentu vėl gali būti grąžinama [`Some(Item)`] (pavyzdžiui, žr. [`TryIter`]).
//!
//!
//! Visas " [Iterator`]` apibrėžimas taip pat apima daugybę kitų metodų, tačiau jie yra numatytieji metodai, sukurti naudojant " [`next`], todėl juos galite gauti nemokamai.
//!
//! Iteratoriai taip pat yra sudedami, ir įprasta juos susieti grandinėmis, kad būtų atliekamos sudėtingesnės apdorojimo formos.Norėdami sužinoti daugiau, žiūrėkite toliau pateiktą skyrių [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Trys kartojimo formos
//!
//! Yra trys įprasti metodai, kurie gali sukurti iteratorius iš kolekcijos:
//!
//! * `iter()`, kuris kartojamas per `&T`.
//! * `iter_mut()`, kuris kartojamas per `&mut T`.
//! * `into_iter()`, kuris kartojamas per `T`.
//!
//! Įvairiais standartinės bibliotekos dalykais prireikus galima įgyvendinti vieną ar daugiau iš trijų.
//!
//! # " Iterator` įgyvendinimas
//!
//! Norėdami sukurti savo iteratorių, reikia atlikti du veiksmus: sukurti `struct`, kad būtų palaikoma iteratoriaus būsena, ir tada įgyvendinti [`Iterator`] šiam `struct`.
//! Štai kodėl šiame modulyje yra tiek daug struktūros: kiekvienam iteratoriui ir iteratoriaus adapteriui yra po vieną.
//!
//! Padarykime iteratorių pavadinimu `Counter`, kuris skaičiuojamas nuo `1` iki `5`:
//!
//! ```
//! // Pirma, struktūra:
//!
//! /// Kartotojas, skaičiuojantis nuo vieno iki penkių
//! struct Counter {
//!     count: usize,
//! }
//!
//! // norime, kad mūsų skaičiavimas prasidėtų vienu, todėl pridėkime new() metodą, kuris padės.
//! // Tai nėra griežtai būtina, tačiau yra patogu.
//! // Atkreipkite dėmesį, kad " `count` pradedame nuo nulio, todėl `next()`'s diegime pamatysime toliau.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Tada mes įdiegiame " `Iterator` savo " `Counter`:
//!
//! impl Iterator for Counter {
//!     // mes skaičiuosime su usize
//!     type Item = usize;
//!
//!     // next() yra vienintelis reikalingas metodas
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Padidinkite mūsų skaičių.Štai kodėl mes pradėjome nuo nulio.
//!         self.count += 1;
//!
//!         // Patikrinkite, ar baigėme skaičiuoti, ar ne.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ir dabar mes galime tai naudoti!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Tokiu būdu paskambinus " [`next`], pasikartoja.Rust turi konstrukciją, kuri gali pakviesti [`next`] jūsų iteratoriuje, kol pasieks `None`.Peržvelkime tai toliau.
//!
//! Taip pat atkreipkite dėmesį, kad `Iterator` suteikia numatytąjį metodų, tokių kaip `nth` ir `fold`, įgyvendinimą, kurie iškviečia `next` viduje.
//! Tačiau taip pat galima parašyti pasirinktinį tokių metodų kaip `nth` ir `fold` įgyvendinimą, jei iteratorius gali juos efektyviau apskaičiuoti neskambindamas į `next`.
//!
//! # `for` kilpos ir `IntoIterator`
//!
//! " Rust `for` kilpos sintaksė iš tikrųjų yra iteratorių cukrus.Štai pagrindinis " `for` pavyzdys:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Tai atspausdins skaičius nuo vieno iki penkių, kiekvienas savo eilutėje.Bet čia ką nors pastebėsite: mes niekada nieko neskambinome savo vector, kad būtų sukurtas iteratorius.Kas duoda?
//!
//! Standartinėje bibliotekoje yra " trait`, norint ką nors paversti iteratoriumi: [`IntoIterator`].
//! Šis " trait`turi vieną metodą " [`into_iter`], kuris paverčia [`IntoIterator`] įgyvendinantį dalyką iteratoriumi.
//! Dar kartą pažvelkime į tą `for` kilpą ir į tai, kuo kompiliatorius ją paverčia:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust tai cukruoja į:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Pirma, mes paskambiname `into_iter()` į vertę.Tada mes suderiname grįžtantį iteratorių, skambindami [`next`] vėl ir vėl, kol pamatysime `None`.
//! Tuo metu mes `break` išeiname iš ciklo ir baigiame kartojimą.
//!
//! Čia yra dar vienas subtilus dalykas: standartinėje bibliotekoje yra įdomus " [`IntoIterator`] diegimas:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Kitaip tariant, visi [" Iterator`] įgyvendina " [`IntoIterator`], tiesiog grįždami patys.Tai reiškia du dalykus:
//!
//! 1. Jei rašote " [`Iterator`], galite jį naudoti su " `for` kilpa.
//! 2. Jei kuriate kolekciją, įdiegę jai " [`IntoIterator`], kolekciją galėsite naudoti su " `for` kilpa.
//!
//! # Kartojimas pagal nuorodą
//!
//! Kadangi [`into_iter()`] pagal `self` atima vertę, naudojant `for` kilpą kartojant kolekciją, ši kolekcija sunaudojama.Dažnai galite norėti kartoti kolekciją jos nevartodami.
//! Daugelis kolekcijų siūlo metodus, kurie pateikia iteratorius per nuorodas, paprastai atitinkamai vadinamus `iter()` ir `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` vis dar priklauso šiai funkcijai.
//! ```
//!
//! Jei kolekcijos tipas `C` teikia `iter()`, jis paprastai taip pat įgyvendina `IntoIterator`, skirtą `&C`, su įdiegimu, kuris tiesiog paskambina į `iter()`.
//! Be to, kolekcija `C`, teikianti `iter_mut()`, paprastai įgyvendina `IntoIterator`, skirtą `&mut C`, perduodama `iter_mut()`.Tai leidžia patogiai rašyti:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // tas pats kaip " `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // tas pats kaip " `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Nors daugelis kolekcijų siūlo " `iter()`, ne visos siūlo " `iter_mut()`.
//! Pavyzdžiui, mutavus " [`HashSet<T>`] arba " [`HashMap<K, V>`] klavišus, kolekcija gali tapti nenuosekli, jei pasikeis raktų maiša, todėl šios kolekcijos siūlo tik " `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcijos, kurios ima [`Iterator`] ir grąžina kitą [`Iterator`], dažnai vadinamos " iteratoriaus adapteriais`, nes tai yra " adapterio` forma
//! pattern'.
//!
//! Į įprastus iteratoriaus adapterius įeina [`map`], [`take`] ir [`filter`].
//! Norėdami sužinoti daugiau, žiūrėkite jų dokumentus.
//!
//! Jei iteratoriaus adapteris panics, iteratorius bus nenurodytos (bet atminties saugios) būsenos.
//! Taip pat negarantuojama, kad ši būsena išliks ta pati visose " Rust` versijose, todėl turėtumėte vengti pasikliauti tiksliomis iteratoriaus, kurį sukėlė panika, vertėmis.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratoriai (ir iteratorius [adapters](#adapters)) yra *tingus*. Tai reiškia, kad vien tik sukūrus iteratorių, " _do_ nėra daug. Nieko iš tikrųjų nevyksta, kol nepaskambinsite į " [`next`].
//! Tai kartais kelia painiavą kuriant iteratorių tik dėl jo šalutinių poveikių.
//! Pavyzdžiui, metodas [`map`] reikalauja uždaryti kiekvieną elementą, kurį jis kartoja:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Tai nespausdins jokių verčių, nes mes sukūrėme tik iteratorių, o ne jį naudojome.Kompiliatorius mus įspės apie tokį elgesį:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomas būdas parašyti [`map`] šalutiniams poveikiams yra naudoti `for` kilpą arba paskambinti metodu [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Kitas įprastas iteratoriaus įvertinimo būdas yra [`collect`] metodo naudojimas kuriant naują kolekciją.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratoriai neturi būti baigtiniai.Pavyzdžiui, atviras diapazonas yra begalinis kartotojas:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Įprastą Xerax iteratoriaus adapterį naudojant begalinį iteratorių paverčiama baigtiniu:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Tai atspausdins skaičius nuo `0` iki `4`, kiekvieną savo eilutėje.
//!
//! Turėkite omenyje, kad begalinių iteratorių metodai, net ir tie, kurių rezultatą galima nustatyti matematiškai per ribotą laiką, gali būti nesibaigiantys.
//! Konkrečiai, tokie metodai kaip [`min`], kuriems paprastai reikia pereiti kiekvieną iteratoriaus elementą, greičiausiai negrįš į jokius begalinius iteratorius.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // O ne!Begalinė kilpa!
//! // `ones.min()` sukelia begalinę kilpą, todėl mes nepasieksime šio taško!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;