//! Apibūdina `IntoIter` priklausantį masyvų iteratorių.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// [array] kartotinė vertė.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Tai masyvas, kurį kartojame.
    ///
    /// Elementai su indeksu `i`, kur `alive.start <= i < alive.end`, dar nebuvo pateikti ir yra galiojantys masyvo įrašai.
    /// Elementai, kurių indeksai yra `i < alive.start` arba `i >= alive.end`, jau buvo pateikti ir prie jų nebegalima prisijungti!Tie negyvi elementai gali būti net visiškai neinicijuoti!
    ///
    ///
    /// Taigi invariantai yra:
    /// - `data[alive]` yra gyvas (ty yra galiojančių elementų)
    /// - `data[..alive.start]` ir `data[alive.end..]` yra mirę (ty elementai jau buvo perskaityti ir jų nebegali liesti!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` elementai, kurie dar nebuvo pateikti.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Sukuria naują iteratorių per nurodytą `array`.
    ///
    /// *Pastaba*: šis metodas gali būti nebenaudojamas future, po [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` tipas yra `i32`, o ne `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SAUGA: Transmutas čia yra saugus." `MaybeUninit` dokumentai
        // promise:
        //
        // > `MaybeUninit<T>` garantuojamas tokio paties dydžio ir išlygiavimas
        // > kaip `T`.
        //
        // Dokumentai netgi rodo transmutatą iš `MaybeUninit<T>` masyvo į `T` masyvą.
        //
        //
        // Tuo šis inicijavimas patenkina invariantus.

        // FIXME(LukasKalbertodt): iš tikrųjų čia naudokite " `mem::transmute`, kai jis veikia su " gener generics`:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Iki tol galime naudoti `mem::transmute_copy`, kad sukurtume bitų kopiją kaip kitokio tipo, tada pamirškite `array`, kad ji nebūtų numesta.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Grąžina nekintamą visų dar negavusių elementų skiltį.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SAUGA: Mes žinome, kad visi `alive` elementai yra tinkamai inicijuoti.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Pateikia kintamą visų dar nepateiktų elementų dalį.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SAUGA: Mes žinome, kad visi `alive` elementai yra tinkamai inicijuoti.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Gaukite kitą indeksą iš priekio.
        //
        // Padidinus " `alive.start` 1, `alive` nekinta.
        // Tačiau dėl šio pasikeitimo trumpam gyvoji zona yra nebe `data[alive]`, o `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Perskaitykite elementą iš masyvo.
            // SAUGA: `idx` yra buvusio "alive" regiono indeksas
            // masyvas.Perskaičius šį elementą, `data[idx]` dabar laikomas mirusiu (ty nelieskite).
            // Kadangi `idx` buvo gyvosios zonos pradžia, gyvoji zona vėl yra `data[alive]`, atstatanti visus invariantus.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Gaukite kitą indeksą iš galo.
        //
        // Sumažinus `alive.end` vienetu, išlaikomas `alive` nekintamasis variantas.
        // Tačiau dėl šio pasikeitimo trumpam gyvoji zona yra nebe `data[alive]`, o `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Perskaitykite elementą iš masyvo.
            // SAUGA: `idx` yra buvusio "alive" regiono indeksas
            // masyvas.Perskaičius šį elementą, `data[idx]` dabar laikomas mirusiu (ty nelieskite).
            // Kadangi `idx` buvo gyvosios zonos pabaiga, gyvoji zona dabar vėl yra `data[alive]`, atstatanti visus invariantus.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SAUGUMAS: Tai saugu: `as_mut_slice` pateikia tiksliai pogrupį
        // elementų, kurie dar nebuvo perkelti ir kuriuos dar reikia mesti.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Niekada nebus nutekėjęs dėl invarianto `gyvas.pradėti <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Kartotojas iš tikrųjų praneša apie teisingą ilgį.
// "alive" elementų (kurie vis tiek bus gauti) skaičius yra diapazono `alive` ilgis.
// Šio diapazono ilgis mažinamas `next` arba `next_back`.
// Taikant tuos metodus, jis visada mažinamas 1, bet tik tuo atveju, jei grąžinama `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Atkreipkite dėmesį, kad mums tikrai nereikia sutapti su tuo pačiu gyvuoju diapazonu, todėl galime tiesiog klonuoti į 0 poslinkį, nepriklausomai nuo to, kur yra `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonuokite visus gyvus elementus.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Įrašykite kloną į naują masyvą, tada atnaujinkite jo gyvąjį diapazoną.
            // Jei klonuosite panics, mes teisingai atsisakysime ankstesnių elementų.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Spausdinkite tik tuos elementus, kurie dar nebuvo gauti: mes nebegalime prieiti prie pateiktų elementų.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}