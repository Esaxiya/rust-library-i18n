//! Darbo su skolintais duomenimis modulis.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait skolinantis duomenis.
///
/// " Rust` yra įprasta pateikti skirtingus tipo vaizdus skirtingiems naudojimo atvejams.
/// Pvz., Vertės saugojimo vietą ir valdymą galima specialiai pasirinkti tam tikram naudojimui naudojant žymeklių tipus, pvz., [`Box<T>`] arba [`Rc<T>`].
/// Be šių bendrų įvyniojimų, kuriuos galima naudoti su bet kokiais tipais, kai kurie tipai teikia pasirinktinius aspektus, suteikiančius potencialiai brangių funkcijų.
/// Tokio tipo pavyzdys yra " [`String`], kuris suteikia galimybę išplėsti eilutę prie pagrindinio " [`str`].
/// Tam reikia laikyti nereikalingą papildomą informaciją paprastai, nekintamai eilutei.
///
/// Šie tipai suteikia prieigą prie pagrindinių duomenų pateikdami nuorodas į tų duomenų tipą.Sakoma, kad jie yra " pasiskolinti` kaip tokio tipo.
/// Pavyzdžiui, [`Box<T>`] galima skolintis kaip `T`, o [`String`]-`str`.
///
/// Tipai reiškia, kad juos galima pasiskolinti kaip kai kuriuos `T` tipus, įgyvendinant `Borrow<T>`, pateikiant nuorodą į `T` trait [`borrow`] metodu.Tipas gali laisvai skolintis kaip keli skirtingi tipai.
/// Jei jis nori skolintis kaip tipo-leisdamas pakeisti pagrindinius duomenis, jis gali papildomai įdiegti " [`BorrowMut<T>`].
///
/// Be to, teikiant papildomų traits diegimą, reikia apsvarstyti, ar jie turėtų elgtis identiškai kaip pagrindinio tipo, kaip to pagrindinio tipo atvaizdo pasekmė.
/// Bendrasis kodas paprastai naudoja " `Borrow<T>`, kai jis remiasi identišku šių papildomų " trait` diegimų elgesiu.
/// Šie traits greičiausiai pasirodys kaip papildomi trait bounds.
///
/// Visų pirma `Eq`, `Ord` ir `Hash` turi būti lygiavertės skolintoms ir turimoms vertėms: `x.borrow() == y.borrow()` turėtų duoti tą patį rezultatą kaip `x == y`.
///
/// Jei bendrąjį kodą reikia naudoti tik visiems tipams, kurie gali pateikti nuorodą į susijusį `T` tipą, dažnai geriau naudoti " [`AsRef<T>`], nes daugiau tipų gali jį saugiai įgyvendinti.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Duomenims rinkti " [`HashMap<K, V>`] priklauso ir raktai, ir reikšmės.Jei faktiniai rakto duomenys suvynioti į kažkokį tvarkymo tipą, vis tiek turėtų būti įmanoma ieškoti vertės naudojant nuorodą į rakto duomenis.
/// Pavyzdžiui, jei raktas yra eilutė, jis greičiausiai saugomas su maišos žemėlapiu kaip [`String`], tuo tarpu turėtų būti įmanoma ieškoti naudojant [`&str`][`str`].
/// Taigi, `insert` turi veikti su `String`, o `get`-su `&str`.
///
/// Šiek tiek supaprastinta, atitinkamos " `HashMap<K, V>` dalys atrodo taip:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // laukai praleisti
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Visas maišos žemėlapis yra bendras, naudojant raktų tipą `K`.Kadangi šie raktai saugomi su maišos žemėlapiu, šiam tipui turi priklausyti rakto duomenys.
/// Įterpiant raktų ir verčių porą, žemėlapiui suteikiamas toks `K` ir reikia rasti tinkamą maišos segmentą ir patikrinti, ar raktas jau yra pagal tą `K`.Todėl reikia `K: Hash + Eq`.
///
/// Tačiau ieškant vertės žemėlapyje, norint pateikti raktą, reikia pateikti nuorodą į " `K`, kad visada būtų sukurta tokia priklausanti vertė.
/// Styginių raktams tai reikštų, kad reikia sukurti `String` reikšmę tik ieškant atvejų, kai yra tik `str`.
///
/// Vietoj to, `get` metodas yra pagrindinis pagrindinių duomenų, vadinamų `Q` aukščiau esančiame metodo parašu, tipui.Jame teigiama, kad `K` skolinasi kaip `Q` reikalaudamas to `K: Borrow<Q>`.
/// Papildomai reikalaujant " `Q: Hash + Eq`, tai reiškia reikalavimą, kad " `K` ir " `Q` būtų įdiegti " `Hash` ir " `Eq` traits`, kurie duoda identiškus rezultatus.
///
/// " `get` diegimas visų pirma priklauso nuo identiškų " `Hash` diegimų nustatant rakto maišos grupę iškviečiant `Hash::hash` į `Q` vertę, net jei ji įterpė raktą pagal maišos vertę, apskaičiuotą iš `K` vertės.
///
///
/// Dėl to maišos žemėlapis nutrūksta, jei `K`, suvyniojęs `Q` reikšmę, sukuria kitokį maišos variantą nei `Q`.Pvz., Įsivaizduokite, kad turite tipą, kuris apvynioja eilutę, tačiau palygina ASCII raides, nepaisydamas jų didžiųjų raidžių:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Kadangi dviem vienodomis reikšmėmis reikia sukurti tą pačią maišos reikšmę, įgyvendinant " `Hash` reikia nepaisyti ir ASCII atvejų:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ar " `CaseInsensitiveString` gali įgyvendinti " `Borrow<str>`?Tai tikrai gali pateikti nuorodą į eilutės pjūvį per jai priklausančią eilutę.
/// Kadangi skiriasi jo " `Hash` diegimas, jis elgiasi kitaip nei " `str`, todėl iš tikrųjų neturi įgyvendinti " `Borrow<str>`.
/// Jei ji nori leisti kitiems prisijungti prie pagrindinio " `str`, tai gali padaryti per " `AsRef<str>`, kuriai nereikia jokių papildomų reikalavimų.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Neabejotinai skolinasi iš nuosavybės vertės.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait už abipusį skolinimąsi duomenų.
///
/// Kaip " [`Borrow<T>`] kompanionas, šis " trait` leidžia tipui skolintis kaip pagrindiniam tipui, pateikdamas kintamą nuorodą.
/// Norėdami sužinoti daugiau apie skolinimąsi kaip kitą tipą, žr. [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Tikrai skolinasi iš nuosavybės vertės.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}