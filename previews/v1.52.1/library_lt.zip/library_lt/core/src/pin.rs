//! Tipai, kurie pritvirtina duomenis prie vietos atmintyje.
//!
//! Kartais naudinga turėti objektų, kurie garantuotai nejudės, ta prasme, kad jų vieta atmintyje nesikeičia, todėl jais galima pasikliauti.
//! Puikus tokio scenarijaus pavyzdys būtų savirefresyvių struktūrų sukūrimas, nes perkėlus objektą su žymikliais į juos, jie negalios, o tai gali sukelti neapibrėžtą elgesį.
//!
//! Aukštu lygiu " [`Pin<P>`] užtikrina, kad bet kurio tipo " `P` žymeklis turėtų stabilią vietą atmintyje, vadinasi, jo negalima perkelti kitur ir jo atminties negalima paskirstyti tol, kol ji nukris.Mes sakome, kad taškas yra "pinned".Aptariant tipus, kurie sujungiami su nesusegtais duomenimis, viskas tampa subtiliau;[see below](#projections-and-structural-pinning) daugiau informacijos.
//!
//! Pagal numatytuosius nustatymus visi Rust tipai yra kilnojami.
//! " Rust`leidžia perduoti visų tipų vertes, o įprasti " smart-pointer` tipai, pvz., [`Box<T>`] ir `&mut T`, leidžia pakeisti ir perkelti juose esančias vertes: galite išeiti iš " [`Box<T>`] arba naudoti " [`mem::swap`].
//! [`Pin<P>`] apvynioja `P` tipo žymeklį, taigi [" PIN`] " <" [" Box`] `<T>> veikia panašiai kaip įprastas
//!
//! [`Box<T>`]: when a [" PIN`] " <" [" Box`] `<T>>`nukrenta, taip pat jo turinys ir atmintis
//!
//! išsidėstęs.Panašiai [" Pin`] " <&mut T>` labai panašus į " `&mut T`.Tačiau " [`Pin<P>`] neleidžia klientams iš tikrųjų gauti prie prisegtų duomenų [`Box<T>`] arba `&mut T`, o tai reiškia, kad negalite naudoti tokių operacijų kaip [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` reikia `&mut T`, bet mes negalime jo gauti.
//!     // Mes įstrigome, negalime pakeisti šių nuorodų turinio.
//!     // Galėtume naudoti " `Pin::get_unchecked_mut`, tačiau tai yra nesaugu dėl priežasties:
//!     // mums neleidžiama jo naudoti norint perkelti daiktus iš " `Pin`.
//! }
//! ```
//!
//! Verta pakartoti, kad [`Pin<P>`]*nekeičia fakto, kad Rust kompiliatorius laiko visų tipų kilnojamaisiais." [`mem::swap`] ir toliau gali skambinti bet kuris " `T`.Vietoj to, [`Pin<P>`] apsaugo nuo tam tikrų* reikšmių * (nurodytų į [`Pin<P>`] suvyniotų rodyklių) perkėlimo, todėl neįmanoma iškviesti metodų, kuriems reikia `&mut T` (pvz., [`mem::swap`]).
//!
//! [`Pin<P>`] gali būti naudojamas apvynioti bet kokį `P` tipo žymeklį ir sąveikauja su [`Deref`] ir [`DerefMut`].[`Pin<P>`], kur `P: Deref` turėtų būti laikomas "`P`-style pointer" prie prisegto `P::Target`-taigi, [" Smeigtukas`] <" [" Dėžutė`]`<T>> " yra prisegto `T` rodyklė ir [" PIN`]" <`[" Rc`] `<T>> yra nuorodos suskaičiuotas žymeklis prie prisegto `T`.
//! Kad būtų teisinga, " [`Pin<P>`] remiasi " [`Deref`] ir " [`DerefMut`] diegimais, kad jie neišeitų iš savo parametro " `self` ir tik visada grąžintų rodyklę prie prisegtų duomenų, kai jie bus iškviesti ant prisegto rodyklės.
//!
//! # `Unpin`
//!
//! Daugelis tipų visada yra laisvai judami, net kai jie yra prisegti, nes jie nepasitiki tuo, kad turi stabilų adresą.Tai apima visus pagrindinius tipus (pvz., [`bool`], [`i32`] ir nuorodas), taip pat tipus, sudarytus tik iš šių tipų.Tipai, kuriems nerūpi prisegimas, įgyvendina " [`Unpin`] auto-trait`, kuris panaikina " [`Pin<P>`] poveikį.
//! Jei naudojate " `T: Unpin`, [" PIN`] " <`[" Box`]<T>> ir [`Box<T>`] veikia identiškai, kaip ir [" Smeigtukas`] " <&mut T>` ir `&mut T`.
//!
//! Atkreipkite dėmesį, kad prisegimas ir [`Unpin`] turi įtakos tik smailiam `P::Target` tipui, o ne pačiam `P` tipo žymekliui, kuris buvo įvyniotas į [`Pin<P>`].Pavyzdžiui, nesvarbu, ar [`Box<T>`] yra [`Unpin`], neturi įtakos [" Pin`] " <` [" Box`]`elgsenai.<T>> " (čia `T` yra smailus tipas).
//!
//! # Pavyzdys: savireferencinė struktūra
//!
//! Prieš pradėdami išsamiau paaiškinti garantijas ir pasirinkimus, susijusius su " `Pin<T>`, aptarsime keletą pavyzdžių, kaip jis gali būti naudojamas.
//! Galite laisvai naudotis " [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Tai yra savaiminė nuoroda, nes pjūvio laukas nurodo duomenų lauką.
//! // Negalime apie tai informuoti kompiliatoriaus su įprasta nuoroda, nes šio modelio negalima apibūdinti pagal įprastas skolinimosi taisykles.
//! //
//! // Vietoj to mes naudojame neapdorotą rodyklę, nors žinoma, kad ji nėra nulinė, nes žinome, kad ji nukreipta į eilutę.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Norėdami užtikrinti, kad duomenys nejudėtų grąžinus funkciją, mes juos dedame į krūvą, kur jie liks objekto visą gyvenimą, ir vienintelis būdas prieiti prie jų būtų per rodyklę.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // žymeklį kuriame tik tada, kai duomenys yra, kitaip jis jau bus pajudėjęs, net mums nepradėjus
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // mes žinome, kad tai yra saugu, nes modifikuojant lauką nepajudinama visa struktūra
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Žymeklis turi būti nukreiptas į teisingą vietą, kol struktūra nepajudėjo.
//! //
//! // Tuo tarpu mes galime laisvai perkelti žymeklį.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Kadangi mūsų tipas neįdiegia atsegimo, to nepavyks sukompiliuoti:
//! // tegul mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Pavyzdys: įkyrus dvigubai susietas sąrašas
//!
//! Įkyriame dvigubai susietame sąraše kolekcija iš tikrųjų nepaskirsto atminties patiems elementams.
//! Paskirstymą kontroliuoja klientai, o elementai gali gyventi ant rietuvės rėmo, kuris gyvena trumpiau nei kolekcija.
//!
//! Kad šis darbas būtų veiksmingas, kiekvienas elementas turi nuorodas į savo pirmtaką ir įpėdinį sąraše.Elementus galima pridėti tik tada, kai jie yra prisegti, nes elementus perkėlus aplink rodyklės negalios.Be to, susieto sąrašo elemento [`Drop`] įgyvendinimas užtaisys pirmtako ir įpėdinio rodiklius, kad pašalintų save iš sąrašo.
//!
//! Svarbiausia, kad mes galėtume pasikliauti [`drop`] iškvietimu.Jei elementą būtų galima išskirstyti ar kitaip pripažinti negaliojančiu nepakviečiant " [`drop`], rodyklės į jį iš jo kaimyninių elementų netektų galios, o tai sulaužytų duomenų struktūrą.
//!
//! Todėl prisegimui taip pat suteikiama su [" numetimu`] susijusi garantija.
//!
//! # `Drop` guarantee
//!
//! Prisegimo tikslas yra galimybė pasikliauti tam tikrų duomenų talpinimu atmintyje.
//! Kad tai veiktų, ribojamas ne tik duomenų perkėlimas;Taip pat yra ribojama atminties, naudojamos duomenims saugoti, paskirstymas, pakartotinis pakeitimas ar kitoks negalavimas.
//! Konkrečiai kalbant, kad prisegti duomenys turi nekintantį variantą, kad *jo atmintis negalios ar nebus pakeista nuo to momento, kai ji bus prisegta, iki tada, kai bus iškviestas [`drop`]*.Tik tada, kai grįš " [`drop`] arba " panics`, atmintis gali būti pakartotinai naudojama.
//!
//! Atmintis gali būti "invalidated" išskaidant, bet taip pat pakeičiant [`Some(v)`] [`None`] arba iškviečiant [`Vec::set_len`] į "kill" kai kuriuos elementus išjungus vector.Jis gali būti pakeistas naudojant " [`ptr::write`], kad perrašytumėte jį iš pradžių nepaskambinę į destruktorių.Nieko iš jų neleidžiama prisegtiems duomenims, neskambinant į " [`drop`].
//!
//! Tai yra būtent tokia garantija, kad įkyraus susieto sąrašo iš ankstesnio skyriaus veikimas turi būti teisingas.
//!
//! Atkreipkite dėmesį, kad ši garantija nereiškia, kad atmintis neteka!Vis dar gerai, kad niekada negalima skambinti [`drop`] ant prisegto elemento (pvz., Vis tiek galite skambinti [`mem::forget`] ant [" PIN`] " <` [" Box`]`<T>> `).Dvigubai susieto sąrašo pavyzdyje tas elementas tiesiog liktų sąraše.Tačiau negalite atlaisvinti ar pakartotinai naudoti saugyklos *, nepaskambinę [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Jei jūsų tipas naudoja prisegimą (pvz., Du aukščiau pateiktus pavyzdžius), turite būti atsargūs diegdami " [`Drop`].[`drop`] funkcija užima `&mut self`, tačiau tai vadinama *, net jei jūsų tipas anksčiau buvo prisegtas*!Tarsi kompiliatorius automatiškai paskambino [`Pin::get_unchecked_mut`].
//!
//! Tai niekada negali sukelti problemų saugiame kode, nes norint įdiegti tipą, kuris priklauso nuo prisegimo, reikalingas nesaugus kodas, tačiau atminkite, kad nusprendus naudoti prisegimą jūsų tipui (pvz., Vykdant tam tikrą operaciją su " [PIN`]`<&Self> `arba [` Pin '] `<&mut Self>`) taip pat turi pasekmių ir jūsų [`Drop`] diegimui: jei jūsų tipo elementas galėjo būti prisegtas, turite laikyti [`Drop`] netiesiogiai paimantį [`PIN'] <&mut Aš>>.
//!
//!
//! Pavyzdžiui, galite įdiegti " `Drop` taip:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` yra gerai, nes mes žinome, kad ši vertė niekada nebebus naudojama, kai bus numesta.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Tikrasis metimo kodas eina čia.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcija `inner_drop` turi tipą, kurį turėtų turėti " [`drop`] *`, todėl tai užtikrina, kad netyčia nenaudosite " `self`/`this` taip, kad tai prieštarautų prisegimui.
//!
//! Be to, jei jūsų tipas yra `#[repr(packed)]`, kompiliatorius automatiškai perkels laukus, kad galėtų juos mesti.Tai netgi gali padaryti laukai, kurie atsitinka pakankamai išlyginti.Todėl negalite naudoti prisegimo su `#[repr(packed)]` tipu.
//!
//! # Projekcijos ir konstrukcinis tvirtinimas
//!
//! Dirbant su prisegtomis struktūromis kyla klausimas, kaip galima pasiekti tos struktūros laukus taikant metodą, kuriam reikia tik [" PIN`] " <&mut Struct>`.
//! Įprastas būdas yra parašyti pagalbinius metodus (taip vadinamus *projekcijas*), kurie paverčia [" Pin`] " <&mut Struct>` nuoroda į lauką, tačiau kokio tipo ši nuoroda turėtų būti?Ar tai [" PIN`] " <&mut Field>`, ar `&mut Field`?
//! Tas pats klausimas kyla ir su `enum` laukais, taip pat atsižvelgiant į tokius container/wrapper tipus kaip [`Vec<T>`], [`Box<T>`] ar [`RefCell<T>`].
//! (Šis klausimas taikomas tiek kintamoms, tiek bendrai naudojamoms nuorodoms, mes iliustracijai naudojame tik dažniausiai pasitaikančius kintamų nuorodų atvejus.)
//!
//! Pasirodo, kad iš tikrųjų duomenų struktūros autorius turi nuspręsti, ar pritvirtinta konkretaus lauko projekcija paverčia [" Pin`] " <&mut Struct>` į [" PIN`] " <&mut Field>` ar `&mut Field`.Vis dėlto yra keletas apribojimų, o svarbiausias apribojimas yra *nuoseklumas*:
//! kiekvienas laukas gali būti *suprojektuotas* prie pritvirtintos nuorodos,*arba* projekcijos metu pašalintas smeigtukas.
//! Jei abu veiksmai atliekami tame pačiame lauke, tai greičiausiai bus nepagrįsta!
//!
//! Kaip duomenų struktūros autorius, kiekvienam laukui turite nuspręsti, ar prisegti "propagates" prie šio lauko, ar ne.
//! Spaudimas, kuris plinta, taip pat vadinamas "structural", nes jis atitinka tipo struktūrą.
//! Tolesniuose poskyriuose aprašome svarstymus, kuriuos reikia padaryti pasirinkus bet kurį variantą.
//!
//! ## Prisegimas *nėra*`field` struktūrinis elementas
//!
//! Gali atrodyti priešingai, kad prisegto struktūros laukas gali būti neprisegtas, tačiau tai iš tikrųjų yra lengviausias pasirinkimas: jei niekada nebus sukurtas [" PIN`] " <&mut Field>`, nieko nebus blogai!Taigi, jei nuspręsite, kad kuriame nors lauke nėra struktūrinio prisegimo, tereikia įsitikinti, kad niekada nesukuriate prisegtos nuorodos į tą lauką.
//!
//! Laukuose be struktūrinio prisegimo gali būti naudojamas projekcijos metodas, kuris paverčia [" PIN`] " <&mut Struct>` į `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Tai gerai, nes " `field` niekada nelaikomas prisegtu.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Taip pat galite `impl Unpin for Struct`*, net jei*`field` tipas nėra [`Unpin`].Tai, ką šis tipas galvoja apie prisegimą, nėra svarbu, kai niekada nėra sukurtas [" PIN`] " <&mut Field>`.
//!
//! ## Prisegimas * yra `field` struktūrinis elementas
//!
//! Kitas variantas yra nuspręsti, kad prisegimas yra "structural", skirtas `field`, o tai reiškia, kad jei struktūra yra prisegta, tai yra ir laukas.
//!
//! Tai leidžia parašyti projekciją, kuri sukuria [" PIN`] " <&mut Field>`, taigi liudija, kad laukas yra prisegtas:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Tai gerai, nes `field` yra prisegtas, kai yra `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Tačiau konstrukciniam tvirtinimui taikomi keli papildomi reikalavimai:
//!
//! 1. Struktūra turi būti [`Unpin`] tik tuo atveju, jei visi struktūriniai laukai yra [`Unpin`].Tai yra numatytasis nustatymas, tačiau " [`Unpin`] yra saugus " trait`, todėl kaip struktūros autorius jūsų pareiga *ne* pridėti kažką panašaus į `impl<T> Unpin for Struct<T>`.
//! (Atkreipkite dėmesį, kad norint pridėti projekcijos operaciją reikia nesaugaus kodo, todėl tai, kad [`Unpin`] yra saugus trait, nepažeidžia principo, kad dėl bet kurio iš šių dalykų turite jaudintis tik tuo atveju, jei naudojate " nesaugu`.)
//! 2. Struktūros destruktorius neturi perkelti struktūrinių laukų iš savo argumento.Tai yra tikslus klausimas, kuris buvo iškeltas naudojant " [previous section][drop-impl]: " `drop` ima " `&mut self`, tačiau struktūra (taigi ir jos laukai) galėjo būti prisegta anksčiau.
//!     Turite garantuoti, kad neperkeliate lauko [`Drop`] diegimo viduje.
//!     Visų pirma, kaip paaiškinta anksčiau, tai reiškia, kad jūsų struktūra *neturi* būti `#[repr(packed)]`.
//!     Žr. Tą skyrių, kaip parašyti [`drop`] taip, kad kompiliatorius galėtų padėti jums netyčia nenutraukti prisegimo.
//! 3. Turite įsitikinti, kad palaikote " [`Drop` guarantee][drop-guarantee]:
//!     prisegus struktūrą, atmintis, kurioje yra turinys, neperrašoma ir nepaskirstoma, nepakviečiant turinio naikintojų.
//!     Tai gali būti keblu, kaip liudija [`VecDeque<T>`]: [`VecDeque<T>`] destruktorius gali nepavykti iškviesti [`drop`] visuose elementuose, jei vienas iš destruktorių yra panics.Tai pažeidžia " [`Drop`] garantiją, nes tai gali sukelti elementų išsidėstymą be jų destruktoriaus iškvietimo.([`VecDeque<T>`] neturi prisegamų projekcijų, todėl tai nesukelia nepagrįstumo.)
//! 4. Negalite siūlyti jokių kitų operacijų, dėl kurių duomenys gali būti perkelti iš struktūrinių laukų, kai jūsų tipas yra prisegtas.Pvz., Jei struktūroje yra [`Option<T>`] ir yra " take` tipo operacija su `fn(Pin<&mut Struct<T>>) -> Option<T>` tipu, tą operaciją galima naudoti norint perkelti `T` iš prisegto `Struct<T>`-tai reiškia, kad smeigimas negali būti struktūrinis laukui, kuriame yra tai duomenis.
//!
//!     Norėdami gauti sudėtingesnį duomenų perkėlimo iš prisegto tipo pavyzdį, įsivaizduokite, ar [`RefCell<T>`] turėjo metodą `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Tada galėtume atlikti šiuos veiksmus:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Tai katastrofiška, tai reiškia, kad pirmiausia galime pritvirtinti " [`RefCell<T>`] turinį (naudodami " `RefCell::get_pin_mut`) ir tada perkelti tą turinį naudodami vėliau gautą kintamą nuorodą.
//!
//! ## Examples
//!
//! Tokio tipo, kaip [`Vec<T>`], prasmės yra abi galimybės (struktūrinis prisegimas ar ne).
//! [`Vec<T>`] su struktūriniu prisegimu gali turėti `get_pin`/`get_pin_mut` metodus, kad gautų prisegtas nuorodas į elementus.Tačiau tai negalėjo *neleisti* skambinti [`pop`][Vec::pop] prisegtu [`Vec<T>`], nes tai perkeltų (struktūriškai prisegtą) turinį!Taip pat negalėjo leisti " [`push`][Vec::push], kuris gali perskirstyti turinį ir taip perkelti.
//!
//! " [`Vec<T>`] be struktūrinio prisegimo gali būti " `impl<T> Unpin for Vec<T>`, nes jo turinys niekada nėra prisegamas, o pats " [`Vec<T>`] yra gerai, kai jį taip pat galima perkelti.
//! Tuo metu prisegimas tiesiog neturi jokios įtakos vector.
//!
//! Standartinėje bibliotekoje žymeklių tipai paprastai neturi struktūrinio prisegimo, todėl jie nesiūlo prisegimo projekcijų.Štai kodėl " `Box<T>: Unpin` tinka visiems " `T`.
//! Tikslinga tai daryti rodyklių tipams, nes judant `Box<T>`, `T` iš tikrųjų nepajudinamas: [`Box<T>`] gali būti laisvai judamas (dar žinomas kaip `Unpin`), net jei `T` nėra.Tiesą sakant, net [" Pin`] " <" [" Box`] `<T>>`ir [`Pin`]] <&mut T> `visada yra patys [`Unpin`], dėl tos pačios priežasties: jų turinys (`T`) yra prisegtas, tačiau pačius rodykles galima perkelti neperkėlus prisegtų duomenų.
//! Tiek [`Box<T>`], tiek [" Pin`] " <` [" Box`]`<T>>, ar turinys yra prisegtas, visiškai nepriklauso nuo to, ar rodyklė yra prisegta, tai reiškia, kad prisegimas nėra * struktūrinis.
//!
//! Įdiegdami " [`Future`] kombinatorių, jums dažniausiai reikės struktūrinio prisegimo, jei norite įdėti įdėtą " futures`, nes norint gauti skambutį " [`poll`], reikia gauti prisegtas nuorodas į juos.
//! Bet jei jūsų kombinatoriuje yra bet kokių kitų duomenų, kurių nereikia prisegti, galite padaryti tuos laukus nestruktūrinius, taigi, laisvai prieiti prie jų naudodami kintamą nuorodą, net jei tik turite [" PIN`] " <&mut Self>` (pvz., kaip savo [`poll`] diegime).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Prisegtas rodyklė.
///
/// Tai yra apvyniojimas aplink tam tikrą žymeklį, kuris padaro tą rodyklę "pin" savo vietoje, neleidžiant perkelti rodyklės nurodytos vertės, nebent ji įgyvendina [`Unpin`].
///
///
/// *Prisegimo paaiškinimą rasite [`pin` module] dokumentacijoje.*
///
/// [`pin` module]: self
///
// Note: Žemiau pateiktas " `Clone` išvedimas sukelia nesąžiningumą, nes jį įmanoma įgyvendinti
// `Clone` kintamoms nuorodoms.
// Norėdami sužinoti daugiau, žr. <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Šie išvardijimai nėra išvesti siekiant išvengti patikimumo problemų.
// `&self.pointer` neturėtų būti prieinamas nepatikimiems trait diegimams.
//
// Norėdami sužinoti daugiau, žr. <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Sukurkite naują " `Pin<P>` aplink žymeklį prie kai kurių duomenų, kurie įgyvendina " [`Unpin`].
    ///
    /// Skirtingai nuo " `Pin::new_unchecked`, šis metodas yra saugus, nes žymeklis `P` daro nuorodas į " [`Unpin`] tipą, o tai panaikina prisegimo garantijas.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAUGUMAS: nurodyta vertė yra `Unpin`, todėl jai netaikomi jokie reikalavimai
        // aplink prisegimą.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Atvynioja šį `Pin<P>` ir grąžina pagrindinį rodyklę.
    ///
    /// Tam reikia, kad `Pin` viduje esantys duomenys būtų [`Unpin`], kad juos išvyniodami negalėtume ignoruoti prisegamų invariantų.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Sukurkite naują `Pin<P>` aplink nuorodą į kai kuriuos duomenis, kurie gali įgyvendinti `Unpin`.
    ///
    /// Jei `pointer` nukrypimai nuo `Unpin` tipo, vietoj jo turėtų būti naudojama `Pin::new`.
    ///
    /// # Safety
    ///
    /// Šis konstruktorius yra nesaugus, nes negalime garantuoti, kad `pointer` nurodyti duomenys yra prisegti, o tai reiškia, kad duomenys nebus perkelti arba jų saugykla negalios, kol jie nebus išmesti.
    /// Jei sukonstruotas `Pin<P>` negarantuoja, kad duomenys, į kuriuos nukreipia `P`, yra prisegti, tai yra API sutarties pažeidimas ir gali sukelti neapibrėžtą elgesį vėlesnėse (safe) operacijose.
    ///
    /// Naudodami šį metodą, kuriate " promise` apie `P::Deref` ir `P::DerefMut` diegimus, jei jų yra.
    /// Svarbiausia, kad jie neturi išeiti iš savo `self` argumentų: `Pin::as_mut` ir `Pin::as_ref` iškviečia `DerefMut::deref_mut` ir `Deref::deref`*ant prisegto rodyklės* ir tikisi, kad šie metodai palaikys prisegtus invariantus.
    /// Be to, paskambinę šiuo metodu, jūs promise, kad nuorodos `P` išlygos nebebus perkeltos;visų pirma neturi būti įmanoma gauti `&mut P::Target` ir tada išeiti iš tos nuorodos (naudojant, pavyzdžiui, [`mem::swap`]).
    ///
    ///
    /// Pvz., Skambinti " `Pin::new_unchecked`" `&'a mut T` yra nesaugu, nes nors ir galite prisegti tam tikrą " `'a` gyvenimą, jūs negalite kontroliuoti, ar jis laikomas prisegtas, kai baigiasi " `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Tai turėtų reikšti, kad kontroliuojamasis `a` niekada nebegali judėti.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // " `a` adresas pasikeitė į " b` kamino lizdą, todėl " `a` buvo perkeltas, nors mes jį anksčiau prisegėme!Pažeidėme prisegimo API sutartį.
    /////
    /// }
    /// ```
    ///
    /// Kai vertė yra prisegta, ji turi likti visam laikui (nebent jos tipas įgyvendina `Unpin`).
    ///
    /// Panašiai ir `Pin::new_unchecked` skambinimas " `Rc<T>` yra nesaugus, nes gali būti tų pačių duomenų slapyvardžiai, kuriems netaikomi prisegimo apribojimai:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Tai turėtų reikšti, kad auklėtinis daugiau niekada negali judėti.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Dabar, jei " `x` buvo vienintelė nuoroda, mes turime kintamą nuorodą į duomenis, kuriuos pritvirtinome aukščiau, kuriuos galėtume naudoti, kad juos perkeltume, kaip matėme ankstesniame pavyzdyje.
    ///     // Pažeidėme prisegimo API sutartį.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Gauna prisegtą bendrą nuorodą iš šio prisegto rodyklės.
    ///
    /// Tai yra bendras metodas nuo `&Pin<Pointer<T>>` iki `Pin<&T>`.
    /// Tai saugu, nes pagal " `Pin::new_unchecked` sutartį nurodomasis negali judėti sukūręs " `Pin<Pointer<T>>`.
    ///
    /// "Malicious" " `Pointer::Deref` diegimas taip pat atmetamas " `Pin::new_unchecked` sutartimi.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SAUGA: žr. Šios funkcijos dokumentaciją
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Atvynioja šį `Pin<P>` ir grąžina pagrindinį rodyklę.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi.Turite garantuoti, kad iškvietę šią funkciją ir toliau laikysite žymeklį `P` kaip prisegtą, kad būtų galima išlaikyti `Pin` tipo invariantus.
    /// Jei kodas, naudojant gautą " `P`, ir toliau neišlaiko prisegamų invariantų, tai yra API sutarties pažeidimas ir gali sukelti neapibrėžtą elgesį vėlesnėse (safe) operacijose.
    ///
    ///
    /// Jei pagrindiniai duomenys yra [`Unpin`], vietoj jo reikėtų naudoti [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Gauna prisegtą keičiamą nuorodą iš šio prisegto rodyklės.
    ///
    /// Tai yra bendras metodas nuo `&mut Pin<Pointer<T>>` iki `Pin<&mut T>`.
    /// Tai saugu, nes pagal " `Pin::new_unchecked` sutartį nurodomasis negali judėti sukūręs " `Pin<Pointer<T>>`.
    ///
    /// "Malicious" " `Pointer::DerefMut` diegimas taip pat atmetamas " `Pin::new_unchecked` sutartimi.
    ///
    /// Šis metodas yra naudingas atliekant kelis skambučius funkcijoms, kurios naudoja prisegtą tipą.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // ką nors padaryti
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` sunaudoja `self`, todėl skolinkitės `Pin<&mut Self>` per `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SAUGA: žr. Šios funkcijos dokumentaciją
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Priskiria naują vertę už prisegtos nuorodos esančią atmintį.
    ///
    /// Tai perrašo prisegtus duomenis, bet tai yra gerai: jo naikintuvas paleidžiamas prieš perrašant, todėl jokia prisegimo garantija nėra pažeista.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Sukonstruoja naują kaištį, priskirdamas interjero vertę.
    ///
    /// Pvz., Jei norite gauti kažkokio lauko `Pin`, galite jį naudoti norėdami gauti prieigą prie to lauko vienoje kodo eilutėje.
    /// Tačiau yra keletas " getchas`su šiais " "pinning projections";
    /// išsamesnės informacijos ta tema rasite [`pin` module] dokumentacijoje.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi.
    /// Turite garantuoti, kad jūsų grąžinti duomenys nebus judinami tol, kol argumento reikšmė nejudės (pavyzdžiui, todėl, kad tai yra vienas iš tos vertės laukų), taip pat, kad neišeitumėte iš gauto argumento interjero funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SAUGA: `new_unchecked` saugos sutartis turi būti
        // palaikė skambinantysis.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Gauna bendrą nuorodą iš kaiščio.
    ///
    /// Tai saugu, nes neįmanoma išeiti iš bendros nuorodos.
    /// Gali atrodyti, kad čia yra problema dėl interjero kintamumo: iš tikrųjų *galima* perkelti " `T` iš " `&RefCell<T>`.
    /// Tačiau tai nėra problema, jei nėra ir `Pin<&T>`, nukreipiančio į tuos pačius duomenis, o " `RefCell<T>` neleidžia jums sukurti prisegtos nuorodos į jos turinį.
    ///
    /// Daugiau informacijos rasite diskusijoje apie ["pinning projections"].
    ///
    /// Note: `Pin` taip pat įgyvendina tikslą `Deref`, kurį galima naudoti norint pasiekti vidinę vertę.
    /// Tačiau " `Deref` pateikia tik nuorodą, kuri gyvuoja tiek, kiek skolinasi " `Pin`, o ne paties " `Pin` gyvavimo laiką.
    /// Šis metodas leidžia " `Pin` paversti nuoroda, kurios tarnavimo laikas yra toks pats kaip ir originalaus " `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konvertuoja šį " `Pin<&mut T>` į " `Pin<&T>` su tuo pačiu tarnavimo laiku.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Gauna kintamą nuorodą į duomenis, esančius šiame `Pin`.
    ///
    /// Tam reikia, kad `Pin` viduje esantys duomenys būtų `Unpin`.
    ///
    /// Note: `Pin` taip pat įgyvendina `DerefMut` prie duomenų, kuriuos galima naudoti norint pasiekti vidinę vertę.
    /// Tačiau " `DerefMut` pateikia tik nuorodą, kuri gyvuoja tiek, kiek skolinasi " `Pin`, o ne paties " `Pin` gyvavimo laiką.
    ///
    /// Šis metodas leidžia " `Pin` paversti nuoroda, kurios tarnavimo laikas yra toks pats kaip ir originalaus " `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Gauna kintamą nuorodą į duomenis, esančius šiame `Pin`.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi.
    /// Turite garantuoti, kad niekada nepajudinsite duomenų iš kintamos nuorodos, kurią gausite paskambinę į šią funkciją, kad būtų palaikomi `Pin` tipo invariantai.
    ///
    ///
    /// Jei pagrindiniai duomenys yra `Unpin`, vietoj jo reikėtų naudoti `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Sukonstruokite naują kaištį, priskirdami interjero vertę.
    ///
    /// Pvz., Jei norite gauti kažkokio lauko `Pin`, galite jį naudoti norėdami gauti prieigą prie to lauko vienoje kodo eilutėje.
    /// Tačiau yra keletas " getchas`su šiais " "pinning projections";
    /// išsamesnės informacijos ta tema rasite [`pin` module] dokumentacijoje.
    ///
    /// # Safety
    ///
    /// Ši funkcija yra nesaugi.
    /// Turite garantuoti, kad jūsų grąžinti duomenys nebus judinami tol, kol argumento reikšmė nejudės (pavyzdžiui, todėl, kad tai yra vienas iš tos vertės laukų), taip pat, kad neišeitumėte iš gauto argumento interjero funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SAUGUMAS: skambintojas yra atsakingas už neperkėlimą
        // vertė iš šios nuorodos.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SAUGUMAS: nes garantuojama, kad `this` vertės neturės
        // buvo perkeltas, šis skambutis į " `new_unchecked` yra saugus.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Gaukite prisegtą nuorodą iš statinės nuorodos.
    ///
    /// Tai saugu, nes " `T` yra skolinamas " `'static` visam gyvenimui, kuris niekada nesibaigia.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SAUGUMAS: " Statinis skolinimasis garantuoja, kad duomenų nebus
        // moved/invalidated kol jis nenukris (o to niekada nėra).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Gaukite prisegtą kintamą nuorodą iš statinės kintamos nuorodos.
    ///
    /// Tai saugu, nes " `T` yra skolinamas " `'static` visam gyvenimui, kuris niekada nesibaigia.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SAUGUMAS: " Statinis skolinimasis garantuoja, kad duomenų nebus
        // moved/invalidated kol jis nenukris (o to niekada nėra).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: tai reiškia, kad bet koks `CoerceUnsized` implantas, leidžiantis versti iš
// tipas, kuris implikuoja `Deref<Target=impl !Unpin>` tipui, kuris implikuoja `Deref<Target=Unpin>`, yra nepagrįstas.
// Bet koks toks implikas tikriausiai būtų nepagrįstas dėl kitų priežasčių, todėl turime tiesiog pasirūpinti, kad tokie implantai nebūtų nusileisti std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}