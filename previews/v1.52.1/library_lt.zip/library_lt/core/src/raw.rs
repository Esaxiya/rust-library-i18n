#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Sudėtyje yra kompiliatoriaus įmontuotų tipų išdėstymo struktūros apibrėžimai.
//!
//! Jie gali būti naudojami kaip nesaugaus kodo perdavimo tikslai, norint tiesiogiai manipuliuoti neapdorotais vaizdais.
//!
//!
//! Jų apibrėžimas visada turėtų atitikti ABI, apibrėžtą `rustc_middle::ty::layout`.
//!

/// trait objekto, pvz., `&dyn SomeTrait`, vaizdavimas.
///
/// Šios struktūros išdėstymas yra toks pat kaip tipų, tokių kaip `&dyn SomeTrait` ir `Box<dyn AnotherTrait>`.
///
/// `TraitObject` garantuojama, kad jis sutaps su išdėstymais, tačiau tai nėra " trait`objektų tipas (pvz., laukai nėra tiesiogiai pasiekiami naudojant " `&dyn SomeTrait`), taip pat jis jo nevaldo (pakeitus apibrėžimą, `&dyn SomeTrait` išdėstymas nepasikeis).
///
/// Jis skirtas naudoti tik nesaugiam kodui, kuriam reikia manipuliuoti žemo lygio detalėmis.
///
/// Negalima bendrai vadinti visų trait objektų, todėl vienintelis būdas sukurti tokio tipo vertes yra tokios funkcijos kaip [`std::mem::transmute`][transmute].
/// Panašiai vienintelis būdas sukurti tikrą trait objektą iš `TraitObject` reikšmės yra `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetinus trait objektą su neatitinkančiais tipais-tokiu atveju, kai " vtable` neatitinka vertės, į kurią nukreipia duomenų rodyklė, tipo, greičiausiai bus neapibrėžtas elgesys.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // pavyzdys trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // tegul kompiliatorius sukuria trait objektą
/// let object: &dyn Foo = &value;
///
/// // pažvelkite į neapdorotą atstovavimą
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // duomenų rodyklė yra " `value` adresas
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // sukonstruokite naują objektą, nukreipdami į kitą " `i32`, atsargiai naudokite " `i32` vtable` iš `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // jis turėtų veikti taip, lyg būtume iš `other_value` tiesiai sukonstravę trait objektą
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}