//! " Libcore` prelude
//!
//! Šis modulis skirtas " libcore`vartotojams, kurie taip pat nesusiję su " libstd`.
//! Šis modulis yra importuojamas pagal numatytuosius nustatymus, kai " `#![no_std]` naudojamas taip pat, kaip ir standartinės bibliotekos " prelude`.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015 m. Pagrindinio prelude versija.
///
/// Norėdami sužinoti daugiau, žiūrėkite " [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018 m. Pagrindinio prelude versija.
///
/// Norėdami sužinoti daugiau, žiūrėkite " [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021 m. Šerdies " prelude` versija.
///
/// Norėdami sužinoti daugiau, žiūrėkite " [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Pridėkite daugiau dalykų.
}