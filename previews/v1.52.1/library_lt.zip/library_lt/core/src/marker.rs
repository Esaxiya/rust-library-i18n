//! Primityvūs traits ir tipai, atstovaujantys pagrindines tipų savybes.
//!
//! Rust tipai gali būti klasifikuojami įvairiais naudingais būdais pagal jų vidines savybes.
//! Šios klasifikacijos pateikiamos kaip traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipai, kuriuos galima perkelti per siūlų ribas.
///
/// Šis trait yra automatiškai įgyvendinamas, kai kompiliatorius nustato, kad jis tinkamas.
///
/// Ne " Siųsti` tipo pavyzdys yra nuorodų skaičiavimo rodyklė [`rc::Rc`][`Rc`].
/// Jei dvi gijos bando klonuoti [" Rc`], kurie nurodo tą pačią nuorodų skaičiuojamą vertę, jie gali bandyti atnaujinti nuorodų skaičių tuo pačiu metu, o tai yra [undefined behavior][ub], nes [`Rc`] nenaudoja atominių operacijų.
///
/// Jo pusbrolis [`sync::Arc`][arc] naudoja atomines operacijas (patiria šiek tiek pridėtinių išlaidų), taigi yra `Send`.
///
/// Norėdami sužinoti daugiau, žr. [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipai su pastoviu dydžiu, žinomi kompiliavimo metu.
///
/// Visi tipo parametrai yra numanomi `Sized`.Jei tai nėra tinkama, gali būti naudojama speciali sintaksė `?Sized`.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//klaida: " [i32] nėra įdiegtas dydis
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Vienintelė išimtis yra numanomas " trait` tipo `Self` tipas.
/// trait neturi netiesioginio `Sized`, nes tai nesuderinama su [trait objektu], kur pagal apibrėžimą trait turi dirbti su visais įmanomais vykdytojais, todėl gali būti bet kokio dydžio.
///
///
/// Nors " Rust`leis jums susieti " `Sized` su " trait`, vėliau jo negalėsite suformuoti " trait` objektui:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // tegul y: &dyn juosta= &Impl;//klaida: trait `Bar` negalima padaryti objektu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // pvz., pagal numatytąjį, kuris reikalauja, kad `[T]: !Default` būtų įvertinamas
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipai, kurie gali būti "unsized" iki dinamiško dydžio tipo.
///
/// Pavyzdžiui, dydžio masyvo tipas `[i8; 2]` įgyvendina `Unsize<[i8]>` ir `Unsize<dyn fmt::Debug>`.
///
/// Visus `Unsize` diegimus kompiliatorius pateikia automatiškai.
///
/// `Unsize` yra įgyvendinamas:
///
/// - `[T; N]` yra `Unsize<[T]>`
/// - `T` yra `Unsize<dyn Trait>`, kai `T: Trait`
/// - `Foo<..., T, ...>` yra `Unsize<Foo<..., U, ...>>`, jei:
///   - `T: Unsize<U>`
///   - Foo yra struktūra
///   - Tik paskutiniame `Foo` lauke yra tipas, susijęs su `T`
///   - `T` nėra jokių kitų laukų tipo dalis
///   - `Bar<T>: Unsize<Bar<U>>`, jei paskutiniame `Foo` lauke yra `Bar<T>` tipas
///
/// `Unsize` yra naudojamas kartu su [`ops::CoerceUnsized`], kad "user-defined" talpyklose, tokiose kaip [`Rc`], būtų dinamiško dydžio tipų.
/// Norėdami gauti daugiau informacijos, žiūrėkite " [DST coercion RFC][RFC982] ir " [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Reikalingas trait konstantoms, naudojamoms modelių atitikmenyse.
///
/// Bet koks tipas, gaunantis `PartialEq`, automatiškai įgyvendina šį trait, nepriklausomai nuo to, ar jo tipo parametrai įgyvendina `Eq`.
///
/// Jei elemente `const` yra kažkokio tipo, kuris neįgyvendina šio trait, tai to tipo (1.) neįdiegia `PartialEq` (tai reiškia, kad konstanta nepateiks to palyginimo metodo, kuris, kaip manoma, galimas kodo generavimas), arba (2.) jis įgyvendina *savo*`PartialEq` versija (kuri, mūsų manymu, neatitinka struktūrinės lygybės palyginimo).
///
///
/// Bet kuriuo iš dviejų aukščiau pateiktų scenarijų atmetame tokios konstantos naudojimą modelio atitikime.
///
/// Taip pat žiūrėkite " [structural match RFC][RFC1445] ir " [issue 63438], kurie motyvavo perėjimą nuo atributais pagrįsto dizaino į šį " trait`.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Reikalingas trait konstantoms, naudojamoms modelių atitikmenyse.
///
/// Bet koks tipas, gaunantis `Eq`, automatiškai įgyvendina šį trait, * nepaisant to, ar jo tipo parametrai įgyvendina `Eq`.
///
/// Tai yra įsilaužimas, leidžiantis išvengti apribojimų mūsų tipo sistemoje.
///
/// # Background
///
/// Norime reikalauti, kad šablonų rungtynių tipai būtų naudojami `#[derive(PartialEq, Eq)]`.
///
/// Idealesniame pasaulyje mes galėtume patikrinti šį reikalavimą tiesiog patikrinę, ar nurodytas tipas įgyvendina ir " `StructuralPartialEq` trait *`, ir*" `Eq` trait`.
/// Tačiau galite turėti ADT, kurie *daro*`derive(PartialEq, Eq)`, ir būti atvejis, kurį norime, kad kompiliatorius priimtų, ir vis dėlto konstantos tipas nepavyksta įgyvendinti `Eq`.
///
/// Būtent toks atvejis:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Pirmiau nurodyto kodo problema yra ta, kad `Wrap<fn(&())>` neįdiegia nei `PartialEq`, nei `Eq`, nes " for <` a> fn(&'a _)` does not implement those traits.)
///
/// Todėl negalime pasikliauti naiviu " `StructuralPartialEq` ir " `Eq` patikrinimu.
///
/// Siekdami išspręsti šią problemą, mes naudojame du atskirus traits, kuriuos įpurškė abu išvestiniai (`#[derive(PartialEq)]` ir `#[derive(Eq)]`), ir patikriname, ar jie abu yra struktūrinės atitikties tikrinimo dalis.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipai, kurių reikšmes galima nukopijuoti paprasčiausiai nukopijuojant bitus.
///
/// Pagal numatytuosius nustatymus kintamieji susiejimai turi " perkelti semantiką`.Kitaip tariant:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` perkėlė į " `y`, todėl jo naudoti negalima
///
/// // println! ("{: ?}", x);//klaida: perkeltos vertės naudojimas
/// ```
///
/// Tačiau jei tipas įgyvendina `Copy`, jis turi " kopijavimo semantiką`:
///
/// ```
/// // Galime išvesti `Copy` diegimą.
/// // `Clone` taip pat reikalingas, nes tai yra `Copy` supertažas.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` yra `x` kopija
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Svarbu pažymėti, kad šiuose dviejuose pavyzdžiuose vienintelis skirtumas yra tai, ar po užduoties jums leidžiama pasiekti " `x`.
/// Po kopija ir perkėlimu bitai gali būti nukopijuoti į atmintį, nors tai kartais ir optimizuojama.
///
/// ## Kaip galiu įdiegti " `Copy`?
///
/// Yra du būdai, kaip įdiegti " `Copy` jūsų tipui.Paprasčiausia naudoti " `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Taip pat galite rankiniu būdu įdiegti " `Copy` ir " `Clone`:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Tarp šių dviejų yra nedidelis skirtumas: strategija `derive` taip pat įtrauks tipo parametrams susietą `Copy`, ko ne visada norima.
///
/// ## Kuo skiriasi " `Copy` ir " `Clone`?
///
/// Kopijos vyksta netiesiogiai, pavyzdžiui, kaip užduoties `y = x` dalis." `Copy` elgesys nėra perkrautas;tai visada paprasta bitų išmintinga kopija.
///
/// Klonavimas yra aiškus veiksmas, `x.clone()`.[`Clone`] diegimas gali suteikti bet kokio tipo elgseną, reikalingą saugiai kopijuoti vertes.
/// Pvz., Įgyvendinant " [`Clone`], skirtą " [`String`], reikia nukopijuoti smailių į eilutes buferį į krūvą.
/// Paprasta [`String`] reikšmių bitų kopija tik nukopijuos žymeklį, o tai du kartus paliks laisvą liniją.
/// Dėl šios priežasties [`String`] yra [`Clone`], bet ne `Copy`.
///
/// [`Clone`] yra `Copy` supertraitas, todėl viskas, kas yra `Copy`, taip pat turi įgyvendinti [`Clone`].
/// Jei tipas yra `Copy`, jo [`Clone`] įgyvendinimas turi grąžinti tik `*self` (žr. Aukščiau pateiktą pavyzdį).
///
/// ## Kada mano tipas gali būti `Copy`?
///
/// Tipas gali įgyvendinti `Copy`, jei visi jo komponentai įgyvendina `Copy`.Pvz., Ši struktūra gali būti `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktūra gali būti `Copy`, o [`i32`] yra `Copy`, todėl `Point` gali būti `Copy`.
/// Priešingai, apsvarstykite
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktūra `PointList` negali įgyvendinti `Copy`, nes [`Vec<T>`] nėra `Copy`.Jei bandysime išgauti `Copy` diegimą, gausime klaidą:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Bendros nuorodos (`&T`) taip pat yra `Copy`, todėl tipas gali būti `Copy`, net jei jame yra bendrų `T` tipų nuorodų, kurios nėra * `Copy`.
/// Apsvarstykite šią struktūrą, kuri gali įdiegti " `Copy`, nes ji turi tik " bendrą nuorodą * į mūsų ne" kopijavimo`tipą `PointList` iš viršaus:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kada *ar* mano tipas negali būti `Copy`?
///
/// Kai kurių tipų negalima saugiai nukopijuoti.Pvz., Nukopijavus `&mut T`, būtų sukurta slapyvardžiu keičiama nuoroda.
/// Nukopijavus " [`String`] būtų dubliuojama atsakomybė už " [String`] `buferio valdymą, o tai būtų dviguba nemokama.
///
/// Apibendrinant pastarąjį atvejį, bet kuris tipas, įgyvendinantis " [`Drop`], negali būti " `Copy`, nes jis valdo kai kuriuos išteklius be savo " [`size_of::<T>`] baitų.
///
/// Jei bandysite įdiegti `Copy` struktūroje ar sąraše, kuriame yra ne " Copy` duomenys, gausite klaidą [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kada *turėtų* mano tipas būti `Copy`?
///
/// Apskritai, jei jūsų tipo " _can_ įdiegia " `Copy`, tai turėtų.
/// Nepamirškite, kad " `Copy` diegimas yra jūsų tipo viešosios API dalis.
/// Jei tipas " future`gali tapti ne " Kopija`, būtų protinga dabar praleisti " `Copy` diegimą, kad būtų išvengta pertraukiančių API pakeitimų.
///
/// ## Papildomi įgyvendintojai
///
/// Be " [implementors listed below][impls], šie tipai taip pat įdiegia " `Copy`:
///
/// * Funkcijų elementų tipai (ty kiekvienai funkcijai nustatyti atskiri tipai)
/// * Funkcijos žymeklio tipai (pvz., `fn() -> i32`)
/// * Visų dydžių masyvo tipai, jei elemento tipas taip pat įdiegia `Copy` (pvz., `[i32; 123456]`)
/// * Tuple tipai, jei kiekvienas komponentas taip pat įdiegia `Copy` (pvz., `()`, `(i32, bool)`)
/// * Uždarymo tipai, jei jie nepriima jokios aplinkos vertės arba jei visos tokios užfiksuotos vertės pačios įgyvendina " `Copy`.
///   Atminkite, kad kintamieji, užfiksuoti naudojant bendrą nuorodą, visada įgyvendina `Copy` (net jei referentas to nepadaro), o kintamosios nuorodos užfiksuoti kintamieji niekada neįgyvendina `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Tai leidžia kopijuoti tipą, kuris neįdiegia `Copy` dėl nepatenkintų gyvenimo trukmės apribojimų (kopijuojant `A<'_>`, kai tik `A<'static>: Copy` ir `A<'_>: Clone`).
// Šiuo metu šį atributą turime tik todėl, kad yra nemažai esamų " `Copy` specializacijų, kurios jau yra standartinėje bibliotekoje, ir šiuo metu nėra jokio būdo saugiai elgtis.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Išveskite makrokomandą, generuojančią trait `Copy` implikaciją.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipai, kuriems saugu dalytis nuorodomis tarp gijų.
///
/// Šis trait yra automatiškai įgyvendinamas, kai kompiliatorius nustato, kad jis tinkamas.
///
/// Tikslus apibrėžimas: `T` tipas yra [`Sync`] tik tada, jei `&T` yra [`Send`].
/// Kitaip tariant, jei perduodant `&T` nuorodas tarp gijų nėra galimybės [undefined behavior][ub] (įskaitant duomenų lenktynes).
///
/// Kaip ir galima tikėtis, tokie primityvūs tipai, kaip [`u8`] ir [`f64`], yra visi [`Sync`], taip pat yra paprastų sudedamųjų tipų tipai, tokie kaip rinkiniai, struktūros ir enums.
/// Daugiau pagrindinių [`Sync`] tipų pavyzdžių yra "immutable" tipai, pvz., `&T`, ir tipai, turintys paprastą paveldimą kintamumą, pvz., [`Box<T>`][box], [`Vec<T>`][vec] ir dauguma kitų kolekcijų tipų.
///
/// (Kad jų talpykla būtų [" Sinchronizuoti`), bendrieji parametrai turi būti [`Sync`].)
///
/// Šiek tiek stebina apibrėžimo pasekmė yra ta, kad `&mut T` yra `Sync` (jei `T` yra `Sync`), nors atrodo, kad tai gali sukelti nesinchronizuotą mutaciją.
/// Apgaulė yra ta, kad keičiamos nuorodos, esančios už bendros nuorodos (tai yra `& &mut T`), tampa tik skaitomos, tarsi `& &T`.
/// Taigi nėra duomenų lenktynių rizikos.
///
/// Tipai, kurie nėra " `Sync`, yra tie, kurie turi " "interior mutability" formą, kuri nėra saugi siūlams, pvz., " [`Cell`][cell] ir " [`RefCell`][refcell].
/// Šie tipai leidžia mutuoti jų turinį net naudojant nekintamą, bendrą nuorodą.
/// Pavyzdžiui, `set` metodas [`Cell<T>`][cell] užima `&self`, todėl jam reikalinga tik bendra nuoroda [`&Cell<T>`][cell].
/// Metodas nevykdo sinchronizavimo, todėl [`Cell`][cell] negali būti `Sync`.
///
/// Kitas ne " Sync` tipo pavyzdys yra nuorodų skaičiavimo rodyklė [`Rc`][rc].
/// Atsižvelgdami į bet kurią nuorodą [`&Rc<T>`][rc], galite klonuoti naują [`Rc<T>`][rc], modifikuodami atskaitos skaičių ne atominiu būdu.
///
/// Tais atvejais, kai reikia, kad interjeras būtų lengvai keičiamas siūlais, Rust teikia [atomic data types], taip pat aiškų užraktą per [`sync::Mutex`][mutex] ir [`sync::RwLock`][rwlock].
/// Šie tipai užtikrina, kad jokios mutacijos negali sukelti duomenų lenktynių, todėl tipai yra `Sync`.
/// Panašiai " [`sync::Arc`][arc] pateikia " [`Rc`][rc] analogą, kuris yra saugus siūlams.
///
/// Visi tipai, turintys vidinį kintamumą, taip pat turi naudoti [`cell::UnsafeCell`][unsafecell] apvalkalą aplink value(s), kurį galima mutuoti naudojant bendrą nuorodą.
/// Nepavykus to padaryti yra " [undefined behavior][ub].
/// Pvz., [`Transmute`][transmute]-ing nuo `&T` iki `&mut T` yra neteisingas.
///
/// Norėdami sužinoti daugiau apie `Sync`, žr. [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kai palaikymas pridėti pastabų " `rustc_on_unimplemented` patenka į beta versiją, ir jis buvo išplėstas siekiant patikrinti, ar uždarymas yra kur nors reikalavimo grandinėje, išplėskite jį kaip tokį (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulinio dydžio tipas naudojamas žymėti daiktus, kuriuos "act like" turi `T`.
///
/// Pridėjus `PhantomData<T>` lauką prie savo tipo, kompiliatorius nurodo, kad jūsų tipas veikia taip, lyg jis išsaugotų `T` tipo vertę, nors taip ir nėra.
/// Ši informacija naudojama apskaičiuojant tam tikras saugos savybes.
///
/// Norėdami išsamiau paaiškinti, kaip naudoti `PhantomData<T>`, žr. [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Šiurpi pastaba 👻👻👻
///
/// Nors abu jie turi bauginančius pavadinimus, " `PhantomData` ir " fantominiai tipai` yra susiję, tačiau nėra tapatūs.Fantomo tipo parametras yra tiesiog tipo parametras, kuris niekada nenaudojamas.
/// Naudojant " Rust`, kompiliatorius dažnai skundžiasi, o sprendimas yra pridėti "dummy" naudojimą naudojant `PhantomData`.
///
/// # Examples
///
/// ## Nenaudojami viso gyvenimo parametrai
///
/// Galbūt labiausiai paplitęs " `PhantomData` atvejis yra struktūra, kurioje yra nenaudojamas viso gyvenimo parametras, paprastai kaip tam tikro nesaugaus kodo dalis.
/// Pvz., Čia yra struct `Slice`, turintis du `*const T` tipo rodiklius, kurie greičiausiai nukreipti į masyvą kažkur:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Tikslas yra tai, kad pagrindiniai duomenys galioja tik visą `'a` gyvenimą, todėl `Slice` neturėtų pergyventi `'a`.
/// Tačiau šis ketinimas nėra išreikštas kode, nes nėra `'a` naudojimo trukmės naudojimo atvejų, todėl nėra aišku, kuriems duomenims jis taikomas.
/// Mes galime tai ištaisyti liepdami kompiliatoriui elgtis *taip, tarsi*`Slice` struktūroje būtų nuoroda `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Tam, savo ruožtu, taip pat reikalinga `T: 'a` anotacija, nurodanti, kad visos nuorodos `T` galioja visą `'a` gyvenimą.
///
/// Inicializuodami `Slice`, `phantom` lauke tiesiog nurodykite `PhantomData` reikšmę:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nenaudojami tipo parametrai
///
/// Kartais atsitinka, kad turite nenaudojamų tipo parametrų, kurie nurodo, kokio tipo duomenims yra " "tied" struktūra, nors tų duomenų iš tikrųjų nėra pačiame struktūroje.
/// Čia yra pavyzdys, kai tai kyla naudojant [FFI].
/// Užsienio sąsajoje naudojamos `*mut ()` tipo rankenos, nurodant skirtingų tipų Rust reikšmes.
/// Mes sekame " Rust`tipą, naudodami fantominio tipo parametrą, esantį " Struct `ExternalResource`, kuris suvynioja rankeną.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Nuosavybė ir patikrinimas
///
/// Pridėjus `PhantomData<T>` tipo lauką, jūsų tipui priklauso `T` tipo duomenys.Tai savo ruožtu reiškia, kad atsisakius jūsų tipo, jis gali atsisakyti vieno ar daugiau `T` tipo egzempliorių.
/// Tai turi įtakos Rust kompiliatoriaus [drop check] analizei.
///
/// Jei jūsų struktūrai iš tikrųjų *nepriklauso `T` tipo duomenys, geriau naudoti nuorodos tipą, pvz., `PhantomData<&'a T>` (ideally) arba `PhantomData<* const T>` (jei netaikomas gyvenimo laikotarpis), kad nenurodytumėte nuosavybės teisės.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Kompiliatorius-vidinis trait naudojamas nurodyti enum diskriminantų tipą.
///
/// Šis " trait`automatiškai įgyvendinamas kiekvienam tipui ir nepateikia jokių garantijų " [`mem::Discriminant`].
/// Tai yra **neapibrėžtas elgesys**, kurį reikia perduoti tarp `DiscriminantKind::Discriminant` ir `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Diskriminanto tipas, kuris turi atitikti `mem::Discriminant` reikalaujamą trait bounds.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompiliatorius-vidinis trait naudojamas nustatyti, ar tipe yra `UnsafeCell` viduje, bet ne per nukreipimą.
///
/// Tai daro įtaką, pavyzdžiui, ar tokio tipo `static` yra dedamas į tik skaitomą statinę atmintį, ar į rašytinę statinę atmintį.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipai, kuriuos galima saugiai perkelti prisegus.
///
/// Pats " Rust` neturi nekilnojamojo tipo sąvokos ir mano, kad judesiai (pvz., Perduodant ar [`mem::replace`]) visada yra saugūs.
///
/// Vietoj to, norint išvengti judėjimo per tipo sistemą, naudojamas [`Pin`][Pin] tipas.Žymeklių `P<T>`, suvyniotų į [`Pin<P<T>>`][Pin] apvalkalą, negalima iškelti.
/// Daugiau informacijos apie prisegimą rasite [`pin` module] dokumentacijoje.
///
/// Įdiegus " `Unpin` trait`, skirtą " `T`, panaikinami tipo nubraukimo apribojimai, o tai leidžia perkelti " `T` iš " [`Pin<P<T>>`][Pin] su tokiomis funkcijomis kaip " [`mem::replace`].
///
///
/// `Unpin` neturi jokių pasekmių nesusietiems duomenims.
/// Visų pirma, " [`mem::replace`] su malonumu perkelia " `!Unpin` duomenis (tai tinka bet kokiems " `&mut T`, ne tik tada, kai " `T: Unpin`).
/// Tačiau negalite naudoti " [`mem::replace`] duomenims, įvyniotiems į " [`Pin<P<T>>`][Pin], nes negalite gauti tam reikalingo " `&mut T`, o *tai* priverčia šią sistemą veikti.
///
/// Pavyzdžiui, tai galima padaryti tik tipams, naudojantiems " `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Mums reikia kintamos nuorodos, kad paskambintume į `mem::replace`.
/// // Tokią nuorodą galime gauti iškvietę (implicitly), naudodami `Pin::deref_mut`, tačiau tai įmanoma tik todėl, kad `String` įgyvendina `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Šis " trait` automatiškai įgyvendinamas beveik kiekvienam tipui.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Žymeklio tipas, kuris neįdiegia `Unpin`.
///
/// Jei tipe yra " `PhantomPinned`, jis pagal nutylėjimą neįgyvendins " `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` įgyvendinimas primityviems tipams.
///
/// Diegimai, kurių negalima aprašyti programoje Rust, yra įdiegiami `traits::SelectionContext::copy_clone_conditions()` sistemoje `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Bendras nuorodas galima nukopijuoti, tačiau kintamų nuorodų *negalima*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}