//! Rust įgyvendinimas panics nutraukus procesą
//!
//! Palyginus su įgyvendinimu atsukant, šis crate yra *daug* paprastesnis!Tai sakant, jis nėra toks universalus, bet čia!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" naudingoji apkrova ir tarpinė atitinkamam abonementui nutraukti minėtoje platformoje.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // paskambinkite std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // " Windows naudokite procesoriui būdingą __fastfail mechanizmą." Windows 8` ir naujesnėse versijose procesas bus nedelsiant nutrauktas, nevykdant jokių išimčių tvarkymo procesų.
            // Ankstesnėse " Windows versijose ši instrukcijų seka bus traktuojama kaip prieigos pažeidimas, nutraukiantis procesą, bet nebūtinai apeinant visus išimčių tvarkytuvus.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: tai tas pats diegimas kaip libstd `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Tai ... yra šiokia tokia keistenybė.Tl; dr;yra tai, kad to reikia norint tinkamai susieti, ilgesnis paaiškinimas yra žemiau.
//
// Šiuo metu visi " libcore/libstd dvejetainiai failai, kuriuos pristatome, yra sudaryti naudojant " `-C panic=unwind`.Tai daroma siekiant užtikrinti, kad dvejetainiai failai būtų maksimaliai suderinami su kuo daugiau situacijų.
// Vis dėlto kompiliatoriui reikia "personality function" visoms funkcijoms, sukompiliuotoms su `-C panic=unwind`.Ši asmenybės funkcija yra koduojama simboliu `rust_eh_personality` ir ją apibrėžia langas `eh_personality`.
//
// So...
// kodėl čia ne tik apibrėžus tą lang elementą?Geras klausimas!" panic`vykdymo laiko susiejimas iš tikrųjų yra šiek tiek subtilus tuo, kad jie yra "sort of" kompiliatoriaus " crate` parduotuvėje, tačiau iš tikrųjų susieti tik tuo atveju, jei kitas iš tikrųjų nėra susietas.
//
// Tai reiškia, kad tiek šis " crate`, tiek " panic_unwind crate` gali pasirodyti kompiliatoriaus " crate`parduotuvėje, ir jei abu apibrėžia " `eh_personality` lang` elementą, tai įvyksta klaida.
//
// Kompiliatorius, norėdamas tai tvarkyti, reikalauja, kad `eh_personality` būtų apibrėžtas tik tuo atveju, jei susietas panic vykdymo laikas yra atsukimo laikas, ir kitaip jo nereikia apibrėžti (teisingai).
// Tačiau šiuo atveju ši biblioteka tik apibrėžia šį simbolį, taigi kažkur yra bent kažkokia asmenybė.
//
// Iš esmės šis simbolis yra tiesiog apibrėžtas norint prijungti prie libcore/libstd dvejetainių failų, tačiau jo niekada nereikėtų vadinti, nes mes visiškai nesusiejame su atsukamuoju vykdymo laiku.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // " X86_64-pc-windows-gnu` mes naudojame savo asmenybės funkciją, kuri turi grąžinti `ExceptionContinueSearch`, kai perduodame visus savo rėmus.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Panašiai kaip aukščiau, tai atitinka " `eh_catch_typeinfo` lang`elementą, kuris šiuo metu naudojamas tik " Emscripten`.
    //
    // Kadangi " panics`nesukuria išimčių, o užsienio išimtys šiuo metu yra UB su -C panic=nutraukti (nors tai gali būti keičiama), bet kokie " catch_unwind` skambučiai niekada nenaudos šio tipo informacijos.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Šiuos du vadina mūsų paleisties objektai, esantys " i686-pc-windows-gnu`, tačiau jiems nieko nereikia daryti, todėl kūnai yra ne.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}