#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Naujosios atminties turinys neinicijuotas.
    Uninitialized,
    /// Garantuojama, kad naujoji atmintis bus nulinė.
    Zeroed,
}

/// Žemo lygio įrankis, skirtas ergonomiškiau paskirstyti, perskirstyti ir paskirstyti atminties buferį ant krūvos, nesijaudinant dėl visų susijusių kampinių atvejų.
///
/// Šis tipas puikiai tinka kurti savo duomenų struktūras, tokias kaip " Vec`ir " VecDeque`.
/// Visų pirma:
///
/// * Gamina " `Unique::dangling()` be nulinio dydžio tipų.
/// * Gaminamas " `Unique::dangling()` paskirstymas be ilgio.
/// * Vengia atlaisvinti `Unique::dangling()`.
/// * Gaudo visus perpildytus pajėgumų skaičiavimus (skatina juos į "capacity overflow" panics).
/// * Apsaugo nuo 32 bitų sistemų, skiriančių daugiau nei isize::MAX baitų.
/// * Apsaugo nuo jūsų ilgio perpildymo.
/// * Skambina " `handle_alloc_error` dėl klaidingų paskirstymų.
/// * Sudėtyje yra " `ptr::Unique` ir vartotojui suteikiamos visos su tuo susijusios naudos.
/// * Naudoja perteklių, grąžintą iš paskirstytojo, kad išnaudotų didžiausią turimą pajėgumą.
///
/// Šis tipas vistiek netikrina jo valdomos atminties.Nukritęs jis *atlaisvins atmintį, bet* nemėgins išmesti turinio.
/// " `RawVec` vartotojas turi tvarkyti faktinius dalykus,*saugomus*" `RawVec` viduje.
///
/// Atkreipkite dėmesį, kad nulinio dydžio tipų perteklius visada yra begalinis, todėl `capacity()` visada grąžina `usize::MAX`.
/// Tai reiškia, kad turėtumėte būti atsargūs, kai sukite šį tipą su " `Box<[T]>`, nes " `capacity()` ilgio neduos.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Taip yra todėl, kad `#[unstable]` `const fn`s neturi atitikti `min_const_fn`, todėl jų taip pat negalima iškviesti į`min_const_fn`.
    ///
    /// Jei pakeisite " `RawVec<T>::new` ar priklausomybes, nepamirškite įvesti nieko, kas tikrai pažeistų " `min_const_fn`.
    ///
    /// NOTE: Galėtume išvengti šio įsilaužimo ir patikrinti atitiktį tam tikram `#[rustc_force_min_const_fn]` atributui, kuriam reikalinga atitiktis `min_const_fn`, bet nebūtinai leidžiama jį iškviesti `stable(...) const fn`/vartotojo kodu, neįgalinančiu `foo`, kai yra `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Sukuria didžiausią įmanomą " `RawVec` (sistemos krūvoje) nepaskiriant.
    /// Jei `T` turi teigiamą dydį, tai daro `RawVec`, kurio talpa yra `0`.
    /// Jei `T` yra nulio dydžio, tada jis daro `RawVec`, kurio talpa yra `usize::MAX`.
    /// Naudinga įgyvendinant uždelstą paskirstymą.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Sukuria " `RawVec`(sistemos krūvoje), tiksliai nurodydamas " `[T; capacity]` talpos ir derinimo reikalavimus.
    /// Tai tolygu skambučiui `RawVec::new`, kai `capacity` yra `0` arba `T` yra lygus nuliui.
    /// Atminkite, kad jei " `T` yra nulio dydžio, tai reiškia, kad * negausite " `RawVec` su reikalaujama talpa.
    ///
    /// # Panics
    ///
    /// Panics, jei prašoma talpa viršija `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Nutraukiama OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Kaip ir " `with_capacity`, tačiau garantuoja, kad buferis bus nulis.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Atkuria `RawVec` iš rodyklės ir talpos.
    ///
    /// # Safety
    ///
    /// `ptr` turi būti priskirtas (ant sistemos kaupo) ir su nurodytu `capacity`.
    /// `capacity` dydžių tipams negali viršyti `isize::MAX`.(rūpi tik 32 bitų sistemoms).
    /// " ZST vectors` gali būti iki `usize::MAX` talpos.
    /// Jei " `ptr` ir " `capacity` yra iš " `RawVec`, tai garantuojama.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Mažyčiai vekai yra nebylūs.Pereiti prie:
    // - 8, jei elemento dydis yra 1, nes bet kuris krūvos paskirstytojas gali suapvalinti mažiau nei 8 baitų užklausą iki mažiausiai 8 baitų.
    //
    // - 4, jei elementai yra vidutinio dydžio (<=1 KiB).
    // - 1 kitaip, kad nebūtų švaistoma per daug vietos labai trumpiems Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Kaip ir " `new`, bet parametruojamas atsižvelgiant į grąžinamo " `RawVec` paskirstytojo pasirinkimą.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` reiškia "unallocated".nulio dydžio tipai nepaisomi.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Kaip ir " `with_capacity`, bet parametruojamas atsižvelgiant į grąžinamo " `RawVec` paskirstytojo pasirinkimą.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Kaip ir " `with_capacity_zeroed`, bet parametruojamas atsižvelgiant į grąžinamo " `RawVec` paskirstytojo pasirinkimą.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` paverčia `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konvertuoja visą buferį į `Box<[MaybeUninit<T>]>` su nurodytu `len`.
    ///
    /// Atminkite, kad tai tinkamai atkurs visus atliktus `cap` pakeitimus.(Išsamesnės informacijos ieškokite tipo aprašyme.)
    ///
    /// # Safety
    ///
    /// * `len` - turi būti didesnis arba lygus paskutiniam prašomam pajėgumui ir
    /// * `len` turi būti mažesnė arba lygi `self.capacity()`.
    ///
    /// Atkreipkite dėmesį, kad prašoma talpa ir " `self.capacity()` gali skirtis, nes paskirstytojas gali bendrai susieti ir grąžinti didesnį atminties bloką nei reikalaujama.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sveikas protas-patikrinkite pusę saugos reikalavimų (kitos pusės mes negalime patikrinti).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Čia išvengiame " `unwrap_or_else`, nes jis išpučia sugeneruoto LLVM IR kiekį.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Atkuria `RawVec` iš rodyklės, talpos ir paskirstytojo.
    ///
    /// # Safety
    ///
    /// `ptr` turi būti priskirtas (per nurodytą skirstytuvą `alloc`) ir su duotu `capacity`.
    /// `capacity` dydžių tipams negali viršyti `isize::MAX`.
    /// (rūpi tik 32 bitų sistemoms).
    /// " ZST vectors` gali būti iki `usize::MAX` talpos.
    /// Jei " `ptr` ir " `capacity` yra iš " `RawVec`, sukurto per " `alloc`, tai bus garantuota.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Gauna neapdorotą rodiklį prie paskirstymo pradžios.
    /// Atminkite, kad tai yra `Unique::dangling()`, jei `capacity == 0` arba `T` yra nulio dydžio.
    /// Pirmuoju atveju turite būti atsargūs.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Gauna paskirstymo pajėgumą.
    ///
    /// Tai visada bus `usize::MAX`, jei `T` yra nulio dydžio.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Grąžina bendrinamą nuorodą paskirstytojui, palaikančiam šį `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Turime priskirtą atminties dalį, todėl galime apeiti vykdymo laiko patikras, kad gautume dabartinį išdėstymą.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Užtikrina, kad buferyje būtų bent jau pakankamai vietos `len + additional` elementams laikyti.
    /// Jei jis dar neturi pakankamai pajėgumų, perskirs pakankamai vietos ir patogios vietos, kad amortizuotų *O*(1) elgesį.
    ///
    /// Apribos šį elgesį, jei tai be reikalo sukeltų panic.
    ///
    /// Jei `len` viršija `self.capacity()`, gali nepavykti iš tikrųjų paskirstyti prašomos vietos.
    /// Tai tikrai nėra nesaugu, tačiau nesaugus kodas, kurį rašote * ir kuris remiasi šios funkcijos veikimu, gali sugesti.
    ///
    /// Tai idealiai tinka įgyvendinti masinio stūmimo operaciją, pvz., `extend`.
    ///
    /// # Panics
    ///
    /// Panics, jei nauja talpa viršija `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Nutraukiama OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezervas būtų nutrauktas arba išsigandęs, jei lenas viršytų `isize::MAX`, todėl dabar tai daryti saugu.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Tas pats, kas `reserve`, bet grąžina klaidas, o ne panikuoja ar nutraukia.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Užtikrina, kad buferyje būtų bent jau pakankamai vietos `len + additional` elementams laikyti.
    /// Jei to dar nepadarė, perskirstys mažiausią įmanomą atminties kiekį.
    /// Paprastai tai bus tiksliai reikalingas atminties kiekis, tačiau iš esmės paskirstytojas gali laisvai grąžinti daugiau, nei prašėme.
    ///
    ///
    /// Jei `len` viršija `self.capacity()`, gali nepavykti iš tikrųjų paskirstyti prašomos vietos.
    /// Tai tikrai nėra nesaugu, tačiau nesaugus kodas, kurį rašote * ir kuris remiasi šios funkcijos veikimu, gali sugesti.
    ///
    /// # Panics
    ///
    /// Panics, jei nauja talpa viršija `isize::MAX` baitus.
    ///
    /// # Aborts
    ///
    /// Nutraukiama OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Tas pats, kas `reserve_exact`, bet grąžina klaidas, o ne panikuoja ar nutraukia.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Sumažina paskirstymą iki nurodytos sumos.
    /// Jei nurodyta suma yra 0, iš tikrųjų visiškai paskirstoma.
    ///
    /// # Panics
    ///
    /// Panics, jei nurodyta suma yra *didesnė* nei dabartinė talpa.
    ///
    /// # Aborts
    ///
    /// Nutraukiama OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Grąžina, jei buferis turi išaugti, kad įvykdytų reikiamą papildomą pajėgumą.
    /// Daugiausia naudojamas norint įterpti atsarginius skambučius be `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Šis metodas paprastai yra išaiškinamas daug kartų.Taigi mes norime, kad jis būtų kuo mažesnis, kad pagerėtų kompiliavimo laikas.
    // Bet mes taip pat norime, kad kuo daugiau jo turinio būtų statiškai apskaičiuojama, kad sugeneruotas kodas veiktų greičiau.
    // Todėl šis metodas yra kruopščiai parašytas, kad visas kodas, priklausantis nuo `T`, būtų jame, o kuo daugiau kodo, kuris nepriklauso nuo `T`, yra funkcijose, kurios nėra generinės per `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Tai užtikrina skambinantys kontekstai.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Kadangi grąžiname `usize::MAX` talpą, kai yra `elem_size`
            // 0, čia patekimas būtinai reiškia, kad " `RawVec` yra perpildytas.
            return Err(CapacityOverflow);
        }

        // Deja, nieko negalime padaryti dėl šių patikrinimų.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Tai garantuoja eksponentinį augimą.
        // Dvigubinimas negali būti perpildytas, nes `cap <= isize::MAX` ir `cap` tipas yra `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yra ne generinis, naudojant `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Šio metodo apribojimai yra beveik tokie patys, kaip ir " `grow_amortized`, tačiau šis metodas paprastai įgyvendinamas rečiau, todėl jis yra mažiau kritiškas.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Kadangi grąžiname `usize::MAX` talpą, kai tipo dydis yra
            // 0, čia patekimas būtinai reiškia, kad " `RawVec` yra perpildytas.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` yra ne generinis, naudojant `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ši funkcija yra už `RawVec` ribų, kad būtų sumažintas kompiliavimo laikas.Norėdami sužinoti daugiau, žiūrėkite komentarą aukščiau `RawVec::grow_amortized`.
// (`A` parametras nėra reikšmingas, nes skirtingų praktikoje matomų `A` tipų skaičius yra daug mažesnis nei `T` tipų.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Patikrinkite, ar čia nėra klaidos, kad sumažintumėte " `RawVec::grow_*` dydį.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Skirstytojas tikrina, ar lygybė lygi
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Išlaisvina atmintį, priklausančią " `RawVec`*, nebandant* išmesti jos turinio.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centrinė atsargų klaidų valdymo funkcija.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Turime garantuoti:
// * Mes niekada neskiriame `> isize::MAX` baito dydžio objektų.
// * Mes neperpildome `usize::MAX` ir iš tikrųjų skiriame per mažai.
//
// 64 bitų versijoje mums tiesiog reikia patikrinti, ar nėra perpildymo, nes bandyti paskirstyti `> isize::MAX` baitus tikrai nepavyks.
// Jei naudojamės platforma, kuri gali naudoti visus 4 GB vartotojo erdvėje, pvz., PAE arba x32, 32 bitų ir 16 bitų bituose turime tai papildyti.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Viena centrinė funkcija, atsakinga už pranešimų apie pajėgumų perpildymą.
// Tai užtikrins, kad su šiais " panics`susijusių kodų generavimas būtų minimalus, nes modulyje yra tik viena vieta, kurią " panics`, o ne krūva.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}