use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializacija trait naudojama Vec::from_iter
///
/// ## Delegacijos grafikas:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Dažnas atvejis yra vector perdavimas į funkciją, kuri nedelsiant vėl kaupiasi į vector.
        // Mes galime tai užtrumpinti, jei " IntoIter` nebuvo visiškai pažengęs.
        // Kai jis bus pažengęs, mes taip pat galime pakartotinai naudoti atmintį ir perkelti duomenis į priekį.
        // Bet mes tai darome tik tada, kai gautas " Vec`neturės daugiau nepanaudotų pajėgumų nei sukuriant juos naudojant bendrą " FromIterator` diegimą.
        //
        // Šis apribojimas nėra būtinas, nes Veco paskirstymo elgesys yra sąmoningai nenurodytas.
        // Bet tai konservatyvus pasirinkimas.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // turi perduoti spec_extend(), nes pats extend() deleguoja spec_from tuščioms Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Tai naudoja " `iterator.as_slice().to_vec()`, nes " spec_extend` turi atlikti daugiau veiksmų, kad galėtų apsvarstyti galutinį pajėgumą + ilgį ir taip atlikti daugiau darbo.
// `to_vec()` tiesiogiai paskirsto teisingą sumą ir tiksliai ją užpildo.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): naudojant cfg(test), būdingas `[T]::to_vec` metodas, reikalingas šiam metodo apibrėžimui, nėra.
    // Vietoj to naudokite " `slice::to_vec` funkciją, kuri yra prieinama tik su " cfg(test) NB`. Norėdami gauti daugiau informacijos, žr. " slice::hack modulį, pateiktą " slice.rs.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}