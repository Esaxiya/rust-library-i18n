use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specializacijos žymeklis, skirtas rinkti iteratoriaus vamzdyną į Vec, pakartotinai naudojant šaltinio paskirstymą, t
/// vykdant dujotiekį vietoje.
///
/// " SourceIter`pirminis " trait` yra būtinas, kad specializacijos funkcija galėtų pasiekti paskirstymą, kuris turi būti pakartotinai naudojamas.
/// Tačiau nepakanka, kad specializacija būtų galiojanti.
/// Žiūrėkite papildomas implanto ribas.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// " std`vidinį " SourceIter/InPlaceIterable traits` įgyvendina tik adapterio grandinės <Adapter<Adapter<IntoIter>>> (visi priklauso " core/std).
// Papildomos adapterio diegimo ribos (už `impl<I: Trait> Trait for Adapter<I>` ribų) priklauso tik nuo kitų traits, jau pažymėtų kaip specializacija traits (Kopija, TrustedRandomAccess, FusedIterator).
//
// I.e. žymeklis nepriklauso nuo vartotojo teikiamų tipų gyvenimo trukmės." Modulo the Copy` skylė, nuo kurios jau priklauso kelios kitos specializacijos.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Papildomi reikalavimai, kurių negalima išreikšti per trait bound.Vietoj to mes pasikliaujame " const eval`:
        // a) nėra ZST, nes nebūtų paskirta pakartotiniam naudojimui, o rodiklio aritmetika būtų panic b) dydis atitiktų, kaip reikalaujama pagal Alloc sutartį, c) sutapimai atitiktų, kaip reikalaujama Alloc sutartyje
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // grįžimas prie bendresnio įgyvendinimo
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // naudoti " try-fold` nuo
        // - tai geriau vektorizuoja kai kuriuos iteratoriaus adapterius
        // - skirtingai nei dauguma vidinių iteracijos metodų, tam reikia tik &mut savęs
        // - tai leidžia mums perrašyti žymeklį per jo vidų ir galų gale jį grąžinti
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // kartoti pavyko, nenuleisk galvos
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // patikrinkite, ar " SourceIter` sutartis buvo laikomasi įspėjimo: jei jų nebūtų, mes galime net nepasiekti šio taško
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // patikrinkite " InPlaceIterable` sutartį.Tai įmanoma tik tuo atveju, jei iteratorius apskritai išplėtojo šaltinio rodyklę.
        // Jei jis naudoja nepatikrintą prieigą per " TrustedRandomAccess`, šaltinio rodyklė liks pradinėje padėtyje ir negalėsime jos naudoti kaip nuorodos
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // numeskite visas likusias reikšmes šaltinio uodegoje, bet neleiskite nukristi pačiam paskirstymui, kai " IntoIter` išeis iš taikymo srities, jei lašas panics tada mes taip pat nutekėsime visus elementus, surinktus į dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // " InPlaceIterable`sutartis negali būti tiksliai patikrinta čia, nes " try_fold` turi išskirtinę nuorodą į šaltinio rodyklę, mes galime tik patikrinti, ar ji vis dar yra diapazone
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}