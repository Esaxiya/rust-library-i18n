//! " Unicode` eilutės griežinėliai.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` tipas yra vienas iš dviejų pagrindinių eilučių tipų, kitas yra `String`.
//! Skirtingai nei `String`, jo turinys yra skolinamas.
//!
//! # Pagrindinis naudojimas
//!
//! Pagrindinė `&str` tipo eilutės deklaracija:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Čia mes paskelbėme eilutės pažodį, dar vadinamą stygos gabalėliu.
//! Styginių literatų tarnavimo laikas yra statinis, o tai reiškia, kad garantuojama, kad eilutė `hello_world` galios visos programos metu.
//!
//! Mes taip pat galime aiškiai nurodyti " labas_pasaulio` gyvenimą:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Daugelis šio modulio naudojimo būdų naudojami tik bandymo konfigūracijoje.
// Švariau tiesiog išjungti nepanaudotą_importo įspėjimą, nei juos pašalinti.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str`, esantis `Concat<str>`, čia nėra prasmingas.
/// Šis trait tipo parametras egzistuoja tik norint įgalinti kitą impliką.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // žymiai greičiau užfiksuotos kilpos specializuojasi mažų separatorių ilgių dėkluose
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // savavališkas nulio dydžio atsarginis variantas
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Optimizuotas prisijungimo diegimas, tinkantis abiem Vec<T>(T: Kopija) ir String's vidinis vec Šiuo metu (2018-05-13) yra klaida su tipo išvada ir specializacija (žr. #36262 leidimą) Dėl šios priežasties " SliceConcat`<T>nėra specializuotas T: Copy ir SliceConcat<str>yra vienintelis šios funkcijos vartotojas.
// Jis paliekamas vietoje tam laikui, kai tai bus nustatyta.
//
// " String-join`ribos yra S: skolinkis<str>ir " Vec-join` pasiskolinkite <[T]> [T] ir str abu įveskite AsRef <[T]> kai kuriems T
// => s.borrow().as_ref() ir mes visada turime griežinėlių
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // pirmasis gabalas yra vienintelis be atskyriklio prieš jį
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // Apskaičiuokite tikslų sujungto Vec ilgį, jei `len` skaičiavimas perpildytas, mes panic mes vis tiek būtų pritrūkę atminties, o likusiai funkcijai reikalinga visa Vec saugumui iš anksto skirta
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // paruoškite neinicijuotą buferį
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kopijavimo skyriklis ir griežinėliai be jokių apribojimų, sukuria kilpas su sunkiai užkoduotais poslinkiais mažiems separatoriams.
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Keistas skolinimosi įgyvendinimas gali pateikti skirtingus ilgio apskaičiavimo ir faktinės kopijos gabalus.
        //
        // Įsitikinkite, kad skambintojui neatskleisime neinicijuotų baitų.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Styginių griežinėlių metodai.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>` paverčia `Box<[u8]>` be kopijavimo ir paskirstymo.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Visas šablono atitiktis pakeičia kita eilute.
    ///
    /// `replace` sukuria naują " [`String`] ir nukopijuoja duomenis iš šios eilutės skiltelės.
    /// Tai darydamas, jis bando rasti modelio atitikmenis.
    /// Jei rado, jis pakeičia juos pakeičiančia eilutės dalimi.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Kai modelis neatitinka:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Pirmus N modelio atitikmenis pakeičia kita eilutė.
    ///
    /// `replacen` sukuria naują " [`String`] ir nukopijuoja duomenis iš šios eilutės skiltelės.
    /// Tai darydamas, jis bando rasti modelio atitikmenis.
    /// Jei tokių randama, jis pakeičiamas eilutės dalimi daugiausia `count` kartų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Kai modelis neatitinka:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Tikiuosi sutrumpinti perskirstymo laiką
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Grąžina šios eilutės gabalo mažąją raidę kaip naują [`String`].
    ///
    /// 'Lowercase' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `Lowercase` sąlygas.
    ///
    /// Kai kurie simboliai, keisdami didžiąsias ir mažąsias raides, gali išsiplėsti į kelis simbolius, ši funkcija grąžina [`String`], užuot modifikavusi parametrą vietoje.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Keblus pavyzdys su sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // bet žodžio gale tai ς, o ne σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Kalbos be didžiųjų raidžių nekeičiamos:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ susieti su σ, išskyrus žodžio pabaigoje, kur jis susietas su ς.
                // Tai yra vienintelis sąlyginis " (contextual), bet nuo kalbos nepriklausomas atvaizdavimas " `SpecialCasing.txt`, todėl jį sunku užkoduoti, o ne turėti bendrą "condition" mechanizmą.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` apibrėžimui.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Grąžina šios eilutės pjūvio didžiųjų raidžių atitikmenį kaip naują [`String`].
    ///
    /// 'Uppercase' yra apibrėžtas pagal " Unicode` išvestinės pagrindinės nuosavybės `Uppercase` sąlygas.
    ///
    /// Kai kurie simboliai, keisdami didžiąsias ir mažąsias raides, gali išsiplėsti į kelis simbolius, ši funkcija grąžina [`String`], užuot modifikavusi parametrą vietoje.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Scenarijai be didžiųjų raidžių nekeičiami:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Vienas simbolis gali tapti keletu:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`] paverčia [`String`] be kopijavimo ir paskirstymo.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Sukuria naują [`String`], pakartodamas eilutę `n` kartus.
    ///
    /// # Panics
    ///
    /// Ši funkcija bus panic, jei pajėgumai perpildytų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic persipildžius:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Grąžina šios eilutės kopiją, kur kiekvienas simbolis susiejamas su jo atitikmeniu didžiosiomis raidėmis ASCII.
    ///
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje didinti vertę, naudokite [`make_ascii_uppercase`].
    ///
    /// Jei norite ne tik ASCII, bet ir ASCII simbolius, naudokite [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() išsaugo UTF-8 invariantą.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Grąžina šios eilutės kopiją, kur kiekvienas simbolis susietas su jo atitikmeniu mažosiomis ASCII raidėmis.
    ///
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje mažinti vertę, naudokite [`make_ascii_lowercase`].
    ///
    /// Jei norite ne tik ASCII, bet ir ASCII simbolius, naudokite [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() išsaugo UTF-8 invariantą.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Konvertuoja dėžutėje esančią baitų dalį į dėžutės eilutės skiltį, netikrindamas, ar eilutėje yra galiojantis UTF-8.
///
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}