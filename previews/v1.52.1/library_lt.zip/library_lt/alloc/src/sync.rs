#![stable(feature = "rust1", since = "1.0.0")]

//! Saugios siūlų skaičiavimo nuorodos.
//!
//! Norėdami gauti daugiau informacijos, žr. [`Arc<T>`][Arc] dokumentaciją.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Neįmanoma nustatyti nuorodų, kurios gali būti daromos su " `Arc`, kiekio.
///
/// Viršijus šią ribą, jūsų programa bus nutraukta (nors ir nebūtinai) pagal _exactly_ `MAX_REFCOUNT + 1` nuorodas.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// " ThreadSanitizer` nepalaiko atminties tvorų.
// Norėdami išvengti klaidingų teigiamų pranešimų įgyvendinant " Arc/Weak`, naudokite atomines apkrovas sinchronizavimui.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Saugus nuorodų skaičiavimo žymeklis.'Arc' reiškia " Atomical Reference Counted`.
///
/// `Arc<T>` tipas suteikia bendrą nuosavybės teisę į `T` tipo vertę, priskirtą kaupui.Pakvietus [`clone`][clone] sistemoje `Arc`, gaunamas naujas `Arc` egzempliorius, kuris nurodo tą patį krūvos paskirstymą kaip šaltinis `Arc`, tuo pačiu padidindamas atskaitos skaičių.
/// Kai sunaikinamas paskutinis tam tikro paskirstymo `Arc` žymeklis, tame paskirstyme saugoma vertė (dažnai vadinama "inner value") taip pat atsisakoma.
///
/// Bendros nuorodos programoje Rust neleidžia mutacijos pagal numatytuosius nustatymus, o `Arc` nėra išimtis: paprastai negalima gauti kintamos nuorodos į kažką, esantį `Arc`.Jei jums reikia mutuoti per `Arc`, naudokite [`Mutex`][mutex], [`RwLock`][rwlock] arba vieną iš [`Atomic`][atomic] tipų.
///
/// ## Siūlų sauga
///
/// Skirtingai nuo " [`Rc<T>`], " `Arc<T>` naudoja atomines operacijas savo atskaitos skaičiavimui.Tai reiškia, kad jis yra saugus siūlams.Trūkumas yra tas, kad atominės operacijos yra brangesnės nei įprastos atminties prieigos.Jei nesidalijate nuorodomis suskaičiuotais paskirstymais tarp gijų, apsvarstykite galimybę naudoti [`Rc<T>`] mažesnėms pridėtinėms sąnaudoms.
/// [`Rc<T>`] yra saugus numatytasis nustatymas, nes kompiliatorius užfiksuos visus bandymus siųsti [`Rc<T>`] tarp gijų.
/// Tačiau biblioteka gali pasirinkti " `Arc<T>`, kad bibliotekos vartotojams būtų suteikta daugiau lankstumo.
///
/// `Arc<T>` įgyvendins [`Send`] ir [`Sync`] tol, kol `T` įgyvendins [`Send`] ir [`Sync`].
/// Kodėl negalite į `Arc<T>` įdėti nesusijusio tipo `T`, kad jis būtų saugus siūlams?Iš pradžių tai gali būti šiek tiek priešinga: juk ar ne `Arc<T>` siūlų saugumas?Svarbiausia yra tai: " `Arc<T>` leidžia saugiai naudoti gijas tuo pačiu metu turėti kelias nuosavybės teises į tuos pačius duomenis, tačiau ji neprideda gijų saugumo savo duomenims.
///
/// Apsvarstykite " Arc <`[`RefCell<T>" ]" > `.
/// [`RefCell<T>`] nėra [`Sync`], o jei `Arc<T>` visada buvo [`Send`], " Arc <`[`RefCell<T>taip pat būtų.
/// Bet tada turėtume problemą:
/// [`RefCell<T>`] nėra saugus siūlams;ji seka skolinimosi skaičių naudodama ne atomines operacijas.
///
/// Galų gale tai reiškia, kad jums gali tekti susieti `Arc<T>` su kažkokiu [`std::sync`] tipu, paprastai [`Mutex<T>`][mutex].
///
/// ## Pertraukimo ciklai su " `Weak`
///
/// [`downgrade`][downgrade] metodas gali būti naudojamas kuriant neturintį [`Weak`] žymeklį.[`Weak`] rodyklę galima [" atnaujinti`][atnaujinti] d iki " `Arc`, tačiau tai grąžins [`None`], jei paskirstyme saugoma vertė jau bus atmesta.
/// Kitaip tariant, `Weak` žymekliai neišlaiko vertės paskirstymo viduje;tačiau jie * palaiko gyvą paskirstymą (vertės atsargą).
///
/// Ciklas tarp `Arc` žymeklių niekada nebus paskirstytas.
/// Dėl šios priežasties [`Weak`] naudojamas pertraukiant ciklus.Pavyzdžiui, medis gali turėti stiprius `Arc` rodiklius nuo tėvų mazgų iki vaikų, o [`Weak`] rodiklius nuo vaikų atgal iki tėvų.
///
/// # Klonavimo nuorodos
///
/// Naujos nuorodos sukūrimas iš esamo nuorodų suskaičiuoto žymiklio atliekamas naudojant `Clone` trait, įdiegtą [`Arc<T>`][Arc] ir [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Žemiau pateiktos dvi sintaksės yra lygiavertės.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b ir foo-tai visi lankai, nukreipiantys į tą pačią atminties vietą
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatiškai daromos išvados į `T` (per [`Deref`][deref] trait), todėl galite paskambinti `T` metodais pagal `Arc<T>` tipo vertę.Kad išvengtume vardų susidūrimo su " T` metodais, pats `Arc<T>` metodas yra susietos funkcijos, vadinamos naudojant [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Lankas<T>" traits`, pvz., " `Clone`, įdiegimus taip pat galima iškviesti naudojant visiškai kvalifikuotą sintaksę.
/// Kai kurie žmonės nori naudoti visiškai kvalifikuotą sintaksę, o kiti-metodo skambučio sintaksę.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metodo-skambučio sintaksė
/// let arc2 = arc.clone();
/// // Visiškai kvalifikuota sintaksė
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] automatiškai nenusileidžia `T`, nes vidinė vertė jau gali būti sumažinta.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Dalijimasis nekintamais duomenimis tarp gijų:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Atminkite, kad mes ** neatliekame šių testų.
// " windows statybininkai tampa labai nepatenkinti, jei gija pergyvena pagrindinę giją ir tada tuo pačiu metu išeina (kažkas užstringa), todėl mes tiesiog to visiškai išvengiame nevykdydami šių bandymų.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Dalijamasi kintamuoju [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Žr. [`rc` documentation][rc_examples], jei norite gauti daugiau pavyzdžių skaičiavimo pavyzdžių.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` yra " [`Arc`] versija, turinti neturinčią nuorodos į valdomą paskirstymą.
/// Paskyrimas pasiekiamas iškvietus [`upgrade`] žymeklį `Weak`, kuris grąžina [" Option`] " <` [" Arc`]`<T>> `.
///
/// Kadangi " `Weak` nuoroda į nuosavybės teisę neįskaičiuojama, tai netrukdys numesti paskirstyme saugomos vertės, o pats " `Weak` negarantuoja, kad vertė vis dar yra.
///
/// Taigi jis gali grąžinti [`None`], kai d.
/// Tačiau atkreipkite dėmesį, kad `Weak` nuoroda * neleidžia paskirstyti paties paskirstymo (pagrindinės saugyklos).
///
/// `Weak` žymeklis yra naudingas laikinai laikant nuorodą į paskirstymą, kurį valdo [`Arc`], netrukdant jo vidinei vertei numesti.
/// Jis taip pat naudojamas užkirsti kelią žiedinėms nuorodoms tarp [`Arc`] žymeklių, nes abipusės nuorodos niekada neleistų nė vieno [`Arc`] mesti.
/// Pavyzdžiui, medyje gali būti stiprios [`Arc`] žymekliai nuo tėvų mazgų iki vaikų, o vaikų `Weak` rodyklės atgal į tėvus.
///
/// Tipiškas `Weak` žymiklio gavimo būdas yra skambinimas į [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Tai yra " `NonNull`, leidžiantis optimizuoti šio tipo dydį, tačiau tai nebūtinai yra galiojantis rodyklė.
    //
    // `Weak::new` nustato tai kaip `usize::MAX`, kad nereikėtų skirti vietos kaupui.
    // Tai nėra vertė, kurią kada nors turės tikrasis rodyklė, nes " RcBox` turi bent 2 lygiavimą.
    // Tai įmanoma tik tada, kai `T: Sized`;nedidelis `T` niekada nekabina.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Tai apsaugo nuo repr(C) iki future nuo galimo lauko pertvarkymo, kuris trukdytų kitu atveju saugiam perdaromų vidinių tipų [into|from]_raw().
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX reikšmė yra laikinasis veiksnys, leidžiantis laikinai "locking" atnaujinti silpnus rodiklius arba pažeminti stiprius;tai naudojama norint išvengti lenktynių `make_mut` ir `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Sukonstruoja naują " `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Pradėkite silpnųjų rodyklių skaičių kaip 1, kuris yra silpnasis rodiklis, kurį turi visi stiprūs žymekliai (kinda), daugiau informacijos žr. std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Sukonstruoja naują " `Arc<T>`, naudodamas silpną nuorodą į save.
    /// Bandant atnaujinti silpną nuorodą prieš grąžinant šią funkciją, bus gaunama `None` reikšmė.
    /// Tačiau silpnoji etalonė gali būti laisvai klonuojama ir saugoma naudoti vėliau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Sukurkite vidinę būseną "uninitialized" su viena silpna nuoroda.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Svarbu neatsisakyti silpnosios žymeklio nuosavybės, kitaip atmintis gali būti atlaisvinta, kol grįš `data_fn`.
        // Jei tikrai norėtume perduoti nuosavybės teisę, galėtume sukurti papildomą silpną rodyklę sau, tačiau tai sukeltų papildomų silpnos atskaitos skaičiaus atnaujinimų, kurių kitu atveju gali būti nereikalinga.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Dabar mes galime tinkamai inicijuoti vidinę vertę ir savo silpną nuorodą paversti stipria nuoroda.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Pirmiau parašytas duomenų laukas turi būti matomas visoms gijoms, stebinčioms stiprų skaičių, kuris nėra nulis.
            // Todėl mums reikia mažiausiai "Release" užsakymo, kad galėtume sinchronizuoti su `compare_exchange_weak` sistemoje `Weak::upgrade`.
            //
            // "Acquire" užsakyti nereikia.
            // Svarstydami galimą " `data_fn` elgseną, turime tik atkreipti dėmesį į tai, ką jis galėtų padaryti, nurodydamas neatnaujinamą " `Weak`:
            //
            // - Jis gali *klonuoti*`Weak`, padidindamas silpną atskaitos skaičių.
            // - Jis gali mesti tuos klonus, sumažindamas silpną atskaitos skaičių (bet niekada iki nulio).
            //
            // Šie šalutiniai poveikiai mūsų niekaip nepaveikia, ir vien tik naudojant saugų kodą kiti šalutiniai poveikiai neįmanomi.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Stiprioms nuorodoms bendrai turėtų priklausyti bendra silpna nuoroda, todėl nenaudokite destruktoriaus pagal mūsų seną silpną nuorodą.
        //
        mem::forget(weak);
        strong
    }

    /// Sukonstruoja naują `Arc` su neinicijuotu turiniu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Sukonstruoja naują `Arc` su neinicijuotu turiniu, o atmintis užpildyta `0` baitais.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Sukonstruoja naują " `Pin<Arc<T>>`.
    /// Jei " `T` neįdiegia " `Unpin`, tada `data` bus prisegtas atmintyje ir negalės būti perkeltas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Sukuria naują " `Arc<T>` ir pateikia klaidą, jei nepavyksta paskirstyti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Pradėkite silpnųjų rodyklių skaičių kaip 1, kuris yra silpnasis rodiklis, kurį turi visi stiprūs žymekliai (kinda), daugiau informacijos žr. std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Sukuria naują " `Arc` su neinicijuotu turiniu ir pateikia klaidą, jei nepavyksta paskirstyti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Sukonstruoja naują `Arc` su neinicijuotu turiniu, o atmintis užpildyta `0` baitais, jei nepavyksta paskirstyti, pateikiant klaidą.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Pateikia vidinę vertę, jei " `Arc` turi tiksliai vieną tvirtą atskaitos tašką.
    ///
    /// Kitu atveju [`Err`] grąžinamas su tuo pačiu `Arc`, kuris buvo perduotas.
    ///
    ///
    /// Tai pavyks, net jei yra išskirtinių silpnų nuorodų.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Pateikite silpną žymeklį, kad išvalytumėte numanomą stiprią ir silpną nuorodą
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Sukuria naują atomų pagrindu suskaičiuotą pjūvį su neinicijuotu turiniu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Sukuria naują atomų pagrindu suskaičiuotą pjūvį su neinicijuotu turiniu, o atmintis užpildyta `0` baitais.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvertuojamas į `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Kaip ir " [`MaybeUninit::assume_init`] atveju, skambinantysis turi garantuoti, kad vidinė vertė iš tikrųjų yra inicializuota.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicializuotas, kyla neatidėliotinas elgesys.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvertuojamas į `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kaip ir " [`MaybeUninit::assume_init`] atveju, skambinantysis turi garantuoti, kad vidinė vertė iš tikrųjų yra inicializuota.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicializuotas, kyla neatidėliotinas elgesys.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Panaudoja " `Arc`, grąžindamas suvyniotą rodyklę.
    ///
    /// Norėdami išvengti atminties nutekėjimo, rodyklę reikia konvertuoti atgal į `Arc` naudojant [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pateikia neapdorotą duomenų rodyklę.
    ///
    /// Skaičiavimai jokiu būdu neturi įtakos ir `Arc` nevartojamas.
    /// Rodyklė galioja tol, kol " `Arc` yra stiprus skaičius.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SAUGUMAS: to negalima atlikti naudojant " Deref::deref arba " RcBoxPtr::inner, nes
        // to reikia norint išlaikyti raw/mut originalumą taip, kad pvz
        // `get_mut` gali rašyti per rodyklę po to, kai Rc yra atkurta per `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Sukuria `Arc<T>` iš neapdoroto žymeklio.
    ///
    /// Neapdorotas žymeklis turi būti anksčiau grąžintas skambučiu į [`Arc<U>::into_raw`][into_raw], kur `U` turi būti tokio pat dydžio ir lygiu kaip `T`.
    /// Tai trivialiai tiesa, jei `U` yra `T`.
    /// Atkreipkite dėmesį, kad jei " `U` nėra " `T`, tačiau jo dydis ir išlygiavimas yra vienodi, tai iš esmės panašu į skirtingų tipų nuorodų transmutavimą.
    /// Norėdami sužinoti daugiau, kokie apribojimai taikomi šiuo atveju, žr. [`mem::transmute`][transmute].
    ///
    /// " `from_raw` vartotojas turi įsitikinti, kad konkreti " `T` vertė yra numesta tik vieną kartą.
    ///
    /// Ši funkcija yra nesaugi, nes netinkamas naudojimas gali sukelti atminties nesaugumą, net jei niekada negrįšite į grąžintą `Arc<T>`.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertuokite atgal į `Arc`, kad išvengtumėte nuotėkio.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Kiti skambučiai į " `Arc::from_raw(x_ptr)` būtų nesaugūs atmintyje.
    /// }
    ///
    /// // Atmintis buvo atlaisvinta, kai " `x` nepateko į aukščiau nurodytą sritį, todėl " `x_ptr` dabar kabo!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Apverskite poslinkį, kad rastumėte originalų " ArcInner`.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Sukuria naują [`Weak`] žymeklį šiam paskirstymui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Tai " Relaxed` yra gerai, nes mes tikriname toliau pateiktą CAS vertę.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // patikrinkite, ar silpnas skaitiklis šiuo metu yra "locked";jei taip, suki.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: šiuo kodu nepaisoma perpildymo galimybės
            // į usize::MAX;apskritai tiek Rc, tiek Arc reikia koreguoti, kad būtų galima išspręsti perpildymą.
            //

            // Skirtingai nei naudojant " Clone(), mums reikia, kad tai būtų " Acquire` skaitymas, kad būtų galima sinchronizuoti su rašymu, gaunamu iš " `is_unique`, kad įvykiai iki šio rašymo įvyktų prieš šį skaitymą.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Įsitikinkite, kad nesukūrėme kabančios silpnosios
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Gauna [`Weak`] žymeklių skaičių šiam paskirstymui.
    ///
    /// # Safety
    ///
    /// Šis metodas savaime yra saugus, tačiau tinkamai jį naudojant reikia atsargiai.
    /// Kita gija gali bet kada pakeisti silpną skaičių, įskaitant galimybę tarp šio metodo iškvietimo ir veikimo pagal rezultatą.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Šis teiginys yra deterministinis, nes mes nepasidalinome `Arc` ar `Weak` tarp gijų.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Jei silpnas skaičius šiuo metu yra užrakintas, skaičiaus vertė buvo 0 prieš pat užrakinant.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Gauna stiprių (`Arc`) žymeklių skaičių šiam paskirstymui.
    ///
    /// # Safety
    ///
    /// Šis metodas savaime yra saugus, tačiau tinkamai jį naudojant reikia atsargiai.
    /// Kita gija gali bet kada pakeisti stiprų skaičių, įskaitant galimybę tarp šio metodo iškvietimo ir veikimo pagal rezultatą.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Šis teiginys yra deterministinis, nes mes nepasidalinome " `Arc` tarp gijų.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Vienu padidina " `Arc<T>`, susieto su pateiktu žymekliu, stiprų atskaitos skaičių.
    ///
    /// # Safety
    ///
    /// Žymeklis turi būti gautas per " `Arc::into_raw`, o susietas " `Arc` egzempliorius turi galioti (t. Y
    /// šio metodo metu stiprus skaičius turi būti bent 1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Šis teiginys yra deterministinis, nes mes nepasidalinome " `Arc` tarp gijų.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Išlaikykite " Arc`, bet nelieskite refcount, įvyniodami į " ManuallyDrop`
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Dabar padidinkite perskaičiavimą, bet taip pat nenumeskite naujo
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Sumažina `Arc<T>` stipraus atskaitos skaičių, susietą su pateiktu žymekliu, vienu.
    ///
    /// # Safety
    ///
    /// Žymeklis turi būti gautas per " `Arc::into_raw`, o susietas " `Arc` egzempliorius turi galioti (t. Y
    /// stiprus skaičius turi būti bent 1) taikant šį metodą.
    /// Šis metodas gali būti naudojamas norint išleisti galutinę " `Arc` ir pagrindinę saugyklą, tačiau **nereikėtų** iškviesti, kai bus išleista paskutinė " `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Šie teiginiai yra deterministiniai, nes mes nepasidalinome `Arc` tarp gijų.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Šis nesaugumas yra gerai, nes kol šis lankas gyvas, mes garantuojame, kad vidinis rodyklė galioja.
        // Be to, mes žinome, kad pati " `ArcInner` struktūra yra " `Sync`, nes vidiniai duomenys taip pat yra " `Sync`, todėl mes gerai skoliname nepakeičiamą rodyklę šiam turiniui.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Neįdėta `drop` dalis.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Šiuo metu sunaikinkite duomenis, net jei mes negalime atlaisvinti pačios dėžutės paskirstymo (vis tiek gali būti silpnų rodyklių).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Nusimeskite silpną nuorodą, kurią kartu turi visos stiprios nuorodos
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Grąžina `true`, jei du lankai rodo tą patį paskirstymą (venoje, panašioje į [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Paskiria " `ArcInner<T>`, kuriame yra pakankamai vietos galimai nedidelei vidinei vertei, jei vertės išdėstymas pateiktas.
    ///
    /// Funkcija `mem_to_arcinner` iškviečiama naudojant duomenų rodyklę ir turi grąžinti `ArcInner<T>` (galimai riebų) žymeklį.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Apskaičiuokite išdėstymą naudodami nurodytą vertės išdėstymą.
        // Anksčiau maketas buvo apskaičiuojamas pagal išraišką `&*(ptr as* const ArcInner<T>)`, tačiau tai sukūrė neteisingą nuorodą (žr. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Paskiria " `ArcInner<T>`, kuriame yra pakankamai vietos galimai nedidelei vidinei vertei, kur vertės pateikiamas išdėstymas, pateikiant klaidą, jei nepavyksta paskirstyti.
    ///
    ///
    /// Funkcija `mem_to_arcinner` iškviečiama naudojant duomenų rodyklę ir turi grąžinti `ArcInner<T>` (galimai riebų) žymeklį.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Apskaičiuokite išdėstymą naudodami nurodytą vertės išdėstymą.
        // Anksčiau maketas buvo apskaičiuojamas pagal išraišką `&*(ptr as* const ArcInner<T>)`, tačiau tai sukūrė neteisingą nuorodą (žr. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializuokite " ArcInner`
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Paskiria " `ArcInner<T>`, kuriame yra pakankamai vietos nedidelei vidinei vertei.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Paskirkite `ArcInner<T>` naudodami nurodytą vertę.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nukopijuokite vertę kaip baitus
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Nemokamai paskirstykite neišmesdami jo turinio
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Paskiria nurodyto ilgio `ArcInner<[T]>`.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Nukopijuokite elementus iš griežinėlio į naujai paskirtą lanką <\[T\]>
    ///
    /// Nesaugu, nes skambinantysis turi perimti nuosavybės teisę arba susieti " `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Sukuria `Arc<[T]>` iš iteratoriaus, kuris, kaip žinoma, yra tam tikro dydžio.
    ///
    /// Jei netinkamas dydis, elgesys nėra apibrėžtas.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic apsauga klonuojant T elementus.
        // " panic`atveju elementai, kurie buvo įrašyti į naująjį " ArcInner`, bus išmesti, o tada atlaisvės atmintis.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pirmojo elemento žymeklis
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Viskas aišku.Pamirškite apsaugą, kad ji neatlaisvintų naujojo " ArcInner`.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializacija trait naudojama `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Padaro `Arc` žymeklio kloną.
    ///
    /// Tai sukuria kitą to paties paskirstymo rodyklę, padidindama stiprų atskaitos skaičių.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Naudoti atpalaiduotą užsakymą čia yra gerai, nes pradinės nuorodos žinojimas neleidžia kitoms gijoms klaidingai ištrinti objekto.
        //
        // Kaip paaiškinta " [Boost documentation][1], atskaitos skaitiklio padidinimą visada galima atlikti naudojant " memory_order_relaxed`: naujas nuorodas į objektą galima suformuoti tik iš esamos nuorodos, o perduodant esamą nuorodą iš vienos gijos kitai, jau turi būti užtikrintas reikalingas sinchronizavimas.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Tačiau mes turime apsisaugoti nuo didelių perskaičiavimų, jei kas nors pamirštų lankus.
        // Jei to nepadarysime, skaičius gali būti perpildytas ir vartotojai naudosis nemokamai.
        // Mes labai prisotiname iki `isize::MAX` darant prielaidą, kad nėra ~2 milijardo gijų, padidinančių atskaitos skaičių vienu metu.
        //
        // Šis " branch` niekada nebus naudojamas jokioje realistinėje programoje.
        //
        // Mes nutraukiame, nes tokia programa yra nepaprastai išsigimusi, ir mums nerūpi ją palaikyti.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Pateikia kintamą nuorodą į nurodytą `Arc`.
    ///
    /// Jei yra kitų to paties paskirstymo `Arc` arba [`Weak`] žymeklių, tada `make_mut` sukurs naują paskirstymą ir vidinei vertei pakvies [`clone`][clone], kad būtų užtikrinta unikali nuosavybės teisė.
    /// Tai taip pat vadinama klonu rašant.
    ///
    /// Atkreipkite dėmesį, kad tai skiriasi nuo " [`Rc::make_mut`] elgesio, kuris atsieja visus likusius " `Weak` rodykles.
    ///
    /// Taip pat žiūrėkite " [`get_mut`][get_mut], kuris žlugs, o ne klonuos.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nieko neklonuos
    /// let mut other_data = Arc::clone(&data); // Neklonuos vidinių duomenų
    /// *Arc::make_mut(&mut data) += 1;         // Klonuoja vidinius duomenis
    /// *Arc::make_mut(&mut data) += 1;         // Nieko neklonuos
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nieko neklonuos
    ///
    /// // Dabar " `data` ir " `other_data` nurodo skirtingus paskirstymus.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Atkreipkite dėmesį, kad mes turime ir stiprią, ir silpną nuorodą.
        // Taigi, atleidus tik mūsų tvirtą nuorodą, savaime atmintis nebus išskaidyta.
        //
        // Norėdami įsitikinti, kad matome bet kokius įrašus į `weak`, įvykusius prieš leidimo rašymą (ty mažinimus) į `strong`, naudokite " Acquire`.
        // Kadangi mūsų skaičius yra menkas, nėra tikimybės, kad pačią " ArcInner` būtų galima paskirstyti.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Yra dar vienas tvirtas rodiklis, todėl turime klonuoti.
            // Iš anksto paskirstykite atmintį, kad būtų galima tiesiogiai įrašyti klonuotą vertę.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Atsipalaidavusiam pakanka to, kas išdėstyta pirmiau, nes tai iš esmės yra optimizavimas: mes visada lenktyniaujame mesti silpnus rodiklius.
            // Blogiausiu atveju mes be reikalo paskiriame naują lanką.
            //

            // Pašalinome paskutinę stiprią nuorodą, tačiau liko papildomų silpnų nuorodų.
            // Perkelsime turinį į naują lanką ir padarysime negaliojančius kitus silpnus nuorodas.
            //

            // Atkreipkite dėmesį, kad nuskaityti `weak` neįmanoma gauti usize::MAX (ty užrakinti), nes silpną skaičių galima užfiksuoti tik gija su stipria nuoroda.
            //
            //

            // Realizuokite savo numanomą silpną žymeklį, kad prireikus jis galėtų išvalyti " ArcInner`.
            //
            let _weak = Weak { ptr: this.ptr };

            // Gali tiesiog pavogti duomenis, belieka tik " Weaks`
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Mes buvome vienintelė bet kurios rūšies nuoroda;sugrįžti atgal į stiprių ref skaičių.
            //
            this.inner().strong.store(1, Release);
        }

        // Kaip ir " `get_mut()` atveju, nesaugumas yra tinkamas, nes mūsų nuoroda buvo unikali pradžioje arba tapo tokia klonuojant turinį.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Pateikia kintamą nuorodą į nurodytą `Arc`, jei nėra kitų to paties paskirstymo `Arc` arba [`Weak`] rodyklių.
    ///
    ///
    /// Priešingu atveju pateikia [`None`], nes nėra saugu mutuoti bendrą vertę.
    ///
    /// Taip pat žiūrėkite [`make_mut`][make_mut], kuris [`clone`][clone] vidinę vertę, kai yra kitų rodyklių.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Šis nesaugumas yra tinkamas, nes mes garantuojame, kad grąžintas žymeklis yra vienintelis * rodiklis, kuris kada nors bus grąžintas T.
            // Šiuo metu garantuojama, kad mūsų atskaitos skaičius bus 1, ir mes reikalaujame, kad pats lankas būtų `mut`, todėl grąžiname vienintelę įmanomą nuorodą į vidinius duomenis.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Pateikia kintamą nuorodą į nurodytą `Arc`, be jokio patikrinimo.
    ///
    /// Taip pat žiūrėkite " [`get_mut`], kuris yra saugus ir atlieka atitinkamus patikrinimus.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Grąžinamos paskolos trukmės laikotarpiu negalima daryti jokios kitos nuorodos į `Arc` arba [`Weak`] į tą patį paskirstymą.
    ///
    /// Tai yra nereikšmingai, jei tokių rodyklių nėra, pavyzdžiui, iškart po `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mes stengiamės *nekurti* nuorodos, apimančios "count" laukus, nes tai būtų slapyvardis, tuo pat metu turint prieigą prie nuorodų skaičiaus (pvz.,
        // iki `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Nustatykite, ar tai yra unikali nuoroda (įskaitant silpnus nuorodas) į pagrindinius duomenis.
    ///
    ///
    /// Atkreipkite dėmesį, kad tam reikia užfiksuoti silpnosios nuorodos skaičių.
    fn is_unique(&mut self) -> bool {
        // užblokuokite silpnųjų rodyklių skaičių, jei atrodo, kad esame vienintelis silpnosios žymeklio turėtojas.
        //
        // Čia įsigijimo etiketė užtikrina santykį su įvykiais prieš bet kokius įrašus į `strong` (ypač `Weak::upgrade`) prieš `weak` skaičiaus sumažėjimą (per `Weak::drop`, kuris naudoja leidimą).
        // Jei atnaujinta silpna nuoroda niekada nebuvo numesta, CAS čia nepavyks, todėl mums nerūpi sinchronizuoti.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Tai turi būti " `Acquire`, kad būtų galima sinchronizuoti su " `drop` skaitiklio mažinimu sistemoje " `drop`-vienintelė prieiga, kuri įvyksta, kai atmetama bet kuri nuoroda, išskyrus paskutinę.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Leidinio rašymas čia sinchronizuojamas su skaitymu `downgrade`, veiksmingai užkertant kelią pirmiau pateiktam `strong` skaitymui po rašymo.
            //
            //
            self.inner().weak.store(1, Release); // atleiskite spyną
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Nuleidžia " `Arc`.
    ///
    /// Tai sumažins stiprų atskaitos skaičių.
    /// Jei stipraus atskaitos skaičius pasiekia nulį, vienintelės kitos nuorodos (jei yra) yra [`Weak`], taigi mes vidinę vertę `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nieko nespausdina
    /// drop(foo2);   // Spausdina "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Kadangi " `fetch_sub` jau yra atominis, mums nereikia sinchronizuoti su kitomis gijomis, nebent ketiname ištrinti objektą.
        // Ta pati logika taikoma žemiau esančiam `fetch_sub` skaičiui `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ši tvora reikalinga siekiant išvengti duomenų naudojimo pertvarkymo ir duomenų ištrynimo.
        // Kadangi jis pažymėtas `Release`, atskaitos skaičiaus mažėjimas sinchronizuojamas su šia `Acquire` tvora.
        // Tai reiškia, kad duomenys naudojami prieš sumažinant atskaitos skaičių, kuris vyksta prieš šią tvorą, kuri įvyksta prieš ištrinant duomenis.
        //
        // Kaip paaiškinta [Boost documentation][1],
        //
        // > Svarbu užtikrinti bet kokią galimą prieigą prie objekto viename
        // > gija (per esamą nuorodą)*įvykti prieš* ištrinant
        // > objektas kitoje gijoje.Tai pasiekiama naudojant " "release"
        // > operacija numetus nuorodą (bet kokia prieiga prie objekto
        // > per šią nuorodą akivaizdžiai turi įvykti anksčiau), ir
        // > "acquire" operaciją prieš ištrinant objektą.
        //
        // Visų pirma, nors " Arc`turinys paprastai yra nekintamas, įmanoma, kad interjeras rašytų kažką panašaus į " Mutex`<T>.
        // Kadangi " Mutex`nėra įgyjamas ištrynus, negalime pasikliauti jo sinchronizavimo logika, kad rašymas " A` temoje būtų matomas naikintojui, veikiančiam B gijoje.
        //
        //
        // Taip pat atkreipkite dėmesį, kad " Acquire`tvorą čia tikriausiai būtų galima pakeisti " Acquire` apkrova, o tai galėtų pagerinti našumą labai ginčytose situacijose.Žr. " [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Bandykite `Arc<dyn Any + Send + Sync>` sumažinti iki konkretaus tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Sukonstruoja naują " `Weak<T>`, nepriskirdamas jokios atminties.
    /// Paskambinus į [`upgrade`] pagal grąžinimo vertę, visada gaunama [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Pagalbininko tipas, leidžiantis pasiekti nuorodų skaičių, nedarant jokių teiginių apie duomenų lauką.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Grąžina neapdorotą žymeklį objektui `T`, kurį nurodo šis `Weak<T>`.
    ///
    /// Rodyklė galioja tik tuo atveju, jei yra stiprių nuorodų.
    /// Rodyklė gali būti kabanti, nesuderinta ar net [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Abu rodo į tą patį objektą
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Stiprieji čia palaiko jį gyvą, todėl vis tiek galime prieiti prie objekto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Bet ne daugiau.
    /// // Galime atlikti " weak.as_ptr(), bet prieiga prie žymiklio lemtų neapibrėžtą elgesį.
    /// // assert_eq! ("labas", nesaugus {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Jei rodyklė kabo, mes tiesiogiai grąžiname kontrolinį.
            // Tai negali būti galiojantis naudingosios apkrovos adresas, nes naudingoji apkrova yra bent jau lygiavertė kaip " ArcInner (usize).
            ptr as *const T
        } else {
            // SAUGUMAS: jei " is_dangling` pateikia klaidingą reikšmę, žymeklį galima išskaičiuoti.
            // Šiuo metu naudingoji apkrova gali būti sumažinta, ir mes turime išlaikyti kilmę, todėl naudokite neapdorotų rodyklių manipuliavimą.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Suvartoja " `Weak<T>` ir paverčia jį neapdorotu žymekliu.
    ///
    /// Tai paverčia silpną rodyklę į neapdorotą rodyklę, tuo pačiu išsaugant vienos silpnosios nuorodos nuosavybės teisę (silpnosios vertės ši operacija nekeičia).
    /// Jį galima vėl paversti " `Weak<T>` su " [`from_raw`].
    ///
    /// Taikomi tie patys apribojimai, kaip pasiekti žymeklio taikinį, kaip ir naudojant [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Anksčiau [`into_raw`] sukurtą neapdorotą žymeklį paverčia atgal į `Weak<T>`.
    ///
    /// Tai gali būti naudojama norint saugiai gauti tvirtą nuorodą (paskambinus vėliau į [`upgrade`]) arba išspręsti silpną skaičių numetant " `Weak<T>`.
    ///
    /// Jis turi vienos silpnos nuorodos nuosavybę (išskyrus [`new`] sukurtus rodiklius, nes jiems nieko nepriklauso; metodas vis tiek veikia su jais).
    ///
    /// # Safety
    ///
    /// Rodyklė turi būti kilusi iš " [`into_raw`] ir vis tiek turi turėti galimą silpną atskaitos tašką.
    ///
    /// Šį skambinant leidžiama, kad stiprus skaičius būtų 0.
    /// Nepaisant to, tam priklauso viena silpna nuoroda, kuri šiuo metu pateikiama kaip neapdorotas rodyklė (silpnas skaičius šios operacijos nekeičia), todėl ją reikia susieti su ankstesniu skambučiu į [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Sumažinti paskutinį silpną skaičių.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Norėdami sužinoti įvesties žymeklį, žr. Weak::as_ptr.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tai kabantys Silpni.
            ptr as *mut ArcInner<T>
        } else {
            // Priešingu atveju mes garantuojame, kad rodyklė buvo iš niekuo neišsiskiriančio Silpno.
            // SAUGUMAS: " data_offset` yra saugu skambinti, nes ptr nurodo tikrąjį (potencialiai nukritusį) T.
            let offset = unsafe { data_offset(ptr) };
            // Taigi mes pakeičiame poslinkį, kad gautume visą RcBox.
            // SAUGUMAS: rodyklė atsirado iš silpno, todėl šis poslinkis yra saugus.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAUGUMAS: mes dabar atkūrėme pradinį silpnojo žymeklio rodiklį, todėl galime sukurti silpnąjį.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Bandoma atnaujinti " `Weak` žymeklį į " [`Arc`], pavėlavus vidinės vertės sumažėjimą, jei pavyks.
    ///
    ///
    /// Pateikia [`None`], jei vidinė vertė nuo to laiko buvo sumažinta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Sunaikink visus stiprius patarimus.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Mes naudojame CAS kilpą, kad padidintume stiprų skaičių, o ne " fetch_add`, nes ši funkcija niekada neturėtų imtis atskaitos skaičiaus nuo nulio iki vieno.
        //
        //
        let inner = self.inner()?;

        // Palengvinta apkrova, nes bet koks 0 užrašymas, kurį galime stebėti, palieka lauką nuolat nulinės būsenos (taigi "stale" rodmuo 0 yra tinkamas), o bet kuri kita reikšmė patvirtinama per toliau pateiktą CAS.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Peržiūrėkite `Arc::clone` komentarus, kodėl tai darome (`mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Atsipalaidavęs yra nesėkmės atvejis, nes mes neturime jokių lūkesčių dėl naujos valstybės.
            // Įsigyti reikia, kad sėkmės atvejis būtų sinchronizuotas su " `Arc::new_cyclic`, kai vidinę vertę galima inicijuoti jau sukūrus " `Weak` nuorodas.
            // Tokiu atveju tikimės stebėti visiškai pradinę vertę.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null patikrinta aukščiau
                Err(old) => n = old,
            }
        }
    }

    /// Gauna stiprių (`Arc`) žymeklių, nukreipiančių į šį paskirstymą, skaičių.
    ///
    /// Jei `self` buvo sukurtas naudojant [`Weak::new`], tai grąžins 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Gauna apytikslį `Weak` žymeklių, nukreipiančių į šį paskirstymą, skaičių.
    ///
    /// Jei `self` buvo sukurtas naudojant [`Weak::new`], arba jei nėra likusių stiprių rodyklių, tai grąžins 0.
    ///
    /// # Accuracy
    ///
    /// Atsižvelgiant į išsamią įgyvendinimo informaciją, grąžinama vertė gali būti išjungta 1 į abi puses, kai kitos gijos manipuliuoja bet kokiais " lankais`arba " silpnaisiais`, nukreipiančiais į tą patį paskirstymą.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Kadangi pastebėjome, kad perskaičius silpną skaičių buvo bent vienas stiprus rodiklis, žinome, kad numanoma silpna nuoroda (esanti, kai tik yra stiprių nuorodų) vis dar buvo, kai stebėjome silpną skaičių, todėl galime ją saugiai atimti.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Pateikia `None`, kai rodyklė kabo ir nėra paskirto `ArcInner` (ty kai `Weak` sukūrė `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mes stengiamės *nekurti* nuorodos, apimančios lauką "data", nes laukas gali būti mutuojamas vienu metu (pvz., Jei metamas paskutinis " `Arc`, duomenų laukas bus atmestas vietoje).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Grąžina `true`, jei abu silpnieji nurodo tą patį paskirstymą (panašų į [`ptr::eq`]), arba jei abu nerodo jokio paskirstymo (nes jie buvo sukurti naudojant `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kadangi tai lygina rodykles, tai reiškia, kad " `Weak::new()` prilygs vienas kitam, nors jie ir nerodo jokio paskirstymo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Lyginant `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Sukuria `Weak` žymeklio kloną, kuris nurodo tą patį paskirstymą.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Peržiūrėkite Arc::clone() komentarus, kodėl tai yra atsipalaidavę.
        // Tai gali naudoti " fetch_add` (nepaisydami užrakto), nes silpnas skaičius užrakintas tik ten, kur *nėra kitų* silpnų rodyklių.
        //
        // (Taigi tokiu atveju negalime paleisti šio kodo).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Peržiūrėkite Arc::clone() komentarus, kodėl tai darome (mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Sukuria naują " `Weak<T>`, nepriskirdamas atminties.
    /// Paskambinus į [`upgrade`] pagal grąžinimo vertę, visada gaunama [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Numeta `Weak` žymeklį.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nieko nespausdina
    /// drop(foo);        // Spausdina "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Jei sužinosime, kad buvome paskutinis silpnas rodiklis, tada laikas visiškai paskirstyti duomenis.Žr. Diskusiją " Arc::drop() apie atminties tvarką
        //
        // Čia nebūtina tikrinti, ar užrakinta būsena, nes silpną skaičių galima užfiksuoti tik tuo atveju, jei buvo tiksliai vienas silpnas ref. Tai reiškia, kad lašas vėliau galėjo įsijungti tik likusį silpną ref.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ši specializacija atliekama čia, o ne kaip bendresnis " `&T` optimizavimas, nes kitaip padidėtų išlaidos visiems lygybės patikrinimams.
/// Manome, kad " Arc` yra naudojami kaupti dideles vertes, kurios lėtai klonuojamos, tačiau taip pat sunkiai tikrinamos lygybės, todėl šios išlaidos lengviau atsipirks.
///
/// Taip pat labiau tikėtina, kad bus du `Arc` klonai, kurie nurodo tą pačią vertę, nei du " &T`.
///
/// Tai galime padaryti tik tada, kai " `T: Eq` kaip " `PartialEq` gali būti sąmoningai neatspindintis.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Dviejų " Arc` lygybė.
    ///
    /// Du " lankai` yra lygūs, jei jų vidinės vertės yra vienodos, net jei jos saugomos skirtinguose paskirstymuose.
    ///
    /// Jei `T` taip pat įgyvendina `Eq` (tai reiškia lygybės atspindį), du " Arc` taškai, nukreipiantys į tą patį paskirstymą, visada yra lygūs.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Dviejų " lankų` nelygybė.
    ///
    /// Du " lankai` yra nevienodi, jei jų vidinės vertybės yra nevienodos.
    ///
    /// Jei `T` taip pat įgyvendina `Eq` (tai reiškia lygybės refleksyvumą), du " Arc`, nukreipiantys į tą pačią vertę, niekada nėra nelygūs.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Dalinis dviejų " Arc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `partial_cmp()` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mažiau nei dviejų " Arc` palyginimų.
    ///
    /// Abu jie lyginami skambinant `<` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Dviejų " lankų`palyginimas " mažesnis arba lygus`.
    ///
    /// Abu jie lyginami skambinant `<=` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Didesnis nei dviejų " Arc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `>` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Dviejų " Arc`lyginimas " didesnis arba lygus`.
    ///
    /// Abu jie lyginami skambinant `>=` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Dviejų " Arc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `cmp()` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Sukuria naują `Arc<T>` su `Default` reikšme `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Paskirkite nuorodą suskaičiuotą gabalėlį ir užpildykite jį klonuodami " v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Paskirkite suskaičiuotą `str` ir nukopijuokite į jį `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Paskirkite suskaičiuotą `str` ir nukopijuokite į jį `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Perkelkite langelyje esantį objektą į naują, pagal nuorodą suskaičiuotą paskirstymą.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Paskirkite suskaičiuotą griežinėlį ir perkelkite į jį " v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Leiskite " Vec` atlaisvinti atmintį, bet nesunaikinkite jos turinio
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Paima kiekvieną `Iterator` elementą ir surenka jį į `Arc<[T]>`.
    ///
    /// # Eksploatacinės charakteristikos
    ///
    /// ## Bendras atvejis
    ///
    /// Paprastai rinkimas į `Arc<[T]>` atliekamas pirmiausia surenkant į `Vec<T>`.Tai yra, kai rašote:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tai elgiasi taip, lyg mes parašytume:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Čia įvyksta pirmasis paskirstymų rinkinys.
    ///     .into(); // Čia įvyksta antrasis " `Arc<[T]>` paskirstymas.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tai paskirs tiek kartų, kiek reikia `Vec<T>` sukūrimui, ir paskirs vieną kartą, kad `Vec<T>` paverstų `Arc<[T]>`.
    ///
    ///
    /// ## Žinomo ilgio iteratoriai
    ///
    /// Kai jūsų " `Iterator` įdiegia " `TrustedLen` ir yra tikslaus dydžio, " `Arc<[T]>` bus skirtas vienas paskirstymas.Pavyzdžiui:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Čia įvyksta tik vienas paskirstymas.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializacija trait naudojama rinkti į `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Tai pasakytina apie " `TrustedLen` iteratorių.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAUGA: Turime užtikrinti, kad iteratorius turi tikslų ilgį ir mes.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Grįžkite prie įprasto įgyvendinimo.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Gauti poslinkį per `ArcInner` už naudingąją apkrovą už rodyklės.
///
/// # Safety
///
/// Žymeklis turi nukreipti į anksčiau galiojantį T egzempliorių (ir turėti galiojančius jų metaduomenis), tačiau T leidžiama atsisakyti.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sulygiuokite nedideli dydį iki " ArcInner` pabaigos.
    // Kadangi " RcBox` yra repr(C), jis visada bus paskutinis atminties laukas.
    // SAUGA: kadangi vieninteliai galimi nedideli tipai yra skiltelės, trait objektai,
    // ir išorinių tipų, įvesties saugos reikalavimas šiuo metu yra pakankamas, kad būtų patenkinti align_of_val_raw reikalavimai;tai yra kalbos, kuria negalima remtis už std ribų, įgyvendinimo detalės.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}