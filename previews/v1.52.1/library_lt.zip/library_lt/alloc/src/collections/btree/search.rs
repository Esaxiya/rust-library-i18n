use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Viskas, ko reikia ieškoti, kaip ir " `Bound::Included(T)`.
    Included(T),
    /// Išskirtinis privalomas ieškoti, kaip ir " `Bound::Excluded(T)`.
    Excluded(T),
    /// Besąlygiškas įtraukiantis įrišimas, kaip ir " `Bound::Unbounded`.
    AllIncluded,
    /// Besąlygiškas išimtinis įpareigojimas.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Rekursyviai ieško nurodyto rakto mazgo vedamame (po) medyje.
    /// Pateikia `Found` su atitinkančios KV rankena, jei tokia yra.
    /// Kitu atveju grąžina `GoDown` su lapo edge rankena, kuriai priklauso raktas.
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra surūšiuotas pagal raktą, kaip yra medis `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Nusileidžia iki artimiausio mazgo, kur edge, atitinkantis apatinę diapazono ribą, skiriasi nuo edge, atitinkančio viršutinę ribą, ty artimiausią mazgą, kurio diapazone yra bent vienas raktas.
    ///
    ///
    /// Jei bus rastas, grąžins `Ok` su tuo mazgu, jame esanti edge indeksų pora atribos diapazoną ir atitinkamą ribų porą, kad būtų tęsiama paieška antriniuose mazguose, jei mazgas yra vidinis.
    ///
    /// Jei nerandama, grąžina `Err`, kurio lapas edge atitinka visą diapazoną.
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra išdėstytas pagal raktą.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Reikėtų vengti šių kintamųjų išdėstymo.
        // Manome, kad " `range` nurodytos ribos išlieka tos pačios, tačiau rungimosi principas gali pasikeisti tarp skambučių " (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Mazge suranda edge, apibrėžiančią apatinę diapazono ribą.
    /// Taip pat grąžina apatinę ribą, kuri bus naudojama tęsti paiešką atitinkamame antriniame mazge, jei `self` yra vidinis mazgas.
    ///
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra išdėstytas pagal raktą.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// `find_lower_bound_edge` klonas viršutinei ribai.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Ieško duoto rakto mazge be rekurso.
    /// Pateikia `Found` su atitinkančios KV rankena, jei tokia yra.
    /// Kitu atveju grąžina `GoDown` su edge rankena, kur raktą galima rasti (jei mazgas yra vidinis) arba kur raktą galima įdėti.
    ///
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra surūšiuotas pagal raktą, kaip yra medis `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Grąžina arba KV indeksą mazge, kuriame yra raktas (arba jo atitikmuo), arba edge indeksą, kuriam priklauso raktas.
    ///
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra surūšiuotas pagal raktą, kaip yra medis `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Mazge randa edge indeksą, apibrėžiantį apatinę diapazono ribą.
    /// Taip pat grąžina apatinę ribą, kuri bus naudojama tęsti paiešką atitinkamame antriniame mazge, jei `self` yra vidinis mazgas.
    ///
    ///
    /// Rezultatas yra prasmingas tik tuo atveju, jei medis yra išdėstytas pagal raktą.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// `find_lower_bound_index` klonas viršutinei ribai.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}