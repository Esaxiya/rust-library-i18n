use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Susijungia su broliu ar pavogia iš jo galimą nepilną mazgą.
    /// Jei tai pavyksta, bet pagrindinio mazgo susitraukimo kaina, grąžina tą susitraukusį pagrindinį mazgą.
    /// Pateikia `Err`, jei mazgas yra tuščias šaknis.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Sandėliuoja galimai nepakankamą mazgą ir, jei dėl to jo pirminis mazgas susitraukia, jis kaupiamas rekursyviai.
    /// Pateikia `true`, jei sutvarkė medį, `false`, jei nepavyko, nes šaknies mazgas tapo tuščias.
    ///
    /// Šis metodas nesitiki, kad įeinant protėviai jau bus nepakankami, o panics, jei jis susiduria su tuščiu protėviu.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Pašalina tuščius lygius viršuje, bet palieka tuščią lapą, jei visas medis tuščias.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Susikaupia arba sujungia visus nepilnus mazgus, esančius dešinėje medžio sienoje.
    /// Kiti mazgai, tie, kurie nėra šaknis ar dešinysis edge, jau turi turėti bent MIN_LEN elementus.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Simetrinis `fix_right_border` klonas.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Sandėliuokite visus nepilnus mazgus dešinėje medžio sienoje.
    /// Kiti mazgai, tie, kurie nėra šaknis ar dešinysis edge, turi būti pasirengę pavogti iki MIN_LEN elementų.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Patikrinkite, ar dešinysis vaikas nėra pilnavertis.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Mums reikia vogti.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Eik toliau.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Susikuria kairįjį vaiką, darant prielaidą, kad dešinysis vaikas nėra pilnavertis, ir numato papildomą elementą, leidžiantį savo vaikus sulieti paeiliui ir netapti nepilnaverčiu.
    ///
    /// Grąžina kairįjį vaiką.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` kad nebūtų suderinta, jei susijungimas įvyktų kitame lygyje.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Susikuria dešinįjį vaiką, darant prielaidą, kad kairysis vaikas nėra pilnavertis, ir numato papildomą elementą, leidžiantį savo vaikus sulieti paeiliui ir netapti nepilnaverčiu.
    ///
    /// Grįžta visur, kur tik atsidūrė tinkamas vaikas.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` kad nebūtų suderinta, jei susijungimas įvyktų kitame lygyje.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}