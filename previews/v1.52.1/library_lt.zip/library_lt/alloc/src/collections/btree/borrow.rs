use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modeliuoja tam tikros unikalios nuorodos pakartotinį panaudojimą, kai žinote, kad paskolos kreditas ir visi jo palikuonys (ty visi iš jo gautos nuorodos ir nuorodos) tam tikru metu nebus naudojami, po to vėl norėsite naudoti originalią nuorodą. .
///
///
/// Skolų tikrintuvas paprastai tvarko šį paskolų kaupimą už jus, tačiau kai kurie valdymo srautai, atliekantys šį kaupimą, yra per sudėtingi, kad kompiliatorius galėtų sekti.
/// " `DormantMutRef` leidžia jums patiems patikrinti skolinimąsi, tuo pačiu išreiškiant jo sudėtį, ir neapibūdinant neapibrėžto elgesio sukomponuoti neapdoroto žymeklio kodą, reikalingą tai padaryti.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Užfiksuokite unikalią paskolą ir nedelsdami ją skolinkite.
    /// Kompiliatoriui naujos nuorodos galiojimo laikas yra toks pat, kaip ir pradinės nuorodos, tačiau jūs žadate ją naudoti trumpiau.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SAUGUMAS: mes skolinamės per " `_marker` ir atidengiame
        // tik ši nuoroda, todėl ji yra unikali.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Grįžkite prie unikalios skolos, iš pradžių paimtos.
    ///
    /// # Safety
    ///
    /// Skolinimas turi būti pasibaigęs, ty nuorodos, kurią grąžino `new`, ir visų iš jos gautų nuorodų bei nuorodų, nebegalima naudoti.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SAUGUMAS: mūsų pačių saugos sąlygos reiškia, kad ši nuoroda yra unikali.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;