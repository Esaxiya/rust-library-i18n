// Tai bandymas įgyvendinti idealą
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Kadangi Rust iš tikrųjų neturi priklausomų tipų ir polimorfinės rekursijos, mes susiduriame su daugybe nesaugumo.
//

// Pagrindinis šio modulio tikslas yra išvengti sudėtingumo, laikant medį kaip bendrą (jei keistos formos) konteinerį ir vengiant susidoroti su dauguma B medžio invariantų.
//
// Šis modulis nesvarbu, ar įrašai yra rūšiuojami, kurie mazgai gali būti nepilnaverčiai, ar net tai, ką reiškia nepilnai.Tačiau mes remiamės keliais invariantais:
//
// - Medžiai turi būti vienodi depth/height.Tai reiškia, kad kiekvienas kelias iki lapo iš tam tikro mazgo yra lygiai tokio pat ilgio.
// - `n` ilgio mazge yra klavišai `n`, vertės `n` ir kraštai `n + 1`.
//   Tai reiškia, kad net tuščiame mazge yra bent vienas edge.
//   Lapų mazge "having an edge" reiškia tik tai, kad galime nustatyti vietą mazge, nes lapo kraštai yra tušti ir jiems nereikia pateikti duomenų.
// Vidiniame mazge " edge` identifikuoja padėtį ir yra rodyklė į antrinį mazgą.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Pagrindinė lapų mazgų ir vidinių mazgų atvaizdavimo dalis.
struct LeafNode<K, V> {
    /// Mes norime būti kovojantys su `K` ir `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Šio mazgo indeksas į pagrindinio mazgo `edges` masyvą.
    /// `*node.parent.edges[node.parent_idx]` turėtų būti tas pats dalykas kaip `node`.
    /// Tai garantuojama inicijuoti tik tada, kai " `parent` nėra nulis.
    parent_idx: MaybeUninit<u16>,

    /// Raktų ir reikšmių, kurias šis mazgas saugo, skaičių.
    len: u16,

    /// Masyvai, kuriuose saugomi tikrieji mazgo duomenys.
    /// Inicijuojami ir galioja tik pirmieji kiekvieno masyvo `len` elementai.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicijuoja naują " `LeafNode` vietoje.
    unsafe fn init(this: *mut Self) {
        // Pagal bendrą politiką laukus paliekame neinicijuotus, jei jie gali būti, nes tai turėtų būti šiek tiek greitesnė ir lengviau sekama " Valgrind`.
        //
        unsafe {
            // " parent_idx`, raktai ir " vals` yra " VarbUninit`
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Sukuria naują dėžutę " `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Pagrindinis vidinių mazgų atvaizdavimas.Kaip ir " LeafNode`, jie turėtų būti paslėpti už " BoxedNode`, kad būtų išvengta neinicijuotų raktų ir reikšmių.
/// Bet kurį žymeklį į `InternalNode` galima tiesiogiai nukreipti į žymeklį į pagrindinę mazgo `LeafNode` dalį, leidžiant kodui veikti lapų ir vidinius mazgus bendrai, net netikrinant, į kurį iš dviejų rodyklių nukreipta.
///
/// Ši nuosavybė įgalinta naudojant " `repr(C)`.
///
#[repr(C)]
// gdb_providers.py naudoja šio tipo pavadinimą savianalizei.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Nurodymai šio mazgo vaikams.
    /// `len + 1` iš jų yra laikomi inicijuotais ir galiojančiais, išskyrus tai, kad netoli galo, nors medis laikomas skolinant `Dying` tipo paskolą, kai kurie iš šių rodyklių kabo.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Sukuria naują dėžutę " `InternalNode`.
    ///
    /// # Safety
    /// Vidinių mazgų nekintamas dalykas yra tas, kad jie turi bent vieną inicializuotą ir galiojantį edge.
    /// Ši funkcija nenustato tokio " edge`.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Mums reikia tik inicializuoti duomenis;kraštai yra galUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Valdomas, nenulinis rodyklė į mazgą.Tai yra priklausantis žymeklis į " `LeafNode<K, V>` arba " `InternalNode<K, V>`.
///
/// Tačiau " `BoxedNode` nėra informacijos, kurį iš dviejų tipų mazgų jis iš tikrųjų turi, ir iš dalies dėl šios informacijos stokos nėra atskiras tipas ir neturi destruktoriaus.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Priklausančio medžio šaknies mazgas.
///
/// Atminkite, kad tai neturi naikintuvo, todėl jį reikia išvalyti rankiniu būdu.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Grąžina naują nuosavybės teise priklausantį medį su savo šaknies mazgu, kuris iš pradžių tuščias.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` neturi būti nulis.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Mainiškai skolinasi turimą šaknies mazgą.
    /// Skirtingai nuo " `reborrow_mut`, tai yra saugu, nes grąžinimo vertės negalima naudoti šaknies sunaikinimui ir negali būti kitų nuorodų į medį.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Šiek tiek abejotinai skolinasi turimą šakninį mazgą.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Negrįžtamai pereinama prie nuorodos, leidžiančios pereiti, siūlančios destruktyvius metodus ir mažai ką kita.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Pridedamas naujas vidinis mazgas su vienu edge, nukreiptu į ankstesnį šaknies mazgą, padarykite tą naują mazgą šaknies mazgu ir grąžinkite.
    /// Tai padidina aukštį 1 ir yra priešinga `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, išskyrus tai, kad mes tiesiog pamiršome, kad esame vidiniai:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pašalina vidinį šaknies mazgą, naudodamas jo pirmąjį antrinį mazgą kaip naują šaknies mazgą.
    /// Kadangi jį ketinama iškviesti tik tada, kai šakniniame mazge yra tik vienas vaikas, nė vienas raktas, reikšmė ir kiti vaikai nėra išvalomi.
    ///
    /// Tai sumažina aukštį 1 ir yra priešinga `push_internal_level`.
    ///
    /// Reikia išskirtinės prieigos prie objekto `Root`, bet ne prie šakninio mazgo;
    /// tai nepanaikins kitų rankenų ar nuorodų į šakninį mazgą.
    ///
    /// Panics, jei nėra vidinio lygio, ty jei šaknies mazgas yra lapas.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SAUGA: mes tvirtinome, kad esame vidiniai.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SAUGUMAS: mes skolinomės išskirtinai " `self` ir jo skolinimosi tipas yra išskirtinis.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SAUGUMAS: pirmasis edge visada inicijuojamas.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` visada yra kintamasis `K` ir `V`, net jei `BorrowType` yra `Mut`.
// Tai techniškai neteisinga, tačiau dėl vidinio " `NodeRef` naudojimo negalima sukelti jokio nesaugumo, nes " `K` ir " `V` mes liekame visiškai bendri.
//
// Tačiau kai viešasis tipas apgaubia `NodeRef`, įsitikinkite, kad jis turi teisingą dispersiją.
//
/// Nuoroda į mazgą.
///
/// Šis tipas turi keletą parametrų, kurie kontroliuoja jo veikimą:
/// - `BorrowType`: Manekeno tipas, apibūdinantis skolinimosi rūšį ir atidedantis visą gyvenimą.
///    - Kai tai yra " `Immut<'a>`, " `NodeRef` veikia maždaug kaip " `&'a Node`.
///    - Kai tai yra " `ValMut<'a>`, " `NodeRef` raktų ir medžio struktūros atžvilgiu veikia maždaug kaip " `&'a Node`, tačiau taip pat leidžia kartu egzistuoti daugybei kintamų nuorodų į vertes visame medyje.
///    - Kai tai yra " `Mut<'a>`, " `NodeRef` veikia maždaug kaip " `&'a mut Node`, nors įterpimo metodai leidžia kartu egzistuoti kintamą rodyklę iki vertės.
///    - Kai tai yra " `Owned`, " `NodeRef` veikia maždaug kaip " `Box<Node>`, tačiau neturi destruktoriaus ir turi būti išvalytas rankiniu būdu.
///    - Kai tai yra " `Dying`, " `NodeRef` vis tiek veikia maždaug kaip " `Box<Node>`, tačiau turi metodų, kaip po truputį naikinti medį, o įprasti metodai, nors ir nėra pažymėti kaip nesaugūs skambinant, gali iškviesti UB, jei iškviečiami neteisingai.
///
///   Kadangi bet koks " `NodeRef` leidžia naršyti per medį, " `BorrowType` efektyviai taikomas visam medžiui, ne tik pačiam mazgui.
/// - `K` ir `V`: tai yra mazgų tipų raktai ir reikšmės.
/// - `Type`: Tai gali būti `Leaf`, `Internal` arba `LeafOrInternal`.
/// Kai tai yra `Leaf`, `NodeRef` nukreipia į lapų mazgą, kai tai yra `Internal`, `NodeRef` rodo į vidinį mazgą, o kai tai yra `LeafOrInternal`, `NodeRef` gali būti nukreiptas į bet kurio tipo mazgą.
///   `Type` yra pavadintas `NodeType`, kai naudojamas ne `NodeRef`.
///
/// Tiek " `BorrowType`, tiek " `NodeType` apriboja metodus, kuriuos įgyvendiname, kad išnaudotume statinio tipo saugumą.Yra apribojimų, kaip mes galime taikyti tokius apribojimus:
/// - Kiekvienam tipo parametrui metodą galime apibrėžti tik bendrai arba vienam konkrečiam tipui.
/// Pvz., Mes negalime apibrėžti tokio metodo kaip " `into_kv` visam " `BorrowType` arba vieną kartą visiems tipams, kurie trunka visą gyvenimą, nes norime, kad jis grąžintų `&'a` nuorodas.
///   Todėl mes jį apibrėžiame tik mažiausiai galingam `Immut<'a>` tipui.
/// - Negalime gauti netiesioginės prievartos, tarkim, nuo `Mut<'a>` iki `Immut<'a>`.
///   Todėl, norėdami pasiekti tokį metodą kaip `into_kv`, turime aiškiai paskambinti `reborrow` galingesniu `NodeRef`.
///
/// Visi `NodeRef` metodai, kurie pateikia tam tikrą nuorodą, arba:
/// - Paimkite `self` pagal vertę ir grąžinkite `BorrowType` nešiojimo laiką.
///   Kartais, norėdami pasinaudoti tokiu metodu, turime paskambinti `reborrow_mut`.
/// - Paimkite `self` kaip nuorodą, o (implicitly) grąžina tos nuorodos tarnavimo laiką, o ne `BorrowType`.
/// Tokiu būdu skolinimosi tikrintojas garantuoja, kad " `NodeRef` bus skolinamas tol, kol bus naudojama grąžinta nuoroda.
///   Metodai, palaikantys intarpą, sulenkia šią taisyklę grąžinant neapdorotą rodyklę, ty nuorodą be jokio gyvenimo.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Lygių, kuriuos mazgas ir lapų lygis yra atskirai, skaičius, mazgo konstanta, kurios negalima visiškai apibūdinti `Type`, ir kurio pats mazgas nesaugo.
    /// Turime įrašyti tik šaknies mazgo aukštį ir iš jo išvesti kiekvieno kito mazgo aukštį.
    /// Turi būti nulis, jei `Type` yra `Leaf`, ir nulis, jei `Type` yra `Internal`.
    ///
    ///
    height: usize,
    /// Lapo arba vidinio mazgo rodyklė.
    /// `InternalNode` apibrėžimas užtikrina, kad žymeklis galioja bet kuriuo atveju.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Išpakuokite mazgo nuorodą, kuri buvo supakuota kaip `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Atskleidžia vidinio mazgo duomenis.
    ///
    /// Grąžina neapdorotą ptr, kad būtų išvengta kitų nuorodų į šį mazgą negaliojimo.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SAUGA: statinio mazgo tipas yra `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Skolinasi išskirtinę prieigą prie vidinio mazgo duomenų.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Randa mazgo ilgį.Tai raktų arba reikšmių skaičius.
    /// Briaunų skaičius yra `len() + 1`.
    /// Atkreipkite dėmesį, kad, nepaisant to, kad ši funkcija yra saugi, iškvietus šią funkciją gali būti pašalintas kintamų nuorodų, kurias sukūrė nesaugus kodas, anuliavimas.
    ///
    pub fn len(&self) -> usize {
        // Svarbiausia, kad čia pateksime tik į `len` lauką.
        // Jei " BorrowType` yra marker::ValMut, gali būti neįvykdytų kintamų nuorodų į reikšmes, kurių neturime pripažinti negaliojančiomis.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Grąžina mazgų ir lapų atskirų lygių skaičių.
    /// Nulis aukštis reiškia, kad mazgas yra pats lapas.
    /// Jei vaizduojate medžius su šaknimi viršuje, skaičius nurodo, kuriame aukštyje rodomas mazgas.
    /// Jei vaizduojate medžius su lapais viršuje, skaičius nurodo, kaip aukštai medis tęsiasi virš mazgo.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Laikinai pašalina kitą, nekintamą nuorodą į tą patį mazgą.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Atskleidžia bet kurio lapo ar vidinio mazgo lapo dalį.
    ///
    /// Grąžina neapdorotą ptr, kad būtų išvengta kitų nuorodų į šį mazgą negaliojimo.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Mazgas turi galioti bent " LeafNode` daliai.
        // Tai nėra " NodeRef` tipo nuoroda, nes nežinome, ar ji turėtų būti unikali, ar bendrinama.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Randa dabartinio mazgo tėvą.
    /// Grąžina `Ok(handle)`, jei dabartinis mazgas iš tikrųjų turi tėvą, kur `handle` rodo į tėvų edge, kuris rodo dabartinį mazgą.
    ///
    /// Pateikia `Err(self)`, jei dabartiniame mazge nėra tėvų, grąžinant pradinį `NodeRef`.
    ///
    /// Metodo pavadinimas daro prielaidą, kad vaizduojate medžius su šaknies mazgu viršuje.
    ///
    /// `edge.descend().ascend().unwrap()` ir " `node.ascend().unwrap().descend()`, pasisekę, turėtų nieko nedaryti.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mes turime naudoti neapdorotus rodiklius mazgams, nes, jei " BorrowType` yra marker::ValMut, gali būti išskirtinių kintamų nuorodų į reikšmes, kurių neturime padaryti negaliojančiomis.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Atminkite, kad " `self` turi būti neveikiantis.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Atminkite, kad " `self` turi būti neveikiantis.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Atskleidžia bet kurio nekintamo medžio lapo ar vidinio mazgo lapų dalį.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SAUGUMAS: šiame medyje, pasiskolintame kaip `Immut`, negali būti jokių keičiamų nuorodų.
        unsafe { &*ptr }
    }

    /// Skolinasi rodinį į mazge saugomus raktus.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Panašiai kaip " `ascend`, gauna nuorodą į pagrindinį mazgo pagrindinį mazgą, bet taip pat išskiria dabartinį mazgą procese.
    /// Tai nesaugu, nes dabartinis mazgas vis tiek bus prieinamas, nepaisant to, kad jis buvo paskirstytas.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nesaugiai tvirtina kompiliatoriui statinę informaciją, kad šis mazgas yra `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nesaugiai tvirtina kompiliatoriui statinę informaciją, kad šis mazgas yra `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Laikinai pašalina kitą, kintamą nuorodą į tą patį mazgą.Saugokitės, nes šis metodas yra labai pavojingas, dvigubai, nes jis gali pasirodyti ne iš karto pavojingas.
    ///
    /// Kadangi kintantys rodyklės gali klajoti bet kur aplink medį, grąžintą rodyklę galima lengvai naudoti, kad pradinis rodyklė būtų pakabinta, be ribų ar negaliojanti pagal sukrautas skolinimosi taisykles.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) apsvarstykite galimybę pridėti dar vieną tipo parametrą prie `NodeRef`, kuris apriboja navigacijos metodų naudojimą perkeltose rodyklėse ir užkerta kelią šiam nesaugumui.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Skolinasi išskirtinę prieigą prie bet kurio lapo ar vidinio mazgo lapų dalies.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SAUGA: mes turime išskirtinę prieigą prie viso mazgo.
        unsafe { &mut *ptr }
    }

    /// Siūlo išskirtinę prieigą prie bet kurio lapo ar vidinio mazgo lapų dalies.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SAUGA: mes turime išskirtinę prieigą prie viso mazgo.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Skolinasi išskirtinę prieigą prie rakto saugyklos srities elemento.
    ///
    /// # Safety
    /// `index` yra ribose 0..GALIMYBĖ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SAUGUMAS: skambinantysis negalės paskambinti kitais būdais
        // tol, kol bus panaikinta pagrindinio griežinėlio nuoroda, nes mes turime unikalią prieigą visam skolinimosi laikotarpiui.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Skolinasi išskirtinę prieigą prie mazgo vertės saugojimo srities elemento ar jo dalies.
    ///
    /// # Safety
    /// `index` yra ribose 0..GALIMYBĖ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SAUGUMAS: skambinantysis negalės paskambinti kitais būdais
        // tol, kol vertės skilties nuoroda nebus numesta, nes mes turime unikalią prieigą visam skolinimosi laikotarpiui.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Skolinasi išskirtinę prieigą prie mazgo saugyklos zonos elemento ar jo dalies, skirtos edge turiniui.
    ///
    /// # Safety
    /// `index` yra ribose 0..GALIMYBĖ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SAUGUMAS: skambinantysis negalės paskambinti kitais būdais
        // kol bus atsisakyta " edge` griežinėlių nuoroda, nes mes turime unikalią prieigą visą paskolos galiojimo laiką.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Mazge yra daugiau nei `idx` inicializuotų elementų.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Kuriame tik nuorodą į vieną mus dominantį elementą, kad išvengtume slapyvardžių su išskirtinėmis nuorodomis į kitus elementus, ypač tuos, kurie grįžo skambinančiajam ankstesnėse kartojimuose.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Dėl Rust leidimo #74679 turime priversti naudoti nedidukus masyvo rodykles.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Skolinasi išskirtinę prieigą prie mazgo ilgio.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nustato mazgo nuorodą į savo pirminį " edge`, nepanaikindamas kitų nuorodų į mazgą nuorodų.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Išvalo šaknies nuorodą į pirminę edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Prie mazgo galo pridedama raktų ir verčių pora.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Kiekvienas " `range` grąžintas elementas yra galiojantis mazgo " edge` indeksas.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Pridedama raktų ir verčių pora ir edge, kad eitų tos poros dešinėje, iki mazgo galo.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Tikrina, ar mazgas yra `Internal` mazgas, ar `Leaf` mazgas.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Nuoroda į konkrečią rakto ir vertės porą arba edge mazge.
/// `Node` parametras turi būti `NodeRef`, o `Type` gali būti arba `KV` (žymintis rankeną raktų ir vertybių poroje), arba `Edge` (žymintis rankeną ant edge).
///
/// Atkreipkite dėmesį, kad net `Leaf` mazgai gali turėti `Edge` rankenas.
/// Užuot pavaizdavę rodiklį vaiko mazge, jie žymi tarpus, kur vaikų rodyklės eitų tarp raktų ir verčių porų.
/// Pavyzdžiui, 2 ilgio mazge būtų 3 galimos edge vietos, viena kairėje mazgo, viena tarp dviejų porų ir viena mazgo dešinėje.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Mums nereikia viso `#[derive(Clone)]` bendrumo, nes vienintelis laikas, kai `Node` bus " klonuojamas`, yra tada, kai tai yra nekintama nuoroda ir todėl `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Gauna mazgą, kuriame yra edge arba rakto ir vertės porą, į kurią nukreipia ši rankena.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Grąžina šios rankenos padėtį mazge.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Sukuria naują raktų ir verčių poros " `node` rankeną.
    /// Nesaugu, nes skambinantysis turi užtikrinti, kad `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Tai gali būti viešas " PartialEq` diegimas, tačiau naudojamas tik šiame modulyje.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Laikinai išimkite kitą, nekintamą rankeną toje pačioje vietoje.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Negalime naudoti " Handle::new_kv ar " Handle::new_edge, nes nežinome savo tipo
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Nesaugiai tvirtina kompiliatoriui statinę informaciją, kad rankenos mazgas yra `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Laikinai paima kitą, kintamą rankeną toje pačioje vietoje.
    /// Saugokitės, nes šis metodas yra labai pavojingas, dvigubai, nes jis gali pasirodyti ne iš karto pavojingas.
    ///
    ///
    /// Išsamesnės informacijos ieškokite `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Negalime naudoti " Handle::new_kv ar " Handle::new_edge, nes nežinome savo tipo
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Sukuria naują " edge`rankeną sistemoje " `node`.
    /// Nesaugu, nes skambinantysis turi užtikrinti, kad `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Atsižvelgiant į edge indeksą, kur mes norime įterpti į mazgą, užpildytą iki talpos, apskaičiuojamas protingas padalijimo taško KV indeksas ir vieta, kur atlikti įterpimą.
///
/// Padalijimo taško tikslas yra, kad jo raktas ir vertė patektų į pagrindinį mazgą;
/// klavišai, reikšmės ir kraštai kairėje nuo padalijimo taško tampa kairiuoju vaiku;
/// klavišai, reikšmės ir kraštai, esantys dešinėje nuo padalijimo taško, tampa tinkamu vaiku.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust leidimas #74834 bando paaiškinti šias simetriškas taisykles.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Įterpia naują rakto vertės porą tarp raktų ir verčių porų, esančių dešinėje ir kairėje šio edge.
    /// Šis metodas daro prielaidą, kad mazge yra pakankamai vietos naujai porai tilpti.
    ///
    /// Grąžintas rodyklė rodo įterptą vertę.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Įterpia naują rakto vertės porą tarp raktų ir verčių porų, esančių dešinėje ir kairėje šio edge.
    /// Šis metodas padalija mazgą, jei nėra pakankamai vietos.
    ///
    /// Grąžintas rodyklė rodo įterptą vertę.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ištaiso pirminį rodyklę ir indeksą antriniame mazge, su kuriuo susieja šis " edge`.
    /// Tai naudinga, kai pakeista briaunų tvarka,
    fn correct_parent_link(self) {
        // Sukurkite atkūrimą neatšaukdami kitų nuorodų į mazgą.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Įterpia naują rakto vertės porą ir " edge`, kuri eis tos naujos poros dešinėje tarp šios edge ir raktų vertės poros, esančių šios edge dešinėje.
    /// Šis metodas daro prielaidą, kad mazge yra pakankamai vietos naujai porai tilpti.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Įterpia naują rakto vertės porą ir " edge`, kuri eis tos naujos poros dešinėje tarp šios edge ir raktų vertės poros, esančių šios edge dešinėje.
    /// Šis metodas padalija mazgą, jei nėra pakankamai vietos.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Įterpia naują rakto vertės porą tarp raktų ir verčių porų, esančių dešinėje ir kairėje šio edge.
    /// Šis metodas padalija mazgą, jei nėra pakankamai vietos, ir bando rekursyviai įterpti atskirtą dalį į pagrindinį mazgą, kol bus pasiekta šaknis.
    ///
    ///
    /// Jei grąžinamas rezultatas yra `Fit`, jo rankenos mazgas gali būti šio edge mazgas arba protėvis.
    /// Jei grąžintas rezultatas yra `Split`, laukas `left` bus šaknies mazgas.
    /// Grąžintas rodyklė rodo įterptą vertę.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Randa mazgą, į kurį nukreipė šis edge.
    ///
    /// Metodo pavadinimas daro prielaidą, kad vaizduojate medžius su šaknies mazgu viršuje.
    ///
    /// `edge.descend().ascend().unwrap()` ir " `node.ascend().unwrap().descend()`, pasisekę, turėtų nieko nedaryti.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Mes turime naudoti neapdorotus rodiklius mazgams, nes, jei " BorrowType` yra marker::ValMut, gali būti išskirtinių kintamų nuorodų į reikšmes, kurių neturime padaryti negaliojančiomis.
        // Nėra jokių rūpesčių patekti į aukščio lauką, nes ši reikšmė nukopijuota.
        // Saugokitės, kad nustačius mazgo rodyklę, mes prieiname kraštų masyvą su nuoroda (Rust problema #73987) ir negalioja visos kitos nuorodos į masyvą ar jo viduje, jei jų būtų.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Negalime iškviesti atskirų raktų ir reikšmių metodų, nes iškvietus antrąjį negalioja pirmojo grąžinta nuoroda.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Pakeiskite raktą ir vertę, kurią nurodo KV rankena.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Padeda įdiegti " `split` tam tikram " `NodeType`, rūpindamasi lapų duomenimis.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Padalija pagrindinį mazgą į tris dalis:
    ///
    /// - Mazgas sutrumpinamas, kad raktų ir reikšmių poros būtų tik kairėje šios rankenos pusėje.
    /// - Išgaunamas šios rankenos nurodytas raktas ir vertė.
    /// - Visos raktų vertės poros, esančios dešinėje šios rankenos, yra įdėtos į naujai priskirtą mazgą.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Pašalina raktų vertės porą, į kurią nukreipta ši rankena, ir grąžina ją kartu su edge, į kurią subliuvo raktų ir verčių pora.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Padalija pagrindinį mazgą į tris dalis:
    ///
    /// - Mazgas sutrumpinamas, kad būtų tik kraštai ir raktų reikšmių poros kairėje šios rankenos.
    /// - Išgaunamas šios rankenos nurodytas raktas ir vertė.
    /// - Visi kraštai ir raktų vertės poros, esančios dešinėje šios rankenos, dedamos į naujai priskirtą mazgą.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Atstovauja balansavimo operacijos aplink vidinę raktų ir vertybių porą įvertinimo ir atlikimo sesijai.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Parenka pusiausvyros kontekstą, kuriame mazgas yra vaikas, taigi tarp KV iš karto kairėje arba dešinėje tėvų mazge.
    /// Pateikia `Err`, jei nėra tėvų.
    /// Panics, jei tėvai tušti.
    ///
    /// Pirmenybė teikiama kairiajai pusei, kad būtų optimalu, jei pateiktas mazgas yra kažkaip nepakankamas, turint omenyje tik tai, kad jame yra mažiau elementų nei kairiajame ir dešiniajame, jei jų yra.
    /// Tokiu atveju susijungimas su kairiuoju broliu ir seserimi yra greitesnis, nes mums reikia tik perkelti mazgo N elementus, o ne perkelti juos į dešinę ir judėti daugiau nei N elementų priekyje.
    /// Vagystė iš kairiojo brolio ir sesers taip pat paprastai yra greitesnė, nes mums reikia tik perkelti mazgo N elementus į dešinę, o ne perkelti bent N iš brolio ir sesers į kairę.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Grąžina, ar įmanoma sujungti, ty ar mazge yra pakankamai vietos, kad centrinis KV būtų sujungtas su abiem gretimais vaiko mazgais.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Atlieka sujungimą ir leidžia uždarymui nuspręsti, ką grąžinti.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SAUGUMAS: sujungiamų mazgų aukštis yra vienas žemiau aukščio
                // šio edge mazgo, taigi viršija nulį, taigi jie yra vidiniai.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Sujungia tėvų raktų ir verčių porą ir abu gretimus vaiko mazgus į kairįjį vaiko mazgą ir grąžina susitraukusį tėvų mazgą.
    ///
    ///
    /// Panics, nebent mes `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Sujungia tėvų raktų ir verčių porą ir abu gretimi vaiko mazgai į kairįjį vaiko mazgą ir grąžina tą vaiko mazgą.
    ///
    ///
    /// Panics, nebent mes `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Sujungia tėvų raktų ir verčių porą ir abu gretimus vaiko mazgus į kairįjį vaiko mazgą ir grąžina edge rankeną tame vaiko mazge, kuriame atsidūrė stebimas vaikas edge,
    ///
    ///
    /// Panics, nebent mes `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Pašalina rakto ir vertės porą iš kairiojo vaiko ir įdeda ją į tėvų raktų ir vertybių saugyklą, o seną pagrindinę raktų ir verčių porą stumia į reikiamą vaiką.
    ///
    /// Grąžina dešiniojo vaiko edge rankeną, atitinkančią `track_right_edge_idx` nurodytą originalų edge.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Pašalina raktų ir verčių porą iš dešiniojo vaiko ir padeda jį į tėvų raktų-vertybių saugyklą, o senąją tėvų raktų ir verčių porą stumia ant kairiojo vaiko.
    ///
    /// Grąžina rankeną kairiajam vaikui, nurodytam `track_left_edge_idx`, edge, kuris nejudėjo.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Tai vagia panašiai kaip " `steal_left`, tačiau pavagia kelis elementus vienu metu.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Įsitikinkite, kad galime pavogti saugiai.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Perkelti lapų duomenis.
            {
                // Tinkamam vaikui palikite vietos pavogtiems daiktams.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Perkelkite elementus iš kairiojo vaiko į dešinįjį.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Perkelkite kairę labiausiai pavogtą porą tėvui.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Perkelkite tėvų raktų ir verčių porą į tinkamą vaiką.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Padarykite vietos pavogtiems kraštams.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Pavogti kraštus.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Simetrinis `bulk_steal_left` klonas.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Įsitikinkite, kad galime pavogti saugiai.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Perkelti lapų duomenis.
            {
                // Perkelkite dešinėje labiausiai pavogtą porą tėvui.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Perkelkite tėvų rakto ir vertės porą į kairįjį vaiką.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Perkelkite elementus iš dešiniojo vaiko į kairįjį.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Užpildykite tarpą ten, kur anksčiau buvo vogti elementai.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Pavogti kraštus.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Užpildykite tarpą ten, kur anksčiau buvo pavogti kraštai.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Pašalina bet kokią statinę informaciją, teigiančią, kad šis mazgas yra `Leaf` mazgas.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pašalina bet kokią statinę informaciją, teigiančią, kad šis mazgas yra `Internal` mazgas.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Tikrina, ar pagrindinis mazgas yra `Internal` mazgas, ar `Leaf` mazgas.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Perkelkite priesagą po `self` iš vieno mazgo į kitą.`right` turi būti tuščias.
    /// Pirmasis " `right` edge lieka nepakitęs.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Įterpimo rezultatas, kai mazgas turi išsiplėsti virš savo pajėgumų.
pub struct SplitResult<'a, K, V, NodeType> {
    // Pakeistas esamo medžio mazgas su elementais ir kraštais, priklausančiais kairei `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Kai kurie raktai ir reikšmės išsiskiria, kad būtų įterpti kitur.
    pub kv: (K, V),
    // Nuosavas, neprisirišęs, naujas mazgas su elementais ir kraštais, priklausančiais `kv` dešinėje.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Ar šio skolinimosi tipo mazgų nuorodos leidžia pereiti į kitus medžio mazgus.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Perėjimas nėra būtinas, tai atsitinka naudojant " `borrow_mut` rezultatą.
        // Neleisdami perėjimo ir tik sukurdami naujas nuorodas į šaknis, žinome, kad kiekviena `Owned` tipo nuoroda yra šaknies mazgas.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Įterpia vertę į inicializuotų elementų dalį, po kurios eina vienas neinicijuotas elementas.
///
/// # Safety
/// Skiltyje yra daugiau nei `idx` elementų.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Pašalina ir grąžina vertę iš visų inicializuotų elementų griežinėlio, palikdamas vieną galinį neinicijuotą elementą.
///
///
/// # Safety
/// Skiltyje yra daugiau nei `idx` elementų.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Perkelkite elementus `distance` pjūvio pozicijose į kairę.
///
/// # Safety
/// Skiltyje yra bent `distance` elementai.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Perkelkite elementus `distance` pjūvio pozicijose į dešinę.
///
/// # Safety
/// Skiltyje yra bent `distance` elementai.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Perkelia visas reikšmes iš inicializuotų elementų riekės į neinicijuotų elementų skiltį, palikdamas `src` kaip visas neinicijuotas.
///
/// Veikia kaip " `dst.copy_from_slice(src)`, tačiau nereikia, kad " `T` būtų " `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;