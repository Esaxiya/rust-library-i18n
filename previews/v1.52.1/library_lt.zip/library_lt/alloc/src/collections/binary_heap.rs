//! Prioritetinė eilė, įgyvendinta naudojant dvejetainį kaupą.
//!
//! Didžiausio elemento įterpimas ir iškėlimas turi *O*(log(*n*)) laiko sudėtingumą.
//! Didžiausias elementas yra *O*(1).Konvertuoti vector į dvejetainį kaupą galima vietoje, ir tai yra *O*(*n*) sudėtingumas.
//! Dvejetainis kaupas taip pat gali būti konvertuojamas į surūšiuotą vector vietoje, leidžiant jį naudoti *O*(*n*\*log(* n*)) vietoje esančiam pagrindiniam uostui.
//!
//! # Examples
//!
//! Tai yra didesnis pavyzdys, kuris įgyvendina " [Dijkstra's algorithm][dijkstra], kad išspręstų " [shortest path problem][sssp] ant " [directed graph][dir_graph].
//!
//! Tai parodo, kaip naudoti " [`BinaryHeap`] su pasirinktiniais tipais.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Prioritetinė eilė priklauso nuo `Ord`.
//! // Aiškiai įgyvendinkite " trait`, kad eilė taptų " min-heap`, o ne " max-heap`.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Atkreipkite dėmesį, kad mes pakeičiame išlaidų užsakymą.
//!         // Jei taškų skaičius yra lygus, šis žingsnis yra būtinas, kad `PartialEq` ir `Ord` įgyvendinimai būtų nuoseklūs.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` taip pat reikia įgyvendinti.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Kiekvienas mazgas pateikiamas kaip `usize`, kad būtų galima trumpiau įgyvendinti.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Dijkstros trumpiausio kelio algoritmas.
//!
//! // Pradėkite nuo `start` ir naudokite `dist`, kad nustatytumėte trumpiausią dabartinį atstumą iki kiekvieno mazgo.Šis diegimas nėra efektyvus atmintyje, nes eilėje gali likti mazgų kopijos.
//! //
//! // Jis taip pat naudoja " `usize::MAX` kaip kontrolinę vertę, kad būtų paprasčiau įgyvendinti.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [mazgas]=dabartinis trumpiausias atstumas nuo `start` iki `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Mes `start`, su nuline kaina
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Pirmiausia ištirkite sieną su mažesnių sąnaudų mazgais (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Arba mes galėjome toliau ieškoti visų trumpiausių kelių
//!         if position == goal { return Some(cost); }
//!
//!         // Svarbu, nes galbūt jau radome geresnį būdą
//!         if cost > dist[position] { continue; }
//!
//!         // Kiekvienam mazgui, kurį galime pasiekti, sužinokite, ar galime rasti būdą su mažesnėmis sąnaudomis per šį mazgą
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Jei taip, pridėkite jį prie sienos ir tęskite
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Atsipalaidavimas, mes dabar radome geresnį būdą
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Tikslas nepasiekiamas
//!     None
//! }
//!
//! fn main() {
//!     // Tai yra nukreiptas grafikas, kurį naudosime.
//!     // Mazgų skaičiai atitinka skirtingas būsenas, o edge svoriai simbolizuoja judėjimo iš vieno mazgo į kitą kainą.
//!     //
//!     // Atkreipkite dėmesį, kad kraštai yra vienpusiai.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Grafikas pateikiamas kaip gretimybių sąrašas, kur kiekvienas indeksas, atitinkantis mazgo vertę, turi išeinančių kraštų sąrašą.
//!     // Pasirinktas dėl jo efektyvumo.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // 0 mazgas
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // 1 mazgas
//!         vec![Edge { node: 3, cost: 2 }],
//!         // 2 mazgas
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // 3 mazgas
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // 4 mazgas
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Prioritetinė eilė, įgyvendinta naudojant dvejetainį kaupą.
///
/// Tai bus maksimalus krūva.
///
/// Tai yra loginė klaida, kai elementas modifikuojamas taip, kad elemento eiliškumas, palyginti su bet kuriuo kitu daiktu, kaip nustatyta `Ord` trait, pasikeis, kol jis yra kaupe.
///
/// Paprastai tai įmanoma tik naudojant `Cell`, `RefCell`, globalinę būseną, I/O arba nesaugų kodą.
/// Elgesys, atsirandantis dėl tokios loginės klaidos, nėra nurodytas, tačiau neapibrėžtas elgesys nesukels.
/// Tai gali apimti " panics`, neteisingus rezultatus, nutraukimus, atminties nutekėjimą ir nenutraukimą.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Tipo išvada leidžia mums praleisti aiškų tipo parašą (kuris šiame pavyzdyje būtų `BinaryHeap<i32>`).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Mes galime naudoti žvilgsnį, norėdami pažvelgti į kitą krūvos elementą.
/// // Šiuo atveju ten dar nėra elementų, todėl mes negauname jokio.
/// assert_eq!(heap.peek(), None);
///
/// // Pridėkime keletą balų ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Dabar žvilgsnis rodo svarbiausią kaupo elementą.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Galime patikrinti krūvos ilgį.
/// assert_eq!(heap.len(), 3);
///
/// // Mes galime kartoti krūvoje esančius daiktus, nors jie grąžinami atsitiktine tvarka.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Jei mes užuot išleidę šiuos balus, jie turėtų grįžti eilės tvarka.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Mes galime išvalyti krūvą nuo likusių daiktų.
/// heap.clear();
///
/// // Krūva dabar turėtų būti tuščia.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Kad `BinaryHeap` taptų min-krūva, gali būti naudojamas arba `std::cmp::Reverse`, arba pasirinktinis `Ord` diegimas.
/// Tai verčia `heap.pop()` grąžinti mažiausią, o ne didžiausią vertę.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Apvyniokite vertes `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Jei mes dabar rodysime šiuos balus, jie turėtų grįžti atvirkštine tvarka.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Laiko sudėtingumas
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// " `push` vertė yra tikėtinos išlaidos;metodo dokumentuose pateikiama išsamesnė analizė.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktūra, apimanti kintamą nuorodą į didžiausią " `BinaryHeap` elementą.
///
///
/// Šis " `struct` sukurtas naudojant " [`peek_mut`] metodą sistemoje " [`BinaryHeap`].
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SAUGA: " PeekMut` yra skirtas tik tuštiems kaupams.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAUGU: " PeekMut` yra skirtas tik tuščioms kaupoms
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAUGU: " PeekMut` yra skirtas tik tuščioms kaupoms
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Pašalina iš krūvos žvilgterėtą vertę ir grąžina ją.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Sukuria tuščią " `BinaryHeap<T>`.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Sukuria tuščią " `BinaryHeap` kaip maksimalų kaupą.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Sukuria tuščią " `BinaryHeap` su tam tikra talpa.
    /// Tai iš anksto paskirsto pakankamai atminties `capacity` elementams, kad `BinaryHeap` nereikėtų perskirstyti tol, kol joje nebus bent tiek daug reikšmių.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Pateikia kintamą nuorodą į didžiausią elementą dvejetainiame kaupe arba `None`, jei jis tuščias.
    ///
    /// Note: Jei nutekėjo `PeekMut` vertė, krūva gali būti nenuosekli.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Laiko sudėtingumas
    ///
    /// Jei elementas yra modifikuotas, blogiausiu atveju laiko sudėtingumas yra *O*(log(*n*)), kitaip jis yra *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Pašalina didžiausią elementą iš dvejetainio kaupo ir grąžina jį arba `None`, jei jis tuščias.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Laiko sudėtingumas
    ///
    /// Blogiausia `pop` kaina su kaupu, kuriame yra *n* elementų, yra *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SAUGA: !self.is_empty() reiškia, kad self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Stumia daiktą ant dvejetainio kaupo.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Laiko sudėtingumas
    ///
    /// Numatoma " `push` kaina, apskaičiuota vidutiniškai pagal kiekvieną įmanomą stumiamų elementų ir pakankamai didelių paspaudimų skaičių, yra *O*(1).
    ///
    /// Tai yra prasmingiausia sąnaudų metrika, kai stumiami elementai, kurie jau nėra * pagal bet kurį rūšiuojamąjį modelį.
    ///
    /// Laiko sudėtingumas blogėja, jei elementai stumiami daugiausia didėjimo tvarka.
    /// Blogiausiu atveju elementai stumiami didėjančia tvarka, o amortizuota vieno stūmimo kaina yra *O*(log(*n*)), palyginti su kaupu, kuriame yra *n* elementų.
    ///
    /// Blogiausia *vieno* skambučio į " `push` kaina yra *O*(*n*).Blogiausias atvejis būna tada, kai pajėgumai yra išeikvoti ir jiems reikia pakeisti dydį.
    /// Pakeitimo kaina buvo amortizuota ankstesniais skaičiais.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SAUGA: Kadangi mes pasistatėme naują daiktą, tai reiškia
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Panaudoja " `BinaryHeap` ir grąžina " vector` rūšiuojama (ascending) tvarka.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SAUGUMAS: `end` pereina nuo `self.len() - 1` iki 1 (abu yra),
            //  taigi prieigai prie jos visada galioja indeksas.
            //  Tai saugu prieiti prie indekso 0 (ty `ptr`), nes
            //  1 <=pabaiga <self.len(), o tai reiškia self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SAUGUMAS: " `end` pereina nuo " `self.len() - 1` iki 1 (abu įtraukti), taigi:
            //  0 <1 <=pabaiga <= self.len(), 1 <self.len() Tai reiškia 0 <pabaiga ir pabaiga <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // " Sift_up`ir " sift_down` diegimas naudoja nesaugius blokus, kad elementas būtų perkeltas iš vector (paliekant skylę), pasislinkus išilgai kitų ir perkeliant pašalintą elementą atgal į vector galinėje skylės vietoje.
    //
    // `Hole` tipas naudojamas tam atspindėti ir įsitikinkite, kad skylė yra užpildyta atgal pasibaigus jos taikymo sričiai, net naudojant " panic`.
    // Skylės naudojimas sumažina pastovų koeficientą, lyginant su apsikeitimo sandoriais, kurie apima dvigubai daugiau ėjimų.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Skambinantysis turi garantuoti, kad `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Išimkite vertę ties `pos` ir sukurkite skylę.
        // SAUGUMAS: skambinantysis garantuoja, kad poz. <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SAUGA: hole.pos()> start>=0, o tai reiškia hole.pos()> 0
            //  todėl hole.pos(), 1 negali būti per mažas.
            //  Tai garantuoja tėvą <hole.pos(), todėl jis yra galiojantis indeksas ir!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SAUGA: Tas pats, kas aukščiau
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Paimkite elementą ties `pos` ir perkelkite jį žemyn, kol jo vaikai yra didesni.
    ///
    ///
    /// # Safety
    ///
    /// Skambinantysis turi garantuoti, kad `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SAUGUMAS: skambinantysis garantuoja, kad poz <pabaiga <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Nekilnojamasis ciklas: vaikas==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // palyginkite su didesne iš dviejų vaikų SAUGUMAS: vaikas <pabaiga, 1 <self.len() ir vaikas + 1 <pabaiga <= self.len(), taigi jie yra tinkami indeksai.
            //
            //  vaikas==2 *hole.pos() + 1!= hole.pos() ir vaikas + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 arba 2* hole.pos() + 2 gali perpildyti, jei T yra ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // jei jau tvarkomės, sustok.
            // SAUGA: vaikas dabar yra senas vaikas arba senas vaikas + 1
            //  Mes jau įrodėme, kad abu yra <self.len() ir!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SAUGA: tas pats, kas aukščiau.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SAUGA: &&trumpasis jungimas, o tai reiškia, kad
        //  antra sąlyga jau tiesa, kad vaikas==pabaiga, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SAUGA: jau įrodyta, kad vaikas yra galiojantis indeksas ir
            //  vaikas==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Skambinantysis turi garantuoti, kad `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SAUGUMAS: pos <len garantuoja skambinantysis ir
        //  akivaizdžiai len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Paimkite elementą ties `pos` ir perkelkite jį iki galo, tada persijokite jį į savo padėtį.
    ///
    ///
    /// Note: Tai yra greičiau, kai žinoma, kad elementas yra didelis/turėtų būti arčiau dugno.
    ///
    /// # Safety
    ///
    /// Skambinantysis turi garantuoti, kad `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SAUGUMAS: skambinantysis garantuoja, kad poz. <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Nekilnojamasis ciklas: vaikas==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SAUGA: vaikas <galas, 1 <self.len() ir
            //  vaikas + 1 <pabaiga <= self.len(), taigi jie yra galiojantys indeksai.
            //  vaikas==2 *hole.pos() + 1!= hole.pos() ir vaikas + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 arba 2* hole.pos() + 2 gali perpildyti, jei T yra ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SAUGA: Tas pats, kas aukščiau
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SAUGA: vaikas==pabaiga, 1 <self.len(), taigi tai galiojantis indeksas
            //  ir vaikas==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SAUGA: poz yra padėtis skylėje ir jau buvo įrodyta
        //  kad būtų galiojantis indeksas.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SAUGA: n prasideda nuo self.len()/2 ir nusileidžia iki 0.
            //  Vienintelis atvejis, kai! (N <self.len()) yra, jei self.len() ==0, bet tai atmeta ciklo sąlyga.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Visi `other` elementai perkeliami į `self`, paliekant `other` tuščią.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` ima O(len1 + len2) operacijas ir apie 2 *(len1 + len2) palyginimus blogiausiu atveju, o `extend` atlieka O(len2* log(len1)) operacijas ir apie 1 *len2* log_2(len1) palyginimus blogiausiu atveju, darant prielaidą, kad len1>= len2.
        // Didesnių krūvų kryžminis taškas nebesilaiko šio samprotavimo ir buvo nustatytas empiriškai.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Pateikia iteratorių, kuris nuskaito elementus kaupo tvarka.
    /// Gauti elementai pašalinami iš pirminio kaupo.
    /// Likę elementai bus pašalinti, kai lašas bus kaupiamas.
    ///
    /// Note:
    /// * `.drain_sorted()` yra *O*(*n*\*log(* n*)); daug lėčiau nei `.drain()`.
    ///   Daugeliu atvejų turėtumėte naudoti pastarąjį.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // pašalina visus elementus kaupo tvarka
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Išlaiko tik predikatą nurodytus elementus.
    ///
    /// Kitaip tariant, pašalinkite visus elementus `e` taip, kad `f(&e)` grąžintų `false`.
    /// Elementai lankomi nerūšiuota (ir nepatikslinta) tvarka.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // laikykite tik lyginius skaičius
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Pateikia iteratorių, kuris bet kokia tvarka aplanko visas pagrindinio vector reikšmes.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Spausdinkite 1, 2, 3, 4 savavališkai
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Pateikia iteratorių, kuris nuskaito elementus kaupo tvarka.
    /// Šis metodas sunaudoja originalų krūvą.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Pateikia didžiausią elementą dvejetainėje kaupoje arba `None`, jei jis tuščias.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Laiko sudėtingumas
    ///
    /// Blogiausiu atveju kaina yra *O*(1).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Grąžina elementų, kuriuos dvejetainis kaupas gali laikyti, neperskirstydamas, skaičių.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Pasilieka mažiausią talpą tiksliai `additional` elementams įterpti į nurodytą `BinaryHeap`.
    /// Nieko nedaro, jei pajėgumų jau pakanka.
    ///
    /// Atminkite, kad paskirstytojas gali suteikti kolekcijai daugiau vietos nei reikalauja.
    /// Todėl negalima pasikliauti, kad pajėgumas yra minimalus.
    /// Pirmenybė teikiama " [`reserve`], jei tikimasi įterpti " future`.
    ///
    /// # Panics
    ///
    /// Panics, jei nauja talpa perpildys `usize`.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervai rezervuojami mažiausiai dar `additional` elementams, kurie bus įterpti į `BinaryHeap`.
    /// Kolekcijoje gali būti rezervuota daugiau vietos, kad būtų išvengta dažnų perskirstymų.
    ///
    /// # Panics
    ///
    /// Panics, jei nauja talpa perpildys `usize`.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Atmeta kuo daugiau papildomų pajėgumų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Atmeta talpą su apatine riba.
    ///
    /// Talpa išliks bent jau tokia pati kaip ilgis ir tiekiama vertė.
    ///
    ///
    /// Jei dabartinis pajėgumas yra mažesnis už apatinę ribą, tai yra draudimas.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Panaudoja " `BinaryHeap` ir grąžina pagrindinį " vector` savavališkai.
    ///
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Spausdins tam tikra tvarka
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Grąžina dvejetainio kaupo ilgį.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Tikrina, ar dvejetainis kaupas tuščias.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Išvalo dvejetainį kaupą, grąžindamas iteratorių virš pašalintų elementų.
    ///
    /// Elementai pašalinami savavališkai.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Nuleidžia visus daiktus iš dvejetainio kaupo.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Skylė reiškia skylę pjūvyje, ty indeksą be tinkamos vertės (nes jis buvo perkeltas arba nukopijuotas).
///
/// Laime `Hole` atkurs pjūvį užpildydamas skylės padėtį iš pradžių pašalinta verte.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Sukurkite naują `Hole` prie indekso `pos`.
    ///
    /// Nesaugu, nes pos turi būti duomenų skiltyje.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAUGA: pos turi būti riekės viduje
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Grąžina nuorodą į pašalintą elementą.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Grąžina nuorodą į elementą, esantį `index`.
    ///
    /// Nesaugu, nes indeksas turi būti duomenų skiltyje ir neturi būti lygus poz.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Perkelkite skylę į naują vietą
    ///
    /// Nesaugu, nes indeksas turi būti duomenų skiltyje ir neturi būti lygus poz.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // vėl užpildykite skylę
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// " `BinaryHeap` elementų pakartojimas.
///
/// Šį " `struct` sukūrė " [`BinaryHeap::iter()`].
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Pašalinti `#[derive(Clone)]` naudai
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Turintis " `BinaryHeap` elementų iteratorių.
///
/// Šį " `struct` sukūrė " [`BinaryHeap::into_iter()`] (pateikė " `IntoIterator` trait`).
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// " `BinaryHeap` elementų nutekėjimo iteratorius.
///
/// Šį " `struct` sukūrė " [`BinaryHeap::drain()`].
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// " `BinaryHeap` elementų nutekėjimo iteratorius.
///
/// Šį " `struct` sukūrė " [`BinaryHeap::drain_sorted()`].
/// Daugiau informacijos rasite jos dokumentacijoje.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Pašalina kaupo elementus kaupo tvarka.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// `Vec<T>` paverčia `BinaryHeap<T>`.
    ///
    /// Ši konversija vyksta vietoje ir turi sudėtingumą *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// `BinaryHeap<T>` paverčia `Vec<T>`.
    ///
    /// Ši konversija nereikalauja duomenų judėjimo ar paskirstymo ir yra nuolat sudėtinga.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Sukuria vartojantį iteratorių, t. Y. Kiekvieną vertę iš dvejetainio kaupo savavališkai tvarkant.
    /// Binarinio kaupo negalima naudoti paskambinus šiam.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Spausdinkite 1, 2, 3, 4 savavališkai
    /// for x in heap.into_iter() {
    ///     // x turi i32 tipą, o ne &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}