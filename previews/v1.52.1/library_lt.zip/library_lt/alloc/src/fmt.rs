//! " String` formatavimo ir spausdinimo priemonės.
//!
//! Šiame modulyje yra [`format!`] sintaksės plėtinio vykdymo palaikymas.
//! Ši makrokomanda įdiegta kompiliatoriuje, kad būtų galima skambinti į šį modulį, kad argumentai vykdymo metu būtų formatuojami į eilutes.
//!
//! # Usage
//!
//! " [`format!`] makrokomanda skirta susipažinti tiems, kurie ateina iš " C` `printf`/`fprintf` funkcijų arba " Python`funkcijos " `str.format`.
//!
//! Keli [`format!`] plėtinio pavyzdžiai:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" su priekiniais nuliais
//! ```
//!
//! Iš jų galite pamatyti, kad pirmasis argumentas yra formato eilutė.Kompiliatorius reikalauja, kad tai būtų eilutės literalas;tai negali būti kintamasis, perduodamas (norint patikrinti galiojimą).
//! Tada kompiliatorius analizuos formato eilutę ir nustatys, ar pateiktas argumentų sąrašas yra tinkamas perduoti šiai formato eilutei.
//!
//! Norėdami konvertuoti vieną vertę į eilutę, naudokite metodą [`to_string`].Tam bus naudojamas [`Display`] formatavimas trait.
//!
//! ## Padėties parametrai
//!
//! Kiekviename formatavimo argumente leidžiama nurodyti, kurios vertės argumentą jis nurodo, ir jei jis praleistas, manoma, kad jis yra "the next argument".
//! Pvz., Formato eilutė `{} {} {}` turėtų tris parametrus ir jie būtų suformatuoti ta pačia tvarka, kokia jie buvo pateikti.
//! Tačiau formato eilutė `{2} {1} {0}` argumentus formatuos atvirkštine tvarka.
//!
//! Viskas gali pasidaryti šiek tiek keblu, kai pradėsite maišyti dviejų tipų pozicinius specifikatorius."next argument" specifikatorius gali būti laikomas iteratoriumi per argumentą.
//! Kiekvieną kartą, kai matomas "next argument" specifikatorius, kartojasi iteratorius.Tai veda prie tokio elgesio:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Vidinis argumento iteratorius nebuvo išplėtotas iki to laiko, kai buvo parodytas pirmasis `{}`, todėl jis išspausdina pirmąjį argumentą.Tada, pasiekęs antrąjį " `{}`, iteratorius pereina į antrąjį argumentą.
//! Iš esmės parametrai, kurie aiškiai įvardija savo argumentą, neturi įtakos parametrams, kurie nevadina argumento pagal pozicinius parametrus.
//!
//! Formato eilutė reikalinga norint naudoti visus jos argumentus, kitaip tai yra kompiliavimo laiko klaida.Formato eilutėje galite nurodyti tą patį argumentą daugiau nei vieną kartą.
//!
//! ## Pavadinti parametrai
//!
//! Pats " Rust`neturi panašių į funkciją Python panašių pavadintų parametrų, tačiau " [`format!`] makrokomanda yra sintaksės plėtinys, leidžiantis panaudoti įvardintus parametrus.
//! Pavadinti parametrai yra išvardyti argumentų sąrašo pabaigoje ir turi sintaksę:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Pvz., Šios [`format!`] išraiškos naudoja argumentą:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Negalima dėti pozicijos parametrų (be pavadinimų) po argumentais, turinčiais pavadinimus.Kaip ir padėties parametruose, neteisinga pateikti nurodytų parametrų, kurių nenaudoja formato eilutė.
//!
//! # Parametrų formatavimas
//!
//! Kiekvienas formatuojamas argumentas gali būti transformuojamas keliais formatavimo parametrais ([the syntax](#syntax)) atitinka `format_spec`. Šie parametrai daro įtaką formatuojamo elemento eilutei.
//!
//! ## Width
//!
//! ```
//! // Visi šie spausdina "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Tai yra " "minimum width" parametras, kurį turėtų naudoti formatas.
//! Jei reikšmės eilutė neužpildo tiek simbolių, fill/alignment nurodytas užpildas bus naudojamas norint užimti reikiamą vietą (žr. Toliau).
//!
//! Pločio reikšmė taip pat gali būti pateikta kaip [`usize`] parametrų sąraše, pridedant postfix `$`, nurodant, kad antrasis argumentas yra [`usize`], nurodantis plotį.
//!
//! Nuoroda į argumentą su dolerio sintakse neturi įtakos "next argument" skaitikliui, todėl paprastai verta nurodyti argumentus pagal poziciją arba naudoti įvardintus argumentus.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Pasirenkamas užpildymo simbolis ir lygiavimas pateikiami paprastai kartu su parametru [`width`](#width).Jis turi būti apibrėžtas prieš `width`, iškart po `:`.
//! Tai rodo, kad jei formatuojama vertė yra mažesnė nei `width`, aplink ją bus spausdinami keli papildomi simboliai.
//! Įvairiems išlygiavimams pateikiami šie variantai:
//!
//! * `[fill]<` - argumentas yra sulygiuotas kairėje `width` stulpeliuose
//! * `[fill]^` - `width` stulpeliuose argumentas sulygiuotas centre
//! * `[fill]>` - `width` stulpeliuose argumentas sureguliuotas dešinėn
//!
//! Numerių numatytasis [fill/alignment](#fillalignment) yra tarpas ir sulygiuotas kairėje.Numatytasis skaitinių formatų formatas taip pat yra tarpo simbolis, bet su dešiniuoju lygiu.
//! Jei skaitmenims nurodoma `0` vėliava (žr. Toliau), numanomas užpildymo simbolis yra `0`.
//!
//! Atminkite, kad kai kurių tipų lygiavimas gali būti neįgyvendintas.Visų pirma, jis nėra įgyvendinamas " `Debug` trait`.
//! Geras būdas užtikrinti užpildymą yra suformatuoti įvestį, tada užpildyti šią gautą eilutę, kad gautumėte išvestį:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Sveiki, Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Tai visos vėliavos, pakeičiančios formato elgesį.
//!
//! * `+` - Tai skirta skaitmeniniams tipams ir nurodo, kad ženklas visada turi būti atspausdintas.Teigiami ženklai niekada nėra spausdinami pagal numatytuosius nustatymus, o neigiami ženklai pagal numatytuosius nustatymus spausdinami tik naudojant " `Signed` trait`.
//! Ši vėliava rodo, kad visada reikia atspausdinti teisingą ženklą (`+` arba `-`).
//! * `-` - Šiuo metu nenaudojama
//! * `#` - Ši žymė rodo, kad turėtų būti naudojama "alternate" spausdinimo forma.Alternatyvios formos yra:
//!     * `#?` - gražiai atspausdinkite [`Debug`] formatavimą
//!     * `#x` - prieš argumentą su `0x`
//!     * `#X` - prieš argumentą su `0x`
//!     * `#b` - prieš argumentą su `0b`
//!     * `#o` - prieš argumentą su `0o`
//! * `0` - Tai naudojama norint nurodyti sveikųjų skaičių formatus, kad užpildymas iki `width` turėtų būti atliekamas su `0` simboliu, taip pat turėtų žinoti ženklą.
//! Toks formatas kaip `{:08}` suteiktų `00000001` sveikam skaičiui `1`, tuo pačiu formatu `-0000001`-sveikam skaičiui `-1`.
//! Atkreipkite dėmesį, kad neigiamoje versijoje yra nulis mažiau nei teigiamoje versijoje.
//!         Atkreipkite dėmesį, kad užpildymo nuliai visada dedami po ženklu (jei yra) ir prieš skaitmenis.Kai naudojama kartu su `#` vėliava, galioja panaši taisyklė: užpildymo nuliai įterpiami po priešdėlio, bet prieš skaitmenis.
//!         Priešdėlis įtraukiamas į bendrą plotį.
//!
//! ## Precision
//!
//! Ne skaitmeniniams tipams tai galima laikyti "maximum width".
//! Jei gaunama eilutė yra ilgesnė už šį plotį, tada ji sutrumpinama iki tiek simbolių ir ta sutrumpinta vertė išduodama su tinkamais `fill`, `alignment` ir `width`, jei šie parametrai yra nustatyti.
//!
//! Integralių tipų atveju tai nepaisoma.
//!
//! Jei tai yra slankiojo kablelio tipai, tai rodo, kiek skaitmenų po kablelio turėtų būti atspausdinta.
//!
//! Norimą " `precision` galite nurodyti trimis būdais:
//!
//! 1. Sveikasis skaičius `.N`:
//!
//!    pats sveikasis skaičius `N` yra tikslumas.
//!
//! 2. Sveikas skaičius arba vardas, po kurio nurodomas dolerio ženklas `.N$`:
//!
//!    kaip tikslumą naudokite formatą *argumentą*`N` (kuris turi būti `usize`).
//!
//! 3. Žvaigždutė `.*`:
//!
//!    `.*` reiškia, kad šis " `{...}` yra susietas su *dviem* formato įvestimis, o ne su vienu: pirmasis įvestis turi `usize` tikslumą, o antrasis-vertę, kurią reikia spausdinti.
//!    Atminkite, kad šiuo atveju, jei naudojama formato eilutė `{<arg>:<spec>.*}`, `<arg>` dalis nurodo* reikšmę * spausdinti, o `precision` turi būti įvesta prieš `<arg>`.
//!
//! Pvz., Visi šie skambučiai spausdina tą patį dalyką " `Hello x is 0.01000`:
//!
//! ```
//! // Sveiki, {arg 0 ("x")} yra {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Sveiki, {arg 1 ("x")} yra {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Sveiki, {arg 0 ("x")} yra {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} yra {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} yra {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Sveiki, {next arg ("x")} yra {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Nors šie:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! atspausdinkite tris labai skirtingus dalykus:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Kai kuriose programavimo kalbose eilučių formatavimo funkcijų veikimas priklauso nuo operacinės sistemos lokalės nustatymo.
//! " Rust` standartinės bibliotekos teikiamos formato funkcijos neturi jokios lokalės sampratos ir pateiks tuos pačius rezultatus visose sistemose, neatsižvelgiant į vartotojo konfigūraciją.
//!
//! Pvz., Šis kodas visada spausdins `1.5`, net jei sistemos lokalėje naudojamas ne dešimtainis, o dešimtainis skyriklis.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Pažodiniai simboliai `{` ir `}` gali būti įtraukti į eilutę prieš juos tuo pačiu simboliu.Pvz., `{` simbolis išvengiamas naudojant `{{`, o `}`-`}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Apibendrinant, čia rasite visą formato eilučių gramatiką.
//! Naudojamos formatavimo kalbos sintaksė yra paimta iš kitų kalbų, todėl ji neturėtų būti per daug svetima.Argumentai yra suformatuoti su Python panašią sintaksę, tai reiškia, kad argumentus supa `{}`, o ne į C panašus `%`.
//! Tikroji formatavimo sintaksės gramatika yra:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Pirmiau pateiktoje gramatikoje `text` negali būti jokių `'{'` ar `'}'` simbolių.
//!
//! # traits formatavimas
//!
//! Prašydami suformatuoti argumentą su tam tikru tipu, jūs iš tikrųjų prašote, kad argumentas būtų priskirtas tam tikram trait.
//! Tai leidžia formatuoti kelis faktinius tipus per `{:x}` (pvz., [`i8`], taip pat [`isize`]).Dabartinis tipų susiejimas su traits yra:
//!
//! * *nieko* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] su mažosiomis raidėmis šešioliktainiais skaičiais
//! * `X?` ⇒ [`Debug`] su didžiųjų raidžių šešioliktainiais skaičiais
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Tai reiškia, kad bet kokį argumentą, kuris įgyvendina " [`fmt::Binary`][`Binary`] trait`, galima suformatuoti naudojant " `{:b}`.Standartinė biblioteka taip pat pateikia šiuos " traits` variantus daugeliui primityvių tipų.
//!
//! Jei nenurodomas joks formatas (kaip `{}` ar `{:6}`), tada naudojamas formatas trait yra [`Display`] trait.
//!
//! Diegdami savo tipo formatą trait, turėsite įdiegti parašo metodą:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // mūsų pasirinktinis tipas
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Jūsų tipas bus perduotas kaip " `self` kaip nuoroda, tada funkcija turėtų skleisti išvestį į " `f.buf` srautą.Kiekvieno formato trait įgyvendinimas turi tinkamai laikytis prašomų formatavimo parametrų.
//! Šių parametrų vertės bus nurodytos [`Formatter`] struktūros laukuose.Norėdami tai padaryti, [`Formatter`] struct taip pat pateikia keletą pagalbinių metodų.
//!
//! Be to, šios funkcijos grįžtamoji vertė yra [`fmt::Result`], kuri yra tipo " [Rezultatas`] pseudonimas <(), " [" std: : fmt::Error`] `>`.
//! Formatavimo diegimai turėtų užtikrinti, kad jie skleistų klaidas iš [`Formatter`] (pvz., Kai skambinate į [`write!`]).
//! Tačiau jie niekada neturėtų klaidingai grąžinti klaidų.
//! Tai reiškia, kad formatavimo įgyvendinimas turi ir gali pateikti klaidą tik tuo atveju, jei perduotas [`Formatter`] pateikia klaidą.
//! Taip yra todėl, kad, priešingai nei siūlo funkcijos parašas, eilutės formatavimas yra neklystanti operacija.
//! Ši funkcija pateikia tik rezultatą, nes gali nepavykti rašyti į pagrindinį srautą ir ji turi suteikti galimybę paskleisti faktą, kad įvyko klaida atsarginėje rietuvės kopijoje.
//!
//! Formatavimo traits įgyvendinimo pavyzdys atrodys taip:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f` reikšmė įgyvendina `Write` trait, tai ir rašo!makro tikisi.
//!         // Atminkite, kad šis formatavimas nepaiso įvairių žymių, pateikiamų formatuojant eilutes.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Skirtingi traits leidžia naudoti skirtingas tipo išvestis.
//! // Šio formato reikšmė yra atspausdinti vector dydį.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Laikykitės formatavimo žymių, naudodami pagalbinį metodą `pad_integral` objekte " Formatter`.
//!         // Išsamesnės informacijos ieškokite metodo dokumentacijoje, o funkciją `pad` galima naudoti stygoms paminkštinti.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` palyginti su " `fmt::Debug`
//!
//! Šie du " traits` formatai turi skirtingus tikslus:
//!
//! - [`fmt::Display`][`Display`] diegimai tvirtina, kad tipą visada galima teisingai pavaizduoti kaip UTF-8 eilutę.Negalima ** tikėtis, kad visi tipai įdiegs " [`Display`] trait`.
//! - [`fmt::Debug`][`Debug`] diegimas turėtų būti įgyvendinamas **visiems** viešiesiems tipams.
//!   Rezultatas paprastai kiek įmanoma teisingiau atspindi vidinę būseną.
//!   " [`Debug`] trait` paskirtis yra palengvinti Rust kodo derinimą.Daugeliu atvejų pakanka ir rekomenduojama naudoti `#[derive(Debug)]`.
//!
//! Keletas " traits` išvesties pavyzdžių:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Susijusios makrokomandos
//!
//! " [`format!`] šeimoje yra daugybė susijusių makrokomandų.Šiuo metu įgyvendinamos šios:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Tai ir [`writeln!`] yra dvi makrokomandos, kurios naudojamos formato eilutei perduoti į nurodytą srautą.Tai naudojama siekiant užkirsti kelią tarpiniams formato eilių paskirstymams ir tiesiogiai įrašyti išvestį.
//! Po gaubtu ši funkcija iš tikrųjų naudoja [`write_fmt`] funkciją, apibrėžtą [`std::io::Write`] trait.
//! Naudojimo pavyzdys yra:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Tai ir " [`println!`] išleidžia savo išvestį į " stdout`.Panašiai kaip makrokomandoje [`write!`], šių makrokomandų tikslas yra išvengti tarpinių paskirstymų spausdinant išvestį.Naudojimo pavyzdys yra:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`] ir [`eprintln!`] makrokomandos yra identiškos atitinkamai [`print!`] ir [`println!`], išskyrus tai, kad jos išleidžia savo išvestį į stderr.
//!
//! ### `format_args!`
//!
//! Tai yra įdomus makrokomandas, naudojamas saugiai apeiti nepermatomą objektą, apibūdinantį formato eilutę.Šiam objektui kurti nereikia jokių kaupo paskirstymų, jis nurodo tik informaciją, esančią rietuvėje.
//! Pagal tai yra įgyvendinamos visos susijusios makrokomandos.
//! Pirmiausia, keletas naudojimo pavyzdžių yra:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! [`format_args!`] makrokomandos rezultatas yra [`fmt::Arguments`] tipo vertė.
//! Tada ši struktūra gali būti perduota šio modulio viduje esančioms funkcijoms [`write`] ir [`format`], kad būtų apdorota formato eilutė.
//! Šios makrokomandos tikslas yra dar labiau užkirsti kelią tarpiniams paskirstymams tvarkant eilučių formatavimą.
//!
//! Pvz., Registravimo bibliotekoje gali būti naudojama standartinė formatavimo sintaksė, tačiau ji viduje apeis šią struktūrą, kol bus nustatyta, kur turėtų būti išvestis.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcija `format` paima [`Arguments`] struktūrą ir grąžina gautą suformatuotą eilutę.
///
///
/// " [`Arguments`] egzempliorių galima sukurti naudojant " [`format_args!`] makrokomandą.
///
/// # Examples
///
/// Pagrindinis naudojimas:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Atkreipkite dėmesį, kad geriau naudoti " [`format!`].
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}