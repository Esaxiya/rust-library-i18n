//! Vienos gijos nuorodų skaičiavimo rodyklės.'Rc' reiškia " nuoroda`
//! Counted'.
//!
//! [`Rc<T>`][`Rc`] tipas suteikia bendrą nuosavybės teisę į `T` tipo vertę, priskirtą kaupui.
//! Iškviečiant " [`clone`][clone] sistemoje " [`Rc`], gaunamas naujas rodiklis į tą patį krūvos paskirstymą.
//! Kai sunaikinamas paskutinis tam tikro paskirstymo [`Rc`] žymeklis, tame paskirstyme saugoma vertė (dažnai vadinama "inner value") taip pat atsisakoma.
//!
//! Bendros nuorodos programoje Rust neleidžia mutacijos pagal numatytuosius nustatymus, o [`Rc`] nėra išimtis: paprastai negalima gauti kintamos nuorodos į kažką, esantį [`Rc`].
//! Jei jums reikia kintamumo, įdėkite [`Cell`] arba [`RefCell`] į [`Rc`] vidų;žr. [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] naudoja ne atominį atskaitos skaičiavimą.
//! Tai reiškia, kad pridėtinės išlaidos yra labai mažos, tačiau [`Rc`] negalima siųsti tarp gijų, todėl [`Rc`] neįgyvendina [`Send`][send].
//! Todėl kompiliatorius Rust patikrins *kompiliavimo metu*, ar nesiunčiate [`Rc`] tarp gijų.
//! Jei jums reikia skaičiuoti atominį atskaitos skaičių, naudokite [`sync::Arc`][arc].
//!
//! [`downgrade`][downgrade] metodas gali būti naudojamas kuriant ne [`Weak`] žymeklį.
//! " [`Weak`] žymeklį galima [" atnaujinti`][atnaujinti] d iki " [`Rc`], tačiau tai grąžins [`None`], jei paskirstyme saugoma vertė jau bus atmesta.
//! Kitaip tariant, `Weak` žymekliai neišlaiko vertės paskirstymo viduje;tačiau jie * išlaiko gyvą paskirstymą (vidinės vertės pagrindinę atsargą).
//!
//! Ciklas tarp [`Rc`] žymeklių niekada nebus paskirstytas.
//! Dėl šios priežasties [`Weak`] naudojamas pertraukiant ciklus.
//! Pavyzdžiui, medyje gali būti stiprios [`Rc`] žymekliai nuo tėvų mazgų iki vaikų, o vaikų [`Weak`] rodyklės atgal į tėvus.
//!
//! `Rc<T>` automatiškai daro išvadas iš `T` (per [`Deref`] trait), todėl galite paskambinti `T` metodais pagal [`Rc<T>`][`Rc`] tipo vertę.
//! Kad išvengtume vardų susidūrimo su " T` metodais, pats [`Rc<T>`][`Rc`] metodas yra susietos funkcijos, vadinamos naudojant [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>" traits`, pvz., " `Clone`, įdiegimus taip pat galima iškviesti naudojant visiškai kvalifikuotą sintaksę.
//! Kai kurie žmonės nori naudoti visiškai kvalifikuotą sintaksę, o kiti-metodo skambučio sintaksę.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Metodo-skambučio sintaksė
//! let rc2 = rc.clone();
//! // Visiškai kvalifikuota sintaksė
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] automatiškai nenusileidžia `T`, nes vidinė vertė jau gali būti sumažinta.
//!
//! # Klonavimo nuorodos
//!
//! Nauja nuoroda į tą patį paskirstymą kaip esamas atskaitos suskaičiuotas žymeklis sukuriamas naudojant `Clone` trait, įdiegtą [`Rc<T>`][`Rc`] ir [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Žemiau pateiktos dvi sintaksės yra lygiavertės.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ir b abu rodo tą pačią atminties vietą kaip ir foo.
//! ```
//!
//! `Rc::clone(&from)` sintaksė yra pati idiomatiškiausia, nes ji aiškiau perteikia kodo reikšmę.
//! Ankstesniame pavyzdyje ši sintaksė leidžia lengviau suprasti, kad šis kodas sukuria naują nuorodą, o ne nukopijuoja visą foo turinį.
//!
//! # Examples
//!
//! Apsvarstykite scenarijų, kai " Gadget`rinkinys priklauso tam tikram " `Owner`.
//! Mes norime, kad mūsų programėlė nukreiptų į jų " `Owner`.Negalime to padaryti turėdami unikalią nuosavybės teisę, nes tam pačiam " `Owner` gali priklausyti daugiau nei viena programėlė.
//! [`Rc`] leidžia mums dalytis " `Owner` tarp kelių " įtaisų` ir leisti, kad " `Owner` būtų paskirstytas tol, kol jame bus visi " `Gadget` taškai.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... kiti laukai
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... kiti laukai
//! }
//!
//! fn main() {
//!     // Sukurkite nuoroda suskaičiuotą `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Sukurkite " Gadget`, priklausantį `gadget_owner`.
//!     // Klonavus " `Rc<Owner>`, gaunamas naujas žymeklis į tą patį " `Owner` paskirstymą, padidinant etalonų skaičių procese.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Išmeskite mūsų vietinį kintamąjį `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Nepaisant to, kad numetėte " `gadget_owner`, mes vis tiek galime atsispausdinti " Gadget` `Owner` pavadinimą.
//!     // Taip yra todėl, kad mes atsisakėme tik vieno " `Rc<Owner>`, o ne " `Owner`, į kurį jis nurodo.
//!     // Tol, kol tuo pačiu `Owner` paskirstymu yra kitų " `Rc<Owner>` taškų, jis liks veikiantis.
//!     // Lauko projekcija `gadget1.owner.name` veikia, nes `Rc<Owner>` automatiškai daro nuorodas į `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Pasibaigus funkcijai, `gadget1` ir `gadget2` sunaikinami, o kartu su jais paskutinės suskaičiuotos nuorodos į mūsų `Owner`.
//!     // " Gadget Man` taip pat sunaikinamas.
//!     //
//! }
//! ```
//!
//! Jei pasikeis mūsų reikalavimai ir mums taip pat reikės mokėti pereiti nuo `Owner` iki `Gadget`, susidursime su problemomis.
//! [`Rc`] žymeklis nuo `Owner` iki `Gadget` pristato ciklą.
//! Tai reiškia, kad jų atskaitos skaičius niekada negali pasiekti 0 ir paskirstymas niekada nebus sunaikintas:
//! atminties nutekėjimas.Norėdami tai apeiti, galime naudoti [`Weak`] rodykles.
//!
//! " Rust` iš tikrųjų šiek tiek apsunkina šios kilpos gamybą.Norint gauti dvi vertybes, nukreiptas viena į kitą, viena iš jų turi būti keičiama.
//! Tai sunku, nes " [`Rc`] užtikrina atminties saugumą, tik pateikdamas bendras nuorodas į vertę, kurią jis apgaubia, ir tai neleidžia tiesiogiai mutuoti.
//! Vertės dalį, kurią norime mutuoti, turime suvynioti į [`RefCell`], kuri suteikia *vidinį kintamumą*: metodą, kaip pasiekti kintamumą naudojant bendrą nuorodą.
//! [`RefCell`] vykdo Rust skolinimosi taisykles vykdymo metu.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... kiti laukai
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... kiti laukai
//! }
//!
//! fn main() {
//!     // Sukurkite nuoroda suskaičiuotą `Owner`.
//!     // Atkreipkite dėmesį, kad " Gadget` savininko vector įdėjome į `RefCell`, kad galėtume jį mutuoti naudodami bendrą nuorodą.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Sukurkite " Gadget`, priklausantį `gadget_owner`, kaip ir anksčiau.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Pridėkite programėlę prie savo `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` dinamiškas skolinimasis čia baigiasi.
//!     }
//!
//!     // Kartokite per mūsų programėlę, išspausdindami jų detales.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` yra " `Weak<Gadget>`.
//!         // Kadangi " `Weak` žymekliai negali garantuoti, kad paskirstymas vis dar egzistuoja, turime iškviesti " `upgrade`, kuris pateikia `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Šiuo atveju mes žinome, kad paskirstymas vis dar egzistuoja, todėl mes tiesiog `unwrap` `Option`.
//!         // Sudėtingesnėje programoje `None` rezultatui gali prireikti gracingo klaidų tvarkymo.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Pasibaigus funkcijai, `gadget_owner`, `gadget1` ir `gadget2` sunaikinami.
//!     // Dabar nėra jokių stiprių " (`Rc`) nuorodų į programėles, todėl jos sunaikinamos.
//!     // Tai nulemia " Gadget Man` atskaitos skaičių, todėl jis taip pat sunaikinamas.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Tai apsaugo nuo repr(C) iki future nuo galimo lauko pertvarkymo, kuris trukdytų kitu atveju saugiam perdaromų vidinių tipų [into|from]_raw().
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Vienos gijos atskaitos skaičiavimo rodyklė.'Rc' reiškia " nuoroda`
/// Counted'.
///
/// Norėdami gauti daugiau informacijos, žiūrėkite " [module-level documentation](./index.html).
///
/// Būdingi `Rc` metodai yra visos susijusios funkcijos, o tai reiškia, kad jūs turite juos vadinti, pvz., [`Rc::get_mut(&mut value)`][get_mut], o ne `value.get_mut()`.
/// Taip išvengiama konfliktų su vidinio tipo `T` metodais.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Šis nesaugumas yra gerai, nes kol šis Rc gyvas, mes garantuojame, kad vidinis rodyklė galioja.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Sukonstruoja naują " `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Yra netiesioginis silpnas žymeklis, priklausantis visiems stipriems rodyklėms, kuris užtikrina, kad silpnas destruktorius niekada neatlaisvina paskirstymo, kol veikia stiprus destruktorius, net jei silpnas rodyklė yra saugoma stipriojo viduje.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Sukonstruoja naują " `Rc<T>`, naudodamas silpną nuorodą į save.
    /// Bandant atnaujinti silpną nuorodą prieš grąžinant šią funkciją, bus gaunama `None` reikšmė.
    ///
    /// Tačiau silpnoji etalonė gali būti laisvai klonuojama ir saugoma naudoti vėliau.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... daugiau laukų
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Sukurkite vidinę būseną "uninitialized" su viena silpna nuoroda.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Svarbu neatsisakyti silpnosios žymeklio nuosavybės, kitaip atmintis gali būti atlaisvinta, kol grįš `data_fn`.
        // Jei tikrai norėtume perduoti nuosavybės teisę, galėtume sukurti papildomą silpną rodyklę sau, tačiau tai sukeltų papildomų silpnos atskaitos skaičiaus atnaujinimų, kurių kitu atveju gali būti nereikalinga.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Stiprioms nuorodoms bendrai turėtų priklausyti bendra silpna nuoroda, todėl nenaudokite destruktoriaus pagal mūsų seną silpną nuorodą.
        //
        mem::forget(weak);
        strong
    }

    /// Sukonstruoja naują `Rc` su neinicijuotu turiniu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Sukonstruoja naują `Rc` su neinicijuotu turiniu, o atmintis užpildyta `0` baitais.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Sukuria naują " `Rc<T>` ir pateikia klaidą, jei paskirstymas nepavyksta
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Yra netiesioginis silpnas žymeklis, priklausantis visiems stipriems rodyklėms, kuris užtikrina, kad silpnas destruktorius niekada neatlaisvina paskirstymo, kol veikia stiprus destruktorius, net jei silpnas rodyklė yra saugoma stipriojo viduje.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Sukuria naują " `Rc` su neinicijuotu turiniu ir pateikia klaidą, jei nepavyksta paskirstyti
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Sukonstruoja naują " `Rc` su neinicijuotu turiniu, o atmintis užpildyta `0` baitais. Jei paskirstymas nepavyksta, pateikiama klaida.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Sukonstruoja naują " `Pin<Rc<T>>`.
    /// Jei " `T` neįdiegia " `Unpin`, tada `value` bus prisegtas atmintyje ir negalės būti perkeltas.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Pateikia vidinę vertę, jei " `Rc` turi tiksliai vieną tvirtą atskaitos tašką.
    ///
    /// Kitu atveju [`Err`] grąžinamas su tuo pačiu `Rc`, kuris buvo perduotas.
    ///
    ///
    /// Tai pavyks, net jei yra išskirtinių silpnų nuorodų.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // nukopijuokite turimą objektą

                // Nurodykite " Weaks`, kad jų negalima reklamuoti mažinant stiprų skaičių, tada pašalinkite numanomą " "strong weak" žymeklį ir tvarkykite kritimo logiką tiesiog sukurdami netikrą silpną.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Sukuria naują nuorodų skaičiuojamą gabalą su neinicijuotu turiniu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Sukuria naują nuorodų suskaičiuotą pjūvį su neinicijuotu turiniu, o atmintis užpildyta `0` baitais.
    ///
    ///
    /// Tinkamo ir neteisingo šio metodo naudojimo pavyzdžių ieškokite [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konvertuojamas į `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Kaip ir " [`MaybeUninit::assume_init`] atveju, skambinantysis turi garantuoti, kad vidinė vertė iš tikrųjų yra inicializuota.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicializuotas, kyla neatidėliotinas elgesys.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konvertuojamas į `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Kaip ir " [`MaybeUninit::assume_init`] atveju, skambinantysis turi garantuoti, kad vidinė vertė iš tikrųjų yra inicializuota.
    ///
    /// Tai paskambinus, kai turinys dar nėra visiškai inicializuotas, kyla neatidėliotinas elgesys.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Atidėtas inicijavimas:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Panaudoja " `Rc`, grąžindamas suvyniotą rodyklę.
    ///
    /// Norėdami išvengti atminties nutekėjimo, rodyklę reikia konvertuoti atgal į `Rc` naudojant [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Pateikia neapdorotą duomenų rodyklę.
    ///
    /// Skaičiavimai jokiu būdu neturi įtakos ir `Rc` nevartojamas.
    /// Rodyklė galioja tol, kol " `Rc` yra stiprus skaičius.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SAUGUMAS: to negalima atlikti naudojant " Deref::deref arba " Rc::inner, nes
        // to reikia norint išlaikyti raw/mut originalumą taip, kad pvz
        // `get_mut` gali rašyti per rodyklę po to, kai Rc yra atkurta per `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Sukuria `Rc<T>` iš neapdoroto žymeklio.
    ///
    /// Neapdorotas žymeklis turi būti anksčiau grąžintas skambučiu į [`Rc<U>::into_raw`][into_raw], kur `U` turi būti tokio pat dydžio ir lygiu kaip `T`.
    /// Tai trivialiai tiesa, jei `U` yra `T`.
    /// Atkreipkite dėmesį, kad jei " `U` nėra " `T`, tačiau jo dydis ir išlygiavimas yra vienodi, tai iš esmės panašu į skirtingų tipų nuorodų transmutavimą.
    /// Norėdami sužinoti daugiau, kokie apribojimai taikomi šiuo atveju, žr. [`mem::transmute`][transmute].
    ///
    /// " `from_raw` vartotojas turi įsitikinti, kad konkreti " `T` vertė yra numesta tik vieną kartą.
    ///
    /// Ši funkcija yra nesaugi, nes netinkamas naudojimas gali sukelti atminties nesaugumą, net jei niekada negrįšite į grąžintą `Rc<T>`.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konvertuokite atgal į `Rc`, kad išvengtumėte nuotėkio.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Kiti skambučiai į " `Rc::from_raw(x_ptr)` būtų nesaugūs atmintyje.
    /// }
    ///
    /// // Atmintis buvo atlaisvinta, kai " `x` nepateko į aukščiau nurodytą sritį, todėl " `x_ptr` dabar kabo!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Apverskite poslinkį, kad rastumėte originalų " RcBox`.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Sukuria naują [`Weak`] žymeklį šiam paskirstymui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Įsitikinkite, kad nesukūrėme kabančios silpnosios
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Gauna [`Weak`] žymeklių skaičių šiam paskirstymui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Gauna stiprių (`Rc`) žymeklių skaičių šiam paskirstymui.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Grąžina `true`, jei nėra kitų `Rc` arba [`Weak`] rodyklių prie šio paskirstymo.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Pateikia kintamą nuorodą į nurodytą `Rc`, jei nėra kitų to paties paskirstymo `Rc` arba [`Weak`] rodyklių.
    ///
    ///
    /// Priešingu atveju pateikia [`None`], nes nėra saugu mutuoti bendrą vertę.
    ///
    /// Taip pat žiūrėkite [`make_mut`][make_mut], kuris [`clone`][clone] vidinę vertę, kai yra kitų rodyklių.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Pateikia kintamą nuorodą į nurodytą `Rc`, be jokio patikrinimo.
    ///
    /// Taip pat žiūrėkite " [`get_mut`], kuris yra saugus ir atlieka atitinkamus patikrinimus.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Grąžinamos paskolos trukmės laikotarpiu negalima daryti jokios kitos nuorodos į `Rc` arba [`Weak`] į tą patį paskirstymą.
    ///
    /// Tai yra nereikšmingai, jei tokių rodyklių nėra, pavyzdžiui, iškart po `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Mes stengiamės *nekurti* nuorodos, apimančios "count" laukus, nes tai prieštarautų prieigoms prie nuorodų skaičiaus (pvz.,
        // iki `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Grąžina `true`, jei du " Rc` rodo tą patį paskirstymą (venoje, panašioje į [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Pateikia kintamą nuorodą į nurodytą `Rc`.
    ///
    /// Jei yra kitų to paties paskirstymo `Rc` žymeklių, `make_mut` [`clone`] vidinę naujo paskirstymo vertę užtikrins unikalią nuosavybės teisę.
    /// Tai taip pat vadinama klonu rašant.
    ///
    /// Jei nėra kitų šio paskirstymo `Rc` žymeklių, tada šio paskirstymo [`Weak`] rodyklės bus atsietos.
    ///
    /// Taip pat žiūrėkite " [`get_mut`], kuris žlugs, o ne klonuos.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nieko neklonuos
    /// let mut other_data = Rc::clone(&data);    // Neklonuos vidinių duomenų
    /// *Rc::make_mut(&mut data) += 1;        // Klonuoja vidinius duomenis
    /// *Rc::make_mut(&mut data) += 1;        // Nieko neklonuos
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nieko neklonuos
    ///
    /// // Dabar " `data` ir " `other_data` nurodo skirtingus paskirstymus.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] rodyklės bus atsietos:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Turi klonuoti duomenis, yra ir kitų Rcs.
            // Iš anksto paskirstykite atmintį, kad būtų galima tiesiogiai įrašyti klonuotą vertę.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Gali tiesiog pavogti duomenis, belieka tik " Weaks`
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Pašalinkite numanomą stiprią ir silpną nuorodą (čia nereikia kurti netikro silpno-mes žinome, kad kiti " Weaks` gali mums išvalyti)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Šis nesaugumas yra tinkamas, nes mes garantuojame, kad grąžintas žymeklis yra vienintelis * rodiklis, kuris kada nors bus grąžintas T.
        // Šiuo metu garantuojama, kad mūsų atskaitos skaičius bus 1, ir mes reikalavome, kad pats `Rc<T>` būtų `mut`, todėl grąžiname vienintelę įmanomą nuorodą į paskirstymą.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Bandykite `Rc<dyn Any>` sumažinti iki konkretaus tipo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Paskiria " `RcBox<T>`, kuriame yra pakankamai vietos galimai nedidelei vidinei vertei, jei vertės išdėstymas pateiktas.
    ///
    /// Funkcija `mem_to_rcbox` iškviečiama naudojant duomenų rodyklę ir turi grąžinti `RcBox<T>` (galimai riebų) žymeklį.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Apskaičiuokite išdėstymą naudodami nurodytą vertės išdėstymą.
        // Anksčiau maketas buvo apskaičiuojamas pagal išraišką `&*(ptr as* const RcBox<T>)`, tačiau tai sukūrė neteisingą nuorodą (žr. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Paskiria " `RcBox<T>`, kuriame yra pakankamai vietos galimai nedidelei vidinei vertei, kur vertės pateikiamas išdėstymas, pateikiant klaidą, jei nepavyksta paskirstyti.
    ///
    ///
    /// Funkcija `mem_to_rcbox` iškviečiama naudojant duomenų rodyklę ir turi grąžinti `RcBox<T>` (galimai riebų) žymeklį.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Apskaičiuokite išdėstymą naudodami nurodytą vertės išdėstymą.
        // Anksčiau maketas buvo apskaičiuojamas pagal išraišką `&*(ptr as* const RcBox<T>)`, tačiau tai sukūrė neteisingą nuorodą (žr. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Paskirti maketui.
        let ptr = allocate(layout)?;

        // Inicializuokite " RcBox`
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Paskiria " `RcBox<T>`, kuriame yra pakankamai vietos nedidelei vidinei vertei
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Paskirkite `RcBox<T>` naudodami nurodytą vertę.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Nukopijuokite vertę kaip baitus
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Nemokamai paskirstykite neišmesdami jo turinio
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Paskiria nurodyto ilgio `RcBox<[T]>`.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Nukopijuokite elementus iš griežinėlio į naujai paskirtą Rc <\[T\]>
    ///
    /// Nesaugu, nes skambinantysis turi perimti nuosavybės teisę arba susieti " `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Sukuria `Rc<[T]>` iš iteratoriaus, kuris, kaip žinoma, yra tam tikro dydžio.
    ///
    /// Jei netinkamas dydis, elgesys nėra apibrėžtas.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic apsauga klonuojant T elementus.
        // " panic`atveju elementai, kurie buvo įrašyti į naująjį " RcBox`, bus išmesti, o tada atlaisvės atmintis.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Pirmojo elemento žymeklis
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Viskas aišku.Pamirškite apsaugą, kad ji neišlaisvintų naujojo " RcBox`.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializacija trait naudojama `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Nuleidžia " `Rc`.
    ///
    /// Tai sumažins stiprų atskaitos skaičių.
    /// Jei stipraus atskaitos skaičius pasiekia nulį, vienintelės kitos nuorodos (jei yra) yra [`Weak`], taigi mes vidinę vertę `drop`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nieko nespausdina
    /// drop(foo2);   // Spausdina "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // sunaikinti esančią daiktą
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // pašalinkite numanomą "strong weak" žymeklį dabar, kai sunaikinsime turinį.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Padaro `Rc` žymeklio kloną.
    ///
    /// Tai sukuria kitą to paties paskirstymo rodyklę, padidindama stiprų atskaitos skaičių.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Sukuria naują `Rc<T>` su `Default` reikšme `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Įsilaužkite į " `Eq` specializaciją, net jei " `Eq` turi metodą.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ši specializacija atliekama čia, o ne kaip bendresnis " `&T` optimizavimas, nes kitaip padidėtų išlaidos visiems lygybės patikrinimams.
/// Manome, kad " Rc` yra naudojami kaupti dideles vertes, kurios lėtai klonuojamos, bet taip pat sunkiai tikrinamos lygybės, todėl šios išlaidos lengviau atsiperka.
///
/// Taip pat labiau tikėtina, kad bus du `Rc` klonai, kurie nurodo tą pačią vertę, nei du " &T`.
///
/// Tai galime padaryti tik tada, kai " `T: Eq` kaip " `PartialEq` gali būti sąmoningai neatspindintis.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Dviejų " Rc` lygybė.
    ///
    /// Du " Rc` yra lygūs, jei jų vidinės vertės yra vienodos, net jei jos yra skirtingai paskirstytos.
    ///
    /// Jei `T` taip pat įgyvendina `Eq` (tai reiškia lygybės atspindį), du " Rc`, nurodantys tą patį paskirstymą, visada yra lygūs.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Dviejų " Rc` nelygybė.
    ///
    /// Du " Rc` yra nevienodi, jei jų vidinės vertės yra nevienodos.
    ///
    /// Jei `T` taip pat įgyvendina `Eq` (tai reiškia lygybės atspindį), du " Rc`, nurodantys tą patį paskirstymą, niekada nėra nelygūs.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Dalinis dviejų " Rc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `partial_cmp()` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mažiau nei dviejų " Rc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `<` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Dviejų " Rc`palyginimas " mažesnis arba lygus`.
    ///
    /// Abu jie lyginami skambinant `<=` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Didesnis nei dviejų " Rc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `>` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Dviejų " Rc`palyginimas " didesnis arba lygus`.
    ///
    /// Abu jie lyginami skambinant `>=` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Dviejų " Rc` palyginimas.
    ///
    /// Abu jie lyginami skambinant `cmp()` savo vidinėms vertybėms.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Paskirkite nuorodą suskaičiuotą gabalėlį ir užpildykite jį klonuodami " v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Paskirkite nuorodų suskaičiuotą eilutės pjūvį ir nukopijuokite į jį `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Paskirkite nuorodų suskaičiuotą eilutės pjūvį ir nukopijuokite į jį `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Perkelkite langelyje esantį objektą į naują, suskaičiuotą nuorodą, paskirstymą.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Paskirkite suskaičiuotą griežinėlį ir perkelkite į jį " v` elementus.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Leiskite " Vec` atlaisvinti atmintį, bet nesunaikinkite jos turinio
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Paima kiekvieną `Iterator` elementą ir surenka jį į `Rc<[T]>`.
    ///
    /// # Eksploatacinės charakteristikos
    ///
    /// ## Bendras atvejis
    ///
    /// Paprastai rinkimas į `Rc<[T]>` atliekamas pirmiausia surenkant į `Vec<T>`.Tai yra, kai rašote:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// tai elgiasi taip, lyg mes parašytume:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Čia įvyksta pirmasis paskirstymų rinkinys.
    ///     .into(); // Čia įvyksta antrasis " `Rc<[T]>` paskirstymas.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Tai paskirs tiek kartų, kiek reikia `Vec<T>` sukūrimui, ir paskirs vieną kartą, kad `Vec<T>` paverstų `Rc<[T]>`.
    ///
    ///
    /// ## Žinomo ilgio iteratoriai
    ///
    /// Kai jūsų " `Iterator` įdiegia " `TrustedLen` ir yra tikslaus dydžio, " `Rc<[T]>` bus skirtas vienas paskirstymas.Pavyzdžiui:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Čia įvyksta tik vienas paskirstymas.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializacija trait naudojama rinkti į `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Tai pasakytina apie " `TrustedLen` iteratorių.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SAUGA: Turime užtikrinti, kad iteratorius turi tikslų ilgį ir mes.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Grįžkite prie įprasto įgyvendinimo.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` yra " [`Rc`] versija, turinti neturinčią nuorodos į valdomą paskirstymą.Paskyrimas pasiekiamas iškvietus [`upgrade`] žymeklį `Weak`, kuris pateikia [" Option`] " <`[" Rc`] `<T>>`.
///
/// Kadangi " `Weak` nuoroda į nuosavybės teisę neįskaičiuojama, tai netrukdys numesti paskirstyme saugomos vertės, o pats " `Weak` negarantuoja, kad vertė vis dar yra.
/// Taigi jis gali grąžinti [`None`], kai d.
/// Tačiau atkreipkite dėmesį, kad `Weak` nuoroda * neleidžia paskirstyti paties paskirstymo (pagrindinės saugyklos).
///
/// `Weak` žymeklis yra naudingas laikinai laikant nuorodą į paskirstymą, kurį valdo [`Rc`], netrukdant jo vidinei vertei numesti.
/// Jis taip pat naudojamas užkirsti kelią žiedinėms nuorodoms tarp [`Rc`] žymeklių, nes abipusės nuorodos niekada neleistų nė vieno [`Rc`] mesti.
/// Pavyzdžiui, medyje gali būti stiprios [`Rc`] žymekliai nuo tėvų mazgų iki vaikų, o vaikų `Weak` rodyklės atgal į tėvus.
///
/// Tipiškas `Weak` žymiklio gavimo būdas yra skambinimas į [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Tai yra " `NonNull`, leidžiantis optimizuoti šio tipo dydį, tačiau tai nebūtinai yra galiojantis rodyklė.
    //
    // `Weak::new` nustato tai kaip `usize::MAX`, kad nereikėtų skirti vietos kaupui.
    // Tai nėra vertė, kurią kada nors turės tikrasis rodyklė, nes " RcBox` turi bent 2 lygiavimą.
    // Tai įmanoma tik tada, kai `T: Sized`;nedidelis `T` niekada nekabina.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Sukonstruoja naują " `Weak<T>`, nepriskirdamas jokios atminties.
    /// Paskambinus į [`upgrade`] pagal grąžinimo vertę, visada gaunama [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Pagalbininko tipas, leidžiantis pasiekti nuorodų skaičių, nedarant jokių teiginių apie duomenų lauką.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Grąžina neapdorotą žymeklį objektui `T`, kurį nurodo šis `Weak<T>`.
    ///
    /// Rodyklė galioja tik tuo atveju, jei yra stiprių nuorodų.
    /// Rodyklė gali būti kabanti, nesuderinta ar net [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Abu rodo į tą patį objektą
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Stiprieji čia palaiko jį gyvą, todėl vis tiek galime prieiti prie objekto.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Bet ne daugiau.
    /// // Galime atlikti " weak.as_ptr(), bet prieiga prie žymiklio lemtų neapibrėžtą elgesį.
    /// // assert_eq! ("labas", nesaugus {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Jei rodyklė kabo, mes tiesiogiai grąžiname kontrolinį.
            // Tai negali būti galiojantis naudingosios apkrovos adresas, nes naudingoji apkrova yra bent jau lygiavertė kaip " RcBox (usize).
            ptr as *const T
        } else {
            // SAUGUMAS: jei " is_dangling` pateikia klaidingą reikšmę, žymeklį galima išskaičiuoti.
            // Šiuo metu naudingoji apkrova gali būti sumažinta, ir mes turime išlaikyti kilmę, todėl naudokite neapdorotų rodyklių manipuliavimą.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Suvartoja " `Weak<T>` ir paverčia jį neapdorotu žymekliu.
    ///
    /// Tai paverčia silpną rodyklę į neapdorotą rodyklę, tuo pačiu išsaugant vienos silpnosios nuorodos nuosavybės teisę (silpnosios vertės ši operacija nekeičia).
    /// Jį galima vėl paversti " `Weak<T>` su " [`from_raw`].
    ///
    /// Taikomi tie patys apribojimai, kaip pasiekti žymeklio taikinį, kaip ir naudojant [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Anksčiau [`into_raw`] sukurtą neapdorotą žymeklį paverčia atgal į `Weak<T>`.
    ///
    /// Tai gali būti naudojama norint saugiai gauti tvirtą nuorodą (paskambinus vėliau į [`upgrade`]) arba išspręsti silpną skaičių numetant " `Weak<T>`.
    ///
    /// Jis turi vienos silpnos nuorodos nuosavybę (išskyrus [`new`] sukurtus rodiklius, nes jiems nieko nepriklauso; metodas vis tiek veikia su jais).
    ///
    /// # Safety
    ///
    /// Rodyklė turi būti kilusi iš " [`into_raw`] ir vis tiek turi turėti galimą silpną atskaitos tašką.
    ///
    /// Šį skambinant leidžiama, kad stiprus skaičius būtų 0.
    /// Nepaisant to, tam priklauso viena silpna nuoroda, kuri šiuo metu pateikiama kaip neapdorotas rodyklė (silpnas skaičius šios operacijos nekeičia), todėl ją reikia susieti su ankstesniu skambučiu į [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Sumažinti paskutinį silpną skaičių.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Norėdami sužinoti įvesties žymeklį, žr. Weak::as_ptr.

        let ptr = if is_dangling(ptr as *mut T) {
            // Tai kabantys Silpni.
            ptr as *mut RcBox<T>
        } else {
            // Priešingu atveju mes garantuojame, kad rodyklė buvo iš niekuo neišsiskiriančio Silpno.
            // SAUGUMAS: " data_offset` yra saugu skambinti, nes ptr nurodo tikrąjį (potencialiai nukritusį) T.
            let offset = unsafe { data_offset(ptr) };
            // Taigi mes pakeičiame poslinkį, kad gautume visą RcBox.
            // SAUGUMAS: rodyklė atsirado iš silpno, todėl šis poslinkis yra saugus.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SAUGUMAS: mes dabar atkūrėme pradinį silpnojo žymeklio rodiklį, todėl galime sukurti silpnąjį.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Bandoma atnaujinti " `Weak` žymeklį į " [`Rc`], pavėlavus vidinės vertės sumažėjimą, jei pavyks.
    ///
    ///
    /// Pateikia [`None`], jei vidinė vertė nuo to laiko buvo sumažinta.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Sunaikink visus stiprius patarimus.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Gauna stiprių (`Rc`) žymeklių, nukreipiančių į šį paskirstymą, skaičių.
    ///
    /// Jei `self` buvo sukurtas naudojant [`Weak::new`], tai grąžins 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Gauna `Weak` žymeklių, nukreipiančių į šį paskirstymą, skaičių.
    ///
    /// Jei neliks jokių stiprių patarimų, tai grąžins nulį.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // atimkite numanomą silpną ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Pateikia `None`, kai rodyklė kabo ir nėra paskirto `RcBox` (ty kai `Weak` sukūrė `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Mes stengiamės *nekurti* nuorodos, apimančios lauką "data", nes laukas gali būti mutuojamas vienu metu (pvz., Jei metamas paskutinis " `Rc`, duomenų laukas bus atmestas vietoje).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Grąžina `true`, jei abu silpnieji nurodo tą patį paskirstymą (panašų į [`ptr::eq`]), arba jei abu nerodo jokio paskirstymo (nes jie buvo sukurti naudojant `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Kadangi tai lygina rodykles, tai reiškia, kad " `Weak::new()` prilygs vienas kitam, nors jie ir nerodo jokio paskirstymo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Lyginant `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Numeta `Weak` žymeklį.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nieko nespausdina
    /// drop(foo);        // Spausdina "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // silpnas skaičius prasideda nuo 1 ir nulis bus tik tada, jei dings visi stiprūs rodikliai.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Sukuria `Weak` žymeklio kloną, kuris nurodo tą patį paskirstymą.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Sukonstruoja naują " `Weak<T>`, priskirdamas atmintį " `T`, neinicijuodamas jos.
    /// Paskambinus į [`upgrade`] pagal grąžinimo vertę, visada gaunama [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Mes patikrinome_did čia, kad saugiai elgtumėtės su " mem::forget.Visų pirma
// jei naudojate " mem::forget Rcs`(arba " Weaks`), pakartotinis skaičiavimas gali perpildyti, tada galėsite nemokamai paskirstyti, kol yra neįvykdytų " Rcs`(arba " Weaks`).
//
// Mes nutraukiame, nes tai yra toks išsigimęs scenarijus, kad mums nerūpi, kas nutiks-jokia tikra programa niekada to neturėtų patirti.
//
// Tai turėtų turėti nereikšmingų pridėtinių išlaidų, nes iš tikrųjų nereikia daug klonuoti Rust dėl nuosavybės ir judėjimo semantikos.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Norime nutraukti perpildymą, užuot metę vertę.
        // Kai tai iškviečiama, atskaitos skaičius niekada nebus lygus nuliui;
        // nepaisant to, čia įterpiame nutraukimą, kad užsimintume LLVM apie kitaip praleistą optimizavimą.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Norime nutraukti perpildymą, užuot metę vertę.
        // Kai tai iškviečiama, atskaitos skaičius niekada nebus lygus nuliui;
        // nepaisant to, čia įterpiame nutraukimą, kad užsimintume LLVM apie kitaip praleistą optimizavimą.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Gauti poslinkį per `RcBox` už naudingąją apkrovą už rodyklės.
///
/// # Safety
///
/// Žymeklis turi nukreipti į anksčiau galiojantį T egzempliorių (ir turėti galiojančius jų metaduomenis), tačiau T leidžiama atsisakyti.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Sulygiuokite nedidžią vertę iki " RcBox` pabaigos.
    // Kadangi " RcBox` yra repr(C), jis visada bus paskutinis atminties laukas.
    // SAUGA: kadangi vieninteliai galimi nedideli tipai yra skiltelės, trait objektai,
    // ir išorinių tipų, įvesties saugos reikalavimas šiuo metu yra pakankamas, kad būtų patenkinti align_of_val_raw reikalavimai;tai yra kalbos, kuria negalima remtis už std ribų, įgyvendinimo detalės.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}