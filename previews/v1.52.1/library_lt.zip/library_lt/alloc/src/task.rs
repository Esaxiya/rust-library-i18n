#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipai ir Traits, skirti dirbti su asinchroninėmis užduotimis.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Vykdytojo budinčios užduoties įgyvendinimas.
///
/// Šis " trait`gali būti naudojamas kuriant " [`Waker`].
/// Vykdytojas gali apibrėžti šio " trait`įgyvendinimą ir naudoti jį sukurdamas " Waker`, kad jis perduotų užduotis, kurios vykdomos šiam vykdytojui.
///
/// Šis " trait` yra saugi atmintyje ir ergonomiška [`RawWaker`] sukūrimo alternatyva.
/// Jis palaiko bendrą vykdytojo dizainą, kuriame užduočiai pažadinti naudojami duomenys yra saugomi [`Arc`].
/// Kai kurie vykdytojai (ypač įdėtųjų sistemų atveju) negali naudoti šios API, todėl [`RawWaker`] egzistuoja kaip alternatyva toms sistemoms.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Pagrindinė " `block_on` funkcija, kuri užima " future` ir ją paleidžia iki galo naudodama esamą giją.
///
/// **Note:** Šis pavyzdys prekiauja teisingumu, kad būtų paprasčiau.
/// Kad būtų išvengta strigčių, gamybos lygio diegimas taip pat turės apdoroti tarpinius skambučius į `thread::unpark`, taip pat įdėtąsias iškvietas.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Budintojas, kuris pažadina esamą giją, kai iškviečiamas.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Paleiskite " future` iki galo dabartinėje gijoje.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Prisekite " future`, kad būtų galima apklausti.
///     let mut fut = Box::pin(fut);
///
///     // Sukurkite naują kontekstą, kuris bus perduotas " future`.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Paleiskite " future` iki galo.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Pažadink šią užduotį.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Atlikite šią užduotį nenaudodami budintojo.
    ///
    /// Jei vykdytojas palaiko pigesnį būdą pabusti nenaudodamas žadintuvo, jis turėtų pakeisti šį metodą.
    /// Pagal numatytuosius nustatymus jis klonuoja " [`Arc`] ir skambina į " [`wake`].
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SAUGA: Tai saugu, nes raw_waker saugiai konstruoja
        // " RawWaker`iš " Arc`<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ši privati " RawWaker` sukūrimo funkcija naudojama, o ne
// įterpiant tai į " `From<Arc<W>> for RawWaker` implą, siekiant užtikrinti, kad " `From<Arc<W>> for Waker` saugumas nepriklauso nuo teisingo " trait` išsiuntimo, vietoj to, abu implantai šią funkciją vadina tiesiogiai ir aiškiai.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Padidinkite lanko atskaitos skaičių, kad jį klonuotumėte.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Pažadinkite pagal vertę, perkeldami lanką į Wake::wake funkciją
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Pažadinkite atskaitos būdu, apvyniokite žadintuvą " ManuallyDrop`, kad jo nenumestumėte
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Sumažinkite lanko atskaitos skaičių kritus
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}