use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Parašyti integracijos testą tarp trečiųjų šalių paskirstytojų ir " `RawVec` yra šiek tiek keblu, nes " `RawVec` API neatskleidžia netinkamų paskirstymo metodų, todėl negalime patikrinti, kas nutinka, kai paskirstytojas yra išnaudotas (be to, kad nustatytume " panic`).
    //
    //
    // Vietoj to, tai tik patikrina, ar `RawVec` metodai bent jau eina per " Allocator` API, kai pasilieka saugyklą.
    //
    //
    //
    //
    //

    // Nebylys paskirstytojas, kuris sunaudoja fiksuotą degalų kiekį, prieš pradedant bandyti paskirstyti.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (sukelia perskirstymą, taigi sunaudojama 50 + 150=200 vienetų kuro)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Pirma, " `reserve` paskirsto kaip " `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 yra daugiau nei dvigubai didesnis už 7, todėl " `reserve` turėtų veikti kaip " `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 yra mažiau nei pusė 12, todėl `reserve` turi augti eksponentiškai.
        // Rašant šį testą, augimo koeficientas yra 2, taigi naujas pajėgumas yra 24, tačiau 1.5 augimo koeficientas taip pat yra tinkamas.
        //
        // Taigi tvirtina `>= 18`.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}