//! Dinamiško dydžio vaizdas į gretimą seką, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Skiltelės yra vaizdas į atminties bloką, vaizduojamas kaip žymeklis ir ilgis.
//!
//! ```
//! // pjaustydamas Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // priverčiant masyvą į gabalą
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Skiltelės yra keičiamos arba bendrinamos.
//! Bendro segmento tipas yra `&[T]`, o keičiamo segmento tipas yra `&mut [T]`, kur `T` reiškia elemento tipą.
//! Pvz., Galite pakoreguoti atminties bloką, į kurį nukreipiama keičiama dalis:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Štai keletas dalykų, kuriuos sudaro šis modulis:
//!
//! ## Structs
//!
//! Yra keletas struktūrų, kurios yra naudingos skiltelėms, pvz., [`Iter`], kuri rodo iteraciją virš griežinėlio.
//!
//! ## Trait įgyvendinimas
//!
//! Yra keletas įprastų " traits` griežinėliams pritaikymų.Keletas pavyzdžių:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], skiltelėms, kurių elementų tipas yra [`Eq`] arba [`Ord`].
//! * [`Hash`] - griežinėliams, kurių elementų tipas yra [`Hash`].
//!
//! ## Iteration
//!
//! Skiltelės įgyvendina `IntoIterator`.Kartotojas pateikia nuorodas į gabalo elementus.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Kintamas gabalas pateikia kintamas nuorodas į elementus:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Šis iteratorius pateikia kintamas nuorodas į gabalo elementus, taigi, jei elemento tipas yra `i32`, iteratoriaus elemento tipas yra `&mut i32`.
//!
//!
//! * [`.iter`] ir [`.iter_mut`] yra aiškūs metodai grąžinti numatytuosius iteratorius.
//! * Kiti iteratorius grąžinantys metodai yra [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ir dar daugiau.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Daugelis šio modulio naudojimo būdų naudojami tik bandymo konfigūracijoje.
// Švariau tiesiog išjungti nepanaudotą_importo įspėjimą, nei juos pašalinti.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Pagrindiniai riekelių išplėtimo metodai
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) reikalingas `vec!` makrokomandai įgyvendinti bandant NB, daugiau informacijos rasite šio failo `hack` modulyje.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) reikalingas norint įdiegti " `Vec::clone` bandant NB, daugiau informacijos rasite šio failo `hack` modulyje.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Naudojant " cfg(test), " `impl [T]` nėra, šios trys funkcijos yra metodai, kurie yra " `impl [T]`, bet ne " `core::slice::SliceExt`, šias funkcijas turime pateikti `test_permutations` testui atlikti
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Mes neturėtume pridėti to atributo, nes jis dažniausiai naudojamas " `vec!` makrokomandoje ir sukelia tobulą regresiją.
    // Žr. #71204 diskusijoms ir geriausiems rezultatams.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // elementai buvo pažymėti inicializuoti žemiau esančioje kilpoje
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) yra būtinas, kad LLVM pašalintų ribų patikrinimus ir turi geresnį kodegeną nei ZIP.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // buvo paskirtas ir inicializuotas aukščiau bent tokio ilgio.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // priskirtas aukščiau, kai talpa yra `s`, ir inicijuokite iki `s.len()` žemiau esančiame ptr::copy_to_non_overlapping.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Rūšiuoja riekelę.
    ///
    /// Ši rūšis yra stabili (ty neperorganizuoja vienodų elementų) ir *O*(*n*\*log(* n*)) blogiausiu atveju.
    ///
    /// Kai taikoma, pirmenybė teikiama nestabiliam rūšiavimui, nes jis paprastai yra greitesnis nei stabilus rūšiavimas ir nepaskirsto pagalbinės atminties.
    /// Žr. " [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Dabartinis įgyvendinimas
    ///
    /// Dabartinis algoritmas yra adaptyvus, iteracinis sujungimo rūšis, įkvėptas [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Jis sukurtas taip, kad būtų labai greitas tais atvejais, kai pjūvis yra beveik surūšiuotas arba susideda iš dviejų ar daugiau surūšiuotų sekų, sujungtų vienas po kito.
    ///
    ///
    /// Be to, ji skiria laikiną saugyklą, kuri yra pusė dydžio, palyginti su " `self`, tačiau trumpiems griežinėliams vietoj to naudojamas nepaskirstantis įterpimo rūšiavimas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Rūšiuoja gabalą su lyginamąja funkcija.
    ///
    /// Ši rūšis yra stabili (ty neperorganizuoja vienodų elementų) ir *O*(*n*\*log(* n*)) blogiausiu atveju.
    ///
    /// Lyginamoji funkcija turi apibrėžti bendrą elementų išdėstymą pjūvyje.Jei užsakymas nėra visas, elementų eiliškumas nenurodytas.
    /// Užsakymas yra visas užsakymas, jei jis yra (visiems `a`, `b` ir `c`):
    ///
    /// * visiškas ir antisimetriškas: teisingas yra tiksliai vienas iš `a < b`, `a == b` arba `a > b` ir
    /// * tranzityvus, `a < b` ir `b < c` reiškia `a < c`.Tas pats turi galioti ir `==`, ir `>`.
    ///
    /// Pavyzdžiui, nors " [`f64`] neįdiegia " [`Ord`], nes " `NaN != NaN`, mes galime naudoti " `partial_cmp` kaip rūšiavimo funkciją, kai žinome, kad gabalėlyje nėra " `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Kai taikoma, pirmenybė teikiama nestabiliam rūšiavimui, nes jis paprastai yra greitesnis nei stabilus rūšiavimas ir nepaskirsto pagalbinės atminties.
    /// Žr. " [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Dabartinis įgyvendinimas
    ///
    /// Dabartinis algoritmas yra adaptyvus, iteracinis sujungimo rūšis, įkvėptas [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Jis sukurtas taip, kad būtų labai greitas tais atvejais, kai pjūvis yra beveik surūšiuotas arba susideda iš dviejų ar daugiau surūšiuotų sekų, sujungtų vienas po kito.
    ///
    /// Be to, ji skiria laikiną saugyklą, kuri yra pusė dydžio, palyginti su " `self`, tačiau trumpiems griežinėliams vietoj to naudojamas nepaskirstantis įterpimo rūšiavimas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // atvirkštinis rūšiavimas
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Rūšiuoja gabalėlį su rakto ištraukimo funkcija.
    ///
    /// Ši rūšis yra stabili (ty neperorganizuoja vienodų elementų) ir *O*(*m*\* * n *\* log(*n*)) blogiausiu atveju, kai pagrindinė funkcija yra *O*(*m*).
    ///
    /// Brangioms pagrindinėms funkcijoms (pvz.,
    /// funkcijos, kurios nėra paprastos prieigos prie nuosavybės ar pagrindinės operacijos), [`sort_by_cached_key`](slice::sort_by_cached_key) greičiausiai bus žymiai greitesnis, nes neperskaičiuoja elementų raktų.
    ///
    ///
    /// Kai taikoma, pirmenybė teikiama nestabiliam rūšiavimui, nes jis paprastai yra greitesnis nei stabilus rūšiavimas ir nepaskirsto pagalbinės atminties.
    /// Žr. " [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Dabartinis įgyvendinimas
    ///
    /// Dabartinis algoritmas yra adaptyvus, iteracinis sujungimo rūšis, įkvėptas [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Jis sukurtas taip, kad būtų labai greitas tais atvejais, kai pjūvis yra beveik surūšiuotas arba susideda iš dviejų ar daugiau surūšiuotų sekų, sujungtų vienas po kito.
    ///
    /// Be to, ji skiria laikiną saugyklą, kuri yra pusė dydžio, palyginti su " `self`, tačiau trumpiems griežinėliams vietoj to naudojamas nepaskirstantis įterpimo rūšiavimas.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Rūšiuoja gabalėlį su rakto ištraukimo funkcija.
    ///
    /// Rūšiuojant klavišo funkcija kiekvienam elementui iškviečiama tik vieną kartą.
    ///
    /// Ši rūšis yra stabili (ty neperorganizuoja vienodų elementų) ir *O*(*m*\* * n *+* n *\* log(*n*)) blogiausiu atveju, kai pagrindinė funkcija yra *O*(*m*) .
    ///
    /// Paprastoms pagrindinėms funkcijoms (pvz., Funkcijoms, kurios yra prieigos prie nuosavybės ar pagrindinės operacijos), [`sort_by_key`](slice::sort_by_key) greičiausiai bus greitesnis.
    ///
    /// # Dabartinis įgyvendinimas
    ///
    /// Dabartinis algoritmas yra pagrįstas Orsono Peterso [pattern-defeating quicksort][pdqsort], kuris sujungia greitą atsitiktinių imčių rūšies vidutinį atvejį su greičiausiu blogiausiu " heapsort` atveju, tuo pačiu metu pasiekdamas linijinį laiką su tam tikrų modelių pjūviais.
    /// Norint išvengti degeneracinių atvejų, naudojamas tam tikras atsitiktinių imčių pasirinkimas, tačiau naudojant fiksuotą seed visada užtikrinamas deterministinis elgesys.
    ///
    /// Blogiausiu atveju algoritmas `Vec<(K, usize)>` skirsto laikiną saugyklą pjūvio ilgiu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Pagalbinė makrokomanda indeksuojant mūsų vector pagal mažiausią įmanomą tipą, siekiant sumažinti paskirstymą.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // " `indices` elementai yra unikalūs, nes yra indeksuojami, todėl bet kokia rūšis bus stabili, palyginti su pradine dalimi.
                // Čia mes naudojame " `sort_unstable`, nes tam reikia mažiau atminties.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Nukopijuoja " `self` į naują " `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Čia `s` ir `x` galima modifikuoti savarankiškai.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Nukopijuoja `self` į naują `Vec` su paskirstytoju.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Čia `s` ir `x` galima modifikuoti savarankiškai.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, daugiau informacijos rasite `hack` modulyje šiame faile.
        hack::to_vec(self, alloc)
    }

    /// `self` paverčia vector be klonų ar paskirstymo.
    ///
    /// Gautą vector galima konvertuoti atgal į dėžę per `Vec<T>`into_boxed_slice` metodas.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` nebegalima naudoti, nes jis buvo konvertuotas į `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, daugiau informacijos rasite `hack` modulyje šiame faile.
        hack::into_vec(self)
    }

    /// Sukuria vector, pakartodamas `n` dalį.
    ///
    /// # Panics
    ///
    /// Ši funkcija bus panic, jei pajėgumai perpildytų.
    ///
    /// # Examples
    ///
    /// Pagrindinis naudojimas:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic persipildžius:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Jei `n` yra didesnis nei nulis, jį galima padalyti kaip `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` yra skaičius, nurodytas kairiausiu '1' bitu `n`, o `rem` yra likusi `n` dalis.
        //
        //

        // `Vec` naudojimas norint pasiekti `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` kartojimas atliekamas padvigubinant `buf` " expn` kartus.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Jei `m > 0`, likę bitai iki kairiausio '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` turi `self.len() * n` talpą.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) kartojimas atliekamas nukopijuojant pirmuosius `rem` pakartojimus iš pačios `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Tai nesutampa nuo `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` lygus `buf.capacity()` (" = self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Išlygina `T` gabalėlį į vieną `Self::Output` vertę.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Išlygina `T` griežinėlį į vieną vertę `Self::Output`, tarp jų įdėdamas tam tikrą separatorių.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Išlygina `T` griežinėlį į vieną vertę `Self::Output`, tarp jų įdėdamas tam tikrą separatorių.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Pateikia vector, kuriame yra šio griežinėlio kopija, kur kiekvienas baitas priskiriamas jo ASCII didžiųjų raidžių atitikmeniui.
    ///
    ///
    /// ASCII raidės 'a' - 'z' susiejamos su 'A' - 'Z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje didinti vertę, naudokite [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Pateikia vector, kuriame yra šio gabalo kopija, kur kiekvienas baitas priskiriamas jo ASCII mažųjų raidžių atitikmeniui.
    ///
    ///
    /// ASCII raidės 'A' - 'Z' susiejamos su 'a' - 'z', tačiau ne ASCII raidės nesikeičia.
    ///
    /// Jei norite vietoje mažinti vertę, naudokite [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// traits plėtinys, skirtas gabalėliams per tam tikros rūšies duomenis
////////////////////////////////////////////////////////////////////////////////

/// Pagalbininkas trait [[T]: : concat`](griežinėlis::concat).
///
/// Note: `Item` tipo parametras šiame trait nenaudojamas, tačiau jis leidžia implikams būti bendresniems.
/// Be jo gauname šią klaidą:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Taip yra todėl, kad gali būti `V` tipų su keletu `Borrow<[_]>` implikų, kad būtų taikomi keli `T` tipai:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Gautas tipas po sujungimo
    type Output;

    /// [[T]: : concat`](griežinėlis::concat) įgyvendinimas
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Pagalbininkas trait [[T]: : prisijungti]](griežinėlis::prisijungti)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Gautas tipas po sujungimo
    type Output;

    /// [[T]: : join`] įgyvendinimas (dalis::prisijungti)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standartiniai " trait` griežinėlių diegimai
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // numeskite į taikinį viską, kas nebus perrašyta
        target.truncate(self.len());

        // target.len <= self.len dėl aukščiau pateikto sutrumpinimo, todėl skiltelės čia visada yra ribos.
        //
        let (init, tail) = self.split_at(target.len());

        // pakartotinai naudokite nurodytas reikšmes " allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Įterpia `v[0]` į iš anksto surūšiuotą `v[1..]` seką, kad visas `v[..]` taptų rūšiuojamas.
///
/// Tai yra neatskiriama įterpimo rūšiavimo paprogramė.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Čia yra trys įterpimo būdai:
            //
            // 1. Keiskite gretimus elementus, kol pirmasis pateks į galutinę paskirties vietą.
            //    Tačiau tokiu būdu mes duomenis kopijuojame daugiau nei reikia.
            //    Jei elementai yra didelės struktūros (brangu kopijuoti), šis metodas bus lėtas.
            //
            // 2. Kartokite tol, kol bus surasta tinkama vieta pirmajam elementui.
            // Tada perkelkite elementus, kad pavyktų, kad atsirastų vietos, ir galiausiai įdėkite jį į likusią skylę.
            // Tai yra geras metodas.
            //
            // 3. Nukopijuokite pirmąjį elementą į laikiną kintamąjį.Kartokite tol, kol bus surasta tinkama jai vieta.
            // Eidami toliau, nukopijuokite kiekvieną įveiktą elementą į prieš jį esančią angą.
            // Galiausiai nukopijuokite duomenis iš laikino kintamojo į likusią skylę.
            // Šis metodas yra labai geras.
            // Lyginamieji indeksai parodė šiek tiek geresnį našumą nei taikant 2-ąjį metodą.
            //
            // Visi metodai buvo lyginami, o 3-asis rodė geriausius rezultatus.Taigi mes pasirinkome tą.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Tarpinę įterpimo būseną visada stebi " `hole`, kuri turi du tikslus:
            // 1. Apsaugo `v` vientisumą nuo panics `is_less`.
            // 2. Galų gale užpildo likusią skylę `v`.
            //
            // Panic sauga:
            //
            // Jei `is_less` panics bet kuriame proceso etape, `hole` nukris ir užpildys skylę `v` `tmp`, taip užtikrindamas, kad `v` vis tiek laiko visus objektus, kuriuos iš pradžių laikė tiksliai vieną kartą.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` nukrenta ir taip nukopijuoja `tmp` į likusią skylę `v`.
        }
    }

    // Nukritus kopijoms iš `src` į `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Sujungia nemažėjančius " `v[..mid]` ir " `v[mid..]` paleidimus, naudodamas `buf` kaip laikiną saugyklą, ir išsaugo rezultatą `v[..]`.
///
/// # Safety
///
/// Dvi skiltelės turi būti ne tuščios, o `mid` turi būti ribos.
/// Buferis `buf` turi būti pakankamai ilgas, kad tilptų trumpesnio gabalo kopiją.
/// Be to, " `T` neturi būti nulinio dydžio tipas.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Sujungimo procesas pirmiausia nukopijuoja trumpesnį paleidimą į `buf`.
    // Tada jis atseka naujai nukopijuotą bėgimą ir ilgesnį bėgimą pirmyn (arba atgal), palygindamas jų kitus nenaudojamus elementus ir nukopijuodamas mažesnįjį (arba didesnį) į `v`.
    //
    // Kai tik trumpesnis važiavimas bus visiškai sunaudotas, procesas bus baigtas.Jei ilgesnis bėgimas iš pradžių sunaudojamas, turime nukopijuoti viską, kas liko nuo trumpesnio važiavimo, į likusią `v` skylę.
    //
    // Tarpinę proceso būseną visada stebi " `hole`, kuri turi du tikslus:
    // 1. Apsaugo `v` vientisumą nuo panics `is_less`.
    // 2. Užpildo likusią " `v` skylę, jei pirmiausia suvartojama ilgesnė eiga.
    //
    // Panic sauga:
    //
    // Jei `is_less` panics bet kuriame proceso etape, `hole` nukris ir užpildys skylę `v` nepanaudotu diapazonu `buf`, taip užtikrindamas, kad `v` vis tiek laiko visus objektus, kuriuos iš pradžių laikė tiksliai vieną kartą.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Kairysis bėgimas yra trumpesnis.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Iš pradžių šie rodyklės nurodo jų masyvų pradžią.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Vartokite mažesnę pusę.
            // Jei vienodas, pirmenybę teikite kairiam bėgimui, kad išlaikytumėte stabilumą.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Teisingas bėgimas yra trumpesnis.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Iš pradžių šie rodyklės nurodo jų masyvų galus.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Suvartokite didesnę pusę.
            // Jei vienodas, pirmenybę teikite tinkamam bėgimui, kad išlaikytumėte stabilumą.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Galiausiai, `hole` nukrenta.
    // Jei trumpesnis važiavimas nebuvo išnaudotas iki galo, visi jo likučiai dabar bus nukopijuoti į `v` skylę.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Nukritęs nukopijuoja diapazoną `start..end` į `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` nėra nulinio dydžio tipas, todėl skirstyti iš jo dydžio tinka.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ši jungimo rūšis pasiskolina keletą (bet ne visų) " TimSort` idėjų, kurios išsamiai aprašytos [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritmas identifikuoja griežtai mažėjančias ir nenusileidžiančias sekmes, kurios vadinamos natūraliais bėgimais.Dar nėra sujungtų laukiančių eilučių.
/// Kiekvienas naujai surastas važiavimas stumiamas ant kamino, o tada sujungiamos kelios gretimų eigų poros, kol bus patenkinti šie du invariantai:
///
/// 1. kiekvienam `i` `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. kiekvienam `i` `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invariantai užtikrina, kad bendras veikimo laikas yra *O*(*n*\*log(* n*)) blogiausiu atveju.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Iki tokio ilgio skiltelės rūšiuojamos naudojant įterpimo rūšiavimą.
    const MAX_INSERTION: usize = 20;
    // Labai trumpi bandymai pratęsiami naudojant įterpimo rūšiavimą, kad apimtų bent tiek elementų.
    const MIN_RUN: usize = 10;

    // Rūšiavimas neturi prasmingo elgesio su nulio dydžio tipais.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Trumpi masyvai rūšiuojami vietoje per įterpimo rūšį, kad būtų išvengta paskirstymo.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Paskirkite buferį, kurį naudosite kaip įbrėžtinę atmintį.Mes išlaikome 0 ilgį, kad galėtume jame laikyti negilias `v` turinio kopijas, nerizikuodami, kad `is_less` panics veiktų gydytojai.
    //
    // Sujungiant du surūšiuotus važiavimus, šiame buferyje yra trumpesnio laikotarpio kopija, kurios ilgis visada bus ne didesnis kaip `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Norėdami nustatyti natūralius važiavimus " `v`, mes jį einame atgal.
    // Tai gali atrodyti keistas sprendimas, tačiau atsižvelkite į tai, kad susijungimai dažniau vyksta priešinga kryptimi (forwards).
    // Pagal etalonus jungimasis į priekį yra šiek tiek greitesnis nei atgal.
    // Apibendrinant galima pasakyti, kad bėgimų atpažinimas važiuojant atgal pagerina našumą.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Raskite kitą natūralų bėgimą ir pakeiskite jį, jei jis griežtai mažėja.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Įveskite dar keletą elementų į bėgimą, jei jis per trumpas.
        // Įterpimo rūšiavimas yra greitesnis nei sujungimo rūšiavimas trumpose sekose, todėl tai žymiai pagerina našumą.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Pastumkite šį bėgimą ant kamino.
        runs.push(Run { start, len: end - start });
        end = start;

        // Sujunkite keletą gretimų bėgimų porų, kad patenkintumėte invariantus.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Galiausiai, šūsnyje turi likti tiksliai vienas važiavimas.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Nagrinėja važiavimo šūsnį ir nustato kitą sujungtų eilučių porą.
    // Tiksliau sakant, jei grąžinama `Some(r)`, tai reiškia, kad vėliau `runs[r]` ir `runs[r + 1]` turi būti sujungtos.
    // Jei vietoj to algoritmas turėtų tęsti naują paleidimą, grąžinama `None`.
    //
    // " TimSort` yra liūdnai pagarsėjęs dėl savo klaidų diegimo, kaip aprašyta čia:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Istorijos esmė yra tokia: mes privalome priversti invariantus iš keturių didžiausių rietuvės eilučių.
    // Neužtenka jų vykdyti tik pirmajame trejete, kad būtų užtikrinta, jog invariantai vis tiek laikysis *visų* važiavimų.
    //
    // Ši funkcija teisingai tikrina invariantus keturis geriausius važiavimus.
    // Be to, jei viršutinis bandymas prasideda nuo indekso 0, jis visada reikalaus suliejimo operacijos, kol krūva bus visiškai sugriuvusi, kad būtų baigtas rūšiavimas.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}