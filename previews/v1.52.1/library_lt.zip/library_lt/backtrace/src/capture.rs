use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Atvaizduojamas turimas ir savarankiškas atgalinis pėdsakas.
///
/// Ši struktūra gali būti naudojama užfiksuoti atgalinį atspaudą įvairiuose programos taškuose, o vėliau naudoti norint patikrinti, kas tuo metu buvo atgalinis pėdsakas.
///
///
/// `Backtrace` palaiko gražų atgalinių pėdsakų spausdinimą per jo `Debug` diegimą.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rėmeliai pateikiami nuo rietuvės viršaus iki apačios
    frames: Vec<BacktraceFrame>,
    // Indeksas, kuris, mūsų manymu, yra tikroji " backtrace` pradžia, praleidžiant kadrus, tokius kaip `Backtrace::new` ir `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Užfiksuota kadro versija " backtrace`.
///
/// Šis tipas grąžinamas iš " `Backtrace::frames` kaip sąrašas ir atspindi vieną kamino rėmą užfiksuotame " backtrace`.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Užfiksuota simbolio versija " backtrace`.
///
/// Šis tipas grąžinamas iš " `BacktraceFrame::symbols` kaip sąrašas ir žymi atgalinio pėdsako simbolio metaduomenis.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Užfiksuoja šios funkcijos iškvietą skambučio vietoje ir grąžina priklausantį atstovavimą.
    ///
    /// Ši funkcija yra naudinga vaizduojant atgalinį pėdsaką kaip objektą Rust.Ši grąžinta vertė gali būti siunčiama per gijas ir atspausdinta kitur, ir šios vertės tikslas yra būti visiškai savarankiška.
    ///
    /// Atkreipkite dėmesį, kad kai kuriose platformose įgyti visišką grįžtamąjį ryšį ir jį išspręsti gali būti labai brangu.
    /// Jei jūsų programos kaina yra per didelė, rekomenduojama vietoj to naudoti " `Backtrace::new_unresolved()`, kad būtų išvengta simbolių skyrimo veiksmo (kuris paprastai trunka ilgiausiai) ir leidžia jį atidėti vėliau.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // norite įsitikinti, kad čia yra rėmelis, kurį reikia pašalinti
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Panašiai kaip " `new`, išskyrus tai, kad tai neišsprendžia jokių simbolių, tai tiesiog užfiksuoja " backtrace` kaip adresų sąrašą.
    ///
    /// Vėliau bus galima iškviesti `resolve` funkciją, kad šios " backtrace` simboliai būtų paversti skaitomais pavadinimais.
    /// Ši funkcija egzistuoja todėl, kad skiriamoji geba kartais gali užtrukti daug laiko, o bet koks atgalinis pėdsakas gali būti spausdinamas tik retai.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // jokių simbolių pavadinimų
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // dabar yra simbolių pavadinimų
    /// ```
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    ///
    #[inline(never)] // norite įsitikinti, kad čia yra rėmelis, kurį reikia pašalinti
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Grąžina rėmelius nuo tada, kai buvo užfiksuotas šis atgalinis pėdsakas.
    ///
    /// Pirmasis šio gabalo įrašas greičiausiai yra funkcija `Backtrace::new`, o paskutinis kadras greičiausiai yra kažkas apie tai, kaip prasidėjo ši gija ar pagrindinė funkcija.
    ///
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Jei šis atgalinis pėdsakas buvo sukurtas iš " `new_unresolved`, ši funkcija išspręs visus atgalinio pėdsako adresus pagal jų simbolinius pavadinimus.
    ///
    ///
    /// Jei ši " backtrace`sistema jau buvo išspręsta arba sukurta naudojant " `new`, ši funkcija nieko nedaro.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Tas pats kaip `Frame::ip`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Tas pats kaip `Frame::symbol_address`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Tas pats kaip `Frame::module_base_address`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Grąžina simbolių, kuriuos atitinka šis rėmelis, sąrašą.
    ///
    /// Paprastai kadre yra tik vienas simbolis, tačiau kartais, jei į vieną kadrą įterpiama keletas funkcijų, bus grąžinti keli simboliai.
    /// Pirmasis nurodytas simbolis yra "innermost function", o paskutinis simbolis yra tolimiausias (paskutinis skambinantysis).
    ///
    /// Atkreipkite dėmesį, kad jei šis kadras atsirado iš neišspręstos atgalinės sekos, tada bus pateiktas tuščias sąrašas.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Tas pats kaip `Symbol::name`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Tas pats kaip `Symbol::addr`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Tas pats kaip `Symbol::filename`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Tas pats kaip `Symbol::lineno`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Tas pats kaip `Symbol::colno`
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Spausdindami kelius, mes bandome nuimti cwd, jei jis yra, kitaip mes tiesiog atspausdiname kelią tokį, koks yra.
        // Atkreipkite dėmesį, kad tai darome tik dėl trumpo formato, nes jei jis pilnas, mes tikriausiai norime atsispausdinti viską.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}