#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formatas atgalinėms trasoms.
///
/// Šis tipas gali būti naudojamas atspausdinti atgalinį pėdsaką, neatsižvelgiant į tai, iš kur yra pats atgalinis pėdsakas.
/// Jei turite `Backtrace` tipą, jo `Debug` diegimas jau naudoja šį spausdinimo formatą.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Spausdinimo stiliai, kuriuos galime spausdinti
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Spausdina " Terser backtrace`, kuriame idealiu atveju yra tik svarbi informacija
    Short,
    /// Spausdina atgalinį pėdsaką, kuriame yra visa įmanoma informacija
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Sukurkite naują `BacktraceFmt`, kuris įrašys išvestį į pateiktą `fmt`.
    ///
    /// `format` argumentas valdys stilių, kuriuo atspausdinama atgalinė linija, o `print_path` argumentas bus naudojamas spausdinant failų pavadinimų `BytesOrWideString` egzempliorius.
    /// Pats šio tipo failų pavadinimai nespausdinami, tačiau norint tai padaryti reikia šio atgalinio skambučio.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Išspausdinama prieš spausdinamo atgalinio kelio preambulė.
    ///
    /// Tai reikalinga kai kuriose platformose, kad vėliau būtų visiškai simbolizuojami atgaliniai pėdsakai, o priešingu atveju tai turėtų būti tik pirmasis būdas, kurį paskambinsite sukūrę " `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Pridedamas rėmas prie " backtrace` išvesties.
    ///
    /// Šis įsipareigojimas grąžina RA00 `BacktraceFrameFmt` egzempliorių, kurį galima naudoti faktiškai kadrui atspausdinti, o sunaikinus jis padidins kadrų skaitiklį.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Baigiama " backtrace` išvestis.
    ///
    /// Šiuo metu tai neveikia, bet pridedama dėl " future`suderinamumo su " backtrace` formatais.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Šiuo metu nėra opcijos, įskaitant šį " hook`, kad būtų galima papildyti " future`.
        Ok(())
    }
}

/// Formatatorius, skirtas tik vienam " backtrace` kadrui.
///
/// Šį tipą sukuria funkcija `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Spausdina " `BacktraceFrame` su šiuo kadro formatu.
    ///
    /// Tai rekursyviai atspausdins visas `BacktraceFrame` egzempliorius.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Spausdina `BacktraceSymbol` per `BacktraceFrame`.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: tai nėra puiku, kad mes nieko nespausdiname
            // su ne utf8 failų pavadinimais.
            // Laimei, beveik viskas yra " utf8, todėl tai neturėtų būti labai blogai.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Spausdina neapdorotus atsekamus `Frame` ir `Symbol`, paprastai iš neapdorotų šio crate skambučių.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Prie " backtrace` išvesties pridedamas neapdorotas rėmelis.
    ///
    /// Šis metodas, skirtingai nei ankstesnis, pateikia neapdorotus argumentus, jei jie yra šaltiniai iš skirtingų vietų.
    /// Atminkite, kad vienam kadrui tai gali būti skambinama kelis kartus.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Prie " backtrace` išvesties pridedamas neapdorotas rėmas, įskaitant stulpelių informaciją.
    ///
    /// Šis metodas, kaip ir ankstesnis, apima neapdorotus argumentus, jei jie yra šaltiniai iš skirtingų vietų.
    /// Atminkite, kad vienam kadrui tai gali būti skambinama kelis kartus.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuksija negali simbolizuoti proceso metu, todėl ji turi specialų formatą, kurį vėliau galima naudoti simbolizuojant.
        // Čia atspausdinkite, užuot spausdinę adresus savo formatu.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nereikia spausdinti " "null" rėmelių, tai iš esmės reiškia tik tai, kad sistemos grįžtamasis ryšys buvo šiek tiek noras atsekti labai toli.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Norėdami sumažinti TCB dydį " Sgx` anklave, nenorime įdiegti simbolių skiriamosios gebos funkcionalumo.
        // Atvirkščiai, čia galime atspausdinti adreso poslinkį, kurį vėliau galima susieti su tikslia funkcija.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Atspausdinkite rėmelio rodyklę ir papildomą rėmelio instrukcijų rodyklę.
        // Jei mes peržengiame pirmąjį šio kadro simbolį, nors mes tiesiog atspausdiname tinkamą tarpą.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Toliau parašykite simbolio pavadinimą, jei norite gauti daugiau informacijos, naudodami alternatyvų formatą, jei esame visiška atsekamybė.
        // Čia mes taip pat tvarkome simbolius, kurie neturi pavadinimo,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ir paskutinį kartą atsispausdinkite filename/line numerį, jei jis yra.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line yra atspausdintos ant linijų po simbolio pavadinimu, todėl atspausdinkite tam tikrą tarpą, norėdami lyginti save.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Jei norite atsispausdinti failo pavadinimą ir išspausdinti eilutės numerį, perkelkite į mūsų vidinį atgalinį skambutį.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Pridėkite stulpelio numerį, jei toks yra.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Mums rūpi tik pirmasis kadro simbolis
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}