use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Išspręskite adresą į simbolį, perduodant simbolį nurodytam uždarymui.
///
/// Ši funkcija ieškos nurodyto adreso tokiose srityse kaip vietinė simbolių lentelė, dinaminių simbolių lentelė arba DWARF derinimo informacija (priklausomai nuo suaktyvinto diegimo), kad surastų simbolių, kuriuos būtų galima gauti.
///
///
/// Uždarymo negalima iškviesti, jei nepavyko išspręsti, taip pat jis gali būti iškviestas daugiau nei vieną kartą įterptinių funkcijų atveju.
///
/// Pateikti simboliai nurodo vykdymą nurodytu `addr`, grąžinant file/line poras tam adresui (jei yra).
///
/// Atminkite, kad jei turite " `Frame`, rekomenduojama naudoti " `resolve_frame` funkciją, o ne šią.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
/// # Panics
///
/// Ši funkcija siekia, kad panic niekada nebūtų, tačiau jei `cb` pateikė panics, kai kurios platformos privers dvigubą panic nutraukti procesą.
/// Kai kurios platformos naudoja C biblioteką, kuri viduje naudoja atgalinius skambučius, kurių negalima atsukti, todėl panika nuo " `cb` gali sukelti proceso nutraukimą.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // žiūrėkite tik į viršutinį rėmą
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Anksčiau užfiksuotą rėmelį išspręskite simboliui, perduodant simbolį nurodytam uždarymui.
///
/// Šis functinas atlieka tą pačią funkciją kaip ir `resolve`, išskyrus tai, kad vietoj adreso jis argumentu laiko `Frame`.
/// Tai gali leisti kai kurioms platformoms įdiegti atgalinį sekimą, kad būtų galima pateikti tikslesnę informaciją apie simbolius arba, pavyzdžiui, informaciją apie vidinius rėmus.
///
/// Rekomenduojama tai naudoti, jei galite.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
/// # Panics
///
/// Ši funkcija siekia, kad panic niekada nebūtų, tačiau jei `cb` pateikė panics, kai kurios platformos privers dvigubą panic nutraukti procesą.
/// Kai kurios platformos naudoja C biblioteką, kuri viduje naudoja atgalinius skambučius, kurių negalima atsukti, todėl panika nuo " `cb` gali sukelti proceso nutraukimą.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // žiūrėkite tik į viršutinį rėmą
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP vertės iš rietuvių rėmelių paprastai yra (always?) nurodymas *po* skambučio, kuris yra tikrasis kamino pėdsakas.
// Simbolizuojant tai, filename/line numeris bus vienas priekyje ir galbūt tuštumas, jei jis artėja prie funkcijos pabaigos.
//
// Atrodo, kad tai iš esmės visada yra visose platformose, todėl mes visada atimame vieną iš išspręsto ip, kad išspręstume jį ankstesnėje skambučio instrukcijoje, o ne prie nurodymo, į kurį grąžinama.
//
//
// Idealiu atveju mes to nedarytume.
// Idealiu atveju reikalautume, kad čia skambinantieji iš `resolve` API rankiniu būdu atliktų " -1 ir nurodytų, kad jie nori buvimo vietos informacijos pagal *ankstesnę* instrukciją, o ne dabartinę.
// Idealiu atveju mes taip pat parodytume `Frame`, jei iš tikrųjų esame kitos instrukcijos arba dabartinės adresas.
//
// Kol kas tai yra gana nišinis rūpestis, todėl mes tiesiog viduje visada atimame vieną.
// Vartotojai turėtų toliau dirbti ir pasiekti gana gerų rezultatų, todėl turėtume būti pakankamai geri.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Tas pats kaip " `resolve`, nesaugus, nes nesinchronizuotas.
///
/// Ši funkcija neturi sinchronizavimo garantijų, tačiau yra prieinama, kai šio crate funkcija `std` nėra sukompiliuota.
/// Daugiau dokumentų ir pavyzdžių rasite funkcijoje `resolve`.
///
/// # Panics
///
/// Žr. Informaciją apie `resolve` apie įspėjimus dėl panikos `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Tas pats kaip " `resolve_frame`, nesaugus, nes nesinchronizuotas.
///
/// Ši funkcija neturi sinchronizavimo garantijų, tačiau yra prieinama, kai šio crate funkcija `std` nėra sukompiliuota.
/// Daugiau dokumentų ir pavyzdžių rasite funkcijoje `resolve_frame`.
///
/// # Panics
///
/// Žr. Informaciją apie `resolve_frame` apie įspėjimus dėl panikos `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, žymintis failo simbolio skiriamąją gebą.
///
/// Šis " trait`suteikiamas kaip " trait` objektas uždarymui, suteiktam `backtrace::resolve` funkcijai, ir jis praktiškai išsiunčiamas, nes nežinoma, kuris įgyvendinimas yra už jo.
///
///
/// Simbolis gali suteikti kontekstinę informaciją apie funkciją, pavyzdžiui, pavadinimą, failo pavadinimą, eilutės numerį, tikslų adresą ir kt.
/// Ne visa informacija visada yra simboliu, todėl visi metodai pateikia `Option`.
///
///
pub struct Symbol {
    // TODO: šį visą gyvenimą susietą reikia galiausiai išlaikyti iki `Symbol`,
    // bet tai šiuo metu lūžtantys pokyčiai.
    // Kol kas tai yra saugu, nes " `Symbol` išduodamas tik remiantis nuoroda ir jo negalima klonuoti.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Grąžina šios funkcijos pavadinimą.
    ///
    /// Grąžintą struktūrą galima naudoti užklausiant įvairias simbolio pavadinimo ypatybes:
    ///
    ///
    /// * `Display` diegimas išspausdins išardytą simbolį.
    /// * Galima pasiekti neapdorotą simbolio `str` vertę (jei ji galioja utf-8).
    /// * Galima pasiekti neapdorotus simbolio pavadinimo baitus.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Grąžina pradinį šios funkcijos adresą.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Grąžina neapdorotą failo pavadinimą kaip pjūvį.
    /// Tai daugiausia naudinga `no_std` aplinkose.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Grąžina stulpelio numerį ten, kur šiuo metu vykdomas šis simbolis.
    ///
    /// Tik gimli čia šiuo metu pateikia vertę ir net tada, jei `filename` grąžina `Some`, todėl jai taikomi panašūs įspėjimai.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Grąžina eilutės numerį ten, kur šiuo metu vykdomas šis simbolis.
    ///
    /// Ši grąžinimo vertė paprastai yra `Some`, jei `filename` grąžina `Some`, todėl jai taikomi panašūs įspėjimai.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Grąžina failo pavadinimą ten, kur ši funkcija buvo apibrėžta.
    ///
    /// Šiuo metu tai galima tik tada, kai naudojamas " libbacktrace`arba " gimli` (pvz.,
    /// unix platformos kitos) ir kai su debuginfo sudaromas dvejetainis failas.
    /// Jei nė viena iš šių sąlygų nebus įvykdyta, tai greičiausiai grąžins `None`.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Galbūt išanalizuotas C++ simbolis, jei nepavyksta analizuoti įstrigusio simbolio kaip Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Nepamirškite išlaikyti šio nulio dydžio, kad išjungus " `cpp_demangle` funkciją nekainuotų.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Apvyniojimas aplink simbolio pavadinimą, suteikiantis ergonomiškus prieigą prie išardyto pavadinimo, neapdorotų baitų, neapdorotų eilių ir kt.
///
// Leisti neveikiantį kodą, kai `cpp_demangle` funkcija neįgalinta.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Iš neapdorotų pagrindinių baitų sukuria naują simbolio pavadinimą.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Grąžina neapdorotą (mangled) simbolio pavadinimą kaip `str`, jei simbolis galioja utf-8.
    ///
    /// Jei norite išardytos versijos, naudokite " `Display` diegimą.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Grąžina neapdoroto simbolio pavadinimą kaip baitų sąrašą
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Tai gali atspausdinti, jei išardytas simbolis iš tikrųjų negalioja, todėl tvarkykite klaidą čia grakščiai, neplatindami jos į išorę.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Pabandykite susigrąžinti talpykloje saugomą atmintį, naudojamą adresams simbolizuoti.
///
/// Šiuo metodu bus bandoma išleisti bet kokias visuotines duomenų struktūras, kurios visuotinai arba talpykloje buvo talpyklos, kurios paprastai atspindi išanalizuotą DWARF informaciją ar panašią informaciją.
///
///
/// # Caveats
///
/// Nors ši funkcija yra visada prieinama, ji iš tikrųjų nieko nedaro daugelyje diegimų.
/// Bibliotekos, pvz., " Dbghelp`ar " libbacktrace`, nesuteikia galimybių išspręsti būseną ir valdyti paskirtą atmintį.
/// Kol kas šios funkcijos " crate` `gimli-symbolize` funkcija yra vienintelė funkcija, kuriai ši funkcija turi kokį nors poveikį.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}