// dabar naudojamas tik " Linux, todėl leiskite mirusį kodą kitur
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Paprastas arenos paskirstytojas baitų buferiams.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Paskiria nurodyto dydžio buferį ir grąžina į jį kintamą nuorodą.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAUGA: tai vienintelė funkcija, kuri kada nors sukuria kintamą
        // nuoroda į `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAUGA: mes niekada nepašaliname elementų iš " `self.buffers`, todėl nuoroda
        // bet kokio buferio viduje esantys duomenys gyvuos tol, kol tai darys " `self`.
        &mut buffers[i]
    }
}