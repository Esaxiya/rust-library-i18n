use core::ffi::c_void;
use core::fmt;

/// Tikrina esamą skambučių kaminą, visus aktyvius rėmelius perduodama į uždarymą, kad būtų galima apskaičiuoti kamino pėdsakus.
///
/// Ši funkcija yra šios bibliotekos arklys, skaičiuojant programos kamino pėdsakus.Nurodytam uždarymui `cb` pateikiami `Frame` egzemplioriai, kurie pateikia informaciją apie tą skambučio rėmą kamino.
/// Uždarymas išgaunamas iš viršaus į apačią (rėmeliai pirmiausia vadinami funkcijomis).
///
/// Uždarymo grąžinimo vertė rodo, ar turėtų būti tęsiamas grįžimas.Grąžinama `false` vertė nutraukia grįžimą ir iškart grįš.
///
/// Įsigiję " `Frame`, greičiausiai norėsite paskambinti į " `backtrace::resolve` ir konvertuoti `ip` (instrukcijų rodyklę) arba simbolių adresą į `Symbol`, per kuriuos galima sužinoti vardą ir (arba) failo pavadinimą/eilutės numerį.
///
///
/// Atkreipkite dėmesį, kad tai yra gana žemo lygio funkcija ir, jei norite, pavyzdžiui, užfiksuoti atgalinį pėdsaką, kurį norite patikrinti vėliau, `Backtrace` tipas gali būti tinkamesnis.
///
/// # Reikalingos funkcijos
///
/// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
///
/// # Panics
///
/// Ši funkcija siekia, kad panic niekada nebūtų, tačiau jei `cb` pateikė panics, kai kurios platformos privers dvigubą panic nutraukti procesą.
/// Kai kurios platformos naudoja C biblioteką, kuri viduje naudoja atgalinius skambučius, kurių negalima atsukti, todėl panika nuo " `cb` gali sukelti proceso nutraukimą.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // tęsti atgalinį kelią
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Tas pats kaip " `trace`, nesaugus, nes nesinchronizuotas.
///
/// Ši funkcija neturi sinchronizavimo garantijų, tačiau yra prieinama, kai šio crate funkcija `std` nėra sukompiliuota.
/// Daugiau dokumentų ir pavyzdžių rasite funkcijoje `trace`.
///
/// # Panics
///
/// Žr. Informaciją apie `trace` apie įspėjimus dėl panikos `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait, vaizduojantis vieną atgalinio kelio kadrą, pasidavė šio crate funkcijai `trace`.
///
/// Atsekimo funkcijos uždarymas suteiks rėmelius, o rėmas praktiškai išsiunčiamas, nes pagrindinis vykdymas ne visada žinomas iki vykdymo laiko.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Grąžina dabartinį šio rėmelio instrukcijų rodyklę.
    ///
    /// Paprastai tai yra kita instrukcija, kurią reikia atlikti rėmelyje, tačiau ne visuose diegimuose tai išvardijama 100% tikslumu (tačiau paprastai tai yra gana arti).
    ///
    ///
    /// Rekomenduojama perduoti šią vertę `backtrace::resolve`, kad ji būtų paversta simbolių pavadinimu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Grąžina dabartinį šio rėmelio rietuvės žymeklį.
    ///
    /// Jei užpakalinė dalis negali atkurti šio kadro šūsnies žymeklio, grąžinamas nulinis rodyklė.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Grąžina šios funkcijos rėmelio pradinį simbolio adresą.
    ///
    /// Tai bandys atsukti instrukcijos žymeklį, kurį `ip` grąžino į funkcijos pradžią, grąžindamas tą vertę.
    ///
    /// Tačiau kai kuriais atvejais užpakalinės programos `ip` tiesiog grąžins iš šios funkcijos.
    ///
    /// Grąžintą vertę kartais galima naudoti, jei `backtrace::resolve` nepavyko dėl aukščiau nurodyto `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Grąžina modulio, kuriam priklauso rėmas, bazinį adresą.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Tai turi būti pirmiausia, kad būtų užtikrinta, jog " Miri` turėtų pirmenybę prieš priimančiosios platformą
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // simbolizuoja tik dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}