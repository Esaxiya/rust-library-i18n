//! Nuo platformos priklausantys tipai.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Nuo platformos nepriklausomas eilutės atvaizdavimas.
/// Dirbant su įgalintu " `std`, rekomenduojama atlikti patogius metodus, kaip pateikti konversijas į `std` tipus.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Riekė, paprastai pateikiama Unix platformose.
    Bytes(&'a [u8]),
    /// Plačios eilutės paprastai nuo Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Praradęs konvertuoja į `Cow<str>`, paskirstys, jei `Bytes` negalioja UTF-8 arba jei `BytesOrWideString` yra `Wide`.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Pateikia `BytesOrWideString` `Path` vaizdą.
    ///
    /// # Reikalingos funkcijos
    ///
    /// Norint naudoti šią funkciją, reikia įjungti " `backtrace` crate`funkciją " `std`, o pagal numatytuosius nustatymus įjungta " `std` funkcija.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}