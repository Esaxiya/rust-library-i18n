//! Modulis, padedantis valdyti dbghelp susiejimus Windows
//!
//! " Windows(bent jau " MSVC`) " backtraces`iš esmės palaiko " `dbghelp.dll` ir įvairios jame esančios funkcijos.
//! Šios funkcijos šiuo metu yra įkeltos *dinamiškai*, o ne susiejant su " `dbghelp.dll`.
//! Šiuo metu tai daro standartinė biblioteka (ir teoriškai to ten reikia), tačiau tai yra pastangos padėti sumažinti statines bibliotekos priklausomybes nuo dll, nes atgaliniai pėdsakai paprastai yra gana neprivalomi.
//!
//! Tai sakant, " `dbghelp.dll` beveik visada sėkmingai įkrauna " Windows.
//!
//! Tačiau atkreipkite dėmesį, kad kadangi dinamiškai krauname visą šį palaikymą, mes iš tikrųjų negalime naudoti neapdorotų apibrėžimų " `winapi`, veikiau patys turime apibrėžti funkcijų rodyklių tipus ir tai naudoti.
//! Mes tikrai nenorime užsiimti " Winapi`kopijavimo verslu, todėl turime " Cargo` funkciją " `verify-winapi`, kuri tvirtina, kad visi apkaustai sutampa su " Winapi` esančiaisiais ir ši funkcija yra įjungta CI.
//!
//! Galiausiai čia pastebėsite, kad " `dbghelp.dll` dll failas niekada nėra iškraunamas, ir tai šiuo metu yra tyčia.
//! Manoma, kad mes galime jį talpinti visame pasaulyje ir naudoti tarp skambučių į API, išvengdami brangaus " loads/unloads.
//! Jei tai yra nuotėkio detektorių problema ar kažkas panašaus, mes galime pereiti tiltą, kai ten pateksime.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Darbas aplink `SymGetOptions` ir `SymSetOptions` nėra pačiame Winapi.
// Priešingu atveju tai naudojama tik tada, kai dvigubai tikriname tipus pagal WinAPI.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Winapi dar neapibrėžta
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Tai apibrėžta " Winapi`, bet neteisinga (" FIXME winapi-rs#768`)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Winapi dar neapibrėžta
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ši makrokomanda naudojama apibrėžti `Dbghelp` struktūrą, kurioje yra visi funkcijų rodyklės, kurias galime įkelti.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Įkeltas " `dbghelp.dll` DLL
            dll: HMODULE,

            // Kiekvienas funkcijos rodyklė kiekvienai funkcijai, kurią galime naudoti
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Iš pradžių mes neįkėlėme DLL
            dll: 0 as *mut _,
            // Visos funkcijos " Initiall` nustatomos į nulį, kad būtų galima sakyti, jog jas reikia dinamiškai įkelti.
            //
            $($name: 0,)*
        };

        // Patogumas typedef kiekvienam funkcijos tipui.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Bandymai atidaryti " `dbghelp.dll`.
            /// Pateikia sėkmę, jei ji veikia, arba klaidą, jei nepavyksta `LoadLibraryW`.
            ///
            /// Panics, jei biblioteka jau įkelta.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcija kiekvienam metodui, kurį norėtume naudoti.
            // Kai jis bus iškviestas, jis nuskaitys talpykloje išsaugotą funkcijos žymeklį arba jį įkels ir grąžins įkeltą vertę.
            // Teigiama, kad apkrovos bus sėkmingos.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Patogus tarpinis serveris naudoti valymo užraktus nuorodoms į dbghelp funkcijas.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicijuokite visą palaikymą, reikalingą norint pasiekti " `dbghelp` API funkcijas iš šio " crate`.
///
///
/// Atminkite, kad ši funkcija yra **saugi**, ji turi savo sinchronizavimą.
/// Taip pat atkreipkite dėmesį, kad saugu skambinti šia funkcija kelis kartus rekursiškai.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Pirmas dalykas, kurį turime padaryti, yra sinchronizuoti šią funkciją.Tai galima vadinti vienu metu iš kitų gijų arba rekursyviai vienoje gijoje.
        // Atkreipkite dėmesį, kad vis dėlto tai yra sudėtingiau, nes tai, ką mes naudojame čia, " `dbghelp`,*taip pat* šiame procese turi būti sinchronizuojami su visais kitais skambinančiaisiais į " `dbghelp`.
        //
        // Paprastai per tą patį procesą nėra tiek daug skambučių į " `dbghelp` ir tikriausiai galime drąsiai manyti, kad tik mes prieiname prie jo.
        // Tačiau yra vienas kitas pagrindinis vartotojas, dėl kurio turime nerimauti ir patys, bet standartinėje bibliotekoje.
        // " Rust`standartinė biblioteka priklauso nuo šio " crate` palaikymo, o " crate`taip pat egzistuoja " crates.io.
        // Tai reiškia, kad jei standartinė biblioteka spausdina panic atgalinį pėdsaką, ji gali lenktyniauti su šiuo crate, gaunamu iš crates.io, sukeldama sutrikimų.
        //
        // Norėdami padėti išspręsti šią sinchronizavimo problemą, mes naudojame " Windows`specifinį triuką (galų gale tai yra " Windows` specifinis sinchronizavimo apribojimas).
        // Mes sukuriame *session-local* pavadinimą " mutex`, kad apsaugotume šį skambutį.
        // Čia ketinama, kad standartinė biblioteka ir ši " crate`neprivalo dalytis " Rust` lygio API, kad čia sinchronizuotųsi, bet gali dirbti užkulisiuose ir įsitikinti, kad jie sinchronizuojasi tarpusavyje.
        //
        // Tokiu būdu, kai ši funkcija iškviečiama per standartinę biblioteką arba per crates.io, galime būti tikri, kad įgyjamas tas pats muteksas.
        //
        // Taigi visa tai reiškia, kad pirmas dalykas, kurį mes darome, yra tai, kad mes atominiu būdu sukursime " `HANDLE`, kuris yra " Windows pavadintas " muteksas`.
        // Šiek tiek sinchronizuojame su kitomis gijomis, kurios naudojasi šia funkcija, ir užtikriname, kad kiekvienam šios funkcijos egzemplioriui būtų sukurta tik viena rankena.
        // Atminkite, kad rankena niekada nebus uždaryta, kai ji bus saugoma visame pasaulyje.
        //
        // Iš tikrųjų užfiksavę spyną, ją paprasčiausiai įsigyjame, o mūsų išleista " `Init` rankena bus atsakinga už jos numetimą.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Gerai, phew!Dabar, kai visi esame saugiai sinchronizuoti, pradėkime viską tvarkyti.
        // Pirmiausia turime užtikrinti, kad šiame procese iš tikrųjų būtų įkelta " `dbghelp.dll`.
        // Tai darome dinamiškai, kad išvengtume statinės priklausomybės.
        // Tai istoriškai buvo padaryta norint išspręsti keistas susiejimo problemas ir yra skirta padaryti dvejetainius failus šiek tiek labiau nešiojamus, nes tai daugiausia tik derinimo priemonė.
        //
        //
        // Atidarę " `dbghelp.dll` turime jame iškviesti kai kurias inicializavimo funkcijas. Tai išsamiau aprašyta toliau.
        // Vis dėlto tai darome tik vieną kartą, todėl turime visuotinę loginę reikšmę, nurodančią, ar mes jau baigėme, ar ne.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Įsitikinkite, kad nustatyta vėliava `SYMOPT_DEFERRED_LOADS`, nes pagal pačios MSVC dokumentus apie tai: "This is the fastest, most efficient way to use the symbol handler.", todėl padarykime tai!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Faktiškai inicijuokite simbolius naudodami MSVC.Atkreipkite dėmesį, kad tai gali nepavykti, tačiau mes to nepaisome.
        // Per se tai nėra daugybė ankstesnio meno, tačiau atrodo, kad LLVM čia ignoruoja grąžinimo vertę, o viena iš LLVM sanitarijos bibliotekų paskelbia bauginantį įspėjimą, jei tai nepavyksta, tačiau iš esmės ilgainiui tai ignoruoja.
        //
        //
        // Vienas atvejis, kai tai labai aktualu " Rust`, yra tai, kad tiek " crates.io standartinė biblioteka, tiek ši " crate`nori konkuruoti dėl " `SymInitializeW`.
        // Standartinė biblioteka istoriškai norėjo didžiąją laiko dalį inicijuoti tada valymą, tačiau dabar, kai ji naudoja šį " crate`, tai reiškia, kad kažkas pirmiausia pateks į inicijavimą, o kitas imsis to inicijavimo.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}