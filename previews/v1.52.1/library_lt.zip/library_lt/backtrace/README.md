# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Biblioteka, skirta įsigyti " Rust` atgalinių pėdsakų vykdymo metu.
Šia biblioteka siekiama sustiprinti standartinės bibliotekos palaikymą, suteikiant programinę sąsają darbui, tačiau ji taip pat palaiko tiesiog lengvai atspausdintą dabartinę atgalinę seką, pvz., Libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Norėdami tiesiog užfiksuoti atgalinį pėdsaką ir atidėti jo nagrinėjimą vėliau, galite naudoti aukščiausio lygio `Backtrace` tipą.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Tačiau jei norite daugiau neapdorotos prieigos prie faktinės sekimo funkcijos, galite tiesiogiai naudoti " `trace` ir " `resolve` funkcijas.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Išspręskite šią instrukcijos žymeklį į simbolio pavadinimą
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // tęskite kitą kadrą
    });
}
```

# License

Šis projektas yra licencijuotas pagal kurį nors iš

 * " Apache` licencija, versija 2.0, ([LICENSE-APACHE](LICENSE-APACHE) arba http://www.apache.org/licenses/LICENSE-2.0)
 * MIT licencija ([LICENSE-MIT](LICENSE-MIT) arba http://opensource.org/licenses/MIT)

savo nuožiūra.

### Contribution

Jei aiškiai nenurodote kitaip, bet koks įnašas, kurį jūs tyčia pateikėte įtraukti į " backtrace-rs`, kaip apibrėžta " Apache-2.0` licencijoje, turi dvigubą licenciją, kaip nurodyta aukščiau, be jokių papildomų sąlygų ar sąlygų.







