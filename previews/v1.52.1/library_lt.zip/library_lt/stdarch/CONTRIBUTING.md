# Prisidedu prie stdarcho

" `stdarch` crate` yra daugiau nei pasirengęs priimti įnašus!Pirmiausia tikriausiai norėsite patikrinti saugyklą ir įsitikinti, kad testai jums tinka:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kur `<your-target-arch>` yra tikslinis trigubas, naudojamas `rustup`, pvz., `x86_x64-unknown-linux-gnu` (be ankstesnio `nightly-` ar panašaus).
Taip pat atminkite, kad šiai saugyklai reikalingas naktinis Rust kanalas!
Pirmiau minėti bandymai iš tikrųjų reikalauja, kad naktinis " rust` būtų numatytasis jūsų sistemos nustatymas, norint naudoti `rustup default nightly` (ir `rustup default stable` norint grįžti).

Jei kuris nors iš anksčiau nurodytų veiksmų neveikia, [please let us know][new]!

Toliau galite [find an issue][issues] padėti, mes pasirinkome keletą su [`help wanted`][help] ir [`impl-period`][impl] žymomis, kurios galėtų ypač padėti. 
Jus labiausiai gali dominti " [#40][vendor], diegiant visas " x86 tiekėjo vidines savybes.Šis klausimas turi keletą gerų patarimų, kur pradėti!

Jei turite bendrų klausimų, nedvejodami kreipkitės į " [join us on gitter][gitter] ir klauskite!Nedvejodami pakvieskite klausimus@BurntSushi arba@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kaip rašyti stdarchų vidinius pavyzdžius

Yra kelios funkcijos, kurios turi būti įjungtos, kad duota vidinė sistema veiktų tinkamai, o pavyzdį " `cargo test --doc` gali vykdyti tik tada, kai šią funkciją palaiko procesorius.

Todėl numatytasis " `fn main`, kurį sugeneravo " `rustdoc`, neveiks (daugeliu atvejų).
Apsvarstykite galimybę naudoti šį vadovą kaip vadovą, kad įsitikintumėte, jog jūsų pavyzdys veikia kaip tikėtasi.

```rust
/// # // Mums reikia cfg_target_feature, kad įsitikintume, jog pavyzdys yra tik
/// # // paleista " `cargo test --doc`, kai procesorius palaiko šią funkciją
/// # #![feature(cfg_target_feature)]
/// # // Mums reikalinga target_feature, kad veiktų vidus
/// # #![feature(target_feature)]
/// #
/// # // Pagal numatytuosius nustatymus " rustdoc`naudoja " `extern crate stdarch`, bet mums to reikia
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarchas;
/// #
/// # // Tikroji pagrindinė funkcija
/// # fn main() {
/// #     // Paleiskite tai tik tuo atveju, jei palaikoma " `<target feature>`
/// #     jei cfg_feature_enabled! ("<target feature>"){
/// #         // Sukurkite `worker` funkciją, kuri bus vykdoma tik tada, jei bus naudojama tikslinė funkcija
/// #         // yra palaikoma ir įsitikinkite, kad jūsų darbuotojui įgalinta " `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nesaugus fn worker() {
/// // Parašykite savo pavyzdį čia.Čia veiks specifiniai ypatumai!Lauk lauk!
///
/// #         }
///
/// #         nesaugus { worker(); }
/// #     }
/// # }
```

Jei kai kuri iš pirmiau minėtų sintaksių neatrodo pažįstama, [Rust Book] skyriuje [Documentation as tests] gana gerai aprašoma `rustdoc` sintaksė.
Kaip visada, nedvejodami kreipkitės į " [join us on gitter][gitter] ir paklauskite, ar nepasitaikė kliūčių, ir dėkojame, kad padėjote patobulinti " `stdarch` dokumentaciją!

# Alternatyvios bandymo instrukcijos

Paprastai bandymams atlikti rekomenduojama naudoti " `ci/run.sh`.
Tačiau tai gali netikti jums, pvz., Jei naudojate " Windows.

Tokiu atveju galite grįžti prie " `cargo +nightly test` ir " `cargo +nightly test --release -p core_arch`, kad išbandytumėte kodo generavimą.
Atminkite, kad tam reikia įdiegti naktinę įrankių grandinę ir kad " `rustc` žinotų apie jūsų tikslinį trigubą ir jo procesorių.
Ypač reikia nustatyti `TARGET` aplinkos kintamąjį, kaip ir `ci/run.sh`.
Be to, turite nustatyti `RUSTCFLAGS` (reikia `C`), kad nurodytumėte tikslines funkcijas, pvz `RUSTCFLAGS="-C -target-features=+avx2"`.
Taip pat galite nustatyti " `-C -target-cpu=native`, jei " "just" kuriate pagal savo dabartinį procesorių.

Įspėjame, kad naudojant šias alternatyvias instrukcijas, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], pvz
instrukcijų generavimo testai gali nepavykti, nes išardytojas juos pavadino kitaip, pvz
nepaisant to, kad jie elgiasi taip pat, jis gali generuoti `vaesenc`, o ne `aesenc` instrukcijas.
Be to, šiose instrukcijose atliekama mažiau bandymų, nei būtų daroma paprastai, todėl nenustebkite, kad kai galų gale pateiksite užklausą, kai kuriose klaidose gali atsirasti testų, kurie čia nėra aprašyti.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






