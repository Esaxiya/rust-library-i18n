`core::arch` - " Rust` pagrindinės bibliotekos architektūrai būdingos savybės
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

" `core::arch` modulis įgyvendina nuo architektūros priklausomus dalykus (pvz., SIMD).

# Usage 

`core::arch` yra kaip " `libcore` dalis ir jį reeksportuoja " `libstd`.Verčiau naudokite jį per " `core::arch` arba " `std::arch`, nei per šį " crate`.
Nestabilios funkcijos dažnai pasiekiamos naktiniame " Rust`per " `feature(stdsimd)`.

Norint naudoti " `core::arch` per šį " crate`, reikia " Rust` kasnakt, ir jis gali (ir dažnai) sugesti.Vieninteliai atvejai, kai turėtumėte apsvarstyti galimybę jį naudoti per šį crate, yra šie:

* jei jums reikia iš naujo kompiliuoti " `core::arch`, pvz., įjungus tam tikras tikslines funkcijas, kurios neįgalintos " `libcore`/`libstd`.
Note: jei jums reikia iš naujo sukompiliuoti jį nestandartiniam taikiniui, pirmenybę naudokite `xargo` ir, jei reikia, iš naujo kompiliuokite `libcore`/`libstd`, užuot naudoję šį crate.
  
* naudojant kai kurias funkcijas, kurių gali nebūti net ir nestabilios " Rust` funkcijos.Mes stengiamės, kad jų būtų kuo mažiau.
Jei jums reikia naudoti kai kurias iš šių funkcijų, atidarykite problemą, kad galėtume jas atskleisti naktį Rust ir jūs galėtumėte naudoti jas iš ten.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` daugiausia platinamas pagal MIT licencijos ir " Apache` licencijos (2.0 versija) sąlygas, o dalims taikomos įvairios į BSD panašios licencijos.

Išsamesnės informacijos ieškokite LICENSE-APACHE ir LICENCIJA-MIT.

# Contribution

Jei aiškiai nenurodote kitaip, bet koks įnašas, kurį jūs tyčia pateikėte įtraukti į " `core_arch`, kaip apibrėžta " Apache-2.0` licencijoje, turi dvigubą licenciją, kaip nurodyta aukščiau, be jokių papildomų sąlygų ar sąlygų.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












