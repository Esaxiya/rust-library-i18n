# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Китобхона барои ба даст овардани backtraces дар вақти корӣ барои Rust.
Ин китобхона мақсад дорад, ки дастгирии китобхонаи стандартиро бо роҳи таъмин намудани интерфейси барномавӣ барои кор, балки инчунин ба осонӣ чоп кардани ақибравии ҳозираро ба монанди panics libstd дастгирӣ мекунад.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Барои содда кардани ақибнишинӣ ва ба таъхир андохтан бо он то вақти дигар, шумо метавонед навъи `Backtrace`-ро дар сатҳи боло истифода баред.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Аммо, агар шумо мехоҳед дастрасии бештар ба функсияи воқеии ҷустуҷӯ дошта бошед, шумо метавонед функсияҳои `trace` ва `resolve`-ро мустақиман истифода баред.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ин нишоннамои дастурро бо номи рамз ҳал кунед
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ба чорчӯбаи навбатӣ равед
    });
}
```

# License

Ин лоиҳа тибқи яке аз он литсензия гирифта шудааст

 * Литсензияи Apache, нусхаи 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ё http://www.apache.org/licenses/LICENSE-2.0)
 * Иҷозатномаи MIT ([LICENSE-MIT](LICENSE-MIT) ё http://opensource.org/licenses/MIT)

бо интихоби шумо.

### Contribution

Агар шумо ба таври возеҳ тартиби дигаре изҳор накардед, ҳама гуна саҳмҳое, ки шумо барои дохил кардан ба backtrace-rs аз ҷониби шумо, ки дар литсензияи Apache-2.0 муайян шудааст, қасдан пешниҳод кардаед, бидуни ҳеҷ гуна шарту шароити иловагӣ дугона иҷозатнома дода мешавад.







