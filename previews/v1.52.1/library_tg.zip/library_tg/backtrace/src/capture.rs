use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Намояндагии ақибгоҳи моликиятӣ ва мустақил.
///
/// Ин сохтор метавонад барои гирифтани акси садо дар нуқтаҳои гуногуни барнома истифода шавад ва баъдтар барои тафтиши он ақиб дар он замон истифода шавад.
///
///
/// `Backtrace` тавассути татбиқи `Debug` чопи зебои пушти сарро дастгирӣ мекунад.
///
/// # Хусусиятҳои зарурӣ
///
/// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Чорчӯбаҳо дар ин ҷо аз боло то поёни анбор номбар карда шудаанд
    frames: Vec<BacktraceFrame>,
    // Индексе, ки мо ба он боварӣ дорем, оғози воқеии ақибнишинӣ, рад кардани фреймҳо ба монанди `Backtrace::new` ва `backtrace::trace` мебошад.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Нусхаи аксшудаи кадр дар пуштибонӣ.
///
/// Ин намуд ҳамчун рӯйхат аз `Backtrace::frames` баргардонида мешавад ва як фрейми стакаро дар ақибнишинии гирифташуда нишон медиҳад.
///
/// # Хусусиятҳои зарурӣ
///
/// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Нусхаи аксшудаи рамз дар ақибгоҳ.
///
/// Ин навъ ҳамчун рӯйхат аз `BacktraceFrame::symbols` баргардонида шудааст ва метамаълумот барои рамзро дар ақибгоҳ ифода мекунад.
///
/// # Хусусиятҳои зарурӣ
///
/// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Дар акси садо ин функсияро бармегардонад ва намояндагии худро бармегардонад.
    ///
    /// Ин функсия барои муаррифии ақибгоҳ ҳамчун объект дар Rust муфид аст.Ин арзиши баргаштаро тавассути риштаҳо фиристодан ва дар ҷои дигар чоп кардан мумкин аст ва ҳадафи ин арзиш комилан мустақил будан аст.
    ///
    /// Дар хотир доред, ки дар баъзе платформаҳо ақибнишинии пурра ба даст оварда, ҳалли он метавонад хеле гарон бошад.
    /// Агар хароҷот барои барномаи шумо аз ҳад зиёд бошад, тавсия дода мешавад, ки `Backtrace::new_unresolved()`-ро истифода баред, ки он қадами ҳалли рамзро пешгирӣ мекунад (ки одатан тӯлонитаринро мегирад) ва ба таъхир гузоштани онро ба санаи дертар медиҳад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // мехоҳед боварӣ ҳосил кунед, ки дар ин ҷо чаҳорчӯба барои нест кардан вуҷуд дорад
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Монанди `new`, ба истиснои он, ки ин ягон рамзро ҳал намекунад, ин танҳо ақибро ҳамчун рӯйхати суроғаҳо сабт мекунад.
    ///
    /// Дертар, вазифаи `resolve`-ро барои ҳалли аломатҳои ин ақибгоҳ ба номҳои хонданӣ метавон даъват кард.
    /// Ин функсия барои он мавҷуд аст, ки раванди ҳалли он баъзан метавонад вақти зиёдро талаб кунад, дар сурате ки ягон ақибнишинӣ танҳо кам чоп карда мешавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // номҳои рамзӣ нест
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // номҳои аломатҳо ҳоло мавҷуданд
    /// ```
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    ///
    #[inline(never)] // мехоҳед боварӣ ҳосил кунед, ки дар ин ҷо чаҳорчӯба барои нест кардан вуҷуд дорад
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Кадрҳоро аз вақти гирифташавии ин ақиб бармегардонад.
    ///
    /// Аввалин вуруди ин бурида эҳтимолияти функсияи `Backtrace::new` аст ва чорчӯбаи охирин эҳтимолан дар бораи он аст, ки ин ришта ё функсияи асосӣ чӣ гуна оғоз ёфтааст.
    ///
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Агар ин ақибнишинӣ аз `new_unresolved` сохта шуда бошад, пас ин вазифа ҳамаи суроғаҳои ақибро ба номҳои рамзии худ ҳал мекунад.
    ///
    ///
    /// Агар ин ақибгоҳ қаблан ҳал шуда бошад ё тавассути `new` сохта шуда бошад, ин функсия ҳеҷ кор намекунад.
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Ҳамон тавре ки `Frame::ip`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Ҳамон тавре ки `Frame::symbol_address`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Ҳамон тавре ки `Frame::module_base_address`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Рӯйхати рамзҳоро, ки ин чорчӯба ба он мувофиқат мекунад, бармегардонад.
    ///
    /// Одатан дар як фрейм танҳо як рамз мавҷуд аст, аммо баъзан агар як функсия ба як чорчӯба дохил карда шавад, пас якчанд рамз бармегарданд.
    /// Аввалин рамзи номбаршуда "innermost function" аст, дар ҳоле ки рамзи охирин аз ҳама берун аст (зангзадаи охирин).
    ///
    /// Дар хотир доред, ки агар ин чорчӯба аз ақибгоҳи ҳалношуда баромада бошад, он гоҳ ин рӯйхати холиро бармегардонад.
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Ҳамон тавре ки `Symbol::name`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Ҳамон тавре ки `Symbol::addr`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Ҳамон тавре ки `Symbol::filename`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Ҳамон тавре ки `Symbol::lineno`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Ҳамон тавре ки `Symbol::colno`
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Ҳангоми чоп кардани роҳҳо мо кӯшиш мекунем, ки cwd-ро, агар он мавҷуд бошад, рахна кунем, вагарна мо танҳо роҳро тавре ҳастем, ки ҳаст, чоп мекунад.
        // Дар хотир доред, ки мо инро танҳо барои формати кӯтоҳ мекунем, зеро агар он пур бошад, мо эҳтимолан ҳама чизро чоп кардан мехоҳем.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}