// танҳо дар айни замон дар Linux истифода мешавад, бинобар ин рамзи мурдаро дар ҷои дигар иҷозат диҳед
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Ҷудокунандаи арсаи оддӣ барои буферҳои байтӣ.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Буфери андозаи муайянро ҷудо мекунад ва ба он истиноди тағиршавандаро бар мегардонад.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // БЕХАТАР: : ин ягона функсияест, ки ҳамеша тағирёбанда месозад
        // истинод ба `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // БЕХАТАР: : мо ҳеҷ гоҳ унсурҳоро аз `self.buffers` хориҷ намекунем, аз ин рӯ истинод
        // ба маълумот дар дохили ягон буфер то даме ки `self` зиндагӣ мекунад, зиндагӣ мекунад.
        &mut buffers[i]
    }
}