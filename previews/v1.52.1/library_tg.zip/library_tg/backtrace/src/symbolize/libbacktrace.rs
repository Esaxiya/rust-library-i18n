//! Стратегияи рамзгузорӣ бо истифодаи рамзи таҳлили DWARF дар libbacktrace.
//!
//! Китобхонаи libbacktrace C, ки одатан бо gcc тақсим карда мешавад, на танҳо тавлиди ақибро (ки мо онро дар асл истифода намебарем) дастгирӣ мекунад, балки инчунин рамзи пуштибонӣ ва коркарди иттилооти сабукрави сабукро дар бораи чизҳое, ба монанди фоторамкаҳои хаттӣ ва чизи дигарро дастгирӣ мекунад.
//!
//!
//! Ин аз сабаби ташвишҳои гуногун дар ин ҷо нисбатан мушкил аст, аммо ғояи асосӣ инҳост:
//!
//! * Аввалан мо ба `backtrace_syminfo` занг мезанем.Ин агар мо метавонем аз ҷадвали рамзи динамикӣ маълумоти рамзӣ мегирад.
//! * Баъд мо ба `backtrace_pcinfo` занг мезанем.Ин ҷадвалҳои debuginfo-ро, агар онҳо дастрас бошанд, таҳлил мекунад ва ба мо имкон медиҳад, ки маълумотро дар бораи фреймҳои дохилӣ, номҳои файлҳо, рақамҳои сатр ва ғ.
//!
//! Бисёр ҳилаҳо дар бораи ба libbacktrace ворид кардани ҷадвалҳои ҷудогона вуҷуд доранд, аммо умедворам, ки ин охири дунё нест ва ҳангоми хондани зер ба таври кофӣ равшан аст.
//!
//! Ин стратегияи аломатгузории пешфарз барои платформаҳои ғайри MSVC ва ғайри OSX мебошад.Дар libstd гарчанде ки ин стратегияи пешфарз барои OSX аст.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Агар имконпазир бошад, ба номи `function` бартарӣ диҳед, ки аз debuginfo мебарояд ва одатан метавонад барои фреймҳои дарунӣ дақиқтар бошад.
                // Агар ин мавҷуд набошад ҳам, ба номи ҷадвали рамзи дар `symname` нишондодашуда баргардед.
                //
                // Дар хотир доред, ки баъзан `function` метавонад каме камтар дақиқро ҳис кунад, масалан, ҳамчун `try<i32,closure>` isntead of `std::panicking::try::do_call` номбар карда мешавад.
                //
                // Дар ҳақиқат маълум нест, ки чаро, аммо дар маҷмӯъ номи `function` дақиқтар ба назар мерасад.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ҳоло ҳеҷ коре накун
}

/// Намуди нишоннамои `data` ба `syminfo_cb` гузашт
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Пас аз он, ки ин занг аз `backtrace_syminfo` даъват карда мешавад, вақте ки мо ба ҳалли масъала шурӯъ мекунем, ба `backtrace_pcinfo` занг мезанем.
    // Функсияи `backtrace_pcinfo` иттилооти ислоҳро баррасӣ мекунад ва кӯшиш мекунад, ки ба монанди барқароркунии иттилооти file/line ва инчунин фреймҳои хаттӣ кор кунад.
    // Дар хотир доред, ки `backtrace_pcinfo` метавонад хато кунад ё кори зиёдеро анҷом диҳад, агар иттилооти ислоҳӣ вуҷуд надошта бошад, бинобар ин, агар ин рӯй диҳад, мо боварӣ дорем, ки зангро бо ақаллан як аломат аз `syminfo_cb` даъват мекунем.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Намуди нишоннамои `data` ба `pcinfo_cb` гузашт
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API эҷоди давлатро дастгирӣ мекунад, аммо вайрон кардани давлатро дастгирӣ намекунад.
// Ман шахсан инро ба он маъно мегирам, ки давлат барои сохтан ва сипас абадӣ зиндагӣ кардан аст.
//
// Ман мехоҳам як коркарди at_exit()-ро сабти ном кунам, ки ин ҳолатро тоза мекунад, аммо libbacktrace ҳеҷ гуна имконро барои ин пешниҳод намекунад.
//
// Бо ин маҳдудиятҳо, ин функсия ҳолати кэшии статикӣ дорад, ки бори аввал талаб карда мешавад.
//
// Дар хотир доред, ки пайгирии ҳама чиз пайдарпай сурат мегирад (як қулфи ҷаҳонӣ).
//
// Аҳамият диҳед, ки набудани ҳамоҳангсозӣ дар ин ҷо ба талабот вобаста аст, ки `resolve` беруна ҳамоҳанг карда шудааст.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Аз қобилиятҳои риштаи libbacktrace истифода набаред, зеро мо ҳамеша онро бо усули ҳамоҳангшуда даъват мекунем.
        //
        0,
        error_cb,
        ptr::null_mut(), // маълумоти иловагӣ нест
    );

    return STATE;

    // Дар хотир доред, ки барои libbacktrace амалан кор кардан ба он лозим аст, ки маълумоти иҷрокунандаи DWARF барои иҷрошавандаи ҷорӣ пайдо карда шавад.Он одатан инро тавассути як қатор механизмҳо анҷом медиҳад, аз ҷумла, вале бо маҳдудиятҳо:
    //
    // * /proc/self/exe дар платформаҳои дастгиришаванда
    // * Номи файл ҳангоми эҷоди ҳолат ба таври возеҳ гузашт
    //
    // Китобхонаи libbacktrace як wad бузурги рамзи C мебошад.Ин табиатан маънои онро дорад, ки он осебпазирии амнияти хотираро ба даст меорад, алахусус ҳангоми корбурди debuginfo нодуруст.
    // Либстд аз инҳо фаровон ба таври таърихӣ кор кардааст.
    //
    // Агар /proc/self/exe истифода шавад, мо метавонем инҳоро одатан нодида гирем, зеро гумон мекунем, ки libbacktrace "mostly correct" аст ва дар акси ҳол бо "attempted to be correct" иттилооти сабукрави карахт чизҳои аҷибе намекунад.
    //
    //
    // Агар мо номи файлро гузорем, пас дар баъзе платформаҳо имконпазир аст (ба монанди BSD-ҳо), ки дар он як актёри бадхоҳ метавонад боиси ҷойгиркунии файли худсарона шавад.
    // Ин маънои онро дорад, ки агар мо ба libbacktrace дар бораи номи файл гӯем, он метавонад файли ихтиёриро истифода барад, ки эҳтимолан боиси вайроншавии сегмента гардад.
    // Агар мо ба libbacktrace чизе нагӯем, ҳарчанд он дар платформаҳое кор нахоҳад кард, ки роҳҳоро ба монанди /proc/self/exe пуштибонӣ намекунанд!
    //
    // Бо назардошти ҳама чизҳое, ки мо ҳарчи бештар кӯшиш мекунем, то номи файлро нагузаронем, аммо мо бояд дар платформаҳое, ки /proc/self/exe-ро тамоман дастгирӣ намекунанд.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Дар хотир доред, ки идеалӣ мо `std::env::current_exe`-ро истифода мебарем, аммо мо наметавонем дар ин ҷо `std` талаб кунем.
            //
            // `_NSGetExecutablePath`-ро истифода баред, то роҳи иҷрошавандаро ба минтақаи статикӣ бор кунед (ки агар он хеле хурд бошад, танҳо даст кашед).
            //
            //
            // Дар хотир доред, ки мо ба таври ҷиддӣ ба libbacktrace боварӣ дорем, то дар иҷрошавандаҳои фасод намирем, аммо ин бешубҳа ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows дорои режими кушодани файлҳо мебошад, ки пас аз кушода шуданаш онро наметавон нест кард.
            // Ин дар маҷмӯъ он чизест, ки мо дар ин ҷо мехоҳем, зеро мо мехоҳем, ки пас аз ба libbacktrace супоридан иҷрокунандаи мо аз зери мо тағир наёбад ва умедворем, ки қобилияти интиқоли маълумотҳои худсарона ба libbacktrace (ки метавонад нодуруст бошад) кам карда шавад.
            //
            //
            // Бо дарназардошти он, ки мо дар ин ҷо каме рақс мекунем, то дар симои худ як навъ қулфро ба даст орем:
            //
            // * Раванди ҷориро ба даст оред, номи файлро бор кунед.
            // * Файлро ба он номи файл бо парчамҳои рост кушоед.
            // * Номи файли раванди ҷориро дубора барқарор кунед ва боварӣ ҳосил кунед, ки ҳамон аст
            //
            // Агар ин ҳама воқеъ шавад, мо дар назария файли раванди моро кушодем ва мо кафолат медиҳем, ки он тағир нахоҳад ёфт.FWIW як хӯшаи ин аз libstd таърихан нусхабардорӣ шудааст, аз ин рӯ, ин беҳтарин тафсири ман дар бораи он чӣ аст.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ин дар хотираи статикӣ зиндагӣ мекунад, то мо онро баргардонем ..
                static mut BUF: [i8; N] = [0; N];
                // ... ва ин дар анбор зиндагӣ мекунад, зеро муваққатӣ аст
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // қасдан `handle`-ро дар ин ҷо фош мекунад, зеро ин кушод бояд қулфи моро дар ин номи файл нигоҳ дорад.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Мо мехоҳем як буридаи бекоркардашударо баргардонем, бинобар ин, агар ҳама чиз пур карда шуда бошад ва он ба дарозии умумӣ баробар бошад, пас онро ба нокомӣ баробар мекунад.
                //
                //
                // Дар акси ҳол, ҳангоми баргардонидани муваффақият боварӣ ҳосил кунед, ки байти нул ба қисм дохил карда шудааст.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // Айни замон хатогиҳои ақибнишинӣ зери қолин печонида шудаанд
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ба `backtrace_syminfo` API занг занед, ки (аз хондани рамз) бояд ба `syminfo_cb` маҳз як маротиба занг занад (ё эҳтимолан бо хатогӣ ноком шавад).
    // Пас мо дар доираи `syminfo_cb` бештар кор мекунем.
    //
    // Дар хотир доред, ки мо ин корро анҷом медиҳем, зеро `syminfo` бо ҷадвали аломатҳо машварат карда, номҳои аломатҳоро пайдо мекунад, ҳатто агар дар бинар маълумоти носаҳеҳ вуҷуд надошта бошад.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}