use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Суроғаеро ба рамз ҳал кунед, аломатро ба бастани муайян гузаред.
///
/// Ин функсия суроғаи додашударо дар минтақаҳо, ба монанди ҷадвали рамзи маҳаллӣ, ҷадвали рамзи динамикӣ ё иттилооти ислоҳи DWARF (вобаста аз татбиқи фаъол) ҷустуҷӯ мекунад, то нишонаҳои ба даст овардашударо пайдо кунад.
///
///
/// Агар қатъият иҷро карда нашавад, инчунин он метавонад дар мавриди функсияҳои дохилкардашуда на як бору ду бор даъват карда шавад.
///
/// Рамзҳои бадастомада иҷрои нишондоди `addr`-ро нишон медиҳанд ва ҷуфти file/line-ро барои он суроға бармегардонанд (агар мавҷуд бошанд).
///
/// Дар хотир доред, ки агар шумо `Frame` дошта бошед, пас ба ҷои ин функсия истифодаи `resolve_frame` тавсия дода мешавад.
///
/// # Хусусиятҳои зарурӣ
///
/// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
///
/// # Panics
///
/// Ин функсия мекӯшад, ки ҳеҷ гоҳ panic нест, аммо агар `cb` panics пешниҳод карда бошад, пас баъзе платформаҳо panic-ро барои барҳам додани раванд маҷбур мекунанд.
/// Баъзе платформаҳо китобхонаи C-ро истифода мебаранд, ки дар дохили он бозгашти зангҳоро истифода мекунад, ки онҳоро кушода наметавонанд, бинобар ин, ваҳм аз `cb` метавонад раванди бекор кардани равандро ба вуҷуд орад.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // танҳо ба чорчӯбаи боло нигаред
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Чорчӯбаи қабл аз гирифтанро ба рамз ҳал карда, аломатро ба бастани муайян гузаред.
///
/// Ин функсия ҳамон як функсияро бо `resolve` иҷро мекунад, ба истиснои он, ки ба ҷои суроға `Frame` ҳамчун далел қабул карда мешавад.
/// Ин метавонад ба баъзе амалисозии платформаи backtracing имкон диҳад, ки маълумоти дақиқ дар бораи рамзҳо ё маълумот дар бораи фреймҳои дохилӣ дошта бошанд.
///
/// Агар тавонед, тавсия дода мешавад, ки аз ин истифода баред.
///
/// # Хусусиятҳои зарурӣ
///
/// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
///
/// # Panics
///
/// Ин функсия мекӯшад, ки ҳеҷ гоҳ panic нест, аммо агар `cb` panics пешниҳод карда бошад, пас баъзе платформаҳо panic-ро барои барҳам додани раванд маҷбур мекунанд.
/// Баъзе платформаҳо китобхонаи C-ро истифода мебаранд, ки дар дохили он бозгашти зангҳоро истифода мекунад, ки онҳоро кушода наметавонанд, бинобар ин, ваҳм аз `cb` метавонад раванди бекор кардани равандро ба вуҷуд орад.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // танҳо ба чорчӯбаи боло нигаред
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Арзишҳои IP аз фреймҳои стек маъмулан (always?) дастур *пас аз* занг ҳастанд, ки ин воқеияти стек стек мебошад.
// Символизатсияи ин боиси он мегардад, ки рақами filename/line як пеш бошад ва шояд ба холигӣ равад, агар он дар охири функсия бошад.
//
// Чунин ба назар мерасад, ки ин асосан ҳамеша дар ҳама платформаҳо дида мешавад, бинобар ин, мо ҳамеша онро аз ip ҳалшуда бароварда, онро ба дастури қаблӣ ба ҷои дастури баргаштан ҳал мекунем.
//
//
// Идеалӣ, мо ин корро намекардем.
// Дар ҳолати беҳтарин, мо аз зангҳои API `resolve` талаб мекунем, ки -1-ро дастӣ иҷро кунанд ва ҳисоб кунанд, ки онҳо маълумоти ҷойгиршавӣ барои дастури *қаблӣ*-ро мехоҳанд, на ҳозира.
// Идеалӣ, мо инчунин дар `Frame` фош хоҳем кард, агар мо воқеан суроғаи дастури навбатӣ ё ҳозира бошем.
//
// Дар ҳоли ҳозир, гарчанде ки ин як нигаронии зебо аст, бинобар ин, мо ҳамеша дар дохили он ҳамеша якеро мекашем.
// Истеъмолкунандагон бояд кор кунанд ва натиҷаҳои хуб ба даст оранд, бинобар ин мо бояд ба қадри кофӣ хуб бошем.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Ҳамон тавре ки `resolve`, танҳо хатарнок аст, зеро он синхронизатсия нашудааст.
///
/// Ин функсия кафолатҳои ҳамоҳангсозӣ надорад, аммо вақте ки `std` хусусияти ин crate тартиб дода намешавад, мавҷуд аст.
/// Барои ҳуҷҷатҳо ва мисолҳои бештар ба функсияи `resolve` нигаред.
///
/// # Panics
///
/// Маълумотро дар бораи `resolve` барои огоҳӣ дар `cb` ба вохима нигаред.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Ҳамон тавре ки `resolve_frame`, танҳо хатарнок аст, зеро он синхронизатсия нашудааст.
///
/// Ин функсия кафолатҳои ҳамоҳангсозӣ надорад, аммо вақте ки `std` хусусияти ин crate тартиб дода намешавад, мавҷуд аст.
/// Барои ҳуҷҷатҳо ва мисолҳои бештар ба функсияи `resolve_frame` нигаред.
///
/// # Panics
///
/// Маълумотро дар бораи `resolve_frame` барои огоҳӣ дар `cb` ба вохима нигаред.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait, ки ҳалли рамзро дар файл нишон медиҳад.
///
/// Ин trait ҳамчун объекти trait ба пӯшидани функсияи `backtrace::resolve` дода мешавад ва он амалан фиристода мешавад, зеро маълум нест, ки татбиқи он кадом аст.
///
///
/// Рамз метавонад дар бораи вазифа маълумоти контексталӣ диҳад, масалан ном, номи файл, рақами сатр, суроғаи дақиқ ва ғайра.
/// На ҳама иттилоот ҳамеша дар рамз мавҷуданд, аз ин рӯ, ҳамаи усулҳо `Option` бармегардонанд.
///
///
pub struct Symbol {
    // TODO: ин умри дарозмуддат бояд дар ниҳоят ба `Symbol` идома ёбад,
    // аммо ин айни замон як тағироти ҷиддӣ аст.
    // Дар ҳоли ҳозир, ин бехатар аст, зеро `Symbol` танҳо ҳамеша бо истинод дода мешавад ва наметавонад онро клонидан мумкин аст.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Номи ин функсияро бармегардонад.
    ///
    /// Сохтори баргашта метавонад барои пурсидани хосиятҳои гуногун дар бораи номи аломат истифода шавад:
    ///
    ///
    /// * Татбиқи `Display` рамзи вайроншударо чоп мекунад.
    /// * Арзиши хоми `str`-и рамзро дастрас кардан мумкин аст (агар он utf-8 дуруст бошад).
    /// * Ба байтҳои хом барои номи рамз дастрас шудан мумкин аст.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Суроғаи оғози ин функсияро бармегардонад.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Номи файли хомро ҳамчун бурида бармегардонад.
    /// Ин асосан барои муҳити `no_std` муфид аст.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Рақами сутунро барои он ҷое, ки ин аломат иҷро шуда истодааст, бармегардонад.
    ///
    /// Танҳо gimli дар айни замон дар ин ҷо арзиш медиҳад ва ҳатто пас аз он, агар `filename` `Some` баргардонад ва аз ин рӯ, он гоҳ ба чунин огоҳиҳо монанд аст.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Рақами сатрро барои он ҷое, ки ин аломат иҷро шуда истодааст, бармегардонад.
    ///
    /// Ин арзиши бозгаштан одатан `Some` аст, агар `filename` `Some` баргардонад ва дар натиҷа ба чунин огоҳиҳо монанд аст.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Номи файлро, ки ин функсия муайян шуда буд, бармегардонад.
    ///
    /// Ин айни замон танҳо дар ҳолати истифодаи libbacktrace ё gimli дастрас аст (масалан
    /// unix платформаҳои дигар) ва вақте ки бинарӣ бо debuginfo тартиб дода мешавад.
    /// Агар ҳеҷ яке аз ин шартҳо иҷро карда нашавад, пас ин эҳтимолан `None` бармегардад.
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Шояд рамзи таҳлилшудаи C++ , агар рамзи манғлро ҳамчун Rust таҳлил карда натавонад.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Боварӣ ҳосил кунед, ки ин андозаи сифрро нигоҳ доред, то ин ки хусусияти `cpp_demangle` ҳангоми ғайрифаъол будан хароҷот надорад.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Печондан дар атрофи номи рамз барои дастрасии эргономикии номи ҷудошуда, байтҳои хом, сатри хом ва ғайра.
///
// Ба рамзи мурда иҷозат диҳед, вақте ки хусусияти `cpp_demangle` фаъол карда нашудааст.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Аз байтҳои хоми аслӣ номи нави рамз месозад.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Номи рамзи (mangled)-ро ҳамчун `str` бармегардонад, агар ин рамз utf-8 дуруст бошад.
    ///
    /// Агар шумо хоҳед, ки версияи ҷудошуда амалисозии `Display`-ро истифода баред.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Номи аломати хомро ҳамчун рӯйхати байт бармегардонад
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Ин метавонад барои чоп кардан, агар рамзи ҷудошуда воқеан дуруст набошад, пас хаторо дар инҷо бо роҳи паҳн накардан ба зоҳир ҳал намоед.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Кӯшиши барқарор кардани он хотираи ҳифзшуда, ки барои нишони нишониҳо истифода мешуд.
///
/// Ин усул кӯшиш мекунад, ки ҳама сохторҳои иттилоотии глобалиро, ки дар акси ҳол дар тамоми ҷаҳон ё дар ришта ҳифз шудаанд, озод кунанд, ки одатан маълумоти таҳлилшудаи DWARF ё монандро пешниҳод мекунанд.
///
///
/// # Caveats
///
/// Гарчанде ки ин функсия ҳамеша дастрас аст, он дарвоқеъ дар аксари татбиқҳо коре намекунад.
/// Китобхонаҳо ба мисли dbghelp ё libbacktrace барои тақсимоти ҳолат ва идоракунии хотираи ҷудошуда имконият намедиҳанд.
/// Дар ҳоли ҳозир хусусияти `gimli-symbolize`-и ин crate ягона хусусиятест, ки ин функсия ягон таъсире дорад.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}