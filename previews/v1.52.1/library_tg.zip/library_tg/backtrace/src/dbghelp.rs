//! Модул барои кӯмак дар идоракунии пайвастҳои dbghelp дар Windows
//!
//! Пуштӣ дар Windows (ҳадди аққал барои MSVC) асосан тавассути `dbghelp.dll` ва функсияҳои гуногуне, ки дар он мавҷуданд, кор мекунанд.
//! Ин функсияҳо айни замон *динамикӣ* бор карда мешаванд, на ба `dbghelp.dll` статикӣ.
//! Ин айни замон аз ҷониби китобхонаи стандартӣ анҷом дода мешавад (ва дар назария он ҷо талаб карда мешавад), аммо кӯшиш ба коҳиш додани вобастагии статикии dll-и китобхона аст, зеро аксбардорӣ одатан хеле ихтиёрӣ аст.
//!
//! Гуфта мешавад, `dbghelp.dll` қариб ҳамеша бомуваффақият ба Windows бор мекунад.
//!
//! Дар хотир доред, ки азбаски мо ҳамаи ин дастгириро ба таври динамикӣ бор мекунем, мо наметавонем таърифҳои хомро дар `winapi` истифода барем, балки ба мо лозим аст, ки намудҳои нишоннамои функсияро худамон муайян кунем ва истифода барем.
//! Мо аслан намехоҳем дар тиҷорати нусхабардории winapi бошем, аз ин рӯ мо дорои хусусияти Cargo `verify-winapi` ҳастем, ки тасдиқ мекунад, ки ҳамаи пайвастагиҳо бо винапи мувофиқат мекунанд ва ин хусусият дар CI фаъол карда шудааст.
//!
//! Ниҳоят, шумо дар ин ҷо қайд хоҳед кард, ки dll барои `dbghelp.dll` ҳеҷ гоҳ фароварда намешавад ва ин айни замон қасдан аст.
//! Фикр дар он аст, ки мо метавонем онро дар саросари ҷаҳон кэш кунем ва дар байни зангҳо ба API истифода барем, аз loads/unloads гарон.
//! Агар ин мушкилот барои детекторҳои ихроҷ ё чизе монанд бошад, вақте ки мо ба он ҷо мерасем, аз болои пул убур карда метавонем.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Дар атрофи `SymGetOptions` ва `SymSetOptions` кор накунед, ки дар худи winapi мавҷуд нестанд.
// Дар акси ҳол, ин танҳо вақте истифода мешавад, ки мо намудҳоро бар зидди winapi дубора тафтиш кунем.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Дар winapi ҳанӯз муайян нашудааст
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Ин дар winapi муайян карда шудааст, аммо ин нодуруст аст (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Дар winapi ҳанӯз муайян нашудааст
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ин макро барои муайян кардани сохтори `Dbghelp` истифода мешавад, ки дар дохили он ҳамаи ишоракунакҳои функсионалиро дар бар мегирад.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL барои `dbghelp.dll` бор карда шудааст
            dll: HMODULE,

            // Ҳар як нишоннамои функсия барои ҳар як функсияе, ки мо метавонем истифода барем
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Дар аввал мо DLL-ро бор накардаем
            dll: 0 as *mut _,
            // Initiall ҳамаи функсияҳо ба сифр гузошта шудаанд, то онҳо динамикӣ бор карда шаванд.
            //
            $($name: 0,)*
        };

        // Typedef барои ҳар як намуди функсия.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Кӯшишҳо барои кушодани `dbghelp.dll`.
            /// Муваффақиятро бармегардонад, агар он кор кунад ё хато, агар `LoadLibraryW` ноком шавад.
            ///
            /// Panics агар китобхона аллакай бор карда шуда бошад.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Вазифа барои ҳар як усуле, ки мо мехоҳем истифода барем.
            // Ҳангоми даъват он нишондиҳандаи функсияи ҳифзшударо мехонад ё онро бор мекунад ва арзиши боршударо бармегардонад.
            // Борҳо барои муваффақ шудан изҳор карда мешаванд.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Ваколатномаи роҳат барои истифодаи қуфлҳои тозакунӣ барои истифодаи вазифаҳои dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Ҳама дастгирии заруриро барои дастрасӣ ба функсияҳои `dbghelp` API аз ин crate оғоз кунед.
///
///
/// Дар хотир доред, ки ин функсия **бехатар** аст, он дар дохили худ ҳамоҳангсозии худро дорад.
/// Инчунин қайд кунед, ки ин функсияро якчанд маротиба такроран даъват кардан хатарнок аст.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Аввалин чизе, ки мо бояд кунем, ин ҳамоҳангсозии ин вазифа аст.Инро метавон дар як вақт аз риштаҳои дигар ё рекурсивӣ дар дохили як ришта номид.
        // Аҳамият диҳед, ки ин аз он ҳам назарфиребтар аст, зеро он чизе, ки мо дар ин ҷо истифода мебарем, `dbghelp`,*инчунин* бояд дар ин раванд бо ҳамаи зангҳои дигари `dbghelp` ҳамоҳанг карда шавад.
        //
        // Одатан, дар ҳақиқат ҳамон қадар зангҳо ба `dbghelp` дар ҳамон як раванд вуҷуд надоранд ва мо эҳтимолан гумон карда метавонем, ки танҳо мо ба он дастрасӣ дорем.
        // Бо вуҷуди ин, як корбари дигари дигаре ҳаст, ки мо бояд аз он хавотир шавем, ки ин ба таври ҳайратовар худи мост, аммо дар китобхонаи стандартӣ.
        // Китобхонаи стандартии Rust барои дастгирии ақибнишинӣ аз ин crate вобаста аст ва ин crate низ дар crates.io мавҷуд аст.
        // Ин маънои онро дорад, ки агар китобхонаи стандартӣ ақидаи ақрабаки panic-ро чоп кунад, он метавонад бо ин crate, ки аз crates.io омадааст, сабқат кунад ва боиси вайрон шудани сегонаҳо гардад.
        //
        // Барои кӯмак ба ҳалли ин мушкилоти ҳамоҳангсозӣ, мо дар ин ҷо як ҳиллаи хоси Windows-ро истифода мебарем (ин, пас аз ҳама, маҳдудияти махсуси Windows дар бораи синхронизатсия аст).
        // Мо *сессия-маҳаллӣ* номи мутексро месозем, то ин зангро ҳимоя кунад.
        // Ҳадаф аз он иборат аст, ки китобхонаи стандартӣ ва ин crate набояд API-ҳои сатҳи Rust-ро барои ҳамоҳангсозӣ мубодила кунанд, балки метавонанд дар паси парда кор кунанд, то боварӣ ҳосил кунанд, ки онҳо бо ҳамдигар ҳамоҳанг карда истодаанд.
        //
        // Ҳамин тариқ, вақте ки ин функсия тавассути китобхонаи стандартӣ ё тавассути crates.io номида мешавад, мо боварӣ дошта метавонем, ки ҳамон мутекс ба даст оварда мешавад.
        //
        // Ҳамин тавр, ин ҳама чизи гуфтанист, ки аввалин чизе, ки мо дар ин ҷо анҷом медиҳем, мо ба таври атом `HANDLE` месозем, ки мутекс дар Windows ном дорад.
        // Мо каме бо дигар риштаҳои мубодилаи ин функсия махсус синхронизатсия мекунем ва кафолат медиҳем, ки дар як мисоли ин функсия танҳо як дастгоҳ сохта мешавад.
        // Аҳамият диҳед, ки дастгоҳ ҳеҷ гоҳ баста намешавад, вақте ки он дар ҷаҳонӣ нигоҳ дошта мешавад.
        //
        // Пас аз он ки мо воқеан қулфро тай кардем, онро содда ба даст меорем ва дастаки `Init`-и мо, ки онро ба дасти мо месупорем, дар ниҳоят тарки он хоҳад буд.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Хуб, ҷон!Ҳоло, ки ҳамаи мо бехатар синхронизатсия шудаем, биёед воқеан коркарди ҳама чизро оғоз кунем.
        // Аввалан, мо бояд таъмин кунем, ки `dbghelp.dll` воқеан дар ин раванд бор карда шудааст.
        // Мо ин корро ба таври динамикӣ барои пешгирӣ кардани вобастагии статикӣ анҷом медиҳем.
        // Ин таърихан барои кор дар атрофи мушкилоти аҷоиби алоқаманд анҷом дода шудааст ва бо мақсади сайёр кардани бинар дутарафа пешбинӣ шудааст, зеро ин асосан танҳо як утилитаи ислоҳӣ аст.
        //
        //
        // Пас аз он ки мо `dbghelp.dll`-ро кушодем, ба мо лозим аст, ки баъзе функсияҳои ибтидоиро дар он даъват кунем, ва ин дар поён муфассалтар аст.
        // Бо вуҷуди ин, мо ин корро танҳо як маротиба анҷом медиҳем, бинобар ин мо як логияи глобалӣ дорем, ки нишон медиҳад, ки мо ҳоло ба анҷом расидаем ё не.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Боварӣ ҳосил кунед, ки парчами `SYMOPT_DEFERRED_LOADS` гузошта шудааст, зеро мувофиқи ҳуҷҷатҳои худи MSVC дар ин бора: "This is the fastest, most efficient way to use the symbol handler.", пас биёед ин корро кунем!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Дар асл рамзҳоро бо MSVC оғоз кунед.Дар хотир доред, ки ин метавонад ноком шавад, аммо мо инро нодида мегирем.
        // Барои ин як тонна санъати қаблӣ вуҷуд надорад, аммо LLVM дар дохили кишвар ба назар чунин мерасад, ки арзиши баргардонидан дар инҷо нодида гирифта мешавад ва яке аз китобхонаҳои тозакунанда дар LLVM огоҳии даҳшатнокро чоп мекунад, агар ин натиҷа надиҳад, аммо асосан онро дар дарозмуддат нодида мегирад.
        //
        //
        // Як ҳолат ин барои Rust хеле зиёд аст, ки китобхонаи стандартӣ ва ин crate дар crates.io ҳам мехоҳанд барои `SymInitializeW` рақобат кунанд.
        // Китобхонаи стандартӣ таърихан мехост, ки аксар вақт тозакуниро оғоз кунад, аммо ҳоло, ки ин crate-ро истифода мебарад, ин маънои онро дорад, ки касе аввал ба ибтидосозӣ хоҳад расид ва дигаре ин ибтидо мегирад.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}