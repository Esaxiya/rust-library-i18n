use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr дубора занг мезанад, ки барои ҳар як DSO, ки ба раванд пайвастааст, нишоннамои dl_phdr_info мегирад.
    // dl_iterate_phdr инчунин кафолати динамикиро аз оғоз то ба охир такрор карданро кафолат медиҳад.
    // Агар бозгаштан арзиши ғайри сифр баргардонад, такрор барвақт қатъ карда мешавад.
    // 'data' ҳамчун далели сеюм барои бозгашти ҳар як занг қабул карда мешавад.
    // 'size' андозаи dl_phdr_info-ро медиҳад.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Мо бояд ID-и сохташаванда ва баъзе маълумоти асосии сарлавҳаи барномаро таҳлил кунем, ки ин маънои онро дорад, ки мо инчунин аз ашёи мушаххаси ELF каме ашё хоҳем дошт.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Ҳоло мо бояд сохтори навъи dl_phdr_info-ро, ки аз ҷониби линкчии ҳозираи фучия истифода мешавад, каме барои каме такрор кунем.
// Chromium инчунин ин сарҳади ABI ва инчунин crashpad дорад.
// Дар ниҳоят, мо мехоҳем ин парвандаҳоро барои истифодаи элф-ҷустуҷӯ интиқол диҳем, аммо мо бояд инро дар SDK пешниҳод кунем ва ин ҳанӯз анҷом нашудааст.
//
// Ҳамин тариқ, мо (ва онҳо) дармондаем, ки ин усулро истифода барем, ки бо фуксия libc пайвастагии сахт пайдо мекунад.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Мо ҳеҷ гуна роҳи донистани дурустии e_phoff ва e_phnum надорем.
    // libc бояд инро барои мо таъмин кунад, аммо бехатар аст, ки дар ин ҷо як бурида ташкил кунед.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr сарлавҳаи барномаи ELF 64-битро дар endianness меъмории мақсаднок нишон медиҳад.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr як сарлавҳаи дурусти барномаи ELF ва мундариҷаи онро нишон медиҳад.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Мо ҳеҷ гуна санҷиши дурусти p_addr ё p_memsz надорем.
    // Lbc-и Fuchsia аввал ёддоштҳоро таҳлил мекунад, аммо аз рӯи ин ҷо будан ин сарлавҳаҳо бояд эътибор дошта бошанд.
    //
    // NoteIter талаб намекунад, ки маълумоти асосӣ эътибор дошта бошанд, аммо ҳудуди он эътибор дорад.
    // Мо боварӣ дорем, ки libc кафолат додааст, ки ин барои мо дар ин ҷо аст.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Намуди ёддошт барои сохтани ID-ҳо.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr сарлавҳаи ёддошти ELF-ро дар endianness ҳадаф нишон медиҳад.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Нота як ёддошти ELF-ро нишон медиҳад (сарлавҳа + мундариҷа).
// Номи мазкур ҳамчун буридаи u8 боқӣ мондааст, зеро он на ҳамеша бекор карда мешавад ва rust кофӣ аст, ки тафтиш кардани байтҳо ба ҳар ҳол мувофиқат кунад.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ба шумо имкон медиҳад, ки бехатар аз болои сегменти нота такрор кунед.
// Он замоне қатъ мешавад, ки хатогӣ рух додааст ё дигар ёддоштҳо мавҷуд нестанд.
// Агар шумо маълумоти бардурӯғро такрор кунед, он тавре кор мекунад, ки гӯё ягон ёддошт ёфт нашуда бошад.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Инвариантҳои функсия ин аст, ки нишоннамо ва андозаи додашуда доираи дурусти байтро нишон диҳанд, ки ҳамаро хондан мумкин аст.
    // Мазмуни ин байтҳо метавонад ҳар чизе бошад, аммо диапазон бояд эътибор дошта бошад, то ин бехатар бошад.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to баробарсозии 'x' ба 'то-байт, бо назардошти 'to' иқтидори 2 мебошад.
// Ин намунаи стандартиро дар рамзи таҳлили C/C ++ ELF риоя мекунад, ки дар он (x + ба, 1)&-to истифода мешавад.
// Rust намегузорад, ки мо истифодаи инкорро рад кунед, аз ин рӯ ман истифода мекунам
// Табдили 2's-complement барои барқарор кардани он.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 аз байт нумерро (агар мавҷуд бошад) истеъмол мекунад ва ба таври илова мутобиқати буриши ниҳоиро таъмин мекунад.
// Агар ё миқдори байтҳои дархостшуда хеле калон бошанд ё пас аз он, ки бинт ба сабаби кофӣ набудани байт мавҷуд аст, онро бурдан ғайриимкон аст, Ҳеҷ баргардонида намешавад ва бурида тағир дода намешавад.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ин вазифа дигаргуниҳои ҳақиқӣ надорад, ки даъваткунанда бояд онро дастгирӣ кунад, ба ғайр аз он, ки 'bytes' бояд барои иҷрои вазифа мувофиқат кунад (ва дар баъзе меъморӣ дуруст аст).
// Арзишҳо дар соҳаҳои Elf_Nhdr шояд сафсата бошанд, аммо ин вазифа чунин чизро таъмин намекунад.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // То он даме, ки фазои кофӣ мавҷуд аст, бехатар аст ва мо танҳо тасдиқ кардем, ки дар изҳороти дар боло буда, ин набояд хатарнок бошад.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Дар хотир доред, ки sice_of: :<Elf_Nhdr>() ҳамеша 4 байт мутобиқ карда шудааст.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Санҷед, ки оё мо ба охир расидаем.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Мо як nhdr-ро интиқол медиҳем, аммо структураи натиҷагирифтаро бодиққат баррасӣ мекунем.
        // Мо ба namesz ё descsz эътимод надорем ва ҳеҷ гуна қарорҳои хатарнокро аз рӯи навъ намегирем.
        //
        // Пас, ҳатто агар мо аз партовҳои пурра берун оем, мо бояд бехатар бошем.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Нишон медиҳад, ки як сегмент иҷрошаванда аст.
const PERM_X: u32 = 0b00000001;
/// Нишон медиҳад, ки як сегмент қобили навиштан аст.
const PERM_W: u32 = 0b00000010;
/// Нишон медиҳад, ки як сегмент хонданист.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Сегменти ELF-ро дар вақти корӣ намояндагӣ мекунад.
struct Segment {
    /// Суроғаи виртуалии мӯҳтавои ин сегментро медиҳад.
    addr: usize,
    /// Андозаи ҳаҷми мундариҷаи ин сегментро медиҳад.
    size: usize,
    /// Бо файли ELF суроғаи виртуалии ин сегментро ба модул медиҳад.
    mod_rel_addr: usize,
    /// Иҷозатҳои дар файли ELF додашударо медиҳад.
    /// Аммо ин иҷозатҳо ҳатман иҷозатҳое мебошанд, ки дар вақти кор мавҷуданд.
    flags: Perm,
}

/// Бигзор як такрори сегментҳои DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Намояндаи ELF DSO (Объекти муштараки динамикӣ).
/// Ин намуд ба маълумоте, ки дар DSO воқеӣ нигоҳ дошта мешавад, на нусхабардории худро.
struct Dso<'a> {
    /// Пайванди динамикӣ ба мо ҳамеша ном медиҳад, ҳатто агар ном холӣ бошад.
    /// Дар сурати иҷрошавандаи асосӣ, ин ном холӣ хоҳад буд.
    /// Дар ҳолати объекти муштарак, он soname хоҳад буд (нигаред ба DT_SONAME).
    name: &'a str,
    /// Дар Фучия амалан ҳамаи бинарҳо ID-ҳои сохташуда доранд, аммо ин талаби қатъӣ нест.
    /// Баъд аз он, ки ягон build_id вуҷуд надошта бошад, мо метавонем маълумоти DSO-ро бо файли воқеии ELF мувофиқат кунем, пас мо талаб мекунем, ки ҳар як DSO инҷоро дошта бошад.
    ///
    /// DSO бе build_id сарфи назар карда мешаванд.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Итератори сегментҳоро дар ин DSO бармегардонад.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Ин хатогиҳо масъалаҳоеро, ки ҳангоми таҳлили маълумот дар бораи ҳар як DSO ба миён меоянд, рамзгузорӣ мекунанд.
///
enum Error {
    /// NameError маънои онро дорад, ки ҳангоми табдил додани сатри услуби C ба сатри rust хатогӣ рух додааст.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError маънои онро дорад, ки мо ID сохтанро пайдо накардем.
    /// Ин метавонад аз он сабаб бошад, ки DSO ID-и сохтанро надошт ё сегменти дорои ID-и сохторӣ нодуруст аст.
    ///
    BuildIDError,
}

/// Зангҳо ё 'dso' ё 'error' барои ҳар як DSO, ки бо раванди пайвасткунандаи динамикӣ пайваст карда мешаванд.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, ки яке аз усулҳои хӯрокхӯриро дорад, ки foreach DSO номида мешавад.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr кафолат медиҳад, ки info.name ба макони дуруст ишора мекунад.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ин функсия нишони рамзи Fuchsia барои ҳама маълумоти дар DSO мавҷудбударо чоп мекунад.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}