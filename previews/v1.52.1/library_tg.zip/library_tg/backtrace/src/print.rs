#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Форматер барои пастракҳо.
///
/// Ин навъро барои чоп кардани ақибгардонӣ, новобаста аз он, ки худи пуштибонӣ аз куҷост, истифода бурдан мумкин аст.
/// Агар шумо навъи `Backtrace` дошта бошед, пас татбиқи `Debug` он аллакай ин формати чопро истифода мебарад.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Услубҳои чоп, ки мо метавонем чоп кунем
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Наздики пасттарро чоп мекунад, ки беҳтаринаш танҳо маълумоти дахлдорро дар бар мегирад
    Short,
    /// Наздикеро чоп мекунад, ки тамоми маълумоти имконпазирро дар бар мегирад
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// `BacktraceFmt` нав эҷод кунед, ки ба `fmt` пешниҳодшуда натиҷа нависад.
    ///
    /// Далели `format` услуби дар он чопшудаи ақибро назорат мекунад ва далели `print_path` барои чоп кардани `BytesOrWideString` ҳолатҳои номҳои файл истифода мешавад.
    /// Худи ин навъи чопи номи файлҳоро иҷро намекунад, аммо барои ин дубора бозгаштан лозим аст.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Дебочаро барои чоп кардани ақибнома чоп мекунад.
    ///
    /// Ин дар баъзе платформаҳо талаб карда мешавад, то паси сурудҳо баъдтар пурра рамзӣ карда шаванд ва дар акси ҳол, ин бояд танҳо усули аввалине бошад, ки шумо пас аз эҷоди `BacktraceFmt` даъват мекунед.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Ба баромади ақибмонда чорчӯба илова мекунад.
    ///
    /// Ин ӯҳдадорӣ мисоли RAII-и `BacktraceFrameFmt`-ро бармегардонад, ки метавонад барои дарвоқеъ чоп кардани чаҳорчӯба истифода шавад ва ҳангоми нобудкунӣ он ҳисобкунаки фреймро афзоиш медиҳад.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Натиҷаи ақибро ба анҷом мерасонад.
    ///
    /// Ин дар айни замон корношоям аст, аммо барои мутобиқати future бо форматҳои ақибмонӣ илова карда мешавад.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Дар ҳоли ҳозир не-оп--аз ҷумла ин hook барои иҷозати иловаҳои future.
        Ok(())
    }
}

/// Форматер барои танҳо як чорчӯбаи пуштибонӣ.
///
/// Ин навъи функсияи `BacktraceFmt::frame` сохта шудааст.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Бо ин форматгари чорчӯба `BacktraceFrame` чоп мекунад.
    ///
    /// Ин ҳама нусхаҳои `BacktraceSymbol` дар доираи `BacktraceFrame` рекурсивӣ чоп мекунад.
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol`-ро дар давоми `BacktraceFrame` чоп мекунад.
    ///
    /// # Хусусиятҳои зарурӣ
    ///
    /// Ин функсия талаб мекунад, ки хусусияти `std` аз `backtrace` crate фаъол карда шавад ва хусусияти `std` бо нобаёнӣ фаъол карда шудааст.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ин олӣ нест, ки мо ҳеҷ чизро ба чоп нарасонем
            // бо номҳои файлҳои ғайри utf8.
            // Хушбахтона тақрибан ҳама чиз utf8 аст, бинобар ин ин набояд бад бошад.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// `Frame` ва `Symbol`-и пайдошударо чоп мекунад, ки маъмулан аз зангҳои хоми ин crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Ба баромади ақибмонда чорчӯбаи хом илова мекунад.
    ///
    /// Ин усул, баръакси усулҳои пешина, далелҳои хомро дар сурате мегирад, ки агар онҳо манбаъи маконҳои гуногун бошанд.
    /// Дар хотир доред, ки ин метавонад барои як кадр якчанд маротиба номида шавад.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Ба баромади ақибмонда чорчӯбаи хом илова мекунад, аз ҷумла маълумоти сутун.
    ///
    /// Ин усул, ба мисли пешина, далелҳои хомро дар сурате мегирад, ки агар онҳо аз ҷойҳои гуногун сарчашма гиранд.
    /// Дар хотир доред, ки ин метавонад барои як кадр якчанд маротиба номида шавад.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Фучия наметавонад дар дохили як раванд рамзгузорӣ кунад, аз ин рӯ формати махсусе дорад, ки баъдтар метавонад онро рамзгузорӣ кунад.
        // Онро ба ҷои чоп кардани суроғаҳо дар формати худамон дар ин ҷо чоп кунед.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ҳоҷати чоп кардани фоторамкаҳои "null" нест, ин асосан маънои онро дорад, ки ақибнишинии система каме хостори пайгирии супер дур буд.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Барои кам кардани андозаи TCB дар анклави Sgx, мо намехоҳем, ки вазифаи ҳалли рамзро амалӣ кунем.
        // Баръакс, мо метавонем офсетро дар ин ҷо чоп кунем, ки баъдтар онро барои ислоҳи вазифа харит кардан мумкин аст.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Индекси чаҳорчӯба ва инчунин нишоннамои дастури ихтиёрии фреймро чоп кунед.
        // Агар мо аз рамзи якуми ин фрейм берун бошем ҳам, фақат фосилаи мувофиқро чоп мекунем.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Баъдан номи рамзро нависед, бо истифода аз форматкунии алтернативӣ барои маълумоти бештар, агар мо ақибнишинии пурра карда бошем.
        // Дар ин ҷо мо инчунин рамзҳое дорем, ки ном надоранд,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Ва дар охир, шумораи filename/line-ро чоп кунед, агар онҳо дастрас бошанд.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line дар сатрҳо бо номи рамз чоп карда мешаванд, бинобарин баъзе фазои мувофиқро чоп кунед, то худамон ба хатти рост ҳамроҳ шавем.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Намояндаи занги дохилии мо барои чоп кардани номи файл ва сипас чоп кардани рақами сатр.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Агар мавҷуд бошад, рақами сутунро илова кунед.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Мо танҳо дар бораи рамзи якуми чаҳорчӯба ғамхорӣ мекунем
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}