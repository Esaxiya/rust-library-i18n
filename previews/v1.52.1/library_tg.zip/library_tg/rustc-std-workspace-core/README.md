# `rustc-std-workspace-core` crate

Ин crate як шим ва холии crate мебошад, ки ба `libcore` вобастагӣ дорад ва ҳамаи мундариҷаи онро аз нав таҳия мекунад.
crate сармашқи тавонмандсозии китобхонаи стандартӣ вобаста ба crates аз crates.io мебошад

Crates дар crates.io, ки китобхонаи стандартӣ аз ниёз ба `rustc-std-workspace-core` crate аз crates.io вобастагӣ дорад, ки холӣ аст.

Мо `[patch]`-ро барои тағир додани он ба ин crate дар ин анбор истифода мебарем.
Дар натиҷа, crates дар crates.io вобастагии edge ба `libcore`, версияи дар ин анбор муайяншударо мекашад.
Ин бояд тамоми канорҳои вобастагӣ кашида шавад, то Cargo бомуваффақият месозад crates!

Дар хотир доред, ки crates дар crates.io бояд ба ин crate бо номи `core` вобаста бошад, то ҳама чиз дуруст кор кунад.Барои ин, онҳо метавонанд истифода баранд:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Тавассути истифодаи калиди `package`, crate ба `core` тағир дода шуд, яъне он монанди хоҳад буд

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

вақте ки Cargo мураккабро даъват мекунад ва директиваи махфии `extern crate core`-ро, ки аз ҷониби компилятсия ворид карда мешавад, қонеъ мекунад.




