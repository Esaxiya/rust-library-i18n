//! Китобхонаи дастгирӣ барои муаллифони макро ҳангоми муайян кардани макросҳои нав.
//!
//! Ин китобхона, ки аз ҷониби тақсимоти стандартӣ пешбинӣ шудааст, намудҳои дар интерфейси таърифҳои макросӣ муайяншудаи ба расмият даровардашударо, ба монанди макросҳои `#[proc_macro]` ба функсия монанд, атрибутҳои макроиқтисодии `#[proc_macro_attribute]` ва хусусиятҳои ҳосилаи фармоишӣ '#[proc_macro_derive] "пешниҳод менамояд.
//!
//!
//! Барои маълумоти бештар ба [the book] нигаред.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Муайян мекунад, ки proc_macro ба барномаи ҳозира иҷрошаванда дастрас аст.
///
/// Proc_macro crate танҳо барои истифода дар дохили татбиқи макросҳои расмӣ пешбинӣ шудааст.Ҳама функсияҳо дар ин crate panic, агар аз беруни макроими расмӣ даъват карда шаванд, масалан аз скрипти сохтан ё санҷиши воҳид ё бинарии оддии Rust.
///
/// Бо дарназардошти китобхонаҳои Rust, ки барои дастгирии ҳолатҳои ҳам макросӣ ва ҳам ғайримакроӣ пешбинӣ шудаанд, `proc_macro::is_available()` роҳи ғайри ваҳмро барои муайян кардани он, ки инфрасохторе, ки барои истифодаи API аз proc_macro зарур аст, дар ҳоли ҳозир дастрас аст.
/// Бозмегардонад ҳақиқӣ, агар аз дохили макроиқонунии протседорӣ даъват карда шуда бошад, бардурӯғ, агар аз ягон бинари дигар даъват карда шуда бошад.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Намуди асосии пешбининамудаи ин crate, ки ҷараёни абстрактии tokens ё махсустар пайдарпайии дарахтони token-ро ифода мекунад.
/// Намуд барои такрори он дарахтони token ва баръакс, ҷамъоварии як қатор дарахтони token дар як ҷараён интерфейсҳо фароҳам меорад.
///
///
/// Ин ҳам вуруд ва ҳам баромади `#[proc_macro]`, `#[proc_macro_attribute]` ва `#[proc_macro_derive]` мебошад.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Хато аз `TokenStream::from_str` баргашт.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// `TokenStream`-и холиро бармегардонад, ки дарахтони token надоранд.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Санҷидани он ки ин `TokenStream` холист.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Кӯшишҳои ба tokens шикастани сатр ва таҳлили он tokens ба ҷараёни token.
/// Метавонад бо як қатор сабабҳо ноком шавад, масалан, агар сатр ҳудудҳои номувозин ё аломатҳои дар забон мавҷудбударо дошта бошад.
///
/// Ҳама tokens дар ҷараёни таҳлилшуда `Span::call_site()` дарозӣ мегиранд.
///
/// NOTE: баъзе хатогиҳо метавонанд ба ҷои баргардонидани `LexError` panics-ро ба вуҷуд оранд.Мо ҳуқуқи тағир додани ин хатогиро ба "LexError`" дертар нигоҳ медорем.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Ҷараёни token-ро ҳамчун сатр, ки гӯё бидуни талафот ба ҳамон ҷараёни token табдил меёбад, чоп мекунад (модулҳоро дар бар мегирад), ба истиснои эҳтимолан "TokenTree: : Group`s бо ҳудудҳои `Delimiter::None` ва ҳарфҳои ададии манфӣ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token-ро дар шакли барои ислоҳи хато мувофиқ чоп мекунад.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ҷараёни token месозад, ки дорои як дарахти token мебошад.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Як қатор дарахтони token-ро дар як ҷӯй ҷамъ меорад.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Амалиёти "flattening" дар ҷараёнҳои token, дарахтони token-ро аз ҷараёни сершумори token ба ҷараёни ягона ҷамъ меорад.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Истифодаи татбиқи оптималии if/when имконпазирро истифода баред.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Тафсилоти татбиқи ҷамъиятӣ барои навъи `TokenStream`, ба монанди такроркунандагон.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Итератор аз болои "TokenStream"-и "TokenTree".
    /// Итератсия "shallow" аст, масалан, итератор ба гурӯҳҳои ҷудошуда такрор намешавад ва гурӯҳҳои томро ҳамчун дарахтони token бармегардонад.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tokens худсарона қабул мекунад ва ба `TokenStream` тавсифи вурудро васеъ мекунад.
/// Масалан, `quote!(a + b)` ифодаеро ба вуҷуд меорад, ки ҳангоми баҳо додан `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Бекоркунӣ бо `$` анҷом дода мешавад ва бо роҳи гирифтани як идентификати навбатӣ ҳамчун истилоҳи нохунак кор мекунад.
/// Барои иқтибоси худи `$`, `$$`-ро истифода баред.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Минтақаи коди сарчашма, дар якҷоягӣ бо иттилооти тавсеаи макро.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `Diagnostic` навро бо `message` додашуда дар тӯли `self` месозад.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Фосилае, ки дар сайти таърифи макро ҳал карда мешавад.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Давраи даъвати макрои амалии амалкунанда.
    /// Муайянкунандаҳое, ки бо ин давра сохта шудаанд, ҳал карда мешаванд, ки онҳо бевосита дар ҷои макро зангҳо навишта шудаанд (гигиенаи сайти занг) ва рамзҳои дигар дар сайти макро-зангҳо метавонанд ба онҳо низ муроҷиат кунанд.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Фосилае, ки гигиенаи `macro_rules`-ро ифода мекунад ва баъзан дар макони таърифи макро (тағирёбандаҳои маҳаллӣ, барчаспҳо, `$crate`) ва баъзан дар сайти макро-зангҳо (ҳама чизи дигар) ҳал мешавад.
    ///
    /// Ҷойгоҳи тӯлонӣ аз сайти даъват гирифта шудааст.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Файли аслии манбаъ, ки ин фосила ба он ишора мекунад.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` барои tokens дар тавсеаи макрои қаблӣ, ки аз он `self` тавлид шуда буд, агар бошад.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Дарозии коди сарчашмаи пайдоиш, ки `self` аз он сохта шудааст.
    /// Агар ин `Span` аз дигар тавсеаи макро тавлид нашуда бошад, пас арзиши баргаштан ба ҳамон `*self` баробар аст.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Мегирад, ки line/column оғоз дар файли манбаъ барои ин давра.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Мегирад, ки line/column хотима дар файли манбаъ барои ин давра.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Давраи наверо дар бар мегирад, ки `self` ва `other`-ро дар бар мегирад.
    ///
    /// `None`-ро бармегардонад, агар `self` ва `other` аз файлҳои гуногун бошанд.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Давраи навро бо ҳамон маълумоти line/column бо `self` эҷод мекунад, аммо рамзҳоро тавре месозад, ки гӯё дар `other` бошад.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Давраи навро бо ҳамон рафтори ҳалли ном бо `self` эҷод мекунад, аммо бо маълумоти line/column аз `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Муқоиса бо давраҳо барои дидани он, ки оё онҳо баробаранд.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Матни сарчашмаро паси як фосила бармегардонад.
    /// Ин рамзи аслии манбаъ, аз ҷумла ҷойҳо ва шарҳҳоро нигоҳ медорад.
    /// Он танҳо дар сурате натиҷа медиҳад, ки давра ба рамзи аслии манбаъ мувофиқат кунад.
    ///
    /// Note: Натиҷаи мушоҳидаи макро бояд танҳо ба tokens такя кунад, на ба ин матни манбаъ.
    ///
    /// Натиҷаи ин вазифа беҳтарин кӯшишест, ки танҳо барои ташхис истифода мешавад.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Давраеро дар шакли барои ислоҳи хато мувофиқ чоп мекунад.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Ҷуфти сутуни сатр, ки ибтидо ё охири `Span`-ро ифода мекунад.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Хатти 1-индексатсияшуда дар файли манбаъ, ки фосилаи он (inclusive) оғоз ё хотима меёбад.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Сутуни индекси 0 (бо аломатҳои UTF-8) дар файли сарчашма, ки паҳншавии он (inclusive) оғоз ё хотима меёбад.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Файли манбаи `Span` додашуда.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Роҳ ба ин файли манбаъро мегирад.
    ///
    /// ### Note
    /// Агар миқдори рамзи бо ин `SourceFile` алоқаманд аз ҷониби як макрои беруна сохта шуда бошад, ин макро, ин метавонад роҳи воқеии системаи файлӣ набошад.
    /// Барои тафтиш [`is_real`]-ро истифода баред.
    ///
    /// Инчунин қайд кунед, ки ҳатто агар `is_real` `true`-ро баргардонад, агар `--remap-path-prefix` дар сатри фармон гузаронида шуда бошад, пас роҳи додашуда воқеан дуруст буда наметавонад.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true`-ро бармегардонад, агар ин файли манбаъ файли аслии манбаъ бошад ва бо тавсеаи макрои беруна тавлид нашуда бошад.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ин хак аст, то он даме, ки миқдори интеркатӣ амалӣ карда мешавад ва мо метавонем файлҳои аслии манбаъҳоро, ки дар макросҳои беруна сохта шудаанд, дошта бошем.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Як token ё пайдарҳамии дарахтони token (масалан, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Ҷараёни token, ки дар иҳотаи ҷудокунандагони қавс қарор гирифтааст.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Муайянкунанда.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Як аломати пунктуатсионии ягона ("+", `,`, `$` ва ғайра).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Аломати аслии (`'a'`), сатри (`"hello"`), рақами (`2.3`) ва ғайра.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Давраи ин дарахтро бармегардонад ва ба усули `span`-и token ё ҷараёни ҷудошуда вогузор мекунад.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Фосилаи *танҳо барои ин token*-ро танзим мекунад.
    ///
    /// Дар хотир доред, ки агар ин token як `Group` бошад, пас ин усул фосилаи ҳар як tokens дохилиро ба танзим дароварда наметавонад, ин танҳо ба усули `set_span`-и ҳар як вариант вогузор хоҳад шуд.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Дарахти token-ро дар шакли барои ислоҳи хато мувофиқ чоп мекунад.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ҳар яке аз инҳо дар навъи struct дар ислоҳи ҳосилшуда ном доранд, бинобар ин бо қабати иловагии бавосита ташвиш надиҳед
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Дарахти token-ро ҳамчун сатре, ки гӯё бидуни талафот ба ҳамон дарахти token табдил меёбад, чоп мекунад (модулҳои дарозмуддат), ба истиснои эҳтимолан "TokenTree: : Group`s бо ҳудудҳои `Delimiter::None` ва ҳарфҳои ададии манфӣ.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ҷараёни ҷудошудаи token.
///
/// `Group` дар дохили худ дорои `TokenStream` мебошад, ки онро бо "Delimiter" иҳота кардааст.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Тасвир медиҳад, ки чӣ гуна пайдарпайии дарахтони token ҷудо карда шудааст.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Ҷудосози номуайян, ки метавонад, масалан, дар атрофи tokens пайдо шавад, ки аз "macro variable" `$var` бармеояд.
    /// Дар ҳолатҳое, ба монанди `$var * 3`, ки `$var` `1 + 2` аст, нигоҳ доштани афзалиятҳои оператор муҳим аст.
    /// Ҷудокунандагони номуайян метавонанд дар гардиши гардиши token тавассути сатр наҷот ёбанд.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// `Group` навро бо ҷудосози додашуда ва ҷараёни token месозад.
    ///
    /// Ин созанда фосилаи ин гурӯҳро ба `Span::call_site()` муқаррар мекунад.
    /// Барои тағир додани фосила шумо метавонед усули `set_span`-ро дар зер истифода баред.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Ҳудуди ин `Group`-ро бармегардонад
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// `TokenStream`-и tokens-ро, ки дар ин `Group` ҷудо шудаанд, бармегардонад.
    ///
    /// Дар хотир доред, ки ҷараёни баргаштаи token ҷудосози дар боло баргаштаро дар бар намегирад.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Муддатро барои ҷудокунандагони ин ҷараёни token бармегардонад ва тамоми `Group`-ро дар бар мегирад.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Фосилаи баргаштаро ба ҷудосози кушоди ин гурӯҳ бармегардонад.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Фосилаи баргаштаро ба ҷудокунандаи пӯшидаи ин гурӯҳ бармегардонад.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Фосилаи ин ҷудокунандагони "Гурӯҳ"-ро танзим мекунад, аммо tokens дохилии онро не.
    ///
    /// Ин усул **тамоми** tokens дохилиро, ки ин гурӯҳ паҳн кардааст, муқаррар намекунад, балки он танҳо фарқияти tokens-ро дар сатҳи `Group` мегузорад.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Гурӯҳро ҳамчун як сатр чоп мекунад, ки бояд бе талафот ба як гурӯҳ баргардонида шавад (модулҳои дароз), ба истиснои эҳтимолан "TokenTree: : Group`s бо ҷудокунандагони `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` як аломати пунктуатсионии ба монанди `+`, `-` ё `#` мебошад.
///
/// Операторони бисёрҳарфӣ ба монанди `+=` ҳамчун ду ҳолати `Punct` бо шаклҳои гуногуни `Spacing` баргардонида мешаванд.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Новобаста аз он ки `Punct` фавран аз ҷониби `Punct` дигар ё аз паси token ё фазои сафед паси дигар меояд.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// Масалан, `+` `Alone` дар `+ =`, `+ident` ё `+()` аст.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// масалан, `+` `Joint` дар `+=` ё `'#` аст.
    /// Ғайр аз ин, иқтибоси ягона `'` метавонад бо идентификаторҳо ҳамроҳ шуда, умри дароз `'ident` созад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Аз аломат ва фосилаи додашуда `Punct` нав месозад.
    /// Далели `ch` бояд аломати дурусти пунктуатсия бошад, ки бо он забон иҷозат додааст, вагарна функсия panic хоҳад буд.
    ///
    /// `Punct`-и баргардонидашуда дорои мӯҳлати пешфарзии `Span::call_site()` мебошад, ки минбаъд бо усули `set_span` дар поён танзим карда мешавад.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Арзиши ин аломати пунктуатсияро ҳамчун `char` бармегардонад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Фосилаи ин аломатҳои пунктуатсияро бармегардонад ва нишон медиҳад, ки оё онро фавран `Punct` дигар дар ҷараёни token пайгирӣ мекунад, бинобар ин онҳо метавонанд ба оператори бисёрҳарфҳои (`Joint`) муттаҳид карда шаванд ё пас аз он token ё фосилаи (`Alone`) дигар дохил карда шудааст, бинобар ин оператор албатта ба охир расид.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Фосилаи ин аломати пунктуатсияро бармегардонад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Фосилаи ин аломати пунктуатсияро танзим кунед.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Аломатҳои пунктуатсияро ҳамчун сатр чоп мекунад, ки бояд бе талафот ба ҳамон аломат баргардонида шавад.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Муайянкунандаи (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// `Ident` навро бо `string` додашуда ва инчунин `span` и мушаххас месозад.
    /// Далели `string` бояд як идентификатори дурусти бо забон иҷозатдодашуда бошад (аз ҷумла калимаҳои калидӣ, масалан `self` ё `fn`).Дар акси ҳол, функсия panic хоҳад буд.
    ///
    /// Дар хотир доред, ки `span`, айни замон дар rustc, иттилооти гигиенаро барои ин нишондиҳанда танзим мекунад.
    ///
    /// Аз ин вақт, `Span::call_site()` возеҳан ба гигиенаи "call-site" маъқул аст, ки муайянкунандагон бо ин давра сохта мешаванд, гӯё ки онҳо бевосита дар маҳалли ҷойгиршавии занги макро навишта шуда бошанд ва рамзи дигар дар сайти зангҳои макросӣ метавонад ба он ишора кунад. онҳо низ.
    ///
    ///
    /// Баъдтар, ба монанди `Span::def_site()`, имкон медиҳад, ки ба гигиенаи "definition-site" даст кашад, яъне нишондиҳандаҳое, ки бо ин давра сохта шудаанд, дар маҳалли таърифи макро ҳал карда мешаванд ва дигар рамзҳо дар сайти макро-зангҳо наметавонанд ба онҳо муроҷиат кунанд.
    ///
    /// Бо назардошти аҳамияти ҷории гигиенӣ, ин конструктор, ба фарқ аз дигар tokens, талаб мекунад, ки ҳангоми сохтмон `Span` муайян карда шавад.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Ҳамон тавре ки `Ident::new`, аммо (`r#ident`) идентификатори хом месозад.
    /// Далели `string` як идентификатори дурустест, ки бо забон иҷозат дода шудааст (аз ҷумла калимаҳои калидӣ, масалан `fn`).
    /// Калимаҳои калидӣ, ки дар қитъаҳои роҳ истифода мешаванд (масалан
    /// `self`, `super`) пуштибонӣ намешавад ва боиси panic мегардад.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Муддати ин `Ident`-ро бармегардонад ва тамоми сатри баргардондаи [`to_string`](Self::to_string)-ро дар бар мегирад.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Давраи ин `Ident`-ро танзим мекунад ва эҳтимолан заминаи гигиении онро тағир медиҳад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Идентификаторро ҳамчун сатр чоп мекунад, ки бояд бе талафот ба ҳамон як идентификатор баргардонида шавад.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Сатри ҳарфии (`"hello"`), сатри байти (`b"hello"`), аломати (`'a'`), аломати байти (`b'a'`), адади бутун ё рақами нуқтаи шинокунанда бо суффикс ё бидуни он (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Литералҳои булӣ ба монанди `true` ва `false` ба ин ҷо тааллуқ надоранд, онҳо "Ident`s" мебошанд.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Адади нави суффиксро бо арзиши муайян эҷод мекунад.
        ///
        /// Ин функсия як бутуне ба монанди `1u32` эҷод мекунад, ки дар он арзиши бутуни муайяншуда қисми якуми token аст ва интеграл низ дар охир суффикс мешавад.
        /// Литералҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд дар гардишҳои даврӣ тавассути `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
        ///
        ///
        /// Литератураҳое, ки тавассути ин усул сохта шудаанд, дорои `Span::call_site()` бо нобаёнӣ мебошанд, ки метавонанд бо усули `set_span` дар поён танзим карда шаванд.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Бутуни нави бефасли навро бо арзиши муайян месозад.
        ///
        /// Ин функсия адади бутунеро ба монанди `1` эҷод мекунад, ки дар он арзиши бутуни қисми якуми token бошад.
        /// Дар ин token ягон суффикс дода нашудааст, яъне маънои даъватҳо ба монанди `Literal::i8_unsuffixed(1)` ба `Literal::u32_unsuffixed(1)` баробар аст.
        /// Литреалҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд аз нав ба воситаи `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
        ///
        ///
        /// Литератураҳое, ки тавассути ин усул сохта шудаанд, дорои `Span::call_site()` бо нобаёнӣ мебошанд, ки метавонанд бо усули `set_span` дар поён танзим карда шаванд.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Вожаи нави нуқтаи шинокунандаи номатлуб месозад.
    ///
    /// Ин созанда ба он монанд аст ба монанди `Literal::i8_unsuffixed`, ки арзиши шино бевосита ба token мебарояд, аммо ягон суффикс истифода намешавад, бинобар ин мумкин аст, ки `f64` баъдтар дар таркиб бошад.
    ///
    /// Литреалҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд аз нав ба воситаи `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
    ///
    /// # Panics
    ///
    /// Ин функсия талаб мекунад, ки флоти мушаххас ниҳоӣ бошад, масалан, агар он беохир бошад ё NaN, ин функсия panic хоҳад буд.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Сохтори нави ҳарфии нуқтаи шинокунанда месозад.
    ///
    /// Ин созанда айнан ба монанди `1.0f32` эҷод мекунад, ки дар он арзиши муайяншуда қисми қаблии token ва `f32` пасванди token мебошад.
    /// Ин token ҳамеша ҳамчун `f32` дар тартибдиҳанда хулоса мебарорад.
    /// Литреалҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд аз нав ба воситаи `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
    ///
    ///
    /// # Panics
    ///
    /// Ин функсия талаб мекунад, ки флоти мушаххас ниҳоӣ бошад, масалан, агар он беохир бошад ё NaN, ин функсия panic хоҳад буд.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Вожаи нави нуқтаи шинокунандаи номатлуб месозад.
    ///
    /// Ин созанда ба он монанд аст ба монанди `Literal::i8_unsuffixed`, ки арзиши шино бевосита ба token мебарояд, аммо ягон суффикс истифода намешавад, бинобар ин мумкин аст, ки `f64` баъдтар дар таркиб бошад.
    ///
    /// Литреалҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд аз нав ба воситаи `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
    ///
    /// # Panics
    ///
    /// Ин функсия талаб мекунад, ки флоти мушаххас ниҳоӣ бошад, масалан, агар он беохир бошад ё NaN, ин функсия panic хоҳад буд.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Сохтори нави ҳарфии нуқтаи шинокунанда месозад.
    ///
    /// Ин созанда айнан ба монанди `1.0f64` эҷод мекунад, ки дар он арзиши пешбининамудаи қисми token ва `f64` пасванди token мебошанд.
    /// Ин token ҳамеша ҳамчун `f64` дар тартибдиҳанда хулоса мебарорад.
    /// Литреалҳое, ки аз рақамҳои манфӣ сохта шудаанд, метавонанд аз нав ба воситаи `TokenStream` ё сатрҳо наҷот ёбанд ва ба ду tokens (`-` ва айнан мусбат) тақсим карда шаванд.
    ///
    ///
    /// # Panics
    ///
    /// Ин функсия талаб мекунад, ки флоти мушаххас ниҳоӣ бошад, масалан, агар он беохир бошад ё NaN, ин функсия panic хоҳад буд.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Сатри аслӣ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Аломати аслӣ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Сатри байт айнан.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Фарогирии ин айнанро бармегардонад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Муддати барои ин айнан алоқамандро танзим мекунад.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span`-ро бар мегардонад, ки маҷмӯи `self.span()` мебошад, ки танҳо байтҳои манбаъ дар доираи `range`-ро дар бар мегирад.
    /// `None`-ро бармегардонад, агар мӯҳлати кӯтоҳкардашуда берун аз ҳудуди `self` бошад.
    ///
    // FIXME(SergioBenitez): санҷед, ки диапазони байт дар ҳудуди UTF-8-и сарчашма оғоз ва поён меёбад.
    // дар акси ҳол, эҳтимол дорад, ки panic дар ҷои дигар ҳангоми чопи матни манбаъ рух диҳад.
    // FIXME(SergioBenitez): барои корбар ҳеҷ роҳе барои донистани он ки `self.span()` воқеан ба чӣ харита рост меояд, вуҷуд надорад, аз ин рӯ, ин усулро ҳоло танҳо кӯр-кӯрона номидан мумкин аст.
    // Масалан, `to_string()` барои аломати 'c' "'\u{63}'"-ро бар мегардонад;ҳеҷ гуна роҳе барои корбар вуҷуд надорад, ки оё матни манбаъ 'c' буд ё '\u{63}' буд.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) чизе ба `Option::cloned` монанд аст, аммо барои `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// ЗН, купрук танҳо `to_string`-ро таъмин мекунад, ки `fmt::Display`-ро дар асоси он татбиқ мекунад (баръакси муносибати маъмулии байни ҳарду).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Матнро ҳамчун сатр чоп мекунад, ки бояд бе талафот ба ҳамон айнан баргардонида шавад (ба истиснои яклухткунии имконпазири нуқтаҳои шинокунанда).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Дастрасии пайгирӣ ба тағирёбандаҳои муҳити атроф.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Тағирёбандаи муҳити зистро гиред ва онро барои сохтани маълумоти вобастагӣ илова кунед.
    /// Системаи сохтани иҷрогар медонад, ки ҳангоми тағирёбӣ ба тағирёбанда дастрасӣ пайдо шудааст ва ҳангоми тағир ёфтани арзиши ин тағирёбанда метавонад дубора сохтанро ба даст орад.
    ///
    /// Ғайр аз пайгирии вобастагӣ, ин функсия бояд ба китобхонаи стандартӣ ба `env::var` баробар бошад, ба истиснои он, ки далел бояд UTF-8 бошад.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}