//! Қисми профилии китобхонаи `compiler-rt`-ро тартиб медиҳад.
//!
//! Барои тафсилот ба build.rs барои libcompiler_builtins crate нигаред.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: Директиваҳои `rerun-if-changed` ҳоло бароварда нашудаанд ва скрипти сохтан
    // дар бораи тағирот дар ин файлҳои манбаъ ё сарлавҳаҳои ба онҳо дохилшуда такрор нахоҳад кард.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // Ин файл дар LLVM 10 номгузорӣ карда шуд.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // Ин файлҳо дар LLVM 11 илова карда шуданд.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // Китобхонаҳои иловагиро дар MSVC накашед
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // Хусусиятҳои гуногуни gcc ва монанди ин, аксаран нусхабардории системаи сохтани compiler-rt-ро хомӯш кунед
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // Фарз мекунем, ки Unixes, ки мо онро сохта истодаем, fnctl() дастрас аст
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // Ин бояд барои таъини COMPILER_RT_HAS_ATOMICS хеле хуб эвристикӣ бошад
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // Аҳамият диҳед, ки ин бояд вуҷуд дошта бошад, агар мо иҷро кунем (дар акси ҳол мо профилҳои профилҳоро умуман намесозем).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}