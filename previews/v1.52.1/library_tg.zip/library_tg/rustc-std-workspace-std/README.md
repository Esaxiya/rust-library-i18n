# `rustc-std-workspace-std` crate

Ба ҳуҷҷатҳо барои `rustc-std-workspace-core` crate нигаред.