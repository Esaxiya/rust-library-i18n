#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` ба иҷрокунандаи иҷрои вазифа имкон медиҳад, ки [`Waker`] созмон диҳад, ки рафтори бедории фармоиширо фароҳам меорад.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Он аз нишоннамои маълумот ва [virtual function pointer table (vtable)][vtable] иборат аст, ки рафтори `RawWaker`-ро фармоиш медиҳад.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Нишондиҳандаи додаҳо, ки метавонад барои нигоҳ доштани маълумоти худсарона мувофиқи талаби иҷрокунанда истифода шавад.
    /// Ин метавонад масалан
    /// нишоннамои бо навъи X тоза кардашуда ба `Arc`, ки бо вазифа алоқаманд аст.
    /// Арзиши ин майдон ба ҳамаи функсияҳое, ки қисми vtable мебошанд, ҳамчун параметрҳои аввал мегузарад.
    ///
    data: *const (),
    /// Ҷадвали нишоннамои функсионалии виртуалӣ, ки рафтори ин вейкерро фармоиш медиҳад.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Аз нишоннамои пешниҳодшудаи `data` ва `vtable` `RawWaker` нав месозад.
    ///
    /// Нишондиҳандаи `data` метавонад барои нигоҳ доштани маълумоти худсарона мувофиқи талаби иҷрокунанда истифода шавад.Ин метавонад масалан
    /// нишоннамои бо навъи X тоза кардашуда ба `Arc`, ки бо вазифа алоқаманд аст.
    /// Арзиши ин нишоннамо ба ҳамаи функсияҳое, ки қисми `vtable` мебошанд, ҳамчун параметрҳои аввал мегузарад.
    ///
    /// `vtable` рафтори `Waker`-ро, ки аз `RawWaker` сохта мешавад, фармоиш медиҳад.
    /// Барои ҳар як амалиёт дар `Waker`, функсияи алоқаманд дар `vtable` аз `RawWaker` аслӣ номида мешавад.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Ҷадвали нишоннамои маҷозии (vtable), ки рафтори [`RawWaker`]-ро муайян мекунад.
///
/// Нишондиҳандае, ки ба ҳамаи функсияҳои дохили ҷадвал дода мешавад, нишоннамои `data` аз объекти иҳотаи [`RawWaker`] мебошад.
///
/// Функсияҳо дар дохили ин сохтор танҳо барои нишон додани `data` объекти [`RawWaker`] дуруст сохташуда аз дохили татбиқи [`RawWaker`] пешбинӣ шудаанд.
/// Занг задан ба яке аз функсияҳои мавҷуда бо истифодаи ягон нишоннамои дигари `data` рафтори номуайянро ба бор меорад.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ин функсия ҳангоми клонидани [`RawWaker`] номида мешавад, масалан, вақте ки [`Waker`], ки дар он [`RawWaker`] захира мешавад, клон мешавад.
    ///
    /// Амалисозии ин функсия бояд ҳамаи захираҳоро, ки барои ин мисоли иловагии [`RawWaker`] ва вазифаи ба он алоқаманд заруранд, нигоҳ дорад.
    /// Даъват кардани `wake` дар натиҷаи [`RawWaker`] бояд ба бедор шудани ҳамон вазифа оварда расонад, ки онро [`RawWaker`] аслӣ бедор карда бошад.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Вақте ки `wake` дар [`Waker`] даъват карда шавад, ин функсия номида мешавад.
    /// Он бояд вазифаи бо ин [`RawWaker`] алоқамандро бедор кунад.
    ///
    /// Амалисозии ин вазифа бояд боварӣ ҳосил кунад, ки манбаъҳое, ки бо ин мисоли [`RawWaker`] ва вазифаи алоқаманд алоқаманданд, озод карда шаванд.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Вақте ки `wake_by_ref` дар [`Waker`] даъват карда шавад, ин функсия номида мешавад.
    /// Он бояд вазифаи бо ин [`RawWaker`] алоқамандро бедор кунад.
    ///
    /// Ин функсия ба `wake` монанд аст, аммо бояд нишоннамои додашударо истеъмол накунад.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Вақте ки [`RawWaker`] афтад, ин функсия даъват карда мешавад.
    ///
    /// Амалисозии ин вазифа бояд боварӣ ҳосил кунад, ки манбаъҳое, ки бо ин мисоли [`RawWaker`] ва вазифаи алоқаманд алоқаманданд, озод карда шаванд.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Аз функсияҳои пешниҳодшудаи `clone`, `wake`, `wake_by_ref` ва `drop` `RawWakerVTable` нав месозад.
    ///
    /// # `clone`
    ///
    /// Ин функсия ҳангоми клонидани [`RawWaker`] номида мешавад, масалан, вақте ки [`Waker`], ки дар он [`RawWaker`] захира мешавад, клон мешавад.
    ///
    /// Амалисозии ин функсия бояд ҳамаи захираҳоро, ки барои ин мисоли иловагии [`RawWaker`] ва вазифаи ба он алоқаманд заруранд, нигоҳ дорад.
    /// Даъват кардани `wake` дар натиҷаи [`RawWaker`] бояд ба бедор шудани ҳамон вазифа оварда расонад, ки онро [`RawWaker`] аслӣ бедор карда бошад.
    ///
    /// # `wake`
    ///
    /// Вақте ки `wake` дар [`Waker`] даъват карда шавад, ин функсия номида мешавад.
    /// Он бояд вазифаи бо ин [`RawWaker`] алоқамандро бедор кунад.
    ///
    /// Амалисозии ин вазифа бояд боварӣ ҳосил кунад, ки манбаъҳое, ки бо ин мисоли [`RawWaker`] ва вазифаи алоқаманд алоқаманданд, озод карда шаванд.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Вақте ки `wake_by_ref` дар [`Waker`] даъват карда шавад, ин функсия номида мешавад.
    /// Он бояд вазифаи бо ин [`RawWaker`] алоқамандро бедор кунад.
    ///
    /// Ин функсия ба `wake` монанд аст, аммо бояд нишоннамои додашударо истеъмол накунад.
    ///
    /// # `drop`
    ///
    /// Вақте ки [`RawWaker`] афтад, ин функсия даъват карда мешавад.
    ///
    /// Амалисозии ин вазифа бояд боварӣ ҳосил кунад, ки манбаъҳое, ки бо ин мисоли [`RawWaker`] ва вазифаи алоқаманд алоқаманданд, озод карда шаванд.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` вазифаи асинхронӣ.
///
/// Дар айни замон, `Context` танҳо барои дастрасӣ ба `&Waker` хизмат мекунад, ки метавонад барои бедор кардани вазифаи ҷорӣ истифода шавад.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Боварӣ ҳосил намоед, ки мо future-ро бар зидди тағирёбандаҳо бо тағирёбии тағирёбанда тавассути маҷбур кардани умр ба тағирёбанда табдил медиҳем (мӯҳлати истифодаи далел-мавқеъ зиддиятнок аст ва умри мавқеи бозгашт ковариант аст).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Аз `&Waker` `Context` нав созед.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Истинод ба `Waker`-ро барои вазифаи ҷорӣ бармегардонад.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` ин дастакест барои бедор кардани вазифа тавассути огоҳ кардани иҷрокунандаи он дар бораи омодагӣ ба кор.
///
/// Ин дастак як мисоли [`RawWaker`]-ро дар бар мегирад, ки рафтори бедории ба иҷрокунанда хосро муайян мекунад.
///
///
/// [`Clone`], [`Send`] ва [`Sync`]-ро татбиқ мекунад.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Вазифаи бо ин `Waker` алоқамандро бедор кунед.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Занги воқеии бедорӣ тавассути даъвати функсионалии маҷозӣ ба амалисозӣ дода мешавад, ки онро иҷрокунанда муайян мекунад.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ба `drop` занг назанед-вакерро `wake` истеъмол мекунад.
        crate::mem::forget(self);

        // БЕХАТАР: : Ин бехатар аст, зеро `Waker::from_raw` роҳи ягона аст
        // барои оғоз кардани `wake` ва `data`, ки аз корбар талаб мекунанд, ки шартномаи `RawWaker` риоя карда шавад.
        //
        unsafe { (wake)(data) };
    }

    /// Вазифаи бо ин `Waker` алоқамандро бидуни истеъмоли `Waker` бедор кунед.
    ///
    /// Ин ба `wake` монанд аст, аммо дар ҳолате, ки агар `Waker` тааллуқ дошта бошад, каме камтар самараноктар аст.
    /// Ин усул бояд аз даъват ба `waker.clone().wake()` бартарӣ дода шавад.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Занги воқеии бедорӣ тавассути даъвати функсионалии маҷозӣ ба амалисозӣ дода мешавад, ки онро иҷрокунанда муайян мекунад.
        //

        // БЕХАТАР: : ба `wake` нигаред
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true`-ро бармегардонад, агар ин `Waker` ва `Waker` дигар ҳамон вазифаро бедор карда бошанд.
    ///
    /// Ин функсия дар асоси саъйи беҳтарин кор мекунад ва ҳатто вақте ки Waker ҳамон вазифаро бедор мекунад, метавонад бардурӯғ баргардад.
    /// Аммо, агар ин функсия `true`-ро баргардонад, кафолат дода мешавад, ки Waker ҳамон вазифаро бедор мекунад.
    ///
    /// Ин функсия пеш аз ҳама барои мақсадҳои оптимизатсия истифода мешавад.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Аз [`RawWaker`] `Waker` нав месозад.
    ///
    /// Рафтори `Waker`-и баргардондашуда номуайян аст, агар шартномае, ки дар ["RawWaker`] 'ва [' RawWakerVTable`] муайян карда шудааст, риоя карда нашавад.
    ///
    /// Аз ин рӯ, ин усул хатарнок аст.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // БЕХАТАР: : Ин бехатар аст, зеро `Waker::from_raw` роҳи ягона аст
            // барои оғоз кардани `clone` ва `data`, ки аз корбар талаб мекунанд, ки шартномаи [`RawWaker`] риоя карда шавад.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // БЕХАТАР: : Ин бехатар аст, зеро `Waker::from_raw` роҳи ягона аст
        // барои оғоз кардани `drop` ва `data`, ки аз корбар талаб мекунанд, ки шартномаи `RawWaker` риоя карда шавад.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}