use crate::iter::FromIterator;

/// Ҳама ҷузъҳои воҳидро аз iterator ба як қисм ҷамъ мекунад.
///
/// Ин дар якҷоягӣ бо абстраксияҳои сатҳи олӣ муфидтар аст, ба монанди ҷамъоварӣ ба `Result<(), E>`, ки шумо танҳо дар бораи хатогиҳо ғамхорӣ мекунед:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}