//! Либкоре prelude
//!
//! Ин модул барои корбарони libcore пешбинӣ шудааст, ки ба libstd ҳам пайванд надоранд.
//! Ин модул бо нобаёнӣ вақте ворид карда мешавад, ки агар `#![no_std]` дар ҳамон шакле, ки китобхонаи стандартӣ prelude истифода бурда мешавад.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Нусхаи соли 2015 асосии prelude.
///
/// Барои маълумоти бештар ба [module-level documentation](self) нигаред.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Нусхаи соли 2018 асосии prelude.
///
/// Барои маълумоти бештар ба [module-level documentation](self) нигаред.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Нусхаи 2021-и аслии prelude.
///
/// Барои маълумоти бештар ба [module-level documentation](self) нигаред.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Чизҳои бештар илова кунед.
}