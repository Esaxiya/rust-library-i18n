//! Тарҷумаи қариб мустақим (аммо каме оптимизатсияшуда) Rust тасвири 3-и "Чопи рақамҳои шинокунанда зуд ва дақиқ" [^ 1].
//!
//!
//! [^1]: Burger, RG ва Dybvig, RK 1996. Чоп кардани рақамҳои нуқтаи шинокунанда
//!   зуд ва дақиқ.Нишондиҳанда Не.31, 5 (май. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// массиви пешакӣ ҳисобшудаи "Digit`s барои 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// танҳо вақте ки `x < 16 * scale` қобили истифода аст;`scaleN` бояд `scale.mul_small(N)` бошад
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Кӯтоҳтарин татбиқи режими Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // рақами `v` барои формат кардан маълум аст:
    // - ба `mant * 2^exp` баробар аст;
    // - пеш аз `(mant - 2 *minus)* 2^exp` дар навъи аслӣ;ва
    // - пас аз он `(mant + 2 *plus)* 2^exp` дар навъи аслӣ.
    //
    // бешубҳа, `minus` ва `plus` наметавонанд сифр бошанд.(барои ҳадди ақалл, мо қиматҳои берун аз диапазонро истифода мебарем.) Инчунин тахмин мекунем, ки ҳадди ақалл як рақам ҳосил мешавад, яъне `mant` низ сифр буда наметавонад.
    //
    // ин инчунин маънои онро дорад, ки ягон рақами байни `low = (mant - minus)*2^exp` ва `high = (mant + plus)* 2^exp` ба ин рақами дақиқи нуқтаи шинокунанда ҳамроҳ карда мешавад, бо ҳудуди он вақте ки мантиссаи аслӣ ҳамвор буд (яъне, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` аст
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `k_0`-ро аз ашёи аслии қонеъкунандаи `10^(k_0-1) < high <= 10^(k_0+1)` ҳисоб кунед.
    // `k` басташудаи қатъии `10^(k-1) < high <= 10^k` баъдтар ҳисоб карда мешавад.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // табдил додани `{mant, plus, minus} * 2^exp` ба шакли касрӣ, то:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` ба `10^k` тақсим кунед.ҳоло `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // ислоҳ ҳангоми `mant + plus > scale` (ё `>=`).
    // мо аслан `scale`-ро тағир намедиҳем, зеро мо метавонем зарбгузории аввалияро ба ҷои он гузарем.
    // ҳоло `scale < mant + plus <= scale * 10` ва мо омодаем, ки рақамҳоро тавлид кунем.
    //
    // қайд кунед, ки `d[0]` * метавонад сифр бошад, вақте ки `scale - plus < mant < scale`.
    // дар ин ҳолат ҳолати яклухткунӣ фавран ба амал оварда мешавад (`up` дар поён).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // баробар ба миқёси `scale` бо 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // кеш `(2, 4, 8) * scale` барои тавлиди рақамӣ.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // инвариантҳо, ки дар он `d[0..n-1]` рақамҳои то ба имрӯз тавлидшуда мебошанд:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ба ин васила `mant / scale < 10`), ки дар он `d[i..j]` стенография барои `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // тавлиди як рақам: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ин тасвири соддакардашудаи алгоритми тағирёфтаи Dragon аст.
        // бисёр далелҳои мобайнӣ ва далелҳои пуррагӣ барои роҳат сарфи назар карда мешаванд.
        //
        // бо инвариантҳои тағирёфта оғоз кунед, зеро мо `n`-ро нав кардем:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // фарз кунем, ки `d[0..n-1]` кӯтоҳтарин намояндагӣ дар байни `low` ва `high` аст, яъне `d[0..n-1]` ҳардуи зеринро қонеъ мекунад, аммо `d[0..n-2]` чунин намекунад:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (биективӣ: рақамҳо ба `v` давр мезананд);ва
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (рақами охирин дуруст аст).
        //
        // шарти дуюм то `2 * mant <= scale` соддатар мешавад.
        // ҳалли инвариантҳо аз нигоҳи `mant`, `low` ва `high` версияи соддаи шарти аввалро медиҳад: `-plus < mant < minus`.
        // азбаски `-plus < 0 <= mant`, мо ҳангоми пешниҳоди `mant < minus` ва `2 * mant <= scale` кӯтоҳтарин намояндагиро дорем.
        // (аввал вақте ки мантиссаи аслӣ ҳамвор аст, `mant <= minus` мешавад.)
        //
        // вақте ки дуюмаш намерасад (`2 * mant> миқёси`), мо бояд рақами охиринро зиёд кунем.
        // ин барои барқарор кардани он шароит кифоя аст: мо аллакай медонем, ки насли рақамӣ ба `0 <= v / 10^(k-n) - d[0..n-1] < 1` кафолат медиҳад.
        // дар ин ҳолат, шарти аввал `-plus < mant - scale < minus` мешавад.
        // азбаски `mant < scale` пас аз насл, мо `scale < mant + plus` дорем.
        // (боз, вақте ки мантиссаи аслӣ ҳамвор аст, ин `scale <= mant + plus` мешавад.)
        //
        // кӯтоҳаш:
        // - ҳангоми `mant < minus` (ё `<=`) `down`-ро боздоред ва давр занед (рақамҳоро тавре нигоҳ доред).
        // - бас ва даври `up` (зиёд кардани рақами охирин) ҳангоми `scale < mant + plus` (ё `<=`).
        // - тавлиди тартиби дигаре нигоҳ доред.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // мо намояндагии кӯтоҳтарин дорем, ба мудаввар гузаред

        // invariant-ҳоро барқарор кунед.
        // ин алгоритмро ҳамеша қатъ мекунад: `minus` ва `plus` ҳамеша зиёд мешаванд, аммо `mant` модули `scale` бурида мешавад ва `scale` собит аст.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // яклухткунӣ дар ҳолате рух медиҳад, ки i) танҳо шарти ҷамъбасткунӣ ба амал омада бошад, ё ii) ҳарду шарт ба амал омадаанд ва шикастани галстук гирдсозиро афзалтар медонад.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // агар яклухткунӣ дарозиро тағир диҳад, нишондиҳанда низ бояд тағир ёбад.
        // Чунин ба назар мерасад, ки ин шартро қонеъ кардан хеле душвор аст (эҳтимолан ғайриимкон аст), аммо мо танҳо дар ин ҷо бехатар ва пайваста ҳастем.
        //
        // БЕХАТАР: : мо ин хотираро дар боло оғоз кардем.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // БЕХАТАР: : мо ин хотираро дар боло оғоз кардем.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Татбиқи режими дақиқ ва собит барои Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `k_0`-ро аз ашёи аслии қонеъкунандаи `10^(k_0-1) < v <= 10^(k_0+1)` ҳисоб кунед.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` ба `10^k` тақсим кунед.ҳоло `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ислоҳ ҳангоми `mant + plus >= scale`, ки дар он `plus / scale = 10^-buf.len() / 2`.
    // барои нигоҳ доштани миқдори муайяни миқдор, мо дарвоқеъ `mant + floor(plus) >= scale` истифода мебарем.
    // мо аслан `scale`-ро тағир намедиҳем, зеро мо метавонем зарбгузории аввалияро ба ҷои он гузарем.
    // боз бо алгоритми кӯтоҳтарин, `d[0]` метавонад сифр бошад, аммо дар ниҳоят якҷоя карда мешавад.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // баробар ба миқёси `scale` бо 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // агар мо бо маҳдудияти рақами охир кор карда истодаем, мо бояд буферро пеш аз расидани воқеӣ кӯтоҳ кунем, то ки яклухткунии дубора пешгирӣ карда шавад.
    //
    // дар хотир доред, ки мо бояд буферро дубора калон кунем, вақте ки мудаввар рӯй медиҳад!
    let mut len = if k < limit {
        // о, мо ҳатто наметавонем *як* рақам истеҳсол кунем.
        // ин имконпазир аст, вақте ки гӯем, мо чизе монанди 9.5 гирифтем ва он ба 10 тақсим карда мешавад.
        // мо як буферии холиро бармегардонем, ба истиснои ҳолати мудавваркунии баъдтар, ки ҳангоми `k == limit` рух медиҳад ва бояд маҳз як рақам истеҳсол кунад.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // кеш `(2, 4, 8) * scale` барои тавлиди рақамӣ.
        // (ин метавонад гарон бошад, бинобар ин, вақте ки буфер холӣ аст, онҳоро ҳисоб накунед.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // рақамҳои зерин ҳама сифрҳо мебошанд, мо дар ин ҷо истодаем * барои иҷрои мудаввар кӯшиш накунед!балки рақамҳои боқимондаро пур кунед.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // БЕХАТАР: : мо ин хотираро дар боло оғоз кардем.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // яклухткунӣ, агар мо дар мобайни рақамҳо истодем, агар рақамҳои зерин дақиқан 5000 бошанд ..., рақами пешинро санҷед ва кӯшиш кунед то ҷуфтро гиред (яъне, вақте ки рақами пешин баробар аст, аз ҳамгироӣ канорагирӣ кунед).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // БЕХАТАР: : `buf[len-1]` оғоз карда шудааст.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // агар яклухткунӣ дарозиро тағир диҳад, нишондиҳанда низ бояд тағир ёбад.
        // аммо аз мо шумораи муайяни рақамҳо талаб карда шудааст, бинобар ин буферро тағир надиҳед ...
        // БЕХАТАР: : мо ин хотираро дар боло оғоз кардем.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... агар ба ҷои мо аз мо дақиқии устувор талаб карда нашуда бошад.
            // мо инчунин бояд тафтиш кунем, ки агар буфери аслӣ холӣ бошад, рақами иловагиро танҳо ҳангоми `k == limit` (парвандаи edge) илова кардан мумкин аст.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // БЕХАТАР: : мо ин хотираро дар боло оғоз кардем.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}