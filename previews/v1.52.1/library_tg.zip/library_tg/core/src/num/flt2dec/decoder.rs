//! Рамзҳои нуқтаи шинокунандаро ба қисмҳои алоҳида ва диапазони хатогӣ декод мекунад.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Арзиши ниҳоии имзошудаи рамзкушоиро, ба монанди:
///
/// - Арзиши аслӣ ба `mant * 2^exp` баробар аст.
///
/// - Ягон рақам аз `(mant - minus)*2^exp` то `(mant + plus)* 2^exp` то арзиши аслӣ давр мезанад.
/// Диапазон танҳо вақте фарогир аст, ки `inclusive` `true` бошад.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Мантиссаи миқёспазир.
    pub mant: u64,
    /// Диапазони хатогии поёнӣ.
    pub minus: u64,
    /// Диапазони хатогии боло.
    pub plus: u64,
    /// Нишондиҳандаи муштарак дар пойгоҳи 2.
    pub exp: i16,
    /// Дуруст аст, вақте ки хатогиҳо фарогир мебошанд.
    ///
    /// Дар IEEE 754, ин дуруст аст, вақте ки мантиссаи аслӣ ҳамвор буд.
    pub inclusive: bool,
}

/// Арзиши имзошудаи рамзкушо.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, ё мусбат ё манфӣ.
    Infinite,
    /// Нул, ё мусбат ё манфӣ.
    Zero,
    /// Рақамҳои ниҳоӣ бо майдонҳои минбаъдаи рамзкушоӣ.
    Finite(Decoded),
}

/// Намуди нуқтаи шинокунанда, ки метавонад "decode`d" бошад.
pub trait DecodableFloat: RawFloat + Copy {
    /// Арзиши ҳадди ақали мусбати меъёршуда.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Аломатро (ҳангоми манфӣ ҳақиқӣ) ва арзиши `FullDecoded`-ро аз рақами нуқтаи шинокунанда бар мегардонад.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ҳамсояҳо: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ҳамеша нишондиҳандаро нигоҳ медорад, аз ин рӯ мантисса барои субнормалҳо миқёс карда мешавад.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ҳамсояҳо: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ки дар он maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ҳамсояҳо: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}