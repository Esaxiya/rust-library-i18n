//! Доимӣ барои навъи бутуни имзои 128-бита.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Рамзи нав бояд доимиҳои алоқамандро мустақиман дар намуди ибтидоӣ истифода барад.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }