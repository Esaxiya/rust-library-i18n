//! Доимӣ барои навъи бутуни имзошудаи андозаи нишоннамо.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Рамзи нав бояд доимиҳои алоқамандро мустақиман дар намуди ибтидоӣ истифода барад.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }