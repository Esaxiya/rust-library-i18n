//! Доимӣ барои навъи бутуни имзои 64-битӣ.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Рамзи нав бояд доимиҳои алоқамандро мустақиман дар намуди ибтидоӣ истифода барад.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }