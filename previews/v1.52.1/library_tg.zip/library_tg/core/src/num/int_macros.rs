macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Хурдтарин арзише, ки онро бо ин навъи бутун нишон додан мумкин аст.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Бузургтарин қимате, ки онро бо ин навъи бутун нишон додан мумкин аст.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Андозаи ин навъи бутун ба бит.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Буридаи сатрро дар пойгоҳи додашуда ба адади бутун табдил медиҳад.
        ///
        /// Интизор меравад, ки сатр аломати ихтиёрии `+` ё `-` бошад ва пас аз он рақамҳо бошанд.
        /// Фазои пешрафта ва қафо хаторо ифода мекунад.
        /// Рақамҳо зергурӯҳи ин аломатҳо мебошанд, вобаста аз `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ин функсия panics агар `radix` дар доираи аз 2 то 36 набошад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Шумораи онҳоро дар намояндагии дуии `self` бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Шумораи сифрҳоро дар намояндагии дуии `self` бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Шумораи сифрҳои пешбарро дар намояндагии бинарии `self` бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Шумораи сифрҳои ақибмондаро дар намояндагии дуии `self` бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Шумораи пешқадамонро дар намояндагии бинарии `self` бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Шумораи онҳоеро, ки дар намояндагии бинарии `self` бармегарданд, бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Лаҷомро бо миқдори муайяншуда ба тарафи чап, `n` мегузаронад ва битҳои буридашударо то охири бутуни ҳосилшуда печонад.
        ///
        ///
        /// Илтимос дар хотир гиред, ки ин ҳамон як амалиёт бо оператори ивазкунандаи `<<` нест!
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Лаҷомҳоро ба тарафи муайян бо миқдори муқарраршуда, `n`, бо печонидани битҳои бурида ба аввали бутуни ҳосилшуда иваз мекунад.
        ///
        ///
        /// Илтимос дар хотир гиред, ки ин ҳамон як амалиёт бо оператори ивазкунандаи `>>` нест!
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Тартиби байтии бутунро бар мегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// бигзор m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Тартиби битҳоро дар адади бутун бармегардонад.
        /// Лаҷоми камаҳамият ба каме муҳимтарин табдил меёбад, дуввум бит ба аҳамияти каме табдил меёбад ва ғайра.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// бигзор m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Ададро аз endianan калон ба endianness ҳадаф табдил медиҳад.
        ///
        /// Дар бораи акнун, ин ғайриимкон аст.Дар бораи акнун каме байтҳо иваз карда мешаванд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// агар cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } дигар {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Ададро аз endian хурд ба endianness ҳадаф табдил медиҳад.
        ///
        /// Дар бораи акнун каме ин ғайриимкон аст.Дар endanan калон байтҳо иваз карда мешаванд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// агар cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } дигар {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Табдил `self` ба endianness калон аз endianness ҳадаф.
        ///
        /// Дар бораи акнун, ин ғайриимкон аст.Дар бораи акнун каме байтҳо иваз карда мешаванд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// агар cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ё не?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Табдил `self` ба endianan хурд аз endianness ҳадаф.
        ///
        /// Дар бораи акнун каме ин ғайриимкон аст.Дар endanan калон байтҳо иваз карда мешаванд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// агар cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Илова кардани бутуни санҷидашуда.
        /// `self + rhs`-ро ҳисоб мекунад, агар `None` барзиёд баргардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Илова кардани бутуни носанҷида.Ҳисоб мекунад `self + rhs`, бо назардошти лабрез шудан наметавонад.
        /// Ин боиси рафтори номуайян ҳангоми
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `unchecked_add` риоя кунад.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Тарккунии бутуни санҷидашуда.
        /// `self - rhs`-ро ҳисоб мекунад, агар `None` барзиёд баргардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Тарки бутуни носанҷида.Ҳисоб мекунад `self - rhs`, бо назардошти лабрез шудан наметавонад.
        /// Ин боиси рафтори номуайян ҳангоми
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `unchecked_sub` риоя кунад.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Зарбкунии бутуни санҷидашуда.
        /// `self * rhs`-ро ҳисоб мекунад, агар `None` барзиёд баргардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Зарбкунии бутуни носанҷида.Ҳисобкунакҳои `self * rhs`, бо назардошти лабрез шудан наметавонад.
        /// Ин боиси рафтори номуайян ҳангоми
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `unchecked_mul` риоя кунад.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Тақсимоти бутун тафтиш карда шуд.
        /// `self / rhs`-ро ҳисоб мекунад, баргардонидани `None` агар `rhs == 0` ё тақсимот ба пур шудани он оварда расонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // БЕХАТАР: : div ба сифр ва INT_MIN дар боло тафтиш карда шуданд
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Тақсимоти эвклидӣ.
        /// `self.div_euclid(rhs)`-ро ҳисоб мекунад, баргардонидани `None` агар `rhs == 0` ё тақсимот ба пур шудани он оварда расонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Қисми боқимондаи санҷидашуда.
        /// `self % rhs`-ро ҳисоб мекунад, баргардонидани `None` агар `rhs == 0` ё тақсимот ба пур шудани он оварда расонад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // БЕХАТАР: : div ба сифр ва INT_MIN дар боло тафтиш карда шуданд
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Қисми боқимондаи евклидӣ.
        /// `self.rem_euclid(rhs)`-ро ҳисоб мекунад, баргардонидани `None` агар `rhs == 0` ё тақсимот ба пур шудани он оварда расонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Инкори рад кардашуда.
        /// Ҳисоб мекунад `-self`, баргардонидани `None` агар `self == MIN`.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Сменаи чап тафтиш карда шуд.
        /// Ҳисоб мекунад `self << rhs`, баргардонидани `None` агар `rhs` аз шумораи битҳо дар `self` зиёдтар ё ба он баробар бошад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Гузариши рост тафтиш карда шуд.
        /// Ҳисоб мекунад `self >> rhs`, баргардонидани `None` агар `rhs` аз шумораи битҳо дар `self` зиёдтар ё ба он баробар бошад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Арзиши мутлақ тафтиш карда шуд.
        /// Ҳисоб мекунад `self.abs()`, баргардонидани `None` агар `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Нишондиҳандаи санҷидашуда.
        /// `self.pow(exp)`-ро ҳисоб мекунад, агар `None` барзиёд баргардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // азбаски exp!=0, ниҳоят exp бояд 1 бошад.
            // Бо битҳои ниҳоии нишондиҳанда алоҳида муносибат кунед, зеро чарх задани пойгоҳ пас аз он шарт нест ва метавонад боиси фаромадани нолозим шавад.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Илова кардани бутуни тофта.
        /// `self + rhs`-ро ҳисоб мекунад, ба ҷои пур шудан дар ҳудуди ададӣ сер мешавад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Тарккунии бутуни тофта.
        /// `self - rhs`-ро ҳисоб мекунад, ба ҷои пур шудан дар ҳудуди ададӣ сер мешавад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Инкоркунии бутуни тофта.
        /// `-self`-ро ҳисоб мекунад, `MAX`-ро бармегардонад, агар `self == MIN` ба ҷои пур шудан.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Арзиши мутлақи тофта.
        /// `self.abs()`-ро ҳисоб мекунад, `MAX`-ро бармегардонад, агар `self == MIN` ба ҷои пур шудан.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Зарбкунии бутуни тофта.
        /// `self * rhs`-ро ҳисоб мекунад, ба ҷои пур шудан дар ҳудуди ададӣ сер мешавад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Нишондиҳандаи пурраи тофта.
        /// `self.pow(exp)`-ро ҳисоб мекунад, ба ҷои пур шудан дар ҳудуди ададӣ сер мешавад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Печондани илова (modular).
        /// Ҳисоб мекунад `self + rhs`, печондан дар сарҳади намуд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Печондани тарҳи (modular).
        /// Ҳисоб мекунад `self - rhs`, печондан дар сарҳади намуд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Печондани зарби (modular).
        /// Ҳисоб мекунад `self * rhs`, печондан дар сарҳади намуд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Печондани тақсимоти (modular).Ҳисоб мекунад `self / rhs`, печондан дар сарҳади намуд.
        ///
        /// Ягона ҳолате, ки чунин печонидан метавонад ба амал ояд, ин аст, ки агар `MIN / -1` ба намуди имзошуда тақсим карда шавад (дар он ҷо `MIN` ин арзиши минималии манфӣ барои он аст);ин ба `-MIN` баробар аст, ки арзиши мусбатест, ки барои нишон додани он хеле калон аст.
        /// Дар чунин ҳолат, ин функсия худи `MIN`-ро бармегардонад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Печонидани тақсимоти эвклидӣ.
        /// Ҳисоб мекунад `self.div_euclid(rhs)`, печондан дар сарҳади намуд.
        ///
        /// Печондан танҳо дар `MIN / -1` дар намуди имзошуда ба амал хоҳад омад (ки дар он `MIN` арзиши минималии манфӣ барои намуд аст).
        /// Ин ба `-MIN` баробар аст, ки арзиши мусбатест, ки барои нишон додани он хеле калон аст.
        /// Дар ин ҳолат, ин усул худи `MIN`-ро бармегардонад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Бастаи боқимондаи (modular).Ҳисоб мекунад `self % rhs`, печондан дар сарҳади намуд.
        ///
        /// Чунин печондан ҳеҷ гоҳ воқеан риёзӣ нест;осори татбиқ `x % y`-ро барои `MIN / -1` дар намуди имзошуда беэътибор мекунад (дар он ҷо `MIN` арзиши манфии манфӣ аст).
        ///
        /// Дар чунин ҳолат, ин функсия `0`-ро бармегардонад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Печонидани боқимондаи Евклид.Ҳисоб мекунад `self.rem_euclid(rhs)`, печондан дар сарҳади намуд.
        ///
        /// Печондан танҳо дар `MIN % -1` дар намуди имзошуда ба амал хоҳад омад (ки дар он `MIN` арзиши минималии манфӣ барои намуд аст).
        /// Дар ин ҳолат, ин усул 0 бар мегардонад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Печондани радди (modular).Ҳисоб мекунад `-self`, печондан дар сарҳади намуд.
        ///
        /// Ягона ҳолате, ки чунин печонидан метавонад ба амал ояд, ин аст, ки агар `MIN` дар намуди имзошуда рад карда шавад (дар он ҷо `MIN` арзиши минималии манфӣ барои он аст);ин арзиши мусбатест, ки барои ифода дар намуд хеле калон аст.
        /// Дар чунин ҳолат, ин функсия худи `MIN`-ро бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic бидуни гузариш ба чап;`self << mask(rhs)` медиҳад, ки дар он `mask` ҳама гуна битҳои баландсифати `rhs`-ро, ки боиси гузаштан аз паҳнои абрҳои тип мегардад, хориҷ мекунад.
        ///
        /// Аҳамият диҳед, ки ин * ҳамон тавре ки чап-чап аст;RHS як баст ба чап ба доираи намуд маҳдуд аст, на битҳое, ки аз LHS ба канори дигар бармегарданд.
        ///
        /// Намудҳои бутуни ибтидоӣ ҳама функсияи [`rotate_left`](Self::rotate_left)-ро иҷро мекунанд, ки метавонад ба ҷои он чизе, ки шумо мехоҳед бошад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // БЕХАТАР: : ниқобпӯшӣ аз рӯи бита ба намуд кафолат медиҳад, ки мо тағир надорем
            // берун аз ҳудуд
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic бидуни гузариш ба тарафи рост;`self >> mask(rhs)` медиҳад, ки дар он `mask` ҳама гуна битҳои баландсифати `rhs`-ро, ки боиси гузаштан аз паҳнои абрҳои тип мегардад, хориҷ мекунад.
        ///
        /// Аҳамият диҳед, ки ин *ба ҳамон як гардиши рост* монанд нест;RHS аз сменаи рости печонидан ба доираи намуд маҳдуд аст, на битҳое, ки аз LHS ба канори дигар бармегарданд.
        ///
        /// Намудҳои бутуни ибтидоӣ ҳама функсияи [`rotate_right`](Self::rotate_right)-ро иҷро мекунанд, ки метавонад ба ҷои он чизе, ки шумо мехоҳед бошад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // БЕХАТАР: : ниқобпӯшӣ аз рӯи бита ба намуд кафолат медиҳад, ки мо тағир надорем
            // берун аз ҳудуд
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Печондани арзиши мутлақи (modular).Ҳисоб мекунад `self.abs()`, печондан дар сарҳади намуд.
        ///
        /// Ягона ҳолате, ки чунин печонидан метавонад ба амал ояд, ин аст, ки касе қимати мутлақи арзиши минималии манфиро барои намуд мегирад;ин арзиши мусбатест, ки барои ифода дар намуд хеле калон аст.
        /// Дар чунин ҳолат, ин функсия худи `MIN`-ро бармегардонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Арзиши мутлақи `self`-ро бидуни ҳеҷ печондан ва ваҳм ҳисоб мекунад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Печондани нишондиҳандаи (modular).
        /// Ҳисоб мекунад `self.pow(exp)`, печондан дар сарҳади намуд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // азбаски exp!=0, ниҳоят exp бояд 1 бошад.
            // Бо битҳои ниҳоии нишондиҳанда алоҳида муносибат кунед, зеро чарх задани пойгоҳ пас аз он шарт нест ва метавонад боиси фаромадани нолозим шавад.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ҳисоб мекунад
        ///
        /// Нишони изофаро дар якҷоягӣ бо буг бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар изофа рух медод, пас арзиши парпечшуда бармегардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ҳисоб мекунад
        ///
        /// Нишондиҳандаи тарҳкуниро дар якҷоягӣ бо мантиқӣ бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар изофа рух медод, пас арзиши парпечшуда бармегардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Зарб задани `self` ва `rhs`-ро ҳисоб мекунад.
        ///
        /// Нишони зарбро дар якҷоягӣ бо мантиқӣ бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар изофа рух медод, пас арзиши парпечшуда бармегардад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, ҳақиқӣ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Ҳангоми тақсим кардани `self` ба `rhs` тақсимкунандаро ҳисоб мекунад.
        ///
        /// Нишони тақсимкунандаро дар якҷоягӣ бо мантиқӣ бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар обхезӣ ба амал ояд, пас худ баргардонида мешавад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Миқдори тақсимоти Евклидро `self.div_euclid(rhs)` ҳисоб мекунад.
        ///
        /// Нишони тақсимкунандаро дар якҷоягӣ бо мантиқӣ бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар обхезӣ ба амал ояд, пас `self` баргардонида мешавад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Ҳангоми бо `rhs` тақсим кардани `self` боқимондаро ҳисоб мекунад.
        ///
        /// Пас аз тақсим кардан мантиқи боқимондаро бо корти боқимонда бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар обхезӣ ба амал ояд, пас 0 бармегардад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Қисми боқимондаи Евклид.`self.rem_euclid(rhs)` ҳисоб мекунад.
        ///
        /// Пас аз тақсим кардан мантиқи боқимондаро бо корти боқимонда бармегардонад, ки он пур шудани арифметикӣ аст ё не.
        /// Агар обхезӣ ба амал ояд, пас 0 бармегардад.
        ///
        /// # Panics
        ///
        /// Агар `rhs` 0 бошад, ин функсия panic хоҳад буд.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Аз худ пур мешавад, агар ин ба арзиши ҳадди ақалл баробар бошад.
        ///
        /// Нишондиҳандаи нусхаи раддшудаи худро дар якҷоягӣ бо мантиқӣ бармегардонад, ки оё он лабрез шудааст.
        /// Агар `self` арзиши ҳадди аққал бошад (масалан, `i32::MIN` барои арзишҳои навъи `i32`), он гоҳ арзиши минималӣ дубора баргардонида мешавад ва `true` барои пур шудани об бармегардад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Худро бо битҳои `rhs` мегузорад.
        ///
        /// Нишондиҳандаи версияи тағирёфтаи худиро дар якҷоягӣ бо мантиқӣ бармегардонад, ки нишондиҳандаи тағирот аз миқдори битҳо ба он калон ё баробар аст.
        /// Агар арзиши баст хеле калон бошад, пас арзиши (N-1) ниқоб дода мешавад, ки дар он N шумораи битҳо аст ва пас ин қимат барои иҷрои баст истифода мешавад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0х10, ҳақиқӣ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Худро аз ҷониби `rhs` бит иваз мекунад.
        ///
        /// Нишондиҳандаи версияи тағирёфтаи худиро дар якҷоягӣ бо мантиқӣ бармегардонад, ки нишондиҳандаи тағирот аз миқдори битҳо ба он калон ё баробар аст.
        /// Агар арзиши баст хеле калон бошад, пас арзиши (N-1) ниқоб дода мешавад, ки дар он N шумораи битҳо аст ва пас ин қимат барои иҷрои баст истифода мешавад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0х1, ҳақиқӣ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Арзиши мутлақи `self`-ро ҳисоб мекунад.
        ///
        /// Нишондиҳандаи нусхаи мутлақи худро бо як мантиқӣ, ки нишон медиҳад, ки лабрез шудааст, бармегардонад.
        /// Агар худ арзиши ҳадди аққал бошад
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// он гоҳ арзиши минималӣ дубора бармегардад ва ҳақиқӣ барои пур шудани ҳолат бармегардад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Худро ба қудрати `exp` баланд мебардорад, бо истифода аз дараҷа бо квадрат.
        ///
        /// Корти экспоненсатсияро дар якҷоягӣ бо bool бармегардонад, ки оё он лабрез шудааст.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, ҳақиқӣ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Фазои харошидан барои нигоҳ доштани натиҷаҳои overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // азбаски exp!=0, ниҳоят exp бояд 1 бошад.
            // Бо битҳои ниҳоии нишондиҳанда алоҳида муносибат кунед, зеро чарх задани пойгоҳ пас аз он шарт нест ва метавонад боиси фаромадани нолозим шавад.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Худро ба қудрати `exp` баланд мебардорад, бо истифода аз дараҷа бо квадрат.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // азбаски exp!=0, ниҳоят exp бояд 1 бошад.
            // Бо битҳои ниҳоии нишондиҳанда алоҳида муносибат кунед, зеро чарх задани пойгоҳ пас аз он шарт нест ва метавонад боиси фаромадани нолозим шавад.
            //
            //
            acc * base
        }

        /// Миқдори тақсимоти эвклидии `self`-ро ба `rhs` ҳисоб мекунад.
        ///
        /// Ин бутуни `n`-ро тавре ҳисоб мекунад, ки `self = n * rhs + self.rem_euclid(rhs)`, бо `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Ба ибораи дигар, натиҷа `self / rhs` то бутуни `n` мудаввар мешавад, ба тавре ки `self >= n * rhs`.
        /// Агар `self > 0`, ин ба давр ба сӯи сифр баробар аст (бо нобаёнӣ дар Rust);
        /// агар `self < 0`, ин ба гардиш ба сӯи +/-беохирӣ баробар аст.
        ///
        /// # Panics
        ///
        /// Ин функсия panic хоҳад буд, агар `rhs` 0 бошад ё тақсимот ба пур шудани он оварда расонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// бигзор b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Қисми камтарини боқимондаи манфии `self (mod rhs)`-ро ҳисоб мекунад.
        ///
        /// Ин тавре амалӣ мешавад, ки гӯё алгоритми тақсимоти Евклид-бо назардошти `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` ва `0 <= r < abs(rhs)` сурат мегирад.
        ///
        ///
        /// # Panics
        ///
        /// Ин функсия panic хоҳад буд, агар `rhs` 0 бошад ё тақсимот ба пур шудани он оварда расонад.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// бигзор b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Арзиши мутлақи `self`-ро ҳисоб мекунад.
        ///
        /// # Рафтор аз ҳад зиёд
        ///
        /// Арзиши мутлаки
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// наметавонад ҳамчун
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ва кӯшиши ҳисоб кардани он боиси пур шудани об мегардад.
        /// Ин маънои онро дорад, ки код дар ҳолати ислоҳкунӣ дар ин ҳолат panic-ро оғоз мекунад ва рамзи оптимизатсия бармегардад
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// бе panic.
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Дар хотир доред, ки#[inline] дар боло маънои онро дорад, ки семантикаи пуркунии тарҳкунӣ аз crate, ки мо ба он дохил кардаем, вобаста аст.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Рақами ифодаи аломати `self`-ро бармегардонад.
        ///
        ///  - `0` агар рақам сифр бошад
        ///  - `1` агар рақам мусбат бошад
        ///  - `-1` агар рақам манфӣ бошад
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// `true`-ро бармегардонад, агар `self` мусбат бошад ва `false`, агар рақам сифр ё манфӣ бошад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Агар `self` манфӣ бошад `true` ва агар он сифр ё мусбат бошад `false` бармегардонад.
        ///
        ///
        /// # Examples
        ///
        /// Истифодаи асосӣ:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Намоиши хотираи ин бутунро ҳамчун массиви байтӣ бо тартиби байти калон endian (network) баргардонед.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Намоиши хотираи ин бутунро ҳамчун массиви байтӣ бо тартиби каме-endian баргардонед.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Намоиши хотираи ин бутунро ҳамчун массиви байтӣ бо тартиби байти аслӣ баргардонед.
        ///
        /// Азбаски endianness-и аслии платформаи мавриди ҳадаф истифода мешавад, рамзи сайёр бояд ба ҷои он, мувофиқи мақсад, [`to_be_bytes`] ё [`to_le_bytes`]-ро истифода барад.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     байт, агар cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } дигар {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕХАТАР: : const садо, зеро бутунҳо намунаҳои оддии кӯҳна мебошанд, бинобар ин мо ҳамеша метавонем
        // онҳоро ба массивҳои байт табдил диҳед
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // БЕХАТАР: : бутунҳо типҳои оддии кӯҳна мебошанд, бинобар ин мо ҳамеша онҳоро ба шакли дигар мегузаронем
            // массиви байтҳо
            unsafe { mem::transmute(self) }
        }

        /// Намоиши хотираи ин бутунро ҳамчун массиви байтӣ бо тартиби байти аслӣ баргардонед.
        ///
        ///
        /// [`to_ne_bytes`] бояд ба қадри имкон бартарӣ дода шавад.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// бигзор байт= num.as_ne_bytes();
        /// assert_eq!(
        ///     байт, агар cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } дигар {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // БЕХАТАР: : бутунҳо типҳои оддии кӯҳна мебошанд, бинобар ин мо ҳамеша онҳоро ба шакли дигар мегузаронем
            // массиви байтҳо
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Аз намояндагии он ҳамчун массиви байтӣ дар endian калон арзиши бутун созед.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// истифода std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вуруд=истироҳат;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Аз намояндагии он ҳамчун массиви байтӣ дар endian хурд арзиши бутун созед.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// истифода std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вуруд=истироҳат;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Аз намояндагии хотираи он ҳамчун массиви байтӣ дар endanness ватанӣ арзиши бутун созед.
        ///
        /// Азбаски endianness-и аслии платформаи мавриди ҳадаф истифода мешавад, рамзи сайёр эҳтимол дорад, ки ба ҷои он [`from_be_bytes`] ё [`from_le_bytes`]-ро истифода барад.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } дигар {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// истифода std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * вуруд=истироҳат;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // БЕХАТАР: : const садо, зеро бутунҳо намунаҳои оддии кӯҳна мебошанд, бинобар ин мо ҳамеша метавонем
        // ба онҳо гузаред
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // БЕХАТАР: : бутунҳо типҳои оддии кӯҳна мебошанд, бинобар ин мо ҳамеша метавонем ба онҳо гузарем
            unsafe { mem::transmute(bytes) }
        }

        /// Рамзи нав бояд истифодаи онро афзалтар шуморад
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Қимати хурдтаринро, ки бо ин навъи бутун пешниҳод карда мешавад, бармегардонад.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Рамзи нав бояд истифодаи онро афзалтар шуморад
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Бузургтарин қиматеро, ки бо ин навъи бутун пешниҳод карда мешавад, бармегардонад.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}