//! Намудҳои хато барои гузариш ба намудҳои интегралӣ.

use crate::convert::Infallible;
use crate::fmt;

/// Ҳангоми баргардонидани намуди интегралии санҷидашуда, навъи хато бармегардад.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Мувофиқатро ба ҷои маҷбур кардан, мутмаин кунед, ки рамзи `From<Infallible> for TryFromIntError` дар боло вақте ки `Infallible` ба тахаллуси `!` табдил меёбад, корашро идома хоҳад дод.
        //
        //
        match never {}
    }
}

/// Хатогие, ки ҳангоми таҳлили бутун баргардонида мешавад.
///
/// Ин хато ҳамчун навъи хато барои функсияҳои `from_str_radix()` дар намудҳои ибтидоии бутун, ба монанди [`i8::from_str_radix`], истифода мешавад.
///
/// # Сабабҳои эҳтимолӣ
///
/// Дар байни дигар сабабҳо, `ParseIntError` метавонад аз сабаби пешрафт ё паси фосила дар сатр партофта шавад, масалан, вақте ки он аз вуруди стандартӣ ба даст оварда мешавад.
///
/// Истифодаи усули [`str::trim()`] кафолат медиҳад, ки пеш аз таҳлил ҳеҷ фазои сафед боқӣ намонад.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum барои нигоҳ доштани намудҳои гуногуни хатогиҳо, ки метавонад боиси нокомии таҳлили бутун гардад.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Арзиши таҳлилшуда холӣ аст.
    ///
    /// Дар қатори дигар сабабҳо, ин вариант ҳангоми таҳлили сатри холӣ сохта мешавад.
    Empty,
    /// Дар контексти он рақами беэътиборро дар бар мегирад.
    ///
    /// Дар қатори дигар сабабҳо, ин вариант ҳангоми таҳлили сатре сохта мешавад, ки дорои чархи ғайри ASCII бошад.
    ///
    /// Ин вариант инчунин вақте сохта мешавад, ки `+` ё `-` дар сатр ё мустақилона ё дар мобайни рақам ҷойгир карда шавад.
    ///
    ///
    InvalidDigit,
    /// Бутун барои нигаҳдорӣ дар навъи бутуни адаф хеле калон аст.
    PosOverflow,
    /// Бутун барои нигоҳдорӣ дар навъи бутуни ҳадаф хеле хурд аст.
    NegOverflow,
    /// Арзиш сифр буд
    ///
    /// Ин вариант вақте бароварда мешавад, ки сатри таҳлил арзиши сифр дошта бошад, ки барои намудҳои ғайрифулӣ ғайриқонунӣ хоҳад буд.
    ///
    Zero,
}

impl ParseIntError {
    /// Сабаби муфассали таҳлили нокомии бутунро мебарорад.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}