//! Доимии хоси навъи дақиқи шинокунандаи `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Рақамҳои аз ҷиҳати математикӣ муҳим дар зермодули `consts` оварда шудаанд.
//!
//! Барои собитҳое, ки мустақиман дар ин модул муайян шудаанд (фарқ аз онҳое, ки дар зермодули `consts` муайян шудаанд), коди нав бояд ба ҷои он доимиҳои алоқамандро, ки бевосита дар навъи `f32` муайян шудаанд, истифода барад.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Радикс ё пойгоҳи намояндагии дохилии `f32`.
/// Ба ҷои ин [`f32::RADIX`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // роҳи пешбинишуда
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Шумораи рақамҳои муҳим дар пойгоҳи 2.
/// Ба ҷои ин [`f32::MANTISSA_DIGITS`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // роҳи пешбинишуда
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Шумораи тахминии рақамҳои муҳим дар пойгоҳи 10.
/// Ба ҷои ин [`f32::DIGITS`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // роҳи пешбинишуда
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] арзиш барои `f32`.
/// Ба ҷои ин [`f32::EPSILON`]-ро истифода баред.
///
/// Ин фарқи байни `1.0` ва шумораи навбатии калонтарини намояндагӣ мебошад.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // роҳи пешбинишуда
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Хурдтарин арзиши ниҳоии `f32`.
/// Ба ҷои ин [`f32::MIN`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // роҳи пешбинишуда
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Арзиши хурдтарини арзиши муқаррарии `f32`.
/// Ба ҷои ин [`f32::MIN_POSITIVE`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // роҳи пешбинишуда
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Бузургтарин арзиши ниҳоии `f32`.
/// Ба ҷои ин [`f32::MAX`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // роҳи пешбинишуда
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Як бузургтар аз ҳадди ақали қудрати муқаррарии имконпазир аз 2 дараҷа.
/// Ба ҷои ин [`f32::MIN_EXP`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // роҳи пешбинишуда
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Қувваи ҳадди имконпазири 2 дараҷа.
/// Ба ҷои ин [`f32::MAX_EXP`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // роҳи пешбинишуда
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Ҳадди ақали қобилияти муқаррарии 10 дараҷа.
/// Ба ҷои ин [`f32::MIN_10_EXP`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // роҳи пешбинишуда
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Максимум қудрати имконпазир аз 10 дараҷа.
/// Ба ҷои ин [`f32::MAX_10_EXP`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // роҳи пешбинишуда
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Не рақами (NaN).
/// Ба ҷои ин [`f32::NAN`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // роҳи пешбинишуда
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Ба ҷои ин [`f32::INFINITY`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // роҳи пешбинишуда
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Беохирии манфӣ (−∞).
/// Ба ҷои ин [`f32::NEG_INFINITY`]-ро истифода баред.
///
/// # Examples
///
/// ```rust
/// // роҳи бекоршуда
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // роҳи пешбинишуда
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Доимии асосии математикӣ.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: бо собитҳои математикии аз cmath иваз кунед.

    /// (π) доимии Архимед
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Давраи пурраи доимии (τ)
    ///
    /// Ба 2π баробар аст.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Рақами Эйлер (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Радикс ё пойгоҳи намояндагии дохилии `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Шумораи рақамҳои муҳим дар пойгоҳи 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Шумораи тахминии рақамҳои муҳим дар пойгоҳи 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] арзиш барои `f32`.
    ///
    /// Ин фарқи байни `1.0` ва шумораи навбатии калонтарини намояндагӣ мебошад.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Хурдтарин арзиши ниҳоии `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Арзиши хурдтарини арзиши муқаррарии `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Бузургтарин арзиши ниҳоии `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Як бузургтар аз ҳадди ақали қудрати муқаррарии имконпазир аз 2 дараҷа.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Қувваи ҳадди имконпазири 2 дараҷа.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Ҳадди ақали қобилияти муқаррарии 10 дараҷа.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Максимум қудрати имконпазир аз 10 дараҷа.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Не рақами (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Беохирии манфӣ (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Агар ин қимат `NaN` бошад, `true`-ро бармегардонад.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` ба далели нигарониҳо дар бораи интиқол, дар libcore ба таври оммавӣ дастнорас аст, бинобар ин, ин амалиёт барои истифодаи хусусӣ дар дохили кишвар аст.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// `true`-ро бармегардонад, агар ин қимат беохирии мусбӣ ё беинтиҳои манфӣ бошад ва дар акси ҳол `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Бозмегардонад `true` агар ин рақам на бепоён бошад ва на `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Ҳоҷати кор бо NaN алоҳида нест: агар худ NaN бошад, муқоиса дуруст нест, ҳамон тавре ки дилхоҳ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Агар рақам [subnormal] бошад, `true`-ро бармегардонад.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Арзишҳо байни `0` ва `min` ғайритабиӣ мебошанд.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// `true`-ро бармегардонад, агар рақам на сифр, беохир, [subnormal] ё `NaN` бошад.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Арзишҳо байни `0` ва `min` ғайритабиӣ мебошанд.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Категорияи нуқтаи шинокунандаи рақамро бармегардонад.
    /// Агар танҳо як моликият санҷида шавад, ба ҷои он, истифодаи предикати мушаххас зудтар зудтар хоҳад буд.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Агар `self` аломати мусбат дошта бошад, аз ҷумла `+0.0`, `NaN` бо аломати мусбӣ ва беохирии мусбӣ `true`-ро бармегардонад.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Агар `self` аломати манфӣ дошта бошад, аз ҷумла `-0.0`, `NaN` бо аломати манфӣ ва беохирии манфӣ `true`-ро бармегардонад.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 мегӯяд: isSignMinus(x) дуруст аст, агар танҳо агар x аломати манфӣ дошта бошад.
        // isSignMinus ба сифрҳо ва NaNs низ дахл дорад.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// (inverse) мутақобилаи рақамро мегирад, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Радианҳоро ба дараҷа табдил медиҳад.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Барои дақиқии беҳтар доимӣ истифода баред.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Дараҷаҳоро ба радианҳо табдил медиҳад.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Максимум ду рақамро бармегардонад.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Агар яке аз далелҳо NaN бошад, пас далели дигар баргардонида мешавад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Ҳадди ақали ду рақамро бармегардонад.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Агар яке аз далелҳо NaN бошад, пас далели дигар баргардонида мешавад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Ба сӯи сифр давр мезанад ва ба ҳама намуди бутуни ибтидоӣ мубаддал мешавад, ба шарте ки қимат маҳдуд бошад ва ба ин тип мувофиқат кунад.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Арзиш бояд:
    ///
    /// * `NaN` набошад
    /// * Бепоён набошед
    /// * Пас аз буридани қисми касрии он, дар намуди бозгашти `Int` муаррифӣ шавед
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `FloatToInt::to_int_unchecked` риоя кунад.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Трансмутатсияи хом ба `u32`.
    ///
    /// Ин айни замон бо `transmute::<f32, u32>(self)` дар ҳама платформаҳо шабеҳ аст.
    ///
    /// Барои баъзе муҳокимаи интиқоли ин амалиёт ба `from_bits` нигаред (қариб ки ягон масъала вуҷуд надорад).
    ///
    /// Дар хотир доред, ки ин функсия аз кастинг `as` фарқ мекунад, ки кӯшиш мекунад арзиши * ададиро нигоҳ дорад, на арзиши битро.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() кастинг намекунад!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // БЕХАТАР: : `u32` як намуди додашудаи пешина аст, ки мо ҳамеша метавонем ба он гузарем
        unsafe { mem::transmute(self) }
    }

    /// Трансмутатсияи хом аз `u32`.
    ///
    /// Ин айни замон бо `transmute::<u32, f32>(v)` дар ҳама платформаҳо шабеҳ аст.
    /// Аз ин бармеояд, ки ин бениҳоят сайёр аст, бо ду сабаб:
    ///
    /// * Флотҳо ва Интҳо дар ҳамаи платформаҳои дастгиришаванда якхела мебошанд.
    /// * IEEE-754 тарҳбандии битҳои шиноварро хеле дақиқ муайян мекунад.
    ///
    /// Аммо як огоҳӣ вуҷуд дорад: пеш аз версияи IEEE-754 дар соли 2008, чӣ гуна тафсир кардани бит сигнали NaN воқеан муайян карда нашуда буд.
    /// Аксари платформаҳо (алалхусус x86 ва ARM) тафсиреро, ки дар ниҳоят дар соли 2008 стандартӣ шуда буд, интихоб карданд, аммо баъзеҳо чунин накарданд (алалхусус MIPS).
    /// Дар натиҷа, ҳама сигналҳои NaNs дар MIPS дар x86 NaNsи ором мебошанд ва баръакс.
    ///
    /// Ба ҷои кӯшиши ҳифзи платформаи сигнализатсия, ин амалисозӣ нигоҳ доштани битҳои дақиқро дастгирӣ мекунад.
    /// Ин маънои онро дорад, ки ҳама гуна сарбориҳои дар NaNs рамзкардашуда нигоҳ дошта мешаванд, ҳатто агар натиҷаи ин усул тавассути шабака аз мошини x86 ба як MIPS фиристода шавад.
    ///
    ///
    /// Агар натиҷаҳои ин усул танҳо бо ҳамон меъморие, ки онҳоро истеҳсол кардааст, идора карда шаванд, пас ҳеҷ гуна ташвиш вуҷуд надорад.
    ///
    /// Агар вуруд NaN набошад, пас ягон ташвиши интиқол вуҷуд надорад.
    ///
    /// Агар шумо дар бораи сигнализатсия ғамхорӣ накунед (ба эҳтимоли зиёд), пас ҳеҷ гуна ташвиш вуҷуд надорад.
    ///
    /// Дар хотир доред, ки ин функсия аз кастинг `as` фарқ мекунад, ки кӯшиш мекунад арзиши * ададиро нигоҳ дорад, на арзиши битро.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // БЕХАТАР: : `u32` як намуди додашудаи пешина аст, ки мо ҳамеша метавонем аз он интиқол диҳем
        // Аз ин бармеояд, ки масъалаҳои бехатарӣ бо sNaN зиёданд!Урат!
        unsafe { mem::transmute(v) }
    }

    /// Намоиши хотираи ин рақами нуқтаи шинокунандаро ҳамчун массиви байтӣ бо тартиби байти калон endian (network) баргардонед.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Намоиши хотираи ин рақами нуқтаи шинокунандаро ҳамчун массиви байтӣ бо тартиби каме-endian байт баргардонед.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Намоиши хотираи ин рақами нуқтаи шинокунандаро ҳамчун массиви байтӣ бо тартиби байти аслӣ баргардонед.
    ///
    /// Азбаски endianness-и аслии платформаи мавриди ҳадаф истифода мешавад, рамзи сайёр бояд ба ҷои он, мувофиқи мақсад, [`to_be_bytes`] ё [`to_le_bytes`]-ро истифода барад.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Намоиши хотираи ин рақами нуқтаи шинокунандаро ҳамчун массиви байтӣ бо тартиби байти аслӣ баргардонед.
    ///
    ///
    /// [`to_ne_bytes`] бояд ба қадри имкон бартарӣ дода шавад.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // БЕХАТАР: : `f32` як намуди додашудаи пешина аст, ки мо ҳамеша метавонем ба он гузарем
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Аз намояндагии он ҳамчун массиви байтӣ дар endian калон арзиши нуқтаи шинокунанда созед.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Аз тасвири он ҳамчун массиви байтӣ дар endian каме арзиши нуқтаи шинокунанда созед.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Аз тасвири он ҳамчун массиви байтӣ дар endian модарӣ арзиши нуқтаи шинокунанда созед.
    ///
    /// Азбаски endianness-и аслии платформаи мавриди ҳадаф истифода мешавад, рамзи сайёр эҳтимол дорад, ки ба ҷои он [`from_be_bytes`] ё [`from_le_bytes`]-ро истифода барад.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Фармоишро байни худ ва арзишҳои дигар бармегардонад.
    /// Баръакси муқоисаи ҷисмонии стандартӣ байни рақамҳои нуқтаи шинокунанда, ин муқоиса ҳамеша фармоишро мутобиқи предикати totalOrder, ки дар стандарти IEEE 754 (revision 2008) муайян карда шудааст, фармоиш медиҳад.
    /// Арзишҳо бо тартиби зерин фармоиш дода мешаванд:
    /// - НаНи ороми манфӣ
    /// - Сигнали манфии NaN
    /// - Беохирии манфӣ
    /// - Рақамҳои манфӣ
    /// - Рақамҳои манфӣ
    /// - Сифти манфӣ
    /// - Нули мусбат
    /// - Рақамҳои мусбатнормалӣ
    /// - Рақамҳои мусбат
    /// - Беохирии мусбат
    /// - Нишондиҳандаи мусбии NaN
    /// - НаНи ороми мусбат
    ///
    /// Дар хотир доред, ки ин вазифа на ҳамеша бо татбиқи [`PartialOrd`] ва [`PartialEq`] аз `f32` мувофиқат мекунад.Аз ҷумла, онҳо сифри манфӣ ва мусбатро баробар меҳисобанд, дар ҳоле ки `total_cmp` чунин намекунад.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Дар ҳолати манфӣ, ҳамаи битҳоро ғайр аз аломат чаппа кунед, то ба як тарҳ шабеҳи ададҳои пурраи ду шавад
        //
        // Чаро ин кор мекунад?IEEE 754 шиновар аз се майдон иборат аст:
        // Аломати бит, нишондиҳанда ва мантисса.Маҷмӯи майдонҳои нишондиҳанда ва мантисса дар маҷмӯъ чунин хосият доранд, ки тартиби ададии онҳо ба бузургии ададӣ, ки бузургӣ муайян карда шудааст, баробар аст.
        // Бузургӣ одатан дар арзишҳои NaN муқаррар карда нашудааст, аммо IEEE 754 totalOrder арзишҳои NaN-ро низ барои риояи тартиби адад муайян мекунад.Ин боиси он мегардад, ки дар шарҳи doc фаҳмонда шудааст.
        // Аммо, нишондиҳандаи бузургӣ барои ададҳои манфӣ ва мусбӣ яксон аст-танҳо бит аломат фарқ мекунад.
        // Барои ба осонӣ муқоиса кардани ҷойивазкунандагон ҳамчун ададҳои тамғаи имзошуда, ба мо лозим аст, ки дар ҳолати ададҳои манфӣ, битҳои дараҷа ва мантиссаро бурем.
        // Мо рақамҳоро самаранок ба шакли "two's complement" табдил медиҳем.
        //
        // Барои иҷро кардани варақгардонӣ, мо ниқоб месозем ва бар зидди он XOR месозем.
        // Мо бидуни шакл ниқоби "all-ones except for the sign bit"-ро аз арзишҳои манфии имзошуда ҳисоб мекунем: аломати тағирёбии рост-адади бутунро дароз мекунад, бинобар ин мо ниқобро бо бит аломат мегузорем ва пас ба тела додани як бит сифри дигар ба имзонашуда табдил медиҳем.
        //
        // Дар муқоиса бо арзишҳои мусбат, ниқоб ҳама сифрҳо мебошанд, бинобар ин, ин ғайриимкон аст.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Арзишро бо фосилаи муайян маҳдуд кунед, агар он NaN бошад.
    ///
    /// `max`-ро бармегардонад, агар `self` аз `max` бузургтар бошад ва `min` агар `self` аз `min` камтар бошад.
    /// Дар акси ҳол, ин `self` бармегардад.
    ///
    /// Дар хотир доред, ки ин функсия NaN-ро бармегардонад, агар арзиши ибтидоӣ низ NaN бошад.
    ///
    /// # Panics
    ///
    /// Panics агар `min > max`, `min` NaN бошад, ё `max` NaN аст.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}