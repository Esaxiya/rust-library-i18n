//! Функсияҳои коммуналӣ барои бегумон, ки ба усули табдил додани онҳо аз ҳад зиёд маъно надоранд.

// FIXME Номи ин модул каме бадбахт аст, зеро модулҳои дигар низ `core::num` ворид мекунанд.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Санҷед, ки оё буридани ҳама битҳо аз `ones_place` камтар аҳамият дорад, хатои нисбиро камтар аз 0.5 ULP, баробар ё бузургтар мекунад.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Агар ҳамаи битҳои боқимонда сифр бошанд, он= 0.5 ULP, вагарна> 0.5 Агар битҳо зиёдтар набошанд (half_bit==0), дар поён низ дуруст Баргардонида мешавад.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Сатри ASCII-ро, ки танҳо рақамҳои даҳиро дар бар мегирад, ба `u64` табдил медиҳад.
///
/// Аломатҳои изофӣ ё беэътиборро тафтиш намекунад, аз ин рӯ, агар зангзан эҳтиёткор набошад, натиҷа дурӯғ аст ва метавонад panic бошад (гарчанде ки он `unsafe` нахоҳад буд).
/// Ғайр аз он, сатрҳои холӣ ҳамчун сифр ҳисобида мешаванд.
/// Ин вазифа аз он сабаб вуҷуд дорад
///
/// 1. истифодаи `FromStr` дар `&[u8]` талаб `from_utf8_unchecked`, ки бад аст, ва
/// 2. Пайваст кардани натиҷаҳои `integral.parse()` ва `fractional.parse()` нисбат ба тамоми функсия мушкилтар аст.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Сатри рақамҳои ASCII-ро ба bignum табдил медиҳад.
///
/// Мисли `from_str_unchecked`, ин функсия ба ҷудокунии рақамҳои ғайри рақамӣ такя мекунад.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Бигнумро ба адади 64 бит мекушояд.Panics агар рақам хеле зиёд бошад.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Як қатор битҳоро ҷудо мекунад.

/// Индекси 0 каме каме назаррас аст ва диапазон одатан нисфи кушода аст.
/// Panics, агар дархост карда шавад, ки аз оне, ки ба навъи бозгаштан мувофиқат кунад, битҳои бештар истихроҷ кунад.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}