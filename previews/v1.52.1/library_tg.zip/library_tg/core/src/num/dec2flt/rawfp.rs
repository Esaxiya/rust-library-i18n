//! Дар бораи IEEE 754 мусбат шино мекунад.Рақамҳои манфӣ коркард намешаванд ва лозим нестанд.
//! Рақамҳои муқаррарии нуқтаи шинокунанда дорои каноникии дорои (frac, exp) мебошанд, ки қимат 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), ки N шумораи битҳост).
//!
//! Субнормалҳо каме фарқ ва аҷибанд, аммо ҳамон принсип амал мекунад.
//!
//! Аммо, дар ин ҷо, мо онҳоро ҳамчун (sig, k) бо f мусбат муаррифӣ мекунем, ки қимат f * бошад
//! 2 <sup>д</sup> .Ғайр аз он, ки "hidden bit" дақиқ карда мешавад, ин нишондиҳандаро бо тағирёбии ба ном mantissa тағир медиҳад.
//!
//! Ба тариқи дигар, одатан шиноварҳо ҳамчун (1) навишта мешаванд, аммо дар ин ҷо онҳо ҳамчун (2) навишта мешаванд:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Мо (1)-ро **намояндагии касрӣ** ва (2)-ро **намояндагии интегралӣ** меномем.
//!
//! Бисёр функсияҳои ин модул танҳо рақамҳои оддиро идора мекунанд.Равандҳои dec2flt барои рақамҳои хеле хурд ва хеле калон ба таври муҳофизакорона роҳи сусти универсалӣ (Алгоритми М)-ро пеш мегиранд.
//! Ин алгоритм танҳо ба next_float() ниёз дорад, ки subnormals ва сифрҳоро идора мекунад.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Ёрдамчии trait барои пешгирӣ кардани такрори ҳамаи рамзҳои табдили `f32` ва `f64`.
///
/// Барои шарҳ додани ин шарҳи ҳуҷҷати модули волидайн нигаред.
///
/// Оё **ҳеҷ гоҳ ҳеҷ гоҳ** барои дигар намудҳо амалӣ карда нашавад ё берун аз модули dec2flt истифода шавад.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Намуди истифода аз `to_bits` ва `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Трансмутатсияи хомро ба бутун иҷро мекунад.
    fn to_bits(self) -> Self::Bits;

    /// Трансмутатсияи хомро аз бутун иҷро мекунад.
    fn from_bits(v: Self::Bits) -> Self;

    /// Категорияеро, ки ин рақам дохил мешавад, бармегардонад.
    fn classify(self) -> FpCategory;

    /// Мантисса, нишондиҳанда ва аломатро ҳамчун адад бармегардонад.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Декодро шино мекунад.
    fn unpack(self) -> Unpacked;

    /// Аз бутуни хурд мепартояд, ки онро дақиқ нишон додан мумкин аст.
    /// Агар Panic агар бутунро нишон додан ғайриимкон бошад, рамзи дигари ин модул боварӣ ҳосил мекунад, ки ҳеҷ гоҳ рух надиҳад.
    fn from_int(x: u64) -> Self;

    /// Аз ҷадвали пешакӣ ҳисобкардашуда 10 <sup>e-ро мегирад</sup> .
    /// Panics барои `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Ном чӣ мегӯяд.
    /// Коди сахт нисбат ба ҷонглези ботинӣ осонтар аст ва умедворам, ки LLVM доимии онро пӯшонад.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Консервативӣ ба рақамҳои даҳии ашё вобастагӣ дорад, ки наметавонад изофа ё сифрро ба вуҷуд оранд
    /// subnormals.Эҳтимол, нишондиҳандаи даҳии арзиши максималии муқаррарӣ, аз ин рӯ ном.
    const MAX_NORMAL_DIGITS: usize;

    /// Вақте ки рақами даҳии муҳимтарин арзиши ҷойро аз ин зиёдтар дошта бошад, албатта ин рақам то абадият мудаввар карда мешавад.
    ///
    const INF_CUTOFF: i64;

    /// Вақте ки рақами даҳии муҳимтарин арзиши ҷойро аз ин камтар дошта бошад, рақам албатта ба сифр якҷоя карда мешавад.
    ///
    const ZERO_CUTOFF: i64;

    /// Шумораи битҳо дар экспонент.
    const EXP_BITS: u8;

    /// Шумораи битҳо дар муҳим,*аз ҷумла* каме пинҳоншуда.
    const SIG_BITS: u8;

    /// Шумораи битҳо дар сигнал, бе истисно * каме пинҳон карда мешавад.
    const EXPLICIT_SIG_BITS: u8;

    /// Нишондиҳандаи максималии ҳуқуқӣ дар намояндагии касрӣ.
    const MAX_EXP: i16;

    /// Нишондиҳандаи ҳадди ақали қонунӣ дар намояндагии касрӣ, ба истиснои зернормалҳо.
    const MIN_EXP: i16;

    /// `MAX_EXP` барои намояндагии интегралӣ, яъне бо басти истифодашаванда.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` рамзбандӣ шудааст (яъне, бо ғарази офсетӣ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` барои намояндагии интегралӣ, яъне бо басти истифодашаванда.
    const MIN_EXP_INT: i16;

    /// Ҳадди ҳадди эътидол ва муаррифии интегралӣ.
    const MAX_SIG: u64;

    /// Ҳадди ақали меъёршуда ва муаррифии интегралӣ.
    const MIN_SIG: u64;
}

// Асосан ҳалли муваққатӣ барои #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Мантисса, нишондиҳанда ва аломатро ҳамчун адад бармегардонад.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Нишондиҳандаи ғарқшавӣ + тағирёбии мантисса
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe номуайян аст, ки оё `as` дар ҳамаи платформаҳо дуруст давр мезанад ё не.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Мантисса, нишондиҳанда ва аломатро ҳамчун адад бармегардонад.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Нишондиҳандаи ғарқшавӣ + тағирёбии мантисса
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe номуайян аст, ки оё `as` дар ҳамаи платформаҳо дуруст давр мезанад ё не.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp`-ро ба наздиктарин навъи шинокунандаи мошин табдил медиҳад.
/// Натиҷаҳои ғайримуқаррариро идора намекунад.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 бит аст, аз ин рӯ xe тағирёбии мантисса бо 63 аст
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Мувофиқати 64-битаро ба битҳои T::SIG_BITS бо нима ҳамвор кунед.
/// Аз ҳад зиёд ифлосшавӣ кор намекунад.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Сменаи мантисисаро танзим кунед
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Баръакси `RawFloat::unpack()` барои рақамҳои муқаррарӣ.
/// Panics, агар нишона ё нишондиҳанда барои рақамҳои мӯътадил эътибор надошта бошанд.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Лаҷои пинҳоншударо хориҷ кунед
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Нишондиҳандаро барои ғарази нишондиҳанда ва гузариши mantissa танзим кунед
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Нишони худро дар 0 ("+") гузоред, рақамҳои мо ҳама мусбатанд
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Сохтани як ғайритабиӣ.Мантиссаи 0 иҷозат дода шудааст ва сифр месозад.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Нишондиҳандаи рамзгузорӣ 0, бит аломат 0, аз ин рӯ, мо бояд битҳоро дубора тафсир кунем.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Бигнумро бо Fp тахмин кунед.Дар доираи 0.5 ULP давр мезанад.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Мо ҳамаи битҳоро пеш аз индекси `start` буридем, яъне самаранок ба андозаи `start` смена мекунем, аз ин рӯ, ин нишондиҳандаи ба мо лозим аст.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // (half-to-even) мудаввар вобаста ба битҳои буридашуда.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Бузургтарин адади нуқтаи шинокунандаро қатъиян камтар аз далел пайдо мекунад.
/// Зеркормалҳо, сифр ё зернамоишро кор намекунад.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Рақами хурдтарини нуқтаи шинокунандаро аз далел қатъиян калонтар ёбед.
// Ин амал тофта аст, яъне next_float(inf) ==inf.
// Баръакси аксари рамзҳои ин модул, ин функсия сифр, зеркалмҳо ва беохириро идора мекунад.
// Аммо, ба монанди ҳамаи рамзҳои дигари ин ҷо, он бо NaN ва рақамҳои манфӣ сарукор намекунад.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Чунин ба назар мерасад, ки дуруст аст, аммо он кор мекунад.
        // 0.0 ҳамчун калимаи сифр рамзгузорӣ шудааст.Зернормалҳо 0x000m ... m мебошанд, ки дар он m мантисса аст.
        // Аз ҷумла, хурдтарин зернормалӣ 0x0 ... 01 ва калонтарин 0x000F ... F мебошад.
        // Адади хурдтарини муқаррарӣ 0x0010 ... 0 мебошад, аз ин рӯ ин парвандаи кунҷӣ низ кор мекунад.
        // Агар афзоиш аз мантисса боло равад, бит интиқол нишондиҳандаро тавре ки мо мехоҳем афзоиш медиҳад ва битҳои мантисса сифр мешаванд.
        // Азбаски конвенсияи пинҳоншудаи бит, ин низ маҳз ҳамон чизест, ки мо мехоҳем!
        // Ниҳоят, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}