//! Тасдиқ ва ҷудо кардани сатри даҳии форма:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Ба ибораи дигар, синтаксиси стандартии нуқтаи шинокунанда, ба истиснои ду истисно: Ягон аломат ва муомилаи "inf" ва "NaN".Инҳоро функсияи драйвер (super::dec2flt) идора мекунад.
//!
//! Гарчанде ки шинохтани вуруди дуруст нисбатан осон аст, ин модул инчунин бояд вариантҳои бешумори беэътиборро ҳеҷ гоҳ panic рад кунад ва санҷишҳои зиёдеро анҷом диҳад, ки модулҳои дигар ба навбати худ ба panic (ё изофа) такя накунанд.
//!
//! Барои бадтар кардани вазъ, ҳама он чизе, ки дар як гузариш ба вуқӯъ мегузарад.
//! Пас, ҳангоми тағир додани чизе эҳтиёт бошед ва бо модулҳои дигар дубора санҷед.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Қисмҳои ҷолиби сатри даҳӣ.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Сатҳи даҳӣ, кафолат дода мешавад, ки камтар аз 18 адади даҳӣ дошта бошад.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Тафтиш мекунад, ки оё сатри вуруд рақами дурусти нуқтаи шинокунанда аст ва агар бошад, қисми ҷудонашаванда, қисми касрӣ ва нишондиҳандаро дар он ҷойгир кунед.
/// Оё нишонаҳо кор намекунад.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Пеш аз 'e' рақам нест
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Мо ҳадди аққал як рақамро пеш аз ё пас аз нуқта талаб мекунем.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Партофтани партовҳо пас аз қисми касрӣ
            }
        }
        _ => Invalid, // Дар паси сатри рақамӣ партофтан
    }
}

/// Рақамҳои даҳиро то аломати ғайримарқалии аввал мекашонад.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Истихроҷи нишондиҳандаҳо ва тафтиши хатогиҳо.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Қафои партовҳо пас аз нишондиҳанда
    }
    if number.is_empty() {
        return Invalid; // Нишондиҳандаи холӣ
    }
    // Дар ин лаҳза, мо албатта сатри дурусти рақамҳо дорем.Шояд ба `i64` гузоштан хеле тӯлонӣ бошад, аммо агар он қадар бузург бошад, вуруди он албатта сифр ё беохир аст.
    // Азбаски ҳар як сифр дар рақамҳои даҳӣ нишондиҳандаро танҳо бо +/-1 танзим мекунад, ҳангоми exp=10 ^ 18 вуруд бояд 17 экзабайт (!) сифрро ташкил диҳад, то ҳатто ба фосилаи дур ба ниҳоӣ наздик шавад.
    //
    // Ин дақиқ як ҳолати истифодаест, ки мо бояд ба ӯ муроҷиат кунем.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}