use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` аммо ғайри сифр ва ковариант.
///
/// Ин аксар вақт чизи дурустест, ки ҳангоми сохтани структураҳои маълумот бо истифода аз нишондиҳандаҳои хом истифода мешавад, аммо бо истифода аз хосиятҳои иловагии он дар ниҳоят хавфноктар аст.Агар шумо мутмаин набошед, ки оё шумо бояд `NonNull<T>`-ро истифода баред, танҳо аз `*mut T` истифода баред!
///
/// Баръакси `*mut T`, нишондиҳанда бояд ҳамеша нул бошад, ҳатто агар нишондиҳанда ҳеҷ гоҳ истинод карда нашавад.Ин барои он аст, ки энумҳо ин арзиши манъшударо ҳамчун дискриминант истифода баранд-`Option<NonNull<T>>` андозаи баробари `* mut T` дорад.
/// Аммо, агар нишон дода нашуда бошад, нишондиҳанда метавонад боз ҳам сусттар шавад.
///
/// Баръакси `*mut T`, `NonNull<T>` covariant бар `T` интихоб карда шуд.Ин имкон медиҳад, ки ҳангоми сохтани намудҳои ковариант истифодаи `NonNull<T>` истифода бурда шавад, аммо хавфи беасосиро дар ҳолате истифода мебарад, ки дар намуди номувофиқ набошад.
/// (Интихоби баръакс барои `*mut T` дода шуд, гарчанде ки аз ҷиҳати техникӣ беасос танҳо аз ҷониби занг задани функсияҳои хатарнок ба амал омада метавонад.)
///
/// Ковариансия барои абстраксияҳои бехатартарин, ба монанди `Box`, `Rc`, `Arc`, `Vec` ва `LinkedList` дуруст аст.Ин ҳолат аз он сабаб аст, ки онҳо API-и оммавиро пешниҳод мекунанд, ки қоидаҳои муқаррарии мутобиқшавандаи XOR-и Rust-ро риоя мекунанд.
///
/// Агар навъи шумо ба таври бехатар коварӣ шуда натавонад, шумо бояд кафолат диҳед, ки он дорои майдони иловагии иловагӣ мебошад.Аксар вақт ин майдон як намуди [`PhantomData`], ба монанди `PhantomData<Cell<T>>` ё `PhantomData<&'a mut T>` хоҳад буд.
///
/// Аҳамият диҳед, ки `NonNull<T>` барои `&T` мисоли `From` дорад.Аммо, ин далелро тағир намедиҳад, ки мутатсия тавассути (ишоракунанда аз а) истиноди муштарак рафтори номуайян аст, агар мутатсия дар дохили [`UnsafeCell<T>`] ба амал наояд.Худи ҳамин ба эҷоди истиноди тағиршаванда аз истиноди муштарак дахл дорад.
///
/// Ҳангоми истифодаи ин мисоли `From` бе `UnsafeCell<T>`, масъулияти шумо барои он аст, ки `as_mut` ҳеҷ гоҳ даъват карда нашавад ва `as_ptr` ҳеҷ гоҳ барои мутатсия истифода набарад.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` нишоннамоҳо `Send` нестанд, зеро маълумотҳое, ки онҳо истинод мекунанд, метавонанд тахаллус шаванд.
// ЗН, ин маънои нолозим аст, аммо бояд паёмҳои хатогии беҳтарро пешниҳод кунад.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` нишоннамоҳо `Sync` нестанд, зеро маълумотҳое, ки онҳо истинод мекунанд, метавонанд тахаллус шаванд.
// ЗН, ин маънои нолозим аст, аммо бояд паёмҳои хатогии беҳтарро пешниҳод кунад.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// `NonNull` наверо месозад, ки овезон аст, аммо хуб мутобиқат мекунад.
    ///
    /// Ин барои оғози навъҳое, ки бо танбалӣ ҷудо мекунанд, ба монанди `Vec::new` муфид аст.
    ///
    /// Дар хотир доред, ки арзиши ишоракунанда метавонад эҳтимолан як нишоннамои дурустро ба `T` нишон диҳад, яъне ин маънои онро надорад, ки ҳамчун посбон "not yet initialized" истифода бурда нашавад.
    /// Намудҳое, ки танбалона ҷудо мекунанд, бояд ибтидоиро бо ягон роҳи дигар пайгирӣ кунанд.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // БЕХАТАР: : mem::align_of() истифодаи ғайри сифрро бармегардонад, ки пас аз он интиқол дода мешавад
        // ба а * мут Т.
        // Аз ин рӯ, `ptr` беэътибор нест ва шароити даъват ба new_unchecked() риоя карда мешавад.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Истинодҳои муштаракро ба арзиш бармегардонад.Дар муқоиса бо [`as_ref`], ин талаб намекунад, ки арзиш оғоз карда шавад.
    ///
    /// Барои ҳамтои тағирёбанда ба [`as_uninit_mut`] нигаред.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд дуруст мутобиқ карда шавад.
    ///
    /// * Он бояд ба маънои дар [the module documentation] муайяншуда "dereferencable" бошад.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///
    ///   Аз ҷумла, дар тӯли тамоми ин умр, хотираи нишоннамо ба он мутант нашавад (ба истиснои дохили `UnsafeCell`).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истинод.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Истинодҳои беназирро ба арзиш бармегардонад.Дар муқоиса бо [`as_mut`], ин талаб намекунад, ки арзиш оғоз карда шавад.
    ///
    /// Барои ҳамтои муштарак нигаред ба [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд дуруст мутобиқ карда шавад.
    ///
    /// * Он бояд ба маънои дар [the module documentation] муайяншуда "dereferencable" бошад.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///
    ///   Аз ҷумла, дар тӯли ин умр, хотираи нишоннамо ба он ишора карда намешавад, ки тавассути ягон нишондиҳандаи дигар дастрасӣ пайдо накунад (хонда ё навишта нашудааст).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истинод.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` нав месозад.
    ///
    /// # Safety
    ///
    /// `ptr` бояд нул бошад.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `ptr` ночиз аст.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Агар `ptr` нул бошад, `NonNull` нав эҷод мекунад.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕХАТАР: : Нишондиҳанда аллакай санҷида шудааст ва холӣ нест
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Ҳамон як функсияро бо [`std::ptr::from_raw_parts`] иҷро мекунад, ба истиснои он, ки нишоннамои `NonNull` баръакс ба нишондиҳандаи хом `*const` бармегардад.
    ///
    ///
    /// Барои тафсилоти бештар ба ҳуҷҷатҳои [`std::ptr::from_raw_parts`] нигаред.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // БЕХАТАР: : Натиҷаи `ptr::from::raw_parts_mut` беэътибор аст, зеро `data_address` чунин аст.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Ҷудокунии нишондиҳанда (эҳтимолан васеъ) ба ҷузъҳои суроға ва метамаълумот аст.
    ///
    /// Баъдтар нишоннаморо бо [`NonNull::from_raw_parts`] барқарор кардан мумкин аст.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Нишондиҳандаи асосии `*mut`-ро ба даст меорад.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Истиноди муштаракро ба арзиши бармегардонад.Агар арзиш метавонад ибтидоӣ карда нашавад, ба ҷои он бояд [`as_uninit_ref`] истифода шавад.
    ///
    /// Барои ҳамтои тағирёбанда ба [`as_mut`] нигаред.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд дуруст мутобиқ карда шавад.
    ///
    /// * Он бояд ба маънои дар [the module documentation] муайяншуда "dereferencable" бошад.
    ///
    /// * Нишондиҳанда бояд ба мисоли ибтидоии `T` ишора кунад.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///
    ///   Аз ҷумла, дар тӯли тамоми ин умр, хотираи нишоннамо ба он мутант нашавад (ба истиснои дохили `UnsafeCell`).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    /// (Қисмат дар бораи ибтидогузорӣ ҳанӯз пурра ҳал нашудааст, аммо то он даме, ки ягона равиши бехатар ин таъмини он аст, ки онҳо воқеан ибтидоӣ карда шаванд.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истинод.
        unsafe { &*self.as_ptr() }
    }

    /// Истиноди беназир ба арзишро бармегардонад.Агар арзиш метавонад ибтидоӣ карда нашавад, ба ҷои он бояд [`as_uninit_mut`] истифода шавад.
    ///
    /// Барои ҳамтои муштарак нигаред ба [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд дуруст мутобиқ карда шавад.
    ///
    /// * Он бояд ба маънои дар [the module documentation] муайяншуда "dereferencable" бошад.
    ///
    /// * Нишондиҳанда бояд ба мисоли ибтидоии `T` ишора кунад.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///
    ///   Аз ҷумла, дар тӯли ин умр, хотираи нишоннамо ба он ишора карда намешавад, ки тавассути ягон нишондиҳандаи дигар дастрасӣ пайдо накунад (хонда ё навишта нашудааст).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    /// (Қисмат дар бораи ибтидогузорӣ ҳанӯз пурра ҳал нашудааст, аммо то он даме, ки ягона равиши бехатар ин таъмини он аст, ки онҳо воқеан ибтидоӣ карда шаванд.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истиноди тағйирёбанда.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ба нишоннамои навъи дигар мепартояд.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // БЕХАТАР: : `self` як нишоннамои `NonNull` мебошад, ки ҳатман бекор аст
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Аз нишоннамои борик ва дарозӣ як буридаи хоми ғайримуқаррарӣ месозад.
    ///
    /// Далели `len` шумораи **элементҳо** аст, на шумораи байтҳо.
    ///
    /// Ин функсия бехатар аст, аммо фарқияти арзиши баргардонидан хатарнок аст.
    /// Барои талабот ба бехатарии буррҳо ба ҳуҷҷатҳои [`slice::from_raw_parts`] нигаред.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ҳангоми сар додан бо нишоннамо ба унсури аввал нишондиҳандаи бурришро эҷод кунед
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Дар хотир доред, ки ин мисол ба таври сунъӣ истифодаи ин усулро нишон медиҳад, аммо "бигзор буриш= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // БЕХАТАР: : `data` як нишоннамои `NonNull` мебошад, ки ҳатман бекор аст
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Дарозии буридаи хомро бо сифр бармегардонад.
    ///
    /// Арзиши баргашта шумораи **элементҳо** аст, на шумораи байтҳо.
    ///
    /// Ин вазифа бехатар аст, ҳатто вақте ки як буридаи хом ғайри холӣ ба як бурида дода намешавад, зеро нишоннамо суроғаи дуруст надорад.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Нишондиҳандаи ғайривоқеаро ба буферии бурида бармегардонад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // БЕХАТАР: : Мо медонем, ки `self` бефоида аст.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Нишондиҳандаи хомро ба буферии бурида бармегардонад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Истиноди муштаракро ба буридаи арзишҳои эҳтимолан номаълум бармегардонад.Дар муқоиса бо [`as_ref`], ин талаб намекунад, ки арзиш оғоз карда шавад.
    ///
    /// Барои ҳамтои тағирёбанда ба [`as_uninit_slice_mut`] нигаред.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд барои хондан барои `ptr.len() * mem::size_of::<T>()` бисёр байт [valid] бошад ва он бояд дуруст мутобиқ карда шавад.Ин аз ҷумла маънои онро дорад:
    ///
    ///     * Тамоми диапазони хотираи ин бурр бояд дар дохили як объекти ҷудошуда бошад!
    ///       Иловаҳо ҳеҷ гоҳ дар саросари объектҳои ҷудошуда паҳн шуда наметавонанд.
    ///
    ///     * Нишондиҳанда бояд ҳатто барои порчаҳои дарозии сифр баробар карда шавад.
    ///     Яке аз сабабҳои он дар он аст, ки оптимизатсияҳои тарҳбандии рӯйхат метавонанд ба маълумотномаҳо (аз ҷумла бурришҳо бо дарозии ҳархела) такя карда, онҳоро аз маълумоти дигар фарқ кунанд.
    ///
    ///     Шумо метавонед як нишоннамоеро, ки ҳамчун `data` барои бурришҳои дарозии сифр истифода мешавад [`NonNull::dangling()`] гиред.
    ///
    /// * Андозаи умумии `ptr.len() * mem::size_of::<T>()` бурида набояд аз `isize::MAX` зиёд бошад.
    ///   Ба ҳуҷҷатҳои бехатарии [`pointer::offset`] нигаред.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///   Аз ҷумла, дар тӯли тамоми ин умр, хотираи нишоннамо ба он мутант нашавад (ба истиснои дохили `UnsafeCell`).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    ///
    /// Инчунин нигаред ба [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `as_uninit_slice` риоя кунад.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Истиноди беназирро ба буридаи арзишҳои эҳтимолан номаълум бармегардонад.Дар муқоиса бо [`as_mut`], ин талаб намекунад, ки арзиш оғоз карда шавад.
    ///
    /// Барои ҳамтои муштарак нигаред ба [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ҳангоми даъват кардани ин усул, шумо бояд боварӣ ҳосил кунед, ки ҳамаи инҳо дурустанд:
    ///
    /// * Нишондиҳанда бояд [valid] барои хондан ва навиштан барои `ptr.len() * mem::size_of::<T>()` байти зиёде бошад ва он бояд дуруст мувофиқат карда шавад.Ин аз ҷумла маънои онро дорад:
    ///
    ///     * Тамоми диапазони хотираи ин бурр бояд дар дохили як объекти ҷудошуда бошад!
    ///       Иловаҳо ҳеҷ гоҳ дар саросари объектҳои ҷудошуда паҳн шуда наметавонанд.
    ///
    ///     * Нишондиҳанда бояд ҳатто барои порчаҳои дарозии сифр баробар карда шавад.
    ///     Яке аз сабабҳои он дар он аст, ки оптимизатсияҳои тарҳбандии рӯйхат метавонанд ба маълумотномаҳо (аз ҷумла бурришҳо бо дарозии ҳархела) такя карда, онҳоро аз маълумоти дигар фарқ кунанд.
    ///
    ///     Шумо метавонед як нишоннамоеро, ки ҳамчун `data` барои бурришҳои дарозии сифр истифода мешавад [`NonNull::dangling()`] гиред.
    ///
    /// * Андозаи умумии `ptr.len() * mem::size_of::<T>()` бурида набояд аз `isize::MAX` зиёд бошад.
    ///   Ба ҳуҷҷатҳои бехатарии [`pointer::offset`] нигаред.
    ///
    /// * Шумо бояд қоидаҳои тахаллуси Rust-ро ҷорӣ кунед, зеро `'a` умри баргашта худсарона интихоб карда шудааст ва ҳатман умри воқеии маълумотро инъикос намекунад.
    ///   Аз ҷумла, дар тӯли ин умр, хотираи нишоннамо ба он ишора карда намешавад, ки тавассути ягон нишондиҳандаи дигар дастрасӣ пайдо накунад (хонда ё навишта нашудааст).
    ///
    /// Ин ҳатто агар натиҷаи ин усул истифода нашуда бошад ҳам дахл дорад!
    ///
    /// Инчунин нигаред ба [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Ин бехатар аст, зеро `memory` барои хондан ва навиштан барои `memory.len()` бисёр байт эътибор дорад.
    /// // Дар хотир доред, ки занг задан ба `memory.as_mut()` дар ин ҷо манъ аст, зеро мундариҷа метавонад номаълум бошад.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `as_uninit_slice_mut` риоя кунад.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Нишондихандаи хомро ба унсур ё сублисия бармегардонад, бидуни тафтиши ҳудуд.
    ///
    /// Даъват кардани ин усул бо индекси берун аз ҳудуд ё вақте ки `self` мустаҳкам нест, ин *[рафтори номуайян]* аст, ҳатто агар нишоннамои натиҷа истифода нашуда бошад.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // БЕХАТАР: : даъваткунанда кафолат медиҳад, ки `self` мустақим ва `index` дар ҳудуд аст.
        // Дар натиҷа, нишоннамои натиҷа наметавонад NULL бошад.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // БЕХАТАР: : Нишондиҳандаи беназир наметавонад сифр бошад, аз ин рӯ, шароит барои
        // new_unchecked() эҳтиром доранд.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕХАТАР reference: Истиноди тағирёбанда наметавонад бекор бошад.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // БЕХАТАР: : Истинод беэътибор буда наметавонад, аз ин рӯ шартҳо барои
        // new_unchecked() эҳтиром доранд.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}