#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Намуди метамаълумоти нишоннамои ҳама гуна намуди ишорашударо таъмин менамояд.
///
/// # Метамаълумоти нишоннамо
///
/// Намудҳои хом ва намудҳои истинод дар Rust метавонанд аз ду қисм сохта шаванд:
/// нишоннамои маълумоте, ки суроғаи хотираи арзиш ва баъзе метамаълумотро дар бар мегирад.
///
/// Барои намудҳои статикии андозаи (ки `Sized` traits-ро татбиқ мекунанд) ва инчунин барои намудҳои `extern` нишондиҳандаҳо "тунук" гуфта мешаванд: метамаълумот ба андозаи сифр ва навъи он `()` аст.
///
///
/// Нишондиҳандаҳо ба [dynamically-sized types][dst] "васеъ" ё "фарбеҳ" гуфта мешаванд, ки онҳо метамаълумотҳои андозаи сифр надоранд:
///
/// * Барои структураҳое, ки майдони охирини онҳо DST мебошад, метамаълумот мета-маълумоти майдони охирин аст
/// * Барои навъи `str`, метамаълумот дарозии байт ба андозаи `usize` аст
/// * Барои намудҳои бурида, ба монанди `[T]`, метамаълумот дарозии ашё ҳамчун `usize` мебошад
/// * Барои объектҳои trait, ба монанди `dyn SomeTrait`, метамаълумот [`DynMetadata<Self>`][DynMetadata] аст (масалан, `DynMetadata<dyn SomeTrait>`)
///
/// Дар future, забони Rust метавонад намудҳои навро ба даст орад, ки метамаълумотҳои мухталиф доранд.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Нуқтаи ин trait навъи алоқаманди `Metadata` аст, ки `()` ё `usize` ё `DynMetadata<_>` тавре ки дар боло тавсиф шудааст.
/// Он барои ҳар як намуди худкор амалӣ карда мешавад.
/// Онро дар заминаи умумӣ, ҳатто бидуни ҳудуди мувофиқ татбиқ кардан мумкин аст.
///
/// # Usage
///
/// Нишондиҳандаҳои хомро бо усули [`to_raw_parts`] ба суроғаи маълумот ва ҷузъҳои метамаълумот ҷудо кардан мумкин аст.
///
/// Интихобан, танҳо метамаълумотро бо функсияи [`metadata`] баровардан мумкин аст.
/// Истинод ба [`metadata`] гузаронида шуда, ба таври маҷбурӣ маҷбур карда мешавад.
///
/// Нишондиҳандаи (possibly-wide) метавонад аз суроға ва метамаълумоти худ бо [`from_raw_parts`] ё [`from_raw_parts_mut`] якҷоя карда шавад.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Намуди метамаълумот дар нишоннамоҳо ва истинодҳо ба `Self`.
    #[lang = "metadata_type"]
    // NOTE: trait bounds-ро дар `static_assert_expected_bounds_for_metadata` нигоҳ доред
    //
    // дар `library/core/src/ptr/metadata.rs` ҳамоҳанг бо онҳое, ки дар ин ҷо ҳастанд:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Нишондиҳандаҳо ба намудҳои татбиқи ин тахаллуси trait "тунук" мебошанд.
///
/// Ин намудҳои статикӣ-Size ва намудҳои `extern`-ро дар бар мегирад.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: пеш аз он ки тахаллусҳои trait дар забон устувор бошанд, инро устувор накунед?
pub trait Thin = Pointee<Metadata = ()>;

/// Қисмати метамаълумоти нишоннаморо берун кунед.
///
/// Арзишҳои навъи `*mut T`, `&T` ё `&mut T` метавонанд бевосита ба ин вазифа интиқол дода шаванд, зеро онҳо ба таври мустақим ба `* const T` маҷбур мешаванд.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // БЕХАТАР: : Дастрасӣ ба арзиш аз иттифоқи `PtrRepr` аз * const T бехатар аст
    // ва PtrComponents<T>ҳамон тарҳҳои хотираро доранд.
    // Ин кафолатро танҳо std дода метавонад.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Нишондиҳандаи (possibly-wide)-ро аз суроғаи маълумот ва метамаълумот ташаккул медиҳад.
///
/// Ин функсия бехатар аст, аммо нишоннамои баргардондашуда ҳатман барои қатъкунӣ бехатар нест.
/// Барои иловаро, ба ҳуҷҷатҳои [`slice::from_raw_parts`] оид ба талаботи бехатарӣ нигаред.
/// Барои объектҳои trait, метамаълумот бояд аз нишоннамо ба ҳамон навъи зеркардашудаи аслӣ ояд.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // БЕХАТАР: : Дастрасӣ ба арзиш аз иттифоқи `PtrRepr` аз * const T бехатар аст
    // ва PtrComponents<T>ҳамон тарҳҳои хотираро доранд.
    // Ин кафолатро танҳо std дода метавонад.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Ҳамон функсияеро бо [`from_raw_parts`] иҷро мекунад, ба истиснои он, ки нишоннамои `*mut` хом баргардонида мешавад, бар хилофи нишонаи `* const` хом.
///
///
/// Барои тафсилоти бештар ба ҳуҷҷатҳои [`from_raw_parts`] нигаред.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // БЕХАТАР: : Дастрасӣ ба арзиш аз иттифоқи `PtrRepr` аз * const T бехатар аст
    // ва PtrComponents<T>ҳамон тарҳҳои хотираро доранд.
    // Ин кафолатро танҳо std дода метавонад.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Нишондиҳии дастӣ барои пешгирӣ аз бастани `T: Copy` лозим аст.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Нишондиҳии дастӣ барои пешгирӣ аз бастани `T: Clone` лозим аст.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Метамаълумот барои намуди объекти `Dyn = dyn SomeTrait` trait.
///
/// Ин нишоннамои vtable аст (ҷадвали занги маҷозӣ), ки тамоми маълумоти заруриро барои идоракунии навъи бетони дар дохили объекти trait ҳифзшаванда ифода мекунад.
/// Дар vtable аз ҷумла иборат аст аз:
///
/// * андозаи навъ
/// * ҳамоҳангсозии навъи
/// * нишоннамо ба имкони навъи `drop_in_place` (метавонад барои маълумоти оддӣ-сола ғайриимкон бошад)
/// * ишора ба ҳамаи усулҳои татбиқи навъи trait
///
/// Дар хотир доред, ки сеюми аввал махсусанд, зеро онҳо барои ҷудо кардан, партофтан ва ҷудо кардани ягон объекти trait заруранд.
///
/// Ин структураро бо параметри навъи номгузорӣ кардан мумкин аст, ки объекти `dyn` trait набошад (масалан `DynMetadata<u64>`), аммо арзиши пурмазмуни ин структураро ба даст наовардан мумкин аст.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Префикси умумии ҳамаи vtables.Пас аз он нишондиҳандаҳои функсия барои усулҳои trait гузошта мешаванд.
///
/// Тафсилоти татбиқи хусусии `DynMetadata::size_of` ва ғайра.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Андозаи намуди бо ин vtable алоқамандро бармегардонад.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Ҳамоҳангсозии намуди бо ин vtable алоқамандро бармегардонад.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Ҳаҷм ва масирро ҳамчун `Layout` бармегардонад
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // БЕХАТАР: : компилятор ин втебро барои навъи бетонии Rust баровардааст, ки
        // маълум аст, ки тарҳбандии дуруст дорад.Ҳамон асоснокӣ, ки дар `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Тарҷумаҳои дастӣ барои пешгирӣ аз ҳудуди `Dyn: $Trait` лозиманд.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}