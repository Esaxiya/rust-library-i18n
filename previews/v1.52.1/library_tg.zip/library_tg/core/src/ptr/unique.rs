use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Печонанда дар атрофи `*mut T`-и хом ғайримуқаррарӣ, ки нишон медиҳад, ки соҳиби ин печонанда референт дорад.
/// Барои сохтани абстраксияҳо ба монанди `Box<T>`, `Vec<T>`, `String` ва `HashMap<K, V>` муфид аст.
///
/// Баръакси `*mut T`, `Unique<T>` рафтори "as if" он як мисоли `T` буд.
/// Он `Send`/`Sync`-ро амалӣ мекунад, агар `T` `Send`/`Sync` бошад.
/// Он инчунин як намуди кафолатҳои тахаллусии қавии як мисоли `T`-ро дар назар дорад:
/// референти нишоннамо набояд бидуни роҳи беназир ба соҳиби Unique тағир дода шавад.
///
/// Агар шумо намедонед, ки оё истифодаи `Unique` барои мақсадҳои худ дуруст аст ё не, истифодаи `NonNull`-ро, ки семантикаи заифтар дорад, баррасӣ кунед.
///
///
/// Баръакси `*mut T`, нишондиҳанда бояд ҳамеша нул бошад, ҳатто агар нишондиҳанда ҳеҷ гоҳ истинод карда нашавад.
/// Ин барои он аст, ки энумҳо ин арзиши манъшударо ҳамчун дискриминант истифода баранд-`Option<Unique<T>>` андозаи баробари `Unique<T>` дорад.
/// Аммо, агар нишон дода нашуда бошад, нишондиҳанда метавонад боз ҳам сусттар шавад.
///
/// Баръакси `*mut T`, `Unique<T>` аз `T` коварӣ аст.
/// Ин бояд ҳамеша барои ҳар навъе, ки талаботи тахаллуси Unique-ро дастгирӣ мекунад, дуруст бошад.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ин нишондиҳанда барои ихтилоф оқибате надорад, аммо зарур аст
    // барои dropck фаҳманд, ки мо мантиқан як `T` дорем.
    //
    // Барои тафсилот, нигаред:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` Нишондиҳандаҳо `Send` мебошанд, агар `T` `Send` бошад, зеро маълумотҳое, ки онҳо истинод мекунанд, бетарафанд.
/// Дар хотир доред, ки инварианти тахаллус бо системаи тип иҷро карда намешавад;абстраксия бо истифодаи `Unique` бояд онро иҷро кунад.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` Нишондиҳандаҳо `Sync` мебошанд, агар `T` `Sync` бошад, зеро маълумотҳое, ки онҳо истинод мекунанд, бетарафанд.
/// Дар хотир доред, ки инварианти тахаллус бо системаи тип иҷро карда намешавад;абстраксия бо истифодаи `Unique` бояд онро иҷро кунад.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// `Unique` наверо месозад, ки овезон аст, аммо хуб мутобиқат мекунад.
    ///
    /// Ин барои оғози навъҳое, ки бо танбалӣ ҷудо мекунанд, ба монанди `Vec::new` муфид аст.
    ///
    /// Дар хотир доред, ки арзиши ишоракунанда метавонад эҳтимолан як нишоннамои дурустро ба `T` нишон диҳад, яъне ин маънои онро надорад, ки ҳамчун посбон "not yet initialized" истифода бурда нашавад.
    /// Намудҳое, ки танбалона ҷудо мекунанд, бояд ибтидоиро бо ягон роҳи дигар пайгирӣ кунанд.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // БЕХАТАР: : mem::align_of() нишоннамои дуруст ва ғайривоқеъро бар мегардонад.Дар
        // шартҳо барои занг задан ба new_unchecked() эҳтиром карда мешаванд.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` нав месозад.
    ///
    /// # Safety
    ///
    /// `ptr` бояд нул бошад.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `ptr` ночиз аст.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Агар `ptr` нул бошад, `Unique` нав эҷод мекунад.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // БЕХАТАР: : Нишондиҳанда аллакай санҷида шудааст ва холӣ нест.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Нишондиҳандаи асосии `*mut`-ро ба даст меорад.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Мазмунро таҳрир кунед.
    ///
    /// Ҳаёти бадастомада ба худ вобаста аст, бинобар ин "as if" рафтор мекунад, ки ин дарвоқеъ як T буд, ки қарз гирифта истодааст.
    /// Агар умри дарозтари (unbound) лозим шавад, `&*my_ptr.as_ptr()`-ро истифода баред.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истинод.
        unsafe { &*self.as_ptr() }
    }

    /// Мутаассифона мундариҷаро рад мекунад.
    ///
    /// Ҳаёти бадастомада ба худ вобаста аст, бинобар ин "as if" рафтор мекунад, ки ин дарвоқеъ як T буд, ки қарз гирифта истодааст.
    /// Агар умри дарозтари (unbound) лозим шавад, `&mut *my_ptr.as_ptr()`-ро истифода баред.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` ба ҳама
        // талабот барои истиноди тағйирёбанда.
        unsafe { &mut *self.as_ptr() }
    }

    /// Ба нишоннамои навъи дигар мепартояд.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // БЕХАТАР: : Unique::new_unchecked() беназир ва ниёзҳои навро эҷод мекунад
        // нишоннамои додашуда бекор набошад.
        // Азбаски мо худро ҳамчун нишондиҳанда мегузаронем, он наметавонад нул бошад.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // БЕХАТАР reference: Истиноди тағирёбанда наметавонад бекор бошад
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}