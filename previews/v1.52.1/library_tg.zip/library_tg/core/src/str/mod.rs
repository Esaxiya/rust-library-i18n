//! Дастгирии сатр.
//!
//! Барои тафсилоти бештар, ба модули [`std::str`] нигаред.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. берун аз ҳудуд
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. сар <=охири
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ҳудуди аломатҳо
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // аломатро ёбед
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` бояд камтар аз лен ва ҳудуди чар бошад
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Дарозии `self`-ро бармегардонад.
    ///
    /// Ин дарозӣ бо байт аст, на [`char`] s ё графема.
    /// Ба ибораи дигар, шояд он чизе набошад, ки инсон дарозии сатрро баррасӣ мекунад.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // f мепиндоред!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true`-ро бармегардонад, агар `self` дарозии сифр байт дошта бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Тафтиш мекунад, ки "индекс`-байт байти аввали пайдарпайии нуқтаи рамзи UTF-8 ё охири сатр аст.
    ///
    ///
    /// Оғоз ва охири сатр (вақте ки `index== self.len()`) ҳудуд ҳисобида мешавад.
    ///
    /// Бозмегардонад `false` агар `index` аз `self.len()` бузургтар аст.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // оғози `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // байти дуюми `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // байти сеюми `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ва лен ҳамеша хуб аст.
        // Барои 0 ба таври возеҳ санҷед, то ки он чекро ба осонӣ оптимизатсия кунад ва хондани маълумоти сатрро барои ин ҳолат гузарад.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Ин ба сеҳри ҷодугарӣ баробар аст: b <128 ||б>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Буридаи сатрро ба буридаи байтӣ табдил медиҳад.
    /// Барои баргардонидани буридаи байтӣ ба буридаи сатр, вазифаи [`from_utf8`]-ро истифода баред.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // Бехатарӣ: const const, зеро мо ду намуди онро бо як тарҳ интиқол медиҳем
        unsafe { mem::transmute(self) }
    }

    /// Буридаи сатри тағиршавандаро ба буридаи байтии тағиршаванда табдил медиҳад.
    ///
    /// # Safety
    ///
    /// Зангзан бояд кафолат диҳад, ки мундариҷаи бурида пеш аз ба охир расидани қарз ва истифодаи `str` асоси UTF-8 эътибор дорад.
    ///
    ///
    /// Истифодаи `str`, ки мундариҷааш UTF-8 мӯътабар нест, рафтори номуайян аст.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // БЕХАТАР: : рехтагарӣ аз `&str` ба `&[u8]` аз `str` бехатар аст
        // дорои ҳамон тарҳ бо `&[u8]` аст (танҳо libstd метавонад ин кафолатро диҳад).
        // Фарқияти нишондиҳанда бехатар аст, зеро он аз истиноди тағирёбанда ба даст омадааст, ки барои навиштан эътибор дорад.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Буридаи сатрро ба нишоннамои хом табдил медиҳад.
    ///
    /// Азбаски иловаро сатр як буридаи байт аст, нишоннамои хом ба [`u8`] ишора мекунад.
    /// Ин нишоннамо ба байти якуми буридаи сатр ишора мекунад.
    ///
    /// Зангзан бояд кафолат диҳад, ки нишоннамои баргашта ҳеҷ гоҳ ба навиштаҷот навишта намешавад.
    /// Агар ба шумо mutate мундариҷаи буридаи сатр лозим бошад, [`as_mut_ptr`]-ро истифода баред.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Буридаи сатри тағиршавандаро ба нишоннамои хом табдил медиҳад.
    ///
    /// Азбаски иловаро сатр як буридаи байт аст, нишоннамои хом ба [`u8`] ишора мекунад.
    /// Ин нишоннамо ба байти якуми буридаи сатр ишора мекунад.
    ///
    /// Ин масъулияти шумост, ки боварӣ ҳосил кунед, ки буридаи сатр танҳо ба тарзе тағир дода мешавад, ки он боқӣ мемонад UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Бозгашти `str` бармегардад.
    ///
    /// Ин алтернативаи ғайри ваҳм барои индексатсияи `str` аст.
    /// [`None`]-ро ҳар вақте бармегардонад, ки амалиёти индексатсияи эквиваленти panic бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // нишондиҳандаҳо на дар сарҳади пайдарпаии UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // берун аз ҳудуд
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Бозгашти тағирёбандаи `str`-ро бармегардонад.
    ///
    /// Ин алтернативаи ғайри ваҳм барои индексатсияи `str` аст.
    /// [`None`]-ро ҳар вақте бармегардонад, ки амалиёти индексатсияи эквиваленти panic бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // дарозии дуруст
    /// assert!(v.get_mut(0..5).is_some());
    /// // берун аз ҳудуд
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Бозмегузаронидашудаи `str`-ро бармегардонад.
    ///
    /// Ин алтернативаи носанҷида ба индексатсияи `str` мебошад.
    ///
    /// # Safety
    ///
    /// Занггарони ин вазифа масъуланд, ки ин шартҳои пешакӣ иҷро карда шаванд:
    ///
    /// * Индекси оғоз набояд аз индекси интиҳо зиёд бошад;
    /// * Индексҳо бояд дар ҳудуди буридаи аслӣ бошанд;
    /// * Индексҳо бояд дар ҳудуди пайдарпаии UTF-8 бошанд.
    ///
    /// Дар сурати иҷро нашудани ин, буридаи сатри баргашта метавонад ба хотираи беэътибор ишора кунад ё инвариантҳои бо навъи `str` ирсолшударо вайрон кунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `get_unchecked` риоя кунад;
        // буридаи dereferencable аст, зеро `self` истиноди бехатар аст.
        // Нишондиҳандаи баргашташуда бехатар аст, зеро имплҳои `SliceIndex` бояд кафолат диҳанд, ки ин аст.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Бозмегардонад, ки тағирёбанда ва носанҷидашудаи `str` бошад.
    ///
    /// Ин алтернативаи носанҷида ба индексатсияи `str` мебошад.
    ///
    /// # Safety
    ///
    /// Занггарони ин вазифа масъуланд, ки ин шартҳои пешакӣ иҷро карда шаванд:
    ///
    /// * Индекси оғоз набояд аз индекси интиҳо зиёд бошад;
    /// * Индексҳо бояд дар ҳудуди буридаи аслӣ бошанд;
    /// * Индексҳо бояд дар ҳудуди пайдарпаии UTF-8 бошанд.
    ///
    /// Дар сурати иҷро нашудани ин, буридаи сатри баргашта метавонад ба хотираи беэътибор ишора кунад ё инвариантҳои бо навъи `str` ирсолшударо вайрон кунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `get_unchecked_mut` риоя кунад;
        // буридаи dereferencable аст, зеро `self` истиноди бехатар аст.
        // Нишондиҳандаи баргашташуда бехатар аст, зеро имплҳои `SliceIndex` бояд кафолат диҳанд, ки ин аст.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Як буридаи сатрро аз буридаи сатрии дигар мегузарад ва аз санҷишҳои бехатарӣ нагузарад.
    ///
    /// Ин одатан тавсия дода намешавад, бо эҳтиёт истифода баред!Барои алтернативаи бехатар ба [`str`] ва [`Index`] нигаред.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ин буридаи нав аз `begin` ба `end` мегузарад, аз ҷумла `begin`, аммо ба истиснои `end`.
    ///
    /// Барои гирифтани як буридаи сатри тағиршаванда, ба усули [`slice_mut_unchecked`] нигаред.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Занггарони ин вазифа масъуланд, ки се шарти пешакӣ иҷро карда шаванд:
    ///
    /// * `begin` набояд аз `end` зиёд бошад.
    /// * `begin` ва `end` бояд дар байти сатр мавқеъҳои байтӣ бошанд.
    /// * `begin` ва `end` бояд дар марзҳои пайдарпаии UTF-8 дурӯғ гӯянд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `get_unchecked` риоя кунад;
        // буридаи dereferencable аст, зеро `self` истиноди бехатар аст.
        // Нишондиҳандаи баргашташуда бехатар аст, зеро имплҳои `SliceIndex` бояд кафолат диҳанд, ки ин аст.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Як буридаи сатрро аз буридаи сатрии дигар мегузарад ва аз санҷишҳои бехатарӣ нагузарад.
    /// Ин одатан тавсия дода намешавад, бо эҳтиёт истифода баред!Барои алтернативаи бехатар ба [`str`] ва [`IndexMut`] нигаред.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ин буридаи нав аз `begin` ба `end` мегузарад, аз ҷумла `begin`, аммо ба истиснои `end`.
    ///
    /// Барои гирифтани як буридаи сатри тағирнашаванда, ба усули [`slice_unchecked`] нигаред.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Занггарони ин вазифа масъуланд, ки се шарти пешакӣ иҷро карда шаванд:
    ///
    /// * `begin` набояд аз `end` зиёд бошад.
    /// * `begin` ва `end` бояд дар байти сатр мавқеъҳои байтӣ бошанд.
    /// * `begin` ва `end` бояд дар марзҳои пайдарпаии UTF-8 дурӯғ гӯянд.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `get_unchecked_mut` риоя кунад;
        // буридаи dereferencable аст, зеро `self` истиноди бехатар аст.
        // Нишондиҳандаи баргашташуда бехатар аст, зеро имплҳои `SliceIndex` бояд кафолат диҳанд, ки ин аст.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Ҳангоми индекс як буридаи сатрро ба ду тақсим кунед.
    ///
    /// Далели `mid`, бояд аз оғози сатр ҷубронкунандаи байт бошад.
    /// Он ҳамчунин бояд дар сарҳади нуқтаи рамзи UTF-8 бошад.
    ///
    /// Ду буридаи баргашта аз оғози буридаи сатр ба `mid` ва аз `mid` то охири буридаи сатр мегузаранд.
    ///
    /// Барои ба даст овардани иловаро сатри тағиршаванда, ба усули [`split_at_mut`] нигаред.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics агар `mid` дар сарҳади нуқтаи рамзи UTF-8 набошад, ё агар он аз охири нуқтаи рамзи охирини буридаи сатр гузашта бошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary месанҷад, ки индекс дар [0, .len()]
        if self.is_char_boundary(mid) {
            // БЕХАТАР: : танҳо тафтиш кард, ки `mid` дар сарҳади char қарор дорад.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ҳангоми индекс як буридаи сатри тағиршавандаро ба ду тақсим кунед.
    ///
    /// Далели `mid`, бояд аз оғози сатр ҷубронкунандаи байт бошад.
    /// Он ҳамчунин бояд дар сарҳади нуқтаи рамзи UTF-8 бошад.
    ///
    /// Ду буридаи баргашта аз оғози буридаи сатр ба `mid` ва аз `mid` то охири буридаи сатр мегузаранд.
    ///
    /// Барои ба даст овардани иловаро сатри тағирнашаванда, ба усули [`split_at`] нигаред.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics агар `mid` дар сарҳади нуқтаи рамзи UTF-8 набошад, ё агар он аз охири нуқтаи рамзи охирини буридаи сатр гузашта бошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary месанҷад, ки индекс дар [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // БЕХАТАР: : танҳо тафтиш кард, ки `mid` дар сарҳади char қарор дорад.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Итераторро бар [`char`]-и буридаи сатр бармегардонад.
    ///
    /// Азбаски буридаи сатрӣ аз UTF-8 эътибор иборат аст, мо метавонем тавассути буридаи сатрӣ бо [`char`] такрор кунем.
    /// Ин усул чунин такроркунандаро бармегардонад.
    ///
    /// Дар хотир доштан муҳим аст, ки [`char`] арзиши скалярии юникодро ифода мекунад ва метавонад ба фикри шумо дар бораи он, ки 'character' чӣ гуна аст, мувофиқат накунад.
    ///
    /// Такрори гурӯҳҳои графикӣ метавонад он чизе бошад, ки шумо воқеан мехоҳед.
    /// Ин функсияро китобхонаи стандартии Rust таъмин намекунад, ба ҷои crates.io санҷед.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Дар хотир доред, ки [`char`] метавонад ба ҳисси шумо дар бораи аломатҳо мувофиқат накунад:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // на 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Итераторро бар [`char`]-и буридаи сатр ва ҷойгоҳҳои онҳоро бар мегардонад.
    ///
    /// Азбаски буридаи сатрӣ аз UTF-8 эътибор иборат аст, мо метавонем тавассути буридаи сатрӣ бо [`char`] такрор кунем.
    /// Ин усул итератори ҳардуи ин [`char`] ва инчунин мавқеъҳои байтии онҳоро бар мегардонад.
    ///
    /// Итератори кортҳо медиҳад.Мавқеъ аввал, [`char`] дуюм аст.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Дар хотир доред, ки [`char`] метавонад ба ҳисси шумо дар бораи аломатҳо мувофиқат накунад:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // не (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 3-ро дар инҷо қайд кунед, аломати охирин ду байт гирифт
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Итератор бар байтҳои як буридаи сатр.
    ///
    /// Азбаски буридаи сатрӣ аз пайдарпаии байт иборат аст, мо метавонем тавассути буридаи сатр ба байт такрор кунем.
    /// Ин усул чунин такроркунандаро бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Як буридаи сатрро тавассути фазои сафед тақсим мекунад.
    ///
    /// Итератори баргашта буришҳои сатриро, ки зергурӯҳҳои буридаи сатрии аслӣ мебошанд ва бо ҳар миқдори фазо ҷудо карда мешаванд, бармегардонад.
    ///
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    /// Агар шумо хоҳед, ки ба ҷои танҳо дар фазои сафедии ASCII тақсим шавед, [`split_ascii_whitespace`]-ро истифода баред.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ҳама намудҳои фазои сафед ҳисобида мешаванд:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Буридаи сатрро аз фазои сафедии ASCII тақсим мекунад.
    ///
    /// Итератори баргашта буррҳои сатрро, ки зергурӯҳҳои буридаи сатр мебошанд, бо ҳар миқдори фазои сафедии ASCII ҷудо мекунанд, бармегардонад.
    ///
    ///
    /// Барои тақсим кардан ба ҷои Unicode `Whitespace`, [`split_whitespace`]-ро истифода баред.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Ҳама намудҳои фазои сафедии ASCII ба назар гирифта мешаванд:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Итератор дар болои сатрҳои сатр, ҳамчун иловаро сатр.
    ///
    /// Хатҳо бо хатти (`\n`) нав ё баргаштани вагон бо хати хати (`\r\n`) ба итмом мерасанд.
    ///
    /// Анҷоми хатти ниҳоӣ ихтиёрӣ аст.
    /// Сатре, ки бо хатти ниҳоии хатм ба анҷом мерасад, ҳамон сатрҳоро ҳамчун сатри дигаре, ки хатти ниҳоӣ надорад, бармегардонад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Анҷоми хатти ниҳоӣ талаб карда намешавад:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Такрори бар хатҳои сатр.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Итератори `u16`-ро бар сатри рамзи UTF-16 бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// `true`-ро бармегардонад, агар намунаи додашуда бо зергурӯҳи ин буридаи сатр мувофиқат кунад.
    ///
    /// `false`-ро бармегардонад, агар ин тавр набошад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// `true`-ро бармегардонад, агар намунаи додашуда бо префикси ин буридаи сатр мувофиқат кунад.
    ///
    /// `false`-ро бармегардонад, агар ин тавр набошад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// `true`-ро бармегардонад, агар намунаи додашуда бо суффикси ин буридаи сатр мувофиқат кунад.
    ///
    /// `false`-ро бармегардонад, агар ин тавр набошад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Индекси байти аломати якуми ин буридаи сатрро, ки бо шабеҳ мувофиқат мекунад, бармегардонад.
    ///
    /// Агар намуна мувофиқат накунад, [`None`] бармегардад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Намунаҳои мураккабтаре, ки бо услуб ва пӯшишҳои бидуни нуқта истифода мешаванд:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Намунаи ёфт нашуд:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Индекси байтро барои аломати якуми росттарин мувофиқати намуна дар ин буридаи сатр бармегардонад.
    ///
    /// Агар намуна мувофиқат накунад, [`None`] бармегардад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Намунаҳои мураккабтари пӯшидаҳо:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Намунаи ёфт нашуд:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Итератор аз болои сатрҳои ин буридаи сатр, ки бо аломатҳои бо намуна мувофиқ ҷудо карда шудааст.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта [`DoubleEndedIterator`] хоҳад буд, агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад ва ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    /// Ин барои масалан, [`char`] дуруст аст, аммо на барои `&str`.
    ///
    /// Агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад, аммо натиҷаҳои он метавонанд аз ҷустуҷӯи пеш фарқ кунанд, усули [`rsplit`] метавонад истифода шавад.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Агар намуна буридаи чархҳо бошад, дар ҳар як пайдоиши ягон аломат тақсим кунед:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Агар сатр дорои якчанд ҷудосози ҳамҷоя бошад, шумо дар натиҷа сатрҳои холӣ хоҳед дошт:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Сепараторҳои ҳамсояро сатри холӣ ҷудо мекунад.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ҷудосозонро дар оғоз ё охири сатр сатрҳои холӣ ҳамсоя мекунанд.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Вақте ки сатри холӣ ҳамчун ҷудосоз истифода мешавад, он ҳар як аломати сатрро дар якҷоягӣ бо аввал ва охири сатр ҷудо мекунад.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Вақте ки фазои сафед ҳамчун ҷудосоз истифода мешавад, ҷудосозони ҳамҷоя метавонанд ба рафтори эҳтимолан тааҷҷубовар оварда расонанд.Ин рамз дуруст аст:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Он ба шумо _not_ медиҳад:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Барои ин рафтор [`split_whitespace`]-ро истифода баред.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Итератор аз болои сатрҳои ин буридаи сатр, ки бо аломатҳои бо намуна мувофиқ ҷудо карда шудааст.
    /// Аз итераторе, ки `split` истеҳсол мекунад, фарқ мекунад, ки дар он `split_inclusive` қисми мувофиқшударо ҳамчун терминатори зерсатр боқӣ мегузорад.
    ///
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Агар унсури охирини сатр мувофиқат кунад, он элемент терминатори зерсатри қаблӣ ҳисобида мешавад.
    /// Ин сатр охирин ҷузъи баргардонидашуда хоҳад буд.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Итератор аз болои сатрҳои буридаи сатрии додашуда, ки бо аломатҳое ҷудо карда шудаанд ва бо тартиби баръакс ҳосил шудаанд.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта талаб мекунад, ки намуна ҷустуҷӯи баръаксро дастгирӣ кунад ва он [`DoubleEndedIterator`] хоҳад буд, агар ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    ///
    ///
    /// Барои такрори аз пеш методи [`split`] истифода бурдан мумкин аст.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Итератор аз болои сатрҳои буридаи сатрии додашуда, бо аломатҳое ҷудо карда шудааст, ки бо намуна мувофиқат мекунанд.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ба [`split`] баробар аст, ба истиснои он, ки сатри ақрабаки холӣ гузаронида мешавад.
    ///
    /// [`split`]: str::split
    ///
    /// Ин усул метавонад барои маълумоти сатр истифода шавад, ки _terminated_ бошад, на _separated_ бо намуна.
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта [`DoubleEndedIterator`] хоҳад буд, агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад ва ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    /// Ин барои масалан, [`char`] дуруст аст, аммо на барои `&str`.
    ///
    /// Агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад, аммо натиҷаҳои он метавонанд аз ҷустуҷӯи пеш фарқ кунанд, усули [`rsplit_terminator`] метавонад истифода шавад.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Итератор аз болои сатрҳои `self`, бо аломатҳое ҷудо карда шудааст, ки бо намуна мувофиқат мекунанд ва бо тартиби баръакс натиҷа медиҳанд.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ба [`split`] баробар аст, ба истиснои он, ки сатри ақрабаки холӣ гузаронида мешавад.
    ///
    /// [`split`]: str::split
    ///
    /// Ин усул метавонад барои маълумоти сатр истифода шавад, ки _terminated_ бошад, на _separated_ бо намуна.
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта талаб мекунад, ки намуна ҷустуҷӯи баръаксро дастгирӣ кунад ва агар ҷустуҷӯи forward/reverse ҳамон унсурҳоро ба даст оварад, он дучанд мешавад.
    ///
    ///
    /// Барои такрори аз пеш методи [`split_terminator`] истифода бурдан мумкин аст.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Итератор аз болои сатрҳои буридаи сатрии додашуда, ки бо намуна ҷудо карда шудаанд, барои баргардонидани ҳадди аксар ашёи `n` маҳдуд аст.
    ///
    /// Агар сатрҳои `n` баргардонида шаванд, сатри охирин ("сатри n`th") боқимондаи сатрро дар бар мегирад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта дучанд намешавад, зеро дастгирӣ кардан самарабахш нест.
    ///
    /// Агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад, усули [`rsplitn`] метавонад истифода шавад.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Итератор аз болои сатрҳои ин буридаи сатр, ки бо намуна ҷудо карда шудааст, аз охири сатр сар карда, бо бозгашти ҳадди аксар ашёи `n` маҳдуд аст.
    ///
    ///
    /// Агар сатрҳои `n` баргардонида шаванд, сатри охирин ("сатри n`th") боқимондаи сатрро дар бар мегирад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта дучанд намешавад, зеро дастгирӣ кардан самарабахш нест.
    ///
    /// Барои тақсим аз пеш методи [`splitn`] метавонад истифода шавад.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Сатрро дар пайдоиши аввали ҷудошаванда тақсим мекунад ва префиксро пеш аз ҷудошаванда ва пасванди пас аз ҷудошударо бар мегардонад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Сатрро дар пайдоиши охирини ҷудошаванда тақсим мекунад ва префиксро пеш аз ҷудошаванда ва пасванди пас аз ҷудошударо бар мегардонад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Итератор бар гӯгирдҳои ҷудошудаи намуна дар доираи буридаи сатрии додашуда.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта [`DoubleEndedIterator`] хоҳад буд, агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад ва ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    /// Ин барои масалан, [`char`] дуруст аст, аммо на барои `&str`.
    ///
    /// Агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад, аммо натиҷаҳои он метавонанд аз ҷустуҷӯи пеш фарқ кунанд, усули [`rmatches`] метавонад истифода шавад.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Итератор бар гӯгирдҳои ҷудогардидаи намуна дар дохили ин буридаи сатр, бо тартиби баръакс натиҷа дод.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта талаб мекунад, ки намуна ҷустуҷӯи баръаксро дастгирӣ кунад ва он [`DoubleEndedIterator`] хоҳад буд, агар ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    ///
    ///
    /// Барои такрори аз пеш методи [`matches`] истифода бурдан мумкин аст.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Итератор бар гӯгирдҳои ҷудошудаи намуна дар дохили ин буридаи сатр ва инчунин нишондиҳандае, ки гӯгирд аз он оғоз меёбад.
    ///
    /// Барои бозиҳои `pat` дар `self`, ки бо ҳам мепайвандад, танҳо нишондиҳандаҳои ба бозии аввал мувофиқ баргардонида мешаванд.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта [`DoubleEndedIterator`] хоҳад буд, агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад ва ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    /// Ин барои масалан, [`char`] дуруст аст, аммо на барои `&str`.
    ///
    /// Агар намуна ба ҷустуҷӯи баръакс иҷозат диҳад, аммо натиҷаҳои он метавонанд аз ҷустуҷӯи пеш фарқ кунанд, усули [`rmatch_indices`] метавонад истифода шавад.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // танҳо аввалин `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Итератор бар гӯгирдҳои ҷудошудаи намуна дар доираи `self`, бо тартиби баръакс дар якҷоягӣ бо индекси мувофиқат ҳосил шуд.
    ///
    /// Барои бозиҳои `pat` дар `self`, ки бо ҳам мепайвандад, танҳо нишондиҳандаҳои ба бозии охирин мувофиқ баргардонида мешаванд.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Рафтори итератор
    ///
    /// Итератори баргашта талаб мекунад, ки намуна ҷустуҷӯи баръаксро дастгирӣ кунад ва он [`DoubleEndedIterator`] хоҳад буд, агар ҷустуҷӯи forward/reverse ҳамон унсурҳоро ҳосил кунад.
    ///
    ///
    /// Барои такрори аз пеш методи [`match_indices`] истифода бурдан мумкин аст.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // танҳо `aba` охирин
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Буридаи сатрро бо фосилаи пешрафта ва ақибгирифта бардошта бармегардонад.
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Буридаи сатрро бо фосилаи пешрафта хориҷшуда бармегардонад.
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// `start` дар ин замина маънои мавқеи аввали он сатри байтро дорад;барои забони чап аз рост ба мисли англисӣ ё русӣ, ин тарафи чап ва барои забонҳои аз чап ба чап, ба монанди арабӣ ё ибрӣ, ин тарафи рост хоҳад буд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Як буридаи сатрро бо фосилаи акибии хориҷшуда бармегардонад.
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// `end` дар ин замина маънои мавқеи охирини он сатри байтро дорад;барои забони чап аз рост ба монанди англисӣ ё русӣ, ин тарафи рост ва барои забонҳои аз чап ба чап, ба монанди арабӣ ё ибрӣ, он тарафи чап хоҳад буд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Буридаи сатрро бо фосилаи пешрафта хориҷшуда бармегардонад.
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// 'Left' дар ин замина маънои мавқеи аввали он сатри байтро дорад;барои забоне чун арабӣ ё ибронӣ, ки ба ҷои "чап ба рост", "рост ба чап" ҳастанд, ин тарафи _right_ хоҳад буд, на чап.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Як буридаи сатрро бо фосилаи акибии хориҷшуда бармегардонад.
    ///
    /// 'Whitespace' мувофиқи шартҳои Unicode Derived Core Property `White_Space` муайян карда мешавад.
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// 'Right' дар ин замина маънои мавқеи охирини он сатри байтро дорад;барои забоне чун арабӣ ё ибрӣ, ки на "аз чап ба рост", балки "рост ба чап" ҳастанд, ин тарафи _left_ хоҳад буд, на рост.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Буридаи сатрро бо тамоми префиксҳо ва суффиксҳое, ки бо намуна такроран хориҷ карда шудаанд, бармегардонад.
    ///
    /// [pattern] метавонад [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки мувофиқати як аломатро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Қадимтарин бозии маълумро ба хотир оред, агар онро дар зер ислоҳ кунед
            // бозии охирин фарқ мекунад
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕХАТАР: : `Searcher` маълум аст, ки индекси дурустро бармегардонад.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Буридаи сатрро бо ҳамаи префиксҳое, ки бо намуна такроран хориҷ карда шудаанд, бармегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// `start` дар ин замина маънои мавқеи аввали он сатри байтро дорад;барои забони чап аз рост ба мисли англисӣ ё русӣ, ин тарафи чап ва барои забонҳои аз чап ба чап, ба монанди арабӣ ё ибрӣ, ин тарафи рост хоҳад буд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // БЕХАТАР: : `Searcher` маълум аст, ки индекси дурустро бармегардонад.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Буридаи сатрро бо префикси хориҷшуда бармегардонад.
    ///
    /// Агар сатр бо намунаи `prefix` сар шавад, пас аз префикс, сатрро бо `Some` печонида бармегардонад.
    /// Баръакси `trim_start_matches`, ин усул префиксро маҳз як бор нест мекунад.
    ///
    /// Агар сатр аз `prefix` сар нашавад, `None` бар мегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Буридаи сатрро бо суффикси хориҷшуда бармегардонад.
    ///
    /// Агар сатр бо намунаи `suffix` хотима ёбад, сатрро пеш аз суффикси бо `Some` печондашуда бармегардонад.
    /// Баръакси `trim_end_matches`, ин усул пасвандро маҳз як бор нест мекунад.
    ///
    /// Агар сатр бо `suffix` тамом нашавад, `None` бар мегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Буридаи сатрро бо тамоми суффиксҳое, ки бо намуна такроран хориҷ карда шудаанд, бармегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// `end` дар ин замина маънои мавқеи охирини он сатри байтро дорад;барои забони чап аз рост ба монанди англисӣ ё русӣ, ин тарафи рост ва барои забонҳои аз чап ба чап, ба монанди арабӣ ё ибрӣ, он тарафи чап хоҳад буд.
    ///
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // БЕХАТАР: : `Searcher` маълум аст, ки индекси дурустро бармегардонад.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Буридаи сатрро бо ҳамаи префиксҳое, ки бо намуна такроран хориҷ карда шудаанд, бармегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// 'Left' дар ин замина маънои мавқеи аввали он сатри байтро дорад;барои забоне чун арабӣ ё ибронӣ, ки ба ҷои "чап ба рост", "рост ба чап" ҳастанд, ин тарафи _right_ хоҳад буд, на чап.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Буридаи сатрро бо тамоми суффиксҳое, ки бо намуна такроран хориҷ карда шудаанд, бармегардонад.
    ///
    /// [pattern] метавонад `&str`, [`char`], буридаи [`char`] s ё функсия ё басташавӣ бошад, ки аломатҳои мувофиқати онро муайян мекунад.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Роҳнамоии матн
    ///
    /// Сатр пайдарпайии байтҳо мебошад.
    /// 'Right' дар ин замина маънои мавқеи охирини он сатри байтро дорад;барои забоне чун арабӣ ё ибрӣ, ки на "аз чап ба рост", балки "рост ба чап" ҳастанд, ин тарафи _left_ хоҳад буд, на рост.
    ///
    ///
    /// # Examples
    ///
    /// Намунаҳои оддӣ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Намунаи мураккабтар бо истифода аз басташавӣ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Ин буридаи сатрро ба навъи дигар ҷудо мекунад.
    ///
    /// Азбаски `parse` хеле умумӣ аст, он метавонад бо хулосабарории намуд мушкилот пеш орад.
    /// Ҳамин тавр, `parse` яке аз чанд маротибаест, ки шумо синтаксисро бо муҳаббат бо номи 'turbofish' мебинед: `::<>`.
    ///
    /// Ин ба алгоритми хулоса кӯмак мекунад, ки мушаххас фаҳманд, ки кадом навъи онро таҳлил кардан мехоҳед.
    ///
    /// `parse` метавонад ба ҳар навъе, ки [`FromStr`] trait-ро татбиқ мекунад, ҷудо кунад.
    ///

    /// # Errors
    ///
    /// Агар XS [`Err`] баргардонида шавад, агар имконнопазирии ин буридаи сатр ба намуди дилхоҳ имконпазир бошад.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Истифодаи 'turbofish' ба ҷои шарҳи `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Натиҷа ҷудо карда нашудааст:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Санҷед, ки оё ҳамаи аломатҳои ин сатр дар ҳудуди ASCII мебошанд.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Мо метавонем ҳар як байтро ҳамчун аломат баррасӣ кунем: ҳамаи аломатҳои бисёрпайта бо байте оғоз мешаванд, ки дар доираи ascii нест, бинобар ин мо аллакай дар он ҷо истодаем.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Тафтиш мекунад, ки ду сатр бозии мувофиқ ба парвандаи ASCII мебошанд.
    ///
    /// Ҳамон тавре ки `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, аммо бидуни тақсим ва нусхабардории муваққатӣ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ин сатрро ба ҳарфҳои калони ASCII дар ҷои худ табдил медиҳад.
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави калон бе тағир додани арзиши мавҷуда, [`to_ascii_uppercase()`]-ро истифода баред.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // БЕХАТАР: : бехатар, зеро мо ду намуди онро бо як тарҳ интиқол медиҳем.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ин сатрро ба ҳарфи хурди ASCII дар ҷои худ табдил медиҳад.
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави хурд бидуни тағир додани арзиши мавҷуда, [`to_ascii_lowercase()`]-ро истифода баред.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // БЕХАТАР: : бехатар, зеро мо ду намуди онро бо як тарҳ интиқол медиҳем.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Итератореро, ки аз ҳар чарх дар `self` бо [`char::escape_debug`] халос мешавад, баргардонед.
    ///
    ///
    /// Note: танҳо рамзҳои рамзии васеъ, ки сатрро оғоз мекунанд, раҳо хоҳанд шуд.
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Итератореро, ки аз ҳар чарх дар `self` бо [`char::escape_default`] халос мешавад, баргардонед.
    ///
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Итератореро, ки аз ҳар чарх дар `self` бо [`char::escape_unicode`] халос мешавад, баргардонед.
    ///
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Str-и холиро месозад
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Str-и тағирёбандаи холиро месозад
    #[inline]
    fn default() -> Self {
        // БЕХАТАР: : сатри холӣ UTF-8 эътибор дорад.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Намуди номбаршуда, clonable fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // БЕХАТАР: : бехатар нест
        unsafe { from_utf8_unchecked(bytes) }
    };
}