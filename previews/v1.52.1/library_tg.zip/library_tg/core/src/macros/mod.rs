#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Вобаста аз нашри занг, ба `$crate::panic::panic_2015` ё `$crate::panic::panic_2021` васеъ мешавад.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Тасдиқ мекунад, ки ду ибора ба ҳамдигар баробаранд (бо истифодаи [`PartialEq`]).
///
/// Дар panic, ин макрос қиматҳои ифодаҳоро бо тасвири ислоҳи онҳо чоп мекунад.
///
///
/// Мисли [`assert!`], ин макро шакли дуюм низ дорад, ки дар он паёми фармоишии panic пешниҳод карда мешавад.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Дар reborrows поён қасдан мебошанд.
                    // Бе онҳо, ҷойи стек барои қарз ҳатто пеш аз муқоисаи арзишҳо оғоз карда мешавад ва ин ба сустшавии назаррас оварда мерасонад.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Дар reborrows поён қасдан мебошанд.
                    // Бе онҳо, ҷойи стек барои қарз ҳатто пеш аз муқоисаи арзишҳо оғоз карда мешавад ва ин ба сустшавии назаррас оварда мерасонад.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Тасдиқ мекунад, ки ду ибора ба ҳамдигар баробар нестанд (бо истифодаи [`PartialEq`]).
///
/// Дар panic, ин макрос қиматҳои ифодаҳоро бо тасвири ислоҳи онҳо чоп мекунад.
///
///
/// Мисли [`assert!`], ин макро шакли дуюм низ дорад, ки дар он паёми фармоишии panic пешниҳод карда мешавад.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Дар reborrows поён қасдан мебошанд.
                    // Бе онҳо, ҷойи стек барои қарз ҳатто пеш аз муқоисаи арзишҳо оғоз карда мешавад ва ин ба сустшавии назаррас оварда мерасонад.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Дар reborrows поён қасдан мебошанд.
                    // Бе онҳо, ҷойи стек барои қарз ҳатто пеш аз муқоисаи арзишҳо оғоз карда мешавад ва ин ба сустшавии назаррас оварда мерасонад.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Тасдиқ мекунад, ки ифодаи булӣ дар вақти корӣ `true` аст.
///
/// Ин макроиқтисодии [`panic!`]-ро даъват мекунад, агар ифодаи пешниҳодшударо ҳангоми кор ба `true` баҳогузорӣ карда натавонад.
///
/// Мисли [`assert!`], ин макро инчунин версияи дуввум дорад, ки дар он паёми фармоишии panic пешниҳод карда мешавад.
///
/// # Uses
///
/// Бар хилофи [`assert!`], изҳороти `debug_assert!` танҳо дар сохтани оптимизатсия бо нобаёнӣ фаъол карда мешаванд.
/// Сохтмони оптимизатсияшуда изҳороти `debug_assert!`-ро иҷро намекунад, агар `-C debug-assertions` ба тартибдиҳанда дода нашавад.
/// Ин `debug_assert!`-ро барои чекҳое муфид мекунад, ки барои сохтани озод хеле гарон ҳастанд, аммо ҳангоми таҳия муфиданд.
/// Натиҷаи васеъ кардани `debug_assert!` ҳамеша санҷида мешавад.
///
/// Изҳороти носанҷида ба барнома имкон медиҳад, ки дар ҳолати номувофиқ кор кунад, ки ин метавонад оқибатҳои ғайричашмдошт дошта бошад, аммо бехатариро ҷорӣ намекунад, ба шарте ки ин танҳо дар рамзи бехатар рӯй диҳад.
///
/// Арзиши иҷрои тасдиқҳо, дар маҷмӯъ, ба қадри кофӣ чен карда намешавад.
/// Иваз кардани [`assert!`] бо `debug_assert!` ҳамин тавр танҳо пас аз профилҳои мукаммал ташвиқ карда мешавад ва муҳимтар аз ҳама, танҳо дар рамзи бехатар!
///
/// # Examples
///
/// ```
/// // паёми panic барои ин тасдиқҳо арзиши сатри ифодаи додашуда мебошад.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // вазифаи хеле содда
/// debug_assert!(some_expensive_computation());
///
/// // бо паёми фармоишӣ тасдиқ кунед
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Таъкид мекунад, ки ду ибора ба ҳамдигар баробаранд.
///
/// Дар panic, ин макрос қиматҳои ифодаҳоро бо тасвири ислоҳи онҳо чоп мекунад.
///
/// Бар хилофи [`assert_eq!`], изҳороти `debug_assert_eq!` танҳо дар сохтани оптимизатсия бо нобаёнӣ фаъол карда мешаванд.
/// Сохтмони оптимизатсияшуда изҳороти `debug_assert_eq!`-ро иҷро намекунад, агар `-C debug-assertions` ба тартибдиҳанда дода нашавад.
/// Ин `debug_assert_eq!`-ро барои чекҳое муфид мекунад, ки барои сохтани озод хеле гарон ҳастанд, аммо ҳангоми таҳия муфиданд.
///
/// Натиҷаи васеъ кардани `debug_assert_eq!` ҳамеша санҷида мешавад.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Таъкид мекунад, ки ду ибора ба ҳамдигар баробар нестанд.
///
/// Дар panic, ин макрос қиматҳои ифодаҳоро бо тасвири ислоҳи онҳо чоп мекунад.
///
/// Бар хилофи [`assert_ne!`], изҳороти `debug_assert_ne!` танҳо дар сохтани оптимизатсия бо нобаёнӣ фаъол карда мешаванд.
/// Сохтмони оптимизатсияшуда изҳороти `debug_assert_ne!`-ро иҷро намекунад, агар `-C debug-assertions` ба тартибдиҳанда дода нашавад.
/// Ин `debug_assert_ne!`-ро барои чекҳое муфид мекунад, ки барои сохтани озод хеле гарон ҳастанд, аммо ҳангоми таҳия муфиданд.
///
/// Натиҷаи васеъ кардани `debug_assert_ne!` ҳамеша санҷида мешавад.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Бозмегардонад, ки оё ифодаи додашуда бо ягон нақшҳои додашуда мувофиқат мекунад.
///
/// Мисли дар ифодаи `match`, намуна метавонад ихтиёрӣ пас аз `if` ва ифодаи посбон, ки дастрасӣ ба номҳои бо намуна алоқамандро дорад, пайгирӣ карда шавад.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Натиҷаро мекушояд ё иштибоҳи онро паҳн мекунад.
///
/// Барои иваз кардани `try!` оператори `?` илова карда шуд ва ба ҷои он бояд истифода бурд.
/// Ғайр аз он, `try` калимаи ҳифзшуда дар Rust 2018 мебошад, аз ин рӯ, агар шумо онро истифода баред, шумо бояд [raw-identifier syntax][ris]-ро истифода баред: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ба [`Result`]-и додашуда мувофиқат мекунад.Дар сурати варианти `Ok`, ифода арзиши арзиши парпечшуда дорад.
///
/// Дар сурати варианти `Err`, он хатои ботиниро барқарор мекунад.Пас аз он `try!` бо истифодаи `From` табдилдиҳиро иҷро мекунад.
/// Ин табдилдиҳии автоматиро байни хатогиҳои махсус ва хатогиҳои бештар таъмин менамояд.
/// Пас аз он хатои натиҷа фавран баргардонида мешавад.
///
/// Азбаски бозгашти барвақтӣ, `try!` метавонад танҳо дар функсияҳое истифода шавад, ки [`Result`]-ро баргардонанд.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Усули афзалиятноки зуд баргардонидани Хатогиҳо
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Усули қаблии хатоҳои баргардонидани зуд
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Ин ба:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Маълумоти форматшударо ба буферӣ менависад.
///
/// Ин макро 'writer', сатри формат ва рӯйхати далелҳоро қабул мекунад.
/// Баҳсҳо мувофиқи сатри форматҳои муайян формат карда мешаванд ва натиҷа ба нависанда дода мешавад.
/// Нависанда метавонад бо усули `write_fmt` ягон арзиш дошта бошад;Умуман, ин аз татбиқи [`fmt::Write`] ё [`io::Write`] trait бармеояд.
/// Макрос ҳар ончи методи `write_fmt` бармегардонад;одатан [`fmt::Result`] ё [`io::Result`].
///
/// Барои маълумоти бештар дар бораи синтаксиси сатри формат ба [`std::fmt`] нигаред.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Модул метавонад ҳарду `std::fmt::Write` ва `std::io::Write`-ро ворид кунад ва ба объектҳои татбиқкунандаи `write!` занг занад, зеро объектҳо одатан ҳардуяшро иҷро намекунанд.
///
/// Аммо, модул бояд traits-и тахассусиро ворид кунад, то номҳои онҳо бо ҳам зид набошанд:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt-ро истифода мебарад
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt-ро истифода мебарад
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ин макро метавонад дар танзимоти `no_std` низ истифода шавад.
/// Дар сабти `no_std` шумо барои тафсилоти татбиқи ҷузъҳо масъул ҳастед.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Маълумоти форматшударо ба буфере нависед, ки хати нав илова карда шавад.
///
/// Дар ҳама платформаҳо, хати нав танҳо аломати (`\n`/`U+000A`) LINE FEED аст (ҳеҷ CARRIAGE RETURN (`\r`/`U+000D`) иловагӣ нест.
///
/// Барои маълумоти иловагӣ, ба [`write!`] нигаред.Барои маълумот дар бораи синтаксиси сатри формат, ба [`std::fmt`] нигаред.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Модул метавонад ҳарду `std::fmt::Write` ва `std::io::Write`-ро ворид кунад ва ба объектҳои татбиқкунандаи `write!` занг занад, зеро объектҳо одатан ҳардуяшро иҷро намекунанд.
/// Аммо, модул бояд traits-и тахассусиро ворид кунад, то номҳои онҳо бо ҳам зид набошанд:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt-ро истифода мебарад
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt-ро истифода мебарад
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Рамзи дастнорасро нишон медиҳад.
///
/// Ин ҳама вақт муфид аст, вақте ки тартибдиҳанда муайян карда наметавонад, ки баъзе кодҳо дастнорасанд.Барои намуна:
///
/// * Дастҳоро бо шароити муҳофиз мутобиқ кунед.
/// * Доиравӣ, ки ба таври динамикӣ қатъ мешавад.
/// * Итераторҳо, ки ба таври динамикӣ қатъ мешаванд.
///
/// Агар муайян кардани дастнорас будани код нодуруст исбот карда шавад, барнома фавран бо [`panic!`] қатъ мешавад.
///
/// Ҳамтои хатарноки ин макро функсияи [`unreachable_unchecked`] мебошад, ки дар сурати расидани код ба рафтори номуайян оварда мерасонад.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Ин ҳамеша [`panic!`] хоҳад буд.
///
/// # Examples
///
/// Бозии даста:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // тартиб додани хато, агар шарҳ дода шавад
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // яке аз бадтарин татбиқи x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Рамзи иҷронашударо бо тарсу ҳарос бо паёми "not implemented" нишон медиҳад.
///
/// Ин ба рамзи шумо имкон медиҳад, ки навъи санҷишро тафтиш кунад, ки дар сурати прототипӣ ё амалисозии trait, ки усулҳои сершумореро талаб мекунад, ки шумо истифодаи ҳамаи онҳоро ба нақша нагиред, муфид аст.
///
/// Фарқи байни `unimplemented!` ва [`todo!`] дар он аст, ки дар ҳоле, ки `todo!` нияти татбиқи функсияро дертар баён мекунад ва паём "not yet implemented" аст, `unimplemented!` чунин даъво намекунад.
/// Паёми он "not implemented" аст.
/// Инчунин баъзе IDEҳо "todo!"-Ро қайд мекунанд.
///
/// # Panics
///
/// Ин ҳамеша [`panic!`] хоҳад буд, зеро `unimplemented!` барои `panic!` танҳо як варақаи фаврӣ бо паёми собит ва мушаххас аст.
///
/// Мисли `panic!`, ин макро шакли дуввум барои намоиши арзишҳои фармоишӣ дорад.
///
/// # Examples
///
/// Бигӯед, ки мо trait `Foo` дорем:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Мо мехоҳем, ки `Foo`-ро барои 'MyStruct' татбиқ кунем, аммо бо ягон сабаб танҳо амалӣ кардани вазифаи `bar()` маъно дорад.
/// `baz()` ва `qux()` бояд дар татбиқи `Foo` муайян карда шаванд, аммо мо метавонем `unimplemented!`-ро дар таърифҳои худ истифода барем, то коди мо тартиб дода шавад.
///
/// Мо то ҳол мехоҳем, ки дар сурати ба даст овардани усулҳои иҷронашуда барномаи мо қатъ карда шавад.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Барои `baz` ба `MyStruct` маъное надорад, аз ин рӯ мо дар ин ҷо умуман мантиқ надорем.
/////
///         // Ин "thread 'main' panicked at 'not implemented'" нишон медиҳад.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Мо дар ин ҷо баъзе мантиқ дорем, Мо метавонем паёмеро ба иҷронашуда илова кунем!то ки беамалии худро нишон диҳем.
///         // Ин нишон медиҳад: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Рамзи нотамомро нишон медиҳад.
///
/// Ин метавонад муфид бошад, агар шумо прототип кунед ва танҳо мехоҳед, ки коди шуморо typecheck тафтиш кунад.
///
/// Фарқи байни [`unimplemented!`] ва `todo!` дар он аст, ки дар ҳоле, ки `todo!` нияти татбиқи функсияро дертар баён мекунад ва паём "not yet implemented" аст, `unimplemented!` чунин даъво намекунад.
/// Паёми он "not implemented" аст.
/// Инчунин баъзе IDEҳо "todo!"-Ро қайд мекунанд.
///
/// # Panics
///
/// Ин ҳамеша [`panic!`] хоҳад буд.
///
/// # Examples
///
/// Ин аст мисоли баъзе коди иҷрошаванда.Мо trait `Foo` дорем:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Мо мехоҳем, ки `Foo`-ро дар яке аз намудҳои худ татбиқ кунем, аммо инчунин мехоҳем аввал танҳо `bar()` кор кунем.Барои тартиб додани коди мо, мо бояд `baz()`-ро татбиқ кунем, бинобар ин мо метавонем `todo!`-ро истифода барем:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // татбиқ ба ин ҷо меравад
///     }
///
///     fn baz(&self) {
///         // биёед ҳоло аз татбиқи baz() хавотир нашавем
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // мо ҳатто baz()-ро истифода намебарем, аз ин рӯ хуб аст.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Таърифҳои макросҳои дарунсохт.
///
/// Аксари хосиятҳои макро (устуворӣ, аёнӣ ва ғ.) Аз коди сарчашма дар инҷо гирифта шудаанд, ба истиснои функсияҳои васеъ, макро вурудро ба натиҷа табдил медиҳанд, ин функсияҳоро компилятор таъмин мекунад.
///
///
pub(crate) mod builtin {

    /// Ҳангоми дучор омадан бо натиҷаи хатои додашуда маҷмӯаро ба вуҷуд меорад.
    ///
    /// Ин макро бояд вақте истифода шавад, ки crate стратегияи тартибдиҳии шартиро барои пешниҳоди паёмҳои хатогии беҳтар барои шароити хато истифода кунад.
    ///
    /// Ин шакли сатҳи компилятории [`panic!`] аст, аммо ҳангоми *тартиб* хато мебарорад, на дар вақти * иҷро.
    ///
    /// # Examples
    ///
    /// Ду чунин мисол макросҳо ва муҳити `#[cfg]` мебошанд.
    ///
    /// Агар макрос арзишҳои беэътиборро гузарад, хатои беҳтарини компиляторро паҳн кунед.
    /// Бе branch ниҳоӣ, тартибдиҳанда бо вуҷуди ин хатогие содир мекунад, аммо дар паёми хато ду қимати дуруст зикр намешавад.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Агар ягон яке аз хусусиятҳо мавҷуд набошад, хатогии компилятсияро фиристед.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Параметри дигар макросҳои форматкунии сатрро месозад.
    ///
    /// Ин макро бо роҳи гирифтани ҳарфҳои форматонӣ дорои `{}` барои ҳар як далели иловагии гузаронидашуда амал мекунад.
    /// `format_args!` параметрҳои иловагиро омода мекунад, то натиҷаро ҳамчун сатр тафсир кунад ва далелҳоро ба намуди ягона канонализатсия кунад.
    /// Ҳар гуна қимате, ки [`Display`] trait-ро татбиқ мекунад, метавонад ба `format_args!` интиқол дода шавад, инчунин ҳар гуна татбиқи [`Debug`] ба `{:?}` дар сатри форматкунӣ интиқол дода шавад.
    ///
    ///
    /// Ин макро арзиши навъи [`fmt::Arguments`]-ро истеҳсол мекунад.Ин қиматро ба макросҳои дохили [`std::fmt`] гузаронидан мумкин аст барои тағирдиҳии муфид.
    /// Ҳама макросҳои форматкунии дигар (["format!"], [`write!`], [`println!`], ва ғайра) тавассути ин максималӣ дода мешаванд.
    /// `format_args!`, бар хилофи макросҳои ҳосилшуда, тақсимоти теппаҳоро пешгирӣ мекунад.
    ///
    /// Шумо метавонед арзиши [`fmt::Arguments`]-ро, ки `format_args!` дар заминаҳои `Debug` ва `Display` бармегардонад, тавре ки дар поён дида мешавад, истифода баред.
    /// Мисол инчунин нишон медиҳад, ки формати `Debug` ва `Display` ба ҳамон чиз: сатри формати интерполятсия дар `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Барои маълумоти иловагӣ, ба ҳуҷҷатҳо дар [`std::fmt`] нигаред.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Ҳамон тавре ки `format_args`, аммо дар охир хати нав илова мекунад.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Дар вақти тартиб додан тағирёбандаи муҳити атрофро тафтиш мекунад.
    ///
    /// Ин макро то вақти тағирёбанда ба арзиши тағирёбандаи муҳити номбурда густариш дода мешавад ва ифодаи навъи `&'static str`-ро медиҳад.
    ///
    ///
    /// Агар тағирёбандаи муҳити атроф муайян карда нашуда бошад, пас хатогии тартиб дода мешавад.
    /// Барои содир накардани хатогии тартиб, ба ҷои макроиқтисодии [`option_env!`] истифода баред.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Шумо метавонед паёмро дар бораи хатогӣ бо додани сатр ҳамчун параметр дуюм танзим кунед:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Агар тағирёбандаи муҳити `documentation` муайян нашуда бошад, шумо хатогии зеринро ба даст меоред:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ихтиёрӣ тағирёбандаи муҳити атрофро дар вақти тартиб додан тафтиш мекунад.
    ///
    /// Агар дар вақти тартиб додан тағирёбандаи муҳити номӣ мавҷуд бошад, он ба ифодаи навъи `Option<&'static str>`, ки арзиши он `Some` аз тағирёбандаи муҳити атроф аст, васеъ мешавад.
    /// Агар тағирёбандаи муҳит мавҷуд набошад, пас ин ба `None` васеъ мешавад.
    /// Барои маълумоти бештар дар бораи ин навъи [`Option<T>`][Option] нигаред.
    ///
    /// Ҳангоми истифода аз ин макро, новобаста аз он ки тағирёбандаи муҳити атроф мавҷуд аст ё не, ҳеҷ гоҳ хатои вақт тартиб дода намешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Идентификаторҳоро ба як идентификатор муттаҳид мекунад.
    ///
    /// Ин макро ягон миқдори идентификаторҳои бо вергул ҷудошударо мегирад ва ҳамаи онҳоро ба як пайваст мекунад ва ифодае медиҳад, ки як идентификатори нав мебошад.
    /// Дар хотир доред, ки гигиена чунин мекунад, ки ин макро тағирёбандаҳои маҳаллиро ба даст оварда наметавонад.
    /// Инчунин, чун қоида, макросҳо танҳо дар ҳолат, изҳорот ё мавқеи ифода иҷозат дода мешаванд.
    /// Ин маънои онро дорад, ки ҳангоми истифодаи ин макро шумо метавонед ба тағирёбандаҳо, функсияҳо ё модулҳои мавҷуда ва ғайра истифода баред, шумо наметавонед навро бо он муайян кунед.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (нав, шавқовар, ном) { }//бо ин роҳ қобили истифода нест!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Литералҳоро ба як буридаи сатри статикӣ пайваст мекунад.
    ///
    /// Ин макро ҳар миқдори литалҳои бо вергул ҷудошударо мегирад ва ифодаи навъи `&'static str`-ро медиҳад, ки ҳамаи литалҳоро аз чап ба рост муттаҳид мекунад.
    ///
    ///
    /// Китобҳои бутун ва нуқтаи шинокунанда бо мақсади ҳамбастагӣ қатъ карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ба рақами сатр, ки он даъват шуда буд, васеъ мешавад.
    ///
    /// Бо [`column!`] ва [`file!`], ин макросҳо барои таҳиягарон дар бораи ҷойгиршавӣ дар дохили манбаъ маълумоти ислоҳиро пешниҳод мекунанд.
    ///
    /// Ифодаи васеъ навъи `u32` дорад ва 1 асос дорад, аз ин рӯ сатри аввал дар ҳар як файл ба 1, дуюм ба 2 ва ғайра арзёбӣ мешавад.
    /// Ин бо паёмҳои хатогии тартибдиҳандаҳои умумӣ ё муҳаррирони маъмул мувофиқат мекунад.
    /// Хатти баргашта *ҳатман* хатти худи даъвати `line!` нест, балки аввалин даъвати макро, ки то даъвати макрои `line!` мебарад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Рақами сутунро, ки он даъват карда шуда буд, васеъ мекунад.
    ///
    /// Бо [`line!`] ва [`file!`], ин макросҳо барои таҳиягарон дар бораи ҷойгиршавӣ дар дохили манбаъ маълумоти ислоҳиро пешниҳод мекунанд.
    ///
    /// Ифодаи васеъ навъи `u32` дорад ва 1 асос дорад, аз ин рӯ сутуни аввал дар ҳар сатр ба 1, дуюм ба 2 ва ғайра арзёбӣ мешавад.
    /// Ин бо паёмҳои хатогии тартибдиҳандаҳои умумӣ ё муҳаррирони маъмул мувофиқат мекунад.
    /// Сутуни баргашта *ҳатман* хатти худи даъвати `column!` нест, балки аввалин даъвати макро, ки то даъвати макрои `column!` мебарад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Номи файлеро, ки дар он оварда шудааст, васеъ мекунад.
    ///
    /// Бо [`line!`] ва [`column!`], ин макросҳо барои таҳиягарон дар бораи ҷойгиршавӣ дар дохили манбаъ маълумоти ислоҳиро пешниҳод мекунанд.
    ///
    /// Ифодаи васеъ навъи `&'static str` дорад ва файли баргашта ин даъвати худи макроиқи `file!` нест, балки аввалин даъвати макро, ки ба даъвати макрои `file!` оварда мерасонад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Далелҳои онро таҳрир мекунад.
    ///
    /// Ин макро ифодаи навъи `&'static str`-ро медиҳад, ки сатри ҳамаи tokens ба макро гузаштааст.
    /// Дар синтаксиси худи даъватномаи макрос маҳдудият гузошта намешавад.
    ///
    /// Дар хотир доред, ки натиҷаҳои васеътари вуруди tokens метавонанд дар future тағир ёбанд.Агар шумо ба натиҷа такя кунед, шумо бояд эҳтиёт шавед.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Файли рамзии UTF-8-ро ҳамчун сатр дар бар мегирад.
    ///
    /// Файл нисбат ба файли ҷорӣ ҷойгир аст (монанд ба тарзи ёфтани модулҳо).
    /// Роҳи пешниҳодшуда дар вақти тартиб додан ба тарзи хоси платформа тафсир карда мешавад.
    /// Ҳамин тавр, масалан, даъватнома бо роҳи Windows, ки дорои пастиву нишони `\` мебошад, дар Unix дуруст тартиб дода намешавад.
    ///
    ///
    /// Ин макро ифодаи навъи `&'static str`-ро медиҳад, ки мундариҷаи файл мебошад.
    ///
    /// # Examples
    ///
    /// Фарз мекунем, ки дар як директория ду файл мавҷуд аст, ки дорои мундариҷаи зерин мебошанд:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Тартиб додани 'main.rs' ва ба кор андохтани бинарии натиҷа "adiós"-ро чоп мекунад.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Файлро ҳамчун истинод ба массиви байтӣ дар бар мегирад.
    ///
    /// Файл нисбат ба файли ҷорӣ ҷойгир аст (монанд ба тарзи ёфтани модулҳо).
    /// Роҳи пешниҳодшуда дар вақти тартиб додан ба тарзи хоси платформа тафсир карда мешавад.
    /// Ҳамин тавр, масалан, даъватнома бо роҳи Windows, ки дорои пастиву нишони `\` мебошад, дар Unix дуруст тартиб дода намешавад.
    ///
    ///
    /// Ин макро ифодаи навъи `&'static [u8; N]`-ро медиҳад, ки мундариҷаи файл мебошад.
    ///
    /// # Examples
    ///
    /// Фарз мекунем, ки дар як директория ду файл мавҷуд аст, ки дорои мундариҷаи зерин мебошанд:
    ///
    /// Файл 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Тартиб додани 'main.rs' ва ба кор андохтани бинарии натиҷа "adiós"-ро чоп мекунад.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Сатрро васеъ мекунад, ки роҳи модули ҷориро нишон медиҳад.
    ///
    /// Роҳи ҳозираи модулро метавон ҳамчун иерархияи модулҳо ҳисобид, ки ба crate root бармегарданд.
    /// Аввалин ҷузъи роҳи баргашта номи crate мебошад, ки ҳоло тартиб дода мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Тарҷумаҳои логикии конфигуратсияро ҳангоми тартиб додан баҳо медиҳад.
    ///
    /// Илова бар аттрибутӣ `#[cfg]`, ин макро барои баҳодиҳии ифодаи булии парчамҳои конфигуратсия пешбинӣ шудааст.
    /// Ин зуд-зуд ба кам такрори код оварда мерасонад.
    ///
    /// Синтаксисе, ки ба ин макро дода шудааст, ҳамон синтаксисест, ки бо атрибути [`cfg`] мебошад.
    ///
    /// `cfg!`, бар хилофи `#[cfg]`, ягон рамзро нест намекунад ва танҳо ба true ё false арзёбӣ мекунад.
    /// Масалан, ҳамаи блокҳои ифодаи if/else ҳангоми эътибори `cfg!`, новобаста аз он ки `cfg!` чӣ гуна арзёбӣ мекунад, бояд эътибор дошта бошанд.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Файлро ҳамчун ифода ё ҷузъ мувофиқи матн ҷудо мекунад.
    ///
    /// Файл нисбат ба файли ҷорӣ ҷойгир аст (монанд ба тарзи ёфтани модулҳо).Роҳи пешниҳодшуда дар вақти тартиб додан ба тарзи хоси платформа тафсир карда мешавад.
    /// Ҳамин тавр, масалан, даъватнома бо роҳи Windows, ки дорои пастиву нишони `\` мебошад, дар Unix дуруст тартиб дода намешавад.
    ///
    /// Истифодаи ин макро аксар вақт фикри бад аст, зеро агар файл ҳамчун ибора таҳлил карда шавад, он ба гигиена дар кодекси атроф ҷойгир карда мешавад.
    /// Ин метавонад ба тағирёбандаҳо ё функсияҳо аз оне, ки файл фарқ мекунад, натиҷа диҳад, агар тағирёбандаҳо ё функсияҳое, ки дар файли ҷорӣ ҳамон номро доранд, фарқ кунанд.
    ///
    ///
    /// # Examples
    ///
    /// Фарз мекунем, ки дар як директория ду файл мавҷуд аст, ки дорои мундариҷаи зерин мебошанд:
    ///
    /// Файл 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Файл 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Тартиб додани 'main.rs' ва ба кор андохтани бинарии натиҷа "🙈🙊🙉🙈🙊🙉"-ро чоп мекунад.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Тасдиқ мекунад, ки ифодаи булӣ дар вақти корӣ `true` аст.
    ///
    /// Ин макроиқтисодии [`panic!`]-ро даъват мекунад, агар ифодаи пешниҳодшударо ҳангоми кор ба `true` баҳогузорӣ карда натавонад.
    ///
    /// # Uses
    ///
    /// Тасдиқҳо ҳамеша дар ҳам сохтани хато ва ҳам сохтани версия тафтиш карда мешаванд ва онҳоро ғайрифаъол кардан мумкин нест.
    /// Барои тасдиқҳое, ки ҳангоми сохтани версияҳо бо нобаёнӣ фаъол нестанд, ба [`debug_assert!`] нигаред.
    ///
    /// Рамзи хатарнок метавонад ба `assert!` такя кунад, то инвариантҳои вақти кориро иҷро кунанд, ки агар вайрон карда шаванд, ба бехатарӣ оварда мерасонанд.
    ///
    /// Дигар ҳолатҳои истифодаи `assert!` иборатанд аз санҷиш ва иҷрои инвариантҳои вақти корӣ дар кодекси бехатар (вайронкунии онҳо боиси бехатарӣ нест).
    ///
    ///
    /// # Паёмҳои фармоишӣ
    ///
    /// Ин макрос шакли дуввум дорад, ки дар он паёми фармоишии panic метавонад бо ва ё бе далел барои форматкунӣ пешниҳод карда шавад.
    /// Барои формаи синтаксис барои [`std::fmt`] нигаред.
    /// Ибораҳое, ки ҳамчун аргументи формат истифода мешаванд, танҳо дар ҳолате арзёбӣ карда мешаванд, ки тасдиқ иҷро нашавад.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // паёми panic барои ин тасдиқҳо арзиши сатри ифодаи додашуда мебошад.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // вазифаи хеле содда
    ///
    /// assert!(some_computation());
    ///
    /// // бо паёми фармоишӣ тасдиқ кунед
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Маҷмӯаи ғайринизомӣ.
    ///
    /// Барои истифода [unstable book]-ро хонед.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Маҷмӯаи хаттии сабки LLVM.
    ///
    /// Барои истифода [unstable book]-ро хонед.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Маҷмӯаи хатти сатҳи модул.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Чопҳо tokens ба натиҷаи стандартӣ гузаштанд.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Фаъолияти ҷустуҷӯро, ки барои ислоҳи макросҳои дигар истифода мешаванд, фаъол ё хомӯш мекунад.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Макрои атрибутӣ, ки барои татбиқи макросҳои ҳосилшаванда истифода мешаванд.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Макроти атрибутӣ ба функсияе, ки онро ба санҷиши воҳид табдил медиҳад, татбиқ карда мешавад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Макроти атрибутӣ, ки ба функсия татбиқ карда мешавад, то онро ба санҷиши нишондиҳанда табдил диҳад.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Тафсилоти татбиқи макросҳои `#[test]` ва `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Макроти атрибутӣ ба статикӣ истифода мешавад, то онро ҳамчун ҷудокунандаи глобалӣ ба қайд гирад.
    ///
    /// Инчунин нигаред ба [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ашёеро, ки дар сурати дастрас будани роҳи гузариш татбиқ мешавад, нигоҳ медорад ва дар акси ҳол онро нест мекунад.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Тамоми атрибутҳои `#[cfg]` ва `#[cfg_attr]`-ро дар фрагменти рамзи истифодашаванда васеъ мекунад.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Тафсилоти ноустувори тартибдиҳандаи `rustc`, истифода набаред.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Тафсилоти ноустувори тартибдиҳандаи `rustc`, истифода набаред.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}