//! Утилитаҳо барои форматкунӣ ва чопи сатрҳо.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Ҳамоҳангсозии эҳтимолӣ аз ҷониби `Formatter::align` баргардонида шудааст
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Нишондиҳандае, ки мундариҷа бояд ба тарафи чап рост карда шаванд
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Нишондиҳандае, ки мундариҷа бояд бо рост рост карда шаванд.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Нишон, ки мундариҷа бояд ба марказ мутобиқ карда шаванд.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Намуди баргашта бо усулҳои форматер.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Навъи хатогие, ки аз форматкунии паём ба наҳр баргардонида мешавад.
///
/// Ин навъи интиқоли хаторо дастгирӣ намекунад, ба ғайр аз он ки хатогие рух додааст.
/// Ҳар гуна маълумоти иловагӣ бояд барои интиқол тавассути дигар василаҳо тартиб дода шавад.
///
/// Як чизи муҳимро бояд дар хотир дошт, ки навъи `fmt::Error` набояд бо [`std::io::Error`] ё [`std::error::Error`] омехта карда шавад, ки шумо низ метавонед дар доираи он дошта бошед.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait барои навиштан ё формат кардан ба буферҳо ё ҷараёнҳои қабулкунандаи Юникод.
///
/// Ин trait танҳо маълумоти кодгузори UTF-8-ро қабул мекунад ва [flushable] нест.
/// Агар шумо танҳо Юникодро қабул кардан хоҳед ва шустушӯ ба шумо лозим нест, шумо бояд ин trait-ро иҷро кунед;
/// дар акси ҳол, шумо бояд [`std::io::Write`]-ро татбиқ кунед.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Ба ин нависанда як буридаи сатр менависад ва бармегардад, ки оё навишта муваффақ шудааст.
    ///
    /// Ин усул танҳо дар сурате муваффақ шуда метавонад, ки агар тамоми буридаи сатрҳо бомуваффақият навишта шуда бошад ва то он даме, ки ҳама маълумот навишта нашуда бошад ё хатогие рух надиҳад, ин усул барнамегардад.
    ///
    ///
    /// # Errors
    ///
    /// Ин функсия мисоли [`Error`]-ро бо хатогӣ бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Ба ин нависанда [`char`] менависад ва бармегардад, ки оё навиштан муваффақ шудааст.
    ///
    /// Як [`char`] метавонад ҳамчун зиёда аз як байт рамзгузорӣ шавад.
    /// Ин усул танҳо дар сурате муваффақ шуда метавонад, ки агар тамоми пайдарпаии байтҳо бомуваффақият навишта шуда бошад ва то он даме, ки ҳама маълумот навишта нашуда бошад ё хатогие рух надиҳад, ин усул барнамегардад.
    ///
    ///
    /// # Errors
    ///
    /// Ин функсия мисоли [`Error`]-ро бо хатогӣ бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Ширеш барои истифодаи макроиқтисодии [`write!`] бо татбиқкунандагони ин trait.
    ///
    /// Ин усул одатан набояд дастӣ, балки тавассути худи макроиқи [`write!`] истифода шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Танзимот барои форматонӣ.
///
/// `Formatter` вариантҳои гуногуни марбут ба форматкуниро нишон медиҳад.
/// Истифодабарандагон мустақиман "Formatter"-ро намесозанд;истиноди тағирёбанда ба як усули `fmt` аз ҳама форматкунии traits, ба монанди [`Debug`] ва [`Display`] гузаронида мешавад.
///
///
/// Барои ҳамкорӣ бо `Formatter`, шумо усулҳои мухталифро барои тағир додани вариантҳои гуногуни вобаста ба форматонӣ даъват мекунед.
/// Барои мисолҳо, лутфан ба ҳуҷҷатҳои усулҳое, ки дар `Formatter` муайян шудаанд, нигаред.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Баҳс аслан функсияи форматонии қисман татбиқшудаи оптималӣ мебошад, ки ба `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` баробар аст.

extern "C" {
    type Opaque;
}

/// Ин структура "argument" умумиро нишон медиҳад, ки онро оилаи функсияҳои Xprintf гирифтааст.Он дорои функсияи форматкунии арзиши додашуда мебошад.
/// Дар вақти тартиб додан таъмин карда мешавад, ки функсия ва қимат намудҳои дуруст доранд ва пас ин структура барои канонализатсияи далелҳо ба як намуд истифода мешавад.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Ин арзиши ягонаи устувори нишоннамои функсияро, ки бо indices/counts дар инфрасохтори форматонӣ алоқаманд аст, кафолат медиҳад.
//
// Дар хотир доред, ки функсияе, ки чунин муайян шудааст, дуруст нахоҳад буд, зеро функсияҳо ҳамеша unnamed_addr бо пастшавии ҷорӣ ба LLVM IR ишора карда мешаванд, аз ин рӯ суроғаи онҳо барои LLVM муҳим ҳисобида намешавад ва аз ин рӯ метавонист as_usize андохта шавад.
//
// Дар амал, мо ҳеҷ гоҳ as_usize-ро дар мавриди истифодаи ғайримуқаррарии дорои маълумот наменомем (чун масъалаи тавлиди статикии далелҳои форматонӣ), бинобар ин ин танҳо як чеки иловагӣ аст.
//
// Мо пеш аз ҳама мехоҳем боварӣ ҳосил кунем, ки нишоннамои функсия дар `USIZE_MARKER` суроғаи *танҳо*-ро ба функсияҳое дошта бошад, ки `&usize`-ро ҳамчун далели аввалини худ қабул кунанд.
// Read_volatile дар инҷо кафолат медиҳад, ки мо метавонем корбарро аз истиноди гузаронидашуда омода созем ва ин суроға ба функсияи қабули ғайризизо ишора накунад.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // БЕХАТАР: : ptr истинод аст
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // БЕХАТАР: : `mem::transmute(x)` бехатар аст, зеро
        //     1. `&'b T` умри онро, ки аз `'b` сарчашма мегирад, нигоҳ медорад (ба тавре ки умри номаҳдуд надошта бошад)
        //     2.
        //     `&'b T` ва `&'b Opaque` ҳамон тарҳбандии хотира доранд (вақте ки `T` `Sized` бошад, ҳамон тавре ки дар ин ҷо аст) `mem::transmute(f)` бехатар аст, зеро `fn(&T, &mut Formatter<'_>) -> Result` ва `fn(&Opaque, &mut Formatter<'_>) -> Result` ҳамон ABI доранд (ба шарте ки `T` `Sized` бошад)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // БЕХАТАР: : майдони `formatter` танҳо ба USIZE_MARKER таъин шудааст, агар
            // арзиши як usize аст, пас ин бехатар аст
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// парчамҳо дар формати v1 format_args мавҷуданд
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Ҳангоми истифодаи макрои format_args! (), Ин функсия барои сохтани сохтори аргументҳо истифода мешавад.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Ин функсия барои муайян кардани параметрҳои форматонии ғайристандартӣ истифода мешавад.
    /// Массиви `pieces` бояд ҳадди аққал то `fmt` дароз бошад, то ки сохтори дурусти Аргументҳо сохта шавад.
    /// Инчунин, ҳар як `Count` дар дохили `fmt`, ки `CountIsParam` ё `CountIsNextParam` аст, бояд ба далели бо `argumentusize` эҷодшуда ишора кунад.
    ///
    /// Аммо, иҷро накардани он боиси бехатарӣ намешавад, аммо беэътибор дониста мешавад.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Дарозии матни форматшударо тахмин мекунад.
    ///
    /// Ин барои таъин кардани иқтидори ибтидоии `String` ҳангоми истифодаи `format!` пешбинӣ шудааст.
    /// Note: ин на сарҳади поёнӣ ва на болоӣ аст.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Агар сатри формат бо далел оғоз шавад, ҳеҷ чизро пешакӣ тақсим накунед, агар дарозии донаҳо аҳамият надошта бошанд.
            //
            //
            0
        } else {
            // Баъзе далелҳо мавҷуданд, бинобар ин ҳар як такони иловагӣ сатрро аз нав тақсим мекунад.
            //
            // Барои роҳ надодан ба ин, мо "pre-doubling" иқтидорро дар ин ҷо дорем.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Ин сохтор версияи бехатар пешакӣ тартибдодашудаи сатри формат ва далелҳои онро нишон медиҳад.
/// Ин наметавонад дар вақти корӣ тавлид карда шавад, зеро онро бехатар иҷро кардан мумкин нест, бинобар ин ягон конструктор дода намешавад ва майдонҳо барои пешгирии тағирот хусусӣ мебошанд.
///
///
/// Макрои [`format_args!`] бехатарии намунаи ин сохторро ба вуҷуд меорад.
/// Макрос сатри форматро дар вақти тартиб додан тасдиқ мекунад, то истифодаи функсияҳои [`write()`] ва [`format()`] бехатар иҷро карда шавад.
///
/// Шумо метавонед `Arguments<'a>`-ро истифода баред, ки [`format_args!`] дар заминаҳои `Debug` ва `Display` бармегардад, ки дар поён дида мешавад.
/// Мисол инчунин нишон медиҳад, ки формати `Debug` ва `Display` ба ҳамон чиз: сатри формати интерполятсия дар `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Пахшҳои сатрро барои чоп формат кунед.
    pieces: &'a [&'static str],

    // Мушаххасоти ҷойгиркунанда ё `None`, агар ҳама мушаххасот бо нобаёнӣ бошанд (тавре ки дар "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Далелҳои динамикӣ барои интерполяция, ки бо дона сатр гузошта мешаванд.
    // (Пеш аз ҳар як далел порчаи сатр пешкаш карда мешавад.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Сатри форматшударо гиред, агар он ягон далеле барои формат кардан надошта бошад.
    ///
    /// Ин метавонад барои пешгирӣ аз ҷудошавӣ дар ҳолати ночизтарин истифода шавад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` бояд натиҷаро дар контексте, ки ба барномасоз дучор шудааст, ислоҳ кунад.
///
/// Умуман, шумо бояд танҳо `derive` татбиқи `Debug` кунед.
///
/// Ҳангоми истифода бо нишондиҳандаи алтернативии `#?`, натиҷаи хеле хуб чоп карда мешавад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// Ин trait метавонад бо `#[derive]` истифода шавад, агар ҳамаи майдонҳо `Debug`-ро иҷро кунанд.
/// Ҳангоми сохтан барои сохторҳо, он номи `struct`, пас `{`, пас рӯйхати ҷудошудаи ҳар як номи соҳа ва арзиши `Debug`, пас `}`-ро истифода мебарад.
/// Барои `enum`s, он номи вариантро истифода мебарад ва агар имконпазир бошад, `(`, пас арзишҳои `Debug`-и майдонҳо, пас `)`.
///
/// # Stability
///
/// Форматҳои `Debug` ҳосилшуда мӯътадил нестанд ва метавонанд бо нусхаҳои future Rust тағир ёбанд.
/// Ғайр аз он, амалисозии `Debug` намудҳои аз ҷониби китобхонаи стандартӣ пешбинишуда (`libstd`, `libcore`, `liballoc` ва ғайра) устувор нестанд ва метавонанд бо версияҳои future Rust низ тағир ёбанд.
///
///
/// # Examples
///
/// Натиҷаи амалисозӣ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Иҷрои дастӣ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Якчанд усулҳои ёрирасон дар сохтори [`Formatter`] мавҷуданд, ки ба шумо дар амалисозии дастӣ кӯмак мерасонанд, ба монанди [`debug_struct`].
///
/// `Debug` татбиқҳо бо истифода аз `derive` ё API созандаи ислоҳӣ дар [`Formatter`] бо истифода аз парчами алтернативӣ чопи зебоеро дастгирӣ мекунад: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Чопи зебо бо `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Модули алоҳида барои дубора содир кардани макро `Debug` аз prelude бе trait `Debug`.
pub(crate) mod macros {
    /// Макросро тавлид кунед, ки имкони trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Формат trait барои формати холӣ, `{}`.
///
/// `Display` ба [`Debug`] монанд аст, аммо `Display` барои баромади рӯ ба корбар аст ва аз ин рӯ наметавон ба даст омад.
///
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Татбиқи `Display` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait бояд баромади худро ҳамчун рақам дар base-8 формат кунад.
///
/// Барои ададҳои имзои ибтидоии имзошуда (`i8` то `i128` ва `isize`), арзишҳои манфӣ ҳамчун намояндагии иловагии ҳарду формат карда мешаванд.
///
///
/// Парчами иловагӣ, `#`, дар назди баромад `0o` илова мекунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `i32`:
///
/// ```
/// let x = 42; // 42 дар ҳаштум '52' аст
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Татбиқи `Octal` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // вакили татбиқи i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait бояд баромади худро ҳамчун рақам дар дуӣ формат кунад.
///
/// Барои ададҳои имзои ибтидоии имзошуда ([`i8`] то [`i128`] ва [`isize`]), арзишҳои манфӣ ҳамчун намояндагии иловагии ҳарду формат карда мешаванд.
///
///
/// Парчами иловагӣ, `#`, дар назди баромад `0b` илова мекунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо [`i32`]:
///
/// ```
/// let x = 42; // 42 дар бинарӣ '101010' аст
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Татбиқи `Binary` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // вакили татбиқи i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait бояд баромади худро ҳамчун рақам дар шонздаҳӣ формат кунад, бо `a` то `f` дар ҳарфи хурд.
///
/// Барои ададҳои имзои ибтидоии имзошуда (`i8` то `i128` ва `isize`), арзишҳои манфӣ ҳамчун намояндагии иловагии ҳарду формат карда мешаванд.
///
///
/// Парчами иловагӣ, `#`, дар назди баромад `0x` илова мекунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `i32`:
///
/// ```
/// let x = 42; // 42 '2a' дар шонздаҳӣ аст
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Татбиқи `LowerHex` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // вакили татбиқи i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait бояд баромади худро ҳамчун рақам дар шонздаҳӣ формат кунад, дар ҳолати калон-`A` то `F`.
///
/// Барои ададҳои имзои ибтидоии имзошуда (`i8` то `i128` ва `isize`), арзишҳои манфӣ ҳамчун намояндагии иловагии ҳарду формат карда мешаванд.
///
///
/// Парчами иловагӣ, `#`, дар назди баромад `0x` илова мекунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `i32`:
///
/// ```
/// let x = 42; // 42 '2A' дар шонздаҳӣ аст
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Татбиқи `UpperHex` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // вакили татбиқи i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait бояд баромади худро ҳамчун макони хотира формат кунад.
/// Ин одатан ҳамчун шонздаҳӣ пешниҳод карда мешавад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ин чизе ба монанди '0x7f06092ac6d0' истеҳсол мекунад
/// ```
///
/// Татбиқи `Pointer` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // `as`-ро барои табдил додан ба `*const T` истифода баред, ки Pointer-ро татбиқ мекунад, ки мо метавонем онро истифода барем
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait бояд баромади худро бо қайдҳои илмӣ бо ҳарфи хурд `e` формат кунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `f64`:
///
/// ```
/// let x = 42.0; // 42.0 дар нотаи илмӣ '4.2e1' аст
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Татбиқи `LowerExp` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // вакили татбиқи f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait бояд баромади худро бо қайдҳои илмӣ бо ҳарфи калон `E` формат кунад.
///
/// Барои маълумоти иловагӣ дар бораи форматгарҳо, ба [the module-level documentation][module] нигаред.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Истифодаи асосӣ бо `f64`:
///
/// ```
/// let x = 42.0; // 42.0 дар нотаи илмӣ '4.2E1' аст
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Татбиқи `UpperExp` дар намуди:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // вакили татбиқи f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Арзишро бо истифода аз форматори додашуда формат мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Функсияи `write` ҷараёни баромадро мегирад ва структураи `Arguments`-ро, ки бо макрои `format_args!` пешакӣ тартиб дода мешавад.
///
///
/// Далелҳо мувофиқи сатри формати муайян дар ҷараёни баромади пешниҳодшуда формат карда мешаванд.
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Лутфан қайд кунед, ки истифодаи [`write!`] метавонад бартарӣ дошта бошад.Мисол:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Мо метавонем параметрҳои форматкунии пешфарзро барои ҳамаи далелҳо истифода барем.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Ҳар як спект як далели мувофиқ дорад, ки пеш аз он порчаи сатр гузошта мешавад.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // БЕХАТАР: : arg ва args.args аз ҳамон далелҳо бармеоянд,
                // ки нишондиҳандаҳоро ҳамеша кафолат медиҳад.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Танҳо як пораи сатри боқимонда боқӣ монда метавонад.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // БЕХАТАР: : arg ва args аз ҳамон далелҳо бармеоянд,
    // ки нишондиҳандаҳоро ҳамеша кафолат медиҳад.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Далели дурустро истихроҷ кунед
    debug_assert!(arg.position < args.len());
    // БЕХАТАР: : arg ва args аз ҳамон далелҳо бармеоянд,
    // ки индекси онро ҳамеша кафолат медиҳад.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Пас воқеан каме чоп кунед
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // БЕХАТАР: : cnt ва args аз ҳамон далелҳо бармеоянд,
            // ки ин нишондиҳандаро ҳамеша кафолат медиҳад.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Пас аз ба охир расидани чизе.Бозгашт аз ҷониби `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Ин постро нависед.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Мо мехоҳем инро тағир диҳем
            buf: wrap(self.buf),

            // Ва инро нигоҳ доред
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Усулҳои ёрирасон, ки барои пур кардан ва коркарди далелҳои форматонӣ истифода мешаванд, ки ҳамаи форматҳои traits метавонанд истифода баранд.
    //

    /// Ҷойгиркунии дурустро барои бутуни тамом, ки аллакай ба str фиристода шудааст, иҷро мекунад.
    /// Дар сатр набояд аломати бутун дошта бошад, ки бо ин усул илова карда мешавад.
    ///
    /// # Arguments
    ///
    /// * новобаста аз он, ки адади аслӣ мусбат ё сифр буд.
    /// * префикс, агар аломати '#' (Alternate) пешбинӣ шуда бошад, ин префиксест, ки дар пеши рақам гузошта мешавад.
    ///
    /// * buf, массиви байтӣ, ки рақам онро формат кардааст
    ///
    /// Ин функсия парчамҳои пешниҳодшуда ва паҳнои ҳадди ақалро дуруст ҳисоб мекунад.
    /// Ин дақиқро ба назар намегирад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Мо бояд "-"-ро аз баромади рақам хориҷ кунем.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Агар он мавҷуд бошад, аломатро менависад ва пас он префиксро, агар он дархост шуда бошад
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Майдони `width` дар ин лаҳза бештар аз як параметри `min-width` аст.
        match self.width {
            // Агар ягон талаботи дарозии ҳадди аққал вуҷуд надошта бошад, мо метавонем танҳо байтҳоро нависем.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Тафтиш кунед, ки мо аз паҳнои ҳадди аққал зиёдем, агар ин тавр бошад, мо метавонем танҳо байтҳоро нависем.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Агар аломати пур кардани сифр сифр бошад, аломат ва префикс пеш аз андоза мегузарад
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Дар акси ҳол, аломат ва префикс пас аз пур кардани ҷой мегузарад
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ин функсия як буридаи сатрро мегирад ва пас аз татбиқи парчамҳои дахлдори форматкардашуда, онро ба буферии дохилӣ мебарорад.
    /// Парчамҳои барои сатрҳои умумӣ шинохташуда инҳоянд:
    ///
    /// * паҳнӣ, паҳнои ҳадди ақали он чӣ бояд партофт
    /// * fill/align - агар сатри пешниҳодшударо пӯшонидан лозим бошад, он чӣ бояд паҳн кунад ва онро дар куҷо барорад
    /// * дақиқӣ, дарозии максималии интишор, сатр бурида мешавад, агар он аз ин дарозӣ дарозтар бошад
    ///
    /// Аз ҷумла, ин функсия параметрҳои `flag`-ро сарфи назар мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Боварӣ ҳосил кунед, ки роҳи зуде дар пеш аст
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Майдони `precision` метавонад ҳамчун `max-width` барои сатри форматшуда тафсир карда шавад.
        //
        let s = if let Some(max) = self.precision {
            // Агар тори мо аз дақиқӣ дарозтар бошад, пас мо бояд кандашавӣ дошта бошем.
            // Аммо парчамҳои дигар ба монанди `fill`, `width` ва `align` бояд мисли ҳамеша амал кунанд.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM дар ин ҷо наметавонад исбот кунад, ки `..i` panic `&s[..i]` нахоҳад шуд, аммо мо медонем, ки он panic наметавонад.
                // Барои пешгирӣ кардани X0 `unsafe``get` + `unwrap_or`-ро истифода баред ва дар акси ҳол дар ин ҷо ягон рамзи марбут ба panic надиҳед.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Майдони `width` дар ин лаҳза бештар аз як параметри `min-width` аст.
        match self.width {
            // Агар мо зери дарозии максималӣ қарор дошта бошем ва талаботи дарозии ҳадди аққал вуҷуд надошта бошад, пас мо танҳо сатрро бароварда метавонем
            //
            None => self.buf.write_str(s),
            // Агар мо зери паҳнои ҳадди аксар бошем, санҷед, ки паҳнои ҳадди аққал аз ҳад зиёд ҳастем, агар ин ба монанди паҳн кардани сатр осон бошад.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Агар мо ҳам паҳнои ҳадди аксар ва ҳам ҳадди аққал дошта бошем, пас паҳнои ҳадди ақалро бо сатри муайяншуда + баъзе ҳамҷоякунӣ пур кунед.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ҷойгиркунии пешакиро нависед ва пас аз пур кардани навиштаҷотро баргардонед.
    /// Зангҳо барои таъмини пас аз пур кардани навиштаҷот пас аз он чизе, ки пӯшонида мешавад, масъуланд.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Қисмҳои форматшударо мегирад ва замима мегузорад.
    /// Фарз мекунад, ки даъваткунанда аллакай қисмҳоро бо дақиқии зарурӣ расонидааст, то `self.precision` сарфи назар карда шавад.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // барои нишонаҳои огоҳ аз сифр, мо аввал аломатро нишон медиҳем ва тавре рафтор мекунем, ки гӯё аз аввал нишоне надоштем.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // аломат ҳамеша дар ҷои аввал меистад
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // нишонаро аз қисмҳои форматшуда хориҷ кунед
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // қисмҳои боқимонда тавассути раванди оддии оддӣ мегузаранд.
            let len = formatted.len();
            let ret = if width <= len {
                // болопӯш нест
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ин ҳолати маъмулист ва мо миёнабур мегирем
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // БЕХАТАР: : Ин барои `flt2dec::Part::Num` ва `flt2dec::Part::Copy` истифода мешавад.
            // Барои `flt2dec::Part::Num` истифода бурдан бехатар аст, зеро ҳар як char `c` байни `b'0'` ва `b'9'` аст, яъне `s` UTF-8 эътибор дорад.
            // Инчунин дар амал истифода бурдани `flt2dec::Part::Copy(buf)` бехатар аст, зеро `buf` бояд ASCII оддӣ бошад, аммо касе имкон дорад, ки арзиши бад барои `buf` ба `flt2dec::to_shortest_str` гузарад, зеро ин вазифаи ҷамъиятӣ аст.
            //
            // FIXME: Муайян кунед, ки оё ин метавонад ба UB оварда расонад.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 сифр
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Баъзе маълумотро ба буфере, ки дар ин форматер мавҷуд аст, менависад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Ин ба:
    ///         // нависед! (форматкунанда, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Ба ин мисол баъзе маълумоти форматшударо менависад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Парчамҳо барои форматонӣ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Аломате, ки ҳамчун 'fill' истифода мешавад, вақте ки ҳамоҳангӣ вуҷуд дорад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Мо бо ">" ба рост рост гузоштем.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Парчам бо нишон додани кадом шакли ҳамворкунӣ
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Паҳнои бутуни ихтиёрӣ муайян карда мешавад, ки натиҷа бояд бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Агар мо паҳнои васеъ мегирифтем, онро истифода мебарем
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Дар акси ҳол, мо ҳеҷ кори махсусе намекунем
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Дурустии ихтиёрӣ барои намудҳои ададӣ муайян карда шудааст.
    /// Интихобан, паҳнои максималӣ барои намудҳои сатр.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Агар мо дақиқро гирифта бошем, онро истифода мебарем.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Дар акси ҳол, мо бо нобаёнӣ 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Муайян мекунад, ки парчами `+` муайян карда шудааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Муайян мекунад, ки парчами `-` муайян карда шудааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Шумо аломати минус мехоҳед?Доред!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Муайян мекунад, ки парчами `#` муайян карда шудааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Муайян мекунад, ки парчами `0` муайян карда шудааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Мо имконоти форматерро сарфи назар мекунем.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Тасмим гиред, ки мо барои ин ду парчам кадом API-и оммавиро мехоҳем.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Созандаи [`DebugStruct`] месозад, ки барои кӯмак дар сохтани татбиқи [`fmt::Debug`] барои структураҳо мусоидат мекунад.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Созандаи `DebugTuple` месозад, ки барои мусоидат ба эҷоди татбиқи `fmt::Debug` барои структураҳои топле пешбинӣ шудааст.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Созандаи `DebugList` месозад, ки барои кӯмак дар сохтани татбиқи `fmt::Debug` барои сохторҳои ба рӯйхат монанд мусоидат мекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Созандаи `DebugSet` месозад, ки барои мусоидат ба эҷоди татбиқи `fmt::Debug` барои сохторҳои шабеҳ ба нақша гирифта шудааст.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Дар ин мисоли мураккабтар, мо [`format_args!`] ва `.debug_set()`-ро барои сохтани рӯйхати силоҳҳои мувофиқ истифода мебарем:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Созандаи `DebugMap` месозад, ки барои мусоидат ба эҷоди татбиқи `fmt::Debug` барои сохторҳои ба харита шабеҳ пешбинӣ шудааст.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Татбиқи форматкунии асосии traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Агар char ба гурехтан ниёз дошта бошад, пас пешгузаштаро тоза кунед ва нависед, вагарна гузаред
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Парчами алтернативӣ аллакай аз ҷониби LowerHex ҳамчун махсус баррасӣ карда мешавад-ин маънои онро дорад, ки оё бо 0x префикс карда мешавад ё не.
        // Мо онро барои коркарди он, ки сифр дароз карда мешавад ё не, истифода мебарем ва пас бидуни ҳеҷ шарт онро ба даст овардани префикс таъин мекунем.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Татбиқи Display/Debug барои намудҳои гуногуни аслӣ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell мутаносибан қарз гирифта шудааст, бинобар ин мо арзиши онро дида наметавонем.
                // Ба ҷои он ҷойгиркунакро нишон диҳед.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Агар шумо интизор будед, ки санҷишҳо дар ин ҷо хоҳанд буд, ба ҷои файли core/tests/fmt.rs нигаред, ин нисбат ба сохтани ҳамаи сохторҳои rt::Piece дар ин ҷо хеле осонтар аст.
//
// Инчунин дар ҷудокунандаи crate озмоишҳо мавҷуданд, ки барои тақсимот ниёз доранд.