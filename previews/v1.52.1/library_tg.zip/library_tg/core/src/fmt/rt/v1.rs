//! Ин як модули дохилиест, ки аз ҷониби ifmt истифода мешавад!вақти корӣ.Ин сохторҳо ба массивҳои статикӣ дода мешаванд, то сатрҳои форматро пешакӣ тартиб диҳанд.
//!
//! Ин таърифҳо ба эквивалентҳои `ct` монанданд, аммо бо он фарқ мекунанд, ки онҳоро статикӣ ҷудо кардан мумкин аст ва барои вақти кор каме оптимизатсия карда шудаанд.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Ҳамоҳангсозии имконпазир, ки ҳамчун як қисми директиваи форматкунӣ дархост карда мешавад.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Нишондиҳандае, ки мундариҷа бояд ба тарафи чап рост карда шаванд
    Left,
    /// Нишондиҳандае, ки мундариҷа бояд бо рост рост карда шаванд.
    Right,
    /// Нишон, ки мундариҷа бояд ба марказ мутобиқ карда шаванд.
    Center,
    /// Ҳеҷ гуна ҳамоҳангӣ дархост карда нашудааст.
    Unknown,
}

/// Бо нишондиҳандаҳои [width](https://doc.rust-lang.org/std/fmt/#width) ва [precision](https://doc.rust-lang.org/std/fmt/#precision) истифода бурда мешавад.
#[derive(Copy, Clone)]
pub enum Count {
    /// Бо рақами аслӣ дода шудааст, арзиши онро нигоҳ медорад
    Is(usize),
    /// Бо истифода аз синтаксисҳои `$` ва `*` муайян карда шудааст, ки индексро ба `args` нигоҳ медорад
    Param(usize),
    /// Муайян нашудааст
    Implied,
}