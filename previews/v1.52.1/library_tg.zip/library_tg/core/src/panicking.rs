//! Дастгирии Panic барои libcore
//!
//! Китобхонаи аслӣ ваҳмро муайян карда наметавонад, аммо *ваҳмро* эълон мекунад.
//! Ин маънои онро дорад, ки функсияҳои дохили libcore ба panic иҷозат дода шудаанд, аммо барои фоиданок будан crate бояд барои истифодаи libcore ваҳмро муайян кунад.
//! Интерфейси ҳозира барои вохӯрӣ инҳоянд:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ин таъриф имкон медиҳад, ки бо ҳар гуна паёми умумӣ ба вохима афтад, аммо он бо арзиши `Box<Any>` иҷозат намедиҳад.
//! (`PanicInfo` танҳо як `&(dyn Any + Send)` дорад, ки барои он мо арзиши панелро дар "PanicInfo: : internal_constructor" пур мекунем.) Сабаби ин дар ҷудошавии libcore иҷозат дода нашудааст.
//!
//!
//! Ин модул якчанд функсияҳои дигари паникингро дар бар мегирад, аммо инҳо ҷузъҳои зарурии забон мебошанд.Ҳама panics тавассути ин як функсия ҷудо карда мешавад.
//! Рамзи воқеӣ тавассути атрибутикаи `#[panic_handler]` эълон карда мешавад.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Татбиқи аслии макросҳои libcore's `panic!`, вақте ки ягон формат истифода намешавад.
#[cold]
// ҳеҷ гоҳ дохил нашавед, агар panic_immediate_abort то ҳадди имкон аз дабдабанок шудани рамз дар сайтҳои зангҳо пешгирӣ кунад
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // барои кодекси panic дар лабрез ва дигар терминаторҳои `Assert` MIR лозим аст
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Arguments::new_v1-ро ба ҷои format_args истифода кунед! ("{}", Expr), то эҳтимолан андозаи болоро кам кунад.
    // Format_args!макро Display Display trait-ро барои навиштани expr истифода мебарад, ки ба Formatter::pad занг мезанад, ки бояд буридани сатр ва ҷойивазкуниро ҷойгир кунад (гарчанде ки дар ин ҷо ягонтои он истифода намешавад).
    //
    // Истифодаи Arguments::new_v1 метавонад ба тартибдиҳанда имкон диҳад, ки Formatter::pad-ро аз бинарии баромади хориҷ кунад ва то чанд килобайт сарфа кунад.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // барои panics мавриди баҳогузорӣ лозим аст
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // барои кодекси panic дар дастрасии OOB array/slice лозим аст
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Татбиқи аслии макроиқтисодии libcore's `panic!` ҳангоми форматонӣ истифода мешавад.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ЭЗОҲ Ин вазифа ҳеҷ гоҳ сарҳади FFI-ро убур намекунад;ин як занги Rust-to-Rust мебошад, ки ба вазифаи `#[panic_handler]` ҳал карда мешавад.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // БЕХАТАР: : `panic_impl` дар рамзи бехатар Rust муайян шудааст ва аз ин рӯ барои занг задан бехатар аст.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Функсияи дохилӣ барои макросҳои `assert_eq!` ва `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}