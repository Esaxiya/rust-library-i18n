//! Такрори беруна.
//!
//! Агар шумо худро бо ягон намуди коллексия пайдо карда бошед ва ба унсурҳои ин коллексия амалиёт лозим бошад, шумо зуд ба 'iterators' медароед.
//! Итераторҳо дар рамзи idiomatic Rust сахт истифода мешаванд, аз ин рӯ бо онҳо ошно шудан лозим аст.
//!
//! Пеш аз шарҳи бештар, биёед дар бораи тарзи сохтани ин модул сӯҳбат кунем:
//!
//! # Organization
//!
//! Ин модул асосан аз рӯи намудҳо ташкил карда шудааст:
//!
//! * [Traits] қисми асосӣ мебошанд: ин traits муайян мекунанд, ки чӣ гуна итераторҳо мавҷуданд ва шумо бо онҳо чӣ кор карда метавонед.Усулҳои ин traits меарзанд, ки вақти иловагии омӯзишӣ сарф кунанд.
//! * [Functions] якчанд роҳҳои муфиди эҷоди баъзе такрори асосиро пешниҳод кунед.
//! * [Structs] аксар вақт намудҳои баргардонидани усулҳои гуногун дар traits ин модул мебошанд.Шумо одатан мехоҳед ба усули эҷоди `struct` назар кунед, на ба худи `struct`.
//! Барои тафсилоти бештар дар бораи он, ба '[Иҷрокунандаи Итератор](#татбиқи-итератор) нигаред.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ана тамом!Биёед такроркунандагонро кобем.
//!
//! # Iterator
//!
//! Дил ва ҷони ин модул [`Iterator`] trait мебошад.Асоси [`Iterator`] чунин менамояд:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Итератори усули [`next`] дорад, ки ҳангоми даъват ["Опсия"]-ро бармегардонад<Item>".
//! [`next`] то он даме, ки унсурҳо мавҷуданд, [`Some(Item)`]-ро бармегардонанд ва пас аз тамом шудани онҳо, `None` бармегардад, ки такрор ба анҷом расидааст.
//! Итераторҳои инфиродӣ метавонанд дубора такрорро интихоб кунанд ва аз ин рӯ дубора занг задан ба [`next`] метавонад ё дар ниҳоят бозгашти [`Some(Item)`]-ро дубора оғоз кунад (масалан, ба [`TryIter`] нигаред).
//!
//!
//! Таърифи пурраи ["Итератор"] як қатор усулҳои дигарро низ дар бар мегирад, аммо онҳо усулҳои пешфарз мебошанд, ки дар болои [`next`] сохта шудаанд ва аз ин рӯ шумо онҳоро ройгон мегиред.
//!
//! Итераторҳо инчунин қобили таҳия ҳастанд ва барои ба ҳам пайванд додани шаклҳои нисбатан мураккаби коркард маъмул аст.Барои тафсилоти бештар ба бахши [Adapters](#adapters) нигаред.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Се шакли такрор
//!
//! Се усули маъмул мавҷуданд, ки метавонанд такроркунандагонро аз маҷмӯа эҷод кунанд:
//!
//! * `iter()`, ки аз `&T` такрор мешавад.
//! * `iter_mut()`, ки аз `&mut T` такрор мешавад.
//! * `into_iter()`, ки аз `T` такрор мешавад.
//!
//! Чизҳои гуногун дар китобхонаи стандартӣ метавонанд як ё якчанд сееро, ки дар ҳолати зарурӣ татбиқ кунанд, иҷро кунанд.
//!
//! # Татбиқи Iterator
//!
//! Сохтани такрори худ аз ду марҳила иборат аст: эҷоди `struct` барои нигоҳ доштани ҳолати итератор ва сипас амалӣ кардани [`Iterator`] барои он `struct`.
//! Аз ин рӯ, дар ин модул бисёр "struct`ҳо" мавҷуданд: барои ҳар як итератори атератори итератор яктогӣ вуҷуд дорад.
//!
//! Биёед як iterator бо номи `Counter` созем, ки аз `1` то `5` ҳисоб карда шавад:
//!
//! ```
//! // Аввалан, структура:
//!
//! /// Итераторе, ки аз як то панҷ ҳисоб мекунад
//! struct Counter {
//!     count: usize,
//! }
//!
//! // мо мехоҳем, ки шумори мо аз як сар шавад, пас биёед усули new() барои кумак расонем.
//! // Ин чандон зарур нест, аммо қулай аст.
//! // Дар хотир доред, ки мо `count`-ро дар сифр оғоз мекунем, мебинем, ки чаро дар татбиқи `next()`'s дар зер.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Пас, мо `Iterator`-ро барои `Counter`-и худ татбиқ мекунем:
//!
//! impl Iterator for Counter {
//!     // мо бо usize ҳисоб хоҳем кард
//!     type Item = usize;
//!
//!     // next() ягона усули зарурӣ мебошад
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Ҳисоби моро зиёд кунед.Ин аст, ки чаро мо дар сифр оғоз кардем.
//!         self.count += 1;
//!
//!         // Санҷед, бубинед, ки мо ҳисобкуниро тамом кардем ё не.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Ва ҳоло мо метавонем онро истифода барем!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Бо ин роҳ даъват кардани [`next`] такрор меёбад.Rust сохторе дорад, ки метавонад ба [`next`] дар итератори шумо занг занад, то он даме ки ба `None` расад.Биёед аз болои он гузарем.
//!
//! Ҳамчунин қайд кунед, ки `Iterator` татбиқи пешфарзаи усулҳоро ба монанди `nth` ва `fold`, ки `next`-ро дар дохили он даъват мекунанд, пешниҳод мекунад.
//! Бо вуҷуди ин, имконпазир аст, ки татбиқи фармоишии усулҳо, ба монанди `nth` ва `fold` нависед, агар итератор битавонад онҳоро бе зангзании `next` самараноктар ҳисоб кунад.
//!
//! # `for` ҳалқаҳо ва `IntoIterator`
//!
//! Синтаксиси ҳалқаи `for` Rust воқеан барои такроркунандагон шакар аст.Ин намунаи асосии `for` аст:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Ин рақамҳоро аз як то панҷ чоп мекунад, ки ҳар яке дар сатри худ.Аммо шумо дар ин ҷо чизеро мушоҳида хоҳед кард: мо ҳеҷ гоҳ дар vector-и худ чизе намедиҳем, то як итератор истеҳсол кунем.Чӣ медиҳад?
//!
//! Дар китобхонаи стандартӣ trait мавҷуд аст, то чизеро ба итератор табдил диҳад: [`IntoIterator`].
//! Ин trait як усули [`into_iter`] дорад, ки чизи татбиқкунандаи [`IntoIterator`]-ро ба итератор табдил медиҳад.
//! Биёед бори дигар он ҳалқаи `for`-ро дида бароем ва чӣ тартибдиҳанда онро ба он табдил медиҳад:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ба ин шакар медиҳад:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Аввалан, мо ба `into_iter()` оид ба арзиш занг мезанем.Сипас, мо дар iterator, ки бармегардад, мувофиқат мекунем ва ба [`next`] такроран занг мезанем, то он даме ки `None`-ро бинем.
//! Дар он лаҳза, мо `break`-ро аз ҳалқа берун кардем ва такрори онро анҷом додем.
//!
//! Дар ин ҷо боз як латифи нозуки дигаре ҳаст: китобхонаи стандартӣ дорои татбиқи ҷолиби [`IntoIterator`] мебошад:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Ба ибораи дигар, ҳамаи [`Iterator`] [`IntoIterator`]-ро танҳо бо роҳи бозгашти худ амалӣ мекунанд.Ин маънои ду чизро дорад:
//!
//! 1. Агар шумо [`Iterator`] нависед, шумо метавонед онро бо ҳалқаи `for` истифода баред.
//! 2. Агар шумо коллексия эҷод карда истодаед, татбиқи [`IntoIterator`] барои он имкон медиҳад, ки коллексияи шумо бо ҳалқаи `for` истифода шавад.
//!
//! # Такрори истинод
//!
//! Азбаски [`into_iter()`] `self`-ро аз рӯи арзиш мегирад, бо истифода аз ҳалқаи `for` барои такроркунӣ аз болои коллексия ин маҷмӯа истеъмол карда мешавад.Аксар вақт, шумо метавонед мехоҳед аз болои коллексия бе истеъмол такрор кунед.
//! Бисёре аз маҷмӯаҳо усулҳоеро пешниҳод мекунанд, ки такроркунандагонро тавассути истинодҳо пешниҳод мекунанд, ки мутаносибан `iter()` ва `iter_mut()` номида мешаванд:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` то ҳол ба ин вазифа тааллуқ дорад.
//! ```
//!
//! Агар намуди коллексияи `C` `iter()` пешниҳод кунад, он одатан инчунин `IntoIterator`-ро барои `&C` татбиқ мекунад, бо татбиқи он, ки танҳо `iter()`-ро даъват мекунад.
//! Ба ин монанд, коллексияи `C`, ки `iter_mut()` таъмин мекунад, одатан `IntoIterator`-ро барои `&mut C` бо роҳи фиристодан ба `iter_mut()` амалӣ мекунад.Ин имкон медиҳад, ки стенографияи мувофиқ:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ҳамон тавре ки `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // ҳамон тавре ки `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Дар ҳоле ки бисёр коллексияҳо `iter()` пешниҳод мекунанд, на ҳама `iter_mut()` пешниҳод мекунанд.
//! Масалан, мутатсияи калидҳои [`HashSet<T>`] ё [`HashMap<K, V>`] метавонад коллексияро дар ҳолати номувофиқ қарор диҳад, агар калидҳои калид иваз шаванд, аз ин рӯ ин маҷмӯаҳо танҳо `iter()` пешниҳод мекунанд.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Вазифаҳое, ки [`Iterator`] мегиранд ва [`Iterator`] дигарро бармегардонанд, аксар вақт "созгорҳои итератор" номида мешаванд, зеро онҳо шакли "адаптер" мебошанд
//! pattern'.
//!
//! Созгорҳои iterator умумӣ дохил [`map`], [`take`] ва [`filter`].
//! Барои маълумоти иловагӣ, ба ҳуҷҷатҳои онҳо нигаред.
//!
//! Агар адаптери итератори panics бошад, такрори он дар ҳолати номуайян (аммо бехатарии хотира) хоҳад буд.
//! Ин ҳолат низ кафолат дода намешавад, ки дар версияҳои Rust якхела монад, бинобар ин шумо бояд аз такя ба арзишҳои дақиқи баргаштаи итератор, ки ба ҳарос афтод, парҳез кунед.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Итераторҳо (ва итератори [adapters](#adapters))*танбал* мебошанд. Ин маънои онро дорад, ки танҳо сохтани итератор _do_-ро пурра иҷро намекунад. То он даме, ки шумо ба [`next`] занг назанед, ҳеҷ чиз рӯй намедиҳад.
//! Ин баъзан манбаи нофаҳмиҳо ҳангоми этератсия танҳо барои таъсири манфии он мегардад.
//! Масалан, усули [`map`] бастани ҳар як унсури такроршавандаро даъват мекунад:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Ин ягон арзишеро чоп намекунад, зеро мо танҳо як iterator сохтаем, ба ҷои истифода аз он.Тартибдиҳанда моро дар бораи ин гуна рафтор огоҳ мекунад:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Усули идеологии навиштани [`map`] барои таъсири манфии он истифодаи ҳалқаи `for` ё бо усули [`for_each`] даъват кардан аст:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Усули дигари маъмули арзёбии итератор истифодаи усули [`collect`] барои сохтани коллексияи нав мебошад.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Итераторҳо набояд маҳдуд бошанд.Мисол, диапазони кушод як такрори беохир аст:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Истифодаи адаптери итератори [`take`] барои табдилдиҳандаи беохир ба як ниҳоӣ маъмул аст:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Ин рақамҳои `0` то `4`-ро, ки ҳар кадоме дар сатри худ чоп мекунад.
//!
//! Дар хотир доред, ки усулҳо дар итераторҳои беохир, ҳатто онҳое, ки натиҷаҳояшонро дар муддати ниҳоӣ математикӣ муайян кардан мумкин аст, қатъ намешавад.
//! Махсусан, усулҳое, ба монанди [`min`], ки дар сурати умум убур кардани ҳар як унсури такрорро талаб мекунанд, эҳтимолан барои ягон такрори беохир бармегарданд.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Оҳ не!Доираи беохир!
//! // `ones.min()` боиси ҳалқаи бепоён мегардад, бинобар ин мо ба ин нуқта намерасем!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;