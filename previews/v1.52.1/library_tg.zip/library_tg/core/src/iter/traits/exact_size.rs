/// Итераторе, ки дарозии дақиқи онро медонад.
///
/// Бисёриҳо ["Итератор"] намедонанд, ки чанд маротиба такрор мешаванд, аммо баъзеҳо.
/// Агар итератор медонад, ки чанд маротиба такрор кардан мумкин аст, дастрасӣ ба ин маълумот муфид буда метавонад.
/// Масалан, агар шумо хоҳед, ки ба қафо такрор кунед, оғози хуб донистани он аст, ки охири он дар куҷост.
///
/// Ҳангоми татбиқи `ExactSizeIterator`, шумо инчунин бояд [`Iterator`]-ро татбиқ кунед.
/// Ҳангоми иҷрои ин, татбиқи [`Iterator::size_hint`]*бояд* андозаи дақиқи такроркунандаро баргардонад.
///
/// Усули [`len`] дорои татбиқи пешфарз мебошад, бинобар ин шумо одатан онро амалӣ намекунед.
/// Аммо, шумо метавонед иҷроиши нисбатан муқаррариро нисбат ба пешфарз таъмин намоед, бинобар ин дар ин ҳолат бекор кардани он маъно дорад.
///
///
/// Дар хотир доред, ки ин trait як trait-и бехатар аст ва аз ин рӯ, дурустии дарозии баргаштаро кафолат дода наметавонад *ва* наметавонад.
/// Ин маънои онро дорад, ки рамзи `unsafe`**набояд** ба дурустии [`Iterator::size_hint`] такя кунад.
/// [`TrustedLen`](super::marker::TrustedLen) trait ноустувор ва хатарнок ба ин кафолати иловагӣ медиҳад.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// // диапазони маҳдуд дақиқ медонад, ки чанд маротиба такрор мешавад
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Дар [module-level docs], мо як [`Iterator`] амалӣ кардем, `Counter`.
/// Биёед `ExactSizeIterator`-ро барои он татбиқ намоем:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Мо метавонем шумораи боқимондаи такрориҳоро ба осонӣ ҳисоб кунем.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Ва ҳоло мо метавонем онро истифода барем!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Дарозии дақиқи такрорро бармегардонад.
    ///
    /// Амалисозӣ кафолат медиҳад, ки iterator пеш аз баргардонидани [`None`] дақиқтар аз `len()` арзиши [`Some(T)`] бармегардад.
    ///
    /// Ин усул татбиқи пешфарз дорад, бинобар ин шумо одатан онро мустақиман иҷро намекунед.
    /// Аммо, агар шумо як татбиқи самараноктарро таъмин карда тавонед, шумо инро карда метавонед.
    /// Барои мисол ба ҳуҷҷатҳои [trait-level] нигаред.
    ///
    /// Ин вазифа ҳамон кафолати бехатариро дорад, ки вазифаи [`Iterator::size_hint`] дорад.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // диапазони маҳдуд дақиқ медонад, ки чанд маротиба такрор мешавад
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ин изҳорот аз ҳад зиёд мудофиа аст, аммо инвариантро месанҷад
        // аз ҷониби trait кафолат дода шудааст.
        // Агар ин trait rust-дохилӣ мебуд, мо метавонем debug_assert истифода барем !;assert_eq!инчунин ҳамаи татбиқи корбарони Rust-ро месанҷад.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// `true`-ро бармегардонад, агар итератор холӣ бошад.
    ///
    /// Ин усул дорои истифодаи пешфарз бо истифодаи [`ExactSizeIterator::len()`] мебошад, бинобар ин ба шумо лозим нест, ки онро худатон татбиқ кунед.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}