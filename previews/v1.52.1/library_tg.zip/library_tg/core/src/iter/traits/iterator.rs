// ignore-tidy-filelength Ин файл тақрибан танҳо аз таърифи `Iterator` иборат аст.
// Мо онро ба якчанд файл тақсим карда наметавонем.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Интерфейс барои мубориза бо итераторҳо.
///
/// Ин iterator асосии trait аст.
/// Барои маълумоти бештар дар бораи мафҳуми итераторҳо, ба [module-level documentation] нигаред.
/// Аз ҷумла, шумо метавонед донистани тарзи [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Навъи унсурҳо, ки такрор мешаванд.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Итератори пешрафта ва арзиши навбатиро бар мегардонад.
    ///
    /// Пас аз ба охир расидани такроркунӣ, [`None`]-ро бармегардонад.
    /// Татбиқи инфиродии итератор метавонад дубора такрорро интихоб кунад ва аз ин рӯ дубора ба `next()` занг задан мумкин аст ё дар ниҳоят бозгашти [`Some(Item)`]-ро оғоз намекунад.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Занг ба next() арзиши навбатиро бар мегардонад ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ва он гоҳ Ҳеҷ гоҳ як бор ба охир расид.
    /// assert_eq!(None, iter.next());
    ///
    /// // Зангҳои зиёд метавонанд `None`-ро баргардонанд ё барнагардонанд.Дар ин ҷо, онҳо ҳамеша хоҳанд кард.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Ҳудуди дарозии боқимондаи такрорро бармегардонад.
    ///
    /// Махсусан, `size_hint()` кортежро бармегардонад, ки элементи аввал ҳудуди поён ва унсури дуюм ҳудуди боло аст.
    ///
    /// Нимаи дуюми корт, ки баргардонида мешавад, ["Опсия"] "<" ["usize`]">"мебошад.
    /// A [`None`] дар ин ҷо маънои онро дорад, ки ё ҳудуди болоии маълум вуҷуд надорад, ё ҳудуди болотар аз [`usize`] калонтар аст.
    ///
    /// # Эзоҳҳои татбиқ
    ///
    /// Он татбиқ карда намешавад, ки татбиқи iterator шумораи эъломшудаи унсурҳоро медиҳад.Итератори ароба метавонад аз ҳудуди поён камтар ё аз ҳудуди болоии элементҳо бештар ҳосил диҳад.
    ///
    /// `size_hint()` пеш аз ҳама пешбинӣ шудааст, ки барои оптимизатсияҳо, аз қабили ҷойгоҳ барои унсурҳои итератор ҷой гирад, аммо ба онҳо боварӣ надоранд, масалан, чекҳои ҳудудро дар рамзи хатарнок.
    /// Татбиқи нодурусти `size_hint()` набояд боиси вайрон кардани бехатарии хотира гардад.
    ///
    /// Гуфта мешавад, ки татбиқ бояд тахмини дурустро пешниҳод кунад, зеро дар акси ҳол ин вайрон кардани протоколи trait хоҳад буд.
    ///
    /// Амалисозии пешфарз "(0,` ["None`]")"-ро бар мегардонад, ки барои ҳар як итератор дуруст аст.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Мисоли мураккабтар:
    ///
    /// ```
    /// // Рақамҳои ҷуфт аз сифр то даҳ.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Мо метавонем аз сифр то даҳ маротиба такрор шавем.
    /// // Донистани он ки ин панҷ аст, бидуни иҷро кардани filter() ғайриимкон аст.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Биёед бо chain() панҷ рақами дигарро илова кунем
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ҳоло ҳарду ҳудуд панҷто афзоиш ёфтааст
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Бозгашти `None` барои ҳудуди боло:
    ///
    /// ```
    /// // итератори бепоён ҳудуди болоӣ ва сарҳади ҳадди имконпазири имконпазирро надорад
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Итераторро истеъмол мекунад, шумораи такрорҳоро ҳисоб карда, бармегардонад.
    ///
    /// Ин усул то он даме, ки [`None`] дучор ояд, такроран ба [`next`] занг мезанад ва миқдори маротиба [`Some`]-ро дидааст.
    /// Дар хотир доред, ки [`next`] бояд ҳадди аққал як маротиба даъват карда шавад, ҳатто агар iterator ягон унсур надошта бошад.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Рафтор
    ///
    /// Усул аз пур шудани об ҳифз намекунад, аз ин рӯ ҳисоб кардани унсурҳои такрори дорои зиёда аз [`usize::MAX`] элемент натиҷаи нодуруст медиҳад ё panics.
    ///
    /// Агар тасдиқи ислоҳот фаъол карда шавад, panic кафолат дода мешавад.
    ///
    /// # Panics
    ///
    /// Ин функсия метавонад panic бошад, агар iterator зиёда аз [`usize::MAX`] унсур дошта бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Итераторро истеъмол мекунад, ва элементи охиринро бармегардонад.
    ///
    /// Ин усул такроркунандаро то баргаштани [`None`] арзёбӣ мекунад.
    /// Ҳангоми иҷрои он, унсури ҷориро пайгирӣ мекунад.
    /// Пас аз баргардонидани [`None`], `last()` пас аз охирин унсури дидаашро бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Итераторро бо унсурҳои `n` пеш мебарад.
    ///
    /// Ин усул бо ҷидду ҷаҳд унсурҳои `n`-ро бо занг задан ба [`next`] то `n` то [`None`] гузарад.
    ///
    /// `advance_by(n)` [`Ok(())`][Ok]-ро бармегардонад, агар итератор аз ҷониби унсурҳои `n` бомуваффақият пеш равад ё [`Err(k)`][Err] дар сурати дучор омадани [`None`], ки `k` миқдори унсурҳои итератори пеш аз тамом шудани унсурҳо мебошад (яъне
    /// дарозии такрори).
    /// Дар хотир доред, ки `k` ҳамеша камтар аз `n` аст.
    ///
    /// Занги `advance_by(0)` ягон унсурро масраф намекунад ва ҳамеша [`Ok(())`][Ok]-ро бармегардонад.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // танҳо `&4` гузаронида шуд
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Бозгаштан унсури `n`th iterator.
    ///
    /// Мисли аксари амалҳои индексатсия, ҳисобкунӣ аз сифр оғоз мешавад, аз ин рӯ `nth(0)` арзиши аввалро, `nth(1)` дуюмро бармегардонад ва ғайра.
    ///
    /// Дар хотир доред, ки ҳамаи унсурҳои қаблӣ, инчунин унсури баргардонидашуда аз такроркунак истеъмол карда мешаванд.
    /// Ин маънои онро дорад, ки унсурҳои қаблӣ ҳазф хоҳанд шуд ва инчунин ба `nth(0)` якчанд маротиба занг задан дар як итератор унсурҳои гуногунро бармегардонад.
    ///
    ///
    /// `nth()` [`None`]-ро бармегардонад, агар `n` аз дарозии такроркунанда зиёдтар ё баробар бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Занги чандкарата ба `nth()` такрори ақибро барнамегардонад:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Бозгашти `None` агар камтар аз унсурҳои `n + 1` вуҷуд дошта бошанд:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Итераторро аз ҳамон лаҳза оғоз мекунад, аммо дар ҳар такрор ба миқдори додашуда қадам мегузорад.
    ///
    /// Эзоҳ 1: Аввалин унсури итератор, новобаста аз қадами додашуда, ҳамеша баргардонида мешавад.
    ///
    /// Эзоҳ 2: Вақти кашидани элементҳои нодида собит нест.
    /// `StepBy` мисли пайдарпаии `next(), nth(step-1), nth(step-1),…` рафтор мекунад, аммо инчунин метавонад ба мисли пайдарпаӣ рафтор кунад
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Кадом роҳи истифодашаванда метавонад барои баъзе такроркунандагон бо сабабҳои иҷро тағйир ёбад.
    /// Роҳи дуюм iterator-ро пештар пеш хоҳад бурд ва метавонад ашёи бештарро истеъмол кунад.
    ///
    /// `advance_n_and_return_first` муодили:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Усул panic хоҳад буд, агар қадами додашуда `0` бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Ду такроркунандаро мегирад ва дар ҳарду пайдарпай такрори нав эҷод мекунад.
    ///
    /// `chain()` як итератори навро бармегардонад, ки он аввал бар арзишҳо аз итератори аввал ва сипас бар арзишҳои итератори дуюм такрор хоҳад шуд.
    ///
    /// Ба ибораи дигар, он дар як занҷир ду итераторро ба ҳам мепайвандад.🔗
    ///
    /// [`once`] одатан барои мутобиқ кардани арзиши ягона ба занҷири дигар намудҳои такрор истифода мешавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски далел ба `chain()` [`IntoIterator`]-ро истифода мебарад, мо метавонем ҳама чизеро ба [`Iterator`] табдил диҳем, на танҳо худи [`Iterator`].
    /// Масалан, иловаро (`&[T]`) [`IntoIterator`]-ро татбиқ мекунад ва ҳамин тавр ба `chain()` мустақиман интиқол дода мешавад:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Агар шумо бо Windows API кор кунед, шумо метавонед [`OsStr`]-ро ба `Vec<u16>` табдил диҳед:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// Ду такрорро ба як такрори ягонаи ҷуфт 'афзоиш диҳед'.
    ///
    /// `zip()` як итератори навро бармегардонад, ки бар ду такрори дигар такрор карда мешавад ва як тупле, ки дар он элементи аввал аз итератори аввал ва элементи дуюм аз итератори дуюм меояд, бармегардад.
    ///
    ///
    /// Ба ибораи дигар, он ду такрорро якҷоя ба як якто зип мекунад.
    ///
    /// Агар ҳарду итератор [`None`]-ро баргардонад, [`next`] аз итератори зипшуда [`None`]-ро бармегардонад.
    /// Агар итератори аввал [`None`] баргардонад, `zip` расиши кӯтоҳ мекунад ва `next` ба итератори дуюм даъват карда намешавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски далел ба `zip()` [`IntoIterator`]-ро истифода мебарад, мо метавонем ҳама чизеро ба [`Iterator`] табдил диҳем, на танҳо худи [`Iterator`].
    /// Масалан, иловаро (`&[T]`) [`IntoIterator`]-ро татбиқ мекунад ва ҳамин тавр ба `zip()` мустақиман интиқол дода мешавад:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` аст, аксар вақт истифода бурда мешавад як iterator беохир ба як ниҳоӣ.
    /// Ин кор барои он аст, ки итератори ниҳоӣ дар ниҳоят ба [`None`] бармегардад ва zipper ба охир мерасад.Zip бо `(0..)` метавонад ба [`enumerate`] монанд бошад:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Итератори нав месозад, ки нусхаи `separator`-ро дар байни ашёи ҳамшафати итератори аслӣ ҷойгир мекунад.
    ///
    /// Дар ҳолате ки `separator` [`Clone`]-ро иҷро намекунад ё бояд ҳар дафъа ҳисоб карда шавад, [`intersperse_with`]-ро истифода баред.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Аввалин унсури `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ҷудосози.
    /// assert_eq!(a.next(), Some(&1));   // Унсури навбатӣ аз `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ҷудосози.
    /// assert_eq!(a.next(), Some(&2));   // Унсури охирин аз `a`.
    /// assert_eq!(a.next(), None);       // Итератор тамом шуд.
    /// ```
    ///
    /// `intersperse` бо элементҳои маъмул ҳамроҳ кардани ашёи iterator метавонад муфид бошад:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Итератори навро эҷод мекунад, ки ашёеро, ки `separator` тавлид кардааст, дар байни ашёи шафати итератори аслӣ ҷойгир мекунад.
    ///
    /// Бастан дақиқ як маротиба дар ҳар як гузоштани ашё дар байни ду ашёи ҳамсоя аз итератори аслӣ номида мешавад;
    /// алалхусус, агар итератори аслӣ камтар аз ду адад ҳосил диҳад ва пас аз он ки банди охирин дода шавад, пӯшида номида намешавад.
    ///
    ///
    /// Агар ашёи iterator [`Clone`]-ро татбиқ кунад, истифодаи [`intersperse`] метавонад осонтар бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Аввалин унсури `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ҷудосози.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Унсури навбатӣ аз `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ҷудосози.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Унсури охирин аз `v`.
    /// assert_eq!(it.next(), None);               // Итератор тамом шуд.
    /// ```
    ///
    /// `intersperse_with` метавонад дар ҳолатҳое истифода шавад, ки ҷудосозро ҳисоб кардан лозим аст:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Бастан мутаносибан контексти худро барои тавлиди ашё қарз мегирад.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Бастанро мегирад ва як итераторро эҷод мекунад, ки ин пӯшишро ба ҳар як унсур даъват мекунад.
    ///
    /// `map()` бо як далели он як итераторро ба дигараш табдил медиҳад:
    /// чизе, ки [`FnMut`]-ро татбиқ мекунад.Он як итератори наверо истеҳсол мекунад, ки ин пӯшидашударо ба ҳар як унсури итератори аслӣ даъват мекунад.
    ///
    /// Агар шумо дар намудҳо хуб фикр кардан дошта бошед, шумо метавонед дар бораи `map()` чунин фикр кунед:
    /// Агар шумо як итераторе дошта бошед, ки ба шумо унсурҳои ягон намуди `A` диҳад ва шумо мехоҳед як итератори ягон намуди дигари `B`-ро истифода кунед, шумо метавонед `map()`-ро истифода баред, ки пӯшидаеро, ки `A` мегирад ва `B` бар мегардонад.
    ///
    ///
    /// `map()` аз ҷиҳати консептуалӣ ба ҳалқаи [`for`] монанд аст.Аммо, азбаски `map()` танбал аст, аз он беҳтар аст, вақте ки шумо аллакай бо дигар итераторҳо кор карда истодаед.
    /// Агар шумо ягон намуди давриро барои таъсири тараф иҷро кунед, истифодаи [`for`] нисбат ба `map()` idiomatic ҳисобида мешавад.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Агар шумо ягон намуди оқибате ба амал оред, ба [`for`] ба `map()` бартарӣ диҳед:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ин тавр накунед:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // онро ҳатто иҷро намекунад, зеро он танбал аст.Rust шуморо дар ин бора огоҳ мекунад.
    ///
    /// // Ба ҷои ин, барои:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Бастани ҳар як унсури итераторро даъват мекунад.
    ///
    /// Ин ба истифодаи ҳалқаи [`for`] дар итератор баробар аст, гарчанде ки `break` ва `continue` аз басташавӣ ғайриимкон мебошанд.
    /// Истифодаи ҳалқаи `for` одатан idiomatic аст, аммо ҳангоми коркарди ашё дар охири занҷирҳои дарозтар `for_each` метавонад равшантар бошад.
    ///
    /// Дар баъзе ҳолатҳо, `for_each` низ метавонад нисбат ба ҳалқа тезтар бошад, зеро он такрори дохилиро дар созгорҳо ба монанди `Chain` истифода мебарад.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Барои чунин мисоли хурд, ҳалқаи `for` метавонад тозатар бошад, аммо `for_each` метавонад услуби функсионалиро бо такрори дарозтар нигоҳ дорад:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Итераторро месозад, ки барои бастани элемент истифода мешавад.
    ///
    /// Бо назардошти унсур, басташавӣ бояд `true` ё `false`-ро баргардонад.Итератори баргашта танҳо унсурҳоеро медиҳад, ки басташуда ҳақиқӣ дорад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски бастани ба `filter()` додашуда истинод мегирад ва бисёр такроркунандагон бар истинодҳо такрор мешаванд, ин ба вазъияти эҳтимолан нофаҳмо оварда мерасонад, ки дар он навъи басташавӣ истиноди дугона аст:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ба ду * с лозим аст!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ин ба ҷои истифодаи тахрибкорӣ дар далел барои аз байн бурдани як чиз маъмул аст:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ҳам ва ва *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ё ҳарду:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ду &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// аз ин қабатҳои.
    ///
    /// Дар хотир доред, ки `iter.filter(f).next()` ба `iter.find(f)` баробар аст.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Итераторе месозад, ки ҳам филтрҳо ва ҳам харитаҳо.
    ///
    /// Итератори баргашта танҳо "арзиши" медиҳад, ки бастани додашуда `Some(value)` бармегардонад.
    ///
    /// `filter_map` барои сохтани занҷирҳои [`filter`] ва [`map`] истифода бурда мешавад.
    /// Мисоли дар поён овардашуда нишон медиҳад, ки чӣ гуна `map().filter().map()`-ро бо як занг ба `filter_map` кӯтоҳ кардан мумкин аст.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ин ҳамон мисол аст, аммо бо [`filter`] ва [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Итератор месозад, ки ҳисобкунии такрори ҷорӣ ва инчунин арзиши навбатиро медиҳад.
    ///
    /// Итератори баргашта ҷуфти `(i, val)` медиҳад, ки дар он `i` индекси ҷории такрор аст ва `val` ин арзиши баргардондашуда мебошад.
    ///
    ///
    /// `enumerate()` ҳисобро ҳамчун [`usize`] нигоҳ медорад.
    /// Агар шумо хоҳед, ки бо бутуни андозааш гуногун ҳисоб кунед, функсияи [`zip`] ба ин монанд имконият фароҳам меорад.
    ///
    /// # Рафтор
    ///
    /// Усул аз пур шудани об муҳофизат намекунад, аз ин рӯ номбар кардани зиёда аз [`usize::MAX`] элемент ё натиҷаи нодуруст медиҳад ё panics.
    /// Агар тасдиқи ислоҳот фаъол карда шавад, panic кафолат дода мешавад.
    ///
    /// # Panics
    ///
    /// Итератори баргашта метавонад panic, агар индекси баргардонида мешударо аз [`usize`] пур кунад.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Итератор месозад, ки метавонад [`peek`]-ро истифода барад, то унсури навбатии iterator-ро бе истеъмол дида барояд.
    ///
    /// Ба итератор усули [`peek`] илова мекунад.Барои маълумоти иловагӣ ба ҳуҷҷатҳои он нигаред.
    ///
    /// Аҳамият диҳед, ки итератори аслӣ ҳангоми бори аввал даъват шудани [`peek`] пешрафта мешавад: Бо мақсади ба даст овардани унсури навбатӣ, [`next`] ба итератори аслӣ даъват карда мешавад, аз ин рӯ ҳама гуна таъсирот (яъне
    ///
    /// чизе ғайр аз гирифтани арзиши навбатӣ) усули [`next`] рух медиҳад.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ба мо имкон медиҳад, ки дар future бубинем
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // мо метавонем якчанд маротиба peek() кунем, iterator пеш намеравад
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // пас аз ба охир расидани iterator, инчунин peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Итераторе месозад, ки ['гузаред'] унсурҳои дар асоси предикат асосёфта.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` басташударо ҳамчун далел қабул мекунад.Он ин пӯшидашударо ба ҳар як унсури итератор даъват мекунад ва унсурҳоро то баргаштани `false` сарфи назар мекунад.
    ///
    /// Пас аз баргардонидани `false`, кори `skip_while()`'s ба итмом мерасад ва боқимондаи элементҳо дода мешаванд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски бастани ба `skip_while()` додашуда истинод мегирад ва бисёр такрориҳо бар истинодҳо такрор мешаванд, ин ба вазъияти эҳтимолан нофаҳмо оварда мерасонад, ки дар он навъи далели басташавӣ истиноди дугона аст:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ба ду * с лозим аст!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Қатъи пас аз `false` ибтидоӣ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // дар ҳоле ки ин дурӯғ мебуд, зеро мо аллакай дурӯғ гирифтаем, skip_while() дигар истифода намешавад
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Итераторе месозад, ки дар асоси предикат унсурҳо медиҳад.
    ///
    /// `take_while()` басташударо ҳамчун далел қабул мекунад.Он ин пӯшидашударо ба ҳар як унсури итератор даъват мекунад ва ҳангоми баргардонидани `true` унсурҳои ҳосилнокиро фароҳам меорад.
    ///
    /// Пас аз баргардонидани `false`, кори `take_while()`'s ба итмом мерасад ва боқимондаи элементҳо сарфи назар карда мешаванд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски бастани ба `take_while()` додашуда истинод мегирад ва бисёр такроркунандагон бар истинодҳо такрор мешаванд, ин ба вазъияти эҳтимолан нофаҳмо оварда мерасонад, ки дар он навъи басташавӣ истиноди дугона аст:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ба ду * с лозим аст!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Қатъи пас аз `false` ибтидоӣ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Мо бештар унсурҳое дорем, ки аз сифр камтаранд, аммо азбаски мо аллакай дурӯғ гирифтаем, take_while() дигар истифода намешавад
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Азбаски `take_while()` бояд арзиши онро дида барояд, то бубинад, ки оё он бояд дохил карда шавад ё не, истеъмолкунандагони такрори он мебинанд, ки он нест карда шудааст:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` акнун дар он ҷо нест, зеро он бо мақсади дидани он, ки такроркунӣ бояд қатъ карда шавад, истеъмол карда шуд, аммо боз ба такроркунак ҷойгир карда нашуд.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Итераторе месозад, ки ҳам элементҳоро дар асоси предикат ва харитаҳо ҳосил кунад.
    ///
    /// `map_while()` басташударо ҳамчун далел қабул мекунад.
    /// Он ин пӯшидашударо ба ҳар як унсури итератор даъват мекунад ва ҳангоми баргардонидани [`Some(_)`][`Some`] унсурҳои ҳосилнокиро фароҳам меорад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ин ҳамон мисол аст, аммо бо [`take_while`] ва [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Қатъи пас аз [`None`] ибтидоӣ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Мо унсурҳои бештаре дорем, ки метавонанд ба u32 дохил шаванд (4, 5), аммо `map_while` барои `-3` `None`-ро баргардонд (чунки `predicate` `None`-ро баргардонид) ва `collect` дар аввалин `None` дучор меистад.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Азбаски `map_while()` бояд арзиши онро дида барояд, то бубинад, ки оё он бояд дохил карда шавад ё не, истеъмолкунандагони такрори он мебинанд, ки он нест карда шудааст:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` акнун дар он ҷо нест, зеро он бо мақсади дидани он, ки такроркунӣ бояд қатъ карда шавад, истеъмол карда шуд, аммо боз ба такроркунак ҷойгир карда нашуд.
    ///
    /// Дар хотир доред, ки бар хилофи [`take_while`] ин итератор ** пухта нашудааст.
    /// Инчунин муайян карда нашудааст, ки ин итератор пас аз баргардонидани [`None`] аввал чӣ бармегардад.
    /// Агар ба шумо як итератори пошидашуда лозим бошад, [`fuse`]-ро истифода баред.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Итераторе месозад, ки аввалин унсурҳои `n`-ро гузарад.
    ///
    /// Пас аз истеъмол, унсурҳои боқимонда дода мешаванд.
    /// Ба ҷои аз даст додани ин усул мустақиман, ба ҷои усули `nth` бекор кунед.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Итератори эҷод мекунад, ки аввалин унсурҳои `n`-ро медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` аксар вақт бо такрори беохир истифода мешавад, то онро маҳдуд кунад:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Агар камтар аз `n` унсур мавҷуд бошад, `take` худро бо андозаи такрори аслӣ маҳдуд мекунад:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Як адаптери такрорӣ ба [`fold`] монанд аст, ки ҳолати дохилиро нигоҳ медорад ва як итератори навро истеҳсол мекунад.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ду далел мегирад: арзиши ибтидоӣ, ки ҳолати дохилиро месозад ва басташавӣ бо ду далел, аввал истиноди тағиршаванда ба ҳолати дохилӣ ва дуввум унсури итератор.
    ///
    /// Бастан метавонад ба ҳолати дохилӣ таъин карда шавад, то ҳолати такрориро тақсим кунанд.
    ///
    /// Ҳангоми такрор, пӯшидан ба ҳар як унсури такрор истифода мешавад ва арзиши баргардонидан аз пӯшидан, [`Option`] аз ҷониби такрори дода мешавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ҳар як такроркунӣ, мо ҳолатро ба унсур зарб хоҳем кард
    ///     *state = *state * x;
    ///
    ///     // пас, мо радди давлатро ба даст меорем
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Итераторе месозад, ки ба монанди харита кор кунад, аммо сохтори лонаҳоро ҳамвор кунад.
    ///
    /// Адаптери [`map`] хеле муфид аст, аммо танҳо вақте ки далели басташавӣ арзишҳоро ба бор меорад.
    /// Агар он ба ҷои он як итератор истеҳсол кунад, қабати иловагии бавосита вуҷуд дорад.
    /// `flat_map()` худ ин қабати иловагиро нест мекунад.
    ///
    /// Шумо метавонед `flat_map(f)`-ро ҳамчун эквиваленти семантикии [`map`] ping ва сипас [` flatten '] ing дар `map(f).flatten()` тасаввур кунед.
    ///
    /// Усули дигари фикрронӣ дар бораи `flat_map()`: бастани ["map`] барои ҳар як унсур як адад бармегардонад ва пӯшидани `flat_map()`'s барои ҳар як унсур итераторро бар мегардонад.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator бармегардонад
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Итераторе месозад, ки сохтори лонаҳоро ҳамвор мекунад.
    ///
    /// Ин вақте муфид аст, ки шумо як итератори итераторҳо ё итератори чизҳое, ки ба итераторҳо табдил дода мешаванд ва шумо мехоҳед як сатҳи ғайримустақимро хориҷ кунед.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Харитасозӣ ва сипас ҳамворкунӣ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator бармегардонад
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Шумо инчунин метавонед инро дар робита ба [`flat_map()`] нависед, ки дар ин ҳолат афзалтар аст, зеро он ниятро ба таври равшантар баён мекунад:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iterator бармегардонад
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ҳамворкунӣ танҳо як сатҳи лонаҳоро дар як вақт хориҷ мекунад:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Дар ин ҷо мо мебинем, ки `flatten()` ҳамворкунии "deep"-ро иҷро намекунад.
    /// Ба ҷои ин, танҳо як сатҳи лона хориҷ карда мешавад.Яъне, агар шумо массиви сеандозаро `flatten()` кунед, натиҷа дуандоза хоҳад буд, на як ченак.
    /// Барои ба даст овардани сохтори якандоза, шумо бояд дубора `flatten()` кунед.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Итераторе месозад, ки пас аз [`None`] аввал ба итмом мерасад.
    ///
    /// Пас аз баргардонидани итератор [`None`], зангҳои future метавонанд боз [`Some(T)`] надиҳанд ё надиҳанд.
    /// `fuse()` итераторро мутобиқ мекунад ва кафолат медиҳад, ки пас аз додани [`None`], он ҳамеша [`None`] то абад бармегардад.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // iterator, ки дар байни Баъзе ва Ҳеҷ мубаддал мешавад
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // агар ин ҳам бошад, Some(i32), вагарна Ҳеҷ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // мо мебинем, ки итератори мо пасу пеш меравад
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Бо вуҷуди ин, вақте ки мо онро пайваст мекунем ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // он пас аз бори аввал ҳамеша `None` бармегардад.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Бо ҳар як унсури итератор чизе иҷро мекунад ва арзиши онро мегузаронад.
    ///
    /// Ҳангоми истифодаи итераторҳо, шумо аксар вақт якчанди онҳоро ба ҳам занед.
    /// Ҳангоми кор бо чунин рамз, шумо метавонед тафтиш кунед, ки дар қисматҳои гуногуни лӯла чӣ рӯй медиҳад.Барои ин, ба `inspect()` занг занед.
    ///
    /// Барои `inspect()` ҳамчун асбоби ислоҳсозӣ истифода шудан нисбат ба мавҷудияти рамзи ниҳоии шумо маъмултар аст, аммо барномаҳо метавонанд онро дар ҳолатҳои муайяне пайдо кунанд, ки хатогиҳо пеш аз партофтан сабт карда шаванд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ин пайдарпаии iterator мураккаб аст.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // биёед якчанд зангҳои inspect()-ро барои таҳқиқи воқеаҳо илова кунем
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Ин чоп мекунад:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Пеш аз он ки хатогиҳоро сабт кунед:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Ин чоп мекунад:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Ба ҷои истеъмол кардани он, iterator қарз мегирад.
    ///
    /// Ин барои иҷозат додан ба корбурди созгорҳои итератор ҳангоми фоидаи моликияти итератори аслӣ муфид аст.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // агар мо бори дигар кӯшиш кунем, ки iter-ро истифода барем, он кор нахоҳад кард.
    /// // Дар сатри зерин "хато: истифодаи арзиши интиқол дода мешавад: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // биёед инро бори дигар санҷем
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ба ҷои ин, мо дар як .by_ref() илова
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ҳоло ин хуб аст:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Итераторро ба маҷмӯа табдил медиҳад.
    ///
    /// `collect()` метавонад ҳама чизи такроршавандаро гирад ва онро ба маҷмӯаи мувофиқ табдил диҳад.
    /// Ин яке аз усулҳои пурқувват дар китобхонаи стандартӣ мебошад, ки дар заминаҳои гуногун истифода мешаванд.
    ///
    /// Намунаи оддитарин, ки дар он `collect()` истифода мешавад, табдил додани як коллексия ба дигараш аст.
    /// Шумо коллексия мегиред, ба он [`iter`] занг мезанед, як даста тағиротҳоро анҷом медиҳед ва пас дар охири он `collect()`.
    ///
    /// `collect()` инчунин метавонад мисолҳои намудҳоеро эҷод кунад, ки маҷмӯаҳои маъмулӣ нестанд.
    /// Масалан, [`String`]-ро аз [`char`] s сохтан мумкин аст ва такрори ашёи [`Result<T, E>`][`Result`] метавонад ба `Result<Collection<T>, E>` ҷамъоварӣ карда шавад.
    ///
    /// Барои гирифтани маълумоти бештар аз мисолҳои зер нигаред.
    ///
    /// Азбаски `collect()` хеле умумӣ аст, он метавонад бо хулосабарории намуд мушкилот пеш орад.
    /// Ҳамин тавр, `collect()` яке аз чанд маротибаест, ки шумо синтаксисро бо муҳаббат бо номи 'turbofish' мебинед: `::<>`.
    /// Ин ба алгоритми хулоса кӯмак мекунад, ки мушаххас фаҳманд, ки кадом коллексияро ҷамъ кардан мехоҳед.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Дар хотир доред, ки ба мо `: Vec<i32>` дар тарафи чап лозим буд.Ин аз он сабаб аст, ки мо метавонистем ба ҷои [`VecDeque<T>`] ба ҷои он ҷамъ оварем:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Истифодаи 'turbofish' ба ҷои шарҳи `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Азбаски `collect()` танҳо дар бораи он чизе, ки шумо ҷамъ меоваред, ғамхорӣ мекунад, шумо метавонед бо як ишораи навъи қисман, `_` бо турбофиш истифода баред:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Истифодаи `collect()` барои сохтани [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Агар шумо рӯйхати [`Натиҷа<T, E>`][`Result`] s, шумо метавонед `collect()`-ро истифода баред, то бубинед, ки ягонтои онҳо ноком шудааст:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // хатои аввалро ба мо медиҳад
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // рӯйхати ҷавобҳоро ба мо медиҳад
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Итераторро истеъмол мекунад ва аз он ду маҷмӯа эҷод мекунад.
    ///
    /// Предикате, ки ба `partition()` гузаштааст, метавонад `true` ё `false`-ро баргардонад.
    /// `partition()` як ҷуфтро бармегардонад, ҳамаи унсурҳое, ки барои он `true` баргардонида шудаанд ва ҳамаи унсурҳое, ки барои он `false` баргаштанд.
    ///
    ///
    /// Инчунин нигаред ба [`is_partitioned()`] ва [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Элементҳои ин итераторро *дар ҷои худ* мувофиқи предикати додашуда тағир медиҳад, ба тавре ки ҳамаи онҳое, ки `true`-ро бармегардонанд, аз ҳамаи онҳое, ки `false`-ро бармегардонанд.
    ///
    /// Шумораи `true` элементҳои баргаштаро бар мегардонад.
    ///
    /// Тартиби нисбии ашёи тақсимшуда риоя намешавад.
    ///
    /// Инчунин нигаред ба [`is_partitioned()`] ва [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Тақсимот дар ҷойгоҳ байни ҷуфтҳо ва эҳтимолият
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: оё мо дар бораи пур шудани шумора хавотир шавем?Ягона роҳи ба даст овардани бештар аз
        // `usize::MAX` Истинодҳои тағирёбанда бо ZSTs мебошанд, ки барои тақсимкунӣ муфид нестанд ...

        // Ин вазифаҳои бастани "factory" барои пешгирӣ аз саховатмандӣ дар `Self` мавҷуданд.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Такроран `false`-и аввалро пайдо кунед ва бо `true` охир иваз кунед.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Тафтиш мекунад, ки оё унсурҳои ин итератор мувофиқи предикати додашуда тақсим шудаанд, ба тавре ки ҳамаи онҳое, ки `true`-ро бармегардонанд, аз ҳамаи онҳое, ки `false`-ро бармегардонанд.
    ///
    ///
    /// Инчунин нигаред ба [`partition()`] ва [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ё ҳама ашёҳо `true`-ро месанҷанд, ё банди аввал дар `false` меистад ва мо месанҷем, ки пас аз он дигар ашёи `true` нест.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Усули такрорие, ки функсияро татбиқ мекунад, то даме ки он бомуваффақият баргардад ва арзиши ягонаи ниҳоиро тавлид кунад.
    ///
    /// `try_fold()` ду далел мегирад: арзиши ибтидоӣ ва басташавӣ бо ду далел: 'accumulator' ва унсур.
    /// Бастан ё бомуваффақият бармегардад, бо қимате, ки аккумулятор бояд барои такрори навбатӣ дошта бошад, ё нокомиро бармегардонад, бо арзиши хатогие, ки фавран ба зангзан паҳн карда мешавад (short-circuiting).
    ///
    ///
    /// Арзиши ибтидоӣ он арзиши он аст, ки аккумулятор ҳангоми занги аввал хоҳад дошт.Агар татбиқи бастани бар зидди ҳар як унсури iterator муваффақ шуда бошад, `try_fold()` аккумуляторро ҳамчун муваффақият бармегардонад.
    ///
    /// Пӯшиш ҳар вақте муфид аст, ки шумо чизе ҷамъоварӣ кунед ва мехоҳед аз он арзиши ягонае ба даст оред.
    ///
    /// # Эзоҳ ба иҷрокунандагон
    ///
    /// Якчанд усули дигари (forward) дар робита бо ин татбиқи пешфарзӣ доранд, бинобарин кӯшиш кунед, ки инро ба таври возеҳ татбиқ кунед, агар он метавонад чизе беҳтар аз татбиқи ҳалли пешфарзии `for` кунад.
    ///
    /// Аз ҷумла, кӯшиш кунед, ки ин занги `try_fold()` дар қисмҳои дохилие, ки ин итератор иборат аст, бошад.
    /// Агар зангҳои зиёд лозим оянд, оператори `?` метавонад барои занҷири арзиши аккумулятор қулай бошад, аммо аз ҳар гуна инвариантҳое эҳтиёт шавед, ки пеш аз бозгашти барвақт бояд дастгирӣ карда шаванд.
    /// Ин усули `&mut self` аст, бинобар ин пас аз хатогӣ дар ин ҷо такрор бояд дубора барқарор карда шавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ҷамъи санҷидашудаи ҳамаи элементҳои массив
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ин маблағ ҳангоми илова кардани 100 элемент лабрез мешавад
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Азбаски он кӯтоҳ аст, унсурҳои боқимонда то ҳол тавассути iterator дастрасанд.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Усули такрорие, ки ба ҳар як унсури такрори функсияи хато татбиқ мекунад, дар хатогии аввал истода, ин хаторо бармегардонад.
    ///
    ///
    /// Инро метавон ҳамчун шакли хатоёфтаи [`for_each()`] ё нусхаи бешаҳрвандии [`try_fold()`] ҳисоб кард.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Он ноқилҳои барқро кӯтоҳ кардааст, бинобар ин ашёи боқимонда то ҳол дар iterator ҳастанд:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Ҳар як элементро бо истифода аз амалиёт ба аккумулятор печонида, натиҷаи ниҳоиро бармегардонад.
    ///
    /// `fold()` ду далел мегирад: арзиши ибтидоӣ ва басташавӣ бо ду далел: 'accumulator' ва унсур.
    /// Бастан арзиши барқароршударо барои такрори навбатӣ бармегардонад.
    ///
    /// Арзиши ибтидоӣ он арзиши он аст, ки аккумулятор ҳангоми занги аввал хоҳад дошт.
    ///
    /// Пас аз татбиқи ин басташавӣ ба ҳар як унсури итератор, `fold()` аккумуляторро бармегардонад.
    ///
    /// Ин амалиётро баъзан 'reduce' ё 'inject' меноманд.
    ///
    /// Пӯшиш ҳар вақте муфид аст, ки шумо чизе ҷамъоварӣ кунед ва мехоҳед аз он арзиши ягонае ба даст оред.
    ///
    /// Note: `fold()` ва усулҳои ба он монанд, ки тамоми итераторро тай мекунанд, барои итераторҳои беохир, ҳатто дар traits, ки натиҷаашон дар вақти ниҳоӣ муайян карда мешавад, қатъ шуда наметавонанд.
    ///
    /// Note: [`reduce()`] метавонад барои истифодаи унсури аввал ҳамчун арзиши ибтидоӣ истифода шавад, агар навъи аккумулятор ва навъи ашё яксон бошад.
    ///
    /// # Эзоҳ ба иҷрокунандагон
    ///
    /// Якчанд усули дигари (forward) дар робита бо ин татбиқи пешфарзӣ доранд, бинобарин кӯшиш кунед, ки инро ба таври возеҳ татбиқ кунед, агар он метавонад чизе беҳтар аз татбиқи ҳалли пешфарзии `for` кунад.
    ///
    ///
    /// Аз ҷумла, кӯшиш кунед, ки ин занги `fold()` дар қисмҳои дохилие, ки ин итератор иборат аст, бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ҷамъи ҳамаи элементҳои массив
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Биёед ҳар як қадами такрорро дар ин ҷо гузарем:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Ва ҳамин тавр, натиҷаи ниҳоии мо, `6`.
    ///
    /// Ин барои одамоне, ки такроркунандагонро зиёд истифода накардаанд, истифодаи ҳалқаи `for` бо рӯйхати чизҳо барои сохтани натиҷа маъмул аст.Онҳоро ба `fold()`s табдил додан мумкин аст:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // барои ҳалқа:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // онҳо ҳамонанд
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Бо такрор ба такрор амали камкунӣ унсурҳоро ба як коҳиш медиҳад.
    ///
    /// Агар iterator холӣ бошад, [`None`] бармегардад;дар акси ҳол, натиҷаи коҳишро бармегардонад.
    ///
    /// Барои такроркунандагоне, ки ҳадди аққал як унсур доранд, ин ҳамон тавре ки [`fold()`] бо унсури якуми итератор ҳамчун арзиши ибтидоӣ мебошад, ҳар як элементи минбаъдаро ба он мепечонад.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Арзиши ниҳоиро ёбед:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Санҷед, ки агар ҳар як унсури итератор бо предикат мувофиқат кунад.
    ///
    /// `all()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.Он ин басташударо ба ҳар як унсури итератор татбиқ мекунад ва агар ҳамаи онҳо `true` баргарданд, пас `all()` низ чунин аст.
    /// Агар касе аз онҳо `false`-ро баргардонад, он `false`-ро бармегардонад.
    ///
    /// `all()` расиши кӯтоҳ аст;ба ибораи дигар, он баробари пайдо кардани `false` коркардро қатъ мекунад, бо назардошти он, ки новобаста аз он чӣ рӯй диҳад, натиҷа низ `false` хоҳад буд.
    ///
    ///
    /// Итератори холӣ `true`-ро бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Боздоштан дар аввалин `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Санҷед, ки ягон унсури итератор бо предикат мувофиқат мекунад.
    ///
    /// `any()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.Он ин пӯшидашударо ба ҳар як унсури итератор татбиқ мекунад ва агар касе аз онҳо `true` баргардонад, пас `any()` низ чунин аст.
    /// Агар ҳамаи онҳо `false` баргарданд, он `false` бармегардад.
    ///
    /// `any()` расиши кӯтоҳ аст;ба ибораи дигар, он баробари пайдо кардани `true` коркардро қатъ мекунад, бо назардошти он, ки новобаста аз он чӣ рӯй диҳад, натиҷа низ `true` хоҳад буд.
    ///
    ///
    /// Итератори холӣ `false`-ро бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Боздоштан дар аввалин `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Ҷустуҷӯи унсури итератор, ки предикатро қонеъ мекунад.
    ///
    /// `find()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.
    /// Он ин пӯшидашударо ба ҳар як унсури итератор татбиқ мекунад ва агар касе аз онҳо `true`-ро баргардонад, пас `find()` [`Some(element)`]-ро бармегардонад.
    /// Агар ҳамаи онҳо `false` баргарданд, он [`None`] бармегардад.
    ///
    /// `find()` расиши кӯтоҳ аст;ба ибораи дигар, он пас аз баргардонидани басташавӣ `true` коркардро қатъ мекунад.
    ///
    /// Азбаски `find()` истинод мегирад ва бисёр такрориҳо бар истинодҳо такрор мешаванд, ин ба вазъияти эҳтимолан печида оварда мерасонад, ки далел истиноди дугона аст.
    ///
    /// Шумо ин таъсирро дар мисолҳои зер, бо `&&x` мебинед.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Боздоштан дар аввалин `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Дар хотир доред, ки `iter.find(f)` ба `iter.filter(f).next()` баробар аст.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Функсияро ба унсурҳои iterator татбиқ мекунад ва натиҷаи аввалини ғайри ҳеҷро бар мегардонад.
    ///
    ///
    /// `iter.find_map(f)` ба `iter.filter_map(f).next()` баробар аст.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Функсияро ба унсурҳои iterator татбиқ мекунад ва аввалин натиҷаи ҳақиқӣ ё хатои аввалро бар мегардонад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Ҷустуҷӯи элемент дар iterator, баргардонидани индекси он.
    ///
    /// `position()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.
    /// Он ин пӯшидашударо ба ҳар як унсури итератор татбиқ мекунад ва агар яке аз онҳо `true`-ро баргардонад, пас `position()` [`Some(index)`]-ро бармегардонад.
    /// Агар ҳамаашон ба `false` баргарданд, он ба [`None`] бармегардад.
    ///
    /// `position()` расиши кӯтоҳ аст;ба ибораи дигар, он баробари коркарди `true` коркардро қатъ мекунад.
    ///
    /// # Рафтор
    ///
    /// Усул аз пур шудани об муҳофизат намекунад, аз ин рӯ, агар зиёда аз [`usize::MAX`] унсурҳои номувофиқ вуҷуд дошта бошанд, он натиҷаи нодуруст медиҳад ё panics.
    ///
    /// Агар тасдиқи ислоҳот фаъол карда шавад, panic кафолат дода мешавад.
    ///
    /// # Panics
    ///
    /// Ин вазифа метавонад panic дошта бошад, агар итератор зиёда аз `usize::MAX` унсурҳои ба ҳам мувофиқат накунад.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Боздоштан дар аввалин `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Индекси баргашта аз ҳолати iterator вобаста аст
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Ҷустуҷӯи элемент дар iterator аз тарафи рост, баргардонидани индекси он.
    ///
    /// `rposition()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.
    /// Он ин пӯшидашударо ба ҳар як унсури итератор сар карда аз охир татбиқ мекунад ва агар яке аз онҳо `true` баргардонад, пас `rposition()` [`Some(index)`]-ро бармегардонад.
    ///
    /// Агар ҳамаашон ба `false` баргарданд, он ба [`None`] бармегардад.
    ///
    /// `rposition()` расиши кӯтоҳ аст;ба ибораи дигар, он баробари коркарди `true` коркардро қатъ мекунад.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Боздоштан дар аввалин `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Дар инҷо ба чеки изофӣ ниёзе нест, зеро `ExactSizeIterator` маънои онро дорад, ки шумораи элементҳо ба `usize` мувофиқат мекунанд.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Элементҳои максималии такроркунандаро бармегардонад.
    ///
    /// Агар якчанд унсурҳо ба ҳадди аксар баробар бошанд, охирин элемент баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Элементҳои ҳадди аққали итераторро бармегардонад.
    ///
    /// Агар якчанд унсур ба ҳадди аққал баробар бошанд, унсури аввал баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Элементеро бар мегардонад, ки аз функсияи муайян арзиши ҳадди аксарро медиҳад.
    ///
    ///
    /// Агар якчанд унсурҳо ба ҳадди аксар баробар бошанд, охирин элемент баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Элементеро бар мегардонад, ки нисбат ба функсияи муқоисаи муайян арзиши максималӣ медиҳад.
    ///
    ///
    /// Агар якчанд унсурҳо ба ҳадди аксар баробар бошанд, охирин элемент баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Элементеро бар мегардонад, ки аз функсияи муайян арзиши ҳадди ақалл медиҳад.
    ///
    ///
    /// Агар якчанд унсур ба ҳадди аққал баробар бошанд, унсури аввал баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Элементеро бар мегардонад, ки нисбат ба функсияи муқоисаи муайян арзиши ҳадди ақалл медиҳад.
    ///
    ///
    /// Агар якчанд унсур ба ҳадди аққал баробар бошанд, унсури аввал баргардонида мешавад.
    /// Агар iterator холӣ бошад, [`None`] баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Роҳнамои итераторро бармегардонад.
    ///
    /// Одатан, такроркунандагон аз чап ба рост такрор мешаванд.
    /// Пас аз истифодаи `rev()`, iterator ба ҷои он аз рост ба чап такрор хоҳад кард.
    ///
    /// Ин танҳо дар сурате имконпазир аст, ки агар итератор хотима дошта бошад, бинобар ин `rev()` танҳо дар [`DoubleEndedIterator`] s кор мекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Итератори ҷуфтҳоро ба ҷуфт контейнерҳо табдил медиҳад.
    ///
    /// `unzip()` тамоми такрори ҷуфтҳоро истеъмол мекунад, ки ду коллексия истеҳсол мекунад: яке аз элементҳои чапи ҷуфтҳо ва дигаре аз унсурҳои рост.
    ///
    ///
    /// Ин функсия, ба маънои муайяне, баръакси [`zip`] мебошад.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Итераторе месозад, ки ҳамаи унсурҳои онро нусхабардорӣ мекунад.
    ///
    /// Ин муфид аст, вақте ки шумо iterator аз `&T` болотар аст, аммо ба шумо iterator аз `T` лозим аст.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // нусхабардорӣ ҳамон .map(|&x| x) аст
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Итераторе месозад, ки ҳамаи унсурҳои онро ["клон"] кунад.
    ///
    /// Ин муфид аст, вақте ки шумо iterator аз `&T` болотар аст, аммо ба шумо iterator аз `T` лозим аст.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // клондашуда ҳамон тавре ки .map(|&x| x) аст, барои бутунҳо
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Итераторро беохир такрор мекунад.
    ///
    /// Ба ҷои он ки дар [`None`] таваққуф шавад, iterator ба ҷои он аз аввал оғоз хоҳад кард.Пас аз такрори дубора, он бори аввал дар аввал оғоз меёбад.Ва боз.
    /// Ва боз.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Унсурҳои iterator-ро ҷамъбаст мекунад.
    ///
    /// Ҳар як элементро мегирад, якҷоя мекунад ва натиҷаро бар мегардонад.
    ///
    /// Итератори холӣ арзиши сифрии типро бармегардонад.
    ///
    /// # Panics
    ///
    /// Ҳангоми даъват кардани `sum()` ва навъи бутуни ибтидоӣ баргардонида мешавад, ин усул panic хоҳад буд, агар ҳисоб пур шавад ва тасдиқи ислоҳӣ фаъол карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Дар тамоми итератор такрор меёбад ва ҳамаи унсурҳоро зарб мекунад
    ///
    /// Итератори холӣ як қимати типро бар мегардонад.
    ///
    /// # Panics
    ///
    /// Ҳангоми даъват кардани `product()` ва навъи бутуни ибтидоӣ баргардонида мешавад, усули panic хоҳад буд, агар ҳисоб пур шавад ва тасдиқи ислоҳӣ фаъол карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) унсурҳои ин [`Iterator`]-ро бо элементҳои дигар муқоиса мекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) нисбат ба функсияи муқоисаи муайян унсурҳои ин [`Iterator`]-ро бо дигараш муқоиса мекунад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) унсурҳои ин [`Iterator`]-ро бо элементҳои дигар муқоиса мекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) нисбат ба функсияи муқоисаи муайян унсурҳои ин [`Iterator`]-ро бо дигараш муқоиса мекунад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] ба элементҳои дигар баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] нисбати функсияи муайяншудаи баробарӣ ба унсури дигаре баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] нисбат ба унсури дигаре нобаробар мебошанд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] нисбат ба элементҳои дигар [lexicographically](Ord#lexicographical-comparison) камтаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] [lexicographically](Ord#lexicographical-comparison) камтар ё ба элементҳои дигар баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] нисбат ба элементҳои дигар [lexicographically](Ord#lexicographical-comparison) зиёдтаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Муайян мекунад, ки оё унсурҳои ин [`Iterator`] аз [lexicographically](Ord#lexicographical-comparison) нисбат ба унсури дигаре зиёдтар ё ба он баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Санҷида мешавад, ки оё унсурҳои ин итератор мураттаб шудаанд.
    ///
    /// Яъне, барои ҳар як унсури `a` ва унсури зерини он `b`, `a <= b` бояд дошта бошанд.Агар iterator дақиқан сифр ё як элемент диҳад, `true` бармегардад.
    ///
    /// Дар хотир доред, ки агар `Self::Item` танҳо `PartialOrd` бошад, аммо `Ord` нест, таърифи дар боло овардашуда маънои онро дорад, ки ин функсия `false`-ро бармегардонад, агар ягон ду ашёи пай дар пай қобили муқоиса набошанд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Санҷида мешавад, ки оё унсурҳои ин итератор бо ёрии функсияи муқоисавии додашуда мураттаб шудаанд.
    ///
    /// Ба ҷои истифодаи `PartialOrd::partial_cmp`, ин функсия вазифаи додашудаи `compare`-ро барои муайян кардани тартиби ду элемент истифода мебарад.
    /// Ғайр аз ин, он ба [`is_sorted`] баробар аст;Барои маълумоти иловагӣ ба ҳуҷҷатҳои он нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Санҷида мешавад, ки оё унсурҳои ин итератор бо ёрии функсияи додашудаи истихроҷи калидҳо ҷобаҷо шудаанд.
    ///
    /// Ба ҷои муқоисаи мустақими унсурҳои итератор, ин функсия калидҳои элементҳоро, ки бо `f` муайян карда шудааст, муқоиса мекунад.
    /// Ғайр аз ин, он ба [`is_sorted`] баробар аст;Барои маълумоти иловагӣ ба ҳуҷҷатҳои он нигаред.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] нигаред
    // Номи ғайриоддӣ ин аст, ки ба пешгирии бархӯрдҳои ном дар ҳалли усул нигаред #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}