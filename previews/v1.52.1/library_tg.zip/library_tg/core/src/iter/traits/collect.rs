/// Табдилдиҳӣ аз [`Iterator`].
///
/// Бо татбиқи `FromIterator` барои як намуд, шумо муайян мекунед, ки чӣ гуна он аз такрори эҷод мешавад.
/// Ин барои намудҳое маъмул аст, ки маҷмӯаи як навъро тасвир мекунанд.
///
/// [`FromIterator::from_iter()`] хеле кам возеҳ номида мешавад ва ба ҷои он тавассути усули [`Iterator::collect()`] истифода мешавад.
///
/// Барои мисолҳои бештар ба ҳуҷҷатҳои [`Iterator::collect()`]'s нигаред.
///
/// Инчунин нигаред: [`IntoIterator`].
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Истифодаи [`Iterator::collect()`] барои истифодаи беасоси `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Татбиқи `FromIterator` барои навъи шумо:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Маҷмӯаи намуна, ин танҳо як варақ бар Vec аст<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Биёед ба он баъзе усулҳо диҳем, то ки мо онро эҷод кунем ва ба он чизҳо илова кунем.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ва мо аз FromIterator амалӣ хоҳем кард
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Ҳоло мо метавонем як итератори нав созем ...
/// let iter = (0..5).into_iter();
///
/// // ... ва аз он MyCollection созед
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ҷамъоварии асарҳо низ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Аз итератор арзиш месозад.
    ///
    /// Барои маълумоти бештар ба [module-level documentation] нигаред.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Табдил ба [`Iterator`].
///
/// Бо татбиқи `IntoIterator` барои як намуд, шумо муайян мекунед, ки чӣ гуна он ба итератор табдил дода мешавад.
/// Ин барои намудҳое маъмул аст, ки маҷмӯаи як навъро тасвир мекунанд.
///
/// Як манфиати татбиқи `IntoIterator` он аст, ки намуди шумо [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) хоҳад буд.
///
///
/// Инчунин нигаред: [`FromIterator`].
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Татбиқи `IntoIterator` барои навъи шумо:
///
/// ```
/// // Маҷмӯаи намуна, ин танҳо як варақ бар Vec аст<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Биёед ба он баъзе усулҳо диҳем, то ки мо онро эҷод кунем ва ба он чизҳо илова кунем.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ва мо IntoIterator-ро иҷро хоҳем кард
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Ҳоло мо метавонем коллексияи нав созем ...
/// let mut c = MyCollection::new();
///
/// // ... ба он баъзе чизҳо илова кунед ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ва сипас онро ба Итератор табдил диҳед:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Истифодаи `IntoIterator` ҳамчун trait bound маъмул аст.Ин имкон медиҳад, ки намуди ҷамъоварии вурудот тағир дода шавад, ба шарте ки он то ҳол такроркунанда бошад.
/// Ҳудуди иловагӣ мумкин аст бо маҳдуд кардани
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Навъи унсурҳо, ки такрор мешаванд.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Мо инро ба кадом намуди итератор табдил медиҳем?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Аз арзиш як iterator месозад.
    ///
    /// Барои маълумоти бештар ба [module-level documentation] нигаред.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Маҷмӯаро бо мундариҷаи iterator васеъ кунед.
///
/// Итераторҳо як қатор арзишҳоро тавлид мекунанд ва маҷмӯаҳоро метавон ҳамчун як қатор арзишҳо тасаввур кард.
/// `Extend` trait ин холигиро бартараф мекунад ва ба шумо имкон медиҳад, ки коллексияро бо дохил кардани мундариҷаи он итератор васеъ кунед.
/// Ҳангоми васеъ кардани маҷмӯа бо калиди аллакай мавҷудбуда он навсозӣ мешавад ё дар ҳолате, ки коллексияҳое, ки ба якчанд вуруд бо калидҳои баробар иҷозат медиҳанд, ин вуруд ворид карда мешавад.
///
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// // Шумо метавонед сатрро бо якчанд аломат дароз кунед:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Татбиқи `Extend`:
///
/// ```
/// // Маҷмӯаи намуна, ин танҳо як варақ бар Vec аст<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Биёед ба он баъзе усулҳо диҳем, то ки мо онро эҷод кунем ва ба он чизҳо илова кунем.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // азбаски MyCollection дорои рӯйхати i32s мебошад, мо Extend for i32-ро татбиқ мекунем
/// impl Extend<i32> for MyCollection {
///
///     // Ин бо имзои навъи мушаххас каме соддатар аст: мо метавонем ҳарферо, ки метавонад ба Итератор табдил ёбад, ки ба мо i32s медиҳад, метавонем.
///     // Зеро ба мо i32s лозим аст, ки онҳоро ба MyCollection гузорем.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Амалисозӣ хеле содда аст: даврро тавассути итератор гузаред ва ҳар як унсурро ба худ add().
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // биёед коллексияи худро бо се рақами дигар васеъ намоем
/// c.extend(vec![1, 2, 3]);
///
/// // мо ин унсурҳоро ба охир илова кардем
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Маҷмӯаро бо мундариҷаи iterator васеъ мекунад.
    ///
    /// Азбаски ин ягона усули зарурӣ барои ин trait аст, ҳуҷҷатҳои [trait-level] тафсилоти бештар доранд.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // Шумо метавонед сатрро бо якчанд аломат дароз кунед:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Маҷмӯаро бо як унсур васеъ мекунад.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Захираи захираҳо дар коллексия барои шумораи муайяни элементҳои иловагӣ.
    ///
    /// Татбиқи пешфарз ҳеҷ кор намекунад.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}