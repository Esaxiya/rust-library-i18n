use crate::ops::{ControlFlow, Try};

/// Итераторе, ки қодир аст аз ҳарду ҷониб элементҳо диҳад.
///
/// Чизе, ки `DoubleEndedIterator`-ро татбиқ мекунад, нисбат ба чизе, ки [`Iterator`]-ро татбиқ мекунад, як қобилияти изофӣ дорад: қобилияти гирифтани "Item`s" аз қафо ва инчунин пеш.
///
///
/// Қайд кардан муҳим аст, ки ҳарду пас ва ҳам дар як қатор кор мекунанд ва убур намекунанд: такрори вақте, ки онҳо дар мобайн вохӯрданд, ба итмом мерасад.
///
/// Бо усули монанд ба протоколи [`Iterator`], як маротиба `DoubleEndedIterator` аз [`next_back()`] [`None`]-ро бармегардонад ва дубора даъват кардани он метавонад [`Some`]-ро дубора баргардонад ё не.
/// [`next()`] ва [`next_back()`] барои ин мақсад ивазшаванда мебошанд.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Унсурро аз охири итератор хориҷ ва бармегардонад.
    ///
    /// Вақте ки дигар унсурҳо мавҷуд нестанд, `None`-ро бармегардонад.
    ///
    /// Ҳуҷҷатҳои [trait-level] тафсилоти бештар доранд.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Унсурҳое, ки бо усулҳои "DoubleEndedIterator" ҳосил шудаанд, метавонанд аз усулҳои ["Итератор"] фарқ кунанд:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Итераторро аз қафо бо унсурҳои `n` пеш мекунад.
    ///
    /// `advance_back_by` версияи баръакси [`advance_by`] мебошад.Ин усул бесаброна унсурҳои `n`-ро аз қафо сар карда, бо зангҳои [`next_back`] то `n` то дучор шудани [`None`] гузарад.
    ///
    /// `advance_back_by(n)` [`Ok(())`]-ро бармегардонад, агар даврзананда бо унсурҳои `n` бомуваффақият пеш равад ё [`Err(k)`] дар сурати дучор омадани [`None`], ки `k` миқдори унсурҳои итератори пеш аз тамом шудани унсурҳо мебошад (яъне
    /// дарозии такрори).
    /// Дар хотир доред, ки `k` ҳамеша камтар аз `n` аст.
    ///
    /// Занги `advance_back_by(0)` ягон унсурро масраф намекунад ва ҳамеша [`Ok(())`]-ро бармегардонад.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // танҳо `&3` гузаронида шуд
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Унсури `n`th '-ро аз охири такроркунанда бармегардонад.
    ///
    /// Ин аслан нусхаи баръакси [`Iterator::nth()`] мебошад.
    /// Гарчанде ки мисли аксари амалҳои индексатсия, ҳисобкунӣ аз сифр оғоз мешавад, аз ин рӯ `nth_back(0)` арзиши аввалро аз охири, `nth_back(1)` дуюмро бармегардонад ва ғайра.
    ///
    ///
    /// Аҳамият диҳед, ки ҳамаи унсурҳо дар байни унсури хотима ва баргардонида мешаванд, аз ҷумла унсури баргашта.
    /// Ин маънои онро низ дорад, ки ба `nth_back(0)` якчанд маротиба дар як такриздиҳанда занг задан унсурҳои гуногун бармегарданд.
    ///
    /// `nth_back()` [`None`]-ро бармегардонад, агар `n` аз дарозии такроркунанда зиёдтар ё баробар бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Занги чандкарата ба `nth_back()` такрори ақибро барнамегардонад:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Бозгашти `None` агар камтар аз унсурҳои `n + 1` вуҷуд дошта бошанд:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Ин версияи баръакси [`Iterator::try_fold()`] аст: он элементҳоро аз пушти саргардон оғоз мекунад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Азбаски он кӯтоҳ аст, унсурҳои боқимонда то ҳол тавассути iterator дастрасанд.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Усули iterator, ки унсурҳои iterator-ро ба арзиши ягона, аз қафо сар мекунад.
    ///
    /// Ин версияи баръакси [`Iterator::fold()`] аст: он элементҳоро аз пушти саргардон оғоз мекунад.
    ///
    /// `rfold()` ду далел мегирад: арзиши ибтидоӣ ва басташавӣ бо ду далел: 'accumulator' ва унсур.
    /// Бастан арзиши барқароршударо барои такрори навбатӣ бармегардонад.
    ///
    /// Арзиши ибтидоӣ он арзиши он аст, ки аккумулятор ҳангоми занги аввал хоҳад дошт.
    ///
    /// Пас аз татбиқи ин басташавӣ ба ҳар як унсури итератор, `rfold()` аккумуляторро бармегардонад.
    ///
    /// Ин амалиётро баъзан 'reduce' ё 'inject' меноманд.
    ///
    /// Пӯшиш ҳар вақте муфид аст, ки шумо чизе ҷамъоварӣ кунед ва мехоҳед аз он арзиши ягонае ба даст оред.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ҷамъи ҳамаи унсурҳои а
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ин мисол сатр месозад, ки аз арзиши ибтидоӣ оғоз ёфта, бо ҳар як унсур аз қафо то пеш идома меёбад:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Ҷустуҷӯи унсури такрори аз қафо, ки предикатро қонеъ мекунад.
    ///
    /// `rfind()` бастанро мегирад, ки `true` ё `false`-ро бармегардонад.
    /// Он ин пӯшидашударо ба ҳар як унсури итератор, аз охири он татбиқ мекунад ва агар касе аз онҳо `true` баргардонад, пас `rfind()` [`Some(element)`]-ро бармегардонад.
    /// Агар ҳамаи онҳо `false` баргарданд, он [`None`] бармегардад.
    ///
    /// `rfind()` расиши кӯтоҳ аст;ба ибораи дигар, он пас аз баргардонидани басташавӣ `true` коркардро қатъ мекунад.
    ///
    /// Азбаски `rfind()` истинод мегирад ва бисёр такрориҳо бар истинодҳо такрор мешаванд, ин ба вазъияти эҳтимолан печида оварда мерасонад, ки далел истиноди дугона аст.
    ///
    /// Шумо ин таъсирро дар мисолҳои зер, бо `&&x` мебинед.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Боздоштан дар аввалин `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // мо то ҳол метавонем `iter`-ро истифода барем, зеро унсурҳои бештар вуҷуд доранд.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}