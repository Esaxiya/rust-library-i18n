use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Объектҳое, ки тасаввуроти *ворис* ва * амалиётҳои пешгузаштаро доранд.
///
/// Амалиёт *ворис* ба сӯи арзишҳое ҳаракат мекунад, ки бузургтарро муқоиса мекунанд.
/// Амалиёти *пешгузашта* ба сӯи арзишҳое ҳаракат мекунад, ки камтар муқоиса мекунанд.
///
/// # Safety
///
/// Ин trait `unsafe` аст, зеро татбиқи он бояд барои бехатарии татбиқи `unsafe trait TrustedLen` дуруст бошад ва натиҷаҳои истифодаи ин trait метавонанд дар акси ҳол бо рамзи `unsafe` боварӣ дошта бошанд, ки ӯҳдадориҳои номбаршударо дуруст иҷро мекунанд.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Шумораи қадамҳои *ворис*-ро, ки барои аз `start` ба `end` гузаштан лозим аст, бармегардонад.
    ///
    /// `None`-ро бармегардонад, агар миқдори қадамҳо аз `usize` зиёдтар бошад (ё бепоён бошад ё ҳеҷ гоҳ ба `end` нарасад).
    ///
    ///
    /// # Invariants
    ///
    /// Барои ҳама гуна `a`, `b` ва `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` агар ва танҳо агар `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` агар ва танҳо агар `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` танҳо агар `a <= b`
    ///   * Хулоса: `steps_between(&a, &b) == Some(0)` агар ва танҳо агар `a == b`
    ///   * Дар хотир доред, ки `a <= b` оё _not_ `steps_between(&a, &b) != None`-ро дар назар дорад;
    ///     ин ҳолатест, ки барои ба `b` расидан зиёда аз қадамҳои `usize::MAX` лозим аст
    /// * `steps_between(&a, &b) == None` агар `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Арзишеро, ки бо истифодаи *ворис*-и `self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// Агар ин диапазони арзишҳоро, ки `Self` дастгирӣ мекунад, зиёдтар кунад, `None` бармегардад.
    ///
    /// # Invariants
    ///
    /// Барои ҳама гуна `a`, `n` ва `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Барои ҳама гуна `a`, `n` ва `m`, ки `n + m` пур намешавад:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Барои ҳама гуна `a` ва `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Арзишеро, ки бо истифодаи *ворис*-и `self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// Агар ин миқёси арзишҳои бо дастгирии `Self` зиёдтарро иҷро кунад, ин функсия ба panic иҷозат дода мешавад, печонад ё сер кунад.
    ///
    /// Рафторе, ки пешниҳод карда мешавад, ба panic ҳангоми фаъол кардани тасдиқҳои ислоҳи хато ва ба тариқи дигар печондан ё пур кардани он аст.
    ///
    /// Рамзи хатарнок набояд ба дурустии рафтори пас аз лабрез такя кунад.
    ///
    /// # Invariants
    ///
    /// Барои ҳама гуна `a`, `n` ва `m`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Барои ҳама гуна `a` ва `n`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Арзишеро, ки бо истифодаи *ворис*-и `self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// # Safety
    ///
    /// Ин рафтори номуайян аст, ки ин амалиёт аз доираи арзишҳое, ки `Self` дастгирӣ мекунанд, зиёдтар аст.
    /// Агар шумо кафолат дода натавонед, ки ин пур намешавад, ба ҷои он `forward` ё `forward_checked`-ро истифода баред.
    ///
    /// # Invariants
    ///
    /// Барои ҳар як `a`:
    ///
    /// * агар `b` вуҷуд дошта бошад, ки `b > a` бошад, бехатар аст ба `Step::forward_unchecked(a, 1)` занг занем
    /// * агар `b`, `n` вуҷуд дошта бошад, ки `steps_between(&a, &b) == Some(n)` бошад, барои `m <= n` ба `Step::forward_unchecked(a, m)` занг задан бехатар аст.
    ///
    ///
    /// Барои ҳама гуна `a` ва `n`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::forward_unchecked(a, n)` ба `Step::forward(a, n)` баробар аст
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Арзишеро, ки бо назардошти *пешгузаштаи*`self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// Агар ин диапазони арзишҳоро, ки `Self` дастгирӣ мекунад, зиёдтар кунад, `None` бармегардад.
    ///
    /// # Invariants
    ///
    /// Барои ҳама гуна `a`, `n` ва `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Барои ҳама гуна `a` ва `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Арзишеро, ки бо назардошти *пешгузаштаи*`self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// Агар ин миқёси арзишҳои бо дастгирии `Self` зиёдтарро иҷро кунад, ин функсия ба panic иҷозат дода мешавад, печонад ё сер кунад.
    ///
    /// Рафторе, ки пешниҳод карда мешавад, ба panic ҳангоми фаъол кардани тасдиқҳои ислоҳи хато ва ба тариқи дигар печондан ё пур кардани он аст.
    ///
    /// Рамзи хатарнок набояд ба дурустии рафтори пас аз лабрез такя кунад.
    ///
    /// # Invariants
    ///
    /// Барои ҳама гуна `a`, `n` ва `m`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Барои ҳама гуна `a` ва `n`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Арзишеро, ки бо назардошти *пешгузаштаи*`self` `count` маротиба ба даст оварда мешавад, бармегардонад.
    ///
    /// # Safety
    ///
    /// Ин рафтори номуайян аст, ки ин амалиёт аз доираи арзишҳое, ки `Self` дастгирӣ мекунанд, зиёдтар аст.
    /// Агар шумо кафолат дода натавонед, ки ин пур намешавад, ба ҷои он `backward` ё `backward_checked`-ро истифода баред.
    ///
    /// # Invariants
    ///
    /// Барои ҳар як `a`:
    ///
    /// * агар `b` вуҷуд дошта бошад, ки `b < a` бошад, бехатар аст ба `Step::backward_unchecked(a, 1)` занг занем
    /// * агар `b`, `n` вуҷуд дошта бошад, ки `steps_between(&b, &a) == Some(n)` бошад, барои `m <= n` ба `Step::backward_unchecked(a, m)` занг задан бехатар аст.
    ///
    ///
    /// Барои ҳама гуна `a` ва `n`, ки дар он лағзиш рух намедиҳад:
    ///
    /// * `Step::backward_unchecked(a, n)` ба `Step::backward(a, n)` баробар аст
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Инҳо ҳанӯз ҳам макро тавлид шудаанд, зеро адади адади бутун ба намудҳои гуногун ҳал мешавад.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `start + n` аз ҳад зиёд намешавад.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `start - n` аз ҳад зиёд намешавад.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Ҳангоми сохтани debug, як panic-ро дар лабрез оғоз кунед.
            // Ин бояд комилан дар сохтори озод оптимизатсия кунад.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Математикаи печондашударо иҷро кунед, то масалан `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Ҳангоми сохтани debug, як panic-ро дар лабрез оғоз кунед.
            // Ин бояд комилан дар сохтори озод оптимизатсия кунад.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Математикаи печондашударо иҷро кунед, то масалан `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ин ба $u_narrower <=usize такя мекунад
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // агар n аз диапазон берун бошад, `unsigned_start + n` низ ҳаст
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // агар n аз диапазон берун бошад, `unsigned_start - n` низ ҳаст
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ин ба $i_narrower <=usize такя мекунад
                        //
                        // Кастинг ба андозаи изиз паҳниро васеъ мекунад, аммо аломатро ҳифз мекунад.
                        // Wrapping_sub-ро дар фазои isize истифода баред ва барои usize андохтан барои фарқ кардани фарқияте, ки ба дохили доираи isize рост намеояд.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Печондани парвандаҳо ба монанди `Step::forward(-120_i8, 200) == Some(80_i8)` сарукор дорад, гарчанде ки 200 барои i8 аз доираи имкон берун аст.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Илова барзиёд
                            }
                        }
                        // Агар n аз доираи масалан берун бошад
                        // u8, пас он аз тамоми диапазон калонтар аст барои i8 васеъ аст, бинобар ин `any_i8 + n` ҳатман i8-ро лабрез мекунад.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Печондани парвандаҳо ба монанди `Step::forward(-120_i8, 200) == Some(80_i8)` сарукор дорад, гарчанде ки 200 барои i8 аз доираи имкон берун аст.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Тарҳкунӣ пур шуд
                            }
                        }
                        // Агар n аз доираи масалан берун бошад
                        // u8, пас он аз тамоми диапазон калонтар аст барои i8 васеъ аст, бинобар ин `any_i8 - n` ҳатман i8-ро лабрез мекунад.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Агар фарқият барои масалан хеле калон бошад
                            // i128, он инчунин барои истифодаи каме ботар аз ҳад зиёд хоҳад буд.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // БЕХАТАРИИ: res скалярии юникоди дуруст аст
            // (дар зери 0x110000 ва на дар 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // БЕХАТАРИИ: res скалярии юникоди дуруст аст
        // (дар зери 0x110000 ва на дар 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки ин пур намешавад
        // доираи арзишҳо барои char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки ин пур намешавад
            // доираи арзишҳо барои char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // БЕХАТАР: : аз сабаби шартномаи қаблӣ, ин кафолат дода мешавад
        // аз ҷониби даъваткунанда як char эътибор дорад.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки ин пур намешавад
        // доираи арзишҳо барои char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки ин пур намешавад
            // доираи арзишҳо барои char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // БЕХАТАР: : аз сабаби шартномаи қаблӣ, ин кафолат дода мешавад
        // аз ҷониби даъваткунанда як char эътибор дорад.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // БЕХАТАР: : шарти пешакии санҷидашуда
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ин макросҳо имплҳои `ExactSizeIterator`-ро барои намудҳои гуногун тавлид мекунанд.
//
// * `ExactSizeIterator::len` барои ҳамеша баргардонидани як `usize` дақиқ талаб карда мешавад, аз ин рӯ ҳеҷ як диапазон аз `usize::MAX` дарозтар буда наметавонад.
//
// * Барои намудҳои бутун дар `Range<_>` ин барои намудҳои аз `usize` тангтар ва ё васеътар аст.
//   Барои намудҳои бутун дар `RangeInclusive<_>` ин нисбат ба `usize` нисбат ба намудҳо *қатъӣ тангтар аст*, масалан
//   `(0..=u64::MAX).len()` мебуд `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Инҳо аз рӯи далелҳои дар боло номувофиқ мебошанд, аммо аз байн бурдани онҳо тағироти ҷиддӣ хоҳад буд, зеро онҳо дар Rust 1.0.0 мӯътадил буданд.
    // Ҳамин тавр
    // `(0..66_000_u32).len()` масалан, дар платформаҳои 16-бита бидуни хато ё огоҳӣ тартиб дода мешавад, аммо натиҷаи нодурустро идома медиҳад.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Инҳо аз рӯи далелҳои дар боло номувофиқ мебошанд, аммо аз байн бурдани онҳо тағироти ҷиддӣ хоҳад буд, зеро онҳо дар Rust 1.26.0 мӯътадил буданд.
    // Ҳамин тавр
    // `(0..=u16::MAX).len()` масалан, дар платформаҳои 16-бита бидуни хато ё огоҳӣ тартиб дода мешавад, аммо натиҷаи нодурустро идома медиҳад.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // БЕХАТАР: : шарти пешакии санҷидашуда
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // БЕХАТАР: : шарти пешакии санҷидашуда
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}