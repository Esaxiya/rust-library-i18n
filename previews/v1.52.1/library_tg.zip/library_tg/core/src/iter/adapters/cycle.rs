use crate::{iter::FusedIterator, ops::Try};

/// Итераторе, ки беохир такрор мекунад.
///
/// Ин `struct` бо усули [`cycle`] дар [`Iterator`] сохта шудааст.
/// Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // такрори давра ё холӣ ё беохир аст
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // итератори ҳозираро пурра такрор кунед.
        // ин зарур аст, зеро ҳатто вақте ки `self.orig` чунин нест, `self.iter` метавонад холӣ бошад
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // як даври пурро анҷом диҳед, пайгирӣ кунед, ки итератори сиклӣ холӣ аст ё не.
        // ба мо лозим аст, ки барвақт баргардем, дар сурате, ки як итератори холӣ пешгирӣ кардани як ҳалқаи бепоён бошад
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Не `fold` бекор карда мешавад, зеро `fold` барои `Cycle` чандон маъно надорад ва мо наметавонем беҳтар аз пешфарзӣ коре кунем.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}