use crate::iter::{FusedIterator, TrustedLen};

/// Итератори нав эҷод мекунад, ки унсурҳои навъи `A`-ро бо истифодаи бастани пешбинишуда, ретранслятор беохир такрор мекунад, `F: FnMut() -> A`.
///
/// Функсияи `repeat_with()` такрорро такрор ба такрор даъват мекунад.
///
/// Итераторҳои бепоён ба монанди `repeat_with()` аксар вақт бо созгорҳо ба монанди [`Iterator::take()`] истифода мешаванд, то онҳоро маҳдуд кунанд.
///
/// Агар навъи унсури такрордиҳандае, ки ба шумо лозим аст, [`Clone`]-ро иҷро кунад ва унсури манбаъро дар хотира нигоҳ доштан хуб аст, шумо бояд функсияи [`repeat()`]-ро истифода баред.
///
///
/// Итератори истеҳсолкардаи `repeat_with()` [`DoubleEndedIterator`] нест.
/// Агар ба шумо барои баргардонидани [`DoubleEndedIterator`] ба `repeat_with()` лозим ояд, лутфан масъалаи GitHub кушоед, ки парвандаи истифодаи шуморо шарҳ диҳад.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::iter;
///
/// // биёед арзиши моеро дошта бошем, ки навъи `Clone` набошад ва ё намехоҳад дар хотираи он ҳанӯз ҳам арзон бошад:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // арзиши махсус то абад:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Истифодаи мутатсия ва ниҳоӣ рафтан:
///
/// ```rust
/// use std::iter;
///
/// // Аз сифр ба қувваи сеюми ду:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ва ҳоло мо тамом
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Итераторе, ки унсурҳои навъи `A`-ро бо истифодаи бастани пешбинишуда `F: FnMut() -> A` беохир такрор мекунад.
///
///
/// Ин `struct` бо функсияи [`repeat_with()`] сохта шудааст.
/// Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}