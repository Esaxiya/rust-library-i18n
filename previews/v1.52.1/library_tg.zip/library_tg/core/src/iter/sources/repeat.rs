use crate::iter::{FusedIterator, TrustedLen};

/// Итератори нав месозад, ки унсури ягонаро беохир такрор мекунад.
///
/// Функсияи `repeat()` арзиши ягонаро такрор ба такрор такрор мекунад.
///
/// Итераторҳои бепоён ба монанди `repeat()` аксар вақт бо созгорҳо ба монанди [`Iterator::take()`] истифода мешаванд, то онҳоро маҳдуд кунанд.
///
/// Агар навъи унсури такрордиҳандае, ки ба шумо лозим аст, `Clone`-ро иҷро накунад ё шумо намехоҳед унсури такроршударо дар хотира нигоҳ доред, шумо метавонед ба ҷои функсияи [`repeat_with()`] истифода баред.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::iter;
///
/// // рақами чор 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ҳу, ҳоло ҳам чор
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Бо [`Iterator::take()`] ниҳоӣ рафтан:
///
/// ```
/// use std::iter;
///
/// // ки мисоли охирин аз ҳад зиёд чор буд.Биёед танҳо чор чаҳор тан дошта бошем.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ва ҳоло мо тамом
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Итераторе, ки унсурро беохир такрор мекунад.
///
/// Ин `struct` бо функсияи [`repeat()`] сохта шудааст.Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}