use crate::fmt;

/// Итератори нав эҷод мекунад, ки дар он ҳар як такрор бастани пешбинишударо `F: FnMut() -> Option<T>` меномад.
///
/// Ин имкон медиҳад, ки як итератори фармоишӣ бо ҳама гуна рафтор бидуни истифодаи синтаксиси муфассали эҷоди навъи махсус ва татбиқи [`Iterator`] trait барои он.
///
/// Дар хотир доред, ки iterator `FromFn` дар бораи рафтори басташавӣ пиндоштҳо ба миён намеорад ва аз ин рӯ консервативӣ [`FusedIterator`]-ро амалӣ намекунад ва ё [`Iterator::size_hint()`]-ро аз `(0, None)` бо нобаёнии худ бекор мекунад.
///
///
/// Бастан метавонад аксҳо ва муҳити онро барои пайгирии ҳолати такрорӣ истифода барад.Вобаста аз он, ки чӣ гуна iterator истифода мешавад, ин метавонад нишон додани калимаи калидии [`move`] дар бастанро талаб кунад.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Биёед такрори зиддитеррористиро аз [module-level documentation] бозсозӣ кунем:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Ҳисоби моро зиёд кунед.Ин аст, ки чаро мо дар сифр оғоз кардем.
///     count += 1;
///
///     // Санҷед, бубинед, ки мо ҳисобкуниро тамом кардем ё не.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Итераторе, ки ҳар такрори он пӯшидани пешбинишударо `F: FnMut() -> Option<T>` меномад.
///
/// Ин `struct` бо функсияи [`iter::from_fn()`] сохта шудааст.
/// Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}