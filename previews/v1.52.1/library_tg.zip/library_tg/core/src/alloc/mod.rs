//! API-ҳои тақсимоти хотира

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Хатогии `AllocError` нокомии тақсимотро нишон медиҳад, ки метавонад ба тамомшавии захираҳо ё ба ягон хатогӣ ҳангоми якҷоя кардани далелҳои додашудаи додашуда бо ин ҷудокунанда бошад.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ба мо ин барои имлои поёнии Хатои trait лозим аст)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Татбиқи `Allocator` метавонад блокҳои худсаронаи маълумотро, ки тавассути [`Layout`][] тавсиф шудаанд, тақсим кунад, афзоиш диҳад, коҳиш диҳад ва тақсим кунад.
///
/// `Allocator` тарҳрезӣ шудааст, ки дар ZSTҳо, маълумотномаҳо ё нишондиҳандаҳои оқил татбиқ карда шаванд, зеро доштани тақсимкунандаро ба монанди `MyAlloc([u8; N])` бе навсозӣ кардани нишондиҳандаҳо ба хотираи ҷудошуда интиқол додан мумкин нест.
///
/// Баръакси [`GlobalAlloc`][], тақсимоти андозаи сифр дар `Allocator` иҷозат дода мешаванд.
/// Агар ҷудокунандаи аслӣ инро дастгирӣ накунад (масалан, jemalloc) ё нишондиҳандаи ночизро баргардонад (масалан, `libc::malloc`), ин бояд аз ҷониби татбиқ бурда шавад.
///
/// ### Дар айни замон хотираи ҷудошуда
///
/// Баъзе усулҳо талаб мекунанд, ки блоки хотира тавассути *алҳол тақсим карда шавад*.Ин маънои онро дорад, ки:
///
/// * суроғаи оғоз барои он блоки хотира қаблан аз ҷониби [`allocate`], [`grow`] ё [`shrink`] баргардонида шуда буд ва
///
/// * блоки хотира баъдан тақсим карда нашудааст, ки дар онҷо блокҳо мустақиман тавассути интиқол ба [`deallocate`] тақсим карда мешаванд ё бо роҳи гузаштан ба [`grow`] ё [`shrink`], ки `Ok`-ро бармегардонанд, тағир дода мешаванд.
///
/// Агар `grow` ё `shrink` `Err`-ро баргардонанд, нишоннамои гузаронидашуда боқӣ мемонад.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Ҷойгиркунии хотира
///
/// Баъзе усулҳо талаб мекунанд, ки тарҳбандии *блоки хотира мувофиқат кунад*.
/// Маънои тарҳбандӣ ба "fit" блоки хотира маънои онро дорад (ё ба ин монанд, барои блоки хотира ба "fit" тарҳбандӣ) ин аст, ки шартҳои зерин бояд иҷро шаванд:
///
/// * Блок бояд бо ҳамон масир тавре ки [`layout.align()`] ҷудо карда шудааст, ва
///
/// * [`layout.size()`] пешниҳодшуда бояд дар доираи `min ..= max` афтад, ки дар он:
///   - `min` аст андозаи тарҳбандӣ, ки ба наздикӣ барои тақсим кардани блок истифода шудааст ва
///   - `max` андозаи охирини воқеии аз [`allocate`], [`grow`] ё [`shrink`] баргашта мебошад.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Блокҳои хотираи аз ҷудокунанда баргашта бояд хотираи дурустро нишон диҳанд ва эътибори худро то афтодани мисол ва ҳамаи клонҳои он нигоҳ доранд,
///
/// * клондан ё ҳаракат кардани ҷудокунанда набояд блокҳои хотираи аз ин ҷудокунанда баргаштаро беэътибор кунад.Ҷудокунандаи клондорӣ бояд мисли ҳамон ҷудокунанда рафтор кунад ва
///
/// * ҳар гуна нишоннамо ба блоки хотира, ки [*currently allocated*] аст, метавонад ба усули дигари ҷудокунанда дода шавад.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Кӯшишҳои ҷудо кардани блоки хотира.
    ///
    /// Дар бораи муваффақият, [`NonNull<[u8]>`][NonNull]-ро, ки ба андозаи андоза ва кафолати мутобиқати `layout` мувофиқат мекунад, бармегардонад.
    ///
    /// Блоки баргардондашуда метавонад андозаи калонтар аз муайянкардаи `layout.size()` дошта бошад ва ё мундариҷаи онро оғоз кунад ё надошта бошад.
    ///
    /// # Errors
    ///
    /// Бозгашти `Err` нишон медиҳад, ки ё хотира тамом шудааст ё `layout` ба андозаи ҷудокунанда ё маҳдудиятҳои мувофиқат ҷавобгӯ нест.
    ///
    /// Амалиётҳо тавсия дода мешаванд, ки `Err`-ро дар бораи хастагии хотира баргардонанд, на ба тарсу ҳарос ё исқоти ҳамл, аммо ин талаби қатъӣ нест.
    /// (Махсусан: татбиқи ин trait дар болои китобхонаи тақсимоти аслии ватанӣ, ки аз хастагии хотира даст мекашад, * қонунӣ аст.)
    ///
    /// Мизоҷоне, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки вазифаи [`handle_alloc_error`]-ро даъват кунанд, на мустақиман ба `panic!` ё монанд.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Ба монанди `allocate` рафтор мекунад, аммо инчунин хотираи баргаштаро бо сифр оғоз мекунад.
    ///
    /// # Errors
    ///
    /// Бозгашти `Err` нишон медиҳад, ки ё хотира тамом шудааст ё `layout` ба андозаи ҷудокунанда ё маҳдудиятҳои мувофиқат ҷавобгӯ нест.
    ///
    /// Амалиётҳо тавсия дода мешаванд, ки `Err`-ро дар бораи хастагии хотира баргардонанд, на ба тарсу ҳарос ё исқоти ҳамл, аммо ин талаби қатъӣ нест.
    /// (Махсусан: татбиқи ин trait дар болои китобхонаи тақсимоти аслии ватанӣ, ки аз хастагии хотира даст мекашад, * қонунӣ аст.)
    ///
    /// Мизоҷоне, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки вазифаи [`handle_alloc_error`]-ро даъват кунанд, на мустақиман ба `panic!` ё монанд.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // БЕХАТАР: : `alloc` блоки хотираи дурустро бармегардонад
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Хотираро бо истинод ба `ptr` тақсим мекунад.
    ///
    /// # Safety
    ///
    /// * `ptr` бояд блоки хотираи [*currently allocated*]-ро тавассути ин ҷудокунанда нишон диҳад ва
    /// * `layout` бояд [*fit*], ки блоки хотира.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Кӯшишҳои васеъ кардани блоки хотира.
    ///
    /// Бозгаштан [`NonNull<[u8]>`][NonNull] нав, ки дорои нишоннамо ва андозаи воқеии хотираи ҷудошуда дорад.Нишондиҳанда барои нигоҳ доштани маълумоте, ки `new_layout` тавсиф кардааст, мувофиқ аст.
    /// Барои ноил шудан ба ин, тақсимкунанда метавонад тақсимоти бо истинод ба `ptr` додашударо ба тарҳбандии нав дароз кунад.
    ///
    /// Агар ин `Ok`-ро баргардонад, пас моликияти блоки хотира, ки бо истинод ба `ptr` ба ин ҷудокунанда интиқол ёфтааст.
    /// Хотира метавонад озод карда шуда бошад ё не, ва ғайри қобили истифода ҳисобида мешавад, агар он ба воситаи бозгашти ин усул дубора ба зангзада интиқол дода нашавад.
    ///
    /// Агар ин усул `Err`-ро баргардонад, пас моликияти блоки хотира ба ин ҷудокунанда нагузаштааст ва мундариҷаи блоки хотира бетағйир аст.
    ///
    /// # Safety
    ///
    /// * `ptr` бояд блоки хотираи [*currently allocated*]-ро тавассути ин ҷудокунанда нишон диҳад.
    /// * `old_layout` бояд [*fit*] ки блоки хотира бошад (Далели `new_layout` набояд ба он мувофиқат кунад.)
    /// * `new_layout.size()` бояд аз `old_layout.size()` бузург ё баробар бошад.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ро бармегардонад, агар тарҳбандии нав ба андозаи ҷудокунанда ва маҳдудиятҳои ҷобаҷогузории ҷудокунанда ҷавобгӯ набошад ё афзоиши дигар барор нагирад.
    ///
    /// Амалиётҳо тавсия дода мешаванд, ки `Err`-ро дар бораи хастагии хотира баргардонанд, на ба тарсу ҳарос ё исқоти ҳамл, аммо ин талаби қатъӣ нест.
    /// (Махсусан: татбиқи ин trait дар болои китобхонаи тақсимоти аслии ватанӣ, ки аз хастагии хотира даст мекашад, * қонунӣ аст.)
    ///
    /// Мизоҷоне, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки вазифаи [`handle_alloc_error`]-ро даъват кунанд, на мустақиман ба `panic!` ё монанд.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЕХАТАР: : зеро `new_layout.size()` бояд аз ё бузургтар бошад
        // `old_layout.size()`, ҳам тақсимоти кӯҳна ва ҳам нав барои хондан ва навиштан барои байтҳои `old_layout.size()` эътибор доранд.
        // Инчунин, азбаски тақсимоти кӯҳна ҳанӯз тақсим карда нашудааст, он наметавонад `new_ptr`-ро такрор кунад.
        // Ҳамин тариқ, занг ба `copy_nonoverlapping` бехатар аст.
        // Шартномаи бехатарӣ барои `dealloc` бояд аз ҷониби шахси зангзада риоя карда шавад.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow`-ро дӯст медорад, аммо инчунин кафолат медиҳад, ки мундариҷаи нав пеш аз баргардонидан ба сифр гузошта мешавад.
    ///
    /// Блоки хотира дорои мундариҷаҳои зеринро пас аз занги бомуваффақият ба бар мегирад
    /// `grow_zeroed`:
    ///   * Байтҳои `0..old_layout.size()` аз тақсимоти аввала маҳфузанд.
    ///   * Вобаста аз татбиқи тақсимкунанда, байтҳои `old_layout.size()..old_size` ё ҳифз карда мешаванд ё сифр карда мешаванд.
    ///   `old_size` ба андозаи блоки хотира пеш аз занги `grow_zeroed` ишора мекунад, ки он метавонад аз андозае, ки ҳангоми тақсим кардани он дархост шуда буд, калонтар бошад.
    ///   * Байтҳои `old_size..new_size` сифр карда шудаанд.`new_size` ба андозаи блоки хотира, ки пас аз даъвати `grow_zeroed` баргардонида шудааст, ишора мекунад.
    ///
    /// # Safety
    ///
    /// * `ptr` бояд блоки хотираи [*currently allocated*]-ро тавассути ин ҷудокунанда нишон диҳад.
    /// * `old_layout` бояд [*fit*] ки блоки хотира бошад (Далели `new_layout` набояд ба он мувофиқат кунад.)
    /// * `new_layout.size()` бояд аз `old_layout.size()` бузург ё баробар бошад.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ро бармегардонад, агар тарҳбандии нав ба андозаи ҷудокунанда ва маҳдудиятҳои ҷобаҷогузории ҷудокунанда ҷавобгӯ набошад ё афзоиши дигар барор нагирад.
    ///
    /// Амалиётҳо тавсия дода мешаванд, ки `Err`-ро дар бораи хастагии хотира баргардонанд, на ба тарсу ҳарос ё исқоти ҳамл, аммо ин талаби қатъӣ нест.
    /// (Махсусан: татбиқи ин trait дар болои китобхонаи тақсимоти аслии ватанӣ, ки аз хастагии хотира даст мекашад, * қонунӣ аст.)
    ///
    /// Мизоҷоне, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки вазифаи [`handle_alloc_error`]-ро даъват кунанд, на мустақиман ба `panic!` ё монанд.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // БЕХАТАР: : зеро `new_layout.size()` бояд аз ё бузургтар бошад
        // `old_layout.size()`, ҳам тақсимоти кӯҳна ва ҳам нав барои хондан ва навиштан барои байтҳои `old_layout.size()` эътибор доранд.
        // Инчунин, азбаски тақсимоти кӯҳна ҳанӯз тақсим карда нашудааст, он наметавонад `new_ptr`-ро такрор кунад.
        // Ҳамин тариқ, занг ба `copy_nonoverlapping` бехатар аст.
        // Шартномаи бехатарӣ барои `dealloc` бояд аз ҷониби шахси зангзада риоя карда шавад.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Кӯшишҳои коҳиш додани блоки хотира.
    ///
    /// Бозгаштан [`NonNull<[u8]>`][NonNull] нав, ки дорои нишоннамо ва андозаи воқеии хотираи ҷудошуда дорад.Нишондиҳанда барои нигоҳ доштани маълумоте, ки `new_layout` тавсиф кардааст, мувофиқ аст.
    /// Барои ноил шудан ба ин, ҷудокунанда метавонад ҷудокуниро, ки `ptr` истинод кардааст, кам кунад, то ба тарҳбандии нав мувофиқат кунад.
    ///
    /// Агар ин `Ok`-ро баргардонад, пас моликияти блоки хотира, ки бо истинод ба `ptr` ба ин ҷудокунанда интиқол ёфтааст.
    /// Хотира метавонад озод карда шуда бошад ё не, ва ғайри қобили истифода ҳисобида мешавад, агар он ба воситаи бозгашти ин усул дубора ба зангзада интиқол дода нашавад.
    ///
    /// Агар ин усул `Err`-ро баргардонад, пас моликияти блоки хотира ба ин ҷудокунанда нагузаштааст ва мундариҷаи блоки хотира бетағйир аст.
    ///
    /// # Safety
    ///
    /// * `ptr` бояд блоки хотираи [*currently allocated*]-ро тавассути ин ҷудокунанда нишон диҳад.
    /// * `old_layout` бояд [*fit*] ки блоки хотира бошад (Далели `new_layout` набояд ба он мувофиқат кунад.)
    /// * `new_layout.size()` бояд аз `old_layout.size()` хурд ё ба он баробар бошад.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err`-ро бармегардонад, агар тарҳбандии нав ба андозаи ҷудокунанда ва маҳдудиятҳои ҷудокунандаи ҷудокунанда ҷавобгӯ набошад ё коҳиш ёфтани тартиби дигаре ноком шавад.
    ///
    /// Амалиётҳо тавсия дода мешаванд, ки `Err`-ро дар бораи хастагии хотира баргардонанд, на ба тарсу ҳарос ё исқоти ҳамл, аммо ин талаби қатъӣ нест.
    /// (Махсусан: татбиқи ин trait дар болои китобхонаи тақсимоти аслии ватанӣ, ки аз хастагии хотира даст мекашад, * қонунӣ аст.)
    ///
    /// Мизоҷоне, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки вазифаи [`handle_alloc_error`]-ро даъват кунанд, на мустақиман ба `panic!` ё монанд.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // БЕХАТАР: : зеро `new_layout.size()` бояд камтар ё баробар бошад
        // `old_layout.size()`, ҳам тақсимоти кӯҳна ва ҳам нав барои хондан ва навиштан барои байтҳои `new_layout.size()` эътибор доранд.
        // Инчунин, азбаски тақсимоти кӯҳна ҳанӯз тақсим карда нашудааст, он наметавонад `new_ptr`-ро такрор кунад.
        // Ҳамин тариқ, занг ба `copy_nonoverlapping` бехатар аст.
        // Шартномаи бехатарӣ барои `dealloc` бояд аз ҷониби шахси зангзада риоя карда шавад.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Барои ин мисоли `Allocator` адаптери "by reference" месозад.
    ///
    /// Адаптери баргашта инчунин `Allocator`-ро татбиқ мекунад ва инро танҳо қарз хоҳад гирифт.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // БЕХАТАР: : шартномаи бехатариро бояд даъваткунанда риоя кунад
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕХАТАР: : шартномаи бехатариро бояд даъваткунанда риоя кунад
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕХАТАР: : шартномаи бехатариро бояд даъваткунанда риоя кунад
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕХАТАР: : шартномаи бехатариро бояд даъваткунанда риоя кунад
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}