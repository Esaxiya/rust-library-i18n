use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ҳангоме ки ин функсия дар як ҷо истифода мешавад ва татбиқи он метавонад хаттӣ карда шавад, кӯшишҳои қаблӣ rustc-ро сусттар карданд:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Тарҳбандии блоки хотира.
///
/// Мисоли `Layout` тарҳбандии мушаххаси хотираро тасвир мекунад.
/// Шумо як `Layout` месозед, то ҳамчун вуруд ба ҷудокунанда.
///
/// Ҳама тарҳҳо андозаи мувофиқ ва ҳамоҳангии қудрати ду доранд.
///
/// (Дар хотир доред, ки тарҳбандиҳо барои андозаи ғайри сифр талаб карда намешаванд, гарчанде ки `GlobalAlloc` талаб мекунад, ки ҳамаи дархостҳои хотира ба андозаи ғайримутамар бошанд.
/// Зангзананда бояд кафолат диҳад, ки шароити ба ин монанд риоя карда шавад, тақсимкунандагони мушаххас бо талаботҳои заифтар истифода баранд ё интерфейси сабуктари `Allocator`-ро истифода баранд.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // андозаи блоки хотираи дархостшуда, ки бо байт чен карда мешавад.
    size_: usize,

    // ҳамоҳангсозии блоки хотираи дархостшуда, ки бо байт чен карда мешавад.
    // мо кафолат медиҳем, ки ин ҳамеша қудрати ду аст, зеро API ба монанди `posix_memalign` инро талаб мекунад ва маҳдуд кардани оқилона аст, ки ба конструкторони Layout ҷорӣ карда шавад.
    //
    //
    // (Аммо, мо ба ин монанд "align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) талаб намекунем
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Аз `size` ва `align` додашуда `Layout` месозад ё `LayoutError`-ро бармегардонад, агар яке аз шартҳои зерин иҷро нашавад:
    ///
    /// * `align` набояд сифр бошад,
    ///
    /// * `align` бояд қудрати ду бошад,
    ///
    /// * `size`, вақте ки то зарбҳои наздиктарини `align` яклухт карда шавад, набояд зиёд шавад (яъне арзиши ҳамаҷониба бояд ба `usize::MAX` камтар ё баробар бошад).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (қудрати ду маънои мувофиқат карданро дорад!=0.)

        // Андозаи ҳамаҷониба:
        //   size_rounded_up=(андоза + баробар, 1)&! (баробар, 1);
        //
        // Мо аз боло медонем, ки ҳамбастагӣ!=0.
        // Агар илова кардан (align, 1) зиёд набошад, пас яклухткунӣ хуб хоҳад буд.
        //
        // Ва баръакс,&-маска бо! (Align, 1) танҳо битҳои камдараҷаро хориҷ мекунад.
        // Ҳамин тариқ, агар ҳосили зиёд бо сумма ба амал ояд,&-mask наметавонад барои баргардонидани ин пуркунӣ ба қадри кофӣ тарҳ кунад.
        //
        //
        // Дар боло дар назар дошта шудааст, ки тафтиши пур кардани ҷамъбаст ҳам зарурӣ ва ҳам кофист.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // БЕХАТАР: : шароит барои `from_size_align_unchecked` мавҷуд буд
        // дар боло тафтиш карда шуд.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Тарҳро таҳия мекунад, аз ҳама санҷишҳо нагузашта.
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро он шартҳои пешакии [`Layout::from_size_align`]-ро тасдиқ намекунад.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `align` аз сифр зиёдтар аст.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Андозаи минималӣ дар байт барои блоки хотираи ин тарҳ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Хатти ҳадди ақали байт барои блоки хотираи ин тарҳ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `Layout` месозад, ки барои нигоҳ доштани арзиши навъи `T` мувофиқ аст.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // БЕХАТАР: : ба хатти Rust кафолати қувваи ду ва
        // андоза + мувофиқаи мувофиқ дар фазои суроғаи мо кафолат дода мешавад.
        // Дар натиҷа, конструктори тафтишнашударо дар ин ҷо истифода баред, то аз ворид кардани рамзи panics, агар он ба қадри кофӣ оптимизатсия нашуда бошад, пешгирӣ кунед.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Тарҳеро тавсиф мекунад, ки сабтро тавсиф мекунад, ки метавонад барои ҷудо кардани сохтори пуштибонӣ барои `T` истифода шавад (ки метавонад trait ё навъи дигари номуайян ба монанди бурида бошад).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕХАТАР: : дар `new` асоснокиро бинед, ки чаро ин варианти хатарнокро истифода мебарад
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Тарҳеро тавсиф мекунад, ки сабтро тавсиф мекунад, ки метавонад барои ҷудо кардани сохтори пуштибонӣ барои `T` истифода шавад (ки метавонад trait ё навъи дигари номуайян ба монанди бурида бошад).
    ///
    /// # Safety
    ///
    /// Ин функсия танҳо дар ҳолати занг задан бехатар аст, агар шартҳои зерин мавҷуд бошанд:
    ///
    /// - Агар `T` `Sized` бошад, ин функсия ҳамеша барои занг задан бехатар аст.
    /// - Агар думи номатлуби `T` ин бошад:
    ///     - як [slice], пас дарозии думи буридаи он бояд бутуни intialized бошад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси андозаи статикӣ) бояд ба `isize` рост ояд.
    ///     - як [trait object], пас қисми vtable нишоннамо бояд ба як vtable-и дуруст барои навъи `T`, ки аз ҷониби як coersion unsizing ба даст омадааст, нишон диҳад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси статикӣ) бояд ба `isize` мувофиқат кунад.
    ///
    ///     - (unstable) [extern type], пас ин функсия ҳамеша барои занг задан бехатар аст, аммо метавонад panic ё ба тариқи дигар арзиши нодурустро баргардонад, зеро тарҳбандии намуди extern маълум нест.
    ///     Ин ҳамон рафтори [`Layout::for_value`] дар истинод ба думи навъи extern аст.
    ///     - дар акси ҳол, даъват кардани ин функсия ба таври консервативӣ иҷозат дода намешавад.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // БЕХАТАР: : мо замимаи зарурии ин функсияҳоро ба шахси зангзада мегузаронем
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // БЕХАТАР: : дар `new` асоснокиро бинед, ки чаро ин варианти хатарнокро истифода мебарад
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` месозад, ки овезон аст, аммо барои ин Тарҳ хуб мувофиқат кардааст.
    ///
    /// Дар хотир доред, ки арзиши нишондиҳанда метавонад эҳтимолан нишоннамои дурустро нишон диҳад, яъне ин маънои онро надорад, ки онро ҳамчун арзиши посбонии "not yet initialized" истифода набаред.
    /// Намудҳое, ки танбалона ҷудо мекунанд, бояд ибтидоиро бо ягон роҳи дигар пайгирӣ кунанд.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // БЕХАТАР: : ба хатсайр баробар будани сифр кафолат дода мешавад
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Як тарҳеро тавсиф мекунад, ки сабтро тавсиф мекунад, ки арзиши ҳамон як тарҳро бо `self` нигоҳ дошта метавонад, аммо он ба хатти `align` мувофиқат мекунад (бо байт чен карда мешавад).
    ///
    ///
    /// Агар `self` аллакай ба масири муқарраршуда ҷавобгӯ бошад, пас `self`-ро бармегардонад.
    ///
    /// Дар хотир доред, ки ин усул ба андозаи умумӣ ҳеҷ гуна замима илова намекунад, новобаста аз он, ки тарҳбозие, ки баргардонида шудааст, ҳамоҳангии дигар дорад.
    /// Ба ибораи дигар, агар `K` андозаи 16 дошта бошад, `K.align_to(32)`*ҳанӯз* андозаи 16 хоҳад дошт.
    ///
    /// Агар хатогии `self.size()` ва `align` дода шартҳои дар [`Layout::from_size_align`] номбаршударо вайрон кунанд, хатогиро бармегардонад.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Ҳаҷми болопӯшеро, ки мо бояд пас аз `self` гузорем, бармегардонад, то суроғаи зерин `align`-ро қонеъ гардонад (бо байт чен карда шавад).
    ///
    /// масалан, агар `self.size()` 9 бошад, пас `self.padding_needed_for(4)` 3-ро бармегардонад, зеро ин миқдори ҳадди ақали байтҳои андова барои гирифтани суроғаи 4 ҳамоҳанг лозим аст (ба назар гирем, ки блоки хотираи мувофиқ аз суроғаи 4 ҳамҷоя сар мешавад).
    ///
    ///
    /// Арзиши бозгашти ин функсия ҳеҷ маъно надорад, агар `align` қудрати ду набошад.
    ///
    /// Дар хотир доред, ки утилитаи баргардондашуда талаб мекунад, ки `align` камтар ё ба ҳамҷоякунии суроғаи оғоз барои тамоми блоки ҷудошудаи хотира баробар бошад.Яке аз роҳҳои қонеъ кардани ин маҳдудият таъмини `align <= self.align()` аст.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Арзиши ҳамаҷониба ин аст:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // ва он гоҳ мо фарқияти фарогириро бармегардонем: `len_rounded_up - len`.
        //
        // Мо арифметикаи модулиро дар тӯли тамоми вақтҳо истифода мебарем:
        //
        // 1. ҳамоҳангсозӣ> 0 кафолат дода мешавад, аз ин рӯ, баробар, 1 ҳамеша дуруст аст.
        //
        // 2.
        // `len + align - 1` метавонад ҳадди аксар `align - 1` лабрез шавад, аз ин рӯ&-mask бо `!(align - 1)` кафолат медиҳад, ки дар сурати пур шудан, худи `len_rounded_up` 0 хоҳад буд.
        //
        //    Ҳамин тариқ, болишти баргашта, вақте ки ба `len` илова карда мешавад, 0 медиҳад, ки масиркунии `align`-ро ба таври ночиз қонеъ мекунад.
        //
        // (Албатта, кӯшишҳои ҷудо кардани блокҳои хотира, ки ҳаҷм ва болопӯшашон ба тариқи дар боло зикршуда бояд ҷудо карда шавад, ба ҳар ҳол боиси хатогӣ мегардад.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Тарҳро бо яклухткунии андозаи ин тарҳ то як қатор ҳамбастагии тарҳбандӣ месозад.
    ///
    ///
    /// Ин ба илова кардани натиҷаи `padding_needed_for` ба андозаи ҳозираи тарҳ баробар аст.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Ин наметавонад лабрез шавад.Иқтибос аз инвариантҳои тарҳ:
        // > `size`, вақте ки ба миқдори наздиктарини `align` мудаввар карда мешавад,
        // > набояд зиёд шавад (яъне, арзиши ҳамаҷониба камтар аз бояд бошад
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Тарҳе тавсиф мекунад, ки сабти `n`-и `self`-ро тавсиф мекунад, бо миқдори мувофиқи ҷойивазкунӣ байни ҳар як, то ба ҳар як мисол андоза ва мувофиқати дархостшуда дода шавад.
    /// Пас аз муваффақият, `(k, offs)`-ро бармегардонад, ки дар он `k` тарҳбандии массив ва `offs` масофаи байни оғози ҳар як унсури массив аст.
    ///
    /// Ҳангоми пур кардани арифметикӣ, `LayoutError` бармегардад.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Ин наметавонад лабрез шавад.Иқтибос аз инвариантҳои тарҳ:
        // > `size`, вақте ки ба миқдори наздиктарини `align` мудаввар карда мешавад,
        // > набояд зиёд шавад (яъне, арзиши ҳамаҷониба камтар аз бояд бошад
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // БЕХАТАР: : self.align аллакай маълум аст, ки эътибор дорад ва sched_size будааст
        // аллакай пӯшонида шудааст.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Тарҳе тавсиф мекунад, ки сабти `self` ва пас аз `next`-ро тавсиф мекунад, аз ҷумла ҳама гуна замимаҳо барои таъмини он, ки `next` дуруст мутобиқ карда мешавад, аммо *ҳеҷ ҷойпӯшкунии қафо*.
    ///
    /// Барои мувофиқ кардани тарҳ бо намояндагии C `repr(C)`, шумо бояд ба `pad_to_align` пас аз васеъ кардани тарҳ бо тамоми майдонҳо занг занед.
    /// (Ҳеҷ имконе барои мувофиқат бо тарҳбандии пешфарзии Rust `repr(Rust)`, as it is unspecified.) вуҷуд надорад
    ///
    /// Дар хотир доред, ки ҳамоҳангсозии тарҳбандии натиҷа ҳадди аксар аз `self` ва `next` хоҳад буд, то ҳамоҳангии ҳарду қисмро таъмин кунад.
    ///
    /// `Ok((k, offset))`-ро бармегардонад, ки дар он `k` тарҳбандии сабти ҳамбастагӣ ва `offset` макони нисбии оғози `next` дар дохили сабти ҳамҷояшуда мебошад (ба назар гирем, ки худи сабт аз ҷуброн 0 оғоз мешавад).
    ///
    ///
    /// Ҳангоми пур кардани арифметикӣ, `LayoutError` бармегардад.
    ///
    /// # Examples
    ///
    /// Барои ҳисоб кардани тарҳбандии сохтори `#[repr(C)]` ва ҷубронкунии майдонҳо аз тарҳбандии майдонҳои он:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Дар хотир доред, ки бо `pad_to_align` ниҳоӣ кунед!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // санҷед, ки он кор мекунад
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Тарҳро тавсиф мекунад, ки сабти `n`-и `self`-ро тавсиф мекунад, дар байни ҳар як мисол ҷой надорад.
    ///
    /// Дар хотир доред, ки ба фарқ аз `repeat`, `repeat_packed` кафолат намедиҳад, ки ҳолатҳои такрории `self` дуруст мувофиқат карда мешаванд, ҳатто агар як мисоли додашудаи `self` дуруст мутобиқ карда шуда бошад.
    /// Ба ибораи дигар, агар тарҳбандие, ки `repeat_packed` баргардонидааст, барои ҷудо кардани массив истифода шавад, кафолат дода намешавад, ки ҳамаи унсурҳои массив мувофиқи мувофиқ оварда мешаванд.
    ///
    /// Ҳангоми пур кардани арифметикӣ, `LayoutError` бармегардад.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Тарҳеро тавсиф мекунад, ки сабти `self`-ро тавсиф мекунад ва пас аз он `next` бидуни замима дар байни ҳарду.
    /// Азбаски ягон замима гузошта нашудааст, масиркунии `next` аҳамият надорад ва ба *тарҳбандии натиҷа дохил намешавад*.
    ///
    ///
    /// Ҳангоми пур кардани арифметикӣ, `LayoutError` бармегардад.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Тарҳе тасвир мекунад, ки сабти `[T; n]`-ро тавсиф мекунад.
    ///
    /// Ҳангоми пур кардани арифметикӣ, `LayoutError` бармегардад.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Параметрҳое, ки ба `Layout::from_size_align` ё конструктори дигари `Layout` дода шудаанд, маҳдудиятҳои ҳуҷҷатгузории онро қонеъ карда наметавонанд.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ба мо ин барои имлои поёнии Хатои trait лозим аст)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}