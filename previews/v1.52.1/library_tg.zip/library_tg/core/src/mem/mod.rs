//! Функсияҳои асосии муносибат бо хотира.
//!
//! Ин модул дорои функсияҳо барои пурсиши андоза ва ҳамоҳангсозии намудҳо, ибтидоӣ ва идоракунии хотира мебошад.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Моликият ва "forgets"-ро дар бораи арзиш **бидуни вайрон кардани деструктор** мегирад.
///
/// Ҳама гуна захираҳое, ки арзиши онро идора мекунанд, ба монанди хотираи теппа ё дастаки файл, дар ҳолати дастнорас абадӣ хоҳанд монд.Аммо, он кафолат намедиҳад, ки нишондиҳандаҳо ба ин хотира боқӣ хоҳанд монд.
///
/// * Агар шумо хоҳед, ки хотираро ифшо кунед, ба [`Box::leak`] нигаред.
/// * Агар шумо хоҳед, ки нишонаи хоми хотираро ба даст оред, ба [`Box::into_raw`] нигаред.
/// * Агар шумо хоҳед, ки арзишро дуруст вайрон карда, деструктори онро иҷро кунед, ба [`mem::drop`] нигаред.
///
/// # Safety
///
/// `forget` ҳамчун `unsafe` қайд карда нашудааст, зеро кафолати бехатарии Rust кафолатеро дар бар намегирад, ки вайронкунандагон ҳамеша кор мекунанд.
/// Масалан, барнома метавонад бо истифода аз [`Rc`][rc] сикли истинод эҷод кунад ё барои баромадан бидуни деструкторҳо ба [`process::exit`][exit] занг занад.
/// Ҳамин тариқ, иҷозат додан ба `mem::forget` аз рамзи бехатар кафолати бехатарии Rust-ро ба куллӣ тағир намедиҳад.
///
/// Гуфта мешавад, ки ифшои захираҳо ба монанди хотира ё объектҳои I/O одатан номатлуб аст.
/// Эҳтиёҷот дар баъзе ҳолатҳои махсусгардонидашудаи истифодаи FFI ё рамзи хатарнок ба миён меояд, аммо ҳатто пас аз он, [`ManuallyDrop`] одатан бартарӣ дода мешавад.
///
/// Азбаски фаромӯш кардани арзиш иҷозат дода мешавад, ҳар як рамзи `unsafe`, ки шумо менависед, бояд ба ин имкон фароҳам орад.Шумо наметавонед қиматеро баргардонед ва интизор шавед, ки даъваткунанда ҳатман деструктори арзишро иҷро мекунад.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Истифодаи бехатарии каноникии `mem::forget` ин вайрон кардани арзиши вайронкунандаи аз ҷониби `Drop` trait татбиқшаванда мебошад.Масалан, ин як `File`-ро ифшо мекунад, яъне
/// фазои гирифтаи тағирёбандаро бозпас гиред, аммо ҳеҷ гоҳ манбаи аслии системаро набандед:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Ин вақте муфид аст, вақте ки моликияти манбаи асосӣ қаблан ба берун аз Rust ба код гузаронида шуд, масалан тавассути интиқоли дескриптори ашё ба коди C.
///
/// # Муносибат бо `ManuallyDrop`
///
/// Дар ҳоле ки `mem::forget` инчунин метавонад барои интиқоли моликияти * хотира истифода шавад, ин кор хатарнок аст.
/// [`ManuallyDrop`] бояд ба ҷои он истифода шавад.Масалан, ин рамзро дида мебароем:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Бо истифода аз мундариҷаи `v` як `String` созед
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ихроҷи `v`, зеро хотираи онро ҳоло `s` идора мекунад
/// mem::forget(v);  // ERROR, v нодуруст аст ва набояд ба вазифа дода шавад
/// assert_eq!(s, "Az");
/// // `s` ба таври мустақим партофта ва хотираи он тақсим карда шудааст.
/// ```
///
/// Бо мисоли боло ду масъала мавҷуданд:
///
/// * Агар байни сохтани `String` ва даъвати `mem::forget()` рамзи бештар илова карда шавад, panic дар дохили он дучанд озодро ба бор меорад, зеро ҳамон хотираро ҳам `v` ва ҳам `s` идора мекунанд.
/// * Пас аз занг задан ба `v.as_mut_ptr()` ва интиқоли моликияти маълумот ба `s`, арзиши `v` нодуруст аст.
/// Ҳатто вақте ки арзиш танҳо ба `mem::forget` интиқол дода мешавад (ки онро тафтиш намекунад), баъзе намудҳо нисбати арзишҳои худ талаботҳои қатъӣ доранд, ки ҳангоми овезон шудан ё бе моликият будан онҳоро беэътибор мекунанд.
/// Истифодаи арзишҳои беэътибор ба ҳеҷ ваҷҳ, аз ҷумла интиқол ба онҳо ё баргардонидани онҳо аз функсияҳо, рафтори номуайянро ташкил медиҳад ва метавонад пиндоштҳои тартибдодашударо вайрон кунад.
///
/// Гузариш ба `ManuallyDrop` ҳарду масъала пешгирӣ мекунад:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Пеш аз он ки мо `v`-ро ба қисмҳои хоми худ ҷудо кунем, боварӣ ҳосил кунед, ки он наафтад!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Акнун `v` ҷудо кунед.Ин амалиёт наметавонад panic бошад, бинобар ин ихроҷ буда наметавонад.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Ниҳоят, як `String` созед.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ба таври мустақим партофта ва хотираи он тақсим карда шудааст.
/// ```
///
/// `ManuallyDrop` ба таври мустақим дукарата пешгирӣ мекунад, зеро мо деструктори "v`"-ро пеш аз анҷом додани ягон чизи дигар хомӯш мекунем.
/// `mem::forget()` ба ин иҷозат намедиҳад, зеро далели худро истеъмол мекунад ва моро маҷбур мекунад, ки онро танҳо пас аз истихроҷи чизи ба мо зарурӣ аз `v` даъват кунем.
/// Ҳатто агар дар байни сохтани `ManuallyDrop` ва сохтани сатр panic ҷорӣ карда шуда бошад (он дар рамз тавре ки нишон дода нашудааст), он ба ихроҷ оварда мерасонад, на озодии дукарата.
/// Ба ибораи дигар, `ManuallyDrop` ба ҷои хато дар паҳлӯи (дубора) партофтан, хатогӣ мекунад.
///
/// Инчунин, `ManuallyDrop` пас аз интиқол додани моликият ба `s` моро аз доштани "touch" `v` бозмедорад-марҳилаи ниҳоии ҳамкорӣ бо `v` барои нобуд кардани он бидуни истифодаи деструктори он комилан пешгирӣ карда мешавад.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Мисли [`forget`], балки инчунин арзишҳои номаҳдудро қабул мекунад.
///
/// Ин функсия танҳо як шим аст, ки ҳангоми барқарорсозии хусусияти `unsized_locals` бароварда мешавад.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Андозаи як навъи байтро бармегардонад.
///
/// Мушаххастараш, ин ҷуброн ба байт байни унсурҳои пай дар пай дар массиви дорои он навъи унсур, аз ҷумла ҷойивазкунӣ мебошад.
///
/// Ҳамин тавр, барои ҳар як намуди `T` ва дарозии `n`, `[T; n]` андозаи `n * size_of::<T>()` дорад.
///
/// Умуман, андозаи як намуд дар маҷмӯаҳо устувор нест, аммо намудҳои мушаххас, ба монанди примитивҳо.
///
/// Дар ҷадвали зерин андозаи ибтидоӣ дода шудааст.
///
/// Намуди |андозаи_оф: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Ғайр аз он, `usize` ва `isize` андозаи якхела доранд.
///
/// Намудҳои `*const T`, `&T`, `Box<T>`, `Option<&T>` ва `Option<Box<T>>` ҳама якхелаанд.
/// Агар `T` андоза карда шуда бошад, ҳамаи ин намудҳо ба андозаи `usize` баробаранд.
///
/// Тағирёбии нишоннамо андозаи онро тағир намедиҳад.Ҳамин тариқ, `&T` ва `&mut T` андозаи якхела доранд.
/// Ҳамин тавр барои `*const T` ва `* mut T`.
///
/// # Андозаи ашёи `#[repr(C)]`
///
/// Намояндагии `C` барои ашё тарҳбандии муайян дорад.
/// Бо ин тарҳ, андозаи ашё низ устувор аст, агар ҳамаи майдонҳо андозаи устувор дошта бошанд.
///
/// ## Андозаи структура
///
/// Барои `structs`, андоза бо алгоритми зерин муайян карда мешавад.
///
/// Барои ҳар як майдон дар структураи бо тартиби эъломия фармоишшуда:
///
/// 1. Андозаи майдонро илова кунед.
/// 2. Андозаи ҳозираро ба зарби наздиктарини [alignment]-и соҳаи оянда яклухт кунед.
///
/// Ниҳоят, андозаи структураро ба зарби наздиктарини [alignment] давр занед.
/// Ҳамоҳангсозии структура одатан бузургтарин ҳамоҳангсозии тамоми майдонҳои он мебошад;инро бо истифодаи `repr(align(N))` тағир додан мумкин аст.
///
/// Баръакси `C`, структураҳои андозаи сифр то як байт бо андозаи ҳамҷоя карда намешаванд.
///
/// ## Андозаи энумҳо
///
/// Энумҳое, ки ба ғайр аз дискриминант ягон маълумот надоранд, ба андозаи enumҳои C дар платформаи тартибдодаашон баробаранд.
///
/// ## Андозаи Иттифоқҳо
///
/// Андозаи иттифоқ андозаи майдони аз ҳама калонтарини он мебошад.
///
/// Баръакси `C`, иттиҳодияҳои андозаи сифр то як байт бо андозаи яклухт карда намешаванд.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Баъзе ибтидоӣ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Баъзе массивҳо
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Баробарии андозаи нишоннамо
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Бо истифода аз `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Андозаи майдони якум 1 аст, бинобар ин ба андозаи он 1 илова кунед.Андоз 1 аст.
/// // Хатти майдони дуюм 2 аст, бинобар ин барои андова ба андозаи 1 илова кунед.Андоз 2 аст.
/// // Андозаи майдони дуюм 2 аст, бинобар ин ба андозаи 2 илова кунед.Андоза 4 аст.
/// // Хатти майдони сеюм 1 аст, аз ин рӯ ба андозаи 0 барои андохтан 0 илова кунед.Андоза 4 аст.
/// // Андозаи майдони сеюм 1 аст, бинобар ин ба андозаи 1 илова кунед.Андозаи 5 аст.
/// // Ниҳоят, ҳамоҳангсозии структура 2 аст (зеро ҳамоҳангии калонтарин дар майдонҳои он 2 аст), бинобар ин андозаи андохтан 1 илова кунед.
/// // Андозаи 6 аст.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Сохтмонҳои Tuple ҳамон қоидаҳоро риоя мекунанд.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Дар хотир доред, ки аз нав танзимкунии майдонҳо метавонад андозаи онро коҳиш диҳад.
/// // Мо метавонем ҳарду байтро бо гузоштани `third` пеш аз `second` хориҷ кунем.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Андозаи иттиҳодия андозаи майдони калонтарин аст.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Андозаи ишора ба байтро бар мегардонад.
///
/// Ин одатан ҳамон `size_of::<T>()` аст.
/// Аммо, вақте ки `T`*андозаи* статикӣ маълум надорад, масалан, буридаи [`[T]`][slice] ё [trait object], пас `size_of_val` метавонад барои ба даст овардани андозаи аз ҷиҳати динамикӣ маълум истифода шавад.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕХАТАР: : `val` истинод аст, бинобар ин он нишоннамои хоми дуруст аст
    unsafe { intrinsics::size_of_val(val) }
}

/// Андозаи ишора ба байтро бар мегардонад.
///
/// Ин одатан ҳамон `size_of::<T>()` аст.Аммо, вақте ки `T`*андозаи* статикӣ маълум надорад, масалан, буридаи [`[T]`][slice] ё [trait object], пас `size_of_val_raw` метавонад барои ба даст овардани андозаи аз ҷиҳати динамикӣ маълум истифода шавад.
///
/// # Safety
///
/// Ин функсия танҳо дар ҳолати занг задан бехатар аст, агар шартҳои зерин мавҷуд бошанд:
///
/// - Агар `T` `Sized` бошад, ин функсия ҳамеша барои занг задан бехатар аст.
/// - Агар думи номатлуби `T` ин бошад:
///     - як [slice], пас дарозии думи буридаи он бояд бутуни ибтидоӣ бошад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси статикӣ) бояд ба `isize` рост ояд.
///     - як [trait object], пас қисми vtable нишоннамо бояд ба як vtable мӯътабаре, ки аз ҷониби як маҷбуркунии беандоза ба даст омадааст, ишора кунад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси андозаи статикӣ) бояд ба `isize` рост ояд.
///
///     - (unstable) [extern type], пас ин функсия ҳамеша барои занг задан бехатар аст, аммо метавонад panic ё ба тариқи дигар арзиши нодурустро баргардонад, зеро тарҳбандии намуди extern маълум нест.
///     Ин ҳамон рафтори [`size_of_val`] дар истинод ба навъи бо думи навъи extern аст.
///     - дар акси ҳол, даъват кардани ин функсия ба таври консервативӣ иҷозат дода намешавад.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЕХАТАР: : даъваткунанда бояд нишоннамои дурусти ашёро пешниҳод кунад
    unsafe { intrinsics::size_of_val(val) }
}

/// Ҳамоҳангсозии ҳадди ақали талабшудаи [ABI]-ро бармегардонад.
///
/// Ҳар истинод ба арзиши навъи `T` бояд зарби ин рақам бошад.
///
/// Ин ҳамоҳангсозӣ барои майдонҳои структура мебошад.Он метавонад аз ҳамоҳангсозии афзалтар хурд бошад.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ҳамоҳангсозии ҳадди аққали [ABI]-и навъи қиматеро, ки `val` ба он ишора мекунад, бармегардонад.
///
/// Ҳар истинод ба арзиши навъи `T` бояд зарби ин рақам бошад.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕХАТАР: : val ин истинод аст, бинобар ин он нишоннамои хоми дуруст аст
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ҳамоҳангсозии ҳадди ақали талабшудаи [ABI]-ро бармегардонад.
///
/// Ҳар истинод ба арзиши навъи `T` бояд зарби ин рақам бошад.
///
/// Ин ҳамоҳангсозӣ барои майдонҳои структура мебошад.Он метавонад аз ҳамоҳангсозии афзалтар хурд бошад.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Ҳамоҳангсозии ҳадди аққали [ABI]-и навъи қиматеро, ки `val` ба он ишора мекунад, бармегардонад.
///
/// Ҳар истинод ба арзиши навъи `T` бояд зарби ин рақам бошад.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // БЕХАТАР: : val ин истинод аст, бинобар ин он нишоннамои хоми дуруст аст
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Ҳамоҳангсозии ҳадди аққали [ABI]-и навъи қиматеро, ки `val` ба он ишора мекунад, бармегардонад.
///
/// Ҳар истинод ба арзиши навъи `T` бояд зарби ин рақам бошад.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ин функсия танҳо дар ҳолати занг задан бехатар аст, агар шартҳои зерин мавҷуд бошанд:
///
/// - Агар `T` `Sized` бошад, ин функсия ҳамеша барои занг задан бехатар аст.
/// - Агар думи номатлуби `T` ин бошад:
///     - як [slice], пас дарозии думи буридаи он бояд бутуни ибтидоӣ бошад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси статикӣ) бояд ба `isize` рост ояд.
///     - як [trait object], пас қисми vtable нишоннамо бояд ба як vtable мӯътабаре, ки аз ҷониби як маҷбуркунии беандоза ба даст омадааст, ишора кунад ва андозаи *тамоми арзиш*(дарозии думи динамикӣ + префикси андозаи статикӣ) бояд ба `isize` рост ояд.
///
///     - (unstable) [extern type], пас ин функсия ҳамеша барои занг задан бехатар аст, аммо метавонад panic ё ба тариқи дигар арзиши нодурустро баргардонад, зеро тарҳбандии намуди extern маълум нест.
///     Ин ҳамон рафтори [`align_of_val`] дар истинод ба навъи бо думи навъи extern аст.
///     - дар акси ҳол, даъват кардани ин функсия ба таври консервативӣ иҷозат дода намешавад.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // БЕХАТАР: : даъваткунанда бояд нишоннамои дурусти ашёро пешниҳод кунад
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `true`-ро бармегардонад, агар арзишҳои навъи `T` аҳамият дошта бошанд.
///
/// Ин сирфан як ишораи оптимизатсия аст ва мумкин аст ба тариқи консервативӣ амалӣ карда шавад:
/// он метавонад `true`-ро барои намудҳое баргардонад, ки дар асл ба партофтан ниёз надоранд.
/// Тавре ки ҳамеша баргардонидани `true` мебуд татбиқи дурусти ин вазифа бошад.Аммо агар ин функсия воқеан `false`-ро баргардонад, пас шумо метавонед мутмаин бошед, ки тарки `T` ягон таъсири манфӣ надорад.
///
/// Татбиқи сатҳи пасти чизҳое, ба монанди коллексияҳо, ки бояд маълумоти худро дастӣ партоянд, бояд ин функсияро истифода баранд, то ҳангоми нобуд шудан тамоми мундариҷаи бесабаб пешгирӣ карда нашавад.
///
/// Ин метавонад дар сохтани озодӣ фарқе ба амал наорад (дар он ҷо ҳалқае, ки ҳеҷ гуна таъсироти тарафайн надорад, ба осонӣ ошкор ва бартараф карда мешавад), аммо аксар вақт бурди калон барои сохтани сознамо мебошад.
///
/// Дар хотир доред, ки [`drop_in_place`] ин санҷишро аллакай иҷро мекунад, бинобар ин, агар миқдори коратон ба миқдори ками зангҳои [`drop_in_place`] кам карда шавад, бо истифода аз ин нолозим аст.
/// Аз ҷумла қайд кунед, ки шумо метавонед як буридаи [`drop_in_place`] кунед ва ин як санҷиши ягонаи need_drop барои ҳамаи арзишҳоро анҷом медиҳад.
///
/// Аз ин рӯ, чунин намудҳо ба монанди Vec танҳо `drop_in_place(&mut self[..])` бидуни истифодаи `needs_drop` ба таври возеҳ.
/// Аз тарафи дигар, намудҳое, ба монанди [`HashMap`], бояд якбора арзишҳоро партоянд ва бояд ин API-ро истифода баранд.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Ин намунаи он аст, ки чӣ гуна коллексия метавонад аз `needs_drop` истифода барад:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // маълумотро партоед
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Арзиши навъи `T`-ро, ки бо намунаи байтии сифр ифода ёфтааст, бармегардонад.
///
/// Ин маънои онро дорад, ки, масалан, байти пуркунии `(u8, u16)` ҳатман сифр карда намешавад.
///
/// Кафолате вуҷуд надорад, ки намунаи байтии сифр арзиши дурусти баъзе намуди `T`-ро ифода кунад.
/// Масалан, намунаи байтии сифр барои намудҳои истинод ("&T`, `&mut T`) ва нишоннамои функсияҳо арзиши дуруст надорад.
/// Истифодаи `zeroed` дар чунин намудҳо боиси фаврии [undefined behavior][ub] мегардад, зеро [the Rust compiler assumes][inv], ки ҳамеша дар як тағирёбандае, ки онро ибтидоӣ ҳисоб мекунад, арзиши дуруст дорад.
///
///
/// Ин ҳамон таъсири [`MaybeUninit::zeroed().assume_init()`][zeroed] дорад.
/// Ин барои FFI баъзан муфид аст, аммо бояд умуман пешгирӣ карда шавад.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Истифодаи дурусти ин функсия: ибтидоии бутун бо сифр.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Нодуруст* истифода бурдани ин функсия: ибтидо гузоштани истинод бо сифр.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Рафтори номуайян!
/// let _y: fn() = unsafe { mem::zeroed() }; // Ва боз!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки арзиши сифр барои `T` эътибор дорад.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Оғози муқаррарии хотираи Rust-ро аз роҳи вонамуд кардани арзиши навъи `T` мегузарад ва дар ҳоле ки ҳеҷ коре намекунад.
///
/// **Ин вазифа бекор карда шудааст.** Ба ҷои он [`MaybeUninit<T>`]-ро истифода баред.
///
/// Сабаби фарсудашавӣ дар он аст, ки функсияро асосан дуруст истифода бурдан мумкин нест: он ҳамон таъсири [`MaybeUninit::uninit().assume_init()`][uninit] дорад.
///
/// Тавре [`assume_init` documentation][assume_init] мефаҳмонад, [the Rust compiler assumes][inv], ки арзишҳо дуруст оғоз карда мешаванд.
/// Дар натиҷа, даъват кардани масалан
/// `mem::uninitialized::<bool>()` боиси рафтори фаврии номуайян барои баргардонидани `bool` аст, ки бешубҳа ё `true` ё `false` нест.
/// Бадтар аз он, хотираи воқеан номаълум, ба монанди он чизе, ки дар ин ҷо бармегардад, махсус аст, зеро тартибдиҳанда медонад, ки он арзиши собит надорад.
/// Ин ба як рафтори номуайян дар доштани тағири тағирёбанда дар тағирёбанда, ҳатто агар он тағирёбанда навъи бутун дошта бошад.
/// (Аҳамият диҳед, ки қоидаҳои атрофи бутунҳои номаълум ҳанӯз ба анҷом нарасидаанд, аммо то он даме, ки аз онҳо даст кашед.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки арзиши воҳидшуда барои `T` эътибор дорад.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Қиматҳоро дар ду макони тағирёбанда иваз мекунад, бидуни деинализатсия кардани яке аз онҳо.
///
/// * Агар шумо хоҳед, ки бо арзиши пешфарз ё дурӯғ иваз кунед, ба [`take`] нигаред.
/// * Агар шумо хоҳед, ки бо арзиши гузариш иваз карда, арзиши пешинаро баргардонед, ба [`replace`] нигаред.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // БЕХАТАР: : нишондиҳандаҳои хом аз маълумотномаҳои бехатарии тағйирёбанда сохта шудаанд, ки ҳама чизро қонеъ мекунанд
    // маҳдудиятҳо дар `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest`-ро бо арзиши пешфарзии `T` иваз карда, арзиши `dest`-и қаблиро бармегардонад.
///
/// * Агар шумо хоҳед, ки арзиши ду тағирёбандаро иваз кунед, ба [`swap`] нигаред.
/// * Агар шумо хоҳед, ки ба ҷои арзиши пешфарз бо арзиши гузариш иваз кунед, нигаред ба [`replace`].
///
/// # Examples
///
/// Мисоли оддӣ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` имкон медиҳад, ки соҳиби соҳаи структураро бо иваз кардани он бо арзиши "empty" ба даст орад.
/// Бе `take` шумо метавонед ба чунин масъалаҳо дучор оед:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Дар хотир доред, ки `T` ҳатман [`Clone`]-ро татбиқ намекунад, бинобар ин, ҳатто наметавонад `self.buf`-ро клон карда аз нав танзим кунад.
/// Аммо `take` метавонад барои ҷудо кардани арзиши аслии `self.buf` аз `self` истифода шавад ва имкон медиҳад, ки он баргардонида шавад:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src`-ро ба `dest`-и истинодшуда бармегардонад, арзиши `dest`-и қаблиро бармегардонад.
///
/// На арзиш партофта мешавад.
///
/// * Агар шумо хоҳед, ки арзиши ду тағирёбандаро иваз кунед, ба [`swap`] нигаред.
/// * Агар шумо хоҳед, ки онро бо арзиши пешфарз иваз кунед, ба [`take`] нигаред.
///
/// # Examples
///
/// Мисоли оддӣ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ба истеъмоли майдони структура бо иваз кардани он бо арзиши дигар имкон медиҳад.
/// Бе `replace` шумо метавонед ба чунин масъалаҳо дучор оед:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Дар хотир доред, ки `T` ҳатман [`Clone`]-ро татбиқ намекунад, бинобар ин мо ҳатто наметавонем `self.buf[i]`-ро барои пешгирӣ аз ҳаракат клон кунем.
/// Аммо `replace` метавонад барои ҷудо кардани арзиши аслӣ дар ин шохис аз `self` истифода шавад ва имкон медиҳад, ки он баргардонида шавад:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // БЕХАТАР: : Мо аз `dest` мехонем, аммо баъд бевосита ба он `src` нависем,
    // ба тавре ки арзиши кӯҳна такрор намешавад.
    // Ҳеҷ чиз партофта нашудааст ва дар ин ҷо ҳеҷ чиз наметавонад panic кунад.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Арзишро ихтиёрдорӣ мекунад.
///
/// Ин бо роҳи даъвати татбиқи далели [`Drop`][drop] чунин мекунад.
///
/// Ин барои намудҳое, ки `Copy`-ро татбиқ мекунанд, ба таври муассир ҳеҷ коре намекунад, масалан
/// integers.
/// Чунин қиматҳо нусхабардорӣ карда мешаванд ва _then_ ба функсия интиқол дода мешавад, аз ин рӯ пас аз ин занги функсия арзиши он боқӣ мемонад.
///
///
/// Ин функсия ҷодугарӣ нест;онро ба маънои аслӣ чун муайян мекунанд
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Азбаски `_x` ба функсия кӯчонида шудааст, он пеш аз бозгашти функсия ба таври худкор партофта мешавад.
///
/// [drop]: Drop
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // ба таври возеҳ vector партофта шавад
/// ```
///
/// Азбаски [`RefCell`] қоидаҳои қарзро дар вақти корӣ иҷро мекунад, `drop` метавонад қарзи [`RefCell`]-ро озод кунад:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // аз қарзи тағирёбанда дар ин слот даст кашед
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Бутунҳо ва навъҳои дигари [`Copy`], ки ба `drop` бетаъсиранд.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // нусхаи `x` кӯчонида ва партофта мешавад
/// drop(y); // нусхаи `y` кӯчонида ва партофта мешавад
///
/// println!("x: {}, y: {}", x, y.0); // ҳанӯз ҳам дастрас аст
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src`-ро ҳамчун навъи `&U` тафсир мекунад ва пас `src`-ро бе интиқол додани арзиши дарҷшуда мехонад.
///
/// Ин функсия нишон медиҳад, ки нишоннамои `src` барои байтҳои [`size_of::<U>`][size_of] бо роҳи интиқоли `&T` ба `&U` ва пас хондани `&U` эътибор дорад (ба истиснои ин, он тавре ба амал оварда мешавад, ки ҳатто вақте ки `&U` талаботро ба ҳамбастагӣ шадидтар мекунад, аз `&T`).
/// Он инчунин ба ҷои берун рафтан аз `src`, ба таври хатарнок нусхаи арзиши мавҷудбударо эҷод мекунад.
///
/// Агар `T` ва `U` андозаи мухталиф дошта бошанд, ин хатои тартибдодашуда нест, аммо тавсия дода мешавад, ки танҳо ин функсияро истифода баред, ки дар он андозаи `T` ва `U` якхела бошанд.Ин функсия [undefined behavior][ub]-ро ба кор меандозад, агар `U` аз `T` калонтар бошад.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Маълумотро аз 'foo_array' нусхабардорӣ кунед ва онро ҳамчун 'Foo' баррасӣ кунед
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Маълумоти нусхабардоршударо тағир диҳед
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Мазмуни 'foo_array' набояд тағир меёфт
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Агар U талабот ба ҳамбастагии баландтар дошта бошад, src метавонад ба таври мувофиқ мутобиқ карда нашавад.
    if align_of::<U>() > align_of::<T>() {
        // БЕХАТАР: : `src` истинодест, ки барои мутолиа кафолат дода мешавад.
        // Зангзан бояд кафолат диҳад, ки интиқоли воқеӣ бехатар аст.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // БЕХАТАР: : `src` истинодест, ки барои мутолиа кафолат дода мешавад.
        // Мо танҳо тафтиш кардем, ки `src as *const U` дуруст мувофиқат кардааст.
        // Зангзан бояд кафолат диҳад, ки интиқоли воқеӣ бехатар аст.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Намуди ношаффоф, ки дискриминанти енумро ифода мекунад.
///
/// Барои маълумоти иловагӣ ба функсияи [`discriminant`] дар ин модул нигаред.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Ин татбиқи trait-ро баровардан мумкин нест, зеро мо намехоҳем дар T ҳудуд дошта бошем.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Арзиши нодиреро, ки варианти enum-ро дар `v` муайян мекунад, бармегардонад.
///
/// Агар `T` enum набошад, даъвати ин функсия ба рафтори номуайян оварда намерасонад, аммо арзиши бозгаштан номуайян аст.
///
///
/// # Stability
///
/// Дискриминанти варианти enum метавонад тағир ёбад, агар таърифи enum тағир ёбад.
/// Дискриминанти баъзе вариантҳо дар байни маҷмӯаҳо бо ҳамон як тартибдиҳанда тағир нахоҳад ёфт.
///
/// # Examples
///
/// Ин метавонад барои муқоисаи enums, ки маълумотро дар бар мегирад, ҳангоми сарфи назар кардани маълумоти воқеӣ истифода шавад:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Шумораи вариантҳои навъи enum `T`-ро бармегардонад.
///
/// Агар `T` enum набошад, даъвати ин функсия ба рафтори номуайян оварда намерасонад, аммо арзиши бозгаштан номуайян аст.
/// Баробар, агар `T` enum бо вариантҳои бештар аз `usize::MAX` бошад, арзиши баргашта номуайян аст.
/// Вариантҳои беодам ҳисоб карда мешаванд.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}