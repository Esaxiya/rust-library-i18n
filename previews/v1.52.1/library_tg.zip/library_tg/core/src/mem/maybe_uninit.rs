use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Намуди парпеч барои сохтани ҳолатҳои номатлуби `T`.
///
/// # Инисиализатсия инвариантӣ аст
///
/// Тартибдиҳанда, дар маҷмӯъ, тахмин мезанад, ки тағирёбанда мувофиқи талаботи навъи тағирёбанда ба таври дуруст оғоз карда шудааст.Масалан, тағирёбандаи навъи истинод бояд мутобиқ ва ғайри NULL бошад.
/// Ин инвариантест, ки бояд *ҳамеша* риоя карда шавад, ҳатто дар рамзи хатарнок.
/// Дар натиҷа, ба сифр оғоз кардани тағирёбандаи навъи истинод боиси фаврии [undefined behavior][ub] мегардад, новобаста аз он, ки оё ин истинод ҳамеша барои дастрасӣ ба хотира одат мекунад:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // рафтори номуайян!⚠️
/// // Рамзи баробар бо `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // рафтори номуайян!⚠️
/// ```
///
/// Ин аз ҷониби тартибдиҳанда барои оптимизатсияҳои гуногун, аз қабили интихоби санҷишҳои вақти корӣ ва оптимизатсияи тарҳбандии `enum` истифода мешавад.
///
/// Ба ин монанд, хотираи комилан номаълум метавонад дорои ягон мундариҷа бошад, дар ҳоле ки `bool` бояд ҳамеша `true` ё `false` бошад.Аз ин рӯ, эҷоди `bool` номаълум рафтори номуайян аст:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // рафтори номуайян!⚠️
/// // Рамзи баробар бо `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // рафтори номуайян!⚠️
/// ```
///
/// Гузашта аз ин, хотираи беасос махсуси он аст, ки арзиши собит надорад ("fixed" ба маънои "it won't change without being written to").Якчанд маротиба хондани як байти ношинос метавонад натиҷаҳои гуногун диҳад.
/// Ин як рафтори номуайян доштани маълумоти номатлубро дар як тағирёбанда месозад, ҳатто агар он тағирёбанда навъи бутун дошта бошад, дар акси ҳол метавонад ҳар гуна *собит* битро нигоҳ дорад:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // рафтори номуайян!⚠️
/// // Рамзи баробар бо `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // рафтори номуайян!⚠️
/// ```
/// (Аҳамият диҳед, ки қоидаҳои атрофи бутунҳои номаълум ҳанӯз ба анҷом нарасидаанд, аммо то он даме, ки аз онҳо даст кашед.)
///
/// Бар замми ин, фаромӯш накунед, ки аксар намудҳо инвариантҳои иловагӣ доранд, ба ғайр аз он, ки онҳо дар сатҳи нав ибтидоӣ ҳисобида мешаванд.
/// Масалан, [`Vec<T>`]-и '1' оғозшуда ҳисобидашуда ҳисобида мешавад (дар доираи татбиқи ҷорӣ; ин кафолати устуворро дар бар намегирад), зеро талаби ягонае, ки тартибдиҳанда дар бораи он медонад, ин аст, ки нишоннамои додаҳо бояд нол бошад.
/// Эҷоди чунин `Vec<T>` боиси рафтори *фаврӣ* номуайян нест, балки рафтори номуайянро бо аксари амалиётҳои бехатар (аз ҷумла тарки он) ба вуҷуд меорад.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` хидмат мекунад, то коди хатарнок барои мубориза бо маълумоти номатлуб истифода шавад.
/// Ин як сигналест, ки ба тартибдиҳанда ишора мекунад, ки маълумот дар ин ҷо мумкин нест * оғоз карда шавад:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Истиноди возеҳи номаълумро эҷод кунед.
/// // Тартибдиҳанда медонад, ки маълумот дар дохили `MaybeUninit<T>` метавонад нодуруст бошад ва аз ин рӯ ин UB нест:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Онро ба арзиши дуруст таъин кунед.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Маълумоти ибтидоиро истихроҷ кунед-ин танҳо пас аз * дуруст оғоз кардани `x` иҷозат дода мешавад!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Пас, тартибдиҳанда медонад, ки дар ин код ҳеҷ гуна тахминҳо ё оптимизатсияҳои нодурустро роҳ надиҳед.
///
/// Шумо метавонед `MaybeUninit<T>`-ро ҳамчун `Option<T>` монанд шуморед, аммо бидуни пайгирии вақти кор ва бидуни санҷиши бехатарӣ.
///
/// ## out-pointers
///
/// Шумо метавонед `MaybeUninit<T>`-ро барои татбиқи "out-pointers" истифода баред: ба ҷои баргардонидани маълумот аз функсия, онро ба хотираи (uninitialized) нишон диҳед, то натиҷаро ба он дохил кунед.
/// Ин метавонад муфид бошад, вақте ки барои зангзананда муҳим аст, ки чӣ гуна захира шудани хотираи натиҷаҳоро ҷудо кунад ва шумо мехоҳед аз ҳаракатҳои нодаркор ҷилавгирӣ кунед.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` мундариҷаи кӯҳнаро напартояд, ки ин муҳим аст.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Ҳоло мо медонем, ки `v` оғоз шудааст!Ин инчунин боварӣ ҳосил мекунад, ки vector дуруст афтодааст.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Оғозкунии массиви унсурҳо
///
/// `MaybeUninit<T>` метавонад барои оғози унсури элементҳои массиви калон истифода шавад:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Массиви номатлуби `MaybeUninit` созед.
///     // `assume_init` бехатар аст, зеро навъе, ки мо даъво дорем, ки онро дар инҷо оғоз кардаем, як тӯдаи "MaybeUninit" аст, ки ибтидоиро талаб намекунад.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Тарки `MaybeUninit` ҳеҷ коре намекунад.
///     // Ҳамин тариқ, истифодаи ҷои нишондоди хом ба ҷои `ptr::write` боиси коҳиш ёфтани арзиши пешинаи номатлуб намешавад.
/////
///     // Инчунин агар дар ин давра panic мавҷуд бошад, мо хотираи ихроҷ дорем, аммо ягон масъалаи бехатарии хотира вуҷуд надорад.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Ҳама чиз оғоз карда шудааст.
///     // Массивро ба намуди ибтидоӣ интиқол диҳед.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Шумо инчунин метавонед бо массивҳои қисман ибтидоёфта кор кунед, ки онҳоро дар сохторҳои сатҳи паст пайдо кардан мумкин аст.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Массиви номатлуби `MaybeUninit` созед.
/// // `assume_init` бехатар аст, зеро навъе, ки мо даъво дорем, ки онро дар инҷо оғоз кардаем, як тӯдаи "MaybeUninit" аст, ки ибтидоиро талаб намекунад.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Шумораи унсурҳои таъинкардаро ҳисоб кунед.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Барои ҳар як ҷузъи массив, агар мо онро ҷудо карда бошем.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Оғоз кардани сохтор ба соҳа
///
/// Шумо метавонед `MaybeUninit<T>` ва макроиқтисодии [`std::ptr::addr_of_mut`]-ро барои оғози сохторҳо ба соҳа истифода баред:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Оғоз кардани майдони `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Оғоз кардани майдони `list` Агар дар ин ҷо panic мавҷуд бошад, пас `String` дар майдони `name` мечакад.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Ҳама майдонҳо ибтидоӣ карда шудаанд, бинобар ин мо ба `assume_init` занг мезанем, то Foo-и ибтидоиро ба даст орем.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` кафолат дода мешавад, ки ба андозаи `T`, ҳаҷм ва ABI баробар аст:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Аммо дар хотир доред, ки навъи *дорои*`MaybeUninit<T>` ҳатман ҳамон як тарҳ нест;Rust ба таври куллӣ кафолат намедиҳад, ки майдонҳои `Foo<T>` бо `Foo<U>` ҳамон тартибот доранд, ҳатто агар `T` ва `U` як андоза ва ҳамоҳангӣ дошта бошанд.
///
/// Ғайр аз он, зеро ягон арзиши бит барои `MaybeUninit<T>` эътибор дорад, тартибдиҳанда наметавонад оптимизатсияҳои non-zero/niche-filling-ро татбиқ кунад, ки эҳтимолан андозаи калонтарро ба бор орад:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Агар `T` FFI-бехатар бошад, пас `MaybeUninit<T>` низ чунин аст.
///
/// Дар ҳоле ки `MaybeUninit` `#[repr(transparent)]` аст (бо нишон додани он ба ҳамон андоза, ҳамоҳангӣ ва ABI ҳамчун `T` кафолат медиҳад), ин ҳеҷ як огоҳиҳои қаблиро тағир намедиҳад *.
/// `Option<T>` ва `Option<MaybeUninit<T>>` то ҳол метавонанд андозаи гуногун дошта бошанд ва намудҳое, ки майдони навъи `T` доранд, метавонанд ба тариқи гуногун гузошта шаванд (ва андозаи онҳо), агар ин майдон `MaybeUninit<T>` бошад.
/// `MaybeUninit` навъи иттифоқ аст ва `#[repr(transparent)]` дар иттифоқҳо ноустувор аст (ниг. [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Бо мурури замон, кафолатҳои дақиқи `#[repr(transparent)]` дар иттифоқҳо метавонанд таҳаввул ёбанд ва `MaybeUninit` метавонанд `#[repr(transparent)]` боқӣ монанд ё намонанд.
/// Гуфта мешавад, ки `MaybeUninit<T>`*ҳамеша* кафолат медиҳад, ки он ба андозаи `T` ҳамон андоза, ҳамоҳангӣ ва ABI дорад;танҳо он аст, ки роҳи `MaybeUninit`, ки ин кафолатро татбиқ мекунад, метавонад таҳаввул ёбад.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Ашёи ланг, то мо метавонем намудҳои дигарро дар он печонем.Ин барои генераторҳо муфид аст.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ба `T::clone()` занг назанем, мо наметавонем бидонем, ки мо барои ин кофӣ оғоз кардаем.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// `MaybeUninit<T>` навро бо арзиши додашуда оғоз мекунад.
    /// Бо арзиши баргардонидани ин вазифа ба [`assume_init`] занг задан бехатар аст.
    ///
    /// Дар хотир доред, ки тарки `MaybeUninit<T>` ҳеҷ гоҳ ба рамзи афтодани "T" занг намезанад.
    /// Ин масъулияти шумост, то боварӣ ҳосил кунед, ки `T` дар ҳолати оғозёбӣ партофта мешавад.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// `MaybeUninit<T>` навро дар ҳолати номаълум месозад.
    ///
    /// Дар хотир доред, ки тарки `MaybeUninit<T>` ҳеҷ гоҳ ба рамзи афтодани "T" занг намезанад.
    /// Ин масъулияти шумост, то боварӣ ҳосил кунед, ки `T` дар ҳолати оғозёбӣ партофта мешавад.
    ///
    /// Барои мисолҳо ба [type-level documentation][MaybeUninit] нигаред.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Массиви нави ашёи `MaybeUninit<T>`-ро дар ҳолати номаълум созед.
    ///
    /// Note: дар як нусхаи future Rust, ин усул метавонад ҳангоми носозгории массив ба [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) иҷозат надиҳад.
    ///
    /// Мисоли дар поён овардашуда метавонад `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`-ро истифода барад.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Як буридаи маълумотро (эҳтимолан хурдтар) бармегардонад, ки воқеан хонда шудааст
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // БЕХАТАР: : `[MaybeUninit<_>; LEN]` номаълум эътибор дорад.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `MaybeUninit<T>`-и навро дар ҳолати номаълум месозад, бо хотира бо байтҳои `0` пур карда мешавад.Ин аз `T` вобаста аст, ки оё он аллакай барои оғози дуруст имкон медиҳад.
    ///
    /// Масалан, `MaybeUninit<usize>::zeroed()` оғоз карда шудааст, аммо `MaybeUninit<&'static i32>::zeroed()` ин нест, ки маълумотномаҳо набояд нол бошанд.
    ///
    /// Дар хотир доред, ки тарки `MaybeUninit<T>` ҳеҷ гоҳ ба рамзи афтодани "T" занг намезанад.
    /// Ин масъулияти шумост, то боварӣ ҳосил кунед, ки `T` дар ҳолати оғозёбӣ партофта мешавад.
    ///
    /// # Example
    ///
    /// Истифодаи дурусти ин функсия: оғози сохтор бо сифр, ки дар он ҳамаи майдонҳои сохтор метавонанд бит-0-ро ҳамчун арзиши дуруст нигоҳ доранд.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Нодуруст* истифода бурдани ин функсия: даъват кардани `x.zeroed().assume_init()`, вақте ки `0` намунаи бит барои эътибор надорад:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Дар дохили як ҷуфт мо `NotZero` месозем, ки дискриминанти дуруст надорад.
    /// // Ин рафтори номуайян аст.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // БЕХАТАР: : `u.as_mut_ptr()` ба хотираи ҷудошуда ишора мекунад.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Арзиши `MaybeUninit<T>`-ро таъин мекунад.
    /// Ин ягон арзиши қаблиро бидуни тарки он сабт мекунад, бинобар ин эҳтиёт шавед, ки инро ду маротиба истифода набаред, агар шумо нахоҳед, ки деструкторро иҷро накунед.
    ///
    /// Барои роҳати шумо, ин инчунин истиноди тағиршавандаро ба мундариҷаи (ҳоло бехатар оғозшуда) `self` бармегардонад.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // БЕХАТАР: : Мо танҳо ин арзишро оғоз кардем.
        unsafe { self.assume_init_mut() }
    }

    /// Ба арзиши ишоракунанда ишора мекунад.
    /// Хондан аз ин нишоннамо ё табдил додани он ба истинод рафтори номуайян аст, агар `MaybeUninit<T>` оғоз нашуда бошад.
    /// Навиштан ба хотира, ки ин нишоннамои (non-transitively) ба он ишора мекунад, рафтори номуайян аст (ба истиснои дохили `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ба `MaybeUninit<T>` истинод эҷод кунед.Ин хуб аст, зеро мо онро оғоз кардем.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Истифодаи * нодурусти ин усул:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Мо ба vector uninitialized ишора кардем!Ин рафтори номуайян аст.⚠️
    /// ```
    ///
    /// (Аҳамият диҳед, ки қоидаҳои атрофи истинодҳо ба маълумоти номатлуб ҳанӯз ба анҷом нарасидаанд, аммо то он даме, ки онҳо пешгирӣ карда шаванд)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ва `ManuallyDrop` ҳам `repr(transparent)` мебошанд, бинобар ин мо метавонем нишоннаморо андохтем.
        self as *const _ as *const T
    }

    /// Нишондиҳандаи тағирёбандаро ба арзиши мавҷудбуда меорад.
    /// Хондан аз ин нишоннамо ё табдил додани он ба истинод рафтори номуайян аст, агар `MaybeUninit<T>` оғоз нашуда бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ба `MaybeUninit<Vec<u32>>` истинод эҷод кунед.
    /// // Ин хуб аст, зеро мо онро оғоз кардем.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Истифодаи * нодурусти ин усул:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Мо ба vector uninitialized ишора кардем!Ин рафтори номуайян аст.⚠️
    /// ```
    ///
    /// (Аҳамият диҳед, ки қоидаҳои атрофи истинодҳо ба маълумоти номатлуб ҳанӯз ба анҷом нарасидаанд, аммо то он даме, ки онҳо пешгирӣ карда шаванд)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ва `ManuallyDrop` ҳам `repr(transparent)` мебошанд, бинобар ин мо метавонем нишоннаморо андохтем.
        self as *mut _ as *mut T
    }

    /// Арзишро аз контейнери `MaybeUninit<T>` хориҷ мекунад.Ин як роҳи олие барои кафолат додани маълумот аст, зеро дар натиҷаи `T` ба тарзи муқаррарии тарки он вобаста аст.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор дорад, ба шахси зангзада вобаста аст.Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, даъват кардани он рафтори фаврии номуайянро ба бор меорад.
    /// [type-level documentation][inv] дорои маълумоти бештар дар бораи инвариантӣ мебошад.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Бар замми ин, фаромӯш накунед, ки аксар намудҳо инвариантҳои иловагӣ доранд, ба ғайр аз он, ки онҳо дар сатҳи нав ибтидоӣ ҳисобида мешаванд.
    /// Масалан, [`Vec<T>`]-и '1' оғозшуда ҳисобидашуда ҳисобида мешавад (дар доираи татбиқи ҷорӣ; ин кафолати устуворро дар бар намегирад), зеро талаби ягонае, ки тартибдиҳанда дар бораи он медонад, ин аст, ки нишоннамои додаҳо бояд нол бошад.
    ///
    /// Эҷоди чунин `Vec<T>` боиси рафтори *фаврӣ* номуайян нест, балки рафтори номуайянро бо аксари амалиётҳои бехатар (аз ҷумла тарки он) ба вуҷуд меорад.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Истифодаи * нодурусти ин усул:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ҳанӯз оғоз нашуда буд, бинобар ин ин сатри охир рафтори номуайянро ба бор овард.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` оғоз карда шудааст.
        // Ин инчунин маънои онро дорад, ки `self` бояд варианти `value` бошад.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Арзишро аз контейнери `MaybeUninit<T>` мехонад.Дар натиҷа `T` ба муомилаи муқаррарии нутфа дучор меояд.
    ///
    /// Ба қадри имкон, ба ҷои он истифодаи [`assume_init`] афзалтар аст, ки ин такрори мундариҷаи `MaybeUninit<T>`-ро пешгирӣ мекунад.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор дорад, ба шахси зангзада вобаста аст.Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори номуайян мегардад.
    /// [type-level documentation][inv] дорои маълумоти бештар дар бораи инвариантӣ мебошад.
    ///
    /// Гузашта аз ин, ин нусхаи ҳамон маълумотро дар `MaybeUninit<T>` боқӣ мегузорад.
    /// Ҳангоми истифодаи нусхаҳои зиёди маълумот (бо якчанд маротиба занг задан ба `assume_init_read`, ё аввал ба `assume_init_read` ва сипас [`assume_init`]), масъулияти шумост, ки ин маълумот дар ҳақиқат такрор карда мешавад.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` аст, бинобар ин мо метавонем якчанд маротиба хонем.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Нусхабардории арзиши `None` хуб аст, бинобар ин мо метавонем якчанд маротиба хонем.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Истифодаи * нодурусти ин усул:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Ҳоло мо ду нусхаи як худи vector-ро эҷод кардем, ки ба a️ дукарата ройгон оварда расонд, вақте ки онҳо ҳам афтоданд!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` оғоз карда шудааст.
        // Хондан аз `self.as_ptr()` бехатар аст, зеро `self` бояд ибтидоӣ карда шавад.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Арзиши мавҷудбударо ба ҷои худ мепартояд.
    ///
    /// Агар шумо моликияти `MaybeUninit` дошта бошед, шумо метавонед ба ҷои [`assume_init`] истифода баред.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор дорад, ба шахси зангзада вобаста аст.Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори номуайян мегардад.
    ///
    /// Ба болои ин, бояд ҳамаи инвариантҳои иловагии навъи `T` қонеъ карда шаванд, зеро татбиқи `Drop` `T` (ё аъзои он) метавонад ба ин такя кунад.
    /// Масалан, [`Vec<T>`]-и '1' оғозшуда ҳисобидашуда ҳисобида мешавад (дар доираи татбиқи ҷорӣ; ин кафолати устуворро дар бар намегирад), зеро талаби ягонае, ки тартибдиҳанда дар бораи он медонад, ин аст, ки нишоннамои додаҳо бояд нол бошад.
    ///
    /// Тарки чунин `Vec<T>` аммо рафтори номуайянро ба бор меорад.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` оғоз карда шудааст ва
        // ҳама инвариантҳои `T`-ро қонеъ мекунад.
        // Партофтани арзиши ҷойдошта бехатар аст, агар чунин бошад.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Истиноди муштарак ба арзиши мавҷудбударо мегирад.
    ///
    /// Ин метавонад муфид бошад, вақте ки мо мехоҳем ба `MaybeUninit`, ки ибтидо гузошта шудааст, дастрасӣ пайдо кунем, аммо ба `MaybeUninit` соҳибӣ надорем (истифодаи `.assume_init()`)-ро пешгирӣ кунем).
    ///
    /// # Safety
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра оғоз нашудааст, занг задан ба ин боиси рафтори номуайян мегардад: кафолат додани он, ки `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор дорад, ба шахси зангзада вобаста аст.
    ///
    ///
    /// # Examples
    ///
    /// ### Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x`-ро оғоз кунед:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Ҳоло, ки маълум аст, ки `MaybeUninit<_>`-и мо оғоз ёфт, хуб аст, ки ба он истиноди муштарак эҷод кунед:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // БЕХАТАР: : `x` ибтидоӣ карда шудааст.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Истифодаи нодурусти ин усул:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Мо ба vector uninitialized ишора кардем!Ин рафтори номуайян аст.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `MaybeUninit`-ро бо истифодаи `Cell::set` оғоз кунед:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Истинод ба `Cell<bool>` номаълум: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` оғоз карда шудааст.
        // Ин инчунин маънои онро дорад, ки `self` бояд варианти `value` бошад.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Истиноди тағйирёбандаи (unique) ба арзиши мавҷудбударо мегирад.
    ///
    /// Ин метавонад муфид бошад, вақте ки мо мехоҳем ба `MaybeUninit`, ки ибтидо гузошта шудааст, дастрасӣ пайдо кунем, аммо ба `MaybeUninit` соҳибӣ надорем (истифодаи `.assume_init()`)-ро пешгирӣ кунем).
    ///
    /// # Safety
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра оғоз нашудааст, занг задан ба ин боиси рафтори номуайян мегардад: кафолат додани он, ки `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор дорад, ба шахси зангзада вобаста аст.
    /// Масалан, `.assume_init_mut()` наметавонад барои оғоз кардани `MaybeUninit` истифода шавад.
    ///
    /// # Examples
    ///
    /// ### Истифодаи дурусти ин усул:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// *Ҳама* байтҳои буферии вурудро оғоз мекунад.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf`-ро оғоз кунед:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Акнун мо медонем, ки `buf` ибтидоӣ гирифта шудааст, бинобар ин мо метавонистем онро `.assume_init()` истифода барем.
    /// // Аммо, истифодаи `.assume_init()` метавонад `memcpy` аз 2048 байтро сар диҳад.
    /// // Барои тасдиқ кардани буферии мо бидуни нусхабардорӣ оғоз шудааст, мо `&mut MaybeUninit<[u8; 2048]>`-ро ба `&mut [u8; 2048]` такмил медиҳем:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // БЕХАТАР: : `buf` ибтидоӣ карда шудааст.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Акнун мо метавонем `buf`-ро ҳамчун буридаи оддӣ истифода барем:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Истифодаи нодурусти ин усул:
    ///
    /// Шумо наметавонед `.assume_init_mut()`-ро барои оғози арзиш истифода баред:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Мо истиноди (mutable) ба `bool` uninitialized эҷод кардем!
    ///     // Ин рафтори номуайян аст.⚠️
    /// }
    /// ```
    ///
    /// Масалан, шумо наметавонед [`Read`]-ро ба буфери номатлуб:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) истинод ба хотираи номаълум!
    ///                             // Ин рафтори номуайян аст.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Шумо инчунин дастрасии мустақими майдониро барои оғози тадриҷии соҳа ба соҳа истифода карда наметавонед:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) истинод ба хотираи номаълум!
    ///                  // Ин рафтори номуайян аст.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) истинод ба хотираи номаълум!
    ///                  // Ин рафтори номуайян аст.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Мо дар айни замон ба нодуруст будани гуфтаҳои боло такя мекунем, яъне ба маълумотҳои номаълум ишора дорем (масалан, дар `libcore/fmt/float.rs`).
    // Пеш аз эътидол мо бояд дар бораи қоидаҳо қарори ниҳоӣ қабул кунем.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `self` оғоз карда шудааст.
        // Ин инчунин маънои онро дорад, ки `self` бояд варианти `value` бошад.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Арзишҳоро аз массиви контейнерҳои `MaybeUninit` хориҷ мекунад.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки ҳамаи унсурҳои массив дар ҳолати ибтидоӣ қарор доранд, ба шахси зангзада вобаста аст.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Бехатарӣ: Ҳоло бехатар аст, вақте ки мо ҳамаи унсурҳоро оғоз кардем
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Зангзан кафолат медиҳад, ки ҳамаи унсурҳои массив ибтидоӣ карда мешаванд
        // * `MaybeUninit<T>` ва T барои тарҳрезии якхела кафолат дода мешавад
        // * МумкинUnint намеафтад, аз ин рӯ, дукаратаҳо вуҷуд надоранд ва аз ин рӯ табдилдиҳӣ бехатар аст
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Фарз мекунем, ки ҳамаи унсурҳо ибтидоӣ карда шудаанд, ба онҳо як бурида гиред.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки унсурҳои `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор доранд, ба шахси зангзада вобаста аст.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори номуайян мегардад.
    ///
    /// Барои тафсилот ва мисолҳои бештар ба [`assume_init_ref`] нигаред.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // БЕХАТАР: : рехтани бурида ба `*const [T]` бехатар аст, зеро зангзан кафолат медиҳад
        // `slice` ибтидоӣ карда шудааст ва "МумкинUninit" дорои ҳамон тарҳест, ки бо `T` кафолат дода мешавад.
        // Нишондиҳандаи ба даст овардашуда эътибор дорад, зеро он ба хотираи `slice` тааллуқ дорад, ки ин истинод аст ва аз ин рӯ барои хондан эътибор дорад.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Фарз мекунем, ки ҳамаи унсурҳо ибтидоӣ карда шудаанд, ба онҳо як буридаи тағиршаванда гиред.
    ///
    /// # Safety
    ///
    /// Кафолат додани он, ки унсурҳои `MaybeUninit<T>` воқеан дар ҳолати ибтидоӣ қарор доранд, ба шахси зангзада вобаста аст.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори номуайян мегардад.
    ///
    /// Барои тафсилот ва мисолҳои бештар ба [`assume_init_mut`] нигаред.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // БЕХАТАР: : монанд ба қайдҳои бехатарӣ барои `slice_get_ref`, аммо мо як
        // истиноди тағйирёбанда, ки барои навиштан низ кафолат дода мешавад.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Ба унсури якуми массив ишоракунак меорад.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Ба унсури якуми массив нишоннамои тағиршаванда меорад.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Нусхаҳои унсурҳоро аз `src` ба `this` бармегардонад, ва истиноди тағиршавандаро ба мундариҷаи ҳоло initalized `this` бармегардонад.
    ///
    /// Агар `T` `Copy`-ро иҷро накунад, [`write_slice_cloned`]-ро истифода баред
    ///
    /// Ин ба [`slice::copy_from_slice`] монанд аст.
    ///
    /// # Panics
    ///
    /// Агар ин функсия дарозии гуногун дошта бошад, ин функсия panic хоҳад буд.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕХАТАР: : мо танҳо ҳамаи унсурҳои ленро ба иқтидори эҳтиётӣ нусхабардорӣ кардем
    /// // аввалин унсурҳои src.len()-и vec ҳоло эътибор доранд.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // БЕХАТАР: :&[T] ва&[MaybeUninit<T>] ҳамин тарҳро доранд
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // БЕХАТАР: : Унсурҳои дуруст танҳо ба `this` нусхабардорӣ карда шуданд, то инитализатсия карда шавад
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Элементҳоро аз `src` то `this` клон мекунад, ва истиноди тағиршавандаро ба мундариҷаи ҳоло initalized `this` бармегардонад.
    /// Ҳама унсурҳои аллакай initalized партофта намешаванд.
    ///
    /// Агар `T` `Copy`-ро татбиқ кунад, [`write_slice`]-ро истифода баред
    ///
    /// Ин ба [`slice::clone_from_slice`] монанд аст, аммо унсурҳои мавҷударо тарк намекунад.
    ///
    /// # Panics
    ///
    /// Ин функсия panic хоҳад буд, агар ду иловаро дарозии гуногун дошта бошанд ё татбиқи `Clone` panics.
    ///
    /// Агар panic мавҷуд бошад, унсурҳои аллакай клондонидашуда партофта мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // БЕХАТАР: : мо танҳо ҳамаи унсурҳои ленро ба иқтидори эҳтиётӣ клондем
    /// // аввалин унсурҳои src.len()-и vec ҳоло эътибор доранд.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Баръакси copy_from_slice, ин clone_from_slice-ро дар буриш даъват намекунад, зеро `MaybeUninit<T: Clone>` Clone-ро амалӣ намекунад.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // БЕХАТАР: : ин буридаи хом танҳо дорои объектҳои ибтидоӣ хоҳад буд
                // барои ҳамин, ба тарки он иҷозат дода шудааст.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Мо бояд ба таври возеҳ онҳоро ба ҳамон дарозӣ бурем
        // барои санҷиши ҳудудҳо ҷудо карда мешавад ва оптимизатор memcpy-ро барои парвандаҳои оддӣ тавлид мекунад (масалан T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // посбон лозим аст b/c panic метавонад ҳангоми клон рӯй диҳад
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // БЕХАТАР: : Унсурҳои дуруст танҳо ба `this` навишта шудаанд, то инитализатсия карда шавад
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}