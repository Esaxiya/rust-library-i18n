//! Намудҳои атом
//!
//! Намудҳои атомӣ иртиботи ибтидоии хотираи муштаракро байни риштаҳо таъмин мекунанд ва блокҳои дигари намудҳои ҳамзамон мебошанд.
//!
//! Ин модул версияҳои атомии шумораи муайяни намудҳои ибтидоиро, аз ҷумла [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] ва ғайра муайян мекунад.
//! Намудҳои атом амалиётеро пешниҳод мекунанд, ки ҳангоми истифодаи дуруст, навсозӣ байни риштаҳоро ҳамоҳанг мекунанд.
//!
//! Ҳар як усул [`Ordering`] мегирад, ки қуввати монеаи хотира барои ин амалиётро нишон медиҳад.Ин фармоишҳо бо ҳамон [C++20 atomic orderings][1] мебошанд.Барои маълумоти иловагӣ ба [nomicon][2] нигаред.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Тағирёбандаҳои атомӣ барои мубодилаи байни риштаҳо бехатар аст (онҳо [`Sync`]-ро татбиқ мекунанд), аммо худашон механизми мубодиларо таъмин намекунанд ва [threading model](../../../std/thread/index.html#the-threading-model) аз Rust-ро риоя мекунанд.
//!
//! Усули маъмултарини мубодилаи тағирёбандаи атом ин гузоштан ба [`Arc`][arc] (нишоннамои муштараки бо истиноди атомӣ ҳисобшуда) мебошад.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Навъҳои атомиро дар тағирёбандаҳои статикӣ нигоҳ доштан мумкин аст, ки бо истифода аз инитализаторҳои доимӣ ба монанди [`AtomicBool::new`] оғоз карда шуданд.Статикаи атомӣ аксар вақт барои ибтидои ҷаҳонии танбал истифода мешаванд.
//!
//! # Portability
//!
//! Ҳама намудҳои атом дар ин модул кафолат дода мешаванд, ки агар онҳо дастрас бошанд, [lock-free] мебошанд.Ин маънои онро дорад, ки онҳо дар дохили мутекс ҷаҳонӣ ба даст намеоранд.Намудҳо ва амалиётҳои атомӣ бидуни интизор кафолат дода намешаванд.
//! Ин маънои онро дорад, ки амалиёте ба монанди `fetch_or` метавонад бо ҳалқаи муқоиса ва своп амалӣ карда шавад.
//!
//! Амалҳои атомиро дар қабати дастур бо атомҳои калонтар амалӣ кардан мумкин аст.Масалан, баъзе платформаҳо дастурҳои атомии 4 байтиро барои татбиқи `AtomicI8` истифода мебаранд.
//! Дар хотир доред, ки ин тақлид набояд ба дурустии код таъсир расонад, ин танҳо як чизест, ки бояд огоҳ бошад.
//!
//! Намудҳои атомии ин модул метавонанд на дар ҳама платформаҳо дастрас бошанд.Навъҳои атомии ин ҷо ҳама дастрасанд, аммо умуман ба мавҷуда такя кардан мумкин аст.Баъзе истисноҳои назаррас инҳоянд:
//!
//! * PowerPC ва платформаҳои MIPS бо нишондиҳандаҳои 32-битӣ намудҳои `AtomicU64` ё `AtomicI64` надоранд.
//! * ARM платформаҳое, ба монанди `armv5te`, ки барои Linux нестанд, танҳо амалиётҳои `load` ва `store`-ро таъмин мекунанд ва амалҳои муқоиса ва ивазкунии (CAS), ба монанди `swap`, `fetch_add` ва ғайраҳоро дастгирӣ намекунанд.
//! Ғайр аз он, дар Linux, ин амалиётҳои CAS тавассути [operating system support] амалӣ карда мешаванд, ки метавонанд бо ҷазои иҷро оварда шаванд.
//! * ARM ҳадафҳо бо `thumbv6m` танҳо амалиётҳои `load` ва `store`-ро таъмин мекунанд ва амалҳои муқоиса ва ивази (CAS), ба монанди `swap`, `fetch_add` ва ғайраҳоро дастгирӣ намекунанд.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Дар хотир доред, ки платформаҳои future метавонанд илова карда шаванд, ки инчунин баъзе амалиётҳои атомиро дастгирӣ намекунанд.Рамзи максималии интиқолшуда мехоҳад дар мавриди истифода бурдани намудҳои атом эҳтиёткор бошад.
//! `AtomicUsize` ва `AtomicIsize` одатан сайёртарин мебошанд, аммо дар ҳама ҳолат онҳо на дар ҳама ҷо дастрасанд.
//! Барои маълумот, китобхонаи `std` атоми андозаи нишондиҳандаро талаб мекунад, гарчанде ки `core` чунин намекунад.
//!
//! Дар айни замон, ба шумо лозим аст, ки `#[cfg(target_arch)]`-ро пеш аз ҳама барои тартиб додани рамз бо атомҳо истифода баред.Як `#[cfg(target_has_atomic)]` ноустувор вуҷуд дорад, ки метавонад дар future устувор карда шавад.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A spinlock оддӣ:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Интизор шавед, ки риштаи дигар қулфро раҳо кунад
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Ҳисоби ҷаҳонии риштаҳои зинда нигоҳ доред:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Намуди булӣ, ки метавонад бехатар дар байни риштаҳо тақсим карда шавад.
///
/// Ин намуд ҳамон як намояндагии хотираро бо [`bool`] дорад.
///
/// **Эзоҳ**: Ин навъи он танҳо дар платформаҳое мавҷуд аст, ки бори атомӣ ва мағозаҳои `u8`-ро дастгирӣ мекунанд.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `AtomicBool`-ро, ки ба `false` оғоз карда шудааст, эҷод мекунад.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Ирсол ба таври мустақим барои AtomicBool амалӣ карда мешавад.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Намуди нишоннамои хом, ки метавонад бехатар дар байни риштаҳо тақсим карда шавад.
///
/// Ин намуд ҳамон як намояндагии хотираро бо `*mut T` дорад.
///
/// **Эзоҳ**: Ин навъи он танҳо дар платформаҳое мавҷуд аст, ки бори атом ва мағозаи нишондиҳандаҳоро дастгирӣ мекунанд.
/// Андозаи он аз андозаи нишоннамои ҳадаф вобаста аст.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// `AtomicPtr<T>`-и ночизро эҷод мекунад.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Фармоишҳои хотираи атом
///
/// Фармоишҳои хотира роҳи ҳамоҳангсозии хотираи амалиётро муайян мекунанд.
/// Дар заифтарин [`Ordering::Relaxed`], танҳо хотираи бевоситаи амалиёт ҳамоҳангшуда мебошад.
/// Аз тарафи дигар, ҷуфти мағозаи амалиётҳои [`Ordering::SeqCst`] хотираи дигарро ҳамоҳанг мекунад ва дар айни замон тартиби умумии чунин амалҳоро дар ҳамаи риштаҳо нигоҳ медорад.
///
///
/// Фармоишҳои хотираи Rust [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) мебошанд.
///
/// Барои маълумоти иловагӣ ба [nomicon] нигаред.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Маҳдудиятҳои фармоишӣ нест, танҳо амалиёти атомӣ.
    ///
    /// [`memory_order_relaxed`] дар C++ 20 мувофиқат мекунад.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Ҳангоми ҳамроҳӣ бо мағоза, ҳамаи амалиётҳои қаблӣ пеш аз ҳар гуна бори ин арзиш бо фармоиши [`Acquire`] (ё қавитар) фармоишӣ мешаванд.
    ///
    /// Аз ҷумла, ҳамаи навиштаҳои қаблӣ барои ҳамаи риштаҳое, ки бори [`Acquire`] (ё қавитар)-и ин арзишро иҷро мекунанд, намоён мешаванд.
    ///
    /// Аҳамият диҳед, ки истифодаи ин фармоиш барои амалиёте, ки борҳо ва мағозаҳоро дар бар мегирад, ба амалиёти борбардории [`Relaxed`] оварда мерасонад!
    ///
    /// Ин фармоиш танҳо барои амалиёте дахл дорад, ки мағозаро иҷро карда метавонанд.
    ///
    /// [`memory_order_release`] дар C++ 20 мувофиқат мекунад.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ҳангоми якҷоя бо сарборӣ, агар арзиши боршударо як амалиёти мағоза бо фармоиши [`Release`] (ё қавитар) навишта бошад, пас ҳамаи амалиётҳои минбаъда пас аз он мағоза фармоишӣ мешаванд.
    /// Аз ҷумла, ҳамаи борҳои минбаъда маълумоти пеш аз мағоза навишташударо мебинанд.
    ///
    /// Аҳамият диҳед, ки истифодаи ин фармоиш барои амалиёте, ки борҳо ва мағозаҳоро дар бар мегирад, ба амалиёти мағозаи [`Relaxed`] оварда мерасонад!
    ///
    /// Ин фармоиш танҳо барои амалиёте татбиқ карда мешавад, ки сарбориро иҷро карда метавонанд.
    ///
    /// [`memory_order_acquire`] дар C++ 20 мувофиқат мекунад.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Таъсири ҳам [`Acquire`] ва [`Release`] якҷоя дорад:
    /// Барои борҳо он фармоиш [`Acquire`]-ро истифода мебарад.Барои мағозаҳо он фармоишии [`Release`]-ро истифода мебарад.
    ///
    /// Аҳамият диҳед, ки дар сурати `compare_and_swap`, имкон дорад, ки амалиёт анҷом надиҳад ва ҳеҷ мағозае иҷро намекунад ва аз ин рӯ он танҳо фармоишии [`Acquire`] дорад.
    ///
    /// Аммо, `AcqRel` ҳеҷ гоҳ дастрасии [`Relaxed`]-ро иҷро намекунад.
    ///
    /// Ин фармоиш танҳо барои амалиёте татбиқ мешавад, ки ҳам борҳо ва ҳам мағозаҳоро дар бар мегиранд.
    ///
    /// [`memory_order_acq_rel`] дар C++ 20 мувофиқат мекунад.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Монанди [`Acquire`]/[`Release`]/[AcqRel`](барои амалиётҳои боркунӣ, нигоҳдорӣ ва боркунӣ бо мағоза мутаносибан) бо кафолати иловагӣ, ки ҳамаи риштаҳо ҳамаи амалиётҳои пайдарпайро бо як тартиб мебинанд .
    ///
    ///
    /// [`memory_order_seq_cst`] дар C++ 20 мувофиқат мекунад.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] ба `false` ибтидо гузоштааст.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// `AtomicBool` нав месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Истиноди тағиршавандаро ба [`bool`] аслӣ бармегардонад.
    ///
    /// Ин бехатар аст, зеро истиноди тағирёбанда кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // БЕХАТАР: : истиноди тағйирёбанда моликияти беназирро кафолат медиҳад.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Дастрасии атомиро ба `&mut bool` дастрас кунед.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // БЕХАТАР: : истиноди тағйирёбанда моликияти беназирро кафолат медиҳад ва
        // ҳамоҳангсозии ҳам `bool` ва ҳам `Self` 1 аст.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Атомро истеъмол мекунад ва арзиши мавҷударо бар мегардонад.
    ///
    /// Ин бехатар аст, зеро гузаштани `self` аз рӯи арзиш кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Арзишро аз bool бор мекунад.
    ///
    /// `load` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Арзишҳои имконпазир [`SeqCst`], [`Acquire`] ва [`Relaxed`] мебошанд.
    ///
    /// # Panics
    ///
    /// Panics агар `order` [`Release`] ё [`AcqRel`] бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // БЕХАТАР: : ҳар гуна нажодҳои додаҳоро бо асбобҳои атомӣ ва хом пешгирӣ мекунанд
        // нишоннамои додашуда эътибор дорад, зеро мо онро аз маълумотнома гирифтаем.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Арзишро ба bool нигоҳ медорад.
    ///
    /// `store` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Арзишҳои имконпазир [`SeqCst`], [`Release`] ва [`Relaxed`] мебошанд.
    ///
    /// # Panics
    ///
    /// Panics агар `order` [`Acquire`] ё [`AcqRel`] бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // БЕХАТАР: : ҳар гуна нажодҳои додаҳоро бо асбобҳои атомӣ ва хом пешгирӣ мекунанд
        // нишоннамои додашуда эътибор дорад, зеро мо онро аз маълумотнома гирифтаем.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Арзишро ба bool нигоҳ медорад ва арзиши қаблиро бармегардонад.
    ///
    /// `swap` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Арзишро ба [`bool`] нигоҳ медорад, агар қимати ҷорӣ бо арзиши `current` баробар бошад.
    ///
    /// Арзиши бозгаштан ҳамеша арзиши қаблӣ мебошад.Агар он ба `current` баробар бошад, пас арзиши он навсозӣ шудааст.
    ///
    /// `compare_and_swap` инчунин як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Аҳамият диҳед, ки ҳатто ҳангоми истифодаи [`AcqRel`], амалиёт ноком шуда метавонад ва аз ин рӯ танҳо як бори `Acquire` иҷро мекунад, аммо семантикаи `Release` надорад.
    /// Истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] мекунад, агар он рӯй диҳад ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Муҳоҷират ба `compare_exchange` ва `compare_exchange_weak`
    ///
    /// `compare_and_swap` ба `compare_exchange` баробар аст бо харитаи зерин барои фармоишҳои хотира:
    ///
    /// Аслӣ |Муваффақият |Нокомӣ
    /// -------- | ------- | -------
    /// Истироҳат |Истироҳат |Хариди осуда |Хариди |Озодшавӣ ба даст оред |Озод кардан |AcqRel истироҳат |AcqRel |Хариди SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` иҷозат дода мешавад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки ин ба тартибдиҳанда имкон медиҳад, ки ҳангоми муқоиса ва своп дар ҳалқа истифода шуда, рамзи васлро беҳтар созад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Арзишро ба [`bool`] нигоҳ медорад, агар қимати ҷорӣ бо арзиши `current` баробар бошад.
    ///
    /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
    /// Дар муваффақият ин арзиш ба `current` баробар аст.
    ///
    /// `compare_exchange` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
    /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
    ///
    /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Арзишро ба [`bool`] нигоҳ медорад, агар қимати ҷорӣ бо арзиши `current` баробар бошад.
    ///
    /// Баръакси [`AtomicBool::compare_exchange`], ин функсия иҷозат медиҳад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки дар баъзе платформаҳо коди самарабахштар ба даст орад.
    ///
    /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
    ///
    /// `compare_exchange_weak` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
    /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
    /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" мантиқӣ бо арзиши логикӣ.
    ///
    /// Амали мантиқии "and"-ро аз рӯи арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
    ///
    /// Арзиши қаблиро бармегардонад
    ///
    /// `fetch_and` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" мантиқӣ бо арзиши логикӣ.
    ///
    /// Амали мантиқии "nand"-ро аз рӯи арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
    ///
    /// Арзиши қаблиро бармегардонад
    ///
    /// `fetch_nand` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Мо atomic_nand-ро дар инҷо истифода карда наметавонем, зеро он метавонад ба bool бо арзиши беэътибор оварда расонад.
        // Ин аз он сабаб рух медиҳад, ки амалиёти атомӣ бо бутуни 8-битӣ дар дохили кишвар анҷом дода мешавад, ки 7 битаи болоро муқаррар мекунад.
        //
        // Пас, мо ба ҷои он танҳо fetch_xor ё свопро истифода барем.
        if val {
            // ! (x&true)== !x Мо бояд bool-ро чаппа кунем.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Мо бояд bool-ро ба true таъин кунем.
            //
            self.swap(true, order)
        }
    }

    /// "or" мантиқӣ бо арзиши логикӣ.
    ///
    /// Амали мантиқии "or"-ро аз рӯи арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
    ///
    /// Арзиши қаблиро бармегардонад
    ///
    /// `fetch_or` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" мантиқӣ бо арзиши логикӣ.
    ///
    /// Амали мантиқии "xor"-ро аз рӯи арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
    ///
    /// Арзиши қаблиро бармегардонад
    ///
    /// `fetch_xor` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Як нишоннамои тағиршавандаро ба [`bool`] аслӣ бармегардонад.
    ///
    /// Кори хондан ва навиштани ғайриматрикӣ дар адади бутуни натиҷа метавонад сабқати маълумот бошад.
    /// Ин усул асосан барои FFI муфид аст, ки имзои функсия метавонад ба ҷои `&AtomicBool` `*mut bool`-ро истифода барад.
    ///
    /// Баргардонидани нишоннамои `*mut` аз истиноди муштарак ба ин атом бехатар аст, зеро намудҳои атом бо тағирёбии дохилӣ кор мекунанд.
    /// Ҳама тағиротҳои атомӣ қиматро тавассути истиноди муштарак тағир медиҳанд ва то он даме, ки онҳо амалиёти атомиро истифода баранд, метавонанд бехатар анҷом диҳанд.
    /// Ҳама гуна истифодаи нишоннамои хоми баргардондашуда блоки `unsafe`-ро талаб мекунад ва бояд ҳамон маҳдудиятро риоя кунад: амалиёт дар он бояд атом бошад.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Арзишро меорад ва ба он функсияеро татбиқ мекунад, ки арзиши нави ихтиёриро бармегардонад.`Result` аз `Ok(previous_value)` бармегардонад, агар функсия `Some(_)`-ро баргардонад, вагарна `Err(previous_value)`.
    ///
    /// Note: Ин метавонад функсияро якчанд маротиба даъват кунад, агар қимат аз дигар риштаҳо дар ин миён тағир дода шуда бошад, ба шарте ки функсия `Some(_)`-ро баргардонад, аммо функсия танҳо як маротиба ба арзиши захирашуда татбиқ карда мешавад.
    ///
    ///
    /// `fetch_update` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// Дар аввал фармоиши зарурӣ барои вақте ки амалиёт ниҳоят муваффақ хоҳад шуд, дар дуввум фармоиши зарурӣ барои борҳо тавсиф карда мешавад.
    /// Инҳо мутаносибан ба фармоишҳои муваффақият ва нокомии [`AtomicBool::compare_exchange`] мувофиқат мекунанд.
    ///
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори ниҳоии муваффақро [`Relaxed`] месозад.
    /// Тартиби бори (failed) танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоишҳои муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар `u8` дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// `AtomicPtr` нав месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Истиноди тағиршавандаро ба нишоннамои аслӣ бармегардонад.
    ///
    /// Ин бехатар аст, зеро истиноди тағирёбанда кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Дастрасии атомиро ба нишоннамо дастрас кунед.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - истиноди тағйирёбанда моликияти беназирро кафолат медиҳад.
        //  - ҳамоҳангсозии `*mut T` ва `Self` дар ҳама платформаҳое, ки rust дастгирӣ мекунанд, ҳамон тавре аст, ки дар боло тасдиқ карда шуд.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Атомро истеъмол мекунад ва арзиши мавҷударо бар мегардонад.
    ///
    /// Ин бехатар аст, зеро гузаштани `self` аз рӯи арзиш кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Арзишро аз нишоннамо бор мекунад.
    ///
    /// `load` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Арзишҳои имконпазир [`SeqCst`], [`Acquire`] ва [`Relaxed`] мебошанд.
    ///
    /// # Panics
    ///
    /// Panics агар `order` [`Release`] ё [`AcqRel`] бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Арзишро ба нишоннамо нигоҳ медорад.
    ///
    /// `store` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Арзишҳои имконпазир [`SeqCst`], [`Release`] ва [`Relaxed`] мебошанд.
    ///
    /// # Panics
    ///
    /// Panics агар `order` [`Acquire`] ё [`AcqRel`] бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Арзишро дар нишоннамо нигоҳ медорад ва арзиши қаблиро бармегардонад.
    ///
    /// `swap` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
    /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар нишондиҳандаҳо дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Агар нишондиҳанда бо арзиши `current` баробар бошад, қиматро ба нишоннамо нигоҳ медорад.
    ///
    /// Арзиши бозгаштан ҳамеша арзиши қаблӣ мебошад.Агар он ба `current` баробар бошад, пас арзиши он навсозӣ шудааст.
    ///
    /// `compare_and_swap` инчунин як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
    /// Аҳамият диҳед, ки ҳатто ҳангоми истифодаи [`AcqRel`], амалиёт ноком шуда метавонад ва аз ин рӯ танҳо як бори `Acquire` иҷро мекунад, аммо семантикаи `Release` надорад.
    /// Истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] мекунад, агар он рӯй диҳад ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар нишондиҳандаҳо дастгирӣ мекунанд.
    ///
    /// # Муҳоҷират ба `compare_exchange` ва `compare_exchange_weak`
    ///
    /// `compare_and_swap` ба `compare_exchange` баробар аст бо харитаи зерин барои фармоишҳои хотира:
    ///
    /// Аслӣ |Муваффақият |Нокомӣ
    /// -------- | ------- | -------
    /// Истироҳат |Истироҳат |Хариди осуда |Хариди |Озодшавӣ ба даст оред |Озод кардан |AcqRel истироҳат |AcqRel |Хариди SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` иҷозат дода мешавад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки ин ба тартибдиҳанда имкон медиҳад, ки ҳангоми муқоиса ва своп дар ҳалқа истифода шуда, рамзи васлро беҳтар созад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Агар нишондиҳанда бо арзиши `current` баробар бошад, қиматро ба нишоннамо нигоҳ медорад.
    ///
    /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
    /// Дар муваффақият ин арзиш ба `current` баробар аст.
    ///
    /// `compare_exchange` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
    /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
    ///
    /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар нишондиҳандаҳо дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Агар нишондиҳанда бо арзиши `current` баробар бошад, қиматро ба нишоннамо нигоҳ медорад.
    ///
    /// Баръакси [`AtomicPtr::compare_exchange`], ин функсия иҷозат медиҳад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки дар баъзе платформаҳо коди самарабахштар ба даст орад.
    ///
    /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
    ///
    /// `compare_exchange_weak` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
    /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
    /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар нишондиҳандаҳо дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // БЕХАТАР: : Ин аслӣ хатарнок аст, зеро он бо нишоннамои хом кор мекунад
        // аммо мо итминон дорем, ки нишондиҳанда дуруст аст (мо онро танҳо аз `UnsafeCell` гирифтаем, ки онро бо истинод дорем) ва худи амалиёти атомӣ ба мо имкон медиҳад, ки мундариҷаи `UnsafeCell`-ро мутаталликона мутатӣ созем.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Арзишро меорад ва ба он функсияеро татбиқ мекунад, ки арзиши нави ихтиёриро бармегардонад.`Result` аз `Ok(previous_value)` бармегардонад, агар функсия `Some(_)`-ро баргардонад, вагарна `Err(previous_value)`.
    ///
    /// Note: Ин метавонад функсияро якчанд маротиба даъват кунад, агар қимат аз дигар риштаҳо дар ин миён тағир дода шуда бошад, ба шарте ки функсия `Some(_)`-ро баргардонад, аммо функсия танҳо як маротиба ба арзиши захирашуда татбиқ карда мешавад.
    ///
    ///
    /// `fetch_update` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
    /// Дар аввал фармоиши зарурӣ барои вақте ки амалиёт ниҳоят муваффақ хоҳад шуд, дар дуввум фармоиши зарурӣ барои борҳо тавсиф карда мешавад.
    /// Инҳо мутаносибан ба фармоишҳои муваффақият ва нокомии [`AtomicPtr::compare_exchange`] мувофиқат мекунанд.
    ///
    /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори ниҳоии муваффақро [`Relaxed`] месозад.
    /// Тартиби бори (failed) танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоишҳои муваффақият баробар ё заифтар бошад.
    ///
    /// **Note:** Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дар нишондиҳандаҳо дастгирӣ мекунанд.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool`-ро ба `AtomicBool` табдил медиҳад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Ин макро дар баъзе меъморӣ истифода нашудааст.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Намуди бутуне, ки онро бехатар дар байни риштаҳо тақсим кардан мумкин аст.
        ///
        /// Ин тип ҳамон як намояндагии хотираро бо навъи бутуни аслӣ, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Барои гирифтани маълумоти бештар дар бораи фарқияти намудҳои атомӣ ва намудҳои ғайриматикӣ, инчунин маълумот дар бораи интиқолёбии ин намуд, лутфан ба [module-level documentation] нигаред.
        ///
        ///
        /// **Note:** Ин навъи он танҳо дар платформаҳое мавҷуд аст, ки бори атомӣ ва мағозаҳои ['-ро дастгирӣ мекунанд
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Тамоми атомии ба `0` ибтидоӣ кардашуда.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Ирсол ба таври мустақим амалӣ карда мешавад.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Адади нави атомро месозад.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Истиноди тағиршавандаро ба бутуни аслӣ бармегардонад.
            ///
            /// Ин бехатар аст, зеро истиноди тағирёбанда кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// бигзор mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - истиноди тағйирёбанда моликияти беназирро кафолат медиҳад.
                //  - ҳамоҳангсозии `$int_type` ва `Self` ҳамон аст, ки $cfg_align ваъда дода ва дар боло тасдиқ шудааст.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Атомро истеъмол мекунад ва арзиши мавҷударо бар мегардонад.
            ///
            /// Ин бехатар аст, зеро гузаштани `self` аз рӯи арзиш кафолат медиҳад, ки ягон риштаи дигар дар як вақт маълумоти атомиро дастрас намекунад.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Арзишро аз бутуни атом бор мекунад.
            ///
            /// `load` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
            /// Арзишҳои имконпазир [`SeqCst`], [`Acquire`] ва [`Relaxed`] мебошанд.
            ///
            /// # Panics
            ///
            /// Panics агар `order` [`Release`] ё [`AcqRel`] бошад.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Арзишро ба бутуни атом нигоҳ медорад.
            ///
            /// `store` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
            ///  Арзишҳои имконпазир [`SeqCst`], [`Release`] ва [`Relaxed`] мебошанд.
            ///
            /// # Panics
            ///
            /// Panics агар `order` [`Acquire`] ё [`AcqRel`] бошад.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Арзишро ба адади бутуни атом нигоҳ медорад ва арзиши қаблиро бармегардонад.
            ///
            /// `swap` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Агар адади ҷорӣ бо арзиши `current` баробар бошад, қиматро ба адади бутуни атом нигоҳ медорад.
            ///
            /// Арзиши бозгаштан ҳамеша арзиши қаблӣ мебошад.Агар он ба `current` баробар бошад, пас арзиши он навсозӣ шудааст.
            ///
            /// `compare_and_swap` инчунин як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.
            /// Аҳамият диҳед, ки ҳатто ҳангоми истифодаи [`AcqRel`], амалиёт ноком шуда метавонад ва аз ин рӯ танҳо як бори `Acquire` иҷро мекунад, аммо семантикаи `Release` надорад.
            ///
            /// Истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] мекунад, агар он рӯй диҳад ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Муҳоҷират ба `compare_exchange` ва `compare_exchange_weak`
            ///
            /// `compare_and_swap` ба `compare_exchange` баробар аст бо харитаи зерин барои фармоишҳои хотира:
            ///
            /// Аслӣ |Муваффақият |Нокомӣ
            /// -------- | ------- | -------
            /// Истироҳат |Истироҳат |Хариди осуда |Хариди |Озодшавӣ ба даст оред |Озод кардан |AcqRel истироҳат |AcqRel |Хариди SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` иҷозат дода мешавад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки ин ба тартибдиҳанда имкон медиҳад, ки ҳангоми муқоиса ва своп дар ҳалқа истифода шуда, рамзи васлро беҳтар созад.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Агар адади ҷорӣ бо арзиши `current` баробар бошад, қиматро ба адади бутуни атом нигоҳ медорад.
            ///
            /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
            /// Дар муваффақият ин арзиш ба `current` баробар аст.
            ///
            /// `compare_exchange` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
            /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
            /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
            /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
            ///
            /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Агар адади ҷорӣ бо арзиши `current` баробар бошад, қиматро ба адади бутуни атом нигоҳ медорад.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ин функсия иҷозат дода мешавад, ки ҳатто ҳангоми муқоиса муваффақ шавад, ки дар баъзе платформаҳо коди самарабахштар ба даст орад.
            /// Арзиши баргаштан натиҷаест, ки арзиши нав навишта шудааст ва дорои арзиши қаблӣ мебошад.
            ///
            /// `compare_exchange_weak` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
            /// `success` фармоиши заруриро барои амалиёти хондан-тағир додан-навиштан тавсиф мекунад, ки агар муқоиса бо `current` муваффақ шавад.
            /// `failure` фармоиши заруриро барои амалиёти сарборӣ, ки ҳангоми нокомии муқоиса сурат мегирад, тавсиф мекунад.
            /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори бомуваффақиятро [`Relaxed`] месозад.
            ///
            /// Тартиби нокомӣ танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоиши муваффақият баробар ё заифтар бошад.
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// бигзор мут кӯҳна= val.load(Ordering::Relaxed);
            /// ҳалқа {бигзор нав=кӯҳна * 2;
            ///     бозии val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
            ///
            /// Ин амалиёт аз ҳад зиёд пур мешавад.
            ///
            /// `fetch_add` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Аз арзиши ҷорӣ ҷудо карда, арзиши қаблиро бармегардонад.
            ///
            /// Ин амалиёт аз ҳад зиёд пур мешавад.
            ///
            /// `fetch_sub` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" бо арзиши ҷорӣ.
            ///
            /// Амалиёти каме "and"-ро бо арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_and` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" бо арзиши ҷорӣ.
            ///
            /// Амалиёти каме "nand"-ро бо арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_nand` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" бо арзиши ҷорӣ.
            ///
            /// Амалиёти каме "or"-ро бо арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_or` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" бо арзиши ҷорӣ.
            ///
            /// Амалиёти каме "xor"-ро бо арзиши ҷорӣ ва далели `val` иҷро мекунад ва арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_xor` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Арзишро меорад ва ба он функсияеро татбиқ мекунад, ки арзиши нави ихтиёриро бармегардонад.`Result` аз `Ok(previous_value)` бармегардонад, агар функсия `Some(_)`-ро баргардонад, вагарна `Err(previous_value)`.
            ///
            /// Note: Ин метавонад функсияро якчанд маротиба даъват кунад, агар қимат аз дигар риштаҳо дар ин миён тағир дода шуда бошад, ба шарте ки функсия `Some(_)`-ро баргардонад, аммо функсия танҳо як маротиба ба арзиши захирашуда татбиқ карда мешавад.
            ///
            ///
            /// `fetch_update` барои тавсифи фармоишии хотираи ин амал ду далели [`Ordering`] мегирад.
            /// Дар аввал фармоиши зарурӣ барои вақте ки амалиёт ниҳоят муваффақ хоҳад шуд, дар дуввум фармоиши зарурӣ барои борҳо тавсиф карда мешавад.Инҳо ба фармоишҳои муваффақият ва нокомии мувофиқат мекунанд
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Истифодаи [`Acquire`] ҳамчун фармоиши муваффақ мағозаро қисми ин амалиётро [`Relaxed`] мекунад ва истифодаи [`Release`] бори ниҳоии муваффақро [`Relaxed`] месозад.
            /// Тартиби бори (failed) танҳо [`SeqCst`], [`Acquire`] ё [`Relaxed`] буда метавонад ва бояд ба фармоишҳои муваффақият баробар ё заифтар бошад.
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Фармоиш: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Фармоиш: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Максимум бо арзиши ҷорӣ.
            ///
            /// Максимум арзиши ҷорӣ ва далели `val`-ро ёфта, арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_max` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// бигзор бар=42;
            /// бигзор max_foo=foo.fetch_max (бар, Ordering::SeqCst).max(bar);
            /// тасдиқ кунед! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Ҳадди аққал бо арзиши ҷорӣ.
            ///
            /// Ҳадди ақали арзиши ҷорӣ ва далели `val`-ро ёфта, арзиши навро ба натиҷа таъин мекунад.
            ///
            /// Арзиши қаблиро бармегардонад
            ///
            /// `fetch_min` як далели [`Ordering`] мегирад, ки тартиби хотираи ин амалро тавсиф мекунад.Ҳама намуди фармоиш имконпазир аст.
            /// Дар хотир доред, ки истифодаи [`Acquire`] қисми мағозаи ин амалиётро [`Relaxed`] ва истифодаи [`Release`] қисми борро [`Relaxed`] мекунад.
            ///
            ///
            /// **Эзоҳ**: Ин усул танҳо дар платформаҳое мавҷуд аст, ки амалиёти атомиро дастгирӣ мекунанд
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// бигзор бар=12;
            /// бигзор min_foo=foo.fetch_min (бар, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // БЕХАТАР: : нажодҳои додаҳоро бо асбобҳои дохилӣ пешгирӣ мекунанд.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Нишондиҳандаи тағиршавандаро ба бутуни аслӣ бармегардонад.
            ///
            /// Кори хондан ва навиштани ғайриматрикӣ дар адади бутуни натиҷа метавонад сабқати маълумот бошад.
            /// Ин усул асосан барои FFI муфид аст, ки дар он имзои функсия метавонад истифода барад
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Баргардонидани нишоннамои `*mut` аз истиноди муштарак ба ин атом бехатар аст, зеро намудҳои атом бо тағирёбии дохилӣ кор мекунанд.
            /// Ҳама тағиротҳои атомӣ қиматро тавассути истиноди муштарак тағир медиҳанд ва то он даме, ки онҳо амалиёти атомиро истифода баранд, метавонанд бехатар анҷом диҳанд.
            /// Ҳама гуна истифодаи нишоннамои хоми баргардондашуда блоки `unsafe`-ро талаб мекунад ва бояд ҳамон маҳдудиятро риоя кунад: амалиёт дар он бояд атом бошад.
            ///
            ///
            /// # Examples
            ///
            /// "" (extern-declaration)-ро нодида гиред
            ///
            /// # фн main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // БЕХАТАР: : То он даме, ки `my_atomic_op` атом аст, бехатар аст.
            /// хатарнок {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_store` риоя кунад.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_load` риоя кунад.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_swap` риоя кунад.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Арзиши қаблиро бармегардонад (ба монанди __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_add` риоя кунад.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Арзиши қаблиро бармегардонад (ба монанди __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_sub` риоя кунад.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_compare_exchange` риоя кунад.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_compare_exchange_weak` риоя кунад.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_and` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_nand` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_or` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_xor` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// арзиши максималиро бар мегардонад (муқоисаи имзошуда)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_max` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// арзиши минро бар мегардонад (муқоисаи имзошуда)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_min` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// арзиши максималиро бар мегардонад (муқоисаи беимзо)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_umax` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// арзиши минро бар мегардонад (муқоисаи беимзо)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `atomic_umin` риоя кунад
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Панҷараи атомӣ.
///
/// Вобаста аз тартиби муқарраршуда, девор ба тартибдиҳанда ва CPU имкон намедиҳад, ки навъҳои алоҳидаи амалиёти хотираро дар атрофи он аз нав танзим кунад.
/// Ин ҳамоҳангсозиро бо муносибатҳои байни он ва амалиётҳои атомӣ ё деворҳо дар риштаҳои дигар меорад.
///
/// Панҷара 'A', ки дорои семантикаи фармоишии (ҳадди аққал) [`Release`] мебошад, бо девори 'B' бо (ҳадди аққал) семантикаи [`Acquire`] ҳамоҳанг мекунад, агар ва танҳо дар сурати мавҷуд будани амалиётҳои X ва Y, ки ҳам дар баъзе ашёи ҳастаии 'M' кор мекунанд, ба монанди A пеш аз пайдарҳамӣ X, Y пеш аз B ҳамоҳанг карда мешавад ва Y тағирёбии M-ро мушоҳида мекунад.
/// Ин вобастагии пеш аз ба вуқӯъ пайвастаро байни А ва В таъмин менамояд.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Амалҳои атомӣ бо семантикаи [`Release`] ё [`Acquire`] низ метавонанд бо девор ҳамоҳанг шаванд.
///
/// Деворе, ки фармоиши [`SeqCst`] дорад, илова бар доштани семантикаи [`Acquire`] ва [`Release`], дар тартиби глобалии амалиётҳои дигари [`SeqCst`] ва/ё деворҳо низ иштирок мекунад.
///
/// Фармоишҳои [`Acquire`], [`Release`], [`AcqRel`] ва [`SeqCst`]-ро қабул мекунад.
///
/// # Panics
///
/// Panics агар `order` [`Relaxed`] бошад.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Як ибтидоии истиснои мутақобила дар асоси спинлок.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Мунтазир бошед, то арзиши кӯҳна `false` бошад.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Ин девор бо мағоза дар `unlock` ҳамоҳанг мешавад.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // БЕХАТАР: : истифодаи девори атом бехатар аст.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Панҷараи хотираи тартибдиҳанда.
///
/// `compiler_fence` ягон коди мошинро намебардорад, аммо намудҳои хотираи аз нав фармоишдиҳандаро маҳдуд месозад, ки иҷозат дода мешавад.Махсусан, вобаста аз семантикаи додашудаи [`Ordering`], тартибдиҳанда метавонад аз ҳаракат хондан ё навиштан аз қабл ё пас аз занг ба тарафи дигари занг ба `compiler_fence` манъ карда шавад.Аҳамият диҳед, ки он **таҷҳизот*-ро аз чунин фармоишдиҳии нав бозмедорад **.
///
/// Ин дар заминаи якранг, иҷрои ин мушкилот нест, аммо вақте ки риштаҳои дигар метавонанд ҳамзамон хотираро тағир диҳанд, ибтидоии ҳамоҳангсозии қавитар ба монанди [`fence`] лозим аст.
///
/// Тартиби дуборае, ки аз ҷониби семантикаи фармоишии гуногун пешгирӣ шудааст, инҳоянд:
///
///  - бо [`SeqCst`], ҳеҷ гуна фармоиши дубораи хондан ва навиштан дар ин нуқта иҷозат дода намешавад.
///  - бо [`Release`], пеш аз хондан ва навиштан аз навиштаҳои баъдӣ гузаштан мумкин нест.
///  - бо [`Acquire`], хондан ва навиштани минбаъдаро пеш аз хондани пештара кӯчондан мумкин нест.
///  - бо [`AcqRel`], ҳарду қоидаҳои дар боло буда амалӣ карда мешаванд.
///
/// `compiler_fence` умуман танҳо барои пешгирии ришта бо худ * муфид аст.Яъне, агар як риштаи додашуда як пораи кодро иҷро карда, сипас қатъ карда шавад ва иҷрои рамзро дар ҷои дигар оғоз кунад (дар ҳоле, ки дар ҳамон ришта, ва консептуалӣ то ҳол дар ҳамон ядро).Дар барномаҳои анъанавӣ, ин танҳо дар ҳолати ба қайд гирифтани коркарди сигнал рух дода метавонад.
/// Дар рамзи сатҳи пасттар, чунин ҳолатҳо инчунин ҳангоми корбурди қатъҳо, ҳангоми татбиқи риштаҳои сабз бо пешакӣ ва ғ.
/// Хонандагони кунҷкоб тавсия дода мешаванд, ки муҳокимаи ядрои Linux дар бораи [memory barriers]-ро хонанд.
///
/// # Panics
///
/// Panics агар `order` [`Relaxed`] бошад.
///
/// # Examples
///
/// Бидуни `compiler_fence`, `assert_eq!` дар рамзи зерин, бо вуҷуди ҳама чизҳое, ки дар як ришта рух медиҳанд, кафолат дода намешавад *.
/// Барои фаҳмидани сабаб, фаромӯш накунед, ки тартибдиҳанда озод аст, ки мағозаҳоро ба `IMPORTANT_VARIABLE` ва `IS_READ` иваз кунад, зеро онҳо ҳам `Ordering::Relaxed` мебошанд.Агар ин тавр бошад ва пас аз навсозии `IS_READY` корбари сигнал пас аз навсозӣ карда шавад, он гоҳ корбари сигнал `IS_READY=1` хоҳад дид, аммо `IMPORTANT_VARIABLE=0`.
/// Истифодаи `compiler_fence` ин вазъро ислоҳ мекунад.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // нагузоред, ки навиштаҳои қаблӣ аз ин нуқта боло бурда шаванд
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // БЕХАТАР: : истифодаи девори атом бехатар аст.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Ба протсессор ишора мекунад, ки он дар дохили чархзании банд-интизор аст ("қулфи чарх").
///
/// Ин функсия ба манфиати [`hint::spin_loop`] бекор карда шудааст.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}