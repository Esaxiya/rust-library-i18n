//! Ин модул `Any` trait-ро татбиқ мекунад, ки ба воситаи инъикоси вақти корӣ чопкунии динамикии ҳама гуна намуди `'static` имкон медиҳад.
//!
//! `Any` худ метавонад барои ба даст овардани `TypeId` истифода шавад ва ҳангоми истифодаи объект ҳамчун trait хусусиятҳои бештар дорад.
//! Ҳамчун `&dyn Any` (объекти қарзии trait), он дорои усулҳои `is` ва `downcast_ref` аст, то санҷидани арзиши мавҷудбуда навъи додашударо ба даст орад ва ба арзиши ботинӣ ҳамчун намуд ишора кунад.
//! Ҳамчун `&mut dyn Any`, инчунин усули `downcast_mut` мавҷуд аст, ки барои гирифтани истиноди тағйирёбанда ба арзиши ботинӣ.
//! `Box<dyn Any>` усули `downcast`-ро илова мекунад, ки кӯшиш мекунад ба `Box<T>` гузарад.
//! Барои тафсилоти пурра ба ҳуҷҷатҳои [`Box`] нигаред.
//!
//! Дар хотир доред, ки `&dyn Any` бо санҷидани он, ки арзиши навъи мушаххаси мушаххас аст, маҳдуд аст ва барои санҷидани он, ки як навъи trait-ро истифода намекунад, истифода намешавад.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Нишондиҳандаҳои интеллектуалӣ ва `dyn Any`
//!
//! Як рафторе, ки ҳангоми истифодаи `Any` ҳамчун объекти trait дар хотир доштан лозим аст, алахусус бо намудҳои `Box<dyn Any>` ё `Arc<dyn Any>`, ин аст, ки танҳо ба `.type_id()` занг задан `TypeId` аз *контейнер* истеҳсол мекунад, на ин ки объекти trait.
//!
//! Ин мумкин аст бо роҳи табдил додани нишоннамои оқил ба `&dyn Any`, ба ҷои он ки `TypeId` объектро бармегардонад.
//! Барои намуна:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Шумо эҳтимолан инро мехоҳед:
//! let actual_id = (&*boxed).type_id();
//! // ... аз ин:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Вазъиятеро дида бароед, ки мо мехоҳем арзиши ба функсия гузаштаро бароварда кунем.
//! Мо арзиши коркарди дастгоҳҳои Debug-ро медонем, аммо навъи мушаххаси онро намедонем.Мо мехоҳем ба намудҳои алоҳида муносибати махсус диҳем: дар ин ҳолат дарозии сатрҳоро пеш аз арзиши онҳо чоп кунед.
//! Мо дар вақти тартиб додани он намуди мушаххаси арзиши худро намедонем, бинобар ин ба ҷои инъикоси вақти корӣ мо бояд истифода барем.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Функсияи Logger барои ҳама намуди, ки Debug-ро амалӣ мекунад.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Кӯшиш кунед, ки арзиши моро ба `String` табдил диҳед.
//!     // Дар сурати муваффақ шудан, мо мехоҳем дарозии String` ва инчунин арзиши онро барорем.
//!     // Агар не, ин навъи дигар аст: танҳо онро ороста чоп кунед.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ин функсия мехоҳад параметри худро қабл аз кор бо он ба қайд гирад.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... баъзе корҳои дигарро анҷом диҳед
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Ҳар trait
///////////////////////////////////////////////////////////////////////////////

/// A trait барои тақлид кардани чопкунии динамикӣ.
///
/// Аксари намудҳо `Any` амалӣ мекунанд.Аммо, ягон намуди дорои истиноди ғайри "статикӣ" нест.
/// Барои тафсилоти бештар ба [module-level documentation][mod] нигаред.
///
/// [mod]: crate::any
// Ин trait хатарнок нест, гарчанде ки мо ба мушаххасоти функсияи `type_id` ягона impl дар рамзи хатарнок такя мекунем (масалан, `downcast`).Одатан, ин мушкилот хоҳад буд, аммо азбаски ягона мафҳуми `Any` татбиқи кӯрпа аст, ягон рамзи дигар `Any`-ро татбиқ карда наметавонад.
//
// Мо метавонистем ин trait-ро хатарнок созем-ин шикастро ба вуҷуд намеорад, зеро мо ҳамаи барномаҳоро назорат мекунем-аммо мо интихоб намекунем, ки ин ҳам воқеан зарур нест ва метавонад корбаронро дар бораи фарқияти traits ва усулҳои хатарнок ба иштибоҳ андозад (яъне, `type_id` ҳанӯз ҳам занг зада метавонад, аммо мо эҳтимол мехоҳем инро дар ҳуҷҷатҳо нишон диҳем).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Меорад `TypeId` аз `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Усулҳои васеъкунӣ барои ҳама гуна объектҳои trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Боварӣ ҳосил кунед, ки натиҷаи масалан пайваст кардани ришта метавонад бо `unwrap` чоп карда шавад ва аз ин рӯ истифода шавад.
// Агар диспетчер бо upcasting кор кунад, шояд оқибат дигар лозим нашавад.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Бозмегардонад `true` агар навъи қуттӣ ҳамон `T` бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // `TypeId`-ро ба даст оред, ки ин функсия бо он сохта шудааст.
        let t = TypeId::of::<T>();

        // Дар объекти (`self`) trait `TypeId`-ро ба даст оред.
        let concrete = self.type_id();

        // Ҳардуи 'TypeId`-ро дар бораи баробарӣ муқоиса кунед.
        t == concrete
    }

    /// Баъзе истинодҳоро ба арзиши қуттӣ бармегардонад, агар он навъи `T` бошад, ё `None`, агар не.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // БЕХАТАР: : танҳо тафтиш кунед, ки оё мо ба навъи дуруст ишора карда истодаем ва мо метавонем ба он такя кунем
            // ки бехатарии хотираро месанҷад, зеро мо ҳама чизро барои ҳама намудҳо татбиқ кардаем;ҳеҷ гуна тасаввуроти дигар вуҷуд дошта наметавонанд, зеро онҳо бо имплияи мо мухолифат мекунанд.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Баъзе истиноди тағиршавандаро ба қимати қуттӣ бармегардонад, агар он навъи `T` бошад ё `None`, агар не.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // БЕХАТАР: : танҳо тафтиш кунед, ки оё мо ба навъи дуруст ишора карда истодаем ва мо метавонем ба он такя кунем
            // ки бехатарии хотираро месанҷад, зеро мо ҳама чизро барои ҳама намудҳо татбиқ кардаем;ҳеҷ гуна тасаввуроти дигар вуҷуд дошта наметавонанд, зеро онҳо бо имплияи мо мухолифат мекунанд.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ба пеш, ба усули дар навъи `Any` муайяншуда.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ва усулҳои он
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` як нишондиҳандаи беназири ҷаҳонӣ барои як навъро нишон медиҳад.
///
/// Ҳар як `TypeId` объекти ношаффоф аст, ки ба санҷиши он чӣ дар дохили он иҷозат намедиҳад, балки ба амалиётҳои асосӣ, аз қабили клондан, муқоиса, чоп ва намоиш имкон медиҳад.
///
///
/// `TypeId` дар айни замон танҳо барои намудҳое мавҷуд аст, ки ба `'static` мансубанд, аммо ин маҳдудият дар future бартараф карда мешавад.
///
/// Дар ҳоле ки `TypeId` `Hash`, `PartialOrd` ва `Ord`-ро татбиқ мекунад, бояд қайд кард, ки ҳашарҳо ва фармоиш байни варақаҳои Rust фарқ мекунанд.
/// Ҳазар кунед, ки ба онҳо дар дохили рамзи худ такя кунед!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// `TypeId`-и навъи ин функсияи умумиро бармегардонад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Номи як навъро ҳамчун буридаи сатр бармегардонад.
///
/// # Note
///
/// Ин барои истифодаи ташхисӣ пешбинӣ шудааст.
/// Мазмун ва формати дақиқи сатри баргардондашуда муайян карда нашудаанд, ба истиснои беҳтарин тавсифи намуд.
/// Масалан, дар байни сатрҳое, ки `type_name::<Option<String>>()` метавонад баргардонад, `"Option<String>"` ва `"std::option::Option<std::string::String>"` мебошанд.
///
///
/// Сатри баргардондашуда набояд ҳамчун як идентификатори ягонаи тип ҳисоб карда шавад, зеро навъҳои сершумор метавонанд ба як навъи тип мувофиқат кунанд.
/// Ба ҳамин монанд, ҳеҷ кафолате вуҷуд надорад, ки ҳамаи қисмҳои намуд дар сатри баргашта пайдо мешаванд: масалан, мушаххасоти умр дар айни замон дохил карда нашудаанд.
/// Илова бар ин, натиҷа метавонад дар байни версияҳои компилятор тағир ёбад.
///
/// Татбиқи ҳозира ҳамон инфрасохторро бо ташхиси компилятор ва debuginfo истифода мекунад, аммо ин кафолат дода намешавад.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Номи намуди қимати ишорашударо ҳамчун буридаи сатр бармегардонад.
/// Ин ҳамон `type_name::<T>()` аст, аммо дар он ҷое, ки навъи тағирёбанда ба осонӣ дастрас нест, истифода бурдан мумкин аст.
///
/// # Note
///
/// Ин барои истифодаи ташхисӣ пешбинӣ шудааст.Мазмун ва форматҳои дақиқи сатр муайян карда нашудаанд, ба истиснои беҳтарин тавсифи намуд.
/// Масалан, `type_name_of_val::<Option<String>>(None)` метавонад `"Option<String>"` ё `"std::option::Option<std::string::String>"`-ро баргардонад, аммо `"foobar"` не.
///
/// Илова бар ин, натиҷа метавонад дар байни версияҳои компилятор тағир ёбад.
///
/// Ин функсия объектҳои trait-ро ҳал намекунад, яъне `type_name_of_val(&7u32 as &dyn Debug)` метавонад `"dyn Debug"`-ро баргардонад, аммо `"u32"` не.
///
/// Номи намуд набояд як нишондиҳандаи беназири намуд ҳисобида шавад;
/// намудҳои гуногун метавонанд номи якхеларо мубодила кунанд.
///
/// Татбиқи ҳозира ҳамон инфрасохторро бо ташхиси компилятор ва debuginfo истифода мекунад, аммо ин кафолат дода намешавад.
///
/// # Examples
///
/// Намуди бутуни пешфарз ва шиноварро чоп мекунад.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}