//! Итератори `IntoIter`-ро барои массивҳо муайян мекунад.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Итератори [array] аз рӯи арзиши иловагӣ.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Ин массиви мо такрори он аст.
    ///
    /// Элементҳое, ки индекси `i` доранд, ки дар он `alive.start <= i < alive.end` ҳанӯз дода нашудааст ва сабтҳои дурусти массив мебошанд.
    /// Унсурҳои индекси `i < alive.start` ё `i >= alive.end` аллакай дода шудаанд ва дигар ба онҳо дастрасӣ надоранд!Он унсурҳои мурда ҳатто метавонанд дар ҳолати комилан бетағйир қарор дошта бошанд!
    ///
    ///
    /// Ҳамин тавр инвариантҳо инҳоянд:
    /// - `data[alive]` зинда аст (яъне унсурҳои дуруст дорад)
    /// - `data[..alive.start]` ва `data[alive.end..]` мурдаанд (яъне унсурҳо аллакай хонда шуда буданд ва дигар ба онҳо даст нарасонед!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Унсурҳои дар `data`, ки ҳанӯз дода нашудаанд.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Дар болои `array` додашуда як iterator нав месозад.
    ///
    /// *Эзоҳ*: ин усул метавонад дар future пас аз [`IntoIterator` is implemented for arrays][array-into-iter] бекор карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Намуди `value` ба ҷои `&i32`, `i32` аст
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // БЕХАТАР: : Трансмут дар ин ҷо воқеан бехатар аст.Ҳуҷҷатҳои `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ба ҳамон андоза ва ҳамоҳангӣ кафолат дода мешавад
        // > ҳамчун `T`.
        //
        // Ҳуҷҷатҳо ҳатто тарҷумаро аз массиви `MaybeUninit<T>` ба массиви `T` нишон медиҳанд.
        //
        //
        // Бо ин, ин ибтидо инвариантҳоро қонеъ мекунад.

        // FIXME(LukasKalbertodt): воқеан `mem::transmute`-ро дар инҷо истифода баред, вақте ки он бо const generics кор мекунад:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // То он вақт, мо метавонем `mem::transmute_copy`-ро барои нусхабардории бита ҳамчун навъи дигар эҷод кунем, пас `array`-ро фаромӯш кунем, то он афтода нашавад.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Як буридаи тағирнашавандаи ҳамаи элементҳоро, ки ҳанӯз дода нашудаанд, бармегардонад.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // БЕХАТАР We: Мо медонем, ки ҳамаи унсурҳо дар доираи `alive` дуруст оғоз карда шудаанд.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Як буридаи тағирёбандаи ҳамаи элементҳоро, ки ҳанӯз дода нашудаанд, бармегардонад.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // БЕХАТАР We: Мо медонем, ки ҳамаи унсурҳо дар доираи `alive` дуруст оғоз карда шудаанд.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Индекси навбатиро аз пеш гиред.
        //
        // Афзоиши `alive.start` аз ҷониби 1 инвариантро нисбати `alive` нигоҳ медорад.
        // Аммо, бинобар ин тағирот, дар муддати кӯтоҳ, минтақаи зинда дигар `data[alive]` нест, балки `data[idx..alive.end]` аст.
        //
        self.alive.next().map(|idx| {
            // Элементро аз массив хонед.
            // БЕХАТАР: : `idx` индекс ба минтақаи собиқи "alive" мебошад
            // массиви.Хондани ин унсур маънои онро дорад, ки `data[idx]` ҳоло мурда шудааст (яъне даст нарасонед).
            // Азбаски `idx` оғози минтақаи зинда буд, минтақаи зинда акнун боз `data[alive]` аст ва ҳама инвариантҳоро барқарор мекунад.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Индекси навбатиро аз қафо гиред.
        //
        // Кам кардани `alive.end` аз ҷониби 1 инвариантро нисбати `alive` нигоҳ медорад.
        // Аммо, бинобар ин тағирот, дар муддати кӯтоҳ, минтақаи зинда дигар `data[alive]` нест, балки `data[alive.start..=idx]` аст.
        //
        self.alive.next_back().map(|idx| {
            // Элементро аз массив хонед.
            // БЕХАТАР: : `idx` индекс ба минтақаи собиқи "alive" мебошад
            // массиви.Хондани ин унсур маънои онро дорад, ки `data[idx]` ҳоло мурда шудааст (яъне даст нарасонед).
            // Азбаски `idx` охири минтақаи зинда буд, минтақаи зинда акнун боз `data[alive]` аст ва ҳама инвариантҳоро барқарор мекунад.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // БЕХАТАР: : Ин бехатар аст: `as_mut_slice` маҳз зергурӯҳро бармегардонад
        // аз унсурҳое, ки ҳанӯз кӯчонида нашудаанд ва боқӣ мондаанд.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Бо сабаби инвариантҳои "live.start <=ҳеҷ гоҳ зери об нахоҳад рафт
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Итератор дар ҳақиқат дарозии дурустро гузориш медиҳад.
// Шумораи унсурҳои "alive" (ки ҳанӯз дода мешавад) дарозии диапазони `alive` мебошад.
// Ин диапазон дар `next` ё `next_back` дарозӣ кам карда мешавад.
// Он ҳамеша дар ин усулҳо 1 кам карда мешавад, аммо танҳо агар `Some(_)` баргардонида шавад.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Дар хотир доред, ки ба мо аслан лозим нест, ки ба ҳамон як диапазони зинда мувофиқат кунем, аз ин рӯ мо метавонем новобаста аз он ки `self` дар куҷост, ба офсет 0 клон кунем.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Ҳама унсурҳои зиндаро клон кунед.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ба массиви нав клон нависед ва диапазони зиндаашро навсозӣ кунед.
            // Агар panics-ро клон кунанд, мо ҷузъҳои қаблиро дуруст партофтем.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Танҳо унсурҳои чопнашударо чоп кунед: мо дигар ба унсурҳои ҳосилшуда дастрасӣ карда наметавонем.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}