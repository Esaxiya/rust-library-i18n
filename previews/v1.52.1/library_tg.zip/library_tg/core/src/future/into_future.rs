use crate::future::Future;

/// Табдил ба `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Натиҷае, ки future ба анҷом мерасонад.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Мо инро ба кадом future табдил медиҳем?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Аз арзиш future месозад.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}