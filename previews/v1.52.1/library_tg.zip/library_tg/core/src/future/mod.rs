#![stable(feature = "futures_api", since = "1.36.0")]

//! Арзишҳои асинхронӣ

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ин навъи он зарур аст, зеро:
///
/// а) Генераторҳо `for<'a, 'b> Generator<&'a mut Context<'b>>`-ро татбиқ карда наметавонанд, бинобар ин мо бояд нишоннамои хомро гузарем (ниг. <https://github.com/rust-lang/rust/issues/68923>).
///
/// б) Нишондиҳандаҳои хом ва `NonNull` `Send` ё `Sync` нестанд, то ин ки ҳар як future non-Send/Sync низ сохта шавад ва мо инро намехоҳем.
///
/// Он инчунин паст кардани HIR аз `.await`-ро содда мекунад.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Генераторро ба future печонед.
///
/// Ин функсия `GenFuture`-ро дар зери бар мегардонад, аммо онро дар `impl Trait` пинҳон мекунад, то паёмҳои хатогии беҳтар диҳад (`impl Future` на `GenFuture<[closure.....]>`).
///
// Ин барои пешгирӣ кардани хатогиҳои иловагӣ пас аз барқароршавӣ аз `const async fn` ин `const` аст
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Мо ба он такя мекунем, ки async/await futures барои эҷоди қарзҳои мустақил дар генератори аслӣ манқул аст.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // БЕХАТАР: : Бехатар аст, зеро мо !Unpin + !Drop ҳастем ва ин танҳо як дурнамои майдон аст.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Генераторро дубора барқарор кунед, ки `&mut Context`-ро ба нишондиҳандаи хоми `NonNull` табдил диҳед.
            // Паст кардани `.await` онро бехатар ба `&mut Context` мепартояд.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `cx.0` нишоннамои дуруст аст
    // ки тамоми талаботро барои истиноди мутавозанда иҷро мекунад.
    unsafe { &mut *cx.0.as_ptr().cast() }
}