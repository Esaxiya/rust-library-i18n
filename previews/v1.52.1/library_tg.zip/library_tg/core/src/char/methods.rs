//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Баландтарин нуқтаи рамзи дурусти `char` метавонад дошта бошад.
    ///
    /// `char` як [Unicode Scalar Value] аст, ки маънои онро дорад, ки он [Code Point] аст, аммо танҳо онҳое, ки дар доираи муайян мебошанд.
    /// `MAX` баландтарин нуқтаи рамзи дуруст аст, ки [Unicode Scalar Value] дуруст аст.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () дар Юникод барои ифодаи хатои рамзкушоӣ истифода мешавад.
    ///
    /// Он метавонад, масалан, ҳангоми ба [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) додани байтҳои нодурусти UTF-8 ба амал ояд.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Версияи [Unicode](http://www.unicode.org/), ки қисмҳои Юникод аз усулҳои `char` ва `str` ба он асос ёфтаанд.
    ///
    /// Версияҳои нави Юникод мунтазам бароварда мешаванд ва баъдан ҳамаи усулҳо дар китобхонаи стандартӣ вобаста ба Юникод нав карда мешаванд.
    /// Аз ин рӯ, рафтори баъзе усулҳои `char` ва `str` ва арзиши ин доимӣ бо мурури замон тағир меёбад.
    /// Ин * дигаргунии қатъӣ ба ҳисоб намеравад.
    ///
    /// Нақшаи рақамгузории версия дар [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) шарҳ дода шудааст.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Аз болои нуқтаҳои рамзии UTF-16 дар `iter` такрори эҷод мекунад, ва ҷонишини ҷудонашударо ҳамчун "Err`" бармегардонад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Бо иваз кардани натиҷаҳои `Err` бо аломати ивазкунӣ, декодерҳои зиёноварро гирифтан мумкин аст:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Табдил `u32` ба `char`.
    ///
    /// Аҳамият диҳед, ки ҳамаи `char`ҳо ['u32`]-и эътибор доранд ва метавонанд ба яке бо
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Аммо, баръакс дуруст нест: на ҳама ['u32`]-и дуруст`char`s мебошанд.
    /// `from_u32()` `None`-ро бармегардонад, агар вуруд барои `char` арзиши мӯътабар набошад.
    ///
    /// Барои версияи хатарноки ин функсия, ки ин чекҳоро нодида мегирад, ба [`from_u32_unchecked`] нигаред.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Бозгашти `None` вақте ки вуруд як `char` мӯътабар нест:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32`-ро ба `char` табдил медиҳад, эътибор надода.
    ///
    /// Аҳамият диҳед, ки ҳамаи `char`ҳо ['u32`]-и эътибор доранд ва метавонанд ба яке бо
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Аммо, баръакс дуруст нест: на ҳама ['u32`]-и дуруст`char`s мебошанд.
    /// `from_u32_unchecked()` инро нодида мегирад ва кӯр-кӯрона ба `char` меандозад ва эҳтимолан беэътиборро ба вуҷуд меорад.
    ///
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро он метавонад арзишҳои нодурусти `char` созад.
    ///
    /// Барои нусхаи бехатарии ин вазифа, ба функсияи [`from_u32`] нигаред.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // БЕХАТАР: : шартномаи бехатариро бояд даъваткунанда риоя кунад.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Рақамро дар радиуси додашуда ба `char` табдил медиҳад.
    ///
    /// 'radix'-ро дар ин ҷо баъзан 'base' низ меноманд.
    /// Радикси ду аз рақами дуӣ, радиуси даҳӣ, даҳӣ ва радиои шонздаҳии шонздаҳӣ ишора мекунад, то баъзе арзишҳои умумӣ диҳанд.
    ///
    /// Радисҳои худсарона дастгирӣ карда мешаванд.
    ///
    /// `from_digit()` агар `None` баргардад, агар вуруд як рақам дар радиуси додашуда набошад.
    ///
    /// # Panics
    ///
    /// Panics агар радиуси аз 36 калонтар дода шавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Даҳсолаи 11 як рақам дар пойгоҳи 16 аст
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Бозгашти `None` вақте ки вуруд рақам нест:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Гузариш аз радиуси калон, ки боиси panic мегардад:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Месанҷад, ки оё `char` як рақам дар радиуси додашуда аст.
    ///
    /// 'radix'-ро дар ин ҷо баъзан 'base' низ меноманд.
    /// Радикси ду аз рақами дуӣ, радиуси даҳӣ, даҳӣ ва радиои шонздаҳии шонздаҳӣ ишора мекунад, то баъзе арзишҳои умумӣ диҳанд.
    ///
    /// Радисҳои худсарона дастгирӣ карда мешаванд.
    ///
    /// Дар муқоиса бо [`is_numeric()`], ин функсия танҳо аломатҳои `0-9`, `a-z` ва `A-Z`-ро мешиносад.
    ///
    /// 'Digit' танҳо аломатҳои зерин муайян карда шудааст:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Барои фаҳмиши ҳамаҷонибаи 'digit', ба [`is_numeric()`] нигаред.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics агар радиуси аз 36 калонтар дода шавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Гузариш аз радиуси калон, ки боиси panic мегардад:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-ро ба рақам дар радиуси додашуда табдил медиҳад.
    ///
    /// 'radix'-ро дар ин ҷо баъзан 'base' низ меноманд.
    /// Радикси ду аз рақами дуӣ, радиуси даҳӣ, даҳӣ ва радиои шонздаҳии шонздаҳӣ ишора мекунад, то баъзе арзишҳои умумӣ диҳанд.
    ///
    /// Радисҳои худсарона дастгирӣ карда мешаванд.
    ///
    /// 'Digit' танҳо аломатҳои зерин муайян карда шудааст:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `None`-ро бармегардонад, агар `char` ба рақаме дар радиуси додашуда ишора накунад.
    ///
    /// # Panics
    ///
    /// Panics агар радиуси аз 36 калонтар дода шавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Гузаронидани натиҷаҳои ғайримақам ба нокомӣ оварда мерасонад:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Гузариш аз радиуси калон, ки боиси panic мегардад:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // рамз дар ин ҷо тақсим карда шудааст, то суръати иҷро барои ҳолатҳои беҳтар шудани `radix` доимӣ ва 10 ё хурдтар иҷро карда шавад
        //
        let val = if likely(radix <= 10) {
            // Агар рақам набошад, адади аз radix бузургтар сохта мешавад.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Итератореро бармегардонад, ки аз шонздаҳии Unicode гурехтани аломатро ҳамчун "char`s" медиҳад.
    ///
    /// Ин аломатҳоро бо синтаксиси Rust шакли `\u{NNNNNN}` раҳо хоҳад кард, ки дар он `NNNNNN` намояндагии шонздаҳӣ аст.
    ///
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 кафолат медиҳад, ки барои c==0 рамз ҳисоб мекунад, ки як рақам бояд чоп карда шавад ва (ки ҳамон аст) аз зеркунии (31, 32) ҷилавгирӣ мекунад
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // индекси муҳимтарин рақами шонздаҳӣ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Версияи васеи `escape_debug`, ки ба таври ихтиёрӣ ба гурезҳои рамзии васеи Grapheme иҷозат медиҳад.
    /// Ин ба мо имконият медиҳад, ки аломатҳо, ба монанди аломатҳои ғайримуқаррариро, вақте ки онҳо дар оғози сатр беҳтаранд, беҳтар формат кунем.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Итератореро бармегардонад, ки рамзи фирори ҳарфро ҳамчун "char`s" медиҳад.
    ///
    /// Ин аломатҳои монанд ба татбиқи `Debug` аз `str` ё `char` хоҳад гурехт.
    ///
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Итератореро бармегардонад, ки рамзи фирори ҳарфро ҳамчун "char`s" медиҳад.
    ///
    /// Бо нобаёнӣ бо рағбат ба сохтани адабиётҳое интихоб карда мешавад, ки бо забонҳои мухталиф қонунӣ ҳастанд, аз ҷумла C++ 11 ва забонҳои шабеҳи С-оила.
    /// Қоидаҳои дақиқ инҳоянд:
    ///
    /// * Ҷадвалбанд ҳамчун `\t` раҳо ёфт.
    /// * Бозгашти вагон ҳамчун `\r` гурехта мешавад.
    /// * Ғизои хатӣ ҳамчун `\n` гурехтааст.
    /// * Иқтибоси ягона ҳамчун `\'` гурехтааст.
    /// * Иқтибоси дугона ҳамчун `\"` раҳо шудааст.
    /// * Баръакс ҳамчун `\\` раҳо ёфт.
    /// * Ягон аломат дар доираи 'чопшавандаи ASCII' `0x20` .. `0x7e` фарогир нест.
    /// * Ба ҳама аломатҳои дигар гурезонидани шонздаҳии Unicode дода мешавад;нигаред [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Шумораи байтро, ки ба `char` лозим аст, агар дар UTF-8 рамзгузорӣ шавад, бармегардонад.
    ///
    /// Ин миқдори байт ҳамеша аз 1 то 4 мебошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Навъи `&str` кафолат медиҳад, ки мундариҷаи он UTF-8 аст ва аз ин рӯ мо метавонем дарозии онро муқоиса кунем, агар ҳар як нуқтаи рамз ҳамчун `char` ва дар худи `&str` нишон дода шавад:
    ///
    ///
    /// ```
    /// // ҳамчун чархҳо
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ҳарду метавонанд ҳамчун се байт нишон дода шаванд
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ҳамчун &str, ин ду дар UTF-8 рамзгузорӣ шудаанд
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // мо мебинем, ки онҳо дар маҷмӯъ шаш байт мегиранд ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ба монанди &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Шумораи воҳидҳои рамзи 16-битаро бармегардонад, ки ин `char` агар дар UTF-16 рамзгузорӣ шавад, лозим аст.
    ///
    ///
    /// Барои шарҳи бештари ин мафҳум ба ҳуҷҷатҳои [`len_utf8()`] нигаред.
    /// Ин функсия оина аст, аммо барои UTF-16 ба ҷои UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ин аломатро ҳамчун UTF-8 ба буферии байти додашуда рамзгузорӣ мекунад ва пас аз он субфисси буфереро, ки аломати рамзишударо дар бар мегирад, бармегардонад.
    ///
    ///
    /// # Panics
    ///
    /// Panics агар буфер ба андозаи кофӣ калон набошад.
    /// Буфери дарозии чорто барои кодир кардани ҳама гуна `char` кофӣ калон аст.
    ///
    /// # Examples
    ///
    /// Дар ҳардуи ин мисолҳо, 'ß' барои рамзгузорӣ ду байт мегирад.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Буфере, ки хеле хурд аст:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // БЕХАТАР: : `char` ҷонишине нест, бинобар ин ин UTF-8 эътибор дорад.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ин аломатро ҳамчун UTF-16 ба буфери `u16` додашуда рамзгузорӣ мекунад ва пас аз он субфисси буфереро, ки аломати рамзгузоришударо дар бар мегирад, бармегардонад.
    ///
    ///
    /// # Panics
    ///
    /// Panics агар буфер ба андозаи кофӣ калон набошад.
    /// Буфери дарозии 2 барои рамзгузории ҳама гуна `char` кофӣ калон аст.
    ///
    /// # Examples
    ///
    /// Дар ҳардуи ин мисолҳо, '𝕊' барои рамзгузорӣ ду `u16 'мегирад.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Буфере, ки хеле хурд аст:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// `true`-ро бармегардонад, агар ин `char` хусусияти `Alphabetic` дошта бошад.
    ///
    /// `Alphabetic` дар боби 4 (Хусусиятҳои аломатҳо)-и [Unicode Standard] тасвир шудааст ва дар [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] нишон дода шудааст.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ишқ бисёр чизҳост, аммо алифбо нест
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// `true`-ро бармегардонад, агар ин `char` хусусияти `Lowercase` дошта бошад.
    ///
    /// `Lowercase` дар боби 4 (Хусусиятҳои аломатҳо)-и [Unicode Standard] тасвир шудааст ва дар [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] нишон дода шудааст.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Скриптҳо ва пунктуацияҳои гуногуни чинӣ ҳолат надоранд ва аз ин рӯ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// `true`-ро бармегардонад, агар ин `char` хусусияти `Uppercase` дошта бошад.
    ///
    /// `Uppercase` дар боби 4 (Хусусиятҳои аломатҳо)-и [Unicode Standard] тасвир шудааст ва дар [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] нишон дода шудааст.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Скриптҳо ва пунктуацияҳои гуногуни чинӣ ҳолат надоранд ва аз ин рӯ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// `true`-ро бармегардонад, агар ин `char` хусусияти `White_Space` дошта бошад.
    ///
    /// `White_Space` дар [Unicode Character Database][ucd] [`PropList.txt`] нишон дода шудааст.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // фазои вайроннашаванда
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Бозмегардонад `true` агар ин `char` ё [`is_alphabetic()`] ё [`is_numeric()`] қонеъ.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true`-ро бармегардонад, агар ин `char` дорои категорияи умумӣ барои рамзҳои назоратӣ бошад.
    ///
    /// Рамзҳои назоратӣ (нуқтаҳои рамзӣ бо категорияи умумии `Cc`) дар боби 4 (Хусусиятҳои аломатҳо)-и [Unicode Standard] тавсиф шудаанд ва дар [Unicode Character Database][ucd] [`UnicodeData.txt`] нишон дода шудаанд.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // U + 009C, ТЕРМИНАТОРИ САТР
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// `true`-ро бармегардонад, агар ин `char` хусусияти `Grapheme_Extend` дошта бошад.
    ///
    /// `Grapheme_Extend` дар [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] тавсиф шудааст ва дар [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] нишон дода шудааст.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true`-ро бармегардонад, агар ин `char` яке аз категорияҳои умумӣ барои рақамҳоро дошта бошад.
    ///
    /// Категорияҳои умумии рақамҳо (`Nd` барои рақамҳои даҳӣ, `Nl` барои аломатҳои ададии ба ҳарф монанд ва `No` барои дигар аломатҳои ададӣ) дар [Unicode Character Database][ucd] [`UnicodeData.txt`] муайян карда шудаанд.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Итератореро бармегардонад, ки харитаи хурди ин `char`-ро ҳамчун як ё якчанд ҳосил мекунад
    /// `char`s.
    ///
    /// Агар ин `char` харитасозии хурдро надошта бошад, iterator ҳамон `char` медиҳад.
    ///
    /// Агар ин `char` харитаи ҳарфҳои як ба як дошта бошад, ки онро [Unicode Character Database][ucd] [`UnicodeData.txt`] додааст, такрори он `char` медиҳад.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Агар ин `char` мулоҳизаҳои махсусро талаб кунад (масалан, якчанд 'char), итератори он' char '(ҳо)-и додаи [`SpecialCasing.txt`]-ро медиҳад.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ин амалиёт харитаи бечунучаро бидуни дӯзандагӣ иҷро мекунад.Яъне табдили он аз матн ва забон мустақил аст.
    ///
    /// Дар [Unicode Standard], боби 4 (Хусусиятҳои аломатҳо) харитасозии парвандаҳоро дар маҷмӯъ ва боби 3 (Conformance) алгоритми пешфарзро барои табдили парванда баррасӣ мекунад.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Баъзан натиҷа аз як аломат зиёдтар мешавад:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Ҳарфҳое, ки ҳам ҳарфи калон ва ҳам хурд надоранд, ба худ табдил меёбанд.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Итератореро бармегардонад, ки харитаи калонҳаҷми ин `char`-ро ҳамчун як ё якчанд ҳосил мекунад
    /// `char`s.
    ///
    /// Агар ин `char` харитаи калонро надошта бошад, такрори ҳамон `char` медиҳад.
    ///
    /// Агар ин `char` харитаи калони як ба як дошта бошад, ки онро [Unicode Character Database][ucd] [`UnicodeData.txt`] дода бошад, такрори он `char` медиҳад.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Агар ин `char` мулоҳизаҳои махсусро талаб кунад (масалан, якчанд 'char), итератори он' char '(ҳо)-и додаи [`SpecialCasing.txt`]-ро медиҳад.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ин амалиёт харитаи бечунучаро бидуни дӯзандагӣ иҷро мекунад.Яъне табдили он аз матн ва забон мустақил аст.
    ///
    /// Дар [Unicode Standard], боби 4 (Хусусиятҳои аломатҳо) харитасозии парвандаҳоро дар маҷмӯъ ва боби 3 (Conformance) алгоритми пешфарзро барои табдили парванда баррасӣ мекунад.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Ҳамчун iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Истифодаи `println!` мустақим:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Ҳарду баробаранд:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Истифодаи `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Баъзан натиҷа аз як аломат зиёдтар мешавад:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Ҳарфҳое, ки ҳам ҳарфи калон ва ҳам хурд надоранд, ба худ табдил меёбанд.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Эзоҳ дар бораи маҳал
    ///
    /// Дар туркӣ, муодили 'i' дар лотинӣ ба ҷои ду шакл панҷ шакл дорад:
    ///
    /// * 'Dotless': I/ı, баъзан навишта шудааст ï
    /// * 'Dotted': İ/i
    ///
    /// Аҳамият диҳед, ки 'i'-и хурд бо нуқтаи лотинӣ ҳамон аст.Аз ин рӯ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Арзиши `upper_i` дар ин ҷо ба забони матн такя мекунад: агар мо дар `en-US` бошем, он бояд `"I"` бошад, аммо агар мо дар `tr_TR` бошем, он бояд `"İ"` бошад.
    /// `to_uppercase()` инро ба назар намегирад ва аз ин рӯ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// забонҳо дорад.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Санҷед, ки оё арзиш дар ҳудуди ASCII аст.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Нусхаи қиматро бо ҳарфи калон ASCII месозад.
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои калон кардани арзиши ҷой, [`make_ascii_uppercase()`] истифода баред.
    ///
    /// Барои калон кардани аломатҳои ASCII, илова бар аломатҳои ғайри ASCII, [`to_uppercase()`]-ро истифода баред.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Нусхаи қиматро бо ҳарфи хурди ASCII месозад.
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои кам кардани арзиши ҷойгоҳ, [`make_ascii_lowercase()`]-ро истифода баред.
    ///
    /// Барои хурд кардани аломатҳои ASCII, илова бар аломатҳои ғайри ASCII, [`to_lowercase()`]-ро истифода баред.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Тафтиш мекунад, ки ду арзиш мувофиқати ҳарфҳои ASCII мебошанд.
    ///
    /// Ба `to_ascii_lowercase(a) == to_ascii_lowercase(b)` баробар аст.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Ин навъро ба ҳарфҳои калони ASCII дар ҷои худ табдил медиҳад.
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави калон бе тағир додани арзиши мавҷуда, [`to_ascii_uppercase()`]-ро истифода баред.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ин навъро бо ҳарфи хурди ASCII дар ҷои худ иваз мекунад.
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави хурд бидуни тағир додани арзиши мавҷуда, [`to_ascii_lowercase()`]-ро истифода баред.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Санҷидани он, ки қимат аломати алифбои ASCII аст:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ё
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Санҷидани он, ки қимат аломати калонии ASCII аст:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Санҷидани он, ки қимат аломати хурди ASCII аст:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Санҷидани он, ки қимат аломати рақамии ASCII аст:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ё
    /// - U + 0061 'a' ..=U + 007A 'z', ё
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Месанҷад, ки оё ин рақам даҳии ASCII аст:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Месанҷад, ки оё ин рақам шонздаҳии ASCII аст:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ё
    /// - U + 0041 'A' ..=U + 0046 'F', ё
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Санҷидани он, ки қимат аломати пунктуатсияи ASCII аст:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ё
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ё
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ё
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Санҷидани он, ки қимат аломати графикии ASCII аст:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Тафтиш мекунад, ки қимат аломати фосилаи фазои ASCII аст:
    /// U + 0020 SPACE, U + 0009 TAB уфуқӣ, U + 000A хати хати, U + 000C ХУРОКИ шакли, ё U + 000D БАРГАШТАНИ АВТОМОБИЛ.
    ///
    /// Rust аз WhatWG Infra Standard [definition of ASCII whitespace][infra-aw] истифода мебарад.Якчанд таърифҳои дигар дар истифодаи васеъ мавҷуданд.
    /// Масалан, [the POSIX locale][pct] U + 000B VERTICAL TAB ва инчунин ҳамаи аломатҳои дар боло овардашударо дар бар мегирад, аммо-аз ҳамон мушаххасот-[қоидаи пешфарз барои "field splitting" дар Bourne shell][bfs]*танҳо* SPACE, HORIZONTAL TAB ва ХИЗМАТИ ХАТТ ҳамчун фазо.
    ///
    ///
    /// Агар шумо барномае нависед, ки формати мавҷудаи файлро коркард кунад, пеш аз истифодаи ин функсия, он таърифи форматро дар фазои сафед муайян кунед.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Месанҷад, ки оё арзиши аломати идоракунии ASCII аст:
    /// U + 0000 NUL ..=U + 001F ҶУДОШАВАНДАИ ЯГОНА, ё U + 007F НЕСТ.
    /// Дар хотир доред, ки аксари аломатҳои фазои сафедии ASCII аломатҳои идоракунӣ мебошанд, аммо SPACE чунин нест.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Арзиши хоми u32-ро ҳамчун UTF-8 ба буферии байтии додашуда рамзгузорӣ мекунад ва пас субсиссияи буферро, ки аломати рамзгузоришударо дар бар мегирад, бармегардонад.
///
///
/// Баръакси `char::encode_utf8`, ин усул инчунин нуқтаҳои кодепро дар диапазони ҷойгузин идора мекунад.
/// (Эҷоди `char` дар диапазони ҷойгузин UB мебошад.) Натиҷа [generalized UTF-8] эътибор дорад, аммо UTF-8 мӯътабар нест.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics агар буфер ба андозаи кофӣ калон набошад.
/// Буфери дарозии чорто барои кодир кардани ҳама гуна `char` кофӣ калон аст.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Арзиши хоми u32-ро ҳамчун UTF-16 ба буфери `u16`-и пешбинишуда рамзгузорӣ мекунад ва пас субсиссияи буферро, ки аломати рамзгузоришударо дар бар мегирад, бармегардонад.
///
///
/// Баръакси `char::encode_utf16`, ин усул инчунин нуқтаҳои кодепро дар диапазони ҷойгузин идора мекунад.
/// (Эҷоди `char` дар диапазони ҷойгузин UB мебошад.)
///
/// # Panics
///
/// Panics агар буфер ба андозаи кофӣ калон набошад.
/// Буфери дарозии 2 барои рамзгузории ҳама гуна `char` кофӣ калон аст.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // БЕХАТАР: : ҳар як даст тафтиш мекунад, ки оё бит барои навиштан кофӣ аст
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ба воситаи он меафтад
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ҳавопаймоҳои иловагӣ ба ҷонишини онҳо ворид мешаванд.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}