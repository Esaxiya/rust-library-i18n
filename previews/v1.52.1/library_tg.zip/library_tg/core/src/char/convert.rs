//! Табдили аломатҳо.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Табдил `u32` ба `char`.
///
/// Аҳамият диҳед, ки ҳама [`char`] ҳо [`u32`]-и эътибор доранд ва метавонанд ба якто партофта шаванд
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Аммо, баръакс дуруст нест: на ҳама [[u32`]-и эътибор доранд [`char`].
/// `from_u32()` `None`-ро бармегардонад, агар вуруд барои [`char`] арзиши мӯътабар набошад.
///
/// Барои версияи хатарноки ин функсия, ки ин чекҳоро нодида мегирад, ба [`from_u32_unchecked`] нигаред.
///
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Бозгашти `None` вақте ки вуруд як [`char`] мӯътабар нест:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32`-ро ба `char` табдил медиҳад, эътибор надода.
///
/// Аҳамият диҳед, ки ҳама [`char`] ҳо [`u32`]-и эътибор доранд ва метавонанд ба якто партофта шаванд
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Аммо, баръакс дуруст нест: на ҳама [[u32`]-и эътибор доранд [`char`].
/// `from_u32_unchecked()` инро нодида мегирад ва кӯр-кӯрона ба [`char`] меандозад ва эҳтимолан беэътиборро ба вуҷуд меорад.
///
///
/// # Safety
///
/// Ин вазифа хатарнок аст, зеро он метавонад арзишҳои нодурусти `char` созад.
///
/// Барои нусхаи бехатарии ин вазифа, ба функсияи [`from_u32`] нигаред.
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `i` арзиши дурусти char аст.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-ро ба [`u32`] табдил медиҳад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-ро ба [`u64`] табдил медиҳад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Чар ба арзиши нуқтаи рамз андохта мешавад ва сипас сифр то 64 бит дароз карда мешавад.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] нигаред
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-ро ба [`u128`] табдил медиҳад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Чар ба арзиши нуқтаи рамз андохта мешавад ва сипас ба 128 бит тамдид карда мешавад.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] нигаред
        c as u128
    }
}

/// Як байтро дар 0x00 ..=0xFF то `char`, ки нуқтаи рамзиаш ҳамон аҳамият дорад, бо U + 0000 ..=U + 00FF харита медиҳад.
///
/// Юникод тавре сохта шудааст, ки ин байтро бо рамзгузории аломате, ки IANA ISO-8859-1 меномад, ба таври муассир рамзкушоӣ мекунад.
/// Ин рамзгузорӣ бо ASCII мувофиқ аст.
///
/// Дар хотир доред, ки ин аз ISO/IEC 8859-1 ака фарқ мекунад
/// ISO 8859-1 (бо як дефиси камтар), ки баъзе "blanks", байтҳоро боқӣ мегузорад, ки ба ягон аломат дода нашудаанд.
/// ISO-8859-1 (яке аз IANA) онҳоро ба рамзҳои назоратии C0 ва C1 таъин мекунад.
///
/// Дар хотир доред, ки ин *инчунин* аз Windows-1252 aka фарқ дорад
/// саҳифаи коди 1252, ки суперсети ISO/IEC 8859-1 мебошад, ки баъзе (на ҳама!) холиро ба пунктуатсия ва аломатҳои гуногуни лотинӣ медиҳад.
///
/// Барои гумроҳ кардани чизҳои дигар, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` ва `windows-1252` ҳама тахаллусҳо барои суперзерсияи Windows-1252 мебошанд, ки бланкаҳои боқимондаро бо рамзҳои дахлдори C0 ва C1 пур мекунанд.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-ро ба [`char`] табдил медиҳад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Хатогие, ки ҳангоми таҳлили char баргардонида мешавад.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // БЕХАТАР: : тафтиш кард, ки ин арзиши юникоди қонунӣ аст
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Навъи хатогӣ ҳангоми баргардонидани u32 ба char барнагашт.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Рақамро дар радиуси додашуда ба `char` табдил медиҳад.
///
/// 'radix'-ро дар ин ҷо баъзан 'base' низ меноманд.
/// Радикси ду аз рақами дуӣ, радиуси даҳӣ, даҳӣ ва радиои шонздаҳии шонздаҳӣ ишора мекунад, то баъзе арзишҳои умумӣ диҳанд.
///
/// Радисҳои худсарона дастгирӣ карда мешаванд.
///
/// `from_digit()` агар `None` баргардад, агар вуруд як рақам дар радиуси додашуда набошад.
///
/// # Panics
///
/// Panics агар радиуси аз 36 калонтар дода шавад.
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Даҳсолаи 11 як рақам дар пойгоҳи 16 аст
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Бозгашти `None` вақте ки вуруд рақам нест:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Гузариш аз радиуси калон, ки боиси panic мегардад:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}