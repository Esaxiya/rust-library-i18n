// Татбиқи аслӣ аз rust-memchr гирифта шудааст.
// Ҳуқуқи муаллиф 2015 Эндрю Галлант, блюс ва Николас Кох

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Қатъкуниро истифода баред.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `true`-ро бармегардонад, агар `x` ягон байти сифр дошта бошад.
///
/// Аз *Масъалаҳои ҳисобӣ*, Ҷ. Арндт:
///
/// "Ғоя иборат аз он аст, ки аз ҳар як байт якеро коҳиш диҳед ва сипас байтҳоро ҷустуҷӯ кунед, ки қарз дар тамоми роҳи паҳнгашта то муҳимтарин паҳн шудааст
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Индекси аввалеро, ки ба байти `x` дар `text` мувофиқат мекунад, бармегардонад.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Роҳи зуд барои иловаро хурд
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Бо хондани ду калимаи `usize` дар як вақт арзиши ягонаи байтро скан кунед.
    //
    // `text`-ро дар се қисм тақсим кунед
    // - қисми ибтидоии ҳамоҳангнашуда, пеш аз калимаи аввал суроға дар матн мувофиқ карда шудааст
    // - бадан, дар як вақт 2 калимаро скан кунед
    // - қисми боқимондаи охир, <2 андозаи калима

    // то сарҳади мувофиқ ҷустуҷӯ кунед
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // бадани матнро ҷустуҷӯ кунед
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // БЕХАТАР: : предикати холӣ масофаи ҳадди аққал 2 * usize_bytes-ро кафолат медиҳад
        // байни офсет ва охири бурида.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // шикастан, агар байти мувофиқ мавҷуд бошад
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Пас аз нуқтае, ки ҳалқаи бадан қатъ шуд, байтро ёбед.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Индекси охирини ба байти `x` дар `text` мувофиқро бар мегардонад.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Бо хондани ду калимаи `usize` дар як вақт арзиши ягонаи байтро скан кунед.
    //
    // Split `text` дар се қисм:
    // - думи номуносиб, пас аз калимаи охирин суроға дар матн мувофиқат карда,
    // - бадан, ки дар як вақт бо 2 калима скан карда мешавад,
    // - байтҳои аввалини боқимонда, <2 андозаи калима.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Мо инро танҳо барои ба даст овардани дарозии префикс ва суффикс меномем.
        // Дар мобайн мо ҳамеша якбора ду қисмро коркард мекунем.
        // БЕХАТАР: : интиқоли `[u8]` ба `[usize]` бехатар аст, ба истиснои фарқиятҳои андозае, ки аз ҷониби `align_to` идора карда мешаванд.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Ҷасади матнро ҷустуҷӯ кунед, боварӣ ҳосил кунед, ки min_aligned_offset нагузарем.
    // офсет ҳамеша мувофиқат мекунад, аз ин рӯ танҳо озмоиши `>` кифоя аст ва аз болоравии эҳтимолӣ ҷилавгирӣ мекунад.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // БЕХАТАР: : ҷуброн аз len, suffix.len() сар мешавад, ба шарте ки аз он бузургтар бошад
        // min_aligned_offset (prefix.len()) масофаи боқимонда ҳадди аққал 2 * чук_ байт аст.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Агар байти мувофиқ мавҷуд бошад, шикастан.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Байтро пеш аз нуқтае, ки ҳалқаи бадан қатъ шудааст, ёбед.
    text[..offset].iter().rposition(|elt| *elt == x)
}