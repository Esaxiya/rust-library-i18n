// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Диапазони `[mid-left, mid+right)`-ро тавре мегардонад, ки элемент дар `mid` унсури аввал шавад.Баробари ин, элементҳои диапазони `left`-ро ба чап ё унсурҳои `right`-ро ба рост мегардонад.
///
/// # Safety
///
/// Миқдори муайяншуда бояд барои хондан ва навиштан эътибор дошта бошад.
///
/// # Algorithm
///
/// Алгоритми 1 барои арзишҳои хурди `left + right` ё барои `T` калон истифода мешавад.
/// Элементҳо ба мавқеъҳои ниҳоии худ аз `mid - left` сар карда, бо қадамҳои `right` бо модули `left + right` пеш мераванд, ба тавре ки танҳо як муваққатӣ лозим аст.
/// Дар ниҳоят, мо ба `mid - left` бармегардем.
/// Аммо, агар `gcd(left + right, right)` 1 набошад, қадамҳои дар боло буда унсурҳоро гузаронданд.
/// Барои намуна:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Хушбахтона, шумораи гузаронидашуда аз унсурҳои байни унсурҳои ниҳоӣ ҳамеша баробар аст, бинобар ин, мо метавонем танҳо мавқеи ибтидоии худро ҷуброн кунем ва даврҳои бештар гузаронем (шумораи умумии даврҳо `gcd(left + right, right)` value) мебошад).
///
/// Натиҷаи ниҳоӣ ин аст, ки ҳамаи унсурҳо як маротиба ва танҳо як маротиба ҷамъбаст карда мешаванд.
///
/// Алгоритми 2 истифода мешавад, агар `left + right` калон бошад, аммо `min(left, right)` он қадар хурд аст, ки ба буфераи стек мувофиқат кунад.
/// Элементҳои `min(left, right)` ба буфер нусхабардорӣ карда мешаванд, `memmove` ба дигарон татбиқ карда мешавад ва ашёҳои буферӣ дубора ба сӯрохи тарафи муқобили он ҷое, ки онҳо пайдо шудаанд, интиқол дода мешаванд.
///
/// Алгоритмҳое, ки метавонанд векторӣ шаванд, аз он вақте ки `left + right` ба андозаи кофӣ калон мешавад, амалӣ мешаванд.
/// Алгоритми 1-ро бо роҳи ҷобаҷокунӣ ва гузаронидани даврҳои зиёд якбора векторӣ кардан мумкин аст, аммо ба ҳисоби миёна то `left + right` хеле бузург давраҳо вуҷуд доранд ва бадтарин ҳолати даври ягона ҳамеша дар он ҷо аст.
/// Ба ҷои ин, алгоритми 3 ивазкунии такрории унсурҳои `min(left, right)`-ро истифода мебарад, то он даме ки мушкилоти гардиши хурд боқӣ мондааст.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// вақте ки `left < right` ивазкунӣ ба ҷои ҷои чап ба амал меояд.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. агар ин ҳолатҳо санҷида нашаванд, алгоритмҳои дар поён овардашуда метавонанд ноком шаванд
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Алгоритми 1 Микробишмаркҳо нишон медиҳанд, ки нишондиҳандаҳои миёнаи гузаришҳои тасодуфӣ то он даме ки тақрибан `left + right == 32` беҳтаранд, аммо бадтарин нишондиҳандаҳо ҳатто тақрибан 16 мешикананд.
            // 24 ҳамчун роҳи миёна интихоб карда шуд.
            // Агар андозаи `T` аз 4 `usize` калонтар бошад, ин алгоритм инчунин аз дигар алгоритмҳо бартарӣ дорад.
            //
            //
            let x = unsafe { mid.sub(left) };
            // оғози даври аввал
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` пеш аз даст бо роҳи ҳисобкунии `gcd(left + right, right)` пайдо кардан мумкин аст, аммо зудтар иҷро кардани як ҳалқа, ки gcd-ро ҳамчун таъсири тараф ҳисоб мекунад, пас қисми боқимондаро иҷро мекунад
            //
            //
            let mut gcd = right;
            // меъёрҳо нишон медиҳанд, ки иваз кардани муваққатӣ зудтар аст, ба ҷои он ки як маротиба муваққатан як маротиба хонед, нусхабардорӣ кунед ва пас дар охири он навиштед.
            // Ин эҳтимолан аз он сабаб ба амал омадааст, ки иваз ё муваққатии муваққатӣ ба ҷои идоракунии ду суроға танҳо як суроғаи хотираро дар ҳалқа истифода мебарад.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // ба ҷои зиёд кардани `i` ва сипас санҷидани он, ки он берун аз ҳудуд аст, мо месанҷем, ки оё `i` аз ҳудуди афзоиши оянда берун хоҳад рафт.
                // Ин ҳама печонидани нишондиҳандаҳо ё `usize`-ро пешгирӣ мекунад.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // охири даври аввал
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ин шарт бояд дар ин ҷо бошад, агар `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // порчаро бо даврҳои бештар ба анҷом расонед
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` навъи андозаи сифр нест, бинобар ин ба андозаи он тақсим кардан дуруст аст.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Алгоритми 2 `[T; 0]` дар ин ҷо барои он мувофиқат мекунад, ки он ба T мувофиқат мекунад
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Алгоритми 3 Як роҳи алтернативии мубодила мавҷуд аст, ки пайдо кардани свопи охирини ин алгоритмро дар бар мегирад ва иваз кардани ин часади охирин ба ҷои иваз кардани порчаҳои ҳамсоя, ба монанди ин алгоритм, амал мекунад, аммо ин роҳ ҳанӯз ҳам зудтар аст.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Алгоритми 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}