//! Ҷудокунии бурида
//!
//! Ин модул алгоритми ҷобаҷогузориро дар асоси киксорти шикастаи намунаи Орсон Петерс дар бар мегирад: <https://github.com/orlp/pdqsort>
//!
//!
//! Ҷобаҷогузории ноустувор бо libcore мувофиқ аст, зеро он ба фарқ аз татбиқи устувори ҷобаҷогузории мо хотира ҷудо намекунад.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ҳангоми партофтан, нусхабардорӣ аз `src` ба `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // БЕХАТАР: : Ин як синфи ёвар аст.
        //          Лутфан ба дурустии истифодаи он муроҷиат кунед.
        //          Яъне, бояд мутмаин бошад, ки `src` ва `dst` мувофиқи талаби `ptr::copy_nonoverlapping` намегузаранд.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Унсури аввалро ба тарафи рост то он даме ки дучор меояд, ки унсури калон ё баробарро иваз мекунад.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕХАТАР: : Амалиёти хатарноки дар поён овардашуда индексатсияро бидуни тафтиши ҳатмӣ (`get_unchecked` ва `get_unchecked_mut`) дар бар мегиранд
    // ва нусхабардории хотираи (`ptr::copy_nonoverlapping`).
    //
    // а.Индексатсия:
    //  1. Мо андозаи массивро ба>=2 санҷидем.
    //  2. Ҳама индексатсияҳое, ки мо анҷом медиҳем, ҳамеша дар байни {0 <= index < len} аст.
    //
    // б.Нусхабардории хотира
    //  1. Мо ишораҳоеро ба истинодҳо мегирем, ки эътибор доранд.
    //  2. Онҳо наметавонанд ба якдигар монанд бошанд, зеро мо нишондиҳандаҳоро барои фарқияти нишондиҳандаҳои буррро мегирем.
    //     Яъне, `i` ва `i-1`.
    //  3. Агар бурида дуруст мувофиқат карда шуда бошад, унсурҳо ба таври мувофиқ мувофиқат мекунанд.
    //     Масъулияти зангзананда аст, ки боварӣ ҳосил кунед, ки бурида дуруст мувофиқ карда шудааст.
    //
    // Барои тафсилоти бештар ба шарҳҳои зер нигаред.
    unsafe {
        // Агар ду унсури аввал ғайримуқаррарӣ бошанд ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Унсури аввалро ба тағирёбандаи стек ҷудо кунед.
            // Агар амалиёти зерини муқоисаи panics, `hole` афтида, ба таври худкор унсурро ба бурида нависед.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Унсури `i`-ро як ҷой ба чап ҳаракат кунед ва сӯрохиро ба тарафи рост иваз кунед.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` афтод ва ба ин васила `tmp`-ро ба сӯрохи боқимондаи `v` нусхабардорӣ мекунад.
        }
    }
}

/// Элементи охиринро ба тарафи чап мегузаронед, то он вақте ки он бо як унсури хурд ё баробар дучор ояд.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // БЕХАТАР: : Амалиёти хатарноки дар поён овардашуда индексатсияро бидуни тафтиши ҳатмӣ (`get_unchecked` ва `get_unchecked_mut`) дар бар мегиранд
    // ва нусхабардории хотираи (`ptr::copy_nonoverlapping`).
    //
    // а.Индексатсия:
    //  1. Мо андозаи массивро ба>=2 санҷидем.
    //  2. Ҳама индексатсияҳое, ки мо анҷом медиҳем, ҳамеша дар байни `0 <= index < len-1` аст.
    //
    // б.Нусхабардории хотира
    //  1. Мо ишораҳоеро ба истинодҳо мегирем, ки эътибор доранд.
    //  2. Онҳо наметавонанд ба якдигар монанд бошанд, зеро мо нишондиҳандаҳоро барои фарқияти нишондиҳандаҳои буррро мегирем.
    //     Яъне, `i` ва `i+1`.
    //  3. Агар бурида дуруст мувофиқат карда шуда бошад, унсурҳо ба таври мувофиқ мувофиқат мекунанд.
    //     Масъулияти зангзананда аст, ки боварӣ ҳосил кунед, ки бурида дуруст мувофиқ карда шудааст.
    //
    // Барои тафсилоти бештар ба шарҳҳои зер нигаред.
    unsafe {
        // Агар ду унсури охирин аз кор баромада бошанд ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Элементи охиринро ба тағирёбандаи стек ҷудо кунед.
            // Агар амалиёти зерини муқоисаи panics, `hole` афтида, ба таври худкор унсурро ба бурида нависед.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Унсури `i`-ро як ҷой ба тарафи рост ҳаракат кунед ва сӯрохиро ба чап гузаронед.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` афтод ва ба ин васила `tmp`-ро ба сӯрохи боқимондаи `v` нусхабардорӣ мекунад.
        }
    }
}

/// Як қисмро бо тағир додани якчанд унсури фармоишӣ дар атрофи қисман ҷудо мекунад.
///
/// `true`-ро бармегардонад, агар бурида дар охири мураттаб карда шавад.Ин функсия *O*(*n*) бадтарин аст.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Шумораи максималии ҷуфтҳои берун аз тартиб, ки иваз мешаванд.
    const MAX_STEPS: usize = 5;
    // Агар бурида аз ин кӯтоҳтар бошад, ягон элементро иваз накунед.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // БЕХАТАР: : Мо аллакай ба таври возеҳ тафтиши ҳатмиро бо `i < len` анҷом додем.
        // Ҳама индексатсияи минбаъдаи мо танҳо дар доираи `0 <= index < len` мебошад
        unsafe {
            // Ҷуфти навбатии унсурҳои берун аз тартибро пайдо кунед.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Мо тамом кардем?
        if i == len {
            return true;
        }

        // Унсурҳоро ба массиви кӯтоҳ иваз накунед, ки арзиши иҷрои онро дорад.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ҷуфти ёфташударо иваз кунед.Ин онҳоро ба тартиби дуруст мегузорад.
        v.swap(i - 1, i);

        // Элементи хурдтарро ба тарафи чап гузаронед.
        shift_tail(&mut v[..i], is_less);
        // Элементи калонтарро ба тарафи рост иваз кунед.
        shift_head(&mut v[i..], is_less);
    }

    // Дар шумораи маҳдуди марҳилаҳо тақсим кардани бураро муяссар нашуд.
    false
}

/// Буридаеро бо истифода аз навъҳои дохилкунӣ ҷудо мекунад, ки *O*(*n*^ 2) бадтарин ҳолат аст.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v`-ро бо истифода аз heapsort ҷудо мекунад, ки кафолати *O*(*n*\*log(* n*))-ҳолати бадтаринро дорад.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ин тӯдаи бинарӣ ба тағирёбанда `parent >= child` эҳтиром мегузорад.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Фарзандони `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Фарзанди калонтарро интихоб кунед.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Агар инвариант дар `node` нигоҳ дошта шавад, қатъ кунед.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node`-ро бо кӯдаки калонтар иваз кунед, як зина поён ҳаракат кунед ва ҷумбониданро давом диҳед.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Тӯфонро дар вақти хаттӣ созед.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Попи унсурҳои максималӣ аз теппа.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` ба унсурҳои хурдтар аз `pivot` тақсим карда мешавад ва пас аз он унсурҳои аз `pivot` бузург ё баробар.
///
///
/// Шумораи элементҳои хурдтар аз `pivot`-ро бармегардонад.
///
/// Ҷудокунӣ бо мақсади ба ҳадди ақал расонидани хароҷоти амалиёти филиал ба блок ба блок иҷро карда мешавад.
/// Ин ғоя дар коғази [BlockQuicksort][pdf] оварда шудааст.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Шумораи элементҳо дар блоки маъмулӣ.
    const BLOCK: usize = 128;

    // Алгоритми тақсимкунӣ қадамҳои зеринро то ба итмом расонидан такрор мекунад:
    //
    // 1. Блокро аз тарафи чап пайгирӣ кунед, то унсурҳои аз гардиш бузургтар ё баробар ба он муайян карда шавад.
    // 2. Барои муайян кардани унсурҳои аз гардиш хурдтар аз тарафи рост блокро пайгирӣ кунед.
    // 3. Унсурҳои муайяншударо дар байни чап ва рост мубодила кунед.
    //
    // Мо тағирёбандаҳои зеринро барои як блок унсурҳо нигоҳ медорем:
    //
    // 1. `block` - Шумораи элементҳо дар блок.
    // 2. `start` - Нишондиҳандаро ба массиви `offsets` оғоз кунед.
    // 3. `end` - Охирин нишоннамо ба массиви `offsets`.
    // 4. `офсетҳо, Нишондиҳандаҳои унсурҳои корношоям дар дохили блок.

    // Блоки ҷорӣ дар тарафи чап (аз `l` то `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Блоки ҷорӣ дар тарафи рост (аз `r.sub(block_r)` to `r`).
    // БЕХАТАР: : Ҳуҷҷатҳои .add() махсусан қайд мекунанд, ки `vec.as_ptr().add(vec.len())` ҳамеша бехатар аст '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Вақте ки мо VLA мегирем, кӯшиш кунед, ки як массиви дарозии `min(v.len(), 2 * BLOCK) "созед
    // аз ду массиви андозаи собит дарозии `BLOCK`.VLA-ҳо метавонанд аз ҳифзи кэш бештар самаранок бошанд.

    // Шумораи элементҳоро байни нишондиҳандаҳои `l` (inclusive) ва `r` (exclusive) бармегардонад.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Вақте ки `l` ва `r` хеле наздик мешаванд, мо бо тақсимоти блок ба блок анҷом медиҳем.
        // Сипас, мо баъзе корҳои таъмириро анҷом медиҳем, то унсурҳои боқимондаро дар байни онҳо тақсим кунем.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Шумораи элементҳои боқимонда (то ҳол дар муқоиса бо гардиш).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Андозаҳои блокро танзим кунед, то ки блокҳои чап ва рост ба ҳам наоянд, аммо барои фарогирии тамоми холигии боқимонда комилан мувофиқат кунед.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Элементҳои `block_l`-ро аз тарафи чап пайгирӣ кунед.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // БЕХАТАР: : Амалиёти бехатарӣ дар зер истифодаи `offset`-ро дар бар мегирад.
                //         Мувофиқи шартҳое, ки вазифа талаб мекунад, мо онҳоро қонеъ мекунем, зеро:
                //         1. `offsets_l` стек ҷудо карда шудааст ва ҳамин тавр объекти ҷудогонаи ҷудогона ҳисобида мешавад.
                //         2. Функсияи `is_less` `bool` бар мегардонад.
                //            Рехтани `bool` ҳеҷ гоҳ `isize`-ро пур намекунад.
                //         3. Мо кафолат додаем, ки `block_l` `<= BLOCK` хоҳад буд.
                //            Ғайр аз он, `end_l` дар аввал ба нишоннамои оғози `offsets_` гузошта шуда буд, ки дар стек эълон карда шуд.
                //            Ҳамин тариқ, мо медонем, ки ҳатто дар ҳолати бадтарин (ҳамаи даъватномаҳои `is_less` бардурӯғ бармегарданд) мо танҳо ҳадди аксар 1 байт аз охир мегузарем.
                //        Амалиёти дигари бехатарӣ дар ин ҷо фарогирии `elem` аст.
                //        Бо вуҷуди ин, `elem` ибтидо нишоннамои шурӯъ ба бурида буд, ки ҳамеша эътибор дорад.
                unsafe {
                    // Муқоисаи филиал.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Элементҳои `block_r`-ро аз тарафи рост пайгирӣ кунед.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // БЕХАТАР: : Амалиёти бехатарӣ дар зер истифодаи `offset`-ро дар бар мегирад.
                //         Мувофиқи шартҳое, ки вазифа талаб мекунад, мо онҳоро қонеъ мекунем, зеро:
                //         1. `offsets_r` стек ҷудо карда шудааст ва ҳамин тавр объекти ҷудогонаи ҷудогона ҳисобида мешавад.
                //         2. Функсияи `is_less` `bool` бар мегардонад.
                //            Рехтани `bool` ҳеҷ гоҳ `isize`-ро пур намекунад.
                //         3. Мо кафолат додаем, ки `block_r` `<= BLOCK` хоҳад буд.
                //            Ғайр аз он, `end_r` дар аввал ба нишоннамои оғози `offsets_` гузошта шуда буд, ки дар стек эълон карда шуд.
                //            Ҳамин тариқ, мо медонем, ки ҳатто дар ҳолати бадтарин (ҳамаи даъватномаҳои `is_less` ҳақиқӣ бармегарданд) мо танҳо ҳадди аксар 1 байт аз охир мегузарем.
                //        Амалиёти дигари бехатарӣ дар ин ҷо фарогирии `elem` аст.
                //        Аммо, `elem` дар аввал `1 *sizeof(T)` аз охир гузашта буд ва мо онро пеш аз дастрасӣ ба `1* sizeof(T)` кам мекардем.
                //        Ғайр аз он, `block_r` изҳор дошт, ки камтар аз `BLOCK` ва `elem` аз ин рӯ, ҳадди аксар ба оғози бурида ишора мекунанд.
                unsafe {
                    // Муқоисаи филиал.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Шумораи унсурҳои ғайримуқаррарӣ барои иваз кардани байни чап ва рост.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Ба ҷои иваз кардани як ҷуфт дар айни замон, иҷрои як ҷойивазкунии даврӣ самарабахштар аст.
            // Ин ба мубодила комилан баробар нест, аммо бо истифода аз амалиётҳои хотираи камтар натиҷаи шабеҳ ба даст меорад.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Ҳама унсурҳои аз кор баромада дар блоки чап кӯчонида шуданд.Ба блоки оянда гузаред.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Ҳама унсурҳои аз кор баромадаро дар блоки рост интиқол доданд.Ба блоки қаблӣ гузаред.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Ҳоло танҳо ҳадди аққал як блок боқӣ мондааст (ё чап ё рост) бо унсурҳои ғайримуқаррарӣ, ки бояд интиқол дода шаванд.
    // Чунин унсурҳои боқимондаро танҳо дар дохили блоки худ ба охир интиқол додан мумкин аст.
    //

    if start_l < end_l {
        // Блоки чап боқӣ мемонад.
        // Унсурҳои боқимондаи аз фармоиш баромада ба тарафи рост ҳаракат кунед.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Блоки рост боқӣ мемонад.
        // Унсурҳои боқимондаи ғайримуқаррарии онро ба тарафи чап интиқол диҳед.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ҳеҷ чизи дигаре нест, мо тамом кардем.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` ба унсурҳои хурдтар аз `v[pivot]` тақсим карда мешавад ва пас аз он унсурҳои аз `v[pivot]` бузург ё баробар.
///
///
/// Корти зеринро бармегардонад:
///
/// 1. Шумораи унсурҳои хурдтар аз `v[pivot]`.
/// 2. Дуруст аст, агар `v` аллакай тақсим карда шуда бошад.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Пивотро дар оғози бурида ҷойгир кунед.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Барои самаранокӣ гардишро ба тағирёбандаи стек ҷудо кунед.
        // Агар амалиёти зерини муқоисавӣ panics бошад, гардиш ба таври худкор ба бурида навишта мешавад.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Ҷуфти якуми унсурҳои ғайримуқаррариро ёбед.
        let mut l = 0;
        let mut r = v.len();

        // БЕХАТАР: : Бехатарӣ дар зер индексатсияи массивро дар бар мегирад.
        // Барои яке аз аввал: Мо аллакай бо `l < r` дар ин ҷо ҳудудҳоро месанҷем.
        // Барои дуввум: Мо дар аввал `l == 0` ва `r == v.len()` дорем ва мо `l < r`-ро дар ҳар як амалиёти индексатсия месанҷидем.
        //                     Аз ин ҷо мо медонем, ки `r` бояд ҳадди аққал `r == l` бошад, ки аз аввал эътибор дорад.
        unsafe {
            // Унсури аввалро аз гардиш бузургтар ё ба он баробар ёбед.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Унсури охирини хурдтарро пайдо кунед.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` аз доираи амал берун меравад ва пивотро (ки тағирёбандаи стака аст) дубора ба буридаи дар ибтидо бударо менависад.
        // Ин қадам барои таъмини бехатарӣ муҳим аст!
        //
    };

    // Гардишро дар байни ду қисм ҷойгир кунед.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v` ба унсурҳои ба `v[pivot]` баробар тақсимшуда ва пас аз он унсурҳои аз `v[pivot]` бузургтар.
///
/// Шумораи элементҳои ба гардиш баробарро бар мегардонад.
/// Тахмин меравад, ки `v` дорои унсурҳои хурд аз гардиш нест.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Пивотро дар оғози бурида ҷойгир кунед.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Барои самаранокӣ гардишро ба тағирёбандаи стек ҷудо кунед.
    // Агар амалиёти зерини муқоисавӣ panics бошад, гардиш ба таври худкор ба бурида навишта мешавад.
    // БЕХАТАР: : Нишондиҳанда дар ин ҷо эътибор дорад, зеро он аз истинод ба як бурида гирифта мешавад.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Ҳоло пораро тақсим кунед.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // БЕХАТАР: : Бехатарӣ дар зер индексатсияи массивро дар бар мегирад.
        // Барои яке аз аввал: Мо аллакай бо `l < r` дар ин ҷо ҳудудҳоро месанҷем.
        // Барои дуввум: Мо дар аввал `l == 0` ва `r == v.len()` дорем ва мо `l < r`-ро дар ҳар як амалиёти индексатсия месанҷидем.
        //                     Аз ин ҷо мо медонем, ки `r` бояд ҳадди аққал `r == l` бошад, ки аз аввал эътибор дорад.
        unsafe {
            // Аввалин унсури бузургтар аз гардишро ёбед.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Унсури охирини ба гардиш баробарро ёбед.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Мо тамом кардем?
            if l >= r {
                break;
            }

            // Ҷуфти ёфтшудаи унсурҳои фармоиширо иваз кунед.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Мо унсурҳои `l`-ро ба гардиш баробар пайдо кардем.Барои ҳисоб кардани худи гардиш 1 илова кунед.
    l + 1

    // `_pivot_guard` аз доираи амал берун меравад ва пивотро (ки тағирёбандаи стака аст) дубора ба буридаи дар ибтидо бударо менависад.
    // Ин қадам барои таъмини бехатарӣ муҳим аст!
}

/// Бо мақсади шикастани намунаҳое, ки метавонанд тақсимоти номутаносибро дар квотсор ба вуҷуд оранд, баъзе унсурҳоро пароканда мекунанд.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Генератори рақами псевдорандӣ аз коғази "Xorshift RNGs" аз ҷониби Ҷорҷ Марсаглия.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Рақамҳои тасодуфиро ин рақамро гиред.
        // Рақам ба `usize` мувофиқат мекунад, зеро `len` аз `isize::MAX` зиёд нест.
        let modulus = len.next_power_of_two();

        // Баъзе номзадҳои муҳим дар наздикии ин индекс хоҳанд буд.Биёед онҳоро тасодуфӣ кунем.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Модули `len`-и рақами тасодуфиро тавлид кунед.
            // Аммо, барои пешгирӣ кардани амалиётҳои гаронарзиш мо аввал онро модули қувваи ду мегирем ва пас аз он то ба диапазони `[0, len - 1]` мувофиқат накунем, `len` кам мешавем.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` камтар аз `2 * len` кафолат дода мешавад.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Гардишро дар `v` интихоб мекунад ва индекс ва `true`-ро бармегардонад, агар бурида эҳтимолан мураттаб шуда бошад.
///
/// Элементҳо дар `v` метавонанд дар раванд аз нав танзим карда шаванд.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Дарозии ҳадди аққал барои интихоби усули миёнаравӣ.
    // Иловаро кӯтоҳтар усули оддии медиан-се-ро истифода мебаранд.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Шумораи максималии свопҳо, ки дар ин вазифа иҷро карда мешаванд.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Се нишондиҳандае, ки дар наздикии он мо як гардишро интихоб мекунем.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Шумораи умумии свопҳоеро, ки мо дар вақти ҷобаҷогузории нишондиҳандаҳо иҷро карданием, ҳисоб мекунад.
    let mut swaps = 0;

    if len >= 8 {
        // Индексҳоро иваз мекунад, то ки `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Индексҳоро иваз мекунад, то ки `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Миёнаи `v[a - 1], v[a], v[a + 1]`-ро ёфта, индексро ба `a` нигоҳ медорад.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Дар маҳаллаҳои `a`, `b` ва `c` миёнаравҳоро ёбед.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Дар байни `a`, `b` ва `c` медианаро ёбед.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Шумораи максималии свопҳо иҷро карда шуд.
        // Эҳтимол дорад, ки бурида кам мешавад ё аксар кам мешавад, бинобар ин баргардонидан эҳтимолан ба зудтар ҷудо шудани он кӯмак хоҳад кард.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v`-ро рекурсивӣ навъ мекунад.
///
/// Агар буридаи пешгузашта дар массиви аслӣ бошад, он ҳамчун `pred` муайян карда мешавад.
///
/// `limit` ин миқдори ҷудокунандаҳои номутаносиби пеш аз гузаштан ба `heapsort` мебошад.
/// Агар сифр бошад, ин функсия фавран ба партовгоҳ мегузарад.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Лутфҳо то ин дарозӣ бо истифодаи навъҳои дохилкунӣ мураттаб карда мешаванд.
    const MAX_INSERTION: usize = 20;

    // Дуруст аст, агар тақсимоти охирин оқилона мутавозин бошанд.
    let mut was_balanced = true;
    // Дуруст аст, агар тақсимоти охирин унсурҳоро омехта накунад (бурида аллакай тақсим карда шуда буд).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Лутфаҳои хеле кӯтоҳ бо истифода аз навъҳои дохилкунӣ мураттаб мешаванд.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Агар аз ҳад зиёди интихоби гардиши гардиш гузаронида шуда бошад, пас ба кафолати бозгашт афтед, то `O(n * log(n))` бадтарин ҳолатро кафолат диҳед.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Агар тақсимоти охирин мувозинат надошта бошанд, кӯшиш кунед, ки бо буридани баъзе унсурҳо дар бурида намунаҳоро дар бурида вайрон кунед.
        // Умедворем, ки ин дафъа як гардиши беҳтарро интихоб хоҳем кард.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Гардишро интихоб кунед ва тахмин кунед, ки оё ин порча аллакай мураттаб шудааст.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Агар тақсимоти охирин ба қадри кофӣ мувозинат шуда бошад ва унсурҳоро ба ҳам омезиш надиҳад ва агар интихоби пивот пешгӯӣ карда шавад, эҳтимолан бурида аллакай мураттаб шудааст ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Кӯшиш кунед, ки якчанд унсурҳои корношоямро муайян кунед ва онҳоро ба мавқеъҳои дуруст иваз кунед.
            // Агар бурида тамоман мураттаб карда шавад, мо тамом кардем.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Агар гардиши интихобшуда ба пешгузашта баробар бошад, пас ин хурдтарин унсури бурриш аст.
        // Буришро ба унсурҳои баробар ва элементҳои аз гардиш калон тақсим кунед.
        // Ин ҳолат одатан вақте зада мешавад, ки бурида бисёр унсурҳои такрорӣ дошта бошад.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ҷобаҷогузории унсурҳои аз гардиш бузургтарро идома диҳед.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Буридаи онро тақсим кунед.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Буридаи онро ба `left`, `pivot` ва `right` тақсим кунед.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Ҷониби кӯтоҳтар танҳо бо мақсади кам кардани шумораи умумии зангҳои рекурсивӣ ва камтар истеъмол кардани ҷойҳои стек баргардед.
        // Пас танҳо бо паҳлӯи дарозтар идома диҳед (ин ба рекурсияи дум монанд аст).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v`-ро бо истифода аз квиксори шикастхӯрдаи намуна, ки *O*(*n*\*log(* n*)) бадтарин аст, ҷудо мекунад.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ҷобаҷогузорӣ дар намудҳои андозаи сифр ягон рафтори пурмазмун надорад.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Шумораи қисмҳои номутаносибро бо `floor(log2(len)) + 1` маҳдуд кунед.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Барои иловаро то ин дарозӣ ба осонӣ ҷудо кардани онҳо зудтар аст.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Гардишро интихоб кунед
        let (pivot, _) = choose_pivot(v, is_less);

        // Агар гардиши интихобшуда ба пешгузашта баробар бошад, пас ин хурдтарин унсури бурриш аст.
        // Буришро ба унсурҳои баробар ва элементҳои аз гардиш калон тақсим кунед.
        // Ин ҳолат одатан вақте зада мешавад, ки бурида бисёр унсурҳои такрорӣ дошта бошад.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Агар мо индекси худро гузашта бошем, пас мо хуб ҳастем.
                if mid > index {
                    return;
                }

                // Дар акси ҳол, ҷобаҷогузории унсурҳои бузургтар аз гардишро идома диҳед.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Буридаи онро ба `left`, `pivot` ва `right` тақсим кунед.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Агар mid==index бошад, пас мо анҷом додем, зеро partition() кафолат дод, ки ҳамаи унсурҳо пас аз миёна аз миёна калонтар ё ба он баробаранд.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Ҷобаҷогузорӣ дар намудҳои андозаи сифр ягон рафтори пурмазмун надорад.Ҳеҷ кор накунед.
    } else if index == v.len() - 1 {
        // Макс элементро ёбед ва онро дар ҳолати охирини массив ҷойгир кунед.
        // Мо дар ин ҷо истифодаи `unwrap()` озодем, зеро мо медонем, ки v бояд холӣ набошад.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min элементро ёбед ва онро дар ҳолати якуми массив ҷойгир кунед.
        // Мо дар ин ҷо истифодаи `unwrap()` озодем, зеро мо медонем, ки v бояд холӣ набошад.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}