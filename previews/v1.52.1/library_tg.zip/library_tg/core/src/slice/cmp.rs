//! Муқоисаи traits барои `[T]`.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// Татбиқи зангҳо бо memcmp таъмин карда шудааст.
    ///
    /// Маълумотро ҳамчун u8 тафсир мекунад.
    ///
    /// 0 барои баробар, <0 барои камтар ва> 0 барои калонтар бармегардад.
    ///
    // FIXME(#32610): Навъи бозгашт бояд c_int бошад
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// Муқоисаи vectors [lexicographically](Ord#lexicographical-comparison)-ро татбиқ мекунад.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// Муқоисаи vectors [lexicographically](Ord#lexicographical-comparison)-ро татбиқ мекунад.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// миёнаравии trait барои ихтисоси қисмҳои PartialEq
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// Баробарии бурриши умумӣ
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// Вақте ки намудҳо имкон медиҳанд, барои баробарии байтӣ memcmp-ро истифода баред
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // БЕХАТАР: : `self` ва `other` истинодҳо мебошанд ва аз ин рӯ, эътибор доранд.
        // Ду иловаро тафтиш карданд, ки андозаи онҳо дар боло якхела аст.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// мобайнии trait барои ихтисоси қисмҳои PartialOrd
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // Бурида ба диапазони такрори ҳалқа имкон диҳед, ки чеки ҳатмӣ дар компилятор фароҳам оварда шавад
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// Ин маънои онро дорад, ки мо мехоҳем онро дошта бошем.Мутаассифона, он садо нест.
// `partial_ord_slice.rs` нигаред.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// мобайнии trait барои ихтисоси ордҳои буридаи
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // Бурида ба диапазони такрори ҳалқа имкон диҳед, ки чеки ҳатмӣ дар компилятор фароҳам оварда шавад
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp пайдарпайии байтҳои беимзоро аз нигоҳи луғатографӣ муқоиса мекунад.
// ин ба фармоише, ки мо барои [u8] мехоҳем, мувофиқат мекунад, аммо ҳеҷ каси дигар (ҳатто [i8]).
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // БЕХАТАР: : `left` ва `right` истинодҳо мебошанд ва аз ин рӯ, эътибор доранд.
            // Мо ҳадди аққали ҳарду дарозиро истифода мебарем, ки кафолат медиҳанд, ки ҳарду минтақа барои хондан дар ин фосила эътибор доранд.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// Хак барои иҷозат додани тахассус дар `Eq`, гарчанде ки `Eq` усули худро дорад.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait барои намудҳое татбиқ карда мешавад, ки бо истифодаи намояндагии байтвисаи онҳо барои баробарӣ муқоиса карда мешаванд
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // БЕХАТАР: : `i8` ва `u8` дорои ҳамон тарҳбандии хотира мебошанд, аз ин рӯ `x.as_ptr()` меандохтанд
        // зеро `*const u8` бехатар аст.
        // `x.as_ptr()` аз истинод сарчашма мегирад ва аз ин рӯ барои мутолиа барои дарозии буридаи `x.len()`, ки аз `isize::MAX` зиёдтар буда наметавонад, эътибор дорад.
        // Буридаи баргашта ҳеҷ гоҳ мутатсия намешавад.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}