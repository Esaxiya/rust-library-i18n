//! Амалиёт дар ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Санҷед, ки оё ҳамаи байтҳои ин бурр дар ҳудуди ASCII мебошанд.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Тафтиш мекунад, ки ду буридаи мувофиқати ҳарфҳои ASCII мебошанд.
    ///
    /// Ҳамон тавре ки `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, аммо бидуни тақсим ва нусхабардории муваққатӣ.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ин бурришро бо ҳарфҳои калони ASCII дар ҷои худ табдил медиҳад.
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави калон бе тағир додани арзиши мавҷуда, [`to_ascii_uppercase`]-ро истифода баред.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ин бурришро бо ҳарфи хурди ASCII дар ҷои худ иваз мекунад.
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои баргардонидани арзиши нави хурд бидуни тағир додани арзиши мавҷуда, [`to_ascii_lowercase`]-ро истифода баред.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Агар ягон байт дар калимаи `v` nonascii (>=128) бошад, `true`-ро бармегардонад.
/// Snarfed аз `../str/mod.rs`, ки барои тасдиқи utf8 чизе монанд мекунад.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Озмоиши оптимизатсияшудаи ASCII, ки ба ҷои амалиётҳои байтӣ дар як вақт (ҳангоми имконпазир) амалҳои истифодаи ҳар лаҳза истифода хоҳад шуд.
///
/// Алгоритме, ки мо дар ин ҷо истифода мебарем, хеле содда аст.Агар `s` хеле кӯтоҳ бошад, мо танҳо ҳар байтро месанҷем ва бо он анҷом медиҳем.Дар акси ҳол:
///
/// - Калимаи аввалро бо бори номуносиб хонед.
/// - Нишонро нишон диҳед, калимаҳои минбаъдаро то бори охир бо борҳои мувофиқ хонед.
/// - `usize` охиринро аз `s` бо бори номуносиб хонед.
///
/// Агар ягонтои ин борҳо чизе истеҳсол кунад, ки барои он `contains_nonascii` (above) ҳақиқӣ баргардад, пас мо медонем, ки ҷавоб дурӯғ аст.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Агар мо аз татбиқи калима дар як вақт чизе ба даст наорем, ба ҳалқаи скалярӣ баргардед.
    //
    // Мо инчунин ин корро барои меъморӣ мекунем, ки дар он `size_of::<usize>()` барои `usize` ҳамоҳангии кофӣ нест, зеро ин як ҳолати аҷибест edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Мо ҳамеша калимаи аввалро бедараҷ мехонем, ки маънои `align_offset` аст
    // 0, мо ҳамон қиматро барои хониши мувофиқшуда дубора мехонем.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // БЕХАТАР: : Мо `len < USIZE_SIZE`-ро дар боло тасдиқ мекунем.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Мо инро дар боло, ба таври ғайримустақим, тафтиш кардем.
    // Дар хотир доред, ки `offset_to_aligned` ё `align_offset` ё `USIZE_SIZE` аст, ҳардуи онҳо ба таври возеҳ дар боло санҷида шудаанд.
    //
    debug_assert!(offset_to_aligned <= len);

    // БЕХАТАР: : word_ptr ин usize ptr (дуруст мутобиқшуда) мебошад, ки мо онро барои хондан истифода мебарем
    // порчаи миёнаи бурида.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` индекси байтии `word_ptr` мебошад, ки барои санҷишҳои охири ҳалқа истифода мешавад.
    let mut byte_pos = offset_to_aligned;

    // Paranoia санҷишро дар бораи ҳамоҳангсозӣ мегузаронад, зеро мо наздики як қатор бори номуносибро анҷом медиҳем.
    // Дар амал, ин набояд ба `align_offset` хато пешгирӣ кунад.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Калимаҳои минбаъдаро то калимаи ҳамоҳангшудаи охир хонед, ба истиснои калимаи ҳамоҳангшудаи худ, ки баъдтар дар санҷиши дум иҷро карда мешавад, то боварӣ ҳосил кунед, ки дум ҳамеша ҳадди аксар як `usize` ба branch `byte_pos == len` иловагӣ бошад.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Санҷиши солимии он, ки хондан дар ҳудуд аст
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ва ин тахминҳои мо дар бораи `byte_pos` амал мекунанд.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // БЕХАТАР We: Мо медонем, ки `word_ptr` дуруст мувофиқа карда шудааст (бинобар ин
        // `align_offset`), ва мо медонем, ки байни `word_ptr` ва охири байтҳои кофӣ дорем
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // БЕХАТАР: : Мо медонем, ки `byte_pos <= len - USIZE_SIZE`, ки маънои онро дорад
        // пас аз ин `add`, `word_ptr` ҳадди аксар дар охир хоҳад буд.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Тафтиши солимӣ барои таъмини он ки воқеан танҳо як `usize` боқӣ мондааст.
    // Ин бояд бо шарти ҳалқаи мо кафолат дода шавад.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // БЕХАТАР: : Ин ба `len >= USIZE_SIZE` такя мекунад, ки мо онро дар оғоз тафтиш мекунем.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}