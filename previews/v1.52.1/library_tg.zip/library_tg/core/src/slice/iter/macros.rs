//! Макросҳое, ки такрори бурр истифода мебаранд.

// Inline is_empty ва len фарқи азимеро ба амал меорад
macro_rules! is_empty {
    // Роҳе, ки мо дарозии як итератори ZST-ро рамзгузорӣ мекунем, ин ҳам барои ZST ва ҳам ғайри ZST кор мекунад.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Барои халос шудан аз баъзе чекҳои ҳудуд (ниг. `position`), мо дарозиро ба тариқи то андозае ғайричашмдошт ҳисоб мекунем.
// (Бо "codegen/slice-position-bounds-check" санҷида шудааст.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // мо баъзан дар дохили як блок хатарнок истифода бурда мешавад

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ин _cannot_ `unchecked_sub`-ро истифода мебарад, зеро мо ба бастабандӣ вобастаем, то дарозии такроркунандагони буридаи дарозии ZST-ро нишон диҳем.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Мо медонем, ки `start <= end`, аз ин рӯ метавонад беҳтар аз `offset_from` кор кунад, ки ба имзо расиданаш лозим аст.
            // Бо гузоштани парчамҳои мувофиқ дар ин ҷо мо метавонем ба LLVM бигӯем, ки ин ба бартараф кардани чекҳои ҳудуд кӯмак мекунад.
            // БЕХАТАР: : Аз рӯи намуди тағирёбанда, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Инчунин ба LLVM гуфтан, ки нишондиҳандаҳо аз рӯи зарби дақиқи андозаи нав ҷудо шудаанд, он метавонад `len() == 0` то `start == end` ба ҷои `(end - start) < size` оптимизатсия кунад.
            //
            // БЕХАТАР: : Аз рӯи намуди тағирёбанда, нишондиҳандаҳо ба тавре мувофиқат мекунанд
            //         масофаи байни онҳо бояд зарби андозаи Pointee бошад
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Таърифи муштараки такрори `Iter` ва `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Элементи аввалро бармегардонад ва оғози итераторро ба пеш 1 мегузаронад.
        // Корро дар муқоиса бо функсияи саркашӣ хеле беҳтар мекунад.
        // Итератор набояд холӣ бошад.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Элементи охиринро бармегардонад ва охири такрори онро ба 1 ба ақиб мегардонад.
        // Корро дар муқоиса бо функсияи саркашӣ хеле беҳтар мекунад.
        // Итератор набояд холӣ бошад.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Вақте ки T як ZST аст, такроркунандаро коҳиш медиҳад, то охири итераторро ба қафо `n` пас гардонад.
        // `n` набояд аз `self.len()` зиёд бошад.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Функсияи ёвар барои эҷоди як бурида аз iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // БЕХАТАР: : iterator аз буридаи бо нишоннамо сохта шудааст
                // `self.ptr` ва дарозии `len!(self)`.
                // Ин кафолат медиҳад, ки ҳамаи заминаҳо барои `from_raw_parts` иҷро мешаванд.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Функсияи ёрирасон барои ҳаракат додани оғози итератор тавассути элементҳои `offset`, баргардонидани оғози кӯҳна.
            //
            // Бехатарӣ, зеро ҷуброн набояд аз `self.len()` зиёд бошад.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // БЕХАТАР: : даъваткунанда кафолат медиҳад, ки `offset` аз `self.len()` зиёд нест,
                    // пас ин нишоннамои нав дар дохили `self` ҷойгир аст ва аз ин рӯ, беэътибор дониста мешавад.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Функсияи ёрирасон барои ҳаракат кардани охири итератор ба элементҳои `offset` ба қафо баргашта, охири навро бармегардонад.
            //
            // Бехатарӣ, зеро ҷуброн набояд аз `self.len()` зиёд бошад.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // БЕХАТАР: : даъваткунанда кафолат медиҳад, ки `offset` аз `self.len()` зиёд нест,
                    // ки кафолат дода мешавад, ки `isize` пур нашавад.
                    // Инчунин, нишоннамои натиҷа дар ҳудуди `slice` қарор дорад, ки талаботҳои дигари `offset`-ро иҷро мекунад.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // метавонист бо иловаро амалӣ карда шавад, аммо ин аз санҷиши ҳудуд халос мешавад

                // БЕХАТАР: : Зангҳои `assume` бехатаранд, зеро нишондиҳандаи оғози бурида
                // бояд ғайрифаъол бошад ва порчаҳо аз рӯи ғайри ZST низ нишоннамои охири ғайрифаъол дошта бошанд.
                // Занг ба `next_unchecked!` бехатар аст, зеро мо тафтиш мекунем, ки пеш аз такроркунӣ холӣ аст.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ин итератор ҳоло холӣ аст.
                    if mem::size_of::<T>() == 0 {
                        // Мо бояд ин тавр кор кунем, зеро `ptr` ҳеҷ гоҳ метавонад 0 бошад, аммо `end` метавонад (бо сабаби печондан) бошад.
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // БЕХАТАР: : end наметавон 0 бошад, агар T ZST набошад, зеро ptr 0 нест ва end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // БЕХАТАР: : Мо дар ҳудуди худ ҳастем.`post_inc_start` ҳатто барои ZSTs дуруст кор мекунад.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            // Инчунин, `assume` аз санҷиши ҳудуд канорагирӣ мекунад.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // БЕХАТАР: : ба мо кафолат дода мешавад, ки ҳалқаи инвариантӣ дорад:
                        // вақте ки `i >= n`, `self.next()` `None`-ро бармегардонад ва ҳалқа мешиканад.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Мо татбиқи пешфарзро, ки `try_fold`-ро истифода мебарад, бекор мекунем, зеро ин татбиқи оддӣ камтар LLVM IR тавлид мекунад ва зудтар тартиб дода мешавад.
            // Инчунин, `assume` аз санҷиши ҳудуд канорагирӣ мекунад.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // БЕХАТАР: : `i` бояд камтар аз `n` бошад, зеро он аз `n` сар мешавад
                        // ва танҳо кам мешавад.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // БЕХАТАР: : даъваткунанда бояд кафолат диҳад, ки `i` дар ҳудуди кишвар аст
                // буридаи аслӣ, аз ин рӯ `i` наметавонад `isize`-ро пур кунад ва истинодҳои баргашта ба унсури бурида кафолат дода мешаванд ва аз ин рӯ эътибор доранд.
                //
                // Инчунин қайд кунед, ки зангзананда инчунин кафолат медиҳад, ки мо дигар ҳеҷ гоҳ бо ҳамон як индекс даъват карда намешавем ва дигар усулҳое, ки ба ин зергурӯҳ дастрасӣ пайдо мекунанд, даъват карда намешаванд, аз ин рӯ, барои истиноди баргашта дар ҳолати тағирёбанда эътибор дорад
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // метавонист бо иловаро амалӣ карда шавад, аммо ин аз санҷиши ҳудуд халос мешавад

                // БЕХАТАР: : Зангҳои `assume` бехатаранд, зеро нишондиҳандаи оғози бурида бояд нол бошад,
                // ва иловаро дар болои ғайри ZST низ бояд нишоннамои охири нулро дошта бошанд.
                // Занг ба `next_back_unchecked!` бехатар аст, зеро мо тафтиш мекунем, ки пеш аз такроркунӣ холӣ аст.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ин итератор ҳоло холӣ аст.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // БЕХАТАР: : Мо дар ҳудуди худ ҳастем.`pre_dec_end` ҳатто барои ZSTs дуруст кор мекунад.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}