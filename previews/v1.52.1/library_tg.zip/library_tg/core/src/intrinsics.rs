//! Intrinsics compiler.
//!
//! Таърифҳои мувофиқ дар `compiler/rustc_codegen_llvm/src/intrinsic.rs` мебошанд.
//! Амалҳои мувофиқ дар `compiler/rustc_mir/src/interpret/intrinsics.rs` мебошанд
//!
//! # Худшиносии доимӣ
//!
//! Note: ҳама гуна тағирот ба устувории дохилӣ бояд бо дастаи забон муҳокима карда шаванд.
//! Ин тағирот дар устувории стстикро дар бар мегирад.
//!
//! Барои дар вақти тартибдиҳӣ қобили истифода сохтани шахс, бояд амалиро аз <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ба `compiler/rustc_mir/src/interpret/intrinsics.rs` нусхабардорӣ карда, ба дохилиаш `#[rustc_const_unstable(feature = "foo", issue = "01234")]` илова кард.
//!
//!
//! Агар аз `const fn` бо хусусияти `rustc_const_stable` истифода шавад, хусусияти дохилӣ бояд `rustc_const_stable` бошад.
//! Чунин тағирот набояд бидуни машварати T-lang анҷом дода шавад, зеро он хусусиятеро ба забон месозад, ки дар рамзи корбар бе дастгирии тартибдиҳанда такрор намешавад.
//!
//! # Volatiles
//!
//! Интриникҳои идоранашаванда амалиётҳоеро фароҳам меоранд, ки барои кор дар хотираи I/O амал мекунанд, ки кафолат дода мешавад, ки онҳоро компилятор дар дигар intrinsics идоранашаванда аз нав танзим намекунад.Ба ҳуҷҷатҳои LLVM дар [[volatile]] нигаред.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Асбобҳои дохилӣ амалиёти маъмули атомиро дар калимаҳои мошинӣ бо якчанд фармоишҳои хотиравӣ фароҳам меоранд.Онҳо ба ҳамон семантикаи C++ 11 итоат мекунанд.Ба ҳуҷҷатҳои LLVM дар [[atomics]] нигаред.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Навсозии зуд дар бораи фармоиши хотира:
//!
//! * Ба даст овардан, монеа барои ба даст овардани қулф.Хондан ва навиштани минбаъда пас аз монеа сурат мегирад.
//! * Озодшавӣ, монеа барои баровардани қулф.Пеш аз хондан ва навиштан пеш аз монеа сурат мегирад.
//! * Амалиёти пайдарпай ва пайдарпай бо тартиби муқарраршуда кафолат дода мешавад.Ин режими стандартӣ барои кор бо намудҳои атом мебошад ва ба `volatile` Java баробар аст.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ин воридот барои соддагардонии пайвандҳои дохилиҳуҷҷат истифода мешаванд
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // БЕХАТАР: : ба `ptr::drop_in_place` нигаред
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // ЗН, ин асбобҳо нишондиҳандаҳои хомро мегиранд, зеро онҳо хотираи тахаллусро mutate мекунанд, ки барои `&` ё `&mut` мӯътабар нест.
    //

    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариши [`Ordering::SeqCst`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариши [`Ordering::Acquire`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `success` ва [`Ordering::Acquire`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариши [`Ordering::Relaxed`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `success` ва [`Ordering::Acquire`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариши [`Ordering::SeqCst`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариши [`Ordering::Acquire`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `success` ва [`Ordering::Acquire`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариши [`Ordering::Relaxed`] ҳамчун параметрҳои `success` ва `failure` дастрас аст.
    ///
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `success` ва [`Ordering::Acquire`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Агар қимати ҷорӣ бо арзиши `old` баробар бошад, қиматро нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `compare_exchange_weak` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `success` ва [`Ordering::Relaxed`] ҳамчун параметрҳои `failure` дастрас аст.
    /// Барои намуна, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Арзиши ҷории нишоннаморо бор мекунад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `load` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Арзиши ҷории нишоннаморо бор мекунад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `load` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Арзиши ҷории нишоннаморо бор мекунад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `load` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `store` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `store` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `store` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад ва арзиши пешинаро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `swap` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад ва арзиши пешинаро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `swap` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад ва арзиши пешинаро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `swap` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад ва арзиши пешинаро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `swap` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Арзишро дар ҷои муайяншудаи хотира нигоҳ медорад ва арзиши пешинаро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `swap` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_add` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_add` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_add` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_add` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ба арзиши ҷорӣ илова карда, арзиши қаблиро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_add` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Аз арзиши ҷорӣ ҷудо кунед, арзиши пешинаро баргардонед.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_sub` бо роҳи гузариши [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Аз арзиши ҷорӣ ҷудо кунед, арзиши пешинаро баргардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_sub` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Аз арзиши ҷорӣ ҷудо кунед, арзиши пешинаро баргардонед.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_sub` бо роҳи гузариши [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Аз арзиши ҷорӣ ҷудо кунед, арзиши пешинаро баргардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_sub` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Аз арзиши ҷорӣ ҷудо кунед, арзиши пешинаро баргардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_sub` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Бо сатр ва бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_and` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ва бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_and` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ва бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_and` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ва бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_and` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ва бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_and` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Бо нархҳои ҷорӣ, ва арзиши қаблиро бармегардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар навъи [`AtomicBool`] тавассути усули `fetch_nand` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо нархҳои ҷорӣ, ва арзиши қаблиро бармегардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар навъи [`AtomicBool`] тавассути усули `fetch_nand` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо нархҳои ҷорӣ, ва арзиши қаблиро бармегардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар навъи [`AtomicBool`] тавассути усули `fetch_nand` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо нархҳои ҷорӣ, ва арзиши қаблиро бармегардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар навъи [`AtomicBool`] тавассути усули `fetch_nand` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо нархҳои ҷорӣ, ва арзиши қаблиро бармегардонед.
    ///
    /// Варианти мӯътадили ин дохилӣ дар навъи [`AtomicBool`] тавассути усули `fetch_nand` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Бо сатр ё бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_or` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ё бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_or` бо роҳи гузариши [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ё бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_or` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ё бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_or` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Бо сатр ё бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_or` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_xor` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_xor` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Версияи мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_xor` бо роҳи гузариши [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_xor` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor бо арзиши ҷорӣ, баргардонидани арзиши пешина.
    ///
    /// Варианти мӯътадили ин дохилӣ дар намудҳои [`atomic`] тавассути усули `fetch_xor` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Максимум бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ҳадди аққал бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифодаи муқоисаи имзошуда.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзои [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Ҳадди аққал бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ҳадди аққал бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_min` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Максимум бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Release`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Максимум бо арзиши ҷорӣ бо истифода аз муқоисаи беимзо.
    ///
    /// Версияи мӯътадилшудаи ин дохилӣ дар намудҳои бутуни имзонашудаи [`atomic`] тавассути усули `fetch_max` бо роҳи гузариш аз [`Ordering::Relaxed`] ҳамчун `order` дастрас аст.
    /// Барои намуна, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Мушаххасоти `prefetch` ишорае барои тавлидкунандаи код аст, ки дар сурати дастгирӣ дастури пешнамоиш медиҳад;дар акси ҳол, ин ғайриимкон аст.
    /// Пешнамоишҳо ба рафтори барнома таъсир намерасонанд, аммо метавонанд хусусиятҳои иҷрои онро тағир диҳанд.
    ///
    /// Далели `locality` бояд бутуни доимӣ бошад ва мушаххаскунандаи маҳалли муваққатӣ аз (0), ҳеҷ маҳал то (3), нигаҳдории ниҳоии маҳаллӣ мебошад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Мушаххасоти `prefetch` ишорае барои тавлидкунандаи код аст, ки дар сурати дастгирӣ дастури пешнамоиш медиҳад;дар акси ҳол, ин ғайриимкон аст.
    /// Пешнамоишҳо ба рафтори барнома таъсир намерасонанд, аммо метавонанд хусусиятҳои иҷрои онро тағир диҳанд.
    ///
    /// Далели `locality` бояд бутуни доимӣ бошад ва мушаххаскунандаи маҳалли муваққатӣ аз (0), ҳеҷ маҳал то (3), нигаҳдории ниҳоии маҳаллӣ мебошад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Мушаххасоти `prefetch` ишорае барои тавлидкунандаи код аст, ки дар сурати дастгирӣ дастури пешнамоиш медиҳад;дар акси ҳол, ин ғайриимкон аст.
    /// Пешнамоишҳо ба рафтори барнома таъсир намерасонанд, аммо метавонанд хусусиятҳои иҷрои онро тағир диҳанд.
    ///
    /// Далели `locality` бояд бутуни доимӣ бошад ва мушаххаскунандаи маҳалли муваққатӣ аз (0), ҳеҷ маҳал то (3), нигаҳдории ниҳоии маҳаллӣ мебошад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Мушаххасоти `prefetch` ишорае барои тавлидкунандаи код аст, ки дар сурати дастгирӣ дастури пешнамоиш медиҳад;дар акси ҳол, ин ғайриимкон аст.
    /// Пешнамоишҳо ба рафтори барнома таъсир намерасонанд, аммо метавонанд хусусиятҳои иҷрои онро тағир диҳанд.
    ///
    /// Далели `locality` бояд бутуни доимӣ бошад ва мушаххаскунандаи маҳалли муваққатӣ аз (0), ҳеҷ маҳал то (3), нигаҳдории ниҳоии маҳаллӣ мебошад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Панҷараи атомӣ.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::fence`] бо роҳи гузаштани [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    ///
    ///
    pub fn atomic_fence();
    /// Панҷараи атомӣ.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::fence`] бо роҳи гузаштани [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Панҷараи атомӣ.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::fence`] бо роҳи гузаштани [`Ordering::Release`] ҳамчун `order` дастрас аст.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Панҷараи атомӣ.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::fence`] бо роҳи гузаштани [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Монеаи хотираи танҳо барои компилятор.
    ///
    /// Дастрасии хотира ҳеҷ гоҳ аз ҷониби ин монеа аз ҷониби компилядор аз нав сабт карда намешавад, аммо барои он ягон дастур дода намешавад.
    /// Ин барои амалиёт дар ҳамон риште, ки пешакӣ мумкин аст, мувофиқ аст, масалан ҳангоми ҳамкорӣ бо коркардкунандагони сигнал.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::compiler_fence`] бо роҳи гузаштани [`Ordering::SeqCst`] ҳамчун `order` дастрас аст.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Монеаи хотираи танҳо барои компилятор.
    ///
    /// Дастрасии хотира ҳеҷ гоҳ аз ҷониби ин монеа аз ҷониби компилядор аз нав сабт карда намешавад, аммо барои он ягон дастур дода намешавад.
    /// Ин барои амалиёт дар ҳамон риште, ки пешакӣ мумкин аст, мувофиқ аст, масалан ҳангоми ҳамкорӣ бо коркардкунандагони сигнал.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::compiler_fence`] бо роҳи гузаштани [`Ordering::Acquire`] ҳамчун `order` дастрас аст.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Монеаи хотираи танҳо барои компилятор.
    ///
    /// Дастрасии хотира ҳеҷ гоҳ аз ҷониби ин монеа аз ҷониби компилядор аз нав сабт карда намешавад, аммо барои он ягон дастур дода намешавад.
    /// Ин барои амалиёт дар ҳамон риште, ки пешакӣ мумкин аст, мувофиқ аст, масалан ҳангоми ҳамкорӣ бо коркардкунандагони сигнал.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::compiler_fence`] бо роҳи гузаштани [`Ordering::Release`] ҳамчун `order` дастрас аст.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Монеаи хотираи танҳо барои компилятор.
    ///
    /// Дастрасии хотира ҳеҷ гоҳ аз ҷониби ин монеа аз ҷониби компилядор аз нав сабт карда намешавад, аммо барои он ягон дастур дода намешавад.
    /// Ин барои амалиёт дар ҳамон риште, ки пешакӣ мумкин аст, мувофиқ аст, масалан ҳангоми ҳамкорӣ бо коркардкунандагони сигнал.
    ///
    /// Версияи мӯътадили ин дохилӣ дар [`atomic::compiler_fence`] бо роҳи гузаштани [`Ordering::AcqRel`] ҳамчун `order` дастрас аст.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Ҷодугарии дохилие, ки маънои худро аз сифатҳои ба функсия вобастагӣ пайдо мекунад.
    ///
    /// Масалан, dataflow аз ин истифода мебарад, то изҳороти статикиро ворид кунад, то ки `rustc_peek(potentially_uninitialized)` воқеан дубора тафтиш кунад, ки dataflow воқеан ҳисоб кардааст, ки он дар он нуқтаи ҷараёни назорат оғоз нашудааст.
    ///
    ///
    /// Ин ботинӣ набояд берун аз таркиб истифода шавад.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Иҷрои равандро қатъ мекунад.
    ///
    /// Нусхаи нисбатан корбар ва устувори ин амалиёт [`std::process::abort`](../../std/process/fn.abort.html) мебошад.
    ///
    pub fn abort() -> !;

    /// Оптизаторро огоҳ мекунад, ки ин нуқтаи рамз дастнорас аст ва имкон медиҳад, ки оптимизатсияҳои минбаъда фароҳам оварда шаванд.
    ///
    /// ЗН, ин аз макроиқтисодии `unreachable!()` ба куллӣ фарқ мекунад: Баръакси макро, ки panics ҳангоми иҷрои он расидан, рафтори номуайян * мебошад, ки бо ин функсия ишора шудааст.
    ///
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) мебошад.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Оптизаторро огоҳ мекунад, ки шарт ҳамеша дуруст аст.
    /// Агар шарт нодуруст бошад, рафтор номуайян аст.
    ///
    /// Барои ин дохилӣ ягон рамз тавлид намешавад, аммо оптимизатор кӯшиш мекунад, ки онро (ва ҳолати онро) дар байни гузаришҳо нигоҳ дорад, ки метавонад ба оптимизатсияи рамзи атроф халал расонад ва иҷрои онро коҳиш диҳад.
    /// Онро истифода бурдан мумкин нест, агар инвариантро худи оптимизатор худаш кашф карда тавонад ё ягон оптимизатсияи назаррасро фароҳам наорад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Маслиҳатҳо ба тартибдиҳанда, ки эҳтимолияти ҳолати branch дуруст аст.
    /// Арзиши ба он гузаштаро бармегардонад.
    ///
    /// Ҳама гуна истифодаи ғайр аз изҳороти `if` шояд таъсире нахоҳад дошт.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Маслиҳатҳо ба тартибдиҳанда дар бораи эҳтимолияти дурӯғ будани ҳолати branch.
    /// Арзиши ба он гузаштаро бармегардонад.
    ///
    /// Ҳама гуна истифодаи ғайр аз изҳороти `if` шояд таъсире нахоҳад дошт.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Доми танаффусро барои санҷиш аз тариқи ислоҳкунанда иҷро мекунад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn breakpoint();

    /// Андозаи як навъи байт.
    ///
    /// Мушаххастараш, ин ҷуброн ба байт байни ашёҳои пайдарпайи як навъ, аз ҷумла ҷойивазкунии мувофиқат аст.
    ///
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::mem::size_of`](crate::mem::size_of) мебошад.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Ҳадди аққали ҳамоҳангсозии як намуд.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::mem::align_of`](crate::mem::align_of) мебошад.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Хатти афзалиятноки як намуд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Андозаи арзиши истинодшуда дар байт.
    ///
    /// Варианти мӯътадили ин дохилӣ [`mem::size_of_val`] мебошад.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Ҳамоҳангсозии зарурии арзиши истинодшуда.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::mem::align_of_val`](crate::mem::align_of_val) мебошад.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Мегирад як буридаи сатри статикӣ дорои номи як навъи.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::any::type_name`](crate::any::type_name) мебошад.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Муайянкунандаеро мегирад, ки дар саросари ҷаҳон ба навъи муайян беназир аст.
    /// Ин функсия, новобаста аз кадом crate, ки ба он даъват карда мешавад, арзиши якхеларо бармегардонад.
    ///
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::any::TypeId::of`](crate::any::TypeId::of) мебошад.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Посбон барои вазифаҳои хатарнок, ки ҳеҷ гоҳ иҷро карда намешавад, агар `T` беодам бошад:
    /// Ин ба таври статикӣ ё panic хоҳад буд, ё ҳеҷ коре намекунад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Посбон барои функсияҳои хатарнок, ки ҳеҷ гоҳ иҷро карда намешавад, агар `T` иҷозати сифрро оғоз накунад: Ин ба таври статикӣ ё panic хоҳад буд, ё ҳеҷ коре намекунад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn assert_zero_valid<T>();

    /// Посбон барои функсияҳои хатарнок, ки ҳеҷ гоҳ иҷро карда намешавад, агар `T` намунаҳои нодурусти бит дошта бошад: Ин ба таври статикӣ ё panic хоҳад буд, ё ҳеҷ коре намекунад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn assert_uninit_valid<T>();

    /// Метавонад истинод ба `Location` статистикиро нишон диҳад, ки он дар куҷо даъват шудааст.
    ///
    /// Ба ҷои истифодаи [`core::panic::Location::caller`](crate::panic::Location::caller) фикр кунед.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Арзишро бидуни иҷро кардани ширеши афтида аз доираи худ дур мекунад.
    ///
    /// Ин танҳо барои [`mem::forget_unsized`] вуҷуд дорад;`forget` муқаррарӣ ба ҷои `ManuallyDrop` истифода мебарад.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Лаҷомҳои қимати як навъро ҳамчун навъи дигар аз нав тафсир мекунад.
    ///
    /// Ҳарду намуд бояд андозаи якхела дошта бошанд.
    /// На аслӣ ва на натиҷа, шояд [invalid value](../../nomicon/what-unsafe-does.html) набошад.
    ///
    /// `transmute` аз ҷиҳати маъноӣ ба ҳаракат ба таври каме ба як навъи дигар табдил ёфтааст.Он битро аз арзиши манбаъ ба арзиши таъиншуда нусхабардорӣ мекунад, пас аслро фаромӯш мекунад.
    /// Он ба X's `memcpy` зери капот баробар аст, ба монанди `transmute_copy`.
    ///
    /// Азбаски `transmute` амалиёт аз рӯи арзиш аст, ҳамоҳангсозии худи *арзишҳои гузаронидашуда* ташвишовар нест.
    /// Мисли дигар функсияҳои дигар, тартибдиҳанда аллакай мувофиқати дурусти `T` ва `U`-ро таъмин мекунад.
    /// Аммо, ҳангоми интиқоли арзишҳое, ки *ба ҷои дигар ишора мекунанд*(масалан, ишораҳо, истинодҳо, қуттиҳо ...), зангзан бояд мутобиқати дурусти арзишҳои ба сӯйро таъмин кунад.
    ///
    /// `transmute` **бениҳоят** хатарнок аст.Як қатор роҳҳои ба вуҷуд овардани [undefined behavior][ub] бо ин вазифа вуҷуд доранд.`transmute` бояд чораи мутлақи охирин бошад.
    ///
    /// [nomicon](../../nomicon/transmutes.html) дорои ҳуҷҷатҳои иловагӣ мебошад.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Чанд чизест, ки `transmute` воқеан барои он муфид аст.
    ///
    /// Табдил додани нишоннамо ба нишоннамои функсия.Ин барои мошинҳое, ки нишондиҳандаҳои функсионалӣ ва нишоннамои маълумот андозаи гуногун доранд, * сайёр нест.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Тамдиди як умр ё кӯтоҳ кардани умри тағирёбанда.Ин пешрафта, хеле хатарнок Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ноумед нашавед: бисёр истифодаи `transmute`-ро бо роҳи дигар ба даст овардан мумкин аст.
    /// Дар зер замимаҳои маъмулии `transmute` оварда шудаанд, ки бо конструксияҳои бехатар иваз карда мешаванд.
    ///
    /// Табдил додани bytes(`&[u8]`) хом ба `u32`, `f64` ва ғ.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ба ҷои `u32::from_ne_bytes` истифода баред
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ё барои муайян кардани endianness `u32::from_le_bytes` ё `u32::from_be_bytes`-ро истифода баред
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Табдил додани нишоннамо ба `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Ба ҷои ин, `as` андохтро истифода баред
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Табдил додани `*mut T` ба `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Ба ҷои ин reborrow истифода баред
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Табдил додани `&mut T` ба `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Акнун, `as`-ро якҷоя кунед ва дубора таваллуд кунед, қайд кунед, ки занҷири `as` `as` гузаранда нест
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Табдил додани `&str` ба `&[u8]`:
    ///
    /// ```
    /// // ин роҳи хуби ин кор нест.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Шумо метавонед `str::as_bytes`-ро истифода баред
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ё, танҳо сатри байтро истифода баред, агар шумо сатри ҳарфиро назорат карда бошед
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Табдил додани `Vec<&T>` ба `Vec<Option<&T>>`.
    ///
    /// Барои тағир додани намуди ботинии контейнер, шумо бояд боварӣ ҳосил кунед, ки ҳеҷ як инвариантҳои контейнерро вайрон накунед.
    /// Барои `Vec`, ин маънои онро дорад, ки ҳам андоза *ва ҳам мувофиқат* намудҳои ботинӣ бояд мувофиқат кунанд.
    /// Дигар контейнерҳо метавонанд ба андозаи навъ, ҳамҷоякунӣ ё ҳатто `TypeId` такя кунанд, дар ин сурат трансмутатсия бидуни вайрон кардани тағирёбандаҳои контейнер умуман ғайриимкон аст.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // клони vector-ро тавре ки мо онҳоро баъдтар истифода хоҳем кард
    /// let v_clone = v_orig.clone();
    ///
    /// // Истифодаи transmute: ин ба тарҳбандии маълумоти номуайяни `Vec` такя мекунад, ки ин фикри бад аст ва метавонад рафтори номуайянро ба бор орад.
    /////
    /// // Аммо, он нусхабардорӣ нест.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ин роҳи пешниҳодшуда, бехатар аст.
    /// // Он ҳатто тамоми vector-ро ба массиви нав нусхабардорӣ мекунад.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Ин роҳи дурусти нусхабардории хатарноки "transmuting" a `Vec` мебошад, бе такя ба тарҳбандии маълумот.
    /// // Ба ҷои он ки ба маънои аслӣ ба `transmute` занг занем, мо як нишондиҳандаро иҷро мекунем, аммо дар мавриди табдил додани навъи аслии ботинии (`&i32`) ба навъи нави (`Option<&i32>`), ин ҳама огоҳиҳо дорад.
    /////
    /// // Ғайр аз маълумоти дар боло овардашуда, инчунин бо ҳуҷҷатҳои [`from_raw_parts`] муроҷиат кунед.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Инро ҳангоми мӯътадил кардани vec_into_raw_parts навсозӣ кунед.
    ///     // Боварӣ ҳосил кунед, ки vector аслӣ партофта нашудааст.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Татбиқи `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Роҳҳои зиёди ин кор вуҷуд доранд ва мушкилоти зиёде дар роҳи (transmute) вуҷуд доранд.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // аввал: transmute хатарнок нест;ҳамаи инро тафтиш мекунад, ки T ва
    ///         // U ҳамон андоза аст.
    ///         // Дуюм, дар ин ҷо, шумо ду истиноди тағиршаванда доред, ки ба ҳамон хотирот ишора мекунанд.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Ин аз мушкилоти бехатарии навъ халос мешавад;`&mut *`* танҳо *ба шумо `&mut T` аз `&mut T` ё `* mut T` медиҳад.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // аммо, шумо то ҳол ду истиноди тағиршаванда доред, ки ба ҳамон хотирот ишора мекунанд.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Китобхонаи стандартӣ ин тавр мекунад.
    /// // Ин усули беҳтарин аст, агар ба шумо чунин коре кардан лозим ояд
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ин ҳоло се истиноди тағиршаванда дорад, ки ба ҳамон хотирот ишора мекунанд.`slice`, арзиши ret.0 ва арзиши ret.1.
    ///         // `slice` ҳеҷ гоҳ пас аз `let ptr = ...` истифода намешавад ва аз ин рӯ метавон онро ҳамчун "dead" баррасӣ кард ва аз ин рӯ, шумо танҳо ду буридаи воқеии тағирёбанда доред.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Гарчанде ки ин const-ро ба эътидол меорад, мо дар const fn якчанд рамзи фармоишӣ дорем
    // чекҳое, ки истифодаи онро дар `const fn` пешгирӣ мекунанд.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true`-ро бармегардонад, агар навъи воқеии ҳамчун `T` додашуда ширеши партофтаро талаб кунад;`false`-ро бармегардонад, агар навъи воқеии барои `T` пешбинишуда `Copy`-ро иҷро кунад.
    ///
    ///
    /// Агар навъи воқеӣ на ширеши партофтанро талаб кунад ва на `Copy`-ро иҷро кунад, пас арзиши бозгашти ин функсия номуайян аст.
    ///
    /// Варианти мӯътадили ин дохилӣ [`mem::needs_drop`](crate::mem::needs_drop) мебошад.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ҷубронро аз нишоннамо ҳисоб мекунад.
    ///
    /// Ин ба тариқи дохилӣ барои пешгирӣ аз тағирёбӣ ба ва аз бутуни амалӣ карда мешавад, зеро табдилдиҳӣ маълумоти тахаллусро мепартояд.
    ///
    /// # Safety
    ///
    /// Ҳарду нишоннамои ибтидоӣ ва натиҷавӣ бояд дар ҳудуд бошанд ё як байт аз охири объекти ҷудошуда гузашта бошад.
    /// Агар ягон нишоннамо берун аз ҳудуд бошад ё лабрезии арифметикӣ ба амал ояд, истифодаи минбаъдаи арзиши баргашта ба рафтори номуайян оварда мерасонад.
    ///
    ///
    /// Варианти мӯътадили ин дохилӣ [`pointer::offset`] мебошад.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ҷубронро аз нишоннамо эҳтимолан печонидан ҳисоб мекунад.
    ///
    /// Ин ҳамчун як аслӣ амалӣ карда мешавад, то табдил ба бутуни бутун ва аз он гирифта нашавад, зеро конверсия оптимизатсияҳои муайянро бозмедорад.
    ///
    /// # Safety
    ///
    /// Баръакси `offset` дохилӣ, ин дохилӣ нишоннамои натиҷагирифтаро барои ишора ба як байт ё охири байти ҷудошуда маҳдуд намекунад ва он бо арифметикаи мукаммали ду печонида мешавад.
    /// Арзиши бадастомада ҳатман эътибор надорад, то барои дастрасӣ ба хотира истифода шавад.
    ///
    /// Варианти мӯътадили ин дохилӣ [`pointer::wrapping_offset`] мебошад.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Баробар ба `llvm.memcpy.p0i8.0i8.*` мувофиқи дохилӣ, бо андозаи `count`*`size_of::<T>()` ва ҳамоҳангсозии
    ///
    /// `min_align_of::<T>()`
    ///
    /// Параметри идоранашаванда ба `true` муқаррар карда шудааст, аз ин рӯ, он вақте ки ҳаҷм ба сифр баробар набошад, он беҳтарин карда намешавад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ба `llvm.memmove.p0i8.0i8.*` мувофиқи дохилӣ баробар аст, бо андозаи `count* size_of::<T>()` ва ҳамоҳангсозии
    ///
    /// `min_align_of::<T>()`
    ///
    /// Параметри идоранашаванда ба `true` муқаррар карда шудааст, аз ин рӯ, он вақте ки ҳаҷм ба сифр баробар набошад, он беҳтарин карда намешавад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ба `llvm.memset.p0i8.*` мувофиқи дохилӣ, бо андозаи `count* size_of::<T>()` ва ҳамоҳангсозии `min_align_of::<T>()` баробар аст.
    ///
    ///
    /// Параметри идоранашаванда ба `true` муқаррар карда шудааст, аз ин рӯ, он вақте ки ҳаҷм ба сифр баробар набошад, он беҳтарин карда намешавад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Сарбории ноустуворро аз нишоннамои `src` иҷро мекунад.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::ptr::read_volatile`](crate::ptr::read_volatile) мебошад.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Дӯкони идоранашавандаро ба нишоннамои `dst` иҷро мекунад.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::ptr::write_volatile`](crate::ptr::write_volatile) мебошад.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Боргузории ноустуворро аз нишоннамои `src` иҷро мекунад. Барои мутобиқ кардани нишоннамо талаб карда намешавад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Дӯкони идоранашавандаро ба нишоннамои `dst` иҷро мекунад.
    /// Барои мутобиқ кардани нишоннамо талаб карда намешавад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Решаи квадратии `f32`-ро бармегардонад
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Решаи квадратии `f64`-ро бармегардонад
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32`-ро ба дараҷаи бутун мебардорад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64`-ро ба дараҷаи бутун мебардорад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Синуси `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Синуси `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Косинуси `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Косинуси `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32`-ро ба қудрати `f32` мебардорад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64`-ро ба қудрати `f64` мебардорад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Экспоненсиалии `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Экспоненсиалии `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2 бармегардад ба қудрати `f32`.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2 бармегардад ба қудрати `f64`.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Логарифми табиии `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Логарифми табиии `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// 10 логарифми пойгоҳи `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// 10 логарифми пойгоҳи `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// 2 логарифми `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// 2 логарифми `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c`-ро барои арзишҳои `f32` бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `a * b + c`-ро барои арзишҳои `f64` бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Қимати мутлақи `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Қимати мутлақи `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Ҳадди аққали ду қимати `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Ҳадди аққали ду қимати `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Максимум ду арзиши `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Максимум ду арзиши `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Нишонро аз `y` то `x` барои арзишҳои `f32` нусхабардорӣ мекунад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Нишонро аз `y` то `x` барои арзишҳои `f64` нусхабардорӣ мекунад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Бузургтарин бутуни аз `f32` хурд ё ба он баробарро бар мегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Бузургтарин бутуни аз `f64` хурд ё ба он баробарро бар мегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Бузургтарин бутуни аз `f32` калон ё баробар ба он бармегардад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Бузургтарин бутуни аз `f64` калон ё баробар ба он бармегардад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Қисми бутуни `f32`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Қисми бутуни `f64`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Адади наздиктаринро ба `f32` бармегардонад.
    /// Мумкин аст истиснои ғайримуқаррарии нуқтаи шинокунандаро ба миён орад, агар далел бутун набошад.
    pub fn rintf32(x: f32) -> f32;
    /// Адади наздиктаринро ба `f64` бармегардонад.
    /// Мумкин аст истиснои ғайримуқаррарии нуқтаи шинокунандаро ба миён орад, агар далел бутун набошад.
    pub fn rintf64(x: f64) -> f64;

    /// Адади наздиктаринро ба `f32` бармегардонад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Адади наздиктаринро ба `f64` бармегардонад.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Адади наздиктаринро ба `f32` бармегардонад.Давраҳои нимпайкараро аз сифр давр мезанад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Адади наздиктаринро ба `f64` бармегардонад.Давраҳои нимпайкараро аз сифр давр мезанад.
    ///
    /// Варианти мӯътадили ин аслӣ чунин аст
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Илова кардани шиновар, ки ба оптимизатсия дар асоси қоидаҳои алгебравӣ имкон медиҳад.
    /// Мумкин аст манбаъҳо маҳдуд бошанд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Тарқиши шиновар, ки ба оптимизатсия дар асоси қоидаҳои алгебравӣ имкон медиҳад.
    /// Мумкин аст манбаъҳо маҳдуд бошанд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Зарбкунии шиновар, ки ба оптимизатсия дар асоси қоидаҳои алгебравӣ имкон медиҳад.
    /// Мумкин аст манбаъҳо маҳдуд бошанд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Шӯъбаи шиноварӣ, ки ба оптимизатсия дар асоси қоидаҳои алгебравӣ имкон медиҳад.
    /// Мумкин аст манбаъҳо маҳдуд бошанд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Қисми боқимонда, ки ба оптимизатсия дар асоси қоидаҳои алгебравӣ имкон медиҳад.
    /// Мумкин аст манбаъҳо маҳдуд бошанд.
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Табдил диҳед бо LLVM's fptoui/fptosi, ки метавонад undef барои арзишҳои берун аз он баргардонад
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Ҳамчун [`f32::to_int_unchecked`] ва [`f64::to_int_unchecked`] мӯътадил карда шудааст.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Шумораи битҳои дар намуди бутуни `T` муқарраршударо бар мегардонад
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `count_ones` мавҷуданд.
    /// Барои намуна,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Шумораи барҷастаи пешгузаштаи (zeroes)-ро дар намуди бутуни `T` бармегардонад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `leading_zeros` мавҷуданд.
    /// Барои намуна,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` бо арзиши `0` паҳнои битои `T`-ро бармегардонад.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Мисли `ctlz`, аммо аз ҳад хатарнок, вақте ки `undef` ҳангоми додани `x` бо арзиши `0` бармегардад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Шумораи битҳои номуносиби (zeroes)-ро дар намуди бутуни `T` бармегардонад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `trailing_zeros` мавҷуданд.
    /// Барои намуна,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` бо арзиши `0` паҳнои битои `T`-ро бармегардонад:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Мисли `cttz`, аммо аз ҳад хатарнок, вақте ки `undef` ҳангоми додани `x` бо арзиши `0` бармегардад.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Байтҳоро дар намуди бутуни `T` бар мегардонад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `swap_bytes` мавҷуданд.
    /// Барои намуна,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Лаҷомҳоро дар намуди бутуни `T` бар мегардонад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `reverse_bits` мавҷуданд.
    /// Барои намуна,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Илова кардани бутуни санҷидашударо иҷро мекунад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `overflowing_add` мавҷуданд.
    /// Барои намуна,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Тарқиши бутуни санҷидашударо иҷро мекунад
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `overflowing_sub` мавҷуданд.
    /// Барои намуна,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Зарбкунии бутуни санҷидашударо иҷро мекунад
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `overflowing_mul` мавҷуданд.
    /// Барои намуна,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Тақсимоти дақиқро иҷро мекунад, ки дар натиҷа рафтори номуайяне, ки дар он `x % y != 0` ё `y == 0` ё `x == T::MIN && y == -1` оварда шудааст
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Тақсимоти номуайянро иҷро мекунад, ки дар натиҷа рафтори номуайяне, ки дар он `y == 0` ё `x == T::MIN && y == -1` оварда шудааст
    ///
    ///
    /// Сарпӯшҳои бехатар барои ин аслӣ тавассути ибтидоии бутун тавассути усули `checked_div` мавҷуданд.
    /// Барои намуна,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Қисми боқимондаи тақсимшударо бармегардонад, ки дар натиҷаи рафтори номуайян ҳангоми `y == 0` ё `x == T::MIN && y == -1`
    ///
    ///
    /// Сарпӯшҳои бехатар барои ин аслӣ тавассути ибтидоии бутун тавассути усули `checked_rem` мавҷуданд.
    /// Барои намуна,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Сменаи чапи тафтишнашударо иҷро мекунад, ки дар натиҷаи рафтори номуайян ҳангоми `y < 0` ё `y >= N`, ки N паҳнои T дар битҳост.
    ///
    ///
    /// Сарпӯшҳои бехатар барои ин аслӣ тавассути ибтидоии бутун тавассути усули `checked_shl` мавҷуданд.
    /// Барои намуна,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Сменаи рости носанҷишро иҷро мекунад, ки дар натиҷаи рафтори номуайян ҳангоми `y < 0` ё `y >= N`, ки N паҳнои T дар битҳост.
    ///
    ///
    /// Сарпӯшҳои бехатар барои ин аслӣ тавассути ибтидоии бутун тавассути усули `checked_shr` мавҷуданд.
    /// Барои намуна,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Натиҷаи иловаҳои тафтишнашударо бармегардонад, ки дар натиҷаи рафтори номуайян ҳангоми `x + y > T::MAX` ё `x + y < T::MIN`.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Натиҷаи тарҳкунии тафтишнашударо бармегардонад, ки дар натиҷаи рафтори номуайян ҳангоми `x - y > T::MAX` ё `x - y < T::MIN`.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Натиҷаи зарбгузории номуайянро бармегардонад, ки дар натиҷаи рафтори номуайян ҳангоми `x *y > T::MAX` ё `x* y < T::MIN`.
    ///
    ///
    /// Ин ботинӣ ҳамтои устувор надорад.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Иҷро битобед чап.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `rotate_left` мавҷуданд.
    /// Барои намуна,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Иҷро мекунад давр рост.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `rotate_right` мавҷуданд.
    /// Барои намуна,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Бармегардад (a + b) mod 2 <sup>N</sup>, ки N паҳнои T дар битҳост.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `wrapping_add` мавҷуданд.
    /// Барои намуна,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (A, b) mod 2 <sup>N-ро бармегардонад</sup>, ки N паҳнои T дар битҳост.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `wrapping_sub` мавҷуданд.
    /// Барои намуна,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Бозгаштан (a * b) mod 2 <sup>N</sup>, ки N паҳнои T дар битҳост.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `wrapping_mul` мавҷуданд.
    /// Барои намуна,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ҳисоб мекунад `a + b`, ки дар ҳудуди ададӣ сер мешавад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `saturating_add` мавҷуданд.
    /// Барои намуна,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ҳисоб мекунад `a - b`, ки дар ҳудуди ададӣ сер мешавад.
    ///
    /// Версияҳои мӯътадили ин дохилӣ дар ибтидои бутун тавассути усули `saturating_sub` мавҷуданд.
    /// Барои намуна,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Арзиши дискриминантро барои вариант дар 'v' бармегардонад;
    /// агар `T` ягон табъиз надошта бошад, `0`-ро бармегардонад.
    ///
    /// Варианти мӯътадили ин дохилӣ [`core::mem::discriminant`](crate::mem::discriminant) мебошад.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Шумораи вариантҳои навъи `T`-ро ба `usize` бармегардонад;
    /// агар `T` вариант надошта бошад, `0`-ро бармегардонад.Вариантҳои беодам ҳисоб карда мешаванд.
    ///
    /// Нусхаи ба эътидол овардани ин аслӣ [`mem::variant_count`] мебошад.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Сохтани "try catch" Rust, ки нишоннамои функсия `try_fn`-ро бо нишоннамои маълумот `data` ба кор медарорад.
    ///
    /// Далели сеюм функсияест, ки агар panic рух диҳад.
    /// Ин функсия нишоннамои додаҳо ва нишоннаморо ба объекти истиснои мушаххаси гирифташуда мегирад.
    ///
    /// Барои маълумоти иловагӣ, манбаи компилятор ва инчунин татбиқи сайди std-ро бинед.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Мувофиқи LLVM мағозаи `!nontemporal` мебарорад (ба ҳуҷҷатҳои онҳо нигаред).
    /// Шояд ҳеҷ гоҳ устувор нахоҳад шуд.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Барои тафсилот ба ҳуҷҷатҳои `<*const T>::offset_from` нигаред.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Барои тафсилот ба ҳуҷҷатҳои `<*const T>::guaranteed_eq` нигаред.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Барои тафсилот ба ҳуҷҷатҳои `<*const T>::guaranteed_ne` нигаред.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Дар вақти тартиб додан ҷудо кунед.Дар вақти корӣ набояд занг зад.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Баъзе функсияҳо дар ин ҷо муайян карда мешаванд, зеро онҳо тасодуфан дар ин модул дар ҳолати устувор қарор гирифтанд.
// <https://github.com/rust-lang/rust/issues/15702> нигаред.
// (`transmute` низ ба ин категория дохил мешавад, аммо бо сабаби тафтиши андозаи якхела доштани `T` ва `U`, онро печондан мумкин нест.)
//

/// Санҷед, ки оё `ptr` нисбат ба `align_of::<T>()` дуруст мувофиқат мекунад.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` байтро аз `src` то `dst` нусхабардорӣ мекунад.Сарчашма ва таъинот набояд* бо ҳамдигар фарқ кунанд.
///
/// Барои минтақаҳои хотира, ки метавонанд бо ҳамдигар такрор шаванд, ба ҷои [`copy`] истифода баред.
///
/// `copy_nonoverlapping` аз ҷиҳати маъноӣ ба X-и C баробар аст, аммо бо фармони мубодила.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Агар ягон шартҳои зерин вайрон карда шаванд, рафтор номуайян аст:
///
/// * `src` барои хондани байтҳои `count * size_of::<T>()` бояд [valid] бошад.
///
/// * `dst` барои навиштани байтҳои `count * size_of::<T>()` бояд [valid] бошад.
///
/// * Ҳарду `src` ва `dst` бояд дуруст мутобиқ карда шаванд.
///
/// * Минтақаи хотира аз `src` бо андозаи `count сар мешавад *
///   андозаи_оф: :<T>() `байтҳо набояд бо минтақаи хотираи аз `dst` оғозёфта бо ҳамон андоза * пӯшанд.
///
/// Мисли [`read`], `copy_nonoverlapping` нусхаи битаии `T`-ро месозад, новобаста аз он ки `T` [`Copy`] аст ё не.
/// Агар `T` [`Copy`] набошад, истифодаи *ҳарду* арзишҳо дар минтақа аз `*src` ва минтақа аз `* dst` сар карда метавонанд [violate memory safety][read-ownership] кунанд.
///
///
/// Дар хотир доред, ки ҳатто агар андозаи самаранок нусхабардорӣ карда шуда бошад ("count * size_of: :<T>()`) `0` аст, нишондиҳандаҳо бояд NULL набошанд ва ба таври дуруст мутобиқ карда шаванд.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`]-ро дастӣ иҷро кунед:
///
/// ```
/// use std::ptr;
///
/// /// Тамоми элементҳои `src`-ро ба `dst` интиқол медиҳад ва `src`-ро холӣ мегузорад.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Боварӣ ҳосил кунед, ки `dst` барои нигоҳ доштани тамоми `src` иқтидори кофӣ дорад.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Занг барои ҷуброн ҳамеша бехатар аст, зеро `Vec` ҳеҷ гоҳ беш аз `isize::MAX` байт ҷудо намекунад.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src`-ро бидуни тарки мундариҷа буред.
///         // Мо инро аввал барои он пешгирӣ мекунем, ки дар сурати пайдо шудани ягон чизи panics мушкилот пеш наояд.
///         src.set_len(0);
///
///         // Ду минтақа наметавонанд бо ҳамдигар пӯшанд, зеро истинодҳои тағиршаванда тахаллус надоранд ва ду vectors гуногун наметавонанд як хотираро соҳиб шаванд.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst`-ро огоҳ кунед, ки ҳоло мундариҷаи `src`-ро нигоҳ медорад.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ин санҷишҳоро танҳо дар вақти корӣ иҷро кунед
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Воҳима накунед, то таъсири коденро хурдтар нигоҳ доред.
        abort();
    }*/

    // БЕХАТАР: : шартномаи бехатарӣ барои `copy_nonoverlapping` бояд бошад
    // аз ҷониби даъваткунанда дастгирӣ карда мешавад.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` байтро аз `src` то `dst` нусхабардорӣ мекунад.Сарчашма ва макони таъинот метавонанд бо ҳам мувофиқат кунанд.
///
/// Агар манбаъ ва таъинот *ҳеҷ гоҳ* бо ҳам нахӯрад, ба ҷои [`copy_nonoverlapping`] истифода бурдан мумкин аст.
///
/// `copy` аз ҷиҳати маъноӣ ба X-и C баробар аст, аммо бо фармони мубодила.
/// Нусхабардорӣ тавре сурат мегирад, ки гӯё байтҳо аз `src` ба массиви муваққатӣ нусхабардорӣ шуда, сипас аз массив ба `dst` нусхабардорӣ карда шуда бошанд.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Агар ягон шартҳои зерин вайрон карда шаванд, рафтор номуайян аст:
///
/// * `src` барои хондани байтҳои `count * size_of::<T>()` бояд [valid] бошад.
///
/// * `dst` барои навиштани байтҳои `count * size_of::<T>()` бояд [valid] бошад.
///
/// * Ҳарду `src` ва `dst` бояд дуруст мутобиқ карда шаванд.
///
/// Мисли [`read`], `copy` нусхаи битаии `T`-ро месозад, новобаста аз он ки `T` [`Copy`] аст ё не.
/// Агар `T` [`Copy`] набошад, бо истифода аз ҳарду арзиш дар минтақа аз `*src` сар мешавад ва минтақа аз `* dst` сар карда метавонад [violate memory safety][read-ownership].
///
///
/// Дар хотир доред, ки ҳатто агар андозаи самаранок нусхабардорӣ карда шуда бошад ("count * size_of: :<T>()`) `0` аст, нишондиҳандаҳо бояд NULL набошанд ва ба таври дуруст мутобиқ карда шаванд.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Аз буферии хатарнок Rust vector-ро самаранок эҷод кунед:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` бояд барои намуди он ва ғайри сифр дуруст мувофиқат карда шавад.
/// /// * `ptr` бояд барои хондани унсурҳои ҳамшафати навъи `T` эътибор дошта бошад.
/// /// * Пас аз даъват кардани ин функсия, агар `T: Copy` набошад, он унсурҳо набояд истифода шаванд.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // БЕХАТАР: : Шарти пешакии мо мутобиқ ва дуруст будани сарчашмаро кафолат медиҳад,
///     // ва `Vec::with_capacity` кафолат медиҳад, ки мо барои навиштани онҳо фазои мувофиқ дорем.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // БЕХАТАР: : Мо онро бо ин иқтидори зиёд пештар сохта будем,
///     // ва `copy` қаблӣ ин унсурҳоро оғоз кардааст.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ин санҷишҳоро танҳо дар вақти корӣ иҷро кунед
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Воҳима накунед, то таъсири коденро хурдтар нигоҳ доред.
        abort();
    }*/

    // БЕХАТАР: : шартномаи бехатарӣ барои `copy` бояд аз ҷониби занг зоҳир карда шавад.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` байтро аз `dst` то `val` сар карда муқаррар мекунад.
///
/// `write_bytes` ба X-и C шабеҳ аст, аммо байтҳои `count * size_of::<T>()`-ро ба `val` муқаррар мекунад.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Агар ягон шартҳои зерин вайрон карда шаванд, рафтор номуайян аст:
///
/// * `dst` барои навиштани байтҳои `count * size_of::<T>()` бояд [valid] бошад.
///
/// * `dst` бояд ба таври дуруст мутобиқ карда шаванд.
///
/// Ғайр аз он, даъваткунанда бояд боварӣ ҳосил кунад, ки навиштани `count * size_of::<T>()` байт ба минтақаи додашудаи хотира ба арзиши дурусти `T` оварда мерасонад.
/// Истифодаи минтақаи хотираи ҳамчун `T`, ки дорои арзиши беэътибории `T` мебошад, рафтори номуайян аст.
///
/// Дар хотир доред, ки ҳатто агар андозаи самаранок нусхабардорӣ карда шуда бошад ("count * size_of: :<T>()`) `0` аст, нишоннамо бояд NULL набошад ва дуруст мувофиқат кунад.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Эҷоди арзиши нодуруст:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Арзиши қаблан нигоҳдоштаро бо навиштани `Box<T>` бо нишоннамои ночиз мегузаронад.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Дар ин лаҳза, истифода ё тарки `v` ба рафтори номуайян оварда мерасонад.
/// // drop(v); // ERROR
///
/// // Ҳатто `v` "uses" онро фош мекунад ва аз ин рӯ рафтори номуайян аст.
/// // mem::forget(v); // ERROR
///
/// // Дар асл, `v` мувофиқи инвариантҳои тарҳбандии намуди асосӣ беэътибор аст, бинобар ин *ҳама* амалиёте, ки ба он даст мерасонад, рафтори номуайян аст.
/////
/// // бигзор v2 =v;//ХАТОГӢ
///
/// unsafe {
///     // Биёед ба ҷои он арзиши дуруст гузорем
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ҳоло қуттӣ хуб аст
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // БЕХАТАР: : шартномаи бехатарӣ барои `write_bytes` бояд аз ҷониби занг зоҳир карда шавад.
    unsafe { write_bytes(dst, val, count) }
}