//! Traits барои табдили байни намудҳо.
//!
//! traits дар ин модул роҳи гузаришро аз як намуд ба навъи дигар фароҳам меорад.
//! Ҳар як trait бо мақсади гуногун хизмат мекунад:
//!
//! - Татбиқи [`AsRef`] trait барои табдили арзон ба истинод
//! - Татбиқи [`AsMut`] trait барои табдили арзон ба тағирёбанда
//! - Татбиқи [`From`] trait барои истеъмоли табдили арзиш ба арзиши
//! - Татбиқи [`Into`] trait барои истеъмоли табдили арзиш ба арзиш ба намудҳои берун аз crate ҷорӣ
//! - [`TryFrom`] ва [`TryInto`] traits мисли [`From`] ва [`Into`] рафтор мекунанд, аммо бояд ҳангоми татбиқи он ноком шаванд.
//!
//! traits дар ин модул аксар вақт ҳамчун trait bounds барои функсияҳои умумӣ истифода мешаванд, то ба далелҳои намудҳои гуногун дастгирӣ карда шаванд.Барои мисолҳо ҳуҷҷатҳои ҳар як trait-ро бинед.
//!
//! Ҳамчун муаллифи китобхона, шумо бояд ҳамеша амалисозии [`From<T>`][`From`] ё [`TryFrom<T>`][`TryFrom`]-ро ба ҷои [`Into<U>`][`Into`] ё [`TryInto<U>`][`TryInto`] афзалтар донед, зеро [`From`] ва [`TryFrom`] чандирии бештарро фароҳам меоранд ва ба туфайли татбиқи кӯрпа дар китобхонаи стандартӣ, амалҳои эквиваленти [`Into`] ё [`TryInto`]-ро ройгон пешниҳод мекунанд.
//! Ҳангоми равона кардани версияи қабл аз Rust 1.41, эҳтимол дорад, ки [`Into`] ё [`TryInto`] мустақиман ҳангоми гузариш ба навъи берун аз crate ҷорӣ карда шавад.
//!
//! # Амалисозии умумӣ
//!
//! - [`AsRef`] ва [`AsMut`] мустақилкунии худкор, агар навъи ботинӣ истинод бошад
//! - [`Аз`]`<U>барои T` маънои [`Ба In`]-ро дорад</u><T><U>барои U`</u>
//! - [`TryFrom`] ' <U>барои T`маънои [` TryInto`]'-ро дорад</u><T><U>барои U`</u>
//! - [`From`] ва [`Into`] рефлексивӣ мебошанд, яъне ҳамаи намудҳо метавонанд худи `into` ва худи `from` бошанд
//!
//! Барои мисолҳои истифода ба ҳар як trait нигаред.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Функсияи ҳувият.
///
/// Дар бораи ин вазифа бояд ду чизро қайд кард:
///
/// - Ин на ҳамеша ба басташавӣ ба монанди `|x| x` баробар аст, зеро басташавӣ метавонад `x`-ро ба намуди дигар маҷбур кунад.
///
/// - Он вуруди `x`-ро, ки ба функсия гузаштааст, интиқол медиҳад.
///
/// Гарчанде ки функсияе, ки танҳо вурудро бармегардонад, аҷиб ба назар мерасад, баъзе аз истифодаи ҷолиб мавҷуданд.
///
///
/// # Examples
///
/// Истифодаи `identity` барои коре дар пайдарҳамии вазифаҳои дигар, ҷолиб, кор намекунад:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Биёед вонамуд кунем, ки илова кардани он вазифаи ҷолиб аст.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Истифодаи `identity` ҳамчун парвандаи пойгоҳи "do nothing" дар шартӣ:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Чизҳои ҷолибтаре анҷом диҳед ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Истифодаи `identity` барои нигоҳ доштани `Some` вариантҳои такрори `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Барои анҷом додани табдили арзон ба истинод истифода мешавад.
///
/// Ин trait ба [`AsMut`] монанд аст, ки барои табдил додани истинодҳои тағиршаванда истифода мешавад.
/// Агар ба шумо табдили гарон лозим ояд, беҳтар аст, ки [`From`]-ро бо навъи `&T` татбиқ кунед ё функсияи фармоишӣ нависед.
///
/// `AsRef` бо [`Borrow`] имзо дорад, аммо [`Borrow`] аз чанд ҷиҳат фарқ мекунад:
///
/// - Баръакси `AsRef`, [`Borrow`] дорои импли кӯрпа барои ҳама гуна `T` аст ва метавонад барои қабули истинод ё арзиш истифода шавад.
/// - [`Borrow`] инчунин талаб мекунад, ки [`Hash`], [`Eq`] ва [`Ord`] барои арзиши қарзӣ ба арзиши дороиҳо баробар бошанд.
/// Аз ин сабаб, агар шумо хоҳед, ки танҳо як соҳаи сохторро қарз гиред, шумо метавонед `AsRef`-ро татбиқ кунед, аммо на [`Borrow`].
///
/// **Note: Ин trait бояд ноком нашавад **.Агар табдилдиҳӣ ноком шуда бошад, усули махсусеро истифода баред, ки [`Option<T>`] ё [`Result<T, E>`]-ро баргардонад.
///
/// # Амалисозии умумӣ
///
/// - `AsRef` истинодҳои худкор, агар навъи дохилӣ истинод ё истиноди тағирёбанда бошад (масалан: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Бо истифода аз trait bounds мо метавонем далелҳои навъҳои мухталифро қабул кунем, то он даме, ки онҳо ба намуди муайяншудаи `T` табдил дода шаванд.
///
/// Масалан: Бо эҷоди як функсияи умумӣ, ки `AsRef<str>` мегирад, мо изҳор медорем, ки ҳамаи истинодҳои ба [`&str`] табдилшударо ҳамчун далел қабул кардан мехоҳем.
/// Азбаски ҳам [`String`] ва ҳам [`&str`] `AsRef<str>`-ро татбиқ мекунанд, мо метавонем онҳоро ҳамчун далели вуруд қабул кунем.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Табдилро иҷро мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Барои анҷом додани табдили арзони тағиршаванда ба тағиршаванда истифода мешавад.
///
/// Ин trait ба [`AsRef`] монанд аст, аммо барои табдил додани истинодҳои тағиршаванда истифода мешавад.
/// Агар ба шумо табдили гарон лозим ояд, беҳтар аст, ки [`From`]-ро бо навъи `&mut T` татбиқ кунед ё функсияи фармоишӣ нависед.
///
/// **Note: Ин trait бояд ноком нашавад **.Агар табдилдиҳӣ ноком шуда бошад, усули махсусеро истифода баред, ки [`Option<T>`] ё [`Result<T, E>`]-ро баргардонад.
///
/// # Амалисозии умумӣ
///
/// - `AsMut` худфиристӣ, агар навъи ботинӣ истиноди тағйирёбанда бошад (масалан: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Бо истифода аз `AsMut` ҳамчун trait bound барои функсияи умумӣ, мо метавонем ҳамаи истинодҳои тағиршавандаро қабул кунем, ки ба намуди `&mut T` табдил дода шаванд.
/// Азбаски [`Box<T>`] `AsMut<T>`-ро татбиқ мекунад, мо метавонем функсияи `add_one` нависем, ки ҳамаи далелҳои ба `&mut u64` табдилшавандаро мегирад.
/// Азбаски [`Box<T>`] `AsMut<T>`-ро татбиқ мекунад, `add_one` далелҳои навъи `&mut Box<u64>`-ро низ қабул мекунад:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Табдилро иҷро мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Табдили арзиш ба арзиш, ки арзиши вурудро истеъмол мекунад.Баръакси [`From`].
///
/// Бояд аз татбиқи [`Into`] канорагирӣ карда, ба ҷои он [`From`] амалӣ карда шавад.
/// Татбиқи [`From`] ба туфайли татбиқи кампал дар китобхонаи стандартӣ ба таври худкор амалисозии [`Into`]-ро таъмин мекунад.
///
/// Ҳангоми мушаххас кардани trait bounds дар функсияи умумӣ истифодаи [`Into`]-ро аз [`From`] бартарӣ диҳед, то намудҳое, ки танҳо [`Into`]-ро татбиқ мекунанд, истифода шаванд.
///
/// **Note: Ин trait бояд ноком нашавад **.Агар конверсия ноком шуда бошад, [`TryInto`]-ро истифода баред.
///
/// # Амалисозии умумӣ
///
/// - ["Аз"]<T>зеро U` `Into<U> for T`-ро дар назар дорад
/// - [`Into`] рефлексивӣ мебошад, ки маънои онро дорад, ки `Into<T> for T` татбиқ карда мешавад
///
/// # Татбиқи [`Into`] барои гузариш ба намудҳои беруна дар версияҳои кӯҳнаи Rust
///
/// Пеш аз он ки Rust 1.41, агар навъи таъинот қисми crate ҷорӣ набошад, пас шумо [`From`]-ро мустақиман иҷро карда наметавонистед.
/// Масалан, ин рамзро гиред:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Ин дар нусхаҳои кӯҳнаи забон тартиб дода намешавад, зеро қоидаҳои ятимии Rust каме сахттар буд.
/// Барои убур кардани ин, шумо метавонед [`Into`]-ро мустақиман иҷро кунед:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Бояд фаҳмид, ки [`Into`] татбиқи [`From`]-ро таъмин намекунад (чунон ки [`From`] бо [`Into`] мекунад).
/// Аз ин рӯ, шумо бояд ҳамеша кӯшиш кунед, ки [`From`]-ро татбиқ кунед ва пас ба [`Into`] баргардед, агар [`From`] иҷро карда нашавад.
///
/// # Examples
///
/// [`String`] иҷро мекунад [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Барои ифодаи он, ки мо мехоҳем, ки функсияи умумӣ ҳамаи далелҳоеро, ки ба навъи муайянкардаи `T` табдил дода мешаванд, қабул кунад, мо метавонем trait bound аз [`Into`] '-ро истифода барем<T>".
///
/// Масалан: Функсияи `is_hello` ҳамаи далелҳоеро мегирад, ки метавонанд ба ["Vec`]"<`[`u8`] `>` табдил дода шаванд.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Табдилро иҷро мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Ҳангоми истеъмоли арзиши вуруд барои тағир додани арзиш ба арзиш истифода мешавад.Ин мутақобилаи [`Into`] аст.
///
/// Кас ҳамеша бояд татбиқи `From`-ро аз [`Into`] бартарӣ диҳад, зеро татбиқи `From` ба туфайли татбиқи кампал дар китобхонаи стандартӣ ба таври худкор татбиқи [`Into`]-ро таъмин мекунад.
///
///
/// Танҳо [`Into`]-ро ҳангоми ҳадафи версияи пеш аз Rust 1.41 ва табдил ба намуди берун аз crate ҷорӣ амалӣ кунед.
/// `From` аз сабаби қоидаҳои ятимии Rust натавонист ин намуди табдили онҳоро дар версияҳои қаблӣ анҷом диҳад.
/// Барои тафсилоти бештар ба [`Into`] нигаред.
///
/// Ҳангоми муайян кардани trait bounds дар вазифаи умумӣ истифодаи [`Into`]-ро аз истифодаи `From` афзалтар мешуморед.
/// Бо ин роҳ, намудҳое, ки [`Into`]-ро мустақиман татбиқ мекунанд, метавонанд ҳамчун далелҳо низ истифода шаванд.
///
/// `From` инчунин ҳангоми иҷрои хатогиҳо хеле муфид аст.Ҳангоми сохтани функсияе, ки қобилияти вайрон кардан дорад, навъи бозгаштан одатан шакли `Result<T, E>` хоҳад буд.
/// `From` trait коркарди хаторо тавассути иҷозати баргардонидани як навъи хатогии ягона, ки якчанд намуди хаторо дар бар мегирад, содда мекунад.Барои тафсилоти бештар ба бахши "Examples" ва [the book][book] нигаред.
///
/// **Note: Ин trait бояд ноком нашавад **.Агар конверсия ноком шуда бошад, [`TryFrom`]-ро истифода баред.
///
/// # Амалисозии умумӣ
///
/// - `From<T> for U` [Tto]-ро <U>барои T` дар назар дорад</u>
/// - `From` рефлексивӣ мебошад, ки маънои онро дорад, ки `From<T> for T` татбиқ карда мешавад
///
/// # Examples
///
/// [`String`] `From<&str>` амалӣ мекунад:
///
/// Табдили возеҳ аз `&str` ба сатр ба тариқи зайл сурат мегирад:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ҳангоми иҷрои хатогиҳо, аксар вақт татбиқи `From` барои навъи хатогиҳои худ муфид аст.
/// Бо табдил додани намудҳои хатогии аслӣ ба навъи хатои фармоишии худ, ки навъи хатои аслиро дар бар мегирад, мо метавонем як навъи хаторо бидуни гум кардани иттилоот дар бораи сабаби аслӣ баргардонем.
/// Оператори '?' ба тариқи занг ба `Into<CliError>::into`, ки ҳангоми татбиқи `From` ба таври худкор таъмин карда мешавад, ба таври худкор навъи хатои аслиро ба навъи хатои фармоишии мо табдил медиҳад.
/// Пас, тартибдиҳанда кадом амалисозии `Into`-ро бояд истифода барад.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Табдилро иҷро мекунад.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Табдил додани кӯшиши `self`, ки метавонад арзон бошад ё не.
///
/// Муаллифони китобхонаҳо бояд одатан ин trait-ро мустақиман татбиқ накунанд, балки бояд татбиқи [`TryFrom`] trait-ро афзалтар донанд, ки чандирии бештарро фароҳам меорад ва ба шарофати татбиқи кӯрпа дар китобхонаи стандартӣ ба `TryInto` эквиваленти ройгонро пешниҳод менамояд.
/// Барои маълумоти иловагӣ дар бораи ин, ба ҳуҷҷатҳои [`Into`] нигаред.
///
/// # Татбиқи `TryInto`
///
/// Ин ҳамон маҳдудиятҳо ва мулоҳизаҳоро ҳангоми татбиқи [`Into`] мекашад, барои тафсилот дар он ҷо бубинед.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Намуди баргашта дар сурати хатои табдил.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Табдилро иҷро мекунад.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Табдилоти оддӣ ва бехатар, ки метавонанд дар баъзе ҳолатҳо ба тариқи назоратӣ ноком шаванд.Ин мутақобилаи [`TryInto`] аст.
///
/// Ин вақте муфид аст, ки шумо табдили наверо анҷом медиҳед, ки ба таври ночиз муваффақ шуданаш мумкин аст, аммо инчунин метавонад муносибати махсусро талаб кунад.
/// Масалан, бо истифода аз [`From`] trait ҳеҷ гуна роҳи табдил додани [`i64`] ба [`i32`] вуҷуд надорад, зеро [`i64`] метавонад дорои арзише бошад, ки [`i32`] онро ифода карда наметавонад ва аз ин рӯ табдилдиҳӣ маълумотро аз даст медиҳад.
///
/// Ин мумкин аст бо роҳи буридани [`i64`] ба [`i32`] (аслан додани модули [`i32::MAX`] арзиши ["i64"]) ё бо роҳи баргардонидани [`i32::MAX`], ё бо усули дигар.
/// [`From`] trait барои табдилдиҳии комил пешбинӣ шудааст, бинобар ин `TryFrom` trait ба барноманавис хабар медиҳад, ки табдили намуди он бад шуда метавонад ва ба онҳо имкон медиҳад, ки чӣ гуна кор кунанд.
///
/// # Амалисозии умумӣ
///
/// - `TryFrom<T> for U` [T TryInto`]-ро <U>барои T` дар назар дорад</u>
/// - [`try_from`] рефлексивӣ мебошад, ки маънои онро дорад, ки `TryFrom<T> for T` амалӣ мешавад ва наметавонад ноком шавад-навъи `Error` алоқаманд барои даъват кардани `T::try_from()` ба арзиши навъи `T` [`Infallible`] аст.
/// Вақте ки навъи [`!`] мӯътадил [`Infallible`] ва [`!`] баробар хоҳанд буд.
///
/// `TryFrom<T>` метавонад ба тариқи зайл амалӣ карда шавад:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Тавре ки тавсиф шудааст, [`i32`] татбиқи "TryFrom <" [`i64`]">`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Хомӯшона `big_number`-ро кӯтоҳ мекунад, талаб мекунад, ки кашфиёт пас аз он муайян карда шавад.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Хаторо бармегардонад, зеро `big_number` аз ҳад калон аст, ки ба `i32` дохил намешавад.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` бармегардад.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Намуди баргашта дар сурати хатои табдил.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Табдилро иҷро мекунад.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// Таъмини умумӣ
////////////////////////////////////////////////////////////////////////////////

// Тавре лифтҳо бар&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Тавре ки аз болои &mut мебардорад
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): имплҳои дар боло зикршударо барои&/&mut бо чунин як умумияти бештар иваз кунед:
// // Тавре ки аз болои Дереф мебарояд
// маънои <D: ?Sized + Deref<Target: AsRef<U>>, U:? Андоза> AsRef <U>барои D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut бар &mut мебардорад
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): имлои дар боло зикршударо барои &mut бо чунин умумияти бештар иваз кунед:
// // AsMut бар DerefMut мебардорад
// маънои <D: ?Sized + Deref<Target: AsMut<U>>, U:? Андоза> AsMut <U>барои D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Аз дар назар дорад
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Аз (ва ба ин васила ба) рефлексӣ аст
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Эзоҳи устувор:** Ин имплект ҳанӯз вуҷуд надорад, аммо мо "reserving space" ҳастем, то онро дар future илова кунем.
/// Барои тафсилот ба [rust-lang/rust#64715][#64715] нигаред.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ба ҷои он ислоҳи принсипӣ анҷом диҳед.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom маънои TryInto-ро дорад
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Табдилоти бе хато аз ҷиҳати маъноӣ ба табдили хато бо навъи хатои беодам баробаранд.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// ИМПЛСҲОИ БЕТОН
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ШАКЛИ ХАТО НАБУД
////////////////////////////////////////////////////////////////////////////////

/// Навъи хатогиҳо барои хатогие, ки ҳеҷ гоҳ рух дода наметавонад.
///
/// Азбаски ин enum ягон вариант надорад, арзиши ин навъи он ҳеҷ гоҳ воқеан вуҷуд дошта наметавонад.
/// Ин метавонад барои API-ҳои умумие, ки [`Result`]-ро истифода мебаранд ва навъи хатогиро параметр мекунанд, муфид бошад, то нишон диҳад, ки натиҷа ҳамеша [`Ok`] аст.
///
/// Масалан, [`TryFrom`] trait (табдилдиҳӣ, ки [`Result`]-ро бармегардонад) барои ҳама намудҳое, ки татбиқи баръакси [`Into`] мавҷуд аст, як кампал дорад.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Мутобиқати Future
///
/// Ин enum нақши [the `!`“never”type][never]-ро дорад, ки дар ин версияи Rust ноустувор аст.
/// Вақте ки `!` мӯътадил мешавад, мо ба нақша гирифтаем, ки `Infallible`-ро тахаллуси типӣ гардонем:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ва дар ниҳоят `Infallible` ро бекор мекунанд.
///
/// Аммо як ҳолат вуҷуд дорад, ки синтаксиси `!` метавонад пеш аз ба эътидол овардани `!` ҳамчун навъи комил истифода шавад: дар ҳолати навъи бозгашти функсия.
/// Махсусан, барои ду намуди нишоннамои функсияҳои гуногун амалӣ кардан мумкин аст:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Бо `Infallible` enum будан, ин рамз дуруст аст.
/// Аммо вақте ки `Infallible` ба тахаллуси never type табдил меёбад, ду 'impl` ба ҳам мепайвандад ва аз ин рӯ қоидаҳои ҳамоҳангии забон trait манъ карда мешаванд.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}