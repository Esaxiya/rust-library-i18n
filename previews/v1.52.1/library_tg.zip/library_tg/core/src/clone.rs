//! `Clone` trait барои намудҳое, ки 'ба таври мустақим нусхабардорӣ' карда намешаванд.
//!
//! Дар Rust, баъзе намудҳои оддӣ "implicitly copyable" мебошанд ва вақте ки шумо онҳоро таъин мекунед ё ҳамчун далел мегузоред, қабулкунанда нусхаи онро мегирад ва арзиши аслиро дар ҷои худ мегузорад.
//! Ин намудҳо ҷудокуниро барои нусхабардорӣ талаб намекунанд ва ниҳоӣ надоранд (яъне, онҳо қуттиҳои моликият надоранд ё [`Drop`]-ро татбиқ намекунанд), аз ин рӯ тартибдиҳанда онҳоро нусхабардорӣ арзон ва бехатар мешуморад.
//!
//! Барои навъҳои дигар нусхаҳоро бояд ба таври возеҳ, бо риояи конвенсияи [`Clone`] trait ва даъват намудани усули [`clone`], таҳия кардан лозим аст.
//!
//! [`clone`]: Clone::clone
//!
//! Мисоли истифодаи асосӣ:
//!
//! ```
//! let s = String::new(); // Навъи сатр Clone-ро амалӣ мекунад
//! let copy = s.clone(); // пас мо метавонем онро клон кунем
//! ```
//!
//! Барои ба осонӣ амалӣ кардани Clone trait, шумо инчунин метавонед `#[derive(Clone)]`-ро истифода баред.Мисол:
//!
//! ```
//! #[derive(Clone)] // мо Clone trait-ро ба Morpheus struct илова мекунем
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ва акнун мо метавонем онро клон кунем!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait маъмул барои қобилияти ба таври возеҳ нусхабардории объект.
///
/// Аз [`Copy`] фарқ мекунад, ки дар он [`Copy`] номуайян ва бениҳоят арзон аст, дар ҳоле ки `Clone` ҳамеша возеҳ аст ва шояд гарон набошад.
/// Барои иҷрои ин хусусиятҳо, Rust ба шумо иҷозат намедиҳад, ки [`Copy`]-ро такмил диҳед, аммо шумо метавонед `Clone`-ро аз нав татбиқ кунед ва рамзи худсарона иҷро кунед.
///
/// Азбаски `Clone` нисбат ба [`Copy`] умумӣтар аст, шумо метавонед ба таври худкор ҳама чизи [`Copy`]-ро `Clone` низ созед.
///
/// ## Derivable
///
/// Ин trait метавонад бо `#[derive]` истифода шавад, агар ҳамаи майдонҳо `Clone` бошанд.Амалисозии "ҳосилшуда"-и [`Clone`] [`clone`]-ро дар ҳар як майдон даъват мекунад.
///
/// [`clone`]: Clone::clone
///
/// Барои структураи умумӣ, `#[derive]` `Clone`-ро ба таври шартӣ бо илова кардани `Clone` вобаста ба параметрҳои умумӣ амалӣ мекунад.
///
/// ```
/// // `derive` Clone for Reading амалӣ менамояд<T>вақте ки T Clone аст.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Чӣ тавр ман метавонам `Clone`-ро татбиқ кунам?
///
/// Намудҳое, ки [`Copy`] мебошанд, бояд татбиқи ночизи `Clone` дошта бошанд.Расман бештар:
/// агар `T: Copy`, `x: T` ва `y: &T`, пас `let x = y.clone();` ба `let x = *y;` баробар аст.
/// Амалҳои дастӣ бояд ҳангоми риоя накардани инвариант бодиққат бошанд;аммо, кодекси хатарнок набояд барои таъмини амнияти хотира ба он эътимод кунад.
///
/// Мисол як структураи умумиест, ки нишоннамои функсияро нигоҳ медорад.Дар ин ҳолат, татбиқи `Clone` наметавонад `ҳосил 'карда шавад, аммо мумкин аст ба тариқи зайл амалӣ карда шавад:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Иҷрокунандагони иловагӣ
///
/// Илова бар [implementors listed below][impls], намудҳои зерин низ `Clone` амалӣ мекунанд:
///
/// * Намудҳои функсия (яъне намудҳои алоҳидаи барои ҳар як функсия муайяншуда)
/// * Намудҳои функсионалӣ (масалан, `fn() -> i32`)
/// * Намудҳои массив, барои ҳама андоза, агар намуди ашё инчунин `Clone` амалӣ кунад (масалан, `[i32; 123456]`)
/// * Навъҳои Tuple, агар ҳар як ҷузъ инчунин `Clone`-ро иҷро кунад (масалан, `()`, `(i32, bool)`)
/// * Намудҳои пӯшида, агар онҳо аз муҳити атроф ҳеҷ арзише ба даст оранд ё агар ҳамаи ин арзишҳои гирифташуда худи `Clone`-ро татбиқ кунанд.
///   Дар хотир доред, ки тағирёбандаҳои бо истиноди муштарак гирифташуда ҳамеша `Clone`-ро татбиқ мекунанд (ҳатто агар референт чунин намекунад), дар ҳоле ки тағирёбандаҳои бо истиноди тағйирёбанда гирифташуда ҳеҷ гоҳ `Clone`-ро иҷро намекунанд.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Нусхаи арзишро бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str Clone-ро амалӣ мекунад
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Нусхабардории нусхабардориро аз `source` иҷро мекунад.
    ///
    /// `a.clone_from(&b)` аз ҷиҳати функсионалӣ ба `a = b.clone()` баробар аст, аммо метавонад барои аз нав истифода бурдани захираҳои `a` бекор карда шавад, то ҷудошавии нолозим пешгирӣ карда шавад.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Макросро тавлид кунед, ки имкони trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ин сохторҳо танҳо аз ҷониби#[derive] истифода бурда мешавад, то тасдиқ кунад, ки ҳар як ҷузъи тип Clone or Copy-ро иҷро мекунад.
//
//
// Ин сохторҳо ҳеҷ гоҳ набояд дар рамзи корбар пайдо шаванд.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Татбиқи `Clone` барои намудҳои ибтидоӣ.
///
/// Амалҳое, ки дар Rust тавсиф карда намешаванд, дар `traits::SelectionContext::copy_clone_conditions()` дар `rustc_trait_selection` татбиқ карда мешаванд.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Истинодҳои муштаракро клонидан мумкин аст, аммо истинодҳои тағиршаванда *наметавонанд*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Истинодҳои муштаракро клонидан мумкин аст, аммо истинодҳои тағиршаванда *наметавонанд*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}