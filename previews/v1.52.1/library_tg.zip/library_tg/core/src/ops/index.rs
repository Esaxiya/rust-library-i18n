/// Барои индексатсияи амалиёти (`container[index]`) дар заминаҳои тағирнопазир истифода мешавад.
///
/// `container[index]` дар асл шакари синтаксисӣ барои `*container.index(index)` аст, аммо танҳо вақте ки ҳамчун арзиши тағирнопазир истифода мешавад.
/// Агар арзиши тағйирёбанда талаб карда шавад, ба ҷои он [`IndexMut`] истифода мешавад.
/// Ин имкон медиҳад, ки чизҳои хуб, ба монанди `let value = v[index]`, агар навъи `value` [`Copy`]-ро татбиқ кунад.
///
/// # Examples
///
/// Намунаи зерин `Index`-ро дар контейнери танҳо барои хондан `NucleotideCount` татбиқ карда, имкон медиҳад, ки ҳисобҳои инфиродӣ бо синтаксиси индекс гирифта шаванд.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Навъи баргашта пас аз индексатсия.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Амалиёти индексатсияи (`container[index]`)-ро иҷро мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Барои индексатсияи амалиёти (`container[index]`) дар заминаҳои тағиршаванда истифода мешавад.
///
/// `container[index]` дар асл шакари синтаксисӣ барои `*container.index_mut(index)` аст, аммо танҳо вақте ки ҳамчун арзиши тағйирёбанда истифода мешавад.
/// Агар арзиши тағирнопазир дархост карда шавад, ба ҷои он [`Index`] trait истифода мешавад.
/// Ин имкон медиҳад, ки чизҳои хуб, ба монанди `v[index] = value`.
///
/// # Examples
///
/// Татбиқи хеле соддаи структураи `Balance`, ки дорои ду ҷониб мебошад, ки ҳар кадоми онҳоро мутаносиб ва бетағйир индексатсия кардан мумкин аст.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Дар ин ҳолат, `balance[Side::Right]` барои `*balance.index(Side::Right)` шакар аст, зеро мо танҳо* Х01Хро мехонем, менависем.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Аммо, дар ин ҳолат `balance[Side::Left]` шакар барои `*balance.index_mut(Side::Left)` аст, зеро мо `balance[Side::Left]` менависем.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Амалиёти индексатсияи тағйирёбандаи (`container[index]`)-ро иҷро мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}