/// Нусхаи оператори даъват, ки қабулкунандаи тағирнопазир мегирад.
///
/// Мисолҳои `Fn`-ро бе ҳолати мутатсия такроран номидан мумкин аст.
///
/// *Ин trait (`Fn`)-ро бо [function pointers] (`fn`) омехта кардан мумкин нест.*
///
/// `Fn` ба таври худкор тавассути басташавӣ амалӣ карда мешавад, ки танҳо ба тағирёбандаҳои гирифташуда истинодҳои тағирнопазир мегиранд ё чизе намегиранд, инчунин (safe) [function pointers] (бо баъзе огоҳӣ, барои тафсилоти бештар ба ҳуҷҷатҳои онҳо нигоҳ кунед).
///
/// Ғайр аз он, барои ҳар як намуди `F`, ки `Fn`-ро татбиқ мекунад, `&F` низ `Fn`-ро татбиқ мекунад.
///
/// Азбаски ҳарду [`FnMut`] ва [`FnOnce`] супертраитҳои `Fn` мебошанд, ҳар як мисоли `Fn` метавонад ҳамчун параметр истифода шавад, ки дар он [`FnMut`] ё [`FnOnce`] интизор аст.
///
/// Вақте ки шумо мехоҳед параметри намуди ба функсия монандро қабул кунед ва ба он такроран ва бидуни ҳолати мутатсия занг занед, бояд `Fn` ҳамчун ҳудуд истифода баред (масалан, ҳангоми даъват дар як вақт).
/// Агар ба шумо чунин талаботҳои шадид ниёз надошта бошанд, [`FnMut`] ё [`FnOnce`]-ро ҳамчун ҳудуд истифода баред.
///
/// Барои маълумоти бештар дар бораи ин мавзӯъ ба [chapter on closures in *The Rust Programming Language*][book] нигаред.
///
/// Ҳамчунин қайд як синтаксиси махсус барои `Fn` traits аст (масалан
/// `Fn(usize, bool) -> истифода бурдан ').Онҳое, ки ба тафсилоти техникии ин таваҷҷӯҳ доранд, метавонанд ба [the relevant section in the *Rustonomicon*][nomicon] муроҷиат кунанд.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Бастанро даъват мекунад
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Бо истифода аз параметр `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ба тавре ки regex метавонад ба `&str: !FnMut` такя кунад
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Амалиёти зангро иҷро мекунад.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Версияи оператори занг, ки қабулкунаки мутавозинро мегирад.
///
/// Мисолҳои `FnMut`-ро такроран даъват кардан мумкин аст ва метавонад ҳолати онро мутатӣ кунад.
///
/// `FnMut` ба тариқи пӯшида, ки ба тағирёбандаҳои гирифташуда истинодҳои тағиршаванда ва инчунин ҳамаи намудҳое, ки [`Fn`]-ро татбиқ мекунанд, ба таври худкор амалӣ карда мешавад, зеро (safe) [function pointers] (азбаски `FnMut` супертрати [`Fn`] аст).
/// Ғайр аз он, барои ҳар як намуди `F`, ки `FnMut`-ро татбиқ мекунад, `&mut F` низ `FnMut`-ро татбиқ мекунад.
///
/// Азбаски [`FnOnce`] як супертрети `FnMut` аст, ҳар як мисоли `FnMut` метавонад дар он ҷое ки [`FnOnce`] интизор аст, истифода шавад ва азбаски [`Fn`] субтрати `FnMut` аст, ҳар як мисоли [`Fn`] метавонад дар он ҷое, ки `FnMut` интизор аст, истифода шавад.
///
/// Вақте ки шумо мехоҳед параметри намуди ба функсия монандро қабул кунед ва ба он такроран занг занед, дар ҳоле, ки он ба мутат ҳолат иҷозат диҳад.
/// Агар шумо намехоҳед, ки параметр мутатсия шавад, [`Fn`] ҳамчун ҳудуд истифода баред;агар ба шумо такроран занг задан лозим набошад, [`FnOnce`]-ро истифода баред.
///
/// Барои маълумоти бештар дар бораи ин мавзӯъ ба [chapter on closures in *The Rust Programming Language*][book] нигаред.
///
/// Ҳамчунин қайд як синтаксиси махсус барои `Fn` traits аст (масалан
/// `Fn(usize, bool) -> истифода бурдан ').Онҳое, ки ба тафсилоти техникии ин таваҷҷӯҳ доранд, метавонанд ба [the relevant section in the *Rustonomicon*][nomicon] муроҷиат кунанд.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Бо бастани мутаносибан забтшаванда даъват карда мешавад
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Бо истифода аз параметр `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ба тавре ки regex метавонад ба `&str: !FnMut` такя кунад
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Амалиёти зангро иҷро мекунад.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Версияи оператори даъват, ки қабулкунандаи арзишро мегирад.
///
/// Мисолҳои `FnOnce`-ро даъват кардан мумкин аст, аммо шояд якчанд маротиба занг зада нашаванд.Аз ин сабаб, агар танҳо дар бораи як навъ маълум аст, ки он `FnOnce`-ро татбиқ мекунад, онро танҳо як маротиба номидан мумкин аст.
///
/// `FnOnce` ба таври худкор тавассути пӯшидаҳо, ки тағирёбандаҳои гирифташударо истеъмол мекунанд ва инчунин ҳамаи намудҳое, ки [`FnMut`]-ро татбиқ мекунанд, амалӣ карда мешаванд (азбаски `FnOnce` супертрати [`FnMut`] аст).
///
///
/// Азбаски ҳарду [`Fn`] ва [`FnMut`] субтретҳои `FnOnce` мебошанд, ҳама гуна мисоли [`Fn`] ё [`FnMut`] метавонад дар он ҷое ки `FnOnce` интизор аст, истифода шавад.
///
/// Вақте ки шумо мехоҳед параметри намуди ба функсия монандро қабул кунед ва танҳо як маротиба занг задан лозим аст, `FnOnce` ҳамчун ҳудуд истифода баред.
/// Агар ба шумо лозим ояд, ки параметрро такроран даъват кунед, [`FnMut`]-ро ҳамчун ҳудуд истифода баред;агар ба шумо лозим ояд, то ҳолати mutate нагиред, [`Fn`]-ро истифода баред.
///
/// Барои маълумоти бештар дар бораи ин мавзӯъ ба [chapter on closures in *The Rust Programming Language*][book] нигаред.
///
/// Ҳамчунин қайд як синтаксиси махсус барои `Fn` traits аст (масалан
/// `Fn(usize, bool) -> истифода бурдан ').Онҳое, ки ба тафсилоти техникии ин таваҷҷӯҳ доранд, метавонанд ба [the relevant section in the *Rustonomicon*][nomicon] муроҷиат кунанд.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Бо истифода аз параметри `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` тағирёбандаҳои гирифташударо истеъмол мекунад, бинобар ин онро на бештар аз як маротиба иҷро кардан мумкин аст.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Кӯшиши дубора даъват кардани `func()` хатои `use of moved value` барои `func` меорад.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` дигар наметавонад дар ин лаҳза даъват карда шавад
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ба тавре ки regex метавонад ба `&str: !FnMut` такя кунад
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Навъи баргашта пас аз оператори занг истифода мешавад.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Амалиёти зангро иҷро мекунад.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}