//! Операторони изофабор.
//!
//! Татбиқи ин traits ба шумо имкон медиҳад, ки операторони муайянро аз ҳад зиёд бардоред.
//!
//! Баъзе аз ин traits аз ҷониби prelude ворид карда мешаванд, бинобар ин онҳо дар ҳар як барномаи Rust дастрасанд.Танҳо оператороне, ки аз ҷониби traits дастгирӣ карда мешаванд, метавонанд изофабори зиёд шаванд.
//! Масалан, оператори замимакунии (`+`) метавонад тавассути [`Add`] trait аз ҳад зиёд сарборӣ карда шавад, аммо азбаски оператори таъиноти (`=`) пуштибони trait надорад, имкони сарбории семантикии он вуҷуд надорад.
//! Ғайр аз ин, ин модул ягон механизми ташкили операторҳои навро пешниҳод намекунад.
//! Агар изофабори беиҷозат ё операторҳои фармоишӣ талаб карда шаванд, шумо бояд ба макросҳо ё плагинҳои компилятор нигаред, то синтаксиси Rust-ро васеъ кунед.
//!
//! Татбиқи оператори traits бояд дар заминаи худ тааҷҷубовар набошад ва маънои оддии онҳо ва [operator precedence]-ро дар назар дошта бошад.
//! Масалан, ҳангоми татбиқи [`Mul`], амалиёт бояд ба зарб то андозае шабоҳат дошта бошад (ва мубодилаи хосиятҳои пешбинишуда ба монанди ассотсиатсия).
//!
//! Дар хотир доред, ки операторҳои `&&` ва `||` ноқилҳои кӯтоҳ, яъне онҳо танҳо операнди дуввуми худро арзёбӣ мекунанд, агар он ба натиҷа мусоидат кунад.Азбаски ин рафтор аз ҷониби traits иҷро карда намешавад, `&&` ва `||` ҳамчун оператори аз ҳад зиёд дастгирӣ карда намешаванд.
//!
//! Бисёре аз операторҳо операндҳои худро аз рӯи арзиш қабул мекунанд.Дар заминаҳои ғайримуқаррарии марбут ба намудҳои дарунсохт, ин одатан мушкиле нест.
//! Аммо, истифодаи ин операторҳо дар рамзи умумӣ, каме диққатро талаб мекунад, агар қиматҳо баръакс бар хилофи иҷозат додани операторҳо истифода шаванд.Яке аз имконотҳо баъзан истифода бурдани [`clone`] мебошад.
//! Варианти дигар такя ба намудҳои марбут ба татбиқи иловагии оператор барои истинод мебошад.
//! Масалан, барои навъи `T`-и корбар, ки бояд иловагиро дастгирӣ кунад, эҳтимол хуб аст, ки ҳам `T` ва `&T` traits [`Add<T>`][`Add`] ва [`Add<&T>`][`Add`]-ро татбиқ кунанд, то коди умумӣ бидуни клонкунии нолозим навишта шавад.
//!
//!
//! # Examples
//!
//! Ин мисол як сохтори `Point` месозад, ки [`Add`] ва [`Sub`]-ро татбиқ мекунад ва пас илова ва тарҳ кардани ду `Point` -ро нишон медиҳад.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Барои татбиқи намуна барои ҳар як trait ҳуҷҷатҳоро бинед.
//!
//! [`Fn`], [`FnMut`] ва [`FnOnce`] traits аз рӯи намудҳое амалӣ карда мешаванд, ки ба монанди функсияҳо истифода шаванд.Дар хотир доред, ки [`Fn`] `&self` мегирад, [`FnMut`] `&mut self` ва [`FnOnce`] `self` мегиранд.
//! Инҳо ба се намуди усулҳое, ки метавонанд дар мисол истифода шаванд, мувофиқат мекунанд: даъват аз рӯи истинод, даъват аз ҷониби тағиршаванда-истинод ва даъват аз рӯи арзиш.
//! Истифодаи маъмултарини ин traits он аст, ки ҳамчун ҳудуди функсияҳои сатҳи олӣ амал мекунад, ки функсияҳо ё бастаҳоро ҳамчун далел қабул мекунанд.
//!
//! Бо назардошти [`Fn`] ҳамчун параметр:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Бо назардошти [`FnMut`] ҳамчун параметр:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Бо назардошти [`FnOnce`] ҳамчун параметр:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` тағирёбандаҳои гирифташударо истеъмол мекунад, бинобар ин онро на бештар аз як маротиба иҷро кардан мумкин аст
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Кӯшиши дубора даъват кардани `func()` хатои `use of moved value` барои `func` меорад
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` дигар наметавонад дар ин лаҳза даъват карда шавад
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;