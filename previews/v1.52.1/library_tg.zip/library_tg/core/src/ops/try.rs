/// A trait барои фармоишии рафтори оператори `?`.
///
/// Намуди татбиқи `Try` онест, ки роҳи каноникии дидани онро аз нигоҳи дикотомияи success/failure дорад.
/// Ин trait имкон медиҳад, ки ҳам он арзишҳои муваффақият ё нокомӣ аз мисоли мавҷуда ва ҳам намунаи нав аз арзиши муваффақият ё нокомӣ эҷод карда шаванд.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Намуди ин арзиш ҳангоми муваффақ ҳисобидан.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Намуди ин арзиш ҳангоми иҷро нашудани он ҳисобида мешавад.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Оператори "?"-ро татбиқ мекунад.Бозгашти `Ok(t)` маънои онро дорад, ки иҷрои он бояд одатан идома ёбад ва натиҷаи `?` арзиши `t` мебошад.
    /// Бозгашти `Err(e)` маънои онро дорад, ки иҷро бояд branch ба ботинии `catch`, ё аз функсия баргардад.
    ///
    /// Агар натиҷаи `Err(e)` баргардонида шавад, арзиши `e` дар намуди бозгашти доираи замима "wrapped" хоҳад буд (ки он бояд `Try`-ро татбиқ кунад).
    ///
    /// Махсусан, арзиши `X::from_error(From::from(e))` баргардонида мешавад, ки дар он `X` навъи бозгашти функсияи иҳота аст.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Барои сохтани натиҷаи таркибӣ арзиши хаторо печонед.
    /// Масалан, `Result::Err(x)` ва `Result::from_error(x)` баробаранд.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Барои сохтани натиҷаи таркибӣ арзиши OK-ро печонед.
    /// Масалан, `Result::Ok(x)` ва `Result::from_ok(x)` баробаранд.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}