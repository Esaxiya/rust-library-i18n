use crate::marker::Unsize;

/// Trait, ки нишон медиҳад, ки ин нишоннамо ё парпеч барои он аст, ки дар он андозаи рангро дар пойнт иҷро кардан мумкин аст.
///
/// Барои тафсилоти бештар ба [DST coercion RFC][dst-coerce] ва [the nomicon entry on coercion][nomicon-coerce] нигаред.
///
/// Барои намудҳои нишоннамои дарунсохт, нишондиҳандаҳо ба `T` ба нишондиҳандаҳо ба `U` маҷбур мешаванд, агар `T: Unsize<U>` бо роҳи аз нишондиҳандаи борик ба нишондиҳандаи чарб табдил ёбад.
///
/// Барои намудҳои фармоишӣ, маҷбуркунӣ дар ин ҷо бо роҳи маҷбуркунии `Foo<T>` ба `Foo<U>` кор мекунад, агар имкони мавҷудияти `CoerceUnsized<Foo<U>> for Foo<T>` вуҷуд дошта бошад.
/// Чунин имплментро танҳо дар сурате навиштан мумкин аст, ки агар `Foo<T>` танҳо як майдони ягонаи фантомата дошта бошад, ки `T`-ро дар бар мегирад.
/// Агар навъи он майдон `Bar<T>` бошад, татбиқи `CoerceUnsized<Bar<U>> for Bar<T>` бояд вуҷуд дошта бошад.
/// Маҷбуркунӣ бо роҳи маҷбур кардани майдони `Bar<T>` ба `Bar<U>` кор карда, майдонҳои боқимондаро аз `Foo<T>` барои сохтани `Foo<U>` пур мекунад.
/// Ин самаранок ба майдони нишоннамо медарояд ва инро маҷбур мекунад.
///
/// Умуман, барои нишондиҳандаҳои оқилона шумо `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`-ро амалӣ хоҳед кард, бо `?Sized` ихтиёрӣ дар худи `T`.
/// Барои намудҳои парпеч, ки мустақиман `T`-ро ба монанди `Cell<T>` ва `RefCell<T>` ҷойгир мекунанд, шумо метавонед `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`-ро мустақиман татбиқ кунед.
///
/// Ин имкон медиҳад, ки маҷбуркунии намудҳо ба монанди `Cell<Box<T>>` кор кунанд.
///
/// [`Unsize`][unsize] барои нишонгузории намудҳое истифода мешавад, ки агар онҳоро дар паси нишоннамоҳо ба DST маҷбур кардан мумкин бошад.Онро компилятор ба таври худкор иҷро мекунад.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut Т-> * мут У.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *мут Т->* мут У.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *мут T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Ин барои бехатарии ашё истифода бурда мешавад, то тафтиш карда шавад, ки навъи қабулкунандаи метод метавонад фиристода шавад.
///
/// Намунаи татбиқи trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *мут Т->* мут У.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}