/// Барои амалиётҳои тағирнопазири тағирнопазир, ба монанди `*v`, истифода мешавад.
///
/// Илова бар он, ки барои амалиётҳои мустақиман фарқкунӣ бо оператори (unary) `*` дар заминаҳои тағирнопазир истифода мешавад, `Deref` инчунин дар бисёр ҳолатҳо аз ҷониби мураттиб ба таври мустақим истифода мешавад.
/// Ин механизм ['`Deref` coercion'][more] номида мешавад.
/// Дар заминаҳои тағиршаванда, [`DerefMut`] истифода мешавад.
///
/// Татбиқи `Deref` барои нишондиҳандаҳои интеллектуалӣ дастрасии маълумотро дар паси онҳо қулай мекунад, аз ин сабаб онҳо `Deref`-ро татбиқ мекунанд.
/// Аз тарафи дигар, қоидаҳо дар бораи `Deref` ва [`DerefMut`] махсус барои ҷойгиркунии нишондиҳандаҳои оқилона таҳия шуда буданд.
/// Аз ин сабаб,**`Deref` бояд танҳо барои нишондиҳандаҳои оқил** амалӣ карда шавад, то нофаҳмиҳо сар назанад.
///
/// Бо чунин сабабҳо,**ин trait набояд ҳеҷ гоҳ аз кор барояд**.Вақте ки `Deref` ба таври мустақим даъват карда мешавад, нокомӣ дар вақти фарогирӣ метавонад хеле печида бошад.
///
/// # Муфассалтар дар бораи маҷбуркунии `Deref`
///
/// Агар `T` `Deref<Target = U>`-ро татбиқ кунад ва `x` арзиши навъи `T` бошад, пас:
///
/// * Дар заминаҳои тағирнопазир, `*x` (ки `T` на истинод аст ва на нишондиҳандаи хом) ба `* Deref::deref(&x)` баробар аст.
/// * Арзишҳои навъи `&T` ба арзишҳои навъи `&U` маҷбур карда мешаванд
/// * `T` ба таври мустақим тамоми усулҳои (immutable)-и навъи `U`-ро татбиқ мекунад.
///
/// Барои тафсилоти бештар, аз [the chapter in *The Rust Programming Language*][book] ва инчунин аз қисматҳои истинод дар [the dereference operator][ref-deref-op], [method resolution] ва [type coercions] боздид кунед.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Сохтор бо як майдони ягона, ки тавассути истиноди структура дастрас аст.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Намуди натиҷа пас аз фарогирӣ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Тафсилоти арзиш.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Барои амалиётҳои тағирёбандаи тағирёбанда, ба монанди `*v = 1;`, истифода мешавад.
///
/// Илова бар он, ки барои амалиётҳои мустақиман фарқкунӣ бо оператори (unary) `*` дар заминаҳои тағиршаванда истифода бурда мешавад, `DerefMut` инчунин дар бисёр ҳолатҳо аз ҷониби мураттиб ба таври мустақим истифода мешавад.
/// Ин механизм ['`Deref` coercion'][more] номида мешавад.
/// Дар заминаҳои тағирнопазир, [`Deref`] истифода мешавад.
///
/// Татбиқи `DerefMut` барои нишондиҳандаҳои оқил мутатсияи маълумотро дар паси онҳо қулай мекунад, бинобар ин онҳо `DerefMut`-ро татбиқ мекунанд.
/// Аз тарафи дигар, қоидаҳо дар бораи [`Deref`] ва `DerefMut` махсус барои ҷойгиркунии нишондиҳандаҳои оқилона таҳия шуда буданд.
/// Аз ин рӯ,**"DerefMut" бояд танҳо барои нишондиҳандаҳои оқил** амалӣ карда шавад, то нофаҳмиҳо роҳ надиҳанд.
///
/// Бо чунин сабабҳо,**ин trait набояд ҳеҷ гоҳ аз кор барояд**.Вақте ки `DerefMut` ба таври мустақим даъват карда мешавад, нокомӣ дар вақти фарогирӣ метавонад хеле печида бошад.
///
/// # Муфассалтар дар бораи маҷбуркунии `Deref`
///
/// Агар `T` `DerefMut<Target = U>`-ро татбиқ кунад ва `x` арзиши навъи `T` бошад, пас:
///
/// * Дар заминаҳои тағиршаванда, `*x` (дар он ҷо `T` на истинод аст ва на нишоннамои хом) ба `* DerefMut::deref_mut(&mut x)` баробар аст.
/// * Арзишҳои навъи `&mut T` ба арзишҳои навъи `&mut U` маҷбур карда мешаванд
/// * `T` ба таври мустақим тамоми усулҳои (mutable)-и навъи `U`-ро татбиқ мекунад.
///
/// Барои тафсилоти бештар, аз [the chapter in *The Rust Programming Language*][book] ва инчунин аз қисматҳои истинод дар [the dereference operator][ref-deref-op], [method resolution] ва [type coercions] боздид кунед.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Сохтор бо як майдони ягона, ки бо тағйири сохтор тағир дода мешавад.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Мутаассифона арзиши онро зеркашӣ мекунад.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Нишон медиҳад, ки структураро бидуни хусусияти `arbitrary_self_types` ҳамчун қабулкунандаи метод истифода кардан мумкин аст.
///
/// Ин аз ҷониби намудҳои нишоннамои stdlib ба монанди `Box<T>`, `Rc<T>`, `&T` ва `Pin<P>` амалӣ карда мешавад.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}