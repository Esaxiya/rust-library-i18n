#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Утилитаҳое, ки бо пайвасткунии интерфейси функсияи хориҷӣ (FFI) алоқаманданд.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Ҳангоми ҳамчун [pointer] истифода шуданаш ба навъи `void` C баробар аст.
///
/// Аслан, `*const c_void` ба C's `const void*` ва `*mut c_void` ба C's `void*` баробаранд.
/// Гуфтанд, ки ин *ба намуди бозгашти C's `void`, ки навъи Rust's `()` аст,* ҳамон * нест.
///
/// Барои намунаи нишондиҳандаҳо ба намудҳои ношаффоф дар FFI, то ба эътидол омадани `extern type`, тавсия дода мешавад, ки пардаи newtype дар массиви холии байтӣ истифода шавад.
///
/// Барои тафсилот ба [Nomicon] нигаред.
///
/// Яке метавонад `std::os::raw::c_void`-ро истифода барад, агар онҳо мехоҳанд тартибгари кӯҳнаи Rust-ро то 1.1.0 дастгирӣ кунанд.
/// Пас аз Rust 1.30.0, он бо ин таъриф дубора содир карда шуд.
/// Барои маълумоти иловагӣ, лутфан [RFC 2521]-ро хонед.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// ЗН, барои он ки LLVM намуди ишоракунандаи ботилро эътироф кунад ва аз рӯи функсияҳои васеъкунӣ ба монанди malloc(), мо бояд онро ҳамчун i8 * дар рамзи LLVM нишон диҳем.
// Enum, ки дар ин ҷо истифода мешавад, инро таъмин мекунад ва истифодаи нодурусти навъи "raw"-ро танҳо бо доштани вариантҳои хусусӣ пешгирӣ мекунад.
// Мо ба ду вариант ниёз дорем, зеро тартибдиҳанда аз хусусияти repr дар акси ҳол шикоят мекунад ва ба мо ҳадди аққал як вариант лозим аст, зеро дар акси ҳол enum беодам хоҳад буд ва ҳадди аққал истиноди чунин нишондиҳандаҳо UB мебуд.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Татбиқи асосии `va_list`.
// Ном WIP аст, бо истифода аз `VaListImpl` ҳоло.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Аз `'f` бетағйир мемонад, аз ин рӯ ҳар як объекти `VaListImpl<'f>` ба минтақаи функсияи муайянкардашуда вобастагӣ дорад
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Татбиқи ABI як `va_list`.
/// Барои тафсилоти бештар ба [AArch64 Procedure Call Standard] нигаред.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Татбиқи ABI як `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Татбиқи ABI як `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Печондан барои `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Табдил додани `VaListImpl` ба `VaList`, ки бо C's `va_list` дуӣ мувофиқ аст.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Табдил додани `VaListImpl` ба `VaList`, ки бо C's `va_list` дуӣ мувофиқ аст.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait бояд дар интерфейси ҷамъиятӣ истифода шавад, аммо худи trait набояд иҷозат дода шавад, ки берун аз ин модул истифода шавад.
// Иҷозат додан ба корбарон барои амалӣ кардани trait барои навъи нав (ба ин васила имкон медиҳад, ки ва_arg дар шакли нав истифода шавад) эҳтимол рафтори номуайянро ба бор орад.
//
// FIXME(dlrobertson): Барои истифодаи VaArgSafe trait дар интерфейси ҷамъиятӣ, балки инчунин кафолат додани он, ки дар дигар ҷойҳо истифода намешавад, trait бояд дар доираи модули хусусӣ оммавӣ бошад.
// Пас аз татбиқи RFC 2145, беҳтар кардани инро дида бароед.
//
//
//
//
mod sealed_trait {
    /// Trait, ки ба истифодаи намудҳои иҷозатдодашуда бо [super::VaListImpl::arg] иҷозат медиҳад.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Пешрафт ба арги навбатӣ.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `va_arg` риоя кунад.
        unsafe { va_arg(self) }
    }

    /// `va_list`-ро дар маҳалли ҷойгиршавӣ нусхабардорӣ мекунад.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // БЕХАТАР: : даъваткунанда бояд шартномаи бехатариро барои `va_end` риоя кунад.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // БЕХАТАР: : мо ба `MaybeUninit` менависем, бинобар ин он оғоз ёфт ва `assume_init` қонунист
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ин бояд ба `va_end` занг занад, аммо роҳи тозае барои ин вуҷуд надорад
        // кафолат медиҳем, ки `drop` ҳамеша ба зангзанандаи худ дохил карда мешавад, бинобар ин `va_end` мустақиман аз ҳамон функсияе, ки ба `va_copy` мувофиқ даъват карда мешавад, даъват карда мешавад.
        // `man va_end` изҳор мекунад, ки C инро талаб мекунад ва LLVM асосан аз семантикаи C пайравӣ мекунад, бинобар ин мо бояд итминон ҳосил кунем, ки `va_end` ҳамеша аз як функсияи `va_copy` даъват карда мешавад.
        //
        // Барои тафсилоти бештар, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Ин ҳоло кор мекунад, зеро `va_end` дар ҳама ҳадафҳои LLVM мавҷуд нест.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Пас аз оғози оғоз бо `va_start` ё `va_copy`, arglist `ap`-ро нест кунед.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Ҷойгоҳи ҷории arglist `src`-ро ба arglist `dst` нусхабардорӣ мекунад.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Далели навъи `T`-ро аз `va_list` `ap` бор мекунад ва далели `ap`-ро зиёд мекунад.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}