//! `Default` trait барои намудҳое, ки метавонанд арзиши пешфарзии пурмазмун дошта бошанд.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait барои додани як навъи арзиши пешфарзи муфид.
///
/// Баъзан, шумо мехоҳед ба ягон намуди пешфарз баргардед ва алалхусус он чӣ аст.
/// Ин аксар вақт бо "struct`s" меояд, ки маҷмӯи вариантҳоро муайян мекунанд:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// Чӣ гуна мо метавонем баъзе арзишҳои пешфарзро муайян кунем?Шумо метавонед `Default`-ро истифода баред:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// Ҳоло, шумо ҳамаи арзишҳои пешфарзро ба даст меоред.Rust барои намудҳои гуногуни ибтидоӣ `Default` татбиқ мекунад.
///
/// Агар шумо хоҳед, ки хосияти мушаххасро бекор кунед, аммо бо вуҷуди ин дигар пешфарзҳоро нигоҳ доред:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// Ин trait-ро бо `#[derive]` истифода бурдан мумкин аст, агар ҳамаи майдонҳои навъи `Default` иҷро кунанд.
/// Вақте ки "даст" d, он арзиши пешфарзро барои ҳар як намуди майдон истифода мебарад.
///
/// ## Чӣ тавр ман метавонам `Default`-ро татбиқ кунам?
///
/// Таъмини татбиқи усули `default()`, ки арзиши навъи шуморо бармегардонад, ки бояд бо нобаёнӣ бошад:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// "default value"-ро барои намуди бармегардад.
    ///
    /// Арзишҳои пешфарз аксар вақт як навъ арзиши ибтидоӣ, арзиши шахсият ё чизи дигаре мебошанд, ки метавонанд ҳамчун пешфарз маъно дошта бошанд.
    ///
    ///
    /// # Examples
    ///
    /// Бо истифода аз арзишҳои пешфарзии дарунсохт:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// Худ сохтан:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// Мувофиқи `Default` trait арзиши пешфарзии як намуди баргардонед.
///
/// Намуди баргаштан аз матн бароварда мешавад;ин ба `Default::default()` баробар аст, аммо барои навиштан кӯтоҳтар.
///
/// Барои намуна:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// Макросро тавлид кунед, ки имкони trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }