//! Ибтидоӣ traits ва намудҳое, ки хосиятҳои асосии намудҳоро ифода мекунанд.
//!
//! Намудҳои Rust-ро бо роҳҳои гуногуни муфид аз рӯи хосиятҳои дохилиашон тасниф кардан мумкин аст.
//! Ин таснифҳо ҳамчун traits муаррифӣ шудаанд.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Намудҳое, ки тавассути сарҳадҳои ришта интиқол дода мешаванд.
///
/// Ин trait ба таври худкор ҳангоми татбиқкунандаи он мувофиқ будани онро тартиб медиҳад.
///
/// Намунаи нишонаи ҳисобкунии истинод [`rc::Rc`][`Rc`] мебошад.
/// Агар ду ришта кӯшиши клон кардани [`Rc`]-ро, ки ба ҳамон арзиши истинодшуда ишора мекунад, кӯшиш кунанд, дар як вақт шумораи истинодро нав кунанд, ки ин [undefined behavior][ub] аст, зеро [`Rc`] амалиёти атомиро истифода намекунад.
///
/// Ҷияни он [`sync::Arc`][arc] амалиёти атомиро истифода мебарад (бо хароҷоти зиёдатӣ) ва ҳамин тавр `Send` аст.
///
/// Барои тафсилоти бештар ба [the Nomicon](../../nomicon/send-and-sync.html) нигаред.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Намудҳо бо андозаи доимии дар вақти тартибдода маълум.
///
/// Ҳама параметрҳои намуд маҳдудияти `Sized` доранд.Синтаксиси махсуси `?Sized` метавонад барои нест кардани ин ҳудуд истифода шавад, агар он номувофиқ бошад.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//хато: Андозагирӣ барои [i32] иҷро карда нашудааст
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Як истисно навъи махфии `Self` як trait мебошад.
/// A trait дорои `Sized` номуайяне нест, зеро ин ба [объекти trait] номувофиқ аст, ки мувофиқи таъриф trait бояд бо ҳамаи иҷрокунандагони имконпазир кор кунад ва ба ин васила ҳар андоза метавонад бошад.
///
///
/// Гарчанде Rust ба шумо имкон медиҳад, ки `Sized`-ро бо trait пайваст кунед, шумо онро баъдтар барои сохтани объекти trait истифода карда наметавонед:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // бигзор y: &dyn Bar= &Impl;//хато: trait `Bar` наметавонад ба ашё сохта шавад
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // барои Default, масалан, талаб мекунад, ки `[T]: !Default` арзёбӣ карда шавад
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Намудҳое, ки метавонанд "unsized" ба намуди андозаи динамикӣ бошанд.
///
/// Масалан, навъи массиви андозаи `[i8; 2]` `Unsize<[i8]>` ва `Unsize<dyn fmt::Debug>`-ро татбиқ мекунад.
///
/// Ҳама татбиқи `Unsize` ба тариқи худкор аз тарафи компилятор пешниҳод карда мешавад.
///
/// `Unsize` барои:
///
/// - `[T; N]` `Unsize<[T]>` аст
/// - `T` ҳангоми `T: Trait` `Unsize<dyn Trait>` аст
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` аст, агар:
///   - `T: Unsize<U>`
///   - Foo структура аст
///   - Танҳо майдони охирини `Foo` дорои навъи `T` мебошад
///   - `T` ҷузъи навъи ягон соҳаи дигар нест
///   - `Bar<T>: Unsize<Bar<U>>`, агар майдони охирини `Foo` навъи `Bar<T>` дошта бошад
///
/// `Unsize` дар якҷоягӣ бо [`ops::CoerceUnsized`] истифода мешавад, то контейнерҳои "user-defined", ба монанди [`Rc`], дорои намудҳои андозаи динамикӣ бошанд.
/// Барои тафсилоти бештар ба [DST coercion RFC][RFC982] ва [the nomicon entry on coercion][nomicon-coerce] нигаред.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait барои доимӣҳое, ки дар бозиҳои шабеҳ истифода мешаванд, талаб карда мешаванд.
///
/// Ҳар навъе, ки `PartialEq`-ро ба даст меорад, ин trait-ро ба таври худкор татбиқ мекунад,*новобаста аз* он ки параметрҳои он `Eq`-ро татбиқ мекунанд ё не.
///
/// Агар ашёи `const` дорои як навъе бошад, ки ин trait-ро татбиқ намекунад, пас он навъи (1.) `PartialEq`-ро татбиқ намекунад (яъне маънои доимӣ ин усули муқоисаро, ки тавлиди код дастрас аст, таъмин намекунад) ё (2.) онро амалӣ мекунад * * версияи `PartialEq` (ки мо тахмин мезанем, ба муқоисаи сохторӣ-баробарӣ мувофиқат намекунад).
///
///
/// Дар ҳарду сенарияи дар боло овардашуда, мо истифодаи чунин доимиро дар бозии шабеҳ рад мекунем.
///
/// Инчунин нигаред ба [structural match RFC][RFC1445] ва [issue 63438], ки муҳоҷиратро аз тарҳи атрибутӣ ба ин trait ҳавасманд кардаанд.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait барои доимӣҳое, ки дар бозиҳои шабеҳ истифода мешаванд, талаб карда мешаванд.
///
/// Ҳар навъе, ки `Eq`-ро ба даст меорад, ин trait-ро ба таври худкор татбиқ мекунад,*новобаста аз он* ки оё параметрҳои навъи он `Eq`-ро иҷро мекунанд.
///
/// Ин хакест, ки дар доираи маҳдудият дар системаи навъи мо кор кунад.
///
/// # Background
///
/// Мо мехоҳем талаб кунем, ки намудҳои consts, ки дар бозиҳои шабеҳ истифода мешаванд, дорои атрибутикаи `#[derive(PartialEq, Eq)]` бошанд.
///
/// Дар ҷаҳони идеалии бештар, мо метавонистем ин талаботро танҳо бо санҷидани он, ки навъи додашуда ҳам `StructuralPartialEq` trait *ва ҳам*`Eq` trait-ро иҷро мекунад, тафтиш кунем.
/// Аммо, шумо метавонед ADT-ҳо дошта бошед, ки *do*`derive(PartialEq, Eq)` доранд ва ҳолате ҳаст, ки мо мехоҳем онро тартибдиҳанда қабул кунад ва аммо навъи доимӣ `Eq`-ро иҷро карда наметавонад.
///
/// Яъне, чунин ҳолат:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Масъала дар коди боло дар он аст, ки `Wrap<fn(&())>` на `PartialEq` ва на `Eq`-ро иҷро намекунад, зеро "барои <" a> fn(&'a _)` does not implement those traits.)
///
/// Аз ин рӯ, мо наметавонем ба чеки соддалавҳона барои `StructuralPartialEq` ва танҳо `Eq` такя кунем.
///
/// Ҳамчун як хак барои кор дар атрофи ин, мо ду traits-и алоҳида, ки аз ҷониби ҳардуи онҳо (`#[derive(PartialEq)]` ва `#[derive(Eq)]`) гирифта шудаанд, истифода мебарем ва месанҷем, ки ҳардуи онҳо ҳамчун як ҷузъи санҷиши сохторӣ мавҷуданд.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Намудҳое, ки арзишҳояшонро танҳо тавассути нусхабардории бит такрор кардан мумкин аст.
///
/// Бо нобаёнӣ, пайвастагиҳои тағирёбанда 'semantics move' доранд.Ба ибораи дигар:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ба `y` гузашт ва аз ин рӯ наметавонад истифода шавад
///
/// // println! ("{: ?}", x);//хато: истифодаи арзиши интиқолшуда
/// ```
///
/// Аммо, агар навъи `Copy` амалӣ карда шавад, ба ҷои он 'семантикаи нусхабардорӣ' дорад:
///
/// ```
/// // Мо метавонем татбиқи `Copy` гирем.
/// // `Clone` инчунин талаб карда мешавад, зеро он супертрейти `Copy` аст.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` нусхаи `x` аст
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Бояд қайд кард, ки дар ин ду мисол, танҳо фарқият дар он аст, ки оё шумо пас аз супориш ба `x` дастрасӣ доред.
/// Дар зери капот, ҳам нусха ва ҳам ҳаракат метавонад битро дар хотира нусхабардорӣ кунанд, гарчанде ки ин баъзан дуртар карда мешавад.
///
/// ## Чӣ тавр ман метавонам `Copy`-ро татбиқ кунам?
///
/// Ду намуди татбиқи `Copy` дар намуди шумо мавҷуд аст.Соддатарин истифодаи `derive` аст:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Шумо инчунин метавонед `Copy` ва `Clone`-ро дастӣ иҷро кунед:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Дар байни инҳо фарқи хурд мавҷуд аст: Стратегияи `derive` инчунин `Copy`-ро вобаста ба параметрҳои намуд ҷойгир мекунад, ки на ҳамеша матлуб аст.
///
/// ## Фарқи байни `Copy` ва `Clone` дар чист?
///
/// Нусхаҳои ошкоро рух медиҳанд, масалан ҳамчун як қисми супориши `y = x`.Рафтори `Copy` сербор нест;он ҳамеша як нусхаи оддии каме оқилона аст.
///
/// Клонизатсия амали ошкоро, `x.clone()` аст.Амалисозии [`Clone`] метавонад ҳар гуна рафтори хоси мушаххасро барои такрор кардани арзишҳоро таъмин намояд.
/// Масалан, татбиқи [`Clone`] барои [`String`] бояд нусхабардории буферии сатриро дар теппа нусхабардорӣ кунад.
/// Нусхаи оддии битаии арзишҳои [`String`] танҳо нишоннаморо нусхабардорӣ хоҳад кард, ки боиси ба сатр озод шудани дукарата мегардад.
/// Аз ин сабаб, [`String`] [`Clone`] аст, аммо `Copy` нест.
///
/// [`Clone`] як супертрети `Copy` аст, бинобар ин ҳама чизи `Copy` низ бояд [`Clone`]-ро татбиқ кунад.
/// Агар навъи `Copy` бошад, пас татбиқи [`Clone`] бояд танҳо `*self`-ро баргардонад (ба мисоли боло нигаред).
///
/// ## Кай навъи ман `Copy` шуда метавонад?
///
/// Як намуд метавонад `Copy`-ро амалӣ кунад, агар ҳамаи ҷузъҳои он `Copy`-ро татбиқ кунанд.Масалан, ин структура метавонад `Copy` бошад:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Сохтор метавонад `Copy` бошад ва [`i32`] `Copy` аст, бинобар ин `Point` ба `Copy` ҳуқуқ дорад.
/// Баръакс, биандешед
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Сохти `PointList` наметавонад `Copy`-ро татбиқ кунад, зеро [`Vec<T>`] `Copy` нест.Агар мо кӯшиш кунем, ки татбиқи `Copy`-ро ба даст орем, хатогӣ ба даст меорем:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Истинодҳои муштараки (`&T`) инчунин `Copy` мебошанд, аз ин рӯ як намуд метавонад `Copy` бошад, ҳатто вақте ки он дорои маълумотномаҳои муштараки намудҳои `T` мебошад, ки *не*`Copy` мебошанд.
/// Сохтори зеринро дида мебароем, ки метавонад `Copy`-ро татбиқ кунад, зеро он танҳо ба истиноди *муштараки* навъи `PointList`-и мо аз "Copy" нигоҳ медорад:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Вақте ки *наметавонад* намуди ман `Copy` бошад?
///
/// Баъзе намудҳоро бехатар нусхабардорӣ кардан мумкин нест.Масалан, нусхабардории `&mut T` метавонад истиноди тағиршавандаро боқӣ гузорад.
/// Нусхабардории [`String`] масъулияти идоракунии буферии ["String`]-ро такрор карда, боиси дучанд озод шудан мегардад.
///
/// Умумӣ кардани ҳолати охирин, ягон намуди татбиқи [`Drop`] наметавонад `Copy` бошад, зеро он ба ҷуз байтҳои [`size_of::<T>`]-и худ баъзе манбаъҳоро идора мекунад.
///
/// Агар шумо кӯшиш кунед, ки `Copy`-ро дар структура ё enum, ки дорои маълумоти ғайри "Copy`" мебошад, татбиқ кунед, хатогии [E0204] пайдо мекунед.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Кай *бояд* навъи ман `Copy` бошад?
///
/// Умуман, агар навъи _can_-и шумо `Copy`-ро татбиқ кунад, он бояд иҷро карда шавад.
/// Дар хотир доред, ки татбиқи `Copy` қисми API-и навъи шумост.
/// Агар ин намуди он метавонад дар future ғайримуқаррарӣ шавад, метавонад амалисозии `Copy`-ро ҳозир партофтан лозим ояд, то тағирёбии API вайрон нашавад.
///
/// ## Иҷрокунандагони иловагӣ
///
/// Илова бар [implementors listed below][impls], намудҳои зерин низ `Copy` амалӣ мекунанд:
///
/// * Намудҳои функсия (яъне намудҳои алоҳидаи барои ҳар як функсия муайяншуда)
/// * Намудҳои функсионалӣ (масалан, `fn() -> i32`)
/// * Намудҳои массив, барои ҳама андоза, агар намуди ашё инчунин `Copy` амалӣ кунад (масалан, `[i32; 123456]`)
/// * Навъҳои Tuple, агар ҳар як ҷузъ инчунин `Copy`-ро иҷро кунад (масалан, `()`, `(i32, bool)`)
/// * Намудҳои пӯшида, агар онҳо аз муҳити атроф ҳеҷ арзише ба даст оранд ё агар ҳамаи ин арзишҳои гирифташуда худи `Copy`-ро татбиқ кунанд.
///   Дар хотир доред, ки тағирёбандаҳои бо истиноди муштарак гирифташуда ҳамеша `Copy`-ро татбиқ мекунанд (ҳатто агар референт чунин намекунад), дар ҳоле ки тағирёбандаҳои бо истиноди тағйирёбанда гирифташуда ҳеҷ гоҳ `Copy`-ро татбиқ намекунанд.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Ин имкон медиҳад, ки нусхабардории навъе, ки `Copy`-ро аз сабаби ҳудуди ҳаёт қаноатманд намекунад (нусхабардории `A<'_>` ҳангоми танҳо `A<'static>: Copy` ва `A<'_>: Clone`).
// Мо ин сифатро ҳоло дар он ҷо дорем, зеро дар `Copy` якчанд ихтисосҳои мавҷуда мавҷуданд, ки аллакай дар китобхонаи стандартӣ мавҷуданд ва ҳоло ҳеҷ гуна роҳи бехатар доштани ин рафтор вуҷуд надорад.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Макросро тавлид кунед, ки имкони trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Намудҳое, ки барои онҳо мубодилаи истинодҳо байни риштаҳо бехатар аст.
///
/// Ин trait ба таври худкор ҳангоми татбиқкунандаи он мувофиқ будани онро тартиб медиҳад.
///
/// Таърифи дақиқ чунин аст: навъи `T` [`Sync`] аст ва агар танҳо `&T` [`Send`] бошад.
/// Ба ибораи дигар, агар ҳангоми гузаронидани истинодҳои `&T` байни риштаҳо имкони [undefined behavior][ub] (аз ҷумла нажодҳои додаҳо) мавҷуд набошад.
///
/// Тавре ки интизор шудан мумкин аст, намудҳои ибтидоӣ ба монанди [`u8`] ва [`f64`] ҳама [`Sync`] мебошанд ва ҳамин тавр намудҳои оддии маҷмӯӣ, ки онҳоро дар бар мегиранд, ба монанди кортҳо, структураҳо ва энумҳо.
/// Намунаҳои бештари намудҳои асосии [`Sync`] аз ҷумла намудҳои "immutable", ба монанди `&T` ва онҳое, ки мутобиқияти оддии меросӣ доранд, ба монанди [`Box<T>`][box], [`Vec<T>`][vec] ва аксари намудҳои дигари коллексия.
///
/// (Параметрҳои умумӣ бояд [`Sync`] бошанд, то контейнери онҳо ["Синхронизация"] шавад.)
///
/// Оқибати то андозае ҳайратангези таъриф дар он аст, ки `&mut T` `Sync` аст (агар `T` `Sync` бошад), гарчанде ки ба назар чунин мерасад, ки метавонад мутатсияи ҳамоҳангнашударо таъмин кунад.
/// Ҳилла дар он аст, ки истиноди тағирёбанда дар паси истиноди муштарак (яъне `& &mut T`) танҳо барои хондан мешавад, гӯё ки он `& &T` бошад.
/// Аз ин рӯ, хавфи сабқати маълумот вуҷуд надорад.
///
/// Намудҳое, ки `Sync` нестанд, онҳое мебошанд, ки "interior mutability" дар шакли ғайримутамарказ доранд, ба монанди [`Cell`][cell] ва [`RefCell`][refcell].
/// Ин намудҳо ба мутатсияи мундариҷаи онҳо ҳатто тавассути истиноди тағирнопазир ва муштарак имкон медиҳанд.
/// Масалан, усули `set` дар [`Cell<T>`][cell] `&self`-ро мегирад, аз ин рӯ танҳо як истиноди муштараки [`&Cell<T>`][cell] талаб мекунад.
/// Усул ягон ҳамоҳангсозӣ намекунад, бинобар ин [`Cell`][cell] `Sync` буда наметавонад.
///
/// Намунаи дигари навъи ғайри `Sync` ин нишоннамои ҳисобкунии истинод [`Rc`][rc] мебошад.
/// Бо назардошти ҳама гуна истиноди [`&Rc<T>`][rc], шумо метавонед [`Rc<T>`][rc]-и навро клон карда, ҳисобҳои истинодро ба тариқи ғайриматрикӣ тағир диҳед.
///
/// Дар ҳолатҳое, ки касе ба тағйирёбии бехатарии ришта ниёз дорад, Rust [atomic data types], инчунин бастани возеҳ тавассути [`sync::Mutex`][mutex] ва [`sync::RwLock`][rwlock] пешниҳод мекунад.
/// Ин намудҳо кафолат медиҳанд, ки ҳама гуна мутатсия нажодҳои додаҳоро ба вуҷуд оварда наметавонад, аз ин рӯ намудҳо `Sync` мебошанд.
/// Ба ин монанд, [`sync::Arc`][arc] аналоги бехатар барои риштаи [`Rc`][rc]-ро таъмин мекунад.
///
/// Ҳамаи намудҳое, ки бо тағирёбии дохилӣ дучор меоянд, инчунин бояд пардаи [`cell::UnsafeCell`][unsafecell] дар атрофи value(s)-ро истифода баранд, ки тавассути истиноди муштарак тағир додан мумкин аст.
/// Нокомӣ дар ин кор [undefined behavior][ub] аст.
/// Масалан, [`transmute`][transmute]-ing аз `&T` ба `&mut T` беэътибор аст.
///
/// Барои тафсилоти бештар дар бораи `Sync` ба [the Nomicon][nomicon-send-and-sync] нигаред.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): як бор дастгирии илова кардани ёддоштҳо дар заминҳои `rustc_on_unimplemented` дар бета ва васеъ карда шуд, то тафтиш карда шавад, ки оё басташавӣ дар ягон нуқтаи талабот ҷойгир аст, онро ба монанди (#48534) дароз кунед:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Навъи андозаи сифр барои аломатгузории чизҳое истифода мешавад, ки "act like" онҳо дорои `T` мебошанд.
///
/// Илова кардани майдони `PhantomData<T>` ба навъи худ ба компилятор мегӯяд, ки навъи шумо тавре амал мекунад, ки гӯё арзиши навъи `T` ро нигоҳ медорад, гарчанде ки он аслан чунин нест.
/// Ин маълумот ҳангоми ҳисоб кардани хосиятҳои муайяни бехатарӣ истифода мешавад.
///
/// Барои шарҳи амиқтари истифодаи `PhantomData<T>`, лутфан ба [the Nomicon](../../nomicon/phantom-data.html) нигаред.
///
/// # Қайдҳои даҳшатнок 👻👻👻
///
/// Гарчанде ки ҳардуи онҳо номҳои даҳшатнок доранд, `PhantomData` ва 'намудҳои фантомҳо' бо ҳам робита доранд, аммо шабеҳ нестанд.Параметри навъи фантом танҳо як параметри навъиест, ки ҳеҷ гоҳ истифода намешавад.
/// Дар Rust, ин аксар вақт боиси шикояти тартибдиҳанда мегардад ва ҳалли он илова кардани истифодаи "dummy" бо роҳи `PhantomData` мебошад.
///
/// # Examples
///
/// ## Параметрҳои умри истифоданашуда
///
/// Эҳтимол, маъмултарин ҳолати истифодаи `PhantomData` ин сохторест, ки дорои параметрҳои умри истифоданашуда мебошад, одатан ҳамчун як қисми баъзе рамзҳои хатарнок.
/// Масалан, ин ҷо як сохтори `Slice`, ки дорои ду нишоннамои навъи `*const T` аст, ки эҳтимолан ба массив дар ҷое ишора мекунад:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ният ин аст, ки маълумоти асосӣ танҳо барои тамоми ҳаёти `'a` эътибор доранд, аз ин рӯ `Slice` набояд аз `'a` умр бубинад.
/// Аммо, ин ният дар кодекс ифода карда нашудааст, зеро истифодаи умри `'a` вуҷуд надорад ва аз ин рӯ маълум нест, ки он ба кадом маълумот дахл дорад.
/// Мо метавонем онро ислоҳ карда, ба тартибдиҳанда гӯем, ки *чун* структураи `Slice` дорои истиноди `&'a T` бошад:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Ин ҳам дар навбати худ эзоҳи `T: 'a`-ро талаб мекунад, ки нишон медиҳад, ки ҳама гуна маълумотномаҳо дар `T` дар тӯли `'a` умр эътибор доранд.
///
/// Ҳангоми оғоз кардани `Slice` шумо танҳо арзиши `PhantomData`-ро барои майдони `phantom` пешниҳод мекунед:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Параметрҳои навъи истифоданашуда
///
/// Баъзан чунин мешавад, ки шумо параметрҳои истифоданашудаи типӣ доред, ки нишон медиҳад, ки структура ба кадом навъи маълумот "tied" аст, гарчанде ки ин маълумот дар худи структура ёфт намешавад.
/// Ин як мисолест, ки ин бо [FFI] ба миён меояд.
/// Интерфейси хориҷӣ барои ишора ба арзишҳои Rust-и навъҳои мухталиф дастакҳои навъи `*mut ()`-ро истифода мебарад.
/// Мо навъи Rust-ро бо истифода аз параметри навъи фантом дар struct `ExternalResource` пайгирӣ мекунем, ки дастакро печонида мегирад.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Моликият ва санҷиши тарки
///
/// Илова кардани майдони навъи `PhantomData<T>` нишон медиҳад, ки навъи шумо дорои маълумоти навъи `T` мебошад.Ин дар навбати худ маънои онро дорад, ки ҳангоми партофтани навъи шумо, он метавонад як ё якчанд ҳолатҳои навъи `T`-ро тарк кунад.
/// Ин ба таҳлили [drop check] тартибдиҳандаи Rust дахл дорад.
///
/// Агар структураи шумо дарвоқеъ маълумоти шахсии *`T` надошта бошад*, беҳтар аст, ки навъи истинод, ба монанди `PhantomData<&'a T>` (ideally) ё `PhantomData<*const T>` (агар ягон мӯҳлат дахл надорад) истифода бурда шавад, то соҳибият нишон дода нашавад.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Компилятор-дохилии trait, ки барои нишон додани навъи дискриминантҳои enum истифода мешавад.
///
/// Ин trait ба таври худкор барои ҳар як намуди он амалӣ карда мешавад ва ба [`mem::Discriminant`] ягон кафолат зам намекунад.
/// Ин интиқоли байни `DiscriminantKind::Discriminant` ва `mem::Discriminant` ** рафтори номуайян аст.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Намуди дискриминант, ки бояд trait bounds-ро, ки `mem::Discriminant` талаб мекунад, қонеъ гардонад.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Компилятор-дохилии trait барои муайян кардани он, ки оё ягон намуди `UnsafeCell` дар дохили он мавҷуд аст, аммо на тавассути ғайримустақим.
///
/// Ин, масалан, оё `static`-и ин навъи дар хотираи статикии танҳо барои хондан ҷойгиршуда ё хотираи статикии навишташавандаро ҷойгир мекунад, таъсир мерасонад.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Намудҳое, ки пас аз пинҳон кардан метавонанд бехатар интиқол дода шаванд.
///
/// Худи Rust тасаввуроти намудҳои ғайриманқулро надорад ва ҳаракатҳоро (масалан, тавассути супориш ё [`mem::replace`]) ҳамеша бехатар меҳисобад.
///
/// Ба ҷои ин навъи [`Pin`][Pin] барои пешгирии ҳаракат тавассути системаи тип истифода мешавад.Нишондиҳандаҳои `P<T>`, ки бо парпечи [`Pin<P<T>>`][Pin] печонида шудаанд, наметавонанд аз онҳо берун карда шаванд.
/// Барои маълумоти бештар дар бораи пинҳон кардан, ба ҳуҷҷатҳои [`pin` module] нигаред.
///
/// Татбиқи `Unpin` trait барои `T` маҳдудиятҳои пинҳон кардани навъро бардошта, пас имкон медиҳад, ки `T` аз [`Pin<P<T>>`][Pin] бо функсияҳои ба монанди [`mem::replace`] ҳаракат кунанд.
///
///
/// `Unpin` барои маълумоти ғайримуқаррарӣ ҳеҷ натиҷае надорад.
/// Аз ҷумла, [`mem::replace`] хушбахтона маълумоти `!Unpin`-ро интиқол медиҳад (он барои ҳама гуна `&mut T` кор мекунад, на танҳо вақте ки `T: Unpin`).
/// Аммо, шумо наметавонед [`mem::replace`]-ро дар маълумоти дар дохили [`Pin<P<T>>`][Pin] печондашуда истифода баред, зеро шумо наметавонед `&mut T`-ро барои ин ба даст оред ва *ин* аст, ки ин система кор мекунад.
///
/// Ҳамин тавр, ин, масалан, танҳо дар намудҳои татбиқи `Unpin` иҷро карда мешавад:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Барои занг задан ба `mem::replace` ба мо истиноди тағйирёбанда лозим аст.
/// // Мо метавонем чунин истинодро тавассути (implicitly) бо даъвати `Pin::deref_mut` ба даст орем, аммо ин танҳо имконпазир аст, зеро `String` `Unpin`-ро татбиқ мекунад.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ин trait қариб барои ҳама намудҳо ба таври худкор амалӣ карда мешавад.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Намуди маркер, ки `Unpin`-ро татбиқ намекунад.
///
/// Агар як намуди дорои `PhantomPinned` бошад, он `Unpin`-ро бо нобаёнӣ иҷро намекунад.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Татбиқи `Copy` барои намудҳои ибтидоӣ.
///
/// Амалҳое, ки дар Rust тавсиф карда намешаванд, дар `traits::SelectionContext::copy_clone_conditions()` дар `rustc_trait_selection` татбиқ карда мешаванд.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Истинодҳои муштаракро нусхабардорӣ кардан мумкин аст, аммо истинодҳои тағиршаванда *наметавонанд*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}