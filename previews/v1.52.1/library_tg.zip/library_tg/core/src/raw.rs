#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Дорои таърифҳои структурӣ барои тарҳбандии намудҳои дарунсохти компилятор мебошад.
//!
//! Онҳо метавонанд ҳамчун ҳадафҳои интиқолдиҳандагон дар коди хатарнок барои идоракунии намояндагиҳои хом бевосита истифода шаванд.
//!
//!
//! Таърифи онҳо ҳамеша бояд ба ABI, ки дар `rustc_middle::ty::layout` муайян шудааст, мувофиқат кунад.
//!

/// Намоиши объекти trait ба монанди `&dyn SomeTrait`.
///
/// Ин структура дорои ҳамон тарҳест, ки ба монанди `&dyn SomeTrait` ва `Box<dyn AnotherTrait>`.
///
/// `TraitObject` барои мувофиқат бо тарҳҳо кафолат дода мешавад, аммо ин навъи объектҳои trait нест (масалан, майдонҳо дар `&dyn SomeTrait` мустақиман дастрас нестанд) ва инчунин он тарҳро назорат намекунад (тағир додани таъриф тарҳбандии `&dyn SomeTrait`-ро тағир намедиҳад).
///
/// Он танҳо барои истифода аз ҷониби коди хатарнок таҳия шудааст, ки бояд тафсилоти сатҳи поёнро идора кунад.
///
/// Ҳеҷ як роҳи ба таври куллӣ ба ҳама объектҳои trait муроҷиат кардан вуҷуд надорад, аз ин рӯ ягона роҳи сохтани арзишҳои ин навъи функсияҳо ба монанди [`std::mem::transmute`][transmute] мебошад.
/// Ба ин монанд, ягона роҳи сохтани объекти ҳақиқии trait аз арзиши `TraitObject` бо `transmute` мебошад.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Синтез кардани объекти trait бо намудҳои номувофиқ-он ҷое ки vtable ба намуди қимате, ки нишоннамои додаҳо ба он ишора мекунад, мувофиқат намекунад-эҳтимолан ба рафтори номуайян оварда мерасонад.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // мисоли trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // бигзор тартибдиҳанда объекти trait созад
/// let object: &dyn Foo = &value;
///
/// // ба намояндагии хом нигаред
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // нишоннамои маълумот суроғаи `value` аст
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // сохтани объекти нав, бо ишора ба `i32` дигар, бодиққат истифода аз vtable `i32` аз `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // он бояд тавре кор кунад, ки гӯё мо бевосита аз `other_value` объекти trait сохта бошем
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}