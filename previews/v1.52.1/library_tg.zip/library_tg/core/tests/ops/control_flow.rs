use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Ин сатҳи сатҳи устувор нест, аммо ба нигоҳ доштани `?` дар байни онҳо мусоидат мекунад, ҳатто агар LLVM ҳоло ҳам наметавонад аз он истифода барад.
    //
    // (Мутаассифона Натиҷа ва Опсия номувофиқ аст, бинобар ин ControlFlow наметавонад бо ҳам мувофиқат кунад.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}