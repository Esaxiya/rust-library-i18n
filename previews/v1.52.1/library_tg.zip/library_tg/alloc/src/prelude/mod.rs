//! Маблағи Prelude
//!
//! Ҳадафи ин модул коҳиш додани воридоти ашёи маъмулан истифодашавандаи `alloc` crate бо роҳи илова кардани глобус ба болои модулҳо мебошад:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;