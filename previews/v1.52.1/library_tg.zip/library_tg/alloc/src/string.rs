//! Рақами UTF-8-рамзи калоншаванда.
//!
//! Ин модул дорои намуди [`String`], [`ToString`] trait барои табдил ба сатрҳо ва якчанд намуди хатогие мебошад, ки метавонанд аз кор бо [`String`] s натиҷа диҳанд.
//!
//!
//! # Examples
//!
//! Роҳҳои сершумори сохтани [`String`] нав аз матни аслӣ вуҷуд доранд:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Шумо метавонед як [`String`] навро бо ҳамоҳангӣ бо як мавҷуда эҷод кунед
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Агар шумо vector байти дурусти UTF-8 дошта бошед, шумо метавонед аз он [`String`] созед.Шумо метавонед баръакс низ кунед.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Мо медонем, ки ин байтҳо эътибор доранд, аз ин рӯ мо `unwrap()`-ро истифода хоҳем кард.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Рақами UTF-8-рамзи калоншаванда.
///
/// Навъи `String` навъи маъмултарини сатр мебошад, ки дорои моликияти мундариҷаи сатр мебошад.Он бо ҳамтои қарзгирифтаи худ, ибтидоии [`str`] муносибати наздик дорад.
///
/// # Examples
///
/// Шумо метавонед `String` аз [a literal string][`str`] бо [`String::from`] созед:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Шумо метавонед [`char`]-ро ба `String` бо усули [`push`] замима кунед ва [`&str`]-ро бо усули [`push_str`] илова кунед:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Агар шумо vector аз UTF-8 байт дошта бошед, шумо метавонед аз он бо усули [`from_utf8`] `String` созед:
///
/// ```
/// // баъзе байтҳо, дар vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Мо медонем, ки ин байтҳо эътибор доранд, аз ин рӯ мо `unwrap()`-ро истифода хоҳем кард.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s ҳамеша UTF-8 эътибор доранд.Ин якчанд натиҷаҳо дорад, ки аввалинаш он аст, ки агар ба шумо сатри ғайри UTF-8 лозим бошад, [`OsString`]-ро баррасӣ кунед.Ин монанд аст, аммо бидуни маҳдудияти UTF-8.Манбаи дуюм он аст, ки шумо наметавонед ба `String` индексатсия кунед:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Индексатсия ҳамчун як амалиёти доимӣ пешбинӣ шудааст, аммо рамзгузории UTF-8 ба мо имкон намедиҳад.Ғайр аз он, маълум нест, ки индекс бояд чӣ гуна чизро баргардонад: байт, кодепунктур ё кластери графема.
/// Усулҳои [`bytes`] ва [`chars`] мутаносибан такроркунандагонро дар давоми дуи аввал бар мегардонанд.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s ["Deref`] "-ро иҷро мекунад<Target=str>, ва аз ин рӯ ҳамаи усулҳои ["str`]-ро ба мерос гиред.Илова бар ин, ин маънои онро дорад, ки шумо метавонед `String`-ро ба функсияе гузаронед, ки [`&str`] мегирад бо истифодаи амперсанд (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Ин як [`&str`] аз `String` эҷод мекунад ва онро мегузаронад. Ин табдилдиҳӣ хеле арзон аст ва аз ин рӯ, функсияҳо ["&str`]"-ро ҳамчун далел қабул мекунанд, агар ба `String` бо ягон сабаби мушаххас ниёз надошта бошанд.
///
/// Дар баъзе ҳолатҳо, Rust иттилооти кофӣ барои табдил додани ин табдили маъруф надорад, ки ҳамчун маҷбуркунии [`Deref`] маъруф аст.Дар мисоли зерин, як буридаи сатрии [`&'a str`][`&str`] trait `TraitExample`-ро амалӣ мекунад ва функсияи `example_func` ҳама чизеро иҷро мекунад, ки trait-ро татбиқ мекунад.
/// Дар ин ҳолат, ба Rust лозим меояд, ки ду тағироти номуайяне ба амал орад, ки Rust барои кор кардан имкон надорад.
/// Аз ин сабаб, намунаи зерин тартиб дода намешавад.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ду вариант вуҷуд доранд, ки ба ҷои он кор мекунанд.Аввалин бояд иваз кардани хатти `example_func(&example_string);` ба `example_func(example_string.as_str());` бо истифода аз усули [`as_str()`] барои ошкоро баровардани буридаи сатр, ки сатр дорад.
/// Роҳи дуюм `example_func(&example_string);` ба `example_func(&*example_string);` иваз мекунад.
/// Дар ин ҳолат мо як `String`-ро ба [`str`][`&str`] фарқ мекунем, пас ба [`str`][`&str`] ба [`&str`] бармегардем.
/// Роҳи дуввум idiomatic аст, аммо ҳарду кор мекунанд, ки конверсияро ба таври возеҳ иҷро кунанд, на ба такрори номуайян.
///
/// # Representation
///
/// `String` аз се ҷузъ иборат аст: нишоннамо ба баъзе байтҳо, дарозӣ ва зарфият.Нишондиҳанда ба буфери дохилии `String` барои нигоҳ доштани маълумотҳои худ ишора мекунад.Дарозӣ миқдори байтҳоест, ки ҳоло дар буфер нигоҳ дошта мешаванд ва ҳаҷм андозаи буферро дар байтҳо ташкил медиҳад.
///
/// Ҳамин тариқ, дарозӣ ҳамеша аз иқтидор камтар ё баробар хоҳад буд.
///
/// Ин буфер ҳамеша дар теппа нигоҳ дошта мешавад.
///
/// Шумо метавонед онҳоро бо усулҳои [`as_ptr`], [`len`] ва [`capacity`] дида бароед:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Инро ҳангоми мӯътадил кардани vec_into_raw_parts навсозӣ кунед.
/// // Пешгирии худкор партофтани маълумоти String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // достон нуздаҳ байт дорад
/// assert_eq!(19, len);
///
/// // Мо метавонем сатрро аз рӯи ptr, len ва азнавсозӣ барқарор кунем.
/// // Ин ҳама хатарнок аст, зеро мо барои эътимоднокии ҷузъҳо масъул ҳастем:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Агар `String` иқтидори кофӣ дошта бошад, илова кардани унсурҳо ба он дубора тақсим карда намешавад.Масалан, ин барномаро дида мебароем:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Ин натиҷаҳои зеринро медиҳад:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Дар аввал, мо ягон хотираи ҷудошуда надорем, аммо вақте ки мо ба сатр замима мекунем, он қобилияти онро ба таври мувофиқ меафзояд.Агар мо ба ҷои усули [`with_capacity`] ҷудо кардани иқтидори дурустро дар аввал истифода барем:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Мо бо натиҷаи гуногун хотима меёбем:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Дар ин ҷо, ҳеҷ зарурате барои тақсим кардани хотираи бештар дар дохили ҳалқа вуҷуд надорад.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Арзиши хатогии эҳтимолӣ ҳангоми табдил додани `String` аз байти UTF-8 vector.
///
/// Ин навъи навъи хато барои усули [`from_utf8`] дар [`String`] мебошад.
/// Он тавре сохта шудааст, ки тақсимоти ҷиддиро бодиққат пешгирӣ кунад: усули [`into_bytes`] байти vector-ро, ки ҳангоми кӯшиши табдили истифода шуда буд, бармегардонад.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Навъи [`Utf8Error`], ки аз ҷониби [`std::str`] пешниҳод шудааст, хатогие мебошад, ки ҳангоми табдил додани буридаи [`u8`] s ба [`&str`] рух дода метавонад.
/// Ба ин маъно, ин аналоги `FromUtf8Error` аст ва шумо метавонед онро аз `FromUtf8Error` тавассути усули [`utf8_error`] дастрас кунед.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// // баъзе байтҳои беэътибор, дар vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Арзиши хатогии эҳтимолӣ ҳангоми табдил додани `String` аз буридаи UTF-16 байтӣ.
///
/// Ин навъи навъи хато барои усули [`from_utf16`] дар [`String`] мебошад.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// `String` нави холӣ месозад.
    ///
    /// Бо дарназардошти он, ки `String` холӣ аст, ин ягон буферии аввалро ҷудо намекунад.Гарчанде ки ин маънои онро дорад, ки ин амалиёти ибтидоӣ хеле арзон аст, он метавонад баъдтар ҳангоми илова кардани маълумот метавонад аз ҳад зиёд тақсим карда шавад.
    ///
    /// Агар шумо тасаввуроте дошта бошед, ки `String` чӣ қадар маълумотро нигоҳ медорад, усули [`with_capacity`]-ро барои пешгирӣ аз ҳад зиёд тақсим кардан баррасӣ кунед.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// `String` нави холиро бо зарфияти мушаххас месозад.
    ///
    /// `String` буфери дохилӣ барои нигоҳ доштани маълумоти худ дорад.
    /// Иқтидор дарозии ин буферро ташкил медиҳад ва бо усули [`capacity`] дархост кардан мумкин аст.
    /// Ин усул `String`-и холиро ба вуҷуд меорад, аммо бо буферии ибтидоӣ, ки метавонад `capacity` байтро дар бар гирад.
    /// Ин вақте муфид аст, ки шумо метавонед як миқдори маълумотро ба `String` илова карда, шумораи тақсимоти онро кам кунед.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Агар иқтидори додашуда `0` бошад, тақсимот ба амал намеояд ва ин усул бо усули [`new`] шабеҳ аст.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Сатр дорои чархҳо нест, гарчанде ки он барои зиёдтар қобилият дорад
    /// assert_eq!(s.len(), 0);
    ///
    /// // Инҳо ҳама бидуни тақсимот анҷом дода мешаванд ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... аммо ин метавонад сатрро аз нав тақсим кунад
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): бо cfg(test) усули хосаи `[T]::to_vec`, ки барои ин таърифи усул зарур аст, дастрас нест.
    // Азбаски мо ин усулро барои санҷиш ниёз надорем, ман онро танҳо ҷудокунӣ медиҳам ЗМ барои маълумоти бештар ба модули slice::hack дар slice.rs нигаред
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector байтро ба `String` табдил медиҳад.
    ///
    /// Сатри ([`String`]) аз байтҳои ([`u8`]) ва vector аз байтҳои ([`Vec<u8>`]) аз байтҳо сохта шудаанд, бинобар ин, ин функсия дар байни ин ду табдил меёбад.
    /// На ҳама буррҳои байт `String`s эътибор надоранд, аммо: `String` талаб мекунад, ки он UTF-8 дуруст бошад.
    /// `from_utf8()` месанҷад, ки байтҳо UTF-8 эътибор доранд ва пас табдилро иҷро мекунад.
    ///
    /// Агар шумо мутмаин бошед, ки буридаи байтӣ ба UTF-8 эътибор дорад ва шумо намехоҳед ба болои изофаи чек эътибор диҳед, як нусхаи хатарноки ин функсия вуҷуд дорад, ки [`from_utf8_unchecked`] дорад, ки ҳамон рафторро дорад, вале чекро аз даст медиҳад.
    ///
    ///
    /// Ин усул барои нусхабардории vector ба хотири самаранокӣ ғамхорӣ мекунад.
    ///
    /// Агар ба ҷои `String` ба шумо [`&str`] лозим шавад, [`str::from_utf8`]-ро дида бароед.
    ///
    /// Баръакси ин усул [`into_bytes`] аст.
    ///
    /// # Errors
    ///
    /// [`Err`]-ро бармегардонад, агар бурида UTF-8 набошад бо тавсиф дар бораи он ки чаро байтҳои пешниҳодшуда UTF-8 нестанд.vector, ки шумо ба он кӯчидед, низ дохил карда шудааст.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳо, дар vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Мо медонем, ки ин байтҳо эътибор доранд, аз ин рӯ мо `unwrap()`-ро истифода хоҳем кард.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Байтҳои нодуруст:
    ///
    /// ```
    /// // баъзе байтҳои беэътибор, дар vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Барои тафсилоти бештар дар бораи он, ки шумо бо ин хато чӣ кор карда метавонед, ба ҳуҷҷатҳои [`FromUtf8Error`] нигаред.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Як буридаи байтро ба сатр, аз ҷумла аломатҳои беэътибор табдил медиҳад.
    ///
    /// Сатрҳо аз байтҳои ([`u8`]) ва як буридаи байтҳои ([`&[u8]`][byteslice]) аз байтҳо сохта шудаанд, бинобар ин, ин функсия дар байни ин ду табдил меёбад.На ҳама буррҳои байт сатрҳои эътиборнок нестанд, аммо: сатрҳо барои дуруст будани UTF-8 талаб карда мешаванд.
    /// Ҳангоми ин табдил, `from_utf8_lossy()` ҳама гуна пайдарпаии UTF-8-ро бо [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] иваз мекунад, ки чунин менамояд:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Агар шумо мутмаин бошед, ки буридаи байтӣ ба UTF-8 эътибор дорад ва шумо намехоҳед ба изофаи табдили он мубтало шавед, версияи хатарноки ин функсия, [`from_utf8_unchecked`] вуҷуд дорад, ки ҳамон рафторро дорад, аммо чекҳоро аз даст медиҳад.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ин функсия [`Cow<'a, str>`] бар мегардонад.Агар буридаи байтии мо UTF-8-и беэътибор бошад, пас мо бояд аломатҳои ивазшударо гузорем, ки андозаи сатрро тағир медиҳад ва аз ин рӯ, `String` талаб мекунад.
    /// Аммо агар он аллакай UTF-8 эътибор дошта бошад, ба мо тақсимоти нав лозим нест.
    /// Ин навъи бозгашт ба мо имкон медиҳад, ки ҳарду ҳолатро ҳал кунем.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳо, дар vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Байтҳои нодуруст:
    ///
    /// ```
    /// // баъзе байтҳои беэътибор
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Рамзгузории UTF-16 -ро бо рамзи vector `v` ба `String`, баргардонидани [`Err`], агар `v` ягон маълумоти нодуруст дошта бошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Ин тавассути ҷамъоварӣ карда намешавад: : <Result<_, _>> () бо сабабҳои иҷро.
        // FIXME: ҳангоми баста шудани #48994 функсияро дубора содда кардан мумкин аст.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Рамзи UTF-16 -ро бо рамзи рамзи `v` ба `String` иваз кунед ва маълумоти нодурустро бо [the replacement character (`U+FFFD`)][U+FFFD] иваз кунед.
    ///
    /// Баръакси [`from_utf8_lossy`], ки [`Cow<'a, str>`]-ро бармегардонад, `from_utf16_lossy` `String`-ро бармегардонад, зеро табдили UTF-16 ба UTF-8 тақсимоти хотираро талаб мекунад.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// `String`-ро ба ҷузъҳои хоми худ тақсим мекунад.
    ///
    /// Нишондиҳандаи хомро ба маълумоти асосӣ, дарозии сатр (дар байт) ва иқтидори ҷудошудаи маълумот (дар байт) бармегардонад.
    /// Ин ҳамон далелҳо бо ҳамон тартиб бо далелҳои [`from_raw_parts`] мебошанд.
    ///
    /// Пас аз занг задан ба ин функсия, даъваткунанда барои хотираи қаблан аз ҷониби `String` идорашаванда масъул аст.
    /// Ягона роҳи ин кор табдил додани нишоннамои хом, дарозӣ ва иқтидори хом ба `String` бо функсияи [`from_raw_parts`] мебошад, ки ба деструктор имкон медиҳад, ки тозакуниро анҷом диҳад.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Аз дарозӣ, иқтидор ва нишоннамо `String` нав месозад.
    ///
    /// # Safety
    ///
    /// Ин аз сабаби шумораи инвариантҳо, ки тафтиш карда намешаванд, хеле хатарнок аст:
    ///
    /// * Хотира дар `buf` бояд қаблан аз ҷониби ҳамон тақсимкунандае, ки китобхонаи стандартӣ истифода мебарад, тақсим карда шуда бошад ва бо масири дақиқ 1.
    /// * `length` бояд камтар аз `capacity` ё баробар бошад.
    /// * `capacity` бояд арзиши дуруст бошад.
    /// * Аввалин байтҳои `length` дар `buf` бояд UTF-8 эътибор дошта бошанд.
    ///
    /// Вайрон кардани инҳо метавонад мушкилот ба монанди вайрон кардани сохторҳои иттилоотии дохилии тақсимкунандаро ба миён орад.
    ///
    /// Моликияти `buf` ба `String` самаранок интиқол дода мешавад, ки он метавонад мундариҷаи хотираро, ки бо хости худ нишон дода шудааст, тақсим кунад, аз нав тақсим кунад ё тағир диҳад.
    /// Боварӣ ҳосил кунед, ки пас аз занг задан ба ин функсия, дигар ҳеҷ чиз нишондиҳандаро истифода намебарад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Инро ҳангоми мӯътадил кардани vec_into_raw_parts навсозӣ кунед.
    ///     // Пешгирии худкор партофтани маълумоти String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// vector байтро ба `String` табдил медиҳад, бе тафтиши он, ки сатр дорои UTF-8 эътибор аст.
    ///
    /// Барои тафсилоти бештар ба версияи бехатар, [`from_utf8`] нигаред.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро он дуруст будани UTF-8 байтҳои ба он гузаронидаро тафтиш намекунад.
    /// Агар ин маҳдудият вайрон карда шавад, он метавонад боиси мушкилоти бехатарии хотира бо корбарони future аз `String` гардад, зеро боқимондаи китобхонаи стандартӣ чунин мешуморанд, ки "String`s UTF-8 эътибор доранд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳо, дар vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// `String`-ро ба байти vector табдил медиҳад.
    ///
    /// Ин `String`-ро истеъмол мекунад, бинобар ин ба мо нусхабардории мундариҷаи он лозим нест.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Буридаи сатрро дар бар мегирад, ки тамоми `String`-ро дар бар мегирад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// `String`-ро ба як буридаи сатри тағирёбанда табдил медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Як буридаи сатрро ба охири ин `String` илова мекунад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Иқтидори ин "сатр"-ро дар байт бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Кафолат медиҳад, ки иқтидори ин "String" ҳадди аққал `additional` байт аз дарозии он калонтар аст.
    ///
    /// Агар имконпазир бошад, қобилиятро бештар аз `additional` байт зиёд кардан мумкин аст.
    ///
    ///
    /// Агар шумо ин рафтори "at least"-ро нахоҳед, ба усули [`reserve_exact`] нигаред.
    ///
    /// # Panics
    ///
    /// Panics агар иқтидори нав аз [`usize`] зиёдтар шавад.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ин метавонад иқтидорро дар асл зиёд накунад:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ҳоло дарозии 2 ва зарфияти 10 дорад
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Азбаски мо аллакай 8 иқтидори иловагӣ дорем, инро ...
    /// s.reserve(8);
    ///
    /// // ... аслан зиёд намешавад.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Кафолат медиҳад, ки иқтидори ин "String" аз дарозии он `additional` байт калонтар аст.
    ///
    /// Истифодаи усули [`reserve`]-ро баррасӣ кунед, агар шумо комилан аз ҷудокунанда хубтар намедонед.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics агар иқтидори нав аз `usize` зиёдтар шавад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Ин метавонад иқтидорро дар асл зиёд накунад:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ҳоло дарозии 2 ва зарфияти 10 дорад
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Азбаски мо аллакай 8 иқтидори иловагӣ дорем, инро ...
    /// s.reserve_exact(8);
    ///
    /// // ... аслан зиёд намешавад.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Кӯшиш мекунад, ки иқтидорро барои ҳадди аққал `additional` унсури бештар дар `String` додашуда захира кунад.
    /// Маҷмӯа метавонад барои пешгирӣ аз тақсимоти зуд зуд фазои бештаре захира кунад.
    /// Пас аз занг задан ба `reserve`, иқтидор аз `self.len() + additional` зиёдтар ё баробар хоҳад буд.
    /// Агар иқтидор аллакай кофӣ бошад, ҳеҷ кор намекунад.
    ///
    /// # Errors
    ///
    /// Агар иқтидор зиёд шавад ё тақсимкунанда дар бораи нокомӣ хабар диҳад, пас хато баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Хотираро пешакӣ захира кунед, агар он имконнопазир бошад
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Акнун мо медонем, ки ин наметавонад OOM дар миёнаи кори мураккаби мо
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Кӯшиш мекунад, ки зарфияти ҳадди аққалро барои дақиқ `additional` унсури бештаре, ки ба `String` додашуда ворид карда шаванд, захира кунад.
    ///
    /// Пас аз занг задан ба `reserve_exact`, иқтидор аз `self.len() + additional` зиёдтар ё баробар хоҳад буд.
    /// Агар иқтидор аллакай кофӣ бошад, ҳеҷ кор намекунад.
    ///
    /// Дар хотир доред, ки ҷудокунанда метавонад ба коллексия назар ба дархост фазои бештар диҳад.
    /// Аз ин рӯ, иқтидорро ба ҳадди аққал бовар кардан мумкин нест.
    /// Агар ворид кардани future дар назар дошта шавад, ба `reserve` афзалият диҳед.
    ///
    /// # Errors
    ///
    /// Агар иқтидор зиёд шавад ё тақсимкунанда дар бораи нокомӣ хабар диҳад, пас хато баргардонида мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Хотираро пешакӣ захира кунед, агар он имконнопазир бошад
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Акнун мо медонем, ки ин наметавонад OOM дар миёнаи кори мураккаби мо
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Иқтидори ин `String`-ро барои дарозии он кам мекунад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Иқтидори ин `String`-ро бо ҳудуди поёнӣ коҳиш медиҳад.
    ///
    /// Иқтидор ҳадди аққал ҳамчун дарозӣ ва арзиши додашуда боқӣ хоҳад монд.
    ///
    ///
    /// Агар иқтидори ҳозира аз ҳадди поёнӣ камтар бошад, ин ғайриимкон аст.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// [`char`] додашударо то охири ин `String` илова мекунад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Буридаи байтӣ аз мундариҷаи "String"-ро бармегардонад.
    ///
    /// Баръакси ин усул [`from_utf8`] аст.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Ин `String`-ро ба дарозии муайян кӯтоҳ мекунад.
    ///
    /// Агар `new_len` аз дарозии ҷории сатр зиёдтар бошад, ин таъсир надорад.
    ///
    ///
    /// Дар хотир доред, ки ин усул ба иқтидори ҷудошудаи сатр ягон таъсир надорад
    ///
    /// # Panics
    ///
    /// Panics агар `new_len` дар сарҳади [`char`] ҷойгир набошад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Аломати охиринро аз буферии сатр хориҷ мекунад ва бармегардонад.
    ///
    /// Агар `String` холӣ бошад, [`None`]-ро бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// [`char`]-ро аз ин `String` дар ҳолати байтӣ хориҷ мекунад ва бармегардонад.
    ///
    /// Ин амалиёт *O*(*n*) аст, зеро он нусхабардории ҳар як унсури буфериро талаб мекунад.
    ///
    /// # Panics
    ///
    /// Panics агар `idx` аз дарозии `String` калонтар ё ба он баробар бошад ё дар ҳудуди [`char`] ҷойгир набошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Ҳама мутобиқати намунаи `pat` дар `String` хориҷ кунед.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Мувофиқатҳо такроран ошкор ва хориҷ карда мешаванд, аз ин рӯ дар ҳолатҳое, ки намунаҳо бо ҳам мепайвандад, танҳо намунаи аввал хориҷ карда мешавад:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // БЕХАТАР: : оғоз ва анҷом дар ҳудуди utf8 байтӣ дар як хоҳад буд
        // ҳуҷҷатҳои Ҷустуҷӯ
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Танҳо аломатҳои муайянкардаи предикатро нигоҳ медорад.
    ///
    /// Ба ибораи дигар, ҳамаи аломатҳои `c`-ро хориҷ кунед, то ки `f(c)` `false` баргардонад.
    /// Ин усул дар ҷои худ амал мекунад ва ҳар як персонажро дақиқ як маротиба аз рӯи тартиби аввал ташриф меорад ва тартиби аломатҳои ҳифзшударо нигоҳ медорад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Тартиби дақиқ метавонад барои пайгирии ҳолати беруна, ба монанди индекс, муфид бошад.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Idx-ро ба чарти оянда ишора кунед
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Аломатеро ба ин `String` дар ҳолати байт дохил мекунад.
    ///
    /// Ин амалиёт *O*(*n*) аст, зеро он нусхабардории ҳар як унсури буфериро талаб мекунад.
    ///
    /// # Panics
    ///
    /// Panics агар `idx` аз дарозии "String" калонтар бошад ё дар ҳудуди [`char`] ҷойгир набошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Як буридаи сатрро ба ин `String` дар ҳолати байт дохил мекунад.
    ///
    /// Ин амалиёт *O*(*n*) аст, зеро он нусхабардории ҳар як унсури буфериро талаб мекунад.
    ///
    /// # Panics
    ///
    /// Panics агар `idx` аз дарозии "String" калонтар бошад ё дар ҳудуди [`char`] ҷойгир набошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Истиноди тағиршавандаро ба мундариҷаи ин `String` бармегардонад.
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро он дуруст будани UTF-8 байтҳои ба он гузаронидаро тафтиш намекунад.
    /// Агар ин маҳдудият вайрон карда шавад, он метавонад боиси мушкилоти бехатарии хотира бо корбарони future аз `String` гардад, зеро боқимондаи китобхонаи стандартӣ чунин мешуморанд, ки "String`s UTF-8 эътибор доранд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Дарозии ин `String`-ро бо байт бармегардонад, на [`char`] s ё графемаро.
    /// Ба ибораи дигар, шояд он чизе набошад, ки инсон дарозии сатрро баррасӣ мекунад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// `true`-ро бармегардонад, агар ин `String` дарозии сифр дошта бошад ва дар акси ҳол `false`.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Дар индекси байти додашуда сатрро ба ду тақсим мекунад.
    ///
    /// `String`-и нав ҷудошударо бармегардонад.
    /// `self` дорои байтҳои `[0, at)` ва `String` баргашта байтҳои `[at, len)` мебошанд.
    /// `at` бояд дар сарҳади нуқтаи рамзи UTF-8 бошад.
    ///
    /// Дар хотир доред, ки иқтидори `self` тағир намеёбад.
    ///
    /// # Panics
    ///
    /// Panics агар `at` дар сарҳади нуқтаи рамзи `UTF-8` набошад, ё агар он аз нуқтаи охирини рамзи сатр бошад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Ин `String`-ро бурида, ҳама мундариҷаро нест мекунад.
    ///
    /// Дар ҳоле ки ин маънои онро дорад, ки `String` дарозии сифр хоҳад дошт, аммо он ба зарфияти он даст намерасонад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Итератори дренажиро эҷод мекунад, ки доираи муайянро дар `String` хориҷ мекунад ва `chars` хориҷшударо медиҳад.
    ///
    ///
    /// Note: Диапазони унсурҳо хориҷ карда мешаванд, ҳатто агар итератор то охир истеъмол карда нашавад.
    ///
    /// # Panics
    ///
    /// Panics агар нуқтаи ибтидоӣ ё нуқтаи ниҳоӣ дар сарҳади [`char`] ҷойгир набошад ё онҳо аз ҳудуд берун бошанд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Диапазонро то сатри β аз сатр хориҷ кунед
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Як қатор пурраи сатрро тоза мекунад
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Бехатарии хотира
        //
        // Версияи сатри Drain масъалаҳои бехатарии хотираи версияи vector надорад.
        // Маълумот танҳо байтҳои оддӣ мебошанд.
        // Азбаски бартараф кардани диапазон дар Drop рӯй медиҳад, агар iterator Drain фош шавад, бартарафсозӣ ба амал намеояд.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Ду қарзи ҳамзамонро бароред.
        // String &mut то даме ки такроркунӣ ба охир нарасад, дар Drop дастрас карда намешавад.
        let self_ptr = self as *mut _;
        // БЕХАТАР: : `slice::range` ва `is_char_boundary` санҷишҳои ҳудуди мувофиқро анҷом медиҳанд.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Диапазони муайяншударо дар сатр хориҷ мекунад ва онро бо сатри додашуда иваз мекунад.
    /// Сатри додашуда ба дарозии баробари диапазон ниёз надорад.
    ///
    /// # Panics
    ///
    /// Panics агар нуқтаи ибтидоӣ ё нуқтаи ниҳоӣ дар сарҳади [`char`] ҷойгир набошад ё онҳо аз ҳудуд берун бошанд.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Диапазонро то β аз сатр иваз кунед
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Бехатарии хотира
        //
        // Replace_range масъалаҳои амнияти хотираи vector Splice надорад.
        // аз версияи vector.Маълумот танҳо байтҳои оддӣ мебошанд.

        // ҲУШДОР: Даровардани ин тағирёбанда (#81138) беасос хоҳад буд
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ҲУШДОР: Даровардани ин тағирёбанда (#81138) беасос хоҳад буд
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Истифодаи `range` дубора (#81138) беасос хоҳад буд Мо тахмин мезанем, ки ҳудуди гузоришкардаи `range` бетағйир боқӣ мемонад, аммо амалисозии зиддият метавонад байни зангҳо тағир ёбад
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ин `String`-ро ба [`Box`]`<`[`str`] `>` табдил медиҳад.
    ///
    /// Ин ҳама гуна иқтидори барзиёдро коҳиш медиҳад.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Як буридаи байти [`u8`] s-ро, ки кӯшиши ба `String` табдил доданро доштанд, бармегардонад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳои беэътибор, дар vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Байтеро, ки кӯшиши ба `String` табдил доданро доштанд, бармегардонад.
    ///
    /// Ин усул бодиққат сохта шудааст, то ҷудо карда нашавад.
    /// Он хаторо сарфи назар карда, байтро берун мекунад, то нусхаи байтро ниёз надошта бошад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳои беэътибор, дар vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Барои гирифтани тафсилоти бештар дар бораи нокомии табдили `Utf8Error` биёваред.
    ///
    /// Навъи [`Utf8Error`], ки аз ҷониби [`std::str`] пешниҳод шудааст, хатогие мебошад, ки ҳангоми табдил додани буридаи [`u8`] s ба [`&str`] рух дода метавонад.
    /// Аз ин ҷиҳат, он шабеҳи `FromUtf8Error` аст.
    /// Барои тафсилоти бештар дар бораи истифодаи он, ба ҳуҷҷатҳои он нигаред.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// // баъзе байтҳои беэътибор, дар vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // байти аввал дар ин ҷо нодуруст аст
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Азбаски мо дар болои "String`s" такрор мекунем, мо метавонем ҳадди аққал як тақсимотро тавассути гирифтани сатри аввал аз итератор ва илова кардани ҳамаи сатрҳои минбаъда пешгирӣ кунем.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Азбаски мо аз болои CoW такрор карда истодаем, мо метавонем (potentially) ҳадди аққал аз як тақсимот тавассути гирифтани ашёи аввал ва илова кардани ҳамаи ашёи баъдӣ пешгирӣ кунем.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Нишондиҳандаи роҳатие, ки ба XL `&str` намояндагӣ мекунад.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// `String` холӣ месозад.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Оператори `+`-ро барои ҳамбастагии ду сатр татбиқ мекунад.
///
/// Ин `String`-ро дар тарафи чап истеъмол мекунад ва буфери онро дубора истифода мебарад (агар зарур бошад, онро меафзояд).
/// Ин барои он ҷудо карда мешавад, ки `String` нав ҷудо карда нашавад ва мундариҷаи он дар ҳар як амалиёт нусхабардорӣ карда шавад, ки ин ба вақти корӣ оварда мерасонад *O*(*n*^ 2) ҳангоми сохтани сатри *n*-байтӣ бо пайвасти такрорӣ.
///
///
/// Ришта дар тарафи рост танҳо қарз гирифта мешавад;мундариҷаи он ба `String` баргашта нусхабардорӣ карда мешавад.
///
/// # Examples
///
/// Муттаҳидсозии ду "сатр" аввалро бо қимат мегирад ва дуввумро қарз мегирад:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` кӯчонида шудааст ва дигар дар ин ҷо истифода бурда намешавад.
/// ```
///
/// Агар шумо хоҳед, ки истифодаи `String`-и аввалро идома диҳед, шумо метавонед онро клонед ва ба ҷои он ба клон илова кунед:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` дар ин ҷо то ҳол эътибор дорад.
/// ```
///
/// Пайваст кардани иловаро `&str` бо роҳи табдил додани якум ба `String` анҷом дода мешавад:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Оператори `+=`-ро барои илова ба `String` татбиқ мекунад.
///
/// Ин ҳамон рафторро бо усули [`push_str`][String::push_str] дорад.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Як тахаллуси навъи барои [`Infallible`].
///
/// Ин тахаллус барои мутобиқати қафо вуҷуд дорад ва шояд дар ниҳоят бекор карда шавад.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait барои табдил додани арзиш ба `String`.
///
/// Ин trait ба тариқи худкор барои ҳама намудҳое амалӣ карда мешавад, ки [`Display`] trait-ро татбиқ мекунанд.
/// Ҳамин тариқ, `ToString` набояд мустақиман амалӣ карда шавад:
/// [`Display`] бояд ба ҷои он амалӣ карда шавад ва шумо татбиқи `ToString`-ро ройгон ба даст меоред.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Арзиши додашударо ба `String` табдил медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Дар ин татбиқ, усули `to_string` panics агар татбиқи `Display` хаторо баргардонад.
/// Ин татбиқи нодурусти `Display`-ро нишон медиҳад, зеро `fmt::Write for String` ҳеҷ гоҳ хатогиро барнамегардонад.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Дастури маъмул ин аст, ки ба вазифаҳои умумӣ дохил карда нашавад.
    // Аммо, хориҷ кардани `#[inline]` аз ин усул боиси регрессияҳои бесабаб мегардад.
    // Ба <https://github.com/rust-lang/rust/pull/74852> нигаред, охирин кӯшиши кӯшиши нест кардани он.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// `&mut str`-ро ба `String` табдил медиҳад.
    ///
    /// Натиҷа дар теппа ҷудо карда мешавад.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: озмоиш libstd-ро мекашад, ки дар ин ҷо хатогиҳо ба амал меоянд
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Буридаи додашудаи `str`-ро ба `String` табдил медиҳад.
    /// Ҷолиби диққат аст, ки буридаи `str` моликият дорад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// `String`-и додашударо ба буридаи қуттии `str`, ки тааллуқ дорад, табдил медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Буридаи сатрро ба варианти қарзӣ табдил медиҳад.
    /// Ҷудо кардани теппа иҷро карда намешавад ва сатр нусхабардорӣ карда намешавад.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Сатрро ба варианти хос табдил медиҳад.
    /// Ҷудо кардани теппа иҷро карда намешавад ва сатр нусхабардорӣ карда намешавад.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Истиноди сатрро ба варианти қарзӣ табдил медиҳад.
    /// Ҷудо кардани теппа иҷро карда намешавад ва сатр нусхабардорӣ карда намешавад.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// `String` додашударо ба vector `Vec` табдил медиҳад, ки арзишҳои навъи `u8` дорад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Итератори дренажӣ барои `String`.
///
/// Ин структура бо усули [`drain`] дар [`String`] сохта шудааст.
/// Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Стринг дар деструктори ҳамчун&'mut mut истифода мешавад
    string: *mut String,
    /// Оғози қисми барои нест кардани
    start: usize,
    /// Хотимаи қисмат барои нест кардан
    end: usize,
    /// Диапазони ҷории боқимонда барои нест кардан
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain-ро истифода баред.
            // "Reaffirm" ҳудудҳо барои пешгирӣ кардани рамзи panic дубора тафтиш карда мешаванд.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Сатрҳои боқимондаи (зерсохтори) ин итераторро ҳамчун бурида бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef ҳангоми ба эътидол овардан ба поён оварда мерасонад.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Ҳангоми ба эътидол овардани `string_drain_as_str` изҳори назар накунед.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>барои Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> барои Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}