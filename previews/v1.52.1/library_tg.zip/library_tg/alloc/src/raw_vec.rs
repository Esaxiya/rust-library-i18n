#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Мазмуни хотираи нав номаълум аст.
    Uninitialized,
    /// Хотираи нав ба сифр кафолат дода мешавад.
    Zeroed,
}

/// Як утилитаи сатҳи паст барои тақсимоти эргономикӣ, тақсимоти дубора ва тақсимоти буферии хотира дар теппа бе ташвиш аз ҳама парвандаҳои кунҷӣ.
///
/// Ин навъи олӣ барои сохтани сохторҳои иттилоотии шахсии худ ба монанди Vec ва VecDeque хеле хуб аст.
/// Алалхусус:
///
/// * `Unique::dangling()`-ро дар намудҳои андозаи сифр истеҳсол мекунад.
/// * `Unique::dangling()` дар тақсимоти дарозии сифр истеҳсол мекунад.
/// * Озод кардани `Unique::dangling()`-ро пешгирӣ мекунад.
/// * Ҳама лаҳзаҳои ҳисоббаробаркуниро ба даст меоранд (онҳоро ба "capacity overflow" panics мусоидат мекунанд).
/// * Муҳофизат аз системаҳои 32-битӣ, ки беш аз isize::MAX байт ҷудо мекунанд.
/// * Посбонон бар зиёд шудани дарозии шумо.
/// * Ба `handle_alloc_error` барои тақсимоти хато занг мезанад.
/// * Дорои `ptr::Unique` аст ва аз ин рӯ ба корбар тамоми манфиатҳои марбутаро тақдим мекунад.
/// * Зиёда аз баргардондашударо барои истифодаи бузургтарин иқтидори мавҷуда истифода мекунад.
///
/// Ин намуд ба ҳар ҳол хотираи идорашавандаро тафтиш намекунад.Ҳангоми партофтан *хотираи онро озод мекунад, аммо* тарки он нахоҳад кард.
/// Коркарди ашёи воқеӣ * ҳифзшуда дар дохили `RawVec` ба корбари `RawVec` вобаста аст.
///
/// Дар хотир доред, ки барзиёдии намудҳои сифр ҳамеша беохир аст, бинобар ин `capacity()` ҳамеша `usize::MAX` бармегардонад.
/// Ин маънои онро дорад, ки шумо бояд ҳангоми кушодани ин намуд бо `Box<[T]>` эҳтиёт шавед, зеро `capacity()` дарозӣ нахоҳад дод.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Ин аз он сабаб мавҷуд аст, ки `#[unstable]` `const fn`s набояд ба `min_const_fn` мувофиқат кунад ва аз ин рӯ онҳоро дар"min_const_fn` "низ хондан мумкин нест.
    ///
    /// Агар шумо `RawVec<T>::new` ё вобастагиҳоро тағир диҳед, лутфан эҳтиёт шавед, то чизе, ки воқеан `min_const_fn`-ро вайрон кунад, ҷорӣ накунед.
    ///
    /// NOTE: Мо метавонем аз ин рахнагӣ ҷилавгирӣ кунем ва мутобиқатро бо баъзе атрибутҳои `#[rustc_force_min_const_fn]`, ки мувофиқатро бо `min_const_fn` талаб мекунад, тафтиш кунем, аммо ҳатман иҷозат намедиҳад, ки онро дар `stable(...) const fn`/рамзи корбар, ки ҳангоми мавҷуд будани `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ба `foo` имкон намедиҳад, даъват намоем.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Бузургтарин `RawVec` имконпазирро (дар теппаи система) бе тақсим месозад.
    /// Агар `T` андозаи мусбат дошта бошад, пас ин `RawVec`-ро бо иқтидори `0` месозад.
    /// Агар `T` андозаи сифр бошад, пас он `RawVec`-ро бо иқтидори `usize::MAX` месозад.
    /// Барои татбиқи ҷудошудаи таъхирнопазир муфид.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `RawVec` (дар теппаи система) бо дақиқи иқтидор ва мувофиқат барои `[T; capacity]` месозад.
    /// Ин ба даъвати `RawVec::new` баробар аст, вақте ки `capacity` `0` ё `T` андозаи сифр бошад.
    /// Дар хотир доред, ки агар `T` андозаи сифр дошта бошад, ин маънои онро дорад, ки шумо `RawVec`-ро бо иқтидори дархостшуда нахоҳед гирифт *.
    ///
    /// # Panics
    ///
    /// Panics агар иқтидори дархостшуда аз `isize::MAX` байт зиёд бошад.
    ///
    /// # Aborts
    ///
    /// Қатъ кардани OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Мисли `with_capacity`, аммо кафолат медиҳад, ки буфер сифр карда мешавад.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec`-ро аз нишондиҳанда ва иқтидор барқарор мекунад.
    ///
    /// # Safety
    ///
    /// `ptr` бояд ҷудо карда шавад (дар теппаи система) ва бо `capacity` додашуда.
    /// `capacity` наметавонад аз `isize::MAX` барои намудҳои андозаи зиёд бошад.(танҳо нигаронӣ дар системаҳои 32-битӣ).
    /// ZST vectors метавонад то `usize::MAX` иқтидор дошта бошад.
    /// Агар `ptr` ва `capacity` аз `RawVec` баромада бошанд, пас ин кафолат дода мешавад.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs ночиз гунг ҳастанд.Гузариш ба:
    // - 8 агар андозаи элемент 1 бошад, зеро ҳама гуна тақсимкунандагони теппа эҳтимолан дархости камтар аз 8 байтро то ҳадди ақалл 8 байтро ҷамъ мекунанд.
    //
    // - 4 агар элементҳо андозаи миёна дошта бошанд (<=1 KiB).
    // - 1 дар акси ҳол, барои пешгирӣ кардани фазои аз ҳад зиёд барои Vecs хеле кӯтоҳ.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Мисли `new`, аммо бар интихоби ҷудокунанда барои `RawVec` баргашта параметр карда шудааст.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` маънои "unallocated" дорад.намудҳои андозаи сифр сарфи назар карда мешаванд.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Мисли `with_capacity`, аммо бар интихоби ҷудокунанда барои `RawVec` баргашта параметр карда шудааст.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Мисли `with_capacity_zeroed`, аммо бар интихоби ҷудокунанда барои `RawVec` баргашта параметр карда шудааст.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>`-ро ба `RawVec<T>` табдил медиҳад.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Тамоми буферро ба `Box<[MaybeUninit<T>]>` бо `len`-и муайян табдил медиҳад.
    ///
    /// Дар хотир доред, ки ин ҳама тағиротҳои `cap`-ро, ки метавонанд иҷро карда шаванд, дуруст барқарор мекунад.(Барои тафсилот ба тавсифи намуд нигаред.)
    ///
    /// # Safety
    ///
    /// * `len` бояд аз иқтидори ба наздикӣ дархостшуда зиёдтар ё баробар бошад ва
    /// * `len` бояд камтар ё ба `self.capacity()` баробар бошад.
    ///
    /// Дар хотир доред, ки иқтидори дархостшуда ва `self.capacity()` метавонанд фарқ кунанд, зеро тақсимкунанда метавонист аз ҳад зиёд тақсим кунад ва блоки хотираи бештарро баргардонад.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Низоми санҷишро тафтиш кунед, нисфи талаботи бехатариро тафтиш кунед (мо нисфи дигарашро тафтиш карда наметавонем).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Мо `unwrap_or_else`-ро дар ин ҷо пешгирӣ мекунем, зеро он миқдори LLVM IR тавлидшударо bloats мекунад.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec`-ро аз нишоннамо, иқтидор ва ҷудокунанда барқарор мекунад.
    ///
    /// # Safety
    ///
    /// `ptr` бояд тақсим карда шавад (тавассути тақсимкунандаи додашуда `alloc`) ва бо `capacity` додашуда.
    /// `capacity` наметавонад аз `isize::MAX` барои намудҳои андозаи зиёд бошад.
    /// (танҳо нигаронӣ дар системаҳои 32-битӣ).
    /// ZST vectors метавонад то `usize::MAX` иқтидор дошта бошад.
    /// Агар `ptr` ва `capacity` аз `RawVec` тавассути `alloc` сохта шуда бошанд, пас ин кафолат дода мешавад.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Нишондиҳандаи хомро то оғози тақсимот мегирад.
    /// Дар хотир доред, ки ин `Unique::dangling()` аст, агар `capacity == 0` ё `T` андозаи сифр дошта бошад.
    /// Дар ҳолати қаблӣ, шумо бояд эҳтиёт бошед.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Иқтидори тақсимотро ба даст меорад.
    ///
    /// Агар `T` андозаи сифр дошта бошад, ин ҳамеша `usize::MAX` хоҳад буд.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Истиноди муштаракро ба ҷудокунандаи дастгирии ин `RawVec` бармегардонад.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Мо як қисми хотираи ҷудошуда дорем, бинобар ин мо метавонем санҷишҳои вақти кориро убур намуда, тарҳбандии ҳозираи худро ба даст орем.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Кафолат медиҳад, ки буфер ҳадди аққал фазои кофӣ барои нигоҳ доштани унсурҳои `len + additional` дорад.
    /// Агар он аллакай иқтидори кофӣ надошта бошад, майдони кофӣ ва фазои сусти бароҳатро барои ҷобаҷогузории амортизацияшуда *O*(1) ҷудо мекунад.
    ///
    /// Ин рафторро маҳдуд мекунад, агар он ба таври бесабаб худро ба panic расонад.
    ///
    /// Агар `len` аз `self.capacity()` зиёд бошад, ин метавонад дарвоқеъ фазои дархостшударо ҷудо кунад.
    /// Ин дар ҳақиқат хатарнок нест, аммо рамзи хатарноке, ки шумо * менависед, ки ба рафтори ин функсия такя мекунад, метавонад вайрон шавад.
    ///
    /// Ин барои амалисозии амалиёти пурқувват ба монанди `extend` беҳтарин аст.
    ///
    /// # Panics
    ///
    /// Panics агар иқтидори нав аз `isize::MAX` байт зиёд бошад.
    ///
    /// # Aborts
    ///
    /// Қатъ кардани OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // агар захира аз `isize::MAX` зиёд бошад, захира қатъ карда мешуд ё ба ваҳм меафтод, бинобар ин ҳоло бехатар аст.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Ҳамон тавре ки `reserve`, аммо ба ҷои воҳима ё исқоти ҳамл хаторо бармегардонад.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Кафолат медиҳад, ки буфер ҳадди аққал фазои кофӣ барои нигоҳ доштани унсурҳои `len + additional` дорад.
    /// Агар ин кор аллакай нашуда бошад, миқдори ҳадди аққали хотираи заруриро аз нав тақсим мекунад.
    /// Умуман, ин маҳз миқдори хотираи зарурӣ хоҳад буд, аммо дар асл принсипатор метавонад озодтар аз он чизе, ки мо талаб кардем, баргардонад.
    ///
    ///
    /// Агар `len` аз `self.capacity()` зиёд бошад, ин метавонад дарвоқеъ фазои дархостшударо ҷудо кунад.
    /// Ин дар ҳақиқат хатарнок нест, аммо рамзи хатарноке, ки шумо * менависед, ки ба рафтори ин функсия такя мекунад, метавонад вайрон шавад.
    ///
    /// # Panics
    ///
    /// Panics агар иқтидори нав аз `isize::MAX` байт зиёд бошад.
    ///
    /// # Aborts
    ///
    /// Қатъ кардани OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Ҳамон тавре ки `reserve_exact`, аммо ба ҷои воҳима ё исқоти ҳамл хаторо бармегардонад.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Ҷудокуниро то ҳаҷми муайян кам мекунад.
    /// Агар миқдори додашуда 0 бошад, дар асл комилан ҷудо мешавад.
    ///
    /// # Panics
    ///
    /// Panics, агар миқдори додашуда аз иқтидори ҷорӣ *калонтар* бошад.
    ///
    /// # Aborts
    ///
    /// Қатъ кардани OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Бармегардад, агар буфер афзоиш ёбад, то иқтидори иловагии заруриро иҷро кунад.
    /// Асосан барои қабули зангҳои фармоишӣ бидуни фарогирии `grow` истифода мешавад.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ин усул одатан борҳо таҳия карда мешавад.Аз ин рӯ, мо мехоҳем, ки он то ҳадди имкон хурд бошад, вақтҳои тартибдиҳӣ беҳтар карда шаванд.
    // Аммо мо инчунин мехоҳем, ки миқдори зиёди мундариҷаи он ба қадри имкон статикӣ ҳисоб карда шавад, то коди тавлидшуда зудтар иҷро карда шавад.
    // Аз ин рӯ, ин усул бодиққат навишта шудааст, то ҳамаи кодҳое, ки ба `T` вобастагӣ доранд, дар дохили он бошанд, дар ҳоле ки ҳарчи бештари кодҳое, ки ба `T` вобастагӣ надоранд, дар функсияҳое мебошанд, ки аз `T` ғайримуқаррарӣ мебошанд.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Инро контекстҳои даъват таъмин мекунанд.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Азбаски мо иқтидори `usize::MAX`-ро бармегардонем, вақте ки `elem_size` аст
            // 0, расидан ба ин ҷо ҳатман маънои онро дорад, ки `RawVec` пур аст.
            return Err(CapacityOverflow);
        }

        // Мутаассифона, мо дар ҳақиқат дар бораи ин чекҳо коре карда наметавонем.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Ин афзоиши фавқулоддаро кафолат медиҳад.
        // Ду баробар зиёд шуда наметавонад, зеро `cap <= isize::MAX` ва навъи `cap` `usize` мебошанд.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` беш аз `T` умумӣ нест.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Маҳдудиятҳо дар ин усул ба ҳамон андозае, ки дар `grow_amortized` мавҷуданд, монанданд, аммо ин усул одатан камтар ба назар гирифта мешавад, бинобар ин он камтар муҳим аст.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Азбаски мо иқтидори `usize::MAX`-ро бармегардонем, вақте ки андозаи он чунин аст
            // 0, расидан ба ин ҷо ҳатман маънои онро дорад, ки `RawVec` пур аст.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` беш аз `T` умумӣ нест.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ин функсия берун аз `RawVec` аст, то вақти кам кардани тартибро кам кунад.Барои тафсилот ба эзоҳи боло дар `RawVec::grow_amortized` нигаред.
// (Параметри `A` аҳамият надорад, зеро шумораи намудҳои гуногуни `A`, ки дар амал дида мешаванд, нисбат ба намудҳои `T` хеле камтар аст.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Барои кам кардани андозаи `RawVec::grow_*` хатогиро дар инҷо санҷед.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Ҷудокунанда баробарии масирро месанҷад
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Хотираи ба `RawVec` * тааллуқдоштаро бе кӯшиши тарки мундариҷа озод мекунад.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Функсияи марказӣ барои баррасии хатогиҳои захиравӣ.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Мо бояд кафолат диҳем:
// * Мо ҳеҷ гоҳ объектҳои андозаи байтӣ `> isize::MAX` ҷудо намекунем.
// * Мо `usize::MAX`-ро пур намекунем ва дар асл хеле кам ҷудо мекунем.
//
// Дар 64-бита мо бояд танҳо пур шудани обро тафтиш кунем, зеро кӯшиши ҷудо кардани байтҳои `> isize::MAX` бешубҳа ноком хоҳад шуд.
// Дар бораи 32-bit ва 16-bit ба мо лозим аст, ки барои он посбони иловагӣ илова кунем, агар мо дар платформае кор кунем, ки метавонад тамоми 4GB-ро дар фазои корбар истифода барад, масалан, PAE ё x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Як функсияи марказӣ, ки барои ҳисоботдиҳӣ пур мешавад.
// Ин кафолат медиҳад, ки тавлиди рамзи марбут ба ин panics ҳадди аққал аст, зеро танҳо як макон вуҷуд дорад, ки panics ба ҷои як даста дар тамоми модул вуҷуд дорад.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}