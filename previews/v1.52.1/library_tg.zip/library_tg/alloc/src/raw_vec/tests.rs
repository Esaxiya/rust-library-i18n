use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Навиштани озмоиши ҳамгироӣ байни паҳнкунандагони сеюм ва `RawVec` каме душвор аст, зеро `RawVec` API усулҳои тақсимоти хатогиро нишон намедиҳад, бинобар ин, мо наметавонем тафтиш кунем, ки ҳангоми тақсимкунӣ чӣ кор мешавад (берун аз ошкор кардани panic).
    //
    //
    // Ба ҷои ин, ин танҳо тафтиш мекунад, ки усулҳои `RawVec` ҳадди аққал тавассути Allocator API ҳангоми захира кардани анбор мегузаранд.
    //
    //
    //
    //
    //

    // Ҷудокунандаи гунг, ки пеш аз кӯшиши тақсимкунӣ ноком шуданаш миқдори муайяни сӯзишвориро истеъмол мекунад.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (боиси реалок мегардад, бинобар ин 50 + 150=200 адад сӯзишворӣ истифода мешавад)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Аввалан, `reserve` монанди `reserve_exact` ҷудо мекунад.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 аз 7 ду баробар зиёдтар аст, бинобар ин `reserve` бояд мисли `reserve_exact` кор кунад.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 камтар аз нисфи 12 аст, бинобар ин `reserve` бояд ба таври фаврӣ афзоиш ёбад.
        // Ҳангоми навиштани ин омили афзоиш 2 аст, аз ин рӯ иқтидори нав 24 аст, аммо афзоиши 1.5 низ хуб аст.
        //
        // Аз ин рӯ, `>= 18` тасдиқ мекунад.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}