//! Нигоҳи динамикӣ ба пайдарпаии ҳамсоя, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Буридаҳо ин намуди блоки хотира мебошанд, ки ҳамчун нишоннамо ва дарозӣ ифода карда мешаванд.
//!
//! ```
//! // буридани Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // маҷбур кардани массив ба бурида
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Иловаҳо тағирёбанда ё мубодила мешаванд.
//! Навъи буридаи муштарак `&[T]` аст, дар ҳоле ки навъи буридаи мутавозин `&mut [T]` аст, ки дар он `T` навъи унсурро нишон медиҳад.
//! Масалан, шумо метавонед блоки хотираеро, ки буридаи тағиршаванда ба он ишора мекунад, mutate кунед:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Инҳоянд баъзе чизҳое, ки ин модул дар бар мегирад:
//!
//! ## Structs
//!
//! Якчанд структураҳое мавҷуданд, ки барои буридаҳо муфид мебошанд, ба монанди [`Iter`], ки такрорро дар як бурида ифода мекунад.
//!
//! ## Татбиқи Trait
//!
//! Якчанд татбиқи traits барои иловаро мавҷуданд.Баъзе мисолҳо инҳоянд:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], барои иловаро, ки навъи унсури онҳо [`Eq`] ё [`Ord`] мебошанд.
//! * [`Hash`] - барои иловаро, ки навъи унсури онҳо [`Hash`] аст.
//!
//! ## Iteration
//!
//! Иловаҳо `IntoIterator` амалӣ мекунанд.Итератори истинодҳо ба унсурҳои бурида медиҳад.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Буридаи тағиршаванда истинодҳои тағиршавандаро ба унсурҳо медиҳад:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ин итератор истинодҳои тағиршавандаро ба унсурҳои бурида медиҳад, аз ин рӯ, дар ҳоле ки навъи унсури бурида `i32` аст, навъи унсури итератор `&mut i32` мебошад.
//!
//!
//! * [`.iter`] ва [`.iter_mut`] усулҳои возеҳ барои баргардонидани такрори пешфарз мебошанд.
//! * Усулҳои минбаъда, ки такроркунандагонро бармегардонанд, [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ва ғайра мебошанд.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Бисёре аз корбурдҳои ин модул танҳо дар конфигуратсияи санҷиш истифода мешаванд.
// Хомӯш кардани огоҳии unused_imports нисбат ба ислоҳ кардан тозатар аст.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Усулҳои асосии васеъкунии бурриш
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ки барои татбиқи макросҳои `vec!` ҳангоми санҷиши ЗН зарур аст, барои тафсилоти бештар ба модули `hack` дар ин файл нигаред.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ки барои татбиқи `Vec::clone` ҳангоми санҷиши ЗН зарур аст, барои тафсилоти бештар ба модули `hack` дар ин файл нигаред.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Бо cfg(test) `impl [T]` дастрас нест, ин се функсия воқеан усулҳое мебошанд, ки дар `impl [T]` ҳастанд, аммо дар `core::slice::SliceExt` нестанд, мо бояд ин функсияҳоро барои санҷиши `test_permutations` пешниҳод кунем
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Мо набояд ба ин атрибути дохилӣ илова кунем, зеро ин дар макрои `vec!` асосан истифода мешавад ва боиси регрессияи комил мегардад.
    // Барои муҳокима ва натиҷаҳои мукаммал ба #71204 нигаред.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ашё дар ҳалқаи поён оғозшуда ишора карда шуд
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) барои LLVM зарур аст, ки чекҳои ҳудудро хориҷ кунанд ва дорои кодекси нисбат ба zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ҳадди аққал ба ин дарозӣ тақсим карда шуда буд.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // дар боло бо иқтидори `s` ҷудо карда шудааст ва ба `s.len()` дар ptr::copy_to_non_overlapping дар зер оғоз мекунад.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Буридаи навъҳоро ҷудо мекунад.
    ///
    /// Ин навъ устувор аст (яъне унсурҳои баробарро аз нав танзим намекунад) ва *O*(*n*\*log(* n*)) бадтарин ҳолат.
    ///
    /// Ҳангоми татбиқ, ҷобаҷогузории ноустувор бартарӣ дода мешавад, зеро он одатан нисбат ба ҷобаҷогузории устувор тезтар аст ва хотираи ёрирасонро ҷудо намекунад.
    /// [`sort_unstable`](slice::sort_unstable) нигаред.
    ///
    /// # Татбиқи ҷорӣ
    ///
    /// Алгоритми ҳозира як навъи мутобиқшавӣ, такроршаванда мебошад, ки аз ҷониби [timsort](https://en.wikipedia.org/wiki/Timsort) илҳом гирифтааст.
    /// Он дар ҳолатҳое, ки бурида тақрибан мураттаб шудааст ё аз ду ё зиёда пайдарпаии мураттаб пай дар пай ба ҳам пайваста иборат аст, хеле зуд сохта шудааст.
    ///
    ///
    /// Инчунин, он нигаҳдории муваққатиро нисфи андозаи `self` ҷудо мекунад, аммо барои буридаи кӯтоҳ ба ҷои он навъи навъе ҷудошаванда истифода мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Буридаҳоро бо функсияи компаратор ҷудо мекунад.
    ///
    /// Ин навъ устувор аст (яъне унсурҳои баробарро аз нав танзим намекунад) ва *O*(*n*\*log(* n*)) бадтарин ҳолат.
    ///
    /// Функсияи компаратор бояд фармоишоти куллиро барои унсурҳои бурида муайян кунад.Агар фармоиш умумӣ набошад, тартиби унсурҳо номуайян аст.
    /// Фармоиш фармоиши куллист, агар он бошад (барои ҳама `a`, `b` ва `c`):
    ///
    /// * тотал ва антисимметрӣ: дақиқан яке аз `a < b`, `a == b` ё `a > b` дуруст аст ва
    /// * гузаранда, `a < b` ва `b < c` `a < c`-ро дар назар доранд.Ҳамин бояд ҳам барои `==` ва `>` нигоҳ дошта шавад.
    ///
    /// Масалан, дар ҳоле, ки [`f64`] [`Ord`]-ро иҷро намекунад, зеро `NaN != NaN`, мо метавонем `partial_cmp`-ро ҳамчун функсияи ҷобаҷогузории худ истифода барем, вақте ки мо медонем, ки бурида `NaN` надорад.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Ҳангоми татбиқ, ҷобаҷогузории ноустувор бартарӣ дода мешавад, зеро он одатан нисбат ба ҷобаҷогузории устувор тезтар аст ва хотираи ёрирасонро ҷудо намекунад.
    /// [`sort_unstable_by`](slice::sort_unstable_by) нигаред.
    ///
    /// # Татбиқи ҷорӣ
    ///
    /// Алгоритми ҳозира як навъи мутобиқшавӣ, такроршаванда мебошад, ки аз ҷониби [timsort](https://en.wikipedia.org/wiki/Timsort) илҳом гирифтааст.
    /// Он дар ҳолатҳое, ки бурида тақрибан мураттаб шудааст ё аз ду ё зиёда пайдарпаии мураттаб пай дар пай ба ҳам пайваста иборат аст, хеле зуд сохта шудааст.
    ///
    /// Инчунин, он нигаҳдории муваққатиро нисфи андозаи `self` ҷудо мекунад, аммо барои буридаи кӯтоҳ ба ҷои он навъи навъе ҷудошаванда истифода мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ҷобаҷогузории баръакс
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Буридаҳоро бо функсияи истихроҷи тугмаҳо ҷудо мекунад.
    ///
    /// Ин навъ устувор аст (яъне, унсурҳои баробарро аз нав танзим намекунад) ва *O*(*m*\* * n *\* log(*n*)) бадтарин ҳолат, ки вазифаи калидӣ *O*(*m*) аст.
    ///
    /// Барои вазифаҳои асосии гарон (масалан
    /// функсияҳое, ки дастрасии оддии амвол ё амалиётҳои оддӣ нестанд), эҳтимол дорад [`sort_by_cached_key`](slice::sort_by_cached_key) ба таври назаррас зудтар шавад, зеро он калидҳои элементро ҳисоб намекунад.
    ///
    ///
    /// Ҳангоми татбиқ, ҷобаҷогузории ноустувор бартарӣ дода мешавад, зеро он одатан нисбат ба ҷобаҷогузории устувор тезтар аст ва хотираи ёрирасонро ҷудо намекунад.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) нигаред.
    ///
    /// # Татбиқи ҷорӣ
    ///
    /// Алгоритми ҳозира як навъи мутобиқшавӣ, такроршаванда мебошад, ки аз ҷониби [timsort](https://en.wikipedia.org/wiki/Timsort) илҳом гирифтааст.
    /// Он дар ҳолатҳое, ки бурида тақрибан мураттаб шудааст ё аз ду ё зиёда пайдарпаии мураттаб пай дар пай ба ҳам пайваста иборат аст, хеле зуд сохта шудааст.
    ///
    /// Инчунин, он нигаҳдории муваққатиро нисфи андозаи `self` ҷудо мекунад, аммо барои буридаи кӯтоҳ ба ҷои он навъи навъе ҷудошаванда истифода мешавад.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Буридаҳоро бо функсияи истихроҷи тугмаҳо ҷудо мекунад.
    ///
    /// Ҳангоми ҷобаҷогузорӣ, функсияи калид танҳо барои як унсур як маротиба даъват карда мешавад.
    ///
    /// Ин навъ устувор аст (яъне унсурҳои баробарро аз нав танзим намекунад) ва *O*(*m*\* * n *+* n *\* log(*n*)) бадтарин ҳолат, ки вазифаи калидӣ *O*(*m*) аст .
    ///
    /// Барои функсияҳои асосии оддӣ (масалан, функсияҳое, ки дастрасӣ ба амвол ё амалиёти асосӣ мебошанд), эҳтимол дорад [`sort_by_key`](slice::sort_by_key) тезтар бошад.
    ///
    /// # Татбиқи ҷорӣ
    ///
    /// Алгоритми ҳозира ба [pattern-defeating quicksort][pdqsort] аз ҷониби Орсон Петерс асос ёфтааст, ки ҳолати миёнаи тези квиксори тасодуфиро бо бадтарин ҳолати пуршиддат дар якҷоягӣ дар бар мегирад ва дар вақти ноқилӣ ба буришҳо бо нақшҳои муайян.
    /// Он баъзе тасодуфиро барои пешгирӣ кардани ҳолатҳои таназзул истифода мекунад, аммо бо seed собит ҳамеша рафтори детерминистиро таъмин мекунад.
    ///
    /// Дар бадтарин ҳолат, алгоритм нигаҳдории муваққатиро дар дарозии `Vec<(K, usize)>` ҷудо мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Макросҳои ёрирасон барои индексатсияи vector-и мо аз рӯи хурдтарин намуди имконпазир, барои кам кардани тақсимот.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Унсурҳои `indices` беназиранд, зеро онҳо индексатсия карда мешаванд, аз ин рӯ, ҳама гуна навъҳо нисбати буридаи аслӣ устувор хоҳанд буд.
                // Мо `sort_unstable`-ро дар ин ҷо истифода мебарем, зеро он тақсимоти хотираро камтар талаб мекунад.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self`-ро ба `Vec` нав нусхабардорӣ мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Дар ин ҷо, `s` ва `x` метавонанд мустақилона тағир дода шаванд.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self`-ро ба `Vec` нав бо ҷудокунанда нусхабардорӣ мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Дар ин ҷо, `s` ва `x` метавонанд мустақилона тағир дода шаванд.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // ЗН, барои тафсилоти бештар ба ин модул `hack` нигаред.
        hack::to_vec(self, alloc)
    }

    /// Табдил `self` ба vector бе клонҳо ва тақсимот.
    ///
    /// Натиҷаи vector метавонад тавассути `Vec ба қуттӣ табдил дода шавад<T>усули `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` дигар наметавонад истифода шавад, зеро он ба `x` табдил дода шудааст.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // ЗН, барои тафсилоти бештар ба ин модул `hack` нигаред.
        hack::into_vec(self)
    }

    /// Бо такрори буридаи `n` маротиба vector месозад.
    ///
    /// # Panics
    ///
    /// Агар ин функсия зиёдтар шавад, ин функсия panic хоҳад буд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ҳангоми лабрез шудан:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Агар `n` аз сифр калонтар бошад, онро ҳамчун `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` тақсим кардан мумкин аст.
        // `2^expn` рақаме мебошад, ки бо чапи каме '1'-и `n` намояндагӣ мекунад ва `rem` қисми боқимондаи `n` мебошад.
        //
        //

        // Бо истифода аз `Vec` барои дастрасӣ ба `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` такрор бо ду маротиба зиёд кардани `buf` `expn` маротиба иҷро карда мешавад.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Агар `m > 0`, каме то '1' чапдаст боқӣ мондааст.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` иқтидори `self.len() * n` дорад.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) такрор бо роҳи нусхабардории аввалин такрори `rem` аз худи `buf` анҷом дода мешавад.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Ин аз соли `2^expn > rem` такрор намешавад.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ба `buf.capacity()` баробар аст (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Буридаи `T`-ро ба арзиши ягонаи `Self::Output` ҳамвор мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Буридаи `T`-ро ба арзиши ягонаи `Self::Output` ҳамвор мекунад ва ҷудосози додашударо байни ҳар як ҷой медиҳад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Буридаи `T`-ро ба арзиши ягонаи `Self::Output` ҳамвор мекунад ва ҷудосози додашударо байни ҳар як ҷой медиҳад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// vector-ро бармегардонад, ки нусхаи ин бурраро дар бар мегирад, ки ҳар байт ба эквиваленти ҳарфҳои калони ASCII ҷойгир карда шудааст.
    ///
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои калон кардани арзиши ҷой, [`make_ascii_uppercase`] истифода баред.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// vector-ро бармегардонад, ки нусхаи ин бурраро дар бар мегирад, ки дар он ҳар як байт ба эквиваленти хурди ASCII ҷойгир карда шудааст.
    ///
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои кам кардани арзиши ҷойгоҳ, [`make_ascii_lowercase`]-ро истифода баред.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Тамдиди traits барои порчаҳо аз рӯи намудҳои мушаххаси маълумот
////////////////////////////////////////////////////////////////////////////////

/// Ёрдамчии trait барои [`[T]: : concat`](бурида::concat).
///
/// Note: Параметри навъи `Item` дар ин trait истифода намешавад, аммо ин имкон медиҳад, ки имплҳо бештар умумӣ бошанд.
/// Бе ин, мо ин хаторо пайдо мекунем:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Сабаб ин аст, ки метавонад намудҳои `V` бо имплектҳои `Borrow<[_]>` вуҷуд дошта бошанд, ба тавре ки намудҳои сершумори `T` татбиқ мешаванд:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Намуди натиҷа пас аз ҳамбастагӣ
    type Output;

    /// Татбиқи [`[T]: : concat`](бурида::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Ёрдамчии trait барои [`[T]: : ҳамроҳ '](бурида::ҳамроҳ шудан)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Намуди натиҷа пас аз ҳамбастагӣ
    type Output;

    /// Татбиқи [`[T]: : ҳамроҳ '](буридан::ҳамроҳ шудан)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Татбиқи стандартии trait барои иловаро
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ягон чизро ба ҳадаф партоед, ки навишта намешавад
        target.truncate(self.len());

        // target.len <= self.len бо сабаби буридани боло, аз ин рӯ, иловаро ҳамеша дар ҳудуд мебошанд.
        //
        let (init, tail) = self.split_at(target.len());

        // арзишҳои allocations/resources-ро дарбар гиред.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]`-ро ба пайдарпаии пешакӣ `v[1..]` дохил мекунад, то ки тамоми `v[..]` мураттаб шавад.
///
/// Ин зерпрутини ҷудонашавандаи навъи дохилкунӣ мебошад.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Дар ин ҷо се роҳи татбиқи замима мавҷуд аст:
            //
            // 1. Унсурҳои шафатро то он даме ки аввал ба манзили охирин расад, иваз кунед.
            //    Аммо, бо ин роҳ, мо маълумотро дар атрофи он аз ҳад зиёд зарурӣ нусхабардорӣ мекунем.
            //    Агар элементҳо сохторҳои калон бошанд (нусхабардорӣ гарон аст), ин усул суст хоҳад буд.
            //
            // 2. То он даме ки ҷои дуруст барои унсури аввал пайдо мешавад, такрор кунед.
            // Сипас унсурҳои ба он муваффақшударо тағир диҳед, то барои он ҷой ҷудо кунед ва дар ниҳоят ба сӯрохи боқимонда ҷойгир кунед.
            // Ин усули хуб аст.
            //
            // 3. Элементи аввалро ба тағирёбандаи муваққатӣ нусхабардорӣ кунед.То он даме ки ҷои мувофиқ барои он пайдо мешавад, такрор кунед.
            // Ҳангоми гузаштан, ҳар як унсури убуршударо ба чуқури пеши он нусхабардорӣ кунед.
            // Ниҳоят, маълумотро аз тағирёбандаи муваққатӣ ба сӯрохи боқимонда нусхабардорӣ кунед.
            // Ин усул хеле хуб аст.
            // Меъёрҳо нисбат ба усули 2 каме беҳтар нишон доданд.
            //
            // Ҳама усулҳо бенчмарк карда шуданд ва 3-ум натиҷаҳои беҳтарин нишон доданд.Аз ин рӯ, мо онро интихоб кардем.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Ҳолати фосилавии раванди дохилкуниро ҳамеша `hole` пайгирӣ мекунад, ки ин ду мақсадро дар бар мегирад:
            // 1. Бутунии `v`-ро аз panics дар `is_less` муҳофизат мекунад.
            // 2. Сӯрохи боқимондаро дар `v` пур мекунад.
            //
            // Амнияти Panic:
            //
            // Агар `is_less` panics дар ягон лаҳзаи раванд, `hole` афтод ва сӯрохи `v`-ро бо `tmp` пур кунад ва ба ин васила кафолат диҳад, ки `v` ҳар як ашёро, ки дар аввал нигаҳдорӣ мешуд, якбора нигоҳ медорад.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` афтод ва ба ин васила `tmp`-ро ба сӯрохи боқимондаи `v` нусхабардорӣ мекунад.
        }
    }

    // Ҳангоми партофтан, нусхабардорӣ аз `src` ба `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `v[..mid]` ва `v[mid..]`-ро бо истифодаи `buf` ҳамчун нигаҳдории муваққатӣ муттаҳид мекунад ва натиҷаро ба `v[..]` нигоҳ медорад.
///
/// # Safety
///
/// Ду порча бояд холӣ набошанд ва `mid` бояд дар ҳудуд бошад.
/// Буфер `buf` бояд кофӣ дароз бошад, то нусхаи буридаи кӯтоҳтарро нигоҳ дорад.
/// Инчунин, `T` набояд навъи андозаи сифр бошад.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Раванди якҷоякунӣ аввал нусхаи кӯтоҳтарро ба `buf` нусхабардорӣ мекунад.
    // Пас аз он, пайдоиши нав нусхабардашуда ва дарозтар ба пеш (ё ба қафо) пайгирӣ карда, унсурҳои истеъмолнашудаи онҳоро муқоиса карда, хурдтар (ё калонтар)-ро ба `v` нусхабардорӣ мекунанд.
    //
    // Ҳамин ки даври кӯтоҳ пурра истеъмол карда шуд, раванд анҷом дода мешавад.Агар давидан дарозтар аввал истеъмол шавад, пас мо бояд ҳар он чизе, ки дар тӯли кӯтоҳтар боқӣ мондааст, ба сӯрохи боқимондаи `v` нусхабардорӣ кунем.
    //
    // Ҳолати фосилавии равандро ҳамеша `hole` пайгирӣ мекунад, ки ба ду мақсад хизмат мекунад:
    // 1. Бутунии `v`-ро аз panics дар `is_less` муҳофизат мекунад.
    // 2. Сӯрохи боқимондаро дар `v` пур мекунад, агар даври дарозтар аввал истеъмол карда шавад.
    //
    // Амнияти Panic:
    //
    // Агар `is_less` panics дар ягон лаҳзаи раванд, `hole` афтод ва сӯрохи `v`-ро бо доираи номатлуб дар `buf` пур кунад ва ба ин васила таъмин карда шавад, ки `v` ҳар як ашёро, ки дар аввал нигаҳдорӣ мешуд, якбора нигоҳ медорад.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Дави чап кӯтоҳтар аст.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Дар аввал, ин нишондиҳандаҳо ба оғози массивҳои худ ишора мекунанд.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Ҷониби камтарро истеъмол кунед.
            // Агар баробар бошад, барои нигоҳ доштани устувор давидан ба чапро афзалтар донед.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Дави дуруст кӯтоҳтар аст.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Дар аввал, ин нишондиҳандаҳо аз паҳлӯи массивҳои худ ишора мекунанд.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Ҷониби бузургтарро истеъмол кунед.
            // Агар баробар бошад, барои нигоҳ доштани субот даври дурустро афзалтар донед.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Ниҳоят, `hole` афтад.
    // Агар давиши кӯтоҳтар пурра истеъмол карда намешуд, пас боқимондаи он ба сӯрохи `v` нусхабардорӣ карда мешавад.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ҳангоми партофтан, диапазони `start..end`-ро ба `dest..` нусхабардорӣ мекунад.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` навъи андозаи сифр нест, бинобар ин ба андозаи он тақсим кардан дуруст аст.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ин навъи якҷоякунӣ баъзе (вале на ҳама) ғояҳоро аз TimSort қарз мегирад, ки ба таври муфассал [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) тасвир шудааст.
///
///
/// Алгоритм пайдарпаии қатъӣ пастшаванда ва нопурраро муайян мекунад, ки давиданҳои табиӣ номида мешаванд.Ҳоло як қатор интизориҳои интизорӣ мавҷуданд, ки ҳанӯз якҷоя карда намешаванд.
/// Ҳар як давидаи нав ёфташуда ба стек тела дода мешавад, ва он гоҳ якчанд ҷуфт давишҳои ҳамсоя то он даме ки ин ду инвариант муттаҳид мешаванд:
///
/// 1. барои ҳар як `i` дар `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. барои ҳар як `i` дар `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Инвариантҳо кафолат медиҳанд, ки вақти умумии кор *O*(*n*\*log(* n*)) бадтарин аст.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Лутфҳо то ин дарозӣ бо истифодаи навъҳои дохилкунӣ мураттаб карда мешаванд.
    const MAX_INSERTION: usize = 20;
    // Давраҳои хеле кӯтоҳ бо истифода аз навъҳои дохилкунӣ васеъ карда мешаванд, то ҳадди аққал ин миқдор элементро дар бар гиранд.
    const MIN_RUN: usize = 10;

    // Ҷобаҷогузорӣ дар намудҳои андозаи сифр ягон рафтори пурмазмун надорад.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Массивҳои кӯтоҳ тавассути ҷобаҷогузории ҷойгиркунӣ дар ҷои худ ҷобаҷо мешаванд, то ҷудо нашаванд.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Барои истифода ҳамчун хотираи сифр буфере ҷудо кунед.Мо дарозии 0-ро нигоҳ медорем, то ки дар он нусхаҳои начандон дур аз мундариҷаи `v`-ро нигоҳ дорем, бидуни хатари дторҳо, ки дар нусхаҳои `is_less` panics кор мекунанд.
    //
    // Ҳангоми якҷоякунии ду даври ҷудошуда, ин буфер нусхаи даври кӯтоҳтарро нигоҳ медорад, ки ҳамеша дарозии онро дар ҳадди аксар `len / 2` хоҳад дошт.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Барои муайян кардани давишҳои табиӣ дар `v`, мо онро ба ақиб мегузарем.
    // Ин метавонад як қарори аҷибе ба назар расад, аммо ба назар гиред, ки якҷояшавӣ бештар ба самти муқобили (forwards) меравад.
    // Мувофиқи меъёрҳо, ҳамроҳшавӣ ба пеш каме зудтар ба ҳам омехта аст.
    // Барои хулоса баровардан, муайян кардани давиданҳо тавассути гузаштан ба қафо нишондиҳандаҳоро беҳтар мекунад.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Дави навбатии табииро ёбед ва агар он ба таври ҷиддӣ коҳиш ёбад, онро баргардонед.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Агар он хеле кӯтоҳ бошад, якчанд унсурҳои дигарро ба кор дароред.
        // Навъи дохилкунӣ нисбат ба муттаҳидкунии навъ дар пайдарпаии кӯтоҳ зудтар аст, бинобар ин, ин иҷрои онро ба таври назаррас беҳтар мекунад.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Ин давиданро ба анбор тела диҳед.
        runs.push(Run { start, len: end - start });
        end = start;

        // Барои қонеъ кардани инвариантҳо якчанд ҷуфтҳои ҳамшафатро якҷоя кунед.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Ниҳоят, маҳз як давидан бояд дар стак боқӣ монад.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Стек даврҳоро месанҷад ва ҷуфти навбатиро барои якҷоякунӣ муайян мекунад.
    // Мушаххастар, агар `Some(r)` баргардонида шавад, ин маънои онро дорад, ки `runs[r]` ва `runs[r + 1]` бояд дар оянда якҷоя карда шаванд.
    // Агар алгоритм ба ҷои сохтани дави нав идома диҳад, `None` баргардонида мешавад.
    //
    // TimSort барои татбиқи хатогиҳои худ машҳур аст, ки дар ин ҷо тавсиф шудааст:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Мазмуни ҳикоя чунин аст: мо бояд инвариантҳоро дар чор даври аввал дар стек иҷро намоем.
    // Амалисозии онҳо танҳо дар се ҷои аввал барои кафолат додани он, ки инвариантҳо барои *ҳама* давидан дар стек нигоҳ дошта намешаванд.
    //
    // Ин функсия invariant-ро барои чор даври аввал дуруст месанҷад.
    // Ғайр аз он, агар даври боло аз индекси 0 сар шавад, он ҳамеша амали якҷояшударо талаб мекунад, то он даме, ки стек пурра фурӯ напечад, барои ба анҷом расонидани навъ.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}