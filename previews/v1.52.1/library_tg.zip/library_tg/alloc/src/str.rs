//! Буридаи сатри Юникод.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Навъи `&str` яке аз ду намуди асосии сатр мебошад, дигараш `String`.
//! Баръакси ҳамтои `String`, мундариҷаи он қарз гирифта мешавад.
//!
//! # Истифодаи асосӣ
//!
//! Декларатсияи асосии сатри навъи `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Дар ин ҷо мо сатри аслиро эълон кардем, ки онро ҳамчун буридаи сатр низ меноманд.
//! Китобҳои сатрӣ умри статикӣ доранд, яъне маънои сатри `hello_world` дар давоми тамоми барнома эътибор дорад.
//!
//! Мо метавонем ба таври возеҳ умри "hello_world"-ро низ муайян кунем:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Бисёре аз корбурдҳои ин модул танҳо дар конфигуратсияи санҷиш истифода мешаванд.
// Хомӯш кардани огоҳии unused_imports нисбат ба ислоҳ кардан тозатар аст.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` дар `Concat<str>` дар ин ҷо маъно надорад.
/// Ин параметри trait танҳо барои ба кор даровардани имлои дигар вуҷуд дорад.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // Доираҳоро бо андозаи рамзи сахт зудтар ба кор андохтани ҳолатҳо бо дарозии ҷудосози хурд
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // бозгашти андозаи худсаронаи ғайри сифр
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Татбиқи оптималии ҳамроҳшавӣ, ки барои ҳардуи Vec кор мекунад<T>(T: Нусхабардорӣ) ва vec дарунии String Айни замон (2018-05-13) хатогие бо хулоса ва ихтисос дорад (ба шумораи #36262 нигаред) Бо ин сабаб SliceConcat<T>барои T: Copy ва SliceConcat махсус нест<str>ягона корбари ин функсия мебошад.
// Он дар вақти муайяншуда дар ҷои худ гузошта мешавад.
//
// ҳудуди String-join S мебошанд: Қарз гиред<str>ва барои Vec-пайвандед Қарз <[T]> [T] ва str ҳам Asref <[T]>-ро барои баъзе T дохил мекунанд
// => s.borrow().as_ref() ва мо ҳамеша иловаро дорем
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // буридаи аввал ягонаест, ки пеш аз он сепаратор нест
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // дарозии умумии дақиқи Vec-и ҳамроҳшударо ҳисоб кунед, агар ҳисобкунии `len` пур шавад, мо panic-ро дар ҳар ҳолат тамом мекардем ва боқимондаи функсия тамоми Vec-и барои бехатарӣ пешакӣ ҷудошударо талаб мекунад
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // буферии нотамомро омода созед
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // нусхабардории ҷудосозанда ва иловаро бидуни ҳудуд ҳалқаҳо бо офсетҳои сахт бо тавлидшуда барои ҷудосозони хурд такмилдиҳии азим имконпазир месозад (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Татбиқи як қарзи аҷиб метавонад буришҳои гуногунро барои ҳисоб кардани дарозӣ ва нусхаи воқеӣ баргардонад.
        //
        // Боварӣ ҳосил кунед, ки байтҳои номаълумро ба зангзананда дучор накунем.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Усулҳои буридани сатр.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// `Box<str>`-ро ба `Box<[u8]>` бе нусхабардорӣ ё тақсимкунӣ табдил медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Ҳама мутобиқати қолабро бо сатри дигар иваз мекунад.
    ///
    /// `replace` [`String`] нав месозад ва маълумотро аз ин буридаи сатр ба он нусхабардорӣ мекунад.
    /// Ҳангоми ин кор, он кӯшиш мекунад, ки гӯгирдҳои намунаро пайдо кунад.
    /// Агар ягон чизро ёбад, онро бо буридаи сатри ивазкунанда иваз мекунад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Вақте ки намуна мувофиқат намекунад:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Аввалин N мувофиқатро бо сатри дигар иваз мекунад.
    ///
    /// `replacen` [`String`] нав месозад ва маълумотро аз ин буридаи сатр ба он нусхабардорӣ мекунад.
    /// Ҳангоми ин кор, он кӯшиш мекунад, ки гӯгирдҳои намунаро пайдо кунад.
    /// Агар ягон чизро ёбад, онро бо буридаи сатри ивазкунӣ ҳадди аксар `count` маротиба иваз мекунад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Вақте ки намуна мувофиқат намекунад:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Умедворам, ки вақти тақсимоти дубора кам карда шавад
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Муодили хурди ин буридаи сатрро ҳамчун [`String`] нав бармегардонад.
    ///
    /// 'Lowercase' мувофиқи шартҳои Unicode Derived Core Property `Lowercase` муайян карда мешавад.
    ///
    /// Азбаски баъзе аломатҳо ҳангоми тағир додани парванда метавонанд ба аломатҳои гуногун васеъ шаванд, ин функсия ба ҷои тағир додани параметр дар ҷои худ, [`String`] бармегардонад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Мисоли назарфиреб бо сигма:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // аммо дар охири калима, ин ς аст, на σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Забонҳо бидуни ҳарф тағир дода мешаванд:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ ба σ харита медиҳад, ба истиснои охири калимае, ки он ба map мувофиқат мекунад.
                // Ин ягона харитасозии (contextual) шартӣ аст, аммо дар `SpecialCasing.txt` харитасозии мустақил аз забон, аз ин рӯ онро сахт рамзгузорӣ кунед, на механизми умумии "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // барои таърифи `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Эквиваленти калони ин буридаи сатрро ҳамчун [`String`] нав бармегардонад.
    ///
    /// 'Uppercase' мувофиқи шартҳои Unicode Derived Core Property `Uppercase` муайян карда мешавад.
    ///
    /// Азбаски баъзе аломатҳо ҳангоми тағир додани парванда метавонанд ба аломатҳои гуногун васеъ шаванд, ин функсия ба ҷои тағир додани параметр дар ҷои худ, [`String`] бармегардонад.
    ///
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Скриптҳо бидуни ҳарф тағир дода мешаванд:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Як аломат метавонад сершумор шавад:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// [`Box<str>`]-ро ба [`String`] бе нусхабардорӣ ё тақсимкунӣ табдил медиҳад.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Бо такрори сатр `n` маротиба [`String`] нав месозад.
    ///
    /// # Panics
    ///
    /// Агар ин функсия зиёдтар шавад, ин функсия panic хоҳад буд.
    ///
    /// # Examples
    ///
    /// Истифодаи асосӣ:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic ҳангоми лабрез шудан:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Нусхаи ин сатрро бармегардонад, ки дар он ҳар як аломат ба эквиваленти калони ҳарфҳои ASCII ҷойгир карда шудааст.
    ///
    ///
    /// Ҳарфҳои ASCII 'a' ба 'z' ба 'A' то 'Z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои калон кардани арзиши ҷой, [`make_ascii_uppercase`] истифода баред.
    ///
    /// Барои калон кардани аломатҳои ASCII, илова бар аломатҳои ғайри ASCII, [`to_uppercase`]-ро истифода баред.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() бетағйир будани UTF-8 ро нигоҳ медорад.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Нусхаи ин сатрро бармегардонад, ки дар он ҳар як аломат ба эквиваленти хурди ASCII-и он ҷойгир карда шудааст.
    ///
    ///
    /// Ҳарфҳои ASCII 'A' ба 'Z' ба 'a' то 'z' харита карда мешаванд, аммо ҳарфҳои ғайри ASCII бетағйиранд.
    ///
    /// Барои кам кардани арзиши ҷойгоҳ, [`make_ascii_lowercase`]-ро истифода баред.
    ///
    /// Барои хурд кардани аломатҳои ASCII, илова бар аломатҳои ғайри ASCII, [`to_lowercase`]-ро истифода баред.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() бетағйир будани UTF-8 ро нигоҳ медорад.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Як буридаи байтро ба буридаи сатри қуттӣ табдил медиҳад ва бидуни санҷидани он, ки сатр дорои UTF-8 эътибор аст.
///
///
/// # Examples
///
/// Истифодаи асосӣ:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}