//! Нишондиҳандаҳои ҳисобкунии истиноди ягона.'Rc' маънои "Маълумотнома"-ро дорад
//! Counted'.
//!
//! Намуди [`Rc<T>`][`Rc`] моликияти муштарак ба арзиши навъи `T`, ки дар теппа ҷудо карда шудааст, таъмин менамояд.
//! Даъвати [`clone`][clone] дар [`Rc`] нишонаи навро ба ҳамон тақсимот дар теппа меорад.
//! Вақте ки нишоннамои охирини [`Rc`] ба тақсимоти додаҳо нест карда мешаванд, арзиши дар ин тақсимот ҳифзшуда (аксар вақт "inner value" номида мешавад) низ партофта мешавад.
//!
//! Истинодҳои муштарак дар Rust мутатсияро бо нобаёнӣ иҷозат намедиҳанд ва [`Rc`] истисно нест: шумо умуман наметавонед истиноди тағиршавандаро ба чизе дар дохили [`Rc`] ба даст оред.
//! Агар ба шумо mutability лозим бошад, [`Cell`] ё [`RefCell`]-ро дар дохили [`Rc`] гузоред;нигаред [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] ҳисобкунии истинодии ғайриматомиро истифода мебарад.
//! Ин маънои онро дорад, ки болопӯш хеле паст аст, аммо [`Rc`] байни риштаҳо фиристода намешавад ва дар натиҷа [`Rc`] [`Send`][send]-ро иҷро намекунад.
//! Дар натиҷа, компилятор Rust *дар вақти тартиб* тафтиш намекунад, ки шумо ['Rc`]-ро байни риштаҳо нафиристед.
//! Агар ба шумо шумориши истинодҳои бисёрҷабҳа ва атомӣ лозим бошад, [`sync::Arc`][arc]-ро истифода баред.
//!
//! Усули [`downgrade`][downgrade] метавонад барои сохтани нишонаи [`Weak`] ғайри соҳибӣ истифода шавад.
//! Нишондиҳандаи [`Weak`] метавонад [`upgrade '][upgrade] d ба [`Rc`] бошад, аммо ин ба [`None`] бармегардад, агар арзиши дар ҷудокунишуда сабтшуда аллакай партофта шуда бошад.
//! Ба ибораи дигар, нишондиҳандаҳои `Weak` арзиши дохили тақсимотро зинда нигоҳ намедоранд;аммо, онҳо тақсимотро (мағозаи пуштибонӣ барои арзиши ботинӣ) зинда нигоҳ медоранд.
//!
//! Давраи байни нишондиҳандаҳои [`Rc`] ҳеҷ гоҳ тақсим карда намешавад.
//! Аз ин сабаб, [`Weak`] барои шикастани давраҳо истифода мешавад.
//! Масалан, дарахт метавонад нишондиҳандаҳои пурқуввати [`Rc`] аз гиреҳҳои волидайн ба кӯдакон ва [`Weak`] нишондиҳандаҳо аз кӯдакон ба волидайн дошта бошад.
//!
//! `Rc<T>` ба тариқи худкор ба `T` муроҷиат мекунад (тавассути [`Deref`] trait), бинобар ин шумо метавонед усулҳои "T"-ро бо арзиши навъи [`Rc<T>`][`Rc`] занг занед.
//! Барои роҳ надодан ба бархӯрдҳои номӣ бо усулҳои "T", усулҳои худи [`Rc<T>`][`Rc`] вазифаҳои алоқаманд мебошанд, ки истифодаи [fully qualified syntax] номида мешаванд:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! "Rc<T>Татбиқи traits, ба монанди `Clone`, инчунин бо истифода аз синтаксиси пурихтисос номида мешавад.
//! Баъзе одамон истифодаи синтаксиси пурихтисосро афзал медонанд, дигарон бошанд истифодаи синтаксиси усули даъватро афзал медонанд.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Усули зангзанӣ
//! let rc2 = rc.clone();
//! // Синтаксиси пурраи тахассусӣ
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ба `T` худкор тағир намедиҳад, зеро арзиши дохилӣ аллакай партофта шудааст.
//!
//! # Клонидани маълумотномаҳо
//!
//! Сохтани истиноди нав ба ҳамон тақсимот бо нишоннамои мавҷудаи ҳисобшуда бо истифодаи `Clone` trait, ки барои [`Rc<T>`][`Rc`] ва [`Weak<T>`][`Weak`] татбиқ карда мешавад, анҷом дода мешавад.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Ду синтаксиси дар поён овардашуда баробаранд.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a ва b ҳарду ба ҳамон макони хотираи foo ишора мекунанд.
//! ```
//!
//! Синтаксиси `Rc::clone(&from)` маъмултарин аст, зеро маънои рамзро ба таври возеҳтар баён мекунад.
//! Дар мисоли дар боло овардашуда, ин синтаксис диданро осонтар мекунад, ки ин рамз ба ҷои нусхабардории тамоми мундариҷаи foo истиноди нав эҷод мекунад.
//!
//! # Examples
//!
//! Сенарияеро дида мебароем, ки маҷмӯи "Gadget" ба `Owner` дода мешавад.
//! Мо мехоҳем, ки "Gadget"-и худро ба `Owner`-и худ нишон диҳем.Мо инро бо моликияти беназир иҷро карда наметавонем, зеро зиёда аз як гаҷет метавонад ба ҳамон `Owner` тааллуқ дошта бошад.
//! [`Rc`] ба мо имкон медиҳад, ки `Owner`-ро дар байни якчанд Gadget тақсим кунем ва `Owner` то он даме, ки ҳама нуқтаҳои `Gadget` дар он ҷойгиранд, ҷудо карда шаванд.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... дигар соҳаҳо
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... дигар соҳаҳо
//! }
//!
//! fn main() {
//!     // `Owner`-ро бо истинод ҳисоб кунед.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Эҷоди "Gadget", ки ба `gadget_owner` тааллуқ дорад.
//!     // Клон кардани `Rc<Owner>` ба мо нишондиҳандаи навро ба ҳамон тақсимоти `Owner` медиҳад ва шумораи истинодҳоро дар раванд афзоиш медиҳад.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // `gadget_owner` тағирёбандаи маҳаллии моро ихтиёрдорӣ кунед.
//!     drop(gadget_owner);
//!
//!     // Бо вуҷуди тарки `gadget_owner`, мо ҳанӯз ҳам номи `Owner`-и "Gadget"-ро чоп карда метавонем.
//!     // Ин аз он сабаб аст, ки мо танҳо як `Rc<Owner>`-ро партофтем, на `Owner`-ро, ки ишора мекунад.
//!     // То он даме, ки дигар `Rc<Owner>` ба ҳамон тақсимоти `Owner` ишора кунанд, он зинда хоҳад монд.
//!     // Дурнамои майдонии `gadget1.owner.name` кор мекунад, зеро `Rc<Owner>` ба таври худкор ба `Owner` истинод мекунад.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Дар охири функсия, `gadget1` ва `gadget2` нобуд карда мешаванд ва бо онҳо охирин истинодҳо ба `Owner`-и мо ҳисоб карда мешаванд.
//!     // Акнун гаҷет Одам низ нобуд мешавад.
//!     //
//! }
//! ```
//!
//! Агар талаботи мо тағир ёбад ва мо низ бояд аз `Owner` то `Gadget` бигзарем, мо дучори мушкилот мешавем.
//! Як нишоннамои [`Rc`] аз `Owner` то `Gadget` давраро ҷорӣ мекунад.
//! Ин маънои онро дорад, ки ҳисобҳои истинодии онҳо ҳеҷ гоҳ ба 0 расида наметавонанд ва тақсимот ҳеҷ гоҳ нобуд намешавад:
//! ихроҷи хотира.Бо мақсади ба даст овардани ин, мо метавонем нишондиҳандаҳои [`Weak`]-ро истифода барем.
//!
//! Rust дарвоқеъ истеҳсоли ин ҳалқаро то андозае мушкил мекунад.Барои ба охир расидани ду арзише, ки ба якдигар ишора мекунанд, яке аз онҳо бояд тағирёбанда бошад.
//! Ин мушкил аст, зеро [`Rc`] бехатарии хотираро тавассути додани маълумотномаҳои муштарак ба арзиши печондашуда таъмин мекунад ва инҳо ба мутасияи мустақим иҷозат намедиҳанд.
//! Мо бояд қисми арзиши мутатсияшударо бо [`RefCell`] печонем, ки он *мутавозунии дохилиро* таъмин мекунад: усули ба даст овардани мутобилият тавассути истиноди муштарак.
//! [`RefCell`] қоидаҳои қарзгирии Rust-ро дар вақти корӣ иҷро мекунад.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... дигар соҳаҳо
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... дигар соҳаҳо
//! }
//!
//! fn main() {
//!     // `Owner`-ро бо истинод ҳисоб кунед.
//!     // Дар хотир доред, ки мо vector-и "Гаҷет"-ро дар дохили `RefCell` гузоштем, то мо онро тавассути истиноди муштарак мутация кунем.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Тавре ки пештар ба "Gadget" тааллуқ дорад, ки ба `gadget_owner` тааллуқ дорад.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // "Gadget"-ро ба `Owner`-и худ илова кунед.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` қарзи динамикӣ дар ин ҷо ба охир мерасад.
//!     }
//!
//!     // "Gadget"-и моро такрор кунед, тафсилоти онҳоро чоп кунед.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` як `Weak<Gadget>` аст.
//!         // Азбаски нишондиҳандаҳои `Weak` кафолат дода наметавонанд, ки тақсимот то ҳол мавҷуданд, мо бояд ба `upgrade` занг занем, ки `Option<Rc<Gadget>>` бар мегардонад.
//!         //
//!         //
//!         // Дар ин ҳолат, мо медонем, ки тақсимот ҳоло ҳам мавҷуданд, бинобар ин мо танҳо `unwrap` `Option`.
//!         // Дар барномаи мураккабтар, ба шумо лозим меояд, ки барои натиҷаи `None` ба хатогиҳои ҷаззоб муроҷиат кунед.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Дар охири вазифа, `gadget_owner`, `gadget1` ва `gadget2` нобуд карда мешаванд.
//!     // Ҳоло ягон нишондиҳандаи қавии (`Rc`) ба гаҷетҳо нест, бинобар ин онҳо нест карда мешаванд.
//!     // Ин ҳисобро ба Gadget Man сифр мекунад, аз ин рӯ вай низ нобуд мешавад.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Ин repr(C) ба future-бар зидди фармоиши эҳтимолии майдон аст, ки ба [into|from]_raw() дар акси ҳол бехатар дар намудҳои дохилии трансмутатсионӣ халал мерасонанд.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Нишондиҳандаи ҳисобкунии истиноди ягона.'Rc' маънои "Маълумотнома"-ро дорад
/// Counted'.
///
/// Барои тафсилоти бештар ба [module-level documentation](./index.html) нигаред.
///
/// Усулҳои ҷудогонаи `Rc` ҳама вазифаҳои алоқаманд мебошанд, ки маънои онро дорад, ки шумо онҳоро ба ҷои `value.get_mut()`, ба мисли [`Rc::get_mut(&mut value)`][get_mut], даъват кунед.
/// Ин муноқишаҳоро бо усулҳои навъи ботинии `T` пешгирӣ мекунад.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ин бехатарӣ хуб аст, зеро дар ҳоле ки Rc зинда аст, мо кафолат медиҳем, ки нишоннамои ботинӣ дуруст аст.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// `Rc<T>` нав месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Як нишоннамои заифи номуайяне, ки ба ҳама нишондиҳандаҳои қавӣ тааллуқ дорад, кафолат медиҳад, ки деструктори заиф ҳеҷ гоҳ ҷудошударо ҳангоми кор даровардани деструктори қавӣ озод намекунад, ҳатто агар нишондиҳандаи суст дар дохили нишонаи қавӣ нигоҳ дошта шавад.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Бо истифода аз истиноди суст ба худ як `Rc<T>` нав месозад.
    /// Кӯшиши такмил додани истиноди суст пеш аз баргардонидани ин функсия, арзиши `None` хоҳад овард.
    ///
    /// Аммо, истиноди заифро озодона клонидан ва барои истифода дертар нигоҳ доштан мумкин аст.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... майдонҳои дигар
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Бо як истиноди сусти ботинӣ дар ҳолати "uninitialized" созед.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Муҳим аст, ки мо аз соҳибӣ ба нишондиҳандаи заиф даст накашем, вагарна пас аз бозгашти `data_fn` хотира метавонад халос шавад.
        // Агар мо воқеан мехостем соҳиби моликият шавем, метавонистем барои худ нишондиҳандаи заифи дигаре эҷод кунем, аммо ин боиси навсозиҳои иловагӣ ба ҳисоби истинодҳои заъиф хоҳад шуд, ки дар акси ҳол лозим нестанд.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Истинодҳои қавӣ бояд дар якҷоягӣ истиноди сусти муштарак дошта бошанд, бинобар ин, деструктори истиноди сусти кӯҳнаи моро иҷро накунед.
        //
        mem::forget(weak);
        strong
    }

    /// Сохтани `Rc` нав бо мундариҷаи uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Rc`-и навро бо мундариҷаи номаълум сохта, бо хотира бо байтҳои `0` месозад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Сохтани `Rc<T>` нав, баргардонидани хато, агар ҷудошавӣ ноком шавад
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Як нишоннамои заифи номуайяне, ки ба ҳама нишондиҳандаҳои қавӣ тааллуқ дорад, кафолат медиҳад, ки деструктори заиф ҳеҷ гоҳ ҷудошударо ҳангоми кор даровардани деструктори қавӣ озод намекунад, ҳатто агар нишондиҳандаи суст дар дохили нишонаи қавӣ нигоҳ дошта шавад.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Сохтани `Rc` нав бо мундариҷаи номаълум, хатогиро бармегардонад, агар тақсимот ноком шавад
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Сохтани `Rc` нав бо мундариҷаи номаълум, бо хотира бо `0` байт пур мешавад ва хатогиро бармегардонад
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Pin<Rc<T>>` нав месозад.
    /// Агар `T` `Unpin`-ро татбиқ накунад, он гоҳ `value` дар хотира пинҳон хоҳад шуд ва ҳаракат кардан ғайриимкон аст.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Арзиши дохилиро бармегардонад, агар `Rc` дақиқан як истиноди қавӣ дошта бошад.
    ///
    /// Дар акси ҳол, [`Err`] бо ҳамон `Rc`, ки дар гузашта буд, баргардонида мешавад.
    ///
    ///
    /// Ин муваффақ хоҳад шуд, ҳатто агар маълумотномаҳои заиф мавҷуд бошанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // объекти мавҷударо нусхабардорӣ кунед

                // Ба заифҳо нишон диҳед, ки онҳоро бо кам кардани шумораи қавӣ пешбарӣ кардан мумкин нест ва сипас нишоннамои номуайян "strong weak"-ро хориҷ кунед ва ҳангоми кор фармудани мантиқи афтодан танҳо бо сохтани як сусти қалбакӣ.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Буридаи нави ҳисобшудаи истинодро бо мундариҷаи номаълум месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Як буридаи нави ҳисобшудаи истинодро бо мундариҷаи номаълум месозад, бо хотира бо байтҳои `0` пур карда мешавад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Ба `Rc<T>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], занг задан ба он аст, ки арзиши ботинӣ воқеан дар ҳолати ибтидоӣ бошад.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Ба `Rc<[T]>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], занг задан ба он аст, ки арзиши ботинӣ воқеан дар ҳолати ибтидоӣ бошад.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc`-ро истеъмол мекунад, ва нишоннамои парпечшударо бармегардонад.
    ///
    /// Барои роҳ надодан ба ифшои хотира, нишондиҳанда бояд бо истифода аз [`Rc::from_raw`][from_raw] ба `Rc` гузаронида шавад.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ба маълумот нишондиҳандаи хом медиҳад.
    ///
    /// Ҳисобҳо ба ҳеҷ ваҷҳ таъсир намерасонанд ва `Rc` истеъмол карда намешавад.
    /// Нишондиҳанда то даме эътибор дорад, ки дар `Rc` ҳисобҳои қавӣ вуҷуд доранд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // БЕХАТАР This: Ин наметавонад тавассути Deref::deref ё Rc::inner гузарад, зеро
        // ин барои нигоҳ доштани raw/mut исботшуда зарур аст, масалан
        // `get_mut` метавонад тавассути нишондиҳанда пас аз барқарор шудани Rc тавассути `from_raw` нависад.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Аз нишоннамои хом `Rc<T>` месозад.
    ///
    /// Нишондиҳандаи хом бояд қаблан тавассути занг ба [`Rc<U>::into_raw`][into_raw] баргардонида шуда бошад, ки дар он `U` бояд бо андозаи `T` баробар ва мутобиқ бошад.
    /// Агар `U` `T` бошад, ин хеле ночиз аст.
    /// Дар хотир доред, ки агар `U` `T` набошад, аммо ҳаҷм ва ҳамоҳангии якхела дошта бошад, ин асосан ба тарҷумаи истинодҳои намудҳои гуногун монанд аст.
    /// Барои маълумоти бештар дар бораи кадом маҳдудиятҳо дар ин ҳолат, ба [`mem::transmute`][transmute] нигаред.
    ///
    /// Истифодабарандаи `from_raw` бояд боварӣ ҳосил кунад, ки арзиши мушаххаси `T` танҳо як маротиба афтидааст.
    ///
    /// Ин вазифа хатарнок аст, зеро истифодаи номатлуб метавонад боиси бехатарии хотира гардад, ҳатто агар ба `Rc<T>` баргашта ҳеҷ гоҳ дастрас нашавад.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ба `Rc` баргардед, то пешгирӣ аз ихроҷ.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Зангҳои минбаъда ба `Rc::from_raw(x_ptr)` барои хотира хатарнок хоҳанд буд.
    /// }
    ///
    /// // Вақте ки `x` аз доираи боло баромад, хотира озод карда шуд, бинобар ин `x_ptr` ҳоло овезон аст!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Барои ёфтани RcBox аслӣ ҷубронро баръакс кунед.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ба ин ҷудокунӣ нишоннамои нави [`Weak`] месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Боварӣ ҳосил кунед, ки мо Заи сустро эҷод намекунем
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Миқдори нишондиҳандаҳои [`Weak`]-ро ба ин тақсимот меорад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Шумораи нишондиҳандаҳои пурқуввати (`Rc`)-ро ба ин тақсимот меорад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// `true`-ро бармегардонад, агар ягон нишондиҳандаи дигари `Rc` ё [`Weak`] ба ин тақсимот набошад.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Истиноди тағиршавандаро ба `Rc` додашуда бармегардонад, агар дигар нишондиҳандаҳои `Rc` ё [`Weak`] ба ҳамон тақсимот набошанд.
    ///
    ///
    /// Дар акси ҳол, [`None`]-ро бармегардонад, зеро mutate кардани арзиши муштарак бехатар нест.
    ///
    /// Инчунин ба [`make_mut`][make_mut] нигаред, ки ҳангоми мавҷудияти нишондиҳандаҳои дигар арзиши ботиниро [`clone`][clone] хоҳад кард.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Истиноди тағиршавандаро ба `Rc` додашуда бе ягон чек бармегардонад.
    ///
    /// Инчунин нигаред ба [`get_mut`], ки бехатар аст ва санҷишҳои мувофиқро анҷом медиҳад.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Ҳама нишондиҳандаҳои дигари `Rc` ё [`Weak`], ки ба ҳамин тақсимот мансубанд, набояд дар давоми қарзи баргардонида шаванд.
    ///
    /// Ин ҳолат ночиз аст, агар чунин нишондиҳандаҳо мавҷуд набошанд, масалан фавран пас аз `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Мо эҳтиёткор ҳастем, ки истинодеро дар бар гирад, ки майдонҳои "count"-ро эҷод накунанд, зеро ин бо дастрасӣ ба ҳисобҳои истинод мухолифат мекунад (масалан.
        // аз ҷониби `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true`-ро бармегардонад, агар ҳардуи "Rc`" ба тақсимоти якхела ишора кунанд (дар раги монанд ба [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Ба `Rc` додашуда истиноди тағирпазир медиҳад.
    ///
    /// Агар нишондиҳандаҳои дигари `Rc` ба ҳамин тақсимот мавҷуд бошанд, пас `make_mut` арзиши ботиниро ба ҷудошавии нав барои таъмини моликияти беназир [`clone`] хоҳад кард.
    /// Ин инчунин ҳамчун клони навиштан номида мешавад.
    ///
    /// Агар ягон нишондиҳандаи дигари `Rc` ба ин тақсимот набошад, пас [`Weak`] нишондиҳандаҳои ин тақсимот ҷудо карда мешаванд.
    ///
    /// Инчунин ба [`get_mut`] нигаред, ки ба ҷои клонкунӣ, ноком мешавад.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ҳеҷ чизро клон намекунад
    /// let mut other_data = Rc::clone(&data);    // Маълумоти дохилиро клон намекунанд
    /// *Rc::make_mut(&mut data) += 1;        // Маълумоти дохилиро клон мекунад
    /// *Rc::make_mut(&mut data) += 1;        // Ҳеҷ чизро клон намекунад
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ҳеҷ чизро клон намекунад
    ///
    /// // Ҳоло `data` ва `other_data` ба тақсимоти гуногун ишора мекунанд.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] нишоннамоҳо ҷудо карда мешаванд:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Маълумотро клон кардан лозим аст, Rcs-ҳои дигар ҳам ҳастанд.
            // Хотираро пешакӣ ҷудо кунед, то ки арзиши мустақиман нависед.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Метавонад танҳо маълумотро бидуздад, танҳо заифҳо боқӣ мондаанд
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Рафъи мустақими заифро нест кунед (дар ин ҷо ҳоҷати сохтани Заифи қалбакӣ нест-мо медонем, ки Заифҳои дигар метавонанд барои мо тоза кунанд)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ин бехатарӣ хуб аст, зеро ба мо кафолат дода мешавад, ки нишоннамои баргашта *ягона* нишондиҳандаест, ки ҳамеша ба T баргардонида мешавад.
        // Ҳисоби истинодии мо дар ин лаҳза 1 кафолат дода мешавад ва мо аз `Rc<T>` талаб кардем, ки `mut` бошад, бинобар ин мо танҳо истиноди имконпазирро ба ҷудо кардан бармегардонем.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Кӯшиши паст кардани `Rc<dyn Any>` ба намуди мушаххас.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `RcBox<T>`-ро бо фазои кофӣ барои арзиши ботинии эҳтимолан номуайян ҷудо мекунад, ки дар он арзиш тарҳбандӣ шудааст.
    ///
    /// Функсияи `mem_to_rcbox` бо нишоннамои додаҳо даъват карда мешавад ва бояд барои `RcBox<T>` нишоннамои (эҳтимолан чарб) баргардад.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Тарҳро бо истифода аз тарҳбандии арзиши додашуда ҳисоб кунед.
        // Пештар, тарҳ дар ифодаи `&*(ptr as* const RcBox<T>)` ҳисоб карда мешуд, аммо ин истиноди нодурустро ба вуҷуд овард (ниг. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `RcBox<T>`-ро бо фазои кофӣ барои арзиши ботинии эҳтимолан ҷудокардашуда, ки дар он арзиши тарҳбандӣ пешбинӣ шудааст, ҷудо мекунад ва дар сурати қатъ нашудани хато.
    ///
    ///
    /// Функсияи `mem_to_rcbox` бо нишоннамои додаҳо даъват карда мешавад ва бояд барои `RcBox<T>` нишоннамои (эҳтимолан чарб) баргардад.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Тарҳро бо истифода аз тарҳбандии арзиши додашуда ҳисоб кунед.
        // Пештар, тарҳ дар ифодаи `&*(ptr as* const RcBox<T>)` ҳисоб карда мешуд, аммо ин истиноди нодурустро ба вуҷуд овард (ниг. #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Барои тарҳбандӣ ҷудо кунед.
        let ptr = allocate(layout)?;

        // RcBox-ро оғоз кунед
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// `RcBox<T>`-ро бо фазои кофӣ барои арзиши ботинии беандоза ҷудо мекунад
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Бо истифода аз арзиши додашуда барои `RcBox<T>` ҷудо кунед.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Арзишро ҳамчун байт нусхабардорӣ кунед
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Ҷудокуниро бидуни тарки мундариҷа озод кунед
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// `RcBox<[T]>`-ро бо дарозии додашуда тақсим мекунад.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Нусхабардории унсурҳо аз бурида ба Rc <\[T\]>
    ///
    /// Хатарнок аст, зеро зангзан бояд ё соҳиби моликият шавад ё `T: Copy`-ро бандад
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// `Rc<[T]>` месозад, аз iterator маълум аст, ки андозаи муайян дорад.
    ///
    /// Рафтор номуайян аст, агар андоза нодуруст бошад.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Посбони Panic ҳангоми клонидани унсурҳои Т.
        // Дар сурати пайдо шудани panic, унсурҳое, ки ба RcBox нав навишта шудаанд, партофта мешаванд ва хотираи онҳо холӣ мешавад.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Нишондиҳанда ба унсури аввал
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ҳама равшан.Посбонро фаромӯш кунед, то он RcBox навро озод накунад.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ихтисоси trait, ки барои `From<&[T]>` истифода мешавад.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Тарки `Rc`.
    ///
    /// Ин ҳисобҳои пурқувватро коҳиш медиҳад.
    /// Агар ҳисобҳои қавии истинод ба сифр расанд, пас танҳо истинодҳои дигар (агар бошанд) [`Weak`] мебошанд, аз ин рӯ мо арзиши ботиниро `drop` мекунем.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ҳеҷ чизро чоп намекунад
    /// drop(foo2);   // "dropped!" чоп мекунад
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // объекти мавҷудбударо нобуд созед
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ҳозир, ки мо мундариҷаро нобуд кардем, нишоннамои номаълуми "strong weak"-ро нест кунед.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Клони нишоннамои `Rc` месозад.
    ///
    /// Ин нишондиҳандаи дигарро ба ҳамон тақсимот эҷод мекунад ва шумораи истиноди қавӣро афзоиш медиҳад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `Rc<T>` навро бо арзиши `Default` барои `T` месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Хак барои иҷозат додани тахассус дар `Eq`, гарчанде ки `Eq` усули худро дорад.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Мо ин ихтисосро дар ин ҷо анҷом медиҳем, на ҳамчун оптимизатсияи умумӣ дар `&T`, зеро дар акси ҳол он ба ҳама санҷишҳои баробарӣ дар refs хароҷот илова мекунад.
/// Мо чунин мешуморем, ки "Rc`s" барои нигоҳ доштани арзишҳои калон истифода мешаванд, ки суст клон мешаванд, аммо барои тафтиши баробарӣ вазнинанд ва ин хароҷотро ба осонӣ пардохт мекунад.
///
/// Инчунин эҳтимол дорад, ки ду клони `Rc` дошта бошанд, ки ба ҳамон арзиш ишора мекунанд, назар ба ду "T".
///
/// Мо инро танҳо вақте иҷро карда метавонем, ки `T: Eq` ҳамчун `PartialEq` дидаву дониста ғайри қобили ислоҳ бошад.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Баробарӣ барои ду "Rc`.
    ///
    /// Ду 'Rc` баробаранд, агар қиматҳои дохилии онҳо баробар бошанд, ҳатто агар онҳо дар тақсимоти гуногун нигоҳ дошта шаванд.
    ///
    /// Агар `T` инчунин `Eq`-ро татбиқ кунад (инъикоскунандаи баробарӣ), ду 'Rc`, ки ба ҳамон тақсимот ишора мекунанд, ҳамеша баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Нобаробарӣ барои ду `Rc`s.
    ///
    /// Ду 'Rc` нобаробаранд, агар қиматҳои дохилии онҳо нобаробар бошанд.
    ///
    /// Агар `T` инчунин `Eq`-ро татбиқ кунад (инъикоскунандаи баробарӣ), ду 'Rc`, ки ба ҳамон тақсимот ишора мекунанд, ҳеҷ гоҳ нобаробар нестанд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Муқоисаи қисман барои ду "Rc`".
    ///
    /// Ҳарду бо занг задан ба `partial_cmp()` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Камтар аз муқоиса барои ду "Rc`".
    ///
    /// Ҳарду бо занг задан ба `<` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Муқоисаи ду "Rc`" камтар ё баробар ".
    ///
    /// Ҳарду бо занг задан ба `<=` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Бузургтар аз муқоиса барои ду "Rc`".
    ///
    /// Ҳарду бо занг задан ба `>` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Муқоисаи ду "Rc` аз"зиёд ё баробар".
    ///
    /// Ҳарду бо занг задан ба `>=` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Муқоиса барои ду Rc`.
    ///
    /// Ҳарду бо занг задан ба `cmp()` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Як буридаи ҳисобшудаи истинодро ҷудо кунед ва онро бо клонидани ҷузъҳои "v" пур кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Буридаи сатри ҳисобкардашударо ҷудо кунед ва ба он `v` нусхабардорӣ кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Буридаи сатри ҳисобкардашударо ҷудо кунед ва ба он `v` нусхабардорӣ кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Объекти қуттиро ба тақсимоти нав, истинод ба ҳисоб, интиқол диҳед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Буридаи ҳисобшудаи истинодро ҷудо кунед ва ҷузъҳои "v"-ро ба он дохил кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Ба Vec иҷозат диҳед, ки хотираи худро озод кунад, аммо мундариҷаро нобуд накунад
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Ҳар як элементро дар `Iterator` мегирад ва онро ба `Rc<[T]>` ҷамъ мекунад.
    ///
    /// # Хусусиятҳои иҷрои
    ///
    /// ## Парвандаи умумӣ
    ///
    /// Дар ҳолати умумӣ, ҷамъоварӣ ба `Rc<[T]>` бо роҳи ҷамъоварӣ ба `Vec<T>` анҷом дода мешавад.Яъне, ҳангоми навиштани инҳо:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ин тавре рафтор мекунад, ки гӯё навиштаем:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Маҷмӯи якуми тақсимот дар ин ҷо рух медиҳад.
    ///     .into(); // Тақсимоти дуюм барои `Rc<[T]>` дар ин ҷо рух медиҳад.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ин барои сохтани `Vec<T>` чанд маротиба лозим аст ва он гоҳ як маротиба барои табдил додани `Vec<T>` ба `Rc<[T]>` ҷудо мекунад.
    ///
    ///
    /// ## Итераторҳои дарозии маълум
    ///
    /// Вақте ки `Iterator`-и шумо `TrustedLen`-ро амалӣ мекунад ва андозаи дақиқ дорад, барои `Rc<[T]>` тақсимоти ягона дода мешавад.Барои намуна:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Дар ин ҷо танҳо як тақсимоти ягона рух медиҳад.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Ихтисоси trait, ки барои ҷамъоварӣ ба `Rc<[T]>` истифода мешавад.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ин барои як iterator `TrustedLen` аст.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕХАТАР We: Мо бояд кафолат диҳем, ки даврзананда дарозии дақиқ дорад ва мо дорем.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Бозгаштан ба татбиқи муқаррарӣ.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` версияи [`Rc`] мебошад, ки истиноди ғайримуқаррарӣ ба ҷудошавии идорашаванда дорад.Ба ҷудокунӣ тавассути даъвати [`upgrade`] дар нишоннамои `Weak`, ки ["Опсия"] "<` [`Rc`]"-ро бармегардонад, дастрас аст.<T>>`.
///
/// Азбаски истиноди `Weak` нисбати моликият ба ҳисоб гирифта намешавад, он арзиши афтодани ҷудокунандаро пешгирӣ намекунад ва худи `Weak` дар бораи арзиши ҳанӯз мавҷудбуда кафолат намедиҳад.
/// Ҳамин тариқ, он метавонад [`None`]-ро баргардонад, вақте ки [`такмил '] d.
/// Аммо дар хотир доред, ки истиноди `Weak` * имкон намедиҳад, ки худи тақсимот (мағозаи пуштибонӣ) тақсим карда шавад.
///
/// Нишондиҳандаи `Weak` барои нигоҳ доштани истиноди муваққатӣ ба тақсимоти аз ҷониби [`Rc`] идорашаванда бе пешгирӣ аз афтодани арзиши ботинии он муфид аст.
/// Он инчунин барои пешгирии истинодҳои даврӣ дар байни нишондиҳандаҳои [`Rc`] истифода мешавад, зеро истинодҳои мутақобила ҳеҷ гоҳ намегузоранд, ки [`Rc`] партофта шавад.
/// Масалан, дарахт метавонад нишондиҳандаҳои пурқуввати [`Rc`] аз гиреҳҳои волидайн ба кӯдакон ва `Weak` нишондиҳандаҳо аз кӯдакон ба волидайн дошта бошад.
///
/// Усули маъмулии ба даст овардани нишоннамои `Weak` занг задан ба [`Rc::downgrade`] мебошад.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ин `NonNull` аст, то имкон медиҳад, ки андозаи ин навъи оптимизатсия оптимизатсия карда шавад, аммо он ҳатман нишоннамои дуруст нест.
    //
    // `Weak::new` онро ба `usize::MAX` муқаррар мекунад, то ки дар тӯда ҷой ҷудо кардан лозим набошад.
    // Ин як аҳамияти нишоннамои воқеӣ нест, зеро RcBox ҳадди аққал ҳамоҳанг мекунад.
    // Ин танҳо вақте имконпазир аст, ки `T: Sized`;`T` беандоза ҳеҷ гоҳ намерасад.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Сохтани `Weak<T>` нав, бе тақсим кардани ягон хотира.
    /// Даъват кардани [`upgrade`] дар арзиши баргардонидан ҳамеша [`None`] медиҳад.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Ёрнавис барои расонидани дастрасӣ ба истинод бидуни ҳеҷ гуна изҳорот дар бораи майдони маълумот ҳисоб кунед.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Нишондиҳандаи хомро ба объекти `T`, ки бо ин `Weak<T>` ишора шудааст, бармегардонад.
    ///
    /// Нишондиҳанда танҳо дар сурате эътибор дорад, ки агар баъзе истинодҳои қавӣ вуҷуд дошта бошанд.
    /// Нишондиҳанда метавонад овезон, номувофиқ ё ҳатто [`null`] бошад, дар акси ҳол.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ҳарду ба як ашё ишора мекунанд
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Қавӣ дар ин ҷо онро зинда нигоҳ медорад, бинобар ин мо метавонем ба объект дастрасӣ пайдо кунем.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Аммо дигар не.
    /// // Мо метавонем weak.as_ptr() кор кунем, аммо дастрасӣ ба нишондиҳанда ба рафтори номуайян оварда мерасонад.
    /// // assert_eq! ("салом", хатарнок {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Агар нишоннамо овезон бошад, мо посбонро мустақиман бармегардонем.
            // Ин суроғаи эътибори хуб буда наметавонад, зеро бори ҳадди аққал баробари RcBox (usize) мувофиқат мекунад.
            ptr as *const T
        } else {
            // БЕХАТАР: : агар is_dangling false баргардад, пас нишоннамо мустақим аст.
            // Маблағи пардохт метавонад дар ин лаҳза коҳиш ёбад ва мо бояд собитро нигоҳ дорем, бинобар ин манипулясияи хомро истифода баред.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>`-ро истеъмол мекунад ва онро ба нишондиҳандаи хом табдил медиҳад.
    ///
    /// Ин нишондиҳандаи сустро ба нишондиҳандаи хом табдил медиҳад ва ҳамзамон моликияти як истиноди сустро нигоҳ медорад (ҳисоби заиф бо ин амал тағир дода намешавад).
    /// Онро бо [`from_raw`] ба `Weak<T>` баргардонидан мумкин аст.
    ///
    /// Худи ҳамон маҳдудиятҳои дастрасӣ ба ҳадафи нишоннамо бо [`as_ptr`] амал мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Нишондиҳандаи хомро, ки қаблан [`into_raw`] сохта буд, ба `Weak<T>` бармегардонад.
    ///
    /// Ин метавонад барои ба даст овардани истиноди қавӣ (бо занг задан ба [`upgrade`] дертар) ё тақсим кардани ҳисоби заиф бо тарки `Weak<T>` истифода шавад.
    ///
    /// Он моликияти як истиноди заифро мегирад (ба истиснои нишондиҳандаҳое, ки [`new`] сохтаанд, зеро инҳо чизе надоранд; метод то ҳол дар онҳо кор мекунад).
    ///
    /// # Safety
    ///
    /// Нишондиҳанда бояд аз [`into_raw`] сарчашма гирифта бошад ва то ҳол бояд истиноди сусти эҳтимолии худро дошта бошад.
    ///
    /// Иҷозат дода шудааст, ки шумораи пурзӯр дар вақти даъват ба 0 бошад.
    /// Бо вуҷуди ин, ин моликияти як истиноди заифро, ки ҳоло ҳамчун нишоннамои хом муаррифӣ шудааст, ба худ мегирад (ҳисоби заиф бо ин амал тағир дода намешавад) ва аз ин рӯ он бояд бо як даъвати қаблӣ ба [`into_raw`] ҷуфт карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ҳисоби охирини заифро коҳиш диҳед.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Барои контекст дар бораи чӣ гуна ба даст овардани нишоннамои вуруд ба Weak::as_ptr нигаред.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ин як сусти сустист.
            ptr as *mut RcBox<T>
        } else {
            // Дар акси ҳол, мо кафолат медиҳем, ки нишондиҳанда аз як сусти нолозим баромадааст.
            // БЕХАТАР: : data_offset барои занг задан бехатар аст, зеро ptr ба T воқеӣ (эҳтимолан афтода) муроҷиат мекунад.
            let offset = unsafe { data_offset(ptr) };
            // Ҳамин тариқ, мо ҷубронро бармегардонем, то тамоми RcBox гирем.
            // БЕХАТАР: : нишоннамо аз заиф сарчашма мегирад, бинобар ин ин ҷуброн бехатар аст.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕХАТАР: : мо ҳоло нишоннамои аслии Заифро барқарор кардем, пас метавонем Заифҳоро эҷод кунем.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Кӯшишҳои баланд бардоштани нишоннамои `Weak` ба [`Rc`], ба таъхир афтодани арзиши ботиниро дар сурати муваффақ шудан.
    ///
    ///
    /// [`None`]-ро бармегардонад, агар арзиши дохилӣ аз он пас афтода бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ҳама нишондиҳандаҳои пурқувватро нест кунед.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Шумораи нишондиҳандаҳои пурқуввати (`Rc`)-ро, ки ба ин тақсимот ишора мекунанд, меорад.
    ///
    /// Агар `self` бо истифодаи [`Weak::new`] сохта шуда бошад, ин 0 бармегардад.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Миқдори нишондиҳандаҳои `Weak`-ро, ки ба ин тақсимот ишора мекунанд, меорад.
    ///
    /// Агар ягон нишондоди қавӣ боқӣ намонад, ин сифр бармегардад.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ptr-и заифи заифро хориҷ кунед
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Вақте ки нишоннамо овезон аст ва `RcBox` ҷудошуда вуҷуд надорад, бармегардад `None`, (яъне вақте ки ин `Weak` аз ҷониби `Weak::new` сохта шудааст).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Мо эҳтиёткор ҳастем, ки маълумотномаи фарогирии майдони "data"-ро эҷод накунем, зеро майдон метавонад ҳамзамон мутатсия карда шавад (масалан, агар `Rc` охирин партофта шавад, майдони маълумот дар ҷои худ партофта мешавад).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true`-ро бармегардонад, агар ҳардуи "Заиф" ба тақсимоти якхела ишора кунанд (ба [`ptr::eq`] монанд), ё агар ҳарду ба ягон ҷудошавӣ ишора накунанд (зеро онҳо бо `Weak::new()`) сохта шудаанд).
    ///
    ///
    /// # Notes
    ///
    /// Азбаски ин нишондиҳандаҳоро муқоиса мекунад, ин маънои онро дорад, ки `Weak::new()` бо ҳам баробар хоҳанд шуд, гарчанде ки онҳо ба ягон тақсимот ишора намекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Муқоисаи `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Нишондиҳандаи `Weak`-ро афтондааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ҳеҷ чизро чоп намекунад
    /// drop(foo);        // "dropped!" чоп мекунад
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ҳисоби заиф аз 1 сар мешавад ва танҳо дар сурате ба сифр мегузарад, ки ҳамаи нишондиҳандаҳои қавӣ нопадид шуда бошанд.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Клони нишоннамои `Weak` месозад, ки ба ҳамон тақсимот ишора мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Сохтани `Weak<T>` нав, ҷудо кардани хотира барои `T` бидуни оғозёбӣ.
    /// Даъват кардани [`upgrade`] дар арзиши баргардонидан ҳамеша [`None`] медиҳад.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Мо барои мубориза бо бехатарии mem::forget инҷоро тафтиш кардем.Алалхусус
// агар шумо mem::forget Rcs (ё заифҳо) дошта бошед, ҳисобкунии ref метавонад пур шавад ва пас шумо метавонед тақсимотро ҳангоми мавҷудияти Rcs (ё суст)-и барҷаста озод кунед.
//
// Мо исқоти ҳамл мекунем, зеро ин чунин сенарияи таназзул аст, ки ба мо фарқе надорад, ки чӣ ҳодиса рӯй медиҳад-ҳеҷ як барномаи воқеӣ набояд инро ҳаргиз таҷриба кунад.
//
// Ин бояд хароҷоти ночиз дошта бошад, зеро ба шумо дар ҳақиқат ба туфайли моликият ва move-semantics ин миқдорро дар Rust клон кардан лозим нест.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Мо мехоҳем, ки ба ҷои тарки арзиш, изофаро қатъ кунем.
        // Ҳисоби истинод ҳеҷ гоҳ сифр нахоҳад шуд, вақте ки ин даъват мешавад;
        // Бо вуҷуди ин, мо ин ҷо исқоти ҳамл мекунем, то LLVM-ро дар бораи оптимизатсияи ғайримуқаррарӣ ишора кунем.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Мо мехоҳем, ки ба ҷои тарки арзиш, изофаро қатъ кунем.
        // Ҳисоби истинод ҳеҷ гоҳ сифр нахоҳад шуд, вақте ки ин даъват мешавад;
        // Бо вуҷуди ин, мо ин ҷо исқоти ҳамл мекунем, то LLVM-ро дар бораи оптимизатсияи ғайримуқаррарӣ ишора кунем.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Дар зарфи `RcBox` ҷубронро барои бори паси нишоннамо гиред.
///
/// # Safety
///
/// Нишондиҳанда бояд ба мисоли қаблан дурусти T ишора кунад (ва метамаълумотҳои дуруст дошта бошад), аммо T-ро партофтан иҷозат дода мешавад.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Арзиши номуайянро ба охири RcBox рост кунед.
    // Азбаски RcBox repr(C) аст, он ҳамеша охирин майдон дар хотира хоҳад буд.
    // БЕХАТАР: : азбаски ягона намудҳои номатлуб имконпазиранд, иловаро, объектҳои trait,
    // ва намудҳои экстерн, талаботи бехатарии вуруд дар ҳоли ҳозир барои қонеъ кардани талаботи align_of_val_raw кифоя аст;ин ҷузъиёти татбиқи забон аст, ки берун аз std ба он эътимод кардан мумкин нест.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}