use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Ҳамаи ҷуфтҳои арзиши калидиро аз ҳамроҳии ду итератори болоӣ илова мекунад, ва тағирёбандаи `length` дар роҳ.Охирин, ҳангоми занг задан ба шахси зангзада, пешгирӣ аз ифшои онро осон мекунад.
    ///
    /// Агар ҳарду итератор як калид истеҳсол кунанд, ин усул ҷуфтро аз итератори чап партофта, ҷуфтро аз итератори рост илова мекунад.
    ///
    /// Агар шумо хоҳед, ки дарахт бо тартиби қатъиян болораванда ба охир расад, ба монанди `BTreeMap`, ҳарду итератор бояд калидҳоро бо тартиби қатъиян афзоянда истеҳсол кунанд, ки ҳар яке аз ҳамаи тугмаҳои дарахт калонтар, аз ҷумла ҳамаи калидҳое, ки аллакай дар дарахт ҳангоми вуруд мавҷуданд.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Мо барои якҷоя кардани `left` ва `right` ба пайдарпаии мураттаб дар вақти хаттӣ омодагӣ мебинем.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Дар ҳамин ҳол, мо дарахтро аз пайдарпаии мураттаб дар вақти хатӣ месозем.
        self.bulk_push(iter, length)
    }

    /// Ҳама ҷуфтҳои калидиро ба охири дарахт меандозад ва тағирёбандаи `length` дар роҳ.
    /// Охирин, ҳангоми ба ҳарос афтодани такрори пешрафта аз занг задан осонтар мекунад.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Ҳамаи ҷуфтҳои калидиро тағир диҳед ва онҳоро ба гиреҳҳо дар сатҳи зарурӣ тела диҳед.
        for (key, value) in iter {
            // Кӯшиш кунед, ки ҷуфти арзиши калидҳоро ба гиреҳи кунунии барг тела диҳед.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Фосила боқӣ намондааст, боло бароед ва ба он ҷо тела диҳед.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Гиреҳе ёфтед, ки фосилааш мондааст, ба ин ҷо зер кунед.
                                open_node = parent;
                                break;
                            } else {
                                // Боз боло бароед.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Мо дар боло ҳастем, гиреҳи нави реша эҷод кунед ва ба он ҷо тела диҳед.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Ҷуфти калидӣ ва зерсохтори рости навро пахш кунед.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Боз ҳам ба барги аз ҳама рост поёнтар равед.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Дар тӯли ҳар як такрор дарозии онро зиёд кунед, то боварӣ ҳосил кунед, ки харита унсурҳои замимашударо афтонад, ҳатто агар пешрави воҳима ба ҳарос ояд.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Итератор барои якҷоя кардани ду пайдарпаии мураттаб ба як
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Агар ду калид баробар бошанд, ҷуфти калидро аз манбаи рост бармегардонад.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}