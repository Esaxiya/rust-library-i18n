// Ин кӯшиши амалисозии пас аз идеал аст
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Азбаски Rust дарвоқеъ намудҳои вобастагӣ ва рекурсияи полиморфӣ надорад, мо корҳои зиёдеро анҷом медиҳем.
//

// Ҳадафи асосии ин модул ҷилавгирӣ аз мураккабӣ бо дарахт ҳамчун контейнери умумӣ (агар аҷиб шаклаш) бошад ва канорагирӣ аз муносибат бо аксари инвариантҳои B-Tree мебошад.
//
// Ҳамин тариқ, ин модул фарқе надорад, ки сабтҳо ҷобаҷо карда шудаанд, кадом гиреҳҳо метавонанд кам пур карда шаванд ва ё ҳатто маънои камшумор чӣ маъно дорад.Аммо, мо ба якчанд инвариантҳо такя мекунем:
//
// - Дарахтон бояд depth/height либоси ягона дошта бошанд.Ин маънои онро дорад, ки ҳар як роҳ ба сӯи барг аз гиреҳи додашуда дарозии дақиқ дорад.
// - Гиреҳи дарозии `n` дорои калидҳои `n`, арзишҳои `n` ва кунҷҳои `n + 1` мебошад.
//   Ин маънои онро дорад, ки ҳатто гиреҳи холӣ ҳадди аққал як edge дорад.
//   Барои гиреҳи барг, "having an edge" танҳо маънои онро дорад, ки мо мавқеъро дар гиреҳ муайян карда метавонем, зеро канори барг холӣ аст ва ба пешниҳоди маълумот ниёз надорад.
// Дар гиреҳи дохилӣ, edge ҳам мавқеъро муайян мекунад ва ҳам нишоннамои гиреҳи кӯдакро дар бар мегирад.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Намоиши аслии гиреҳҳои барг ва қисми намояндагии гиреҳҳои дохилӣ.
struct LeafNode<K, V> {
    /// Мо мехоҳем дар `K` ва `V` ковариант бошем.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Индекси ин гиреҳ ба массиви `edges` гиреҳи волидайн.
    /// `*node.parent.edges[node.parent_idx]` бояд ҳамон чизи `node` бошад.
    /// Ин танҳо вақте оғоз меёбад, ки `parent` бекор бошад, кафолат дода мешавад.
    parent_idx: MaybeUninit<u16>,

    /// Шумораи калидҳо ва арзишҳои ин гиреҳ нигоҳ медорад.
    len: u16,

    /// Массивҳо, ки маълумоти воқеии гиреҳро нигоҳ медоранд.
    /// Танҳо аввалин `len` унсурҳои ҳар як массив ибтидоӣ ва эътибор доранд.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// `LeafNode` навро дар ҷои худ оғоз мекунад.
    unsafe fn init(this: *mut Self) {
        // Ҳамчун сиёсати умумӣ, мо майдонҳоро бетаъсир мегузорем, агар имкон дошта бошанд, зеро ин бояд ҳам зудтар ва ҳам дар пайгирии Valgrind осонтар бошад.
        //
        unsafe {
            // parent_idx, калидҳо ва валҳо ҳама шоядUuninit мебошанд
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// `LeafNode` нави қуттӣ месозад.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Намояндагии гиреҳҳои дохилӣ.Мисли `LeafNode`, инҳо бояд дар паси"BoxedNode"пинҳон карда шаванд, то тарки калидҳо ва арзишҳои номатлуб пешгирӣ карда шавад.
/// Ҳар як нишоннамо ба `InternalNode` метавонад бевосита ба нишоннамо ба қисми аслии `LeafNode` гиреҳ андохта шавад ва имкон диҳад, ки рамзҳо дар гиреҳҳо ва баргҳои дохилӣ ба таври умум амал кунанд, бидуни он ки ҳатто тафтиш кунанд, ки кадом як нишоннамо ба он ишора мекунад.
///
/// Ин амвол тавассути истифодаи `repr(C)` фаъол карда шудааст.
///
#[repr(C)]
// gdb_providers.py ин номро барои дарунсохт истифода мебарад.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Нишондиҳандаҳо ба фарзандони ин гиреҳ.
    /// `len + 1` аз инҳо ибтидоӣ ва эътиборнок ҳисобида мешаванд, ба истиснои он, ки дар охири он дарахт тавассути қарзи навъи `Dying` нигоҳ дошта мешавад, баъзе аз ин нишондиҳандаҳо овезон мебошанд.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// `InternalNode` нави қуттӣ месозад.
    ///
    /// # Safety
    /// Инвариантҳои гиреҳҳои дохилӣ ин аст, ки онҳо ҳадди аққал як edge-и ибтидоӣ ва дуруст доранд.
    /// Ин вазифа чунин edge насб намекунад.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Мо бояд танҳо маълумотро оғоз кунем;кунҷҳо BəlUninit мебошанд.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Нишондиҳандаи идорашаванда, ғайрифаъол ба гиреҳ.Ин ё нишоннамои ба `LeafNode<K, V>` тааллуқдошта ё нишоннамои ба `InternalNode<K, V>` тааллуқдошта мебошад.
///
/// Аммо, `BoxedNode` ҳеҷ маълумоте дар бораи он надорад, ки кадоме аз ду намуди гиреҳҳо воқеан онро дар бар мегирад ва қисман аз сабаби ин набудани иттилоот, навъи алоҳида нест ва деструктори надорад.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Гиреҳи решаи дарахти моликият.
///
/// Дар хотир доред, ки ин деструктор надорад ва онро бояд дастӣ тоза кард.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Дарахти навро бармегардонад, бо гиреҳи решаи худ, ки дар аввал холӣ аст.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` набояд сифр бошад.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Мутаносибан гиреҳи решаи моликиятро қарз мегирад.
    /// Баръакси `reborrow_mut`, ин бехатар аст, зеро арзиши баргардонидан наметавонад решаро нобуд кунад ва дигар ишораҳо ба дарахт вуҷуд дошта наметавонанд.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Гиреҳи решаи моликиятро каме мутавассит қарз мегирад.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Бебозгашт ба истиноде мегузарад, ки гузаришро иҷозат медиҳад ва усулҳои харобиоварро пешниҳод мекунад ва чизи дигаре.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Гиреҳи нави дохилиро бо як edge ягона ба гиреҳи решаи қаблӣ ишора мекунад, илова кунед, онро гиреҳи нав гиреҳ гиред ва онро баргардонед.
    /// Ин баландиро 1 зиёд мекунад ва баръакси `pop_internal_level` мебошад.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ба истиснои он ки мо фақат фаромӯш кардем, ки ҳоло дохил ҳастем:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Гиреҳи решаи дохилиро хориҷ мекунад, бо истифода аз фарзанди аввалини он ҳамчун гиреҳи решаи нав.
    /// Азбаски он танҳо вақте даъват карда мешавад, ки гиреҳи реша танҳо як фарзанд дошта бошад, дар ҳеҷ кадоме аз калидҳо, арзишҳо ва дигар фарзандон тоза карда намешавад.
    ///
    /// Ин баландиро ба 1 коҳиш медиҳад ва баръакси `push_internal_level` мебошад.
    ///
    /// Дастрасии истисноиро ба объекти `Root` талаб мекунад, аммо на ба гиреҳи реша;
    /// он дигар дастакҳо ё ишораҳо ба гиреҳи решаро беэътибор намекунад.
    ///
    /// Panics агар сатҳи дохилӣ набошад, яъне агар гиреҳи реша барг бошад.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // БЕХАТАР: : мо тасдиқ кардем, ки дохилӣ ҳастем.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // БЕХАТАР: : мо танҳо `self` қарз гирифтаем ва навъи қарзи он истисноӣ аст.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // БЕХАТАР: : аввалин edge ҳамеша ибтидоӣ карда мешавад.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` ҳамеша дар `K` ва `V` covariant аст, ҳатто вақте ки `BorrowType` `Mut` бошад.
// Ин аз ҷиҳати техникӣ нодуруст аст, аммо бо сабаби истифодаи дохилии `NodeRef` ба ҳеҷ гуна хатар оварда наметавонад, зеро мо нисбат ба `K` ва `V` комилан умумӣ ҳастем.
//
// Аммо, вақте ки ягон намуди оммавӣ `NodeRef`-ро печонад, боварӣ ҳосил кунед, ки он тафовути дуруст дорад.
//
/// Истинод ба гиреҳ.
///
/// Ин намуд як қатор параметрҳо дорад, ки чӣ гуна амал кардани онро назорат мекунанд:
/// - `BorrowType`: Намуди думӣ, ки намуди қарзро тавсиф мекунад ва тамоми умрро дар бар мегирад.
///    - Вақте ки ин `Immut<'a>` бошад, `NodeRef` тақрибан ба монанди `&'a Node` амал мекунад.
///    - Вақте ки ин `ValMut<'a>` бошад, `NodeRef` нисбат ба калидҳо ва сохтори дарахтҳо тақрибан ба монанди `&'a Node` амал мекунад, аммо инчунин имкон медиҳад, ки бисёр нишонаҳои тағиршаванда ба арзишҳо дар саросари дарахт ҳамзистӣ кунанд.
///    - Вақте ки ин `Mut<'a>` бошад, `NodeRef` тақрибан ба монанди `&'a mut Node` амал мекунад, гарчанде ки усулҳои дохилкунӣ нишондиҳандаи тағиршавандаро бо ҳам арзиш доранд.
///    - Вақте ки ин `Owned` бошад, `NodeRef` тақрибан ба монанди `Box<Node>` амал мекунад, аммо деструктор надорад ва онро бояд дастӣ тоза кард.
///    - Вақте ки ин `Dying` бошад, `NodeRef` ҳанӯз ҳам тақрибан ба монанди `Box<Node>` амал мекунад, аммо усулҳои нобуд кардани дарахт дорад ва усулҳои оддӣ, дар ҳоле, ки барои занг задан хатарнок нестанд, метавонанд UB-ро бихонанд, агар нодуруст номида шавад.
///
///   Азбаски ҳама гуна `NodeRef` имкон медиҳад, ки тавассути дарахт сайр кунад, `BorrowType` самаранок ба тамоми дарахт дахл дорад, на танҳо ба худи гиреҳ.
/// - `K` ва `V`: Инҳо намуди калидҳо ва арзишҳо мебошанд, ки дар гиреҳҳо нигоҳ дошта мешаванд.
/// - `Type`: Ин метавонад `Leaf`, `Internal` ё `LeafOrInternal` бошад.
/// Вақте ки ин `Leaf` бошад, `NodeRef` ба гиреҳи барг ишора мекунад, вақте ки ин `Internal` бошад, `NodeRef` ба гиреҳи дохилӣ ишора мекунад ва вақте ки ин `LeafOrInternal` бошад, `NodeRef` метавонад ба ҳар як намуди гиреҳ ишора кунад.
///   `Type` ҳангоми берун аз `NodeRef` истифода бурдан `NodeType` номида мешавад.
///
/// Ҳарду `BorrowType` ва `NodeType` маҳдуд месозанд, ки мо кадом усулҳоро амалӣ мекунем, то аз амнияти навъи статикӣ истифода барем.Дар истифодаи чунин маҳдудиятҳо маҳдудиятҳо мавҷуданд:
/// - Барои ҳар як параметри навъи, мо метавонем танҳо як усулро ба таври умум ё барои як навъи махсус муайян кунем.
/// Масалан, мо метавонем усули ба монанди `into_kv`-ро барои ҳама `BorrowType` ё як бор барои ҳамаи намудҳое, ки умрро дарбар мегиранд, муайян карда наметавонем, зеро мо мехоҳем, ки он истинодҳои `&'a`-ро баргардонад.
///   Аз ин рӯ, мо онро танҳо барои навъи камқудрати `Immut<'a>` муайян мекунем.
/// - Мо наметавонем маҷбуркунии махфиро аз гуфти `Mut<'a>` то `Immut<'a>` ба даст орем.
///   Аз ин рӯ, мо бояд `reborrow`-ро ба таври қавитар ба `NodeRef` даъват кунем, то ба усули ба монанди `into_kv` бирасем.
///
/// Ҳамаи усулҳо дар `NodeRef`, ки як навъ истинодро бармегардонанд, ё:
/// - Андешидани `self` бо арзиши, ва баргардонидани умри `BorrowType` гузаронида.
///   Баъзан, барои ба кор бурдани чунин усул, мо бояд ба `reborrow_mut` занг занем.
/// - Андешидани `self` тавассути истинод, ва (implicitly) умри ин истинодро бармегардонад, ба ҷои он умри `BorrowType`.
/// Ҳамин тавр, чеки қарз кафолат медиҳад, ки `NodeRef` то он даме, ки истиноди баргашта истифода мешавад, боқӣ мондааст.
///   Усулҳои дастгирии дохилкунӣ ин қоидаро тавассути баргардонидани нишоннамои хом, яъне истинод бе ягон умр хам мекунанд.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Шумораи сатҳҳое, ки гиреҳ ва сатҳи баргҳо аз ҳам ҷудоанд, як доимии гиреҳ, ки онро `Type` комилан тавсиф карда наметавонад ва худи гиреҳ ҳам онро захира намекунад.
    /// Мо бояд танҳо баландии гиреҳи решаро нигоҳ дорем ва баландии ҳар як гиреҳи дигарро аз он барорем.
    /// Агар `Type` `Leaf` бошад, бояд сифр бошад ва агар `Type` `Internal` бошад, нол аст.
    ///
    ///
    height: usize,
    /// Нишондиҳанда ба барг ё гиреҳи дохилӣ.
    /// Таърифи `InternalNode` кафолат медиҳад, ки нишондиҳанда ба ҳарду ҳолат эътибор дорад.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Истиноди гиреҳро, ки ҳамчун `NodeRef::parent` баста шуда буд, кушоед.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Маълумоти гиреҳи дохилиро нишон медиҳад.
    ///
    /// Барои барҳам додани истинодҳои дигар ба ин гиреҳ, ptr хомро бармегардонад.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // БЕХАТАР: : навъи гиреҳи статикӣ `Internal` аст.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Дастрасии истисноии маълумоти гиреҳи дохилиро қарз медиҳад.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Дарозии гиреҳро меёбад.Ин шумораи калидҳо ё арзишҳо мебошад.
    /// Шумораи кунҷҳо `len() + 1` аст.
    /// Дар хотир доред, ки бо вуҷуди бехатар будан, даъват кардани ин вазифа метавонад таъсири манфии истинодҳои тағиршавандаро, ки рамзи хатарнок эҷод кардааст, дошта бошад.
    ///
    pub fn len(&self) -> usize {
        // Муҳим, мо танҳо ба майдони `len` дастрасӣ дорем.
        // Агар BorrowType marker::ValMut бошад, метавонад истинодҳои барҷастаи тағирёбанда ба арзишҳое бошанд, ки мо онҳоро беэътибор накунем.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Шумораи сатҳҳоеро, ки гиреҳ ва баргҳо ҷудо мебошанд, бармегардонад.
    /// Баландии сифр маънои онро дорад, ки гиреҳ худи барг аст.
    /// Агар шумо дарахтонро бо решаи боло тасаввур кунед, рақам мегӯяд, ки гиреҳ дар кадом баландӣ пайдо мешавад.
    /// Агар шумо дарахтонро бо баргҳои боло тасаввур кунед, рақам нишон медиҳад, ки дарахт дар болои гиреҳ чӣ гуна баланд аст.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Муваққатан истиноди тағирнопазирро ба ҳамон гиреҳ мебарорад.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Қисми барги ҳама гуна барг ё гиреҳи дохилиро нишон медиҳад.
    ///
    /// Барои барҳам додани истинодҳои дигар ба ин гиреҳ, ptr хомро бармегардонад.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Гиреҳ бояд ҳадди аққал барои қисми LeafNode эътибор дошта бошад.
        // Ин истинод дар навъи NodeRef нест, зеро мо намедонем, ки он беназир ё муштарак бошад.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Волидайни гиреҳи ҷориро меёбад.
    /// `Ok(handle)`-ро бармегардонад, агар гиреҳи ҷорӣ воқеан волидайн дошта бошад, ки `handle` ба edge-и волидайн ишора мекунад, ки ба гиреҳи ҷорӣ ишора мекунад.
    ///
    /// `Err(self)`-ро бармегардонад, агар гиреҳи ҷорӣ волидайн надошта бошад ва `NodeRef` аслиро баргардонад.
    ///
    /// Номи усул фарз мекунад, ки шумо дарахтонро бо гиреҳи реша дар боло тасвир кунед.
    ///
    /// `edge.descend().ascend().unwrap()` ва `node.ascend().unwrap().descend()` набояд ҳарду бо муваффақият коре кунанд.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Мо бояд нишондиҳандаҳои хомро барои гиреҳҳо истифода барем, зеро, агар BorrowType marker::ValMut бошад, метавонад истинодҳои барҷастаи тағирёбанда ба арзишҳо вуҷуд дошта бошанд, ки мо онҳоро беэътибор накунем.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Дар хотир доред, ки `self` бояд холӣ бошад.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Дар хотир доред, ки `self` бояд холӣ бошад.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Қисми барги ҳама гуна барг ё гиреҳи дохилиро дарахти тағирнопазир нишон медиҳад.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // БЕХАТАР: : дар ин дарахт, ки ҳамчун `Immut` қарз гирифта шудааст, ягон ишораи тағирёбанда вуҷуд дошта наметавонад.
        unsafe { &*ptr }
    }

    /// Намуди калидҳои дар гиреҳ нигоҳдоштаро қарз медиҳад.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Монанди `ascend`, ба гиреҳи волидайни гиреҳ ишора мекунад, аммо гиреҳи кунуниро дар раванд ҷудо мекунад.
    /// Ин хатарнок аст, зеро гиреҳи ҷорӣ бо вуҷуди ҷудо шудан, ҳанӯз ҳам дастрас хоҳад буд.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Ба бехатарӣ ба тартибдиҳанда маълумоти статикӣ тасдиқ мекунад, ки ин гиреҳ `Leaf` аст.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Беэътиноёна ба таҳиягар маълумоти статистикиро тасдиқ мекунад, ки ин гиреҳ `Internal` аст.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Муваққатан истиноди дигари тағиршавандаро ба ҳамон гиреҳ мебарорад.Эҳтиёт шавед, зеро ин усул хеле хатарнок аст, дучандон, зеро он фавран хатарнок ба назар намерасад.
    ///
    /// Азбаски нишондиҳандаҳои тағирёбанда метавонанд дар ҳама ҷо дар атрофи дарахт сайругашт кунанд, нишоннамои баргаштаро ба осонӣ бо истифода аз нишондиҳандаи аслӣ овезон, берун аз ҳудуд ё мувофиқи қоидаҳои қарзии андохташуда беэътибор кардан мумкин аст.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) Ба `NodeRef` илова кардани як параметри дигареро, ки истифодаи усулҳои новбари дар нишондиҳандаҳои барқароршударо маҳдуд мекунад, баррасӣ кунед ва ин бехатариро пешгирӣ кунед.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Дастрасии махсусро ба қисми барги ҳама гуна барг ё гиреҳи дохилӣ қарз медиҳад.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // БЕХАТАР: : мо дастрасии истисноӣ ба тамоми гиреҳ дорем.
        unsafe { &mut *ptr }
    }

    /// Дастрасии истисноӣ ба қисми барги ҳама гуна барг ё гиреҳи дохилиро пешниҳод мекунад.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // БЕХАТАР: : мо дастрасии истисноӣ ба тамоми гиреҳ дорем.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Дастрасии махсусро ба унсури майдони нигоҳдории калид қарз медиҳад.
    ///
    /// # Safety
    /// `index` дар ҳудуди 0..ИМКОНИЯТ аст
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // БЕХАТАР: : даъваткунанда наметавонад усулҳои минбаъдаро ба худ даъват кунад
        // то даме ки истиноди буридаи калидӣ партофта нашавад, зеро мо дар тӯли қарз дастрасии беназир дорем.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Дастрасии махсусро ба унсур ё буридаи майдони нигоҳдории арзиши гиреҳ қарз медиҳад.
    ///
    /// # Safety
    /// `index` дар ҳудуди 0..ИМКОНИЯТ аст
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // БЕХАТАР: : даъваткунанда наметавонад усулҳои минбаъдаро ба худ даъват кунад
        // то он даме, ки истиноди буридаи арзиш паст карда шавад, зеро мо дар тӯли қарз дастрасии беназир дорем.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Барои мундариҷаи edge дастрасии истисноӣ ба унсур ё буридаи майдони нигоҳдории гиреҳ қарз мегирад.
    ///
    /// # Safety
    /// `index` дар ҳудуди 0..ИМКОНИЯТ + 1 аст
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // БЕХАТАР: : даъваткунанда наметавонад усулҳои минбаъдаро ба худ даъват кунад
        // то даме ки истиноди буридаи edge партофта нашавад, зеро мо дар тӯли қарз дастрасии беназир дорем.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Гиреҳ зиёда аз `idx` унсурҳои ибтидоӣ дорад.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Мо танҳо ба як унсури мавриди таваҷҷӯҳи худ истинод эҷод мекунем, то аз тахаллус бо истинодҳои барҷаста ба унсурҳои дигар, аз ҷумла, онҳое, ки дар такрори қаблӣ ба зангзада баргаштанд, ҷилавгирӣ кунем.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Мо бояд ба далелҳои Rust #74679 ба нишондиҳандаҳои ҷудошуда маҷбур кунем.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Дастрасии махсусро ба дарозии гиреҳ қарз медиҳад.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Истиноди гиреҳро ба волидайн edge таъин мекунад, бе истинод дигар ишораҳо ба гиреҳ.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Истиноди решаро ба волидайн edge тоза мекунад.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Ҷуфти арзиши калидиро ба охири гиреҳ илова мекунад.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Ҳар як ашёе, ки `range` бармегардонад, индекси дурусти edge барои гиреҳ аст.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Ҷуфти арзиши калидӣ ва edge илова мекунад, то ба тарафи рост, то охири гиреҳ равед.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Тафтиш мекунад, ки гиреҳ гиреҳи `Internal` ё гиреҳи `Leaf` аст.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Истинод ба ҷуфти махсуси арзиши калидӣ ё edge дар дохили гиреҳ.
/// Параметри `Node` бояд `NodeRef` бошад, дар ҳоле ки `Type` метавонад `KV` (ишораи дастаки ҷуфти калидӣ) ё `Edge` (ишораи дастаки edge) бошад.
///
/// Дар хотир доред, ки ҳатто гиреҳи `Leaf` метавонад дастаки `Edge` дошта бошад.
/// Ба ҷои он ки нишондиҳанда ба гиреҳи кӯдакро нишон диҳанд, онҳо ҷойҳоеро нишон медиҳанд, ки нишондиҳандаҳои кӯдакон байни ҷуфтҳои калидӣ мегузаранд.
/// Масалан, дар гиреҳ бо дарозии 2, 3 макони имконпазири edge мавҷуд хоҳад буд, ки яке дар тарафи чапи гиреҳ, дигаре дар байни ду ҷуфт ва дигаре дар тарафи рости гиреҳ.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ба мо умумияти пурраи `#[derive(Clone)]` лозим нест, зеро ягона вақт `Node` "Clone" мешавад, вақте ки он истиноди тағирнопазир аст ва аз ин рӯ `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Гиреҳеро, ки дорои edge ё ҷуфти калидии калидро дар бар мегирад, меорад.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Мавқеи ин дастакро дар гиреҳ бармегардонад.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Дастаки навро ба ҷуфти калидӣ дар `node` месозад.
    /// Хатарнок аст, зеро даъваткунанда бояд `idx < node.len()`-ро таъмин кунад.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Метавонист татбиқи оммавии PartialEq бошад, аммо танҳо дар ин модул истифода мешавад.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Муваққатан як дастаки тағирнопазирро дар ҳамон маҳал мебарорад.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Мо наметавонем Handle::new_kv ё Handle::new_edge-ро истифода барем, зеро мо навъи худро намедонем
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Беэътимодона ба таҳиягар маълумоти статистикиро тасдиқ мекунад, ки гиреҳи дастак `Leaf` аст.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Муваққатан як дастаки дигаргуншавандаро дар ҳамон ҷой мебарорад.
    /// Эҳтиёт шавед, зеро ин усул хеле хатарнок аст, дучандон, зеро он фавран хатарнок ба назар намерасад.
    ///
    ///
    /// Барои тафсилот, ба `NodeRef::reborrow_mut` нигаред.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Мо наметавонем Handle::new_kv ё Handle::new_edge-ро истифода барем, зеро мо навъи худро намедонем
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Дастаки навро ба edge дар `node` эҷод мекунад.
    /// Хатарнок аст, зеро даъваткунанда бояд `idx <= node.len()`-ро таъмин кунад.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Бо назардошти индекси edge, ки мо мехоҳем ба гиреҳи пурқудрат ворид кунем, индекси оқилонаи KV нуқтаи тақсимшударо ҳисоб мекунад ва ҷойгиркуниро дар куҷо иҷро мекунад.
///
/// Ҳадафи нуқтаи тақсимшавӣ аз он иборат аст, ки калид ва арзиши он ба гиреҳи волидайн хотима ёбад;
/// тугмаҳо, арзишҳо ва кунҷҳои чапи нуқтаи тақсимшавӣ кӯдаки чап мешаванд;
/// тугмаҳо, арзишҳо ва кунҷҳои рости нуқтаи тақсимшавӣ фарзанди дуруст мешаванд.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Масъалаи Rust #74834 кӯшиш мекунад, ки ин қоидаҳои симметриро шарҳ диҳад.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ҷуфти нави арзиши калидро ба ҷуфтҳои арзиши калид ба тарафи рост ва чапи ин edge дохил мекунад.
    /// Ин усул тахмин мезанад, ки дар гиреҳ ҷой барои ҷойгоҳи ҷуфти нав кофӣ аст.
    ///
    /// Нишондиҳандаи баргашта ба арзиши дохилшуда ишора мекунад.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ҷуфти нави арзиши калидро ба ҷуфтҳои арзиши калид ба тарафи рост ва чапи ин edge дохил мекунад.
    /// Ин усул гиреҳро тақсим мекунад, агар ҷой кофӣ набошад.
    ///
    /// Нишондиҳандаи баргашта ба арзиши дохилшуда ишора мекунад.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Нишондиҳанда ва индекси волидайнро дар гиреҳи кӯдак, ки ин edge ба он пайванд медиҳад, ислоҳ мекунад.
    /// Ин вақте муфид аст, ки тартиби кунҷҳо тағир дода шудааст,
    fn correct_parent_link(self) {
        // Беэътибор кардани истинодҳои дигар ба гиреҳ, backpointer созед.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Ҷуфти нави арзиши калидӣ ва edge-ро дохил мекунад, ки он ба ҷуфти нав дар байни ин edge ва ҷуфти калидӣ дар тарафи рости ин edge хоҳад рафт.
    /// Ин усул тахмин мезанад, ки дар гиреҳ ҷой барои ҷойгоҳи ҷуфти нав кофӣ аст.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Ҷуфти нави арзиши калидӣ ва edge-ро дохил мекунад, ки он ба ҷуфти нав дар байни ин edge ва ҷуфти калидӣ дар тарафи рости ин edge хоҳад рафт.
    /// Ин усул гиреҳро тақсим мекунад, агар ҷой кофӣ набошад.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Ҷуфти нави арзиши калидро ба ҷуфтҳои арзиши калид ба тарафи рост ва чапи ин edge дохил мекунад.
    /// Ин усул гиреҳро тақсим мекунад, агар ҷой кофӣ набошад ва кӯшиш мекунад, ки қисмати тақсимшударо ба гиреҳи волидайн рекурсивӣ то расидани реша ворид кунад.
    ///
    ///
    /// Агар натиҷаи баргашта `Fit` бошад, гиреҳи дастаки он метавонад гиреҳи ин edge ё аҷдод бошад.
    /// Агар натиҷаи баргашта `Split` бошад, майдони `left` гиреҳи реша хоҳад буд.
    /// Нишондиҳандаи баргашта ба арзиши дохилшуда ишора мекунад.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Гиреҳеро, ки ба ин edge ишора шудааст, меёбад.
    ///
    /// Номи усул фарз мекунад, ки шумо дарахтонро бо гиреҳи реша дар боло тасвир кунед.
    ///
    /// `edge.descend().ascend().unwrap()` ва `node.ascend().unwrap().descend()` набояд ҳарду бо муваффақият коре кунанд.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Мо бояд нишондиҳандаҳои хомро барои гиреҳҳо истифода барем, зеро, агар BorrowType marker::ValMut бошад, метавонад истинодҳои барҷастаи тағирёбанда ба арзишҳо вуҷуд дошта бошанд, ки мо онҳоро беэътибор накунем.
        // Дастрасӣ ба майдони баландӣ хавотир нест, зеро ин қимат нусхабардорӣ карда мешавад.
        // Эҳтиёт шавед, ки пас аз истиноди ишоракунандаи гиреҳ, мо ба массиви кунҷҳо бо истинод дастрасӣ пайдо мекунем (Rust барориши #73987) ва истинодҳои дигарро ба массив ва ё дар дохили массив беэътибор мекунад, агар онҳо дар атрофи он бошанд.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Мо усулҳои калидӣ ва қимати алоҳида занг зада наметавонем, зеро даъвати дуввум истиноди баргаштаи якумро беэътибор мекунад.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Калид ва қиматеро, ки дастаки KV ба он ишора мекунад, иваз кунед.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Кӯмак ба татбиқи `split` барои `NodeType` мушаххас, бо нигоҳубини маълумоти баргҳо.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Гиреҳи аслиро ба се қисм тақсим мекунад:
    ///
    /// - Гиреҳ бурида шудааст, ки танҳо дорои ҷуфтҳои калидӣ дар тарафи чапи ин дастак бошад.
    /// - Калид ва арзиши ишорашудаи ин дастак бароварда мешавад.
    /// - Ҳама ҷуфтҳои калидӣ дар тарафи рости ин дастак ба гиреҳи нав ҷудошуда гузошта мешаванд.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Ҷуфти арзиши калидро, ки бо ин дастак нишон дода шудааст, хориҷ мекунад ва онро дар якҷоягӣ бо edge, ки ҷуфти арзиши калид ба он афтодааст, бармегардонад.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Гиреҳи аслиро ба се қисм тақсим мекунад:
    ///
    /// - Гиреҳ бурида шудааст, ки танҳо канорҳо ва ҷуфтҳои арзиши калидро дар тарафи чапи ин дастак дошта бошад.
    /// - Калид ва арзиши ишорашудаи ин дастак бароварда мешавад.
    /// - Ҳама кунҷҳо ва ҷуфтҳои калидӣ дар тарафи рости ин дастак ба гиреҳи нав ҷудошуда гузошта мешаванд.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Сессияро барои баҳогузорӣ ва иҷрои амалиёти мувозинат дар атрофи ҷуфти арзишҳои дохилӣ намояндагӣ мекунад.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Контекси мувозинатиро, ки гиреҳро дар кӯдакӣ дар бар мегирад, интихоб мекунад, аз ин рӯ байни KV фавран ба чап ё рост дар гиреҳи волидайн.
    /// Агар падару модар набошад, `Err` бармегардонад.
    /// Panics агар волидайн холӣ бошад.
    ///
    /// Дар ҳолате, ки гиреҳи додашуда ба андозае нопурра бошад, тарафи чапро афзалтар мешуморад, зеро ин маънои онро дорад, ки он нисбат ба бародари чап ва аз хоҳари рости худ камтар унсурҳо дорад, агар онҳо мавҷуд бошанд.
    /// Дар ин ҳолат, ҳамроҳшавӣ бо бародари чап тезтар мешавад, зеро ба мо танҳо ба ҷои рост ҳаракат кардан ва аз N унсури пеш ҳаракат кардан лозим аст, танҳо N элементро гиред.
    /// Дуздӣ аз бародари чап низ одатан тезтар аст, зеро ба мо танҳо лозим аст, ки N унсури гиреҳро ба рост иваз кунем, ба ҷои иваз кардани ақаллан N унсури хоҳарро ба чап.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Бозмегардонад, ки оё муттаҳидшавӣ имконпазир аст, яъне оё дар як гиреҳ ҷой кофӣ аст, то KV марказиро бо ҳарду гиреҳи кӯдаки ҳамҷоя якҷоя кунед.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Якҷоякуниро иҷро мекунад ва имкон медиҳад, ки бастани он чӣ баргардад.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // БЕХАТАР: : баландии гиреҳҳои якҷояшаванда яке аз поёнии баландӣ аст
                // аз гиреҳи ин edge, бинобар ин аз сифр болотар аст, бинобар ин онҳо дохилӣ мебошанд.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Ҷуфти калидии волидайн ва ҳарду гиреҳи фарзанди ҳамшафатро ба гиреҳи кӯдаки чап муттаҳид мекунад ва гиреҳи кӯтоҳшудаи волидайнро бар мегардонад.
    ///
    ///
    /// Panics, агар мо `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Ҷуфти калидии волидайн ва ҳарду гиреҳи кӯдаки ҳамсояро ба гиреҳи кӯдаки чап муттаҳид мекунад ва он гиреҳи фарзандро бармегардонад.
    ///
    ///
    /// Panics, агар мо `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Ҷуфти калидии волидайн ва ҳарду гиреҳи кӯдаки ҳамсояро ба гиреҳи кӯдаки чап муттаҳид мекунад ва дастаки edge-ро дар он гиреҳи кӯдаконе, ки фарзанди мушоҳидашуда edge тамом шудааст, бар мегардонад,
    ///
    ///
    /// Panics, агар мо `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Ҷуфти калидии калидро аз кӯдаки чап хориҷ мекунад ва дар анбори арзиши калидии волидайн ҷойгир мекунад, дар ҳоле ки ҷуфти калидии волидайнро ба фарзанди рост тела медиҳад.
    ///
    /// Дастакро ба edge дар кӯдаки рост бармегардонад, ки ба edge аслии муайянкардаи `track_right_edge_idx` мувофиқат мекунад.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Ҷуфти арзиши калидиро аз кӯдаки рост дур мекунад ва онро дар анбори арзиши калидии волидайн ҷойгир мекунад, дар ҳоле ки ҷуфти қадимии калидии волидайнро ба кӯдаки чап тела медиҳад.
    ///
    /// Дастакро ба edge дар кӯдаки чапи аз ҷониби `track_left_edge_idx` муайяншуда бармегардонад, ки ҳаракат намекунад.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Ин ба монанди `steal_left` дуздӣ мекунад, аммо якбора якчанд унсурро медуздад.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Боварӣ ҳосил намоед, ки мо бехатар дуздида метавонем.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Ҷойивазкунии маълумотҳои барг.
            {
                // Барои унсурҳои дуздидашуда дар кӯдаки мувофиқ ҷой ҷудо кунед.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Элементҳоро аз кӯдаки чап ба рост ҳаракат кунед.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Ҷуфти аз ҳама чап дуздидашударо ба волидайн интиқол диҳед.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ҷуфти калидии волидонро ба фарзанди рост интиқол диҳед.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Барои канораҳои дуздидашуда ҷой ҷудо кунед.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Дуздӣ кунҷҳо.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Клони симметрии `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Боварӣ ҳосил намоед, ки мо бехатар дуздида метавонем.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Ҷойивазкунии маълумотҳои барг.
            {
                // Ҷуфти аз ҳама рост дуздидашударо ба волидайн интиқол диҳед.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Ҷуфти калидии волидонро ба кӯдаки чап интиқол диҳед.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Элементҳоро аз кӯдаки рост ба чап интиқол диҳед.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Холигиро дар он ҷое, ки элементҳои дуздида буданд, пур кунед.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Дуздӣ кунҷҳо.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Холигиро дар он ҷойҳое, ки пештар дуздидашуда буданд, пур кунед.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Ҳама гуна иттилооти статикиро нест мекунад, ки ин гиреҳ як гиреҳи `Leaf` аст.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ҳама гуна иттилооти статикиро нест мекунад, ки ин гиреҳ гиреҳи `Internal` мебошад.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Гиреҳи `Internal` ё гиреҳи `Leaf` будани гиреҳи аслиро месанҷад.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Пасвандро пас аз `self` аз як гиреҳ ба гиреҳи дигар интиқол диҳед.`right` бояд холӣ бошад.
    /// Аввалин edge аз `right` бетағйир боқӣ мемонад.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Натиҷаи дохилкунӣ, вақте ки гиреҳ бояд аз ҳадди имкон васеъ шавад.
pub struct SplitResult<'a, K, V, NodeType> {
    // Гиреҳи тағирёфта дар дарахти мавҷуда бо унсурҳо ва кунҷҳо, ки ба чапи `kv` тааллуқ доранд.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Баъзе калид ва қимат тақсим карда мешаванд, то дар ҷои дигаре ҷойгир карда шаванд.
    pub kv: (K, V),
    // Гиреҳи нав, алоқаманднашуда, дорои унсурҳо ва кунҷҳо, ки ба тарафи `kv` рост тааллуқ доранд.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Оё муроҷиатҳои гиреҳии ин намуди қарз имкон медиҳанд, ки гузариш ба гиреҳҳои дигари дарахт гузарад.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal лозим нест, он бо истифодаи натиҷаи `borrow_mut` рӯй медиҳад.
        // Бо қатъ кардани гузариш ва танҳо эҷоди истинодҳои нав ба решаҳо, мо медонем, ки ҳар як истиноди навъи `Owned` ба гиреҳи реша аст.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Арзишро ба буридаи унсурҳои ибтидоӣ ва пас аз як унсури номаълум дохил мекунад.
///
/// # Safety
/// Бурида зиёда аз `idx` унсур дорад.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Арзишро аз буридаи ҳамаи унсурҳои ибтидоӣ хориҷ мекунад ва бармегардонад, ва дар паси худ як унсури паси номаълумро мегузорад.
///
///
/// # Safety
/// Бурида зиёда аз `idx` унсур дорад.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Элементҳоро дар як буридаи `distance` ба тарафи чап иваз мекунад.
///
/// # Safety
/// Бурида ҳадди аққал элементҳои `distance` дорад.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Элементҳоро дар як буридаи `distance` ба тарафи рост иваз мекунад.
///
/// # Safety
/// Бурида ҳадди аққал элементҳои `distance` дорад.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Ҳама арзишҳоро аз буридаи унсурҳои ибтидоӣ ба буридаи унсурҳои номаълум интиқол медиҳад ва `src`-ро ҳамчун ҳама нофармонда мегузорад.
///
/// Ба монанди `dst.copy_from_slice(src)` кор мекунад, аммо `T`-ро `Copy` талаб намекунад.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;