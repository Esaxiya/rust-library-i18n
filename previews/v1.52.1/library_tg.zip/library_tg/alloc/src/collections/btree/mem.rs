use core::intrinsics;
use core::mem;
use core::ptr;

/// Ин иваз кардани арзиши паси истиноди беназири `v` бо занг задан ба функсияи дахлдор.
///
///
/// Агар panic дар бастани `change` ба амал ояд, тамоми раванд бекор карда мешавад.
#[allow(dead_code)] // ҳамчун мисол нигоҳ доред ва барои истифодаи future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Ин арзиши паси истиноди беназири `v`-ро бо занг задан ба функсияи дахлдор иваз мекунад ва натиҷаи ба даст овардашударо дар роҳ бар мегардонад.
///
///
/// Агар panic дар бастани `change` ба амал ояд, тамоми раванд бекор карда мешавад.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}