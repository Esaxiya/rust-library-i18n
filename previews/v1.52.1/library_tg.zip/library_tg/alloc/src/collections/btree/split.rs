use super::node::{ForceResult::*, Root};
use super::search::SearchResult::*;
use core::borrow::Borrow;

impl<K, V> Root<K, V> {
    /// Дарозии ҳарду дарахтро, ки дар натиҷаи тақсим кардани шумораи муайяни ҷуфтҳои калидии арзиши калидӣ ҳисоб карда мешавад.
    ///
    pub fn calc_split_length(
        total_num: usize,
        root_a: &Root<K, V>,
        root_b: &Root<K, V>,
    ) -> (usize, usize) {
        let (length_a, length_b);
        if root_a.height() < root_b.height() {
            length_a = root_a.reborrow().calc_length();
            length_b = total_num - length_a;
            debug_assert_eq!(length_b, root_b.reborrow().calc_length());
        } else {
            length_b = root_b.reborrow().calc_length();
            length_a = total_num - length_b;
            debug_assert_eq!(length_a, root_a.reborrow().calc_length());
        }
        (length_a, length_b)
    }

    /// Дарахтро бо ҷуфтҳои калидӣ дар калиди додашуда ва пас аз он ҷудо кунед.
    /// Натиҷа он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад ва агар тартиби `Q` ба `K` мувофиқат кунад.
    /// Агар `self` ба ҳама инвариантҳои дарахти `BTreeMap` эҳтиром гузорад, пас ҳам `self` ва дарахти баргашта он инвариантҳоро эҳтиром мекунанд.
    ///
    ///
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q>,
    {
        let left_root = self;
        let mut right_root = Root::new_pillar(left_root.height());
        let mut left_node = left_root.borrow_mut();
        let mut right_node = right_root.borrow_mut();

        loop {
            let mut split_edge = match left_node.search_node(key) {
                // калид ба сӯи дарахти рост меравад
                Found(kv) => kv.left_edge(),
                GoDown(edge) => edge,
            };

            split_edge.move_suffix(&mut right_node);

            match (split_edge.force(), right_node.force()) {
                (Internal(edge), Internal(node)) => {
                    left_node = edge.descend();
                    right_node = node.first_edge().descend();
                }
                (Leaf(_), Leaf(_)) => break,
                _ => unreachable!(),
            }
        }

        left_root.fix_right_border();
        right_root.fix_left_border();
        right_root
    }

    /// Дарахтро иборат аст аз гиреҳҳои холӣ.
    fn new_pillar(height: usize) -> Self {
        let mut root = Root::new();
        for _ in 0..height {
            root.push_internal_level();
        }
        root
    }
}