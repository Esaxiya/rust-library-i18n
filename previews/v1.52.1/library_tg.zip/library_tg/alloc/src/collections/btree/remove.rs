use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Ҷуфти арзиши калидиро аз дарахт хориҷ мекунад ва ин ҷуфтро бармегардонад, инчунин барге edge, ки ба он ҷуфти қаблӣ мувофиқ аст.
    /// Ин имконпазир аст, ки ин гиреҳи решаро холӣ кунад, ки дохили он бошад, ва даъваткунанда бояд аз харитаи дарахтбуда берун ояд.
    /// Зангзан бояд инчунин дарозии харитаро коҳиш диҳад.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Мо бояд навъи кӯдаконро муваққатан фаромӯш кунем, зеро барои волидони бевоситаи барг навъи гиреҳи алоҳида вуҷуд надорад.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // БЕХАТАР: : `new_pos` барге, ки мо аз он оғоз кардем ё хоҳару бародар.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Танҳо дар сурати муттаҳид шудан, волидайн (агар бошад) коҳиш ёфтааст, аммо қадами зеринро гузаред, дар акси ҳол, дар меъёрҳо натиҷа намедиҳад.
            //
            // БЕХАТАР: : Мо баргро, ки `pos` дар он аст, нобуд ё аз нав танзим намекунем
            // бо истифодаи падару модари худ рекурсивӣ;дар бадтарин ҳолат мо волидайнро ба воситаи бобову модарбузург нобуд хоҳем кард ё тағир медиҳем, бинобар ин пайвандро бо волидайн дар дохили барг иваз мекунем.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // КВ-и ҳамшафатро аз барги он хориҷ кунед ва пас онро ба ҷои унсуре гузоред, ки аз мо талаб карданд.
        //
        // Бо сабабҳои дар `choose_parent_kv` номбаршуда KV чапи чапро афзалтар донед.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Гиреҳи дохилиро шояд дуздида ё якҷоя карда бошанд.
        // Ба рост баргардед, то дар куҷо KV-и аслӣ ба поён расидааст.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}