use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Муваққатан эквиваленти тағирнашавандаи ҳамон диапазонро мебарорад.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Канорҳои гуногуни баргро муайян мекунад, ки доираи муайянро дар дарахт маҳдуд мекунад.
    /// Ё як ҷуфт дастаки гуногунро ба як дарахт бармегардонад ё як ҷуфт имконоти холиро.
    ///
    /// # Safety
    ///
    /// Агар `BorrowType` `Immut` набошад, дастакҳои такрориро барои боздид аз як КВ ду маротиба истифода набаред.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ба `(root1.first_leaf_edge(), root2.last_leaf_edge())` баробар аст, аммо самараноктар.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ҷуфтҳои канори баргро муайян мекунад, ки доираи муайяни дарахтро маҳдуд мекунанд.
    ///
    /// Натиҷа танҳо он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад, ба монанди дарахт дар `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // БЕХАТАР: : намуди қарзи мо бетағйир аст.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Ҷуфтҳои канори баргро, ки тамоми дарахтро ҷудо мекунад, пайдо мекунад.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Истиноди беназирро ба як ҷуфт канори барг тақсим мекунад, ки доираи муайянро фароҳам меорад.
    /// Дар натиҷа истинодҳои ғайримуқаррарӣ ба mutation (some) имкон медиҳанд, ки бояд бодиққат истифода шаванд.
    ///
    /// Натиҷа танҳо он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад, ба монанди дарахт дар `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Барои дидани як КВ ду маротиба аз дастакҳои такрорӣ истифода набаред.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Истиноди беназирро ба як ҷуфт канори барг тақсим мекунад, ки доираи тамоми дарахтро тақсим мекунад.
    /// Натиҷаҳо истинодҳои ғайримуқаррарӣ мебошанд, ки ба мутатсия иҷозат медиҳанд (танҳо аз рӯи арзишҳо), бинобар ин бояд эҳтиёткорона истифода бурда шавад.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Мо решаи NodeRef-ро дар инҷо такрори мекунем-мо ҳеҷ гоҳ ба як KV ду маротиба ташриф нахоҳем овард ва ҳеҷ гоҳ бо истинодҳои арзиши такрори ба охир нарасем.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Истиноди беназирро ба як ҷуфт канори барг тақсим мекунад, ки доираи тамоми дарахтро тақсим мекунад.
    /// Натиҷаҳо истинодҳои ғайримуқаррарӣ мебошанд, ки ба мутатсияи азим харобиовар имкон медиҳанд, бинобар ин бояд бодиққат истифода бурда шавад.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Мо решаи NodeRef-ро дар инҷо такрор мекунем-мо ҳеҷ гоҳ ба он дастрасӣ нахоҳем ёфт, ки муроҷиатҳое, ки аз реша ба даст омадаанд, такрор шаванд.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Бо назардошти дастаки барги edge, [`Result::Ok`]-ро бо дастак ба КВ-и ҳамсоя дар тарафи рост, ки ё дар як гиреҳи барге ё дар гиреҳи аҷдодон аст, бармегардонад.
    ///
    /// Агар барги edge охирин дарахт бошад, [`Result::Err`]-ро бо гиреҳи реша бармегардонад.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Бо дарназардошти дастаки барги edge, [`Result::Ok`]-ро бо дастак ба КВ-и ҳамсоя дар тарафи чап, ки ё дар як гиреҳи барге ё дар гиреҳи аҷдодон аст, бармегардонад.
    ///
    /// Агар барги edge аввалин дарахт бошад, [`Result::Err`]-ро бо гиреҳи реша бармегардонад.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Бо дарназардошти дастаки дохилии edge, [`Result::Ok`]-ро бо дастак ба КВ-и ҳамсоя дар тарафи рост, ки ё дар ҳамон гиреҳи дохилӣ ё дар гиреҳи ниёгон ҷойгир аст, бармегардонад.
    ///
    /// Агар edge дохилӣ охирин дарахт бошад, [`Result::Err`]-ро бо гиреҳи реша бармегардонад.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Бо дарназардошти дастаки барги edge ба дарахти миранда, барги навбатии edge-ро дар тарафи рост ва ҷуфти арзиши калидро дар байни он, ки ё дар ҳамон гиреҳи барге, дар гиреҳи аҷдодон аст ё вуҷуд надорад, бармегардонад.
    ///
    ///
    /// Ин усул инчунин ҳар node(s)-ро, ки ба охири он мерасад, ҷудо мекунад.
    /// Ин маънои онро дорад, ки агар дигар ҷуфти арзиши калидӣ вуҷуд надошта бошад, тамоми боқимондаи дарахт тақсим карда мешавад ва барои бозгашт чизе боқӣ намемонад.
    ///
    /// # Safety
    /// edge-и додашуда набояд қаблан аз ҷониби ҳамтои `deallocating_next_back` баргардонида шуда бошад.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Бо дарназардошти дастаки барги edge ба дарахти миранда, барги навбатии edge-ро дар тарафи чап ва ҷуфти арзиши калидро дар байни он, ки ё дар як гиреҳи барге, дар гиреҳи аҷдодон ё номавҷуд аст, бармегардонад.
    ///
    ///
    /// Ин усул инчунин ҳар node(s)-ро, ки ба охири он мерасад, ҷудо мекунад.
    /// Ин маънои онро дорад, ки агар дигар ҷуфти арзиши калидӣ вуҷуд надошта бошад, тамоми боқимондаи дарахт тақсим карда мешавад ва барои бозгашт чизе боқӣ намемонад.
    ///
    /// # Safety
    /// edge-и додашуда набояд қаблан аз ҷониби ҳамтои `deallocating_next` баргардонида шуда бошад.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Тӯдаи гиреҳҳоро аз барг то реша тақсим мекунад.
    /// Ин ягона роҳи ҷудо кардани боқимондаи дарахт пас аз `deallocating_next` ва `deallocating_next_back` дар ду тарафи дарахт неш зада, ҳамон edge-ро задааст.
    /// Азбаски он танҳо даъват карда мешавад, вақте ки ҳамаи тугмаҳо ва арзишҳо баргардонида мешаванд, тоза кардани ягон калид ё арзиш анҷом дода намешавад.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Дастаки барги edge-ро ба барги навбатии edge интиқол медиҳад ва истинодҳоро ба калид ва арзиши байни онҳо бармегардонад.
    ///
    ///
    /// # Safety
    /// Дар самти сайркардашуда бояд боз як KV бошад.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Дастаки барги edge-ро ба барги қаблии edge интиқол медиҳад ва истинодҳоро ба калид ва арзиши байни онҳо бармегардонад.
    ///
    ///
    /// # Safety
    /// Дар самти сайркардашуда бояд боз як KV бошад.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Дастаки барги edge-ро ба барги навбатии edge интиқол медиҳад ва истинодҳоро ба калид ва арзиши байни онҳо бармегардонад.
    ///
    ///
    /// # Safety
    /// Дар самти сайркардашуда бояд боз як KV бошад.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Мувофиқи меъёрҳо, ин корро охирин кардан зудтар аст.
        kv.into_kv_valmut()
    }

    /// Дастаки барги edge-ро ба варақи қаблӣ интиқол медиҳад ва истинодҳоро ба калид ва арзиши байни онҳо бармегардонад.
    ///
    ///
    /// # Safety
    /// Дар самти сайркардашуда бояд боз як KV бошад.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Мувофиқи меъёрҳо, ин корро охирин кардан зудтар аст.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Дастаки edge баргро ба барги навбатии edge интиқол медиҳад ва калид ва қиматро дар байни он бармегардонад, ҳар як гиреҳро, ки ҳангоми гузоштан edge-и мувофиқро дар овезони волидайни худ ҷойгир мекунад, ҷудо мекунад.
    ///
    /// # Safety
    /// - Дар самти сайркардашуда бояд боз як KV бошад.
    /// - Ки KV қаблан аз ҷониби ҳамтои `next_back_unchecked` ба ягон нусхаи дастакҳое, ки барои гашти дарахт истифода мешуданд, баргардонида нашуд.
    ///
    /// Ягона роҳи бехатар барои идомаи дастаки навсозишуда муқоиса кардани он, партофтан, бо усули бехатарии он дубора занг задан ё ба ҳамтои `next_back_unchecked` бо назардошти шароити бехатарии он мебошад.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Дастаки барги edge-ро ба барги қаблии edge интиқол медиҳад ва калид ва қиматро дар байни он бармегардонад, ҳар як гиреҳи дар ақибмондаро ҳангоми ҷудо кардани edge-и мувофиқро дар гиреҳи овезони худ ҷудо мекунад.
    ///
    /// # Safety
    /// - Дар самти сайркардашуда бояд боз як KV бошад.
    /// - Он барги edge қаблан аз ҷониби ҳамтои `next_unchecked` дар ягон нусхаи дастакҳое, ки барои гашти дарахт истифода мешуданд, баргардонида нашудааст.
    ///
    /// Ягона роҳи бехатар барои идомаи дастаки навсозишуда муқоиса кардани он, афтондан, бо усули бехатарии он дубора занг задан ё ба ҳамтои `next_unchecked` бо назардошти шароити бехатарии он мебошад.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Баргҳои чаптарини edge-ро дар дохили гиреҳ ё дар зери он бармегардонад, ба ибораи дигар, edge, ки ба шумо аввал ҳангоми ҳаракат ба пеш лозим аст (ё ҳангоми ҳаракат ба қафо охирин).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Баргҳои рости edge-ро дар дохили гиреҳ ё зери он бармегардонад, ба ибораи дигар, edge, ки ҳангоми ҳаракат ба пеш (ё аввал ҳангоми ҳаракат ба қафо) лозим аст.
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Ба гиреҳҳои барг ва КВ-ҳои дохилӣ бо тартиби калидҳои баландшаванда ташриф меорад ва инчунин гиреҳҳои дохилиро дар маҷмӯъ бо тартиби аввал амиқ меҳисобад, яъне гиреҳҳои дохилӣ қабл аз КВ-ҳои инфиродии худ ва гиреҳи кӯдакони онҳо.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Шумораи элементҳоро дар дарахти (зер) ҳисоб мекунад.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Барги edge-ро, ки ба KV наздиктар аст, барои ҳаракат ба пеш бармегардонад.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Барги edge-ро, ки ба KV наздик аст, барои новбари қафо бармегардонад.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}