use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Фарогирии фарогир барои ҷустуҷӯ, ба монанди `Bound::Included(T)`.
    Included(T),
    /// Як истисноии ҳатмӣ барои ҷустуҷӯ, ба монанди `Bound::Excluded(T)`.
    Excluded(T),
    /// Бастаи фарогирии бечунучаро, ба монанди `Bound::Unbounded`.
    AllIncluded,
    /// Ҳудуди истисноии бечунучаро.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Калиди додашударо дар дарахти (зер) сарвари гиреҳ рекурсивӣ ҷустуҷӯ мекунад.
    /// `Found`-ро бо дастаки KV-и мувофиқ бармегардонад, агар бошад.
    /// Дар акси ҳол, `GoDown`-ро бо дастаки барге edge бармегардонад, ки калид дар он тааллуқ дорад.
    ///
    /// Натиҷа танҳо он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад, ба монанди дарахт дар `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Ба гиреҳи наздиктарин мефурояд, ки edge, ки ба ҳудуди поёнии диапазон мувофиқат мекунад, аз edge, ки ба ҳудуди боло мувофиқат мекунад, фарқ мекунад, яъне гиреҳи наздиктарин, ки ҳадди ақалл як калидро дар диапазон дорад.
    ///
    ///
    /// Агар ёфт шавад, `Ok`-ро бо он гиреҳ бармегардонад, ҷуфти индекси edge дар он диапазонро маҳдуд мекунад ва ҷуфти дахлдори ҳудуд барои идомаи ҷустуҷӯ дар гиреҳҳои кӯдак, дар сурате, ки гиреҳ дохилӣ бошад.
    ///
    /// Агар ёфт нашуд, `Err`-ро бо баргҳои edge бо тамоми диапазон мувофиқат мекунад.
    ///
    /// Натиҷа танҳо дар сурате пурмазмун мешавад, ки агар дарахт бо калид фармоиш дода шавад.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Даровардани ин тағирёбандаҳо бояд пешгирӣ карда шавад.
        // Мо чунин мешуморем, ки ҳудуди гузоришкардаи `range` бетағйир боқӣ мемонад, аммо татбиқи рақобат метавонад байни зангҳои (#81138) тағир ёбад.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Дар гиреҳе, ки ҳудуди поёнии диапазонро маҳдуд мекунад, edge-ро меёбад.
    /// Ҳамчунин ҳудуди поёниро барои барқарор кардани ҷустуҷӯ дар гиреҳи кӯдаки мувофиқ истифода мебарад, агар `self` гиреҳи дохилӣ бошад.
    ///
    ///
    /// Натиҷа танҳо дар сурате пурмазмун мешавад, ки агар дарахт бо калид фармоиш дода шавад.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Клони `find_lower_bound_edge` барои ҳудуди боло.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Тугмаи додашударо бидуни рекурсия ҷустуҷӯ мекунад.
    /// `Found`-ро бо дастаки KV-и мувофиқ бармегардонад, агар бошад.
    /// Дар акси ҳол, `GoDown`-ро бо дастаки edge бармегардонад, ки дар он калид пайдо мешавад (агар гиреҳ дохилӣ бошад) ё дар он ҷо калид ворид карда мешавад.
    ///
    ///
    /// Натиҷа танҳо он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад, ба монанди дарахт дар `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Ё индекси KV-ро дар гиреҳе, ки калид (ё муодили он) мавҷуд аст, ё индекси edge, ки калид дар он тааллуқ дорад, бармегардонад.
    ///
    ///
    /// Натиҷа танҳо он вақт пурмазмун хоҳад буд, ки агар дарахт бо калид фармоиш дода шавад, ба монанди дарахт дар `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Дар гиреҳ индекси edge-ро, ки ҳудуди поёнии диапазонро маҳдуд мекунад, меёбад.
    /// Ҳамчунин ҳудуди поёниро барои барқарор кардани ҷустуҷӯ дар гиреҳи кӯдаки мувофиқ истифода мебарад, агар `self` гиреҳи дохилӣ бошад.
    ///
    ///
    /// Натиҷа танҳо дар сурате пурмазмун мешавад, ки агар дарахт бо калид фармоиш дода шавад.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Клони `find_lower_bound_index` барои ҳудуди боло.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}