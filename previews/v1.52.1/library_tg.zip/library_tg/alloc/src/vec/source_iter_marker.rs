use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Нишондиҳандаи тахассусӣ барои ҷамъоварии лӯлаи iterator ба Vec ҳангоми истифодаи дубораи тақсимоти манбаъ, яъне
/// лӯлаи газро дар ҷои худ иҷро мекунад.
///
/// Волидони SourceIter trait барои функсияи тахассусӣ барои дастрасӣ ба ҷудокунӣ, ки бояд дубора истифода шавад, зарур аст.
/// Аммо барои эътибор доштани ихтисос кофӣ нест.
/// Ҳудуди иловагиро оид ба имл бинед.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-дохилии SourceIter/InPlaceIterable traits танҳо аз ҷониби занҷирҳои адаптер амалӣ карда мешавад <Adapter<Adapter<IntoIter>>> (ҳамааш ба core/std тааллуқ дорад).
// Ҳудуди иловагӣ оид ба татбиқи адаптер (берун аз `impl<I: Trait> Trait for Adapter<I>`) танҳо аз дигар traits, ки аллакай ҳамчун тахассуси traits ишора шудааст (Copy, TrustedRandomAccess, FusedIterator) вобаста аст.
//
// I.e. нишондиҳанда аз мӯҳлати истифодаи намудҳои аз ҷониби корбар таъминшуда вобастагӣ надорад.Модули нусхаи нусхабардорӣ, ки чанд ихтисоси дигар аллакай ба он вобаста аст.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Талаботи иловагӣ, ки тавассути trait bounds ифода карда намешаванд.Мо ба ҷои const eval такя мекунем:
        // а) ягон ZST нест, зеро барои истифодаи такрорӣ ва арифметикаи нишоннамо тақсимоте вуҷуд нахоҳад дошт panic б) андозаи мувофиқи шартномаи Alloc мувофиқат кунад в) мувофиқатҳо мувофиқи шартномаи Alloc мувофиқат мекунанд
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // бозгашт ба татбиқи умумӣ
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // аз он дам истифода баред
        // - он барои баъзе созгорҳои итератор беҳтар аст
        // - баръакси аксари усулҳои такрории дохилӣ, он танҳо як &mut-ро мегирад
        // - он ба мо имкон медиҳад, ки нишоннамои навиштаро ба дохили худ гузарем ва онро дар ниҳоят баргардонем
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // такрор муваффақ шуд, сар наафтонед
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // санҷед, ки оё шартномаи SourceIter ҳушдор дода шудааст: агар онҳо намебуданд, мо ҳатто ба ин нуқта нарасидем
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // Шартномаи InPlaceIterable-ро санҷед.Ин танҳо дар сурате имконпазир аст, ки агар итератор нишондиҳандаи манбаъро комилан пеш барад.
        // Агар он дастрасии номуайянро тавассути TrustedRandomAccess истифода барад, он гоҳ нишоннамои манбаъ дар ҳолати аввалаи худ боқӣ хоҳад монд ва мо онро ҳамчун истинод истифода карда наметавонем
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ҳама гуна арзишҳои боқимондаро ба думи манбаъ партоед, аммо як бор IntoIter аз доираи худ хориҷ шуданро пешгирӣ кунад, агар panics афтад, пас мо низ ягон унсури дар dst_buf ҷамъоваришударо мерезем
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // шартномаи InPlaceIterable-ро дар ин ҷо дақиқ тасдиқ кардан мумкин нест, зеро try_fold истиноди истисноӣ ба нишоннамои манбаъ дорад, мо метавонем санҷем, ки оё он ҳанӯз ҳам дар масофа аст
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}