use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Ихтисоси дигари trait барои Vec::from_iter, ки барои афзалият додани ихтисосҳои такрори дастӣ зарур аст, барои тафсилот ба [`SpecFromIter`](super::SpecFromIter) нигаред.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Такрори аввалро кушоед, зеро дар ин ҳолат vector дар ҳама ҳолатҳо васеъ карда мешавад, агар такроршаванда холӣ набошад, аммо ҳалқа дар extend_desugared() нахоҳад дид, ки vector дар чанд такрори минбаъда пур бошад.
        //
        // Ҳамин тавр, мо пешгӯии branch-ро беҳтар мекунем.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // бояд ба spec_extend() ваколат диҳад, зеро худи extend() ба spec_from барои Vecs холӣ ваколат медиҳад
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // бояд ба spec_extend() ваколат диҳад, зеро худи extend() ба spec_from барои Vecs холӣ ваколат медиҳад
        //
        vector.spec_extend(iterator);
        vector
    }
}