use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Итераторе, ки барои бастани элемент истифода мебарад, пӯшидаро истифода мебарад.
///
/// Ин структура аз ҷониби [`Vec::drain_filter`] сохта шудааст.
/// Барои маълумоти бештар ба ҳуҷҷатҳои он нигаред.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Индекси ашёе, ки бо занги оянда ба `next` тафтиш карда мешавад.
    pub(super) idx: usize,
    /// Шумораи ашёе, ки то имрӯз (removed) холӣ шудаанд.
    pub(super) del: usize,
    /// Дарозии аслии `vec` то холӣ шудан.
    pub(super) old_len: usize,
    /// Санҷиши санҷиши филтр.
    pub(super) pred: F,
    /// Парчаме, ки panic-ро нишон медиҳад, дар предикати санҷиши филтр ба вуҷуд омадааст.
    /// Ин ҳамчун як ишора дар татбиқи тарки барои пешгирии истеъмоли боқимондаи `DrainFilter` истифода бурда мешавад.
    /// Ҳама ашёи коркарднашуда дар `vec` гузаронида мешаванд, аммо дигар ашёҳо аз ҷониби предикати филтр партофта ё санҷида намешаванд.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Истинод ба ҷудосози аслиро бармегардонад.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Навсозӣ кардани индекс *пас аз* предикат даъват карда шавад.
                // Агар индекс пеш аз такмил дода шавад ва предикати panics бошад, унсури ин индекс фош хоҳад шуд.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ин як давлати хеле бесарусомон аст ва дарвоқеъ як кори баръало дуруст нест.
                        // Мо намехоҳем кӯшиш кунем, ки `pred`-ро иҷро кунем, аз ин рӯ мо танҳо ҳамаи элементҳои коркарднашударо паси сар карда, ба vec мегӯем, ки онҳо то ҳол вуҷуд доранд.
                        //
                        // Гузариш барои пешгирии дукарата афтодани охирин ашёи бомуваффақият хушкшуда пеш аз panic дар предикат пешгирӣ кардан лозим аст.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Кӯшиши истеъмоли ҳама гуна унсурҳои боқимонда, агар предикати филтр ҳанӯз ба ҳарос наомада бошад.
        // Мо ҳар гуна унсурҳои боқимондаро сарфи назар мекунем, новобаста аз он ки мо аллакай ба воҳима афтодаем ё дар ин ҷо истеъмол panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}