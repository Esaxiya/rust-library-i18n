// Вақте ки арзиши `SetLenOnDrop` аз доираи амал берун мешавад, дарозии vec-ро таъин кунед.
//
// Ғоя чунин аст: Майдони дарозӣ дар SetLenOnDrop як тағирёбандаи маҳаллӣ мебошад, ки оптимизатор онро бо ягон нишондиҳанда тавассути нишоннамои Vec тахаллус намекунад.
// Ин як роҳи ҳалли масъалаи таҳлили тахаллуси #32155 аст
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}