use core::ptr::{self};
use core::slice::{self};

// Сохтори ёрирасон барои такрори дар ҷои худ, ки буридаи таъиншудаи такрорро, яъне сарро мепартояд.
// Буридаи манбаъ (дум) аз ҷониби IntoIter партофта мешавад.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}