use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Ихтисоси trait, ки барои Vec::from_iter истифода мешавад
///
/// ## Графики ҳайат:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Ҳолати маъмул ин гузаштани vector ба функсияест, ки фавран дубора ба vector ҷамъ мешавад.
        // Мо метавонем инро кӯтоҳ кунем, агар IntoIter ҳеҷ гоҳ пешрафта нашуда бошад.
        // Вақте ки он такмил дода шуд Мо инчунин метавонем хотираро дубора истифода барем ва маълумотро ба пеш ҳаракат диҳем.
        // Аммо мо инро танҳо вақте анҷом медиҳем, ки дар натиҷаи Vec иқтидори истифоданашуда бештар аз эҷоди он тавассути татбиқи генералии FromIterator хоҳад буд.
        //
        // Ин маҳдудият шадидан зарур нест, зеро рафтори тақсимоти Vec дидаву дониста номуайян аст.
        // Аммо ин як интихоби муҳофизакор аст.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // бояд ба spec_extend() ваколат диҳад, зеро худи extend() ба spec_from барои Vecs холӣ ваколат медиҳад
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ин аз `iterator.as_slice().to_vec()` истифода мебарад, зеро spec_extend бояд барои андешидани иқтидори ниҳоӣ + дарозӣ қадамҳои бештаре гузорад ва ба ин васила кори бештаре анҷом диҳад.
// `to_vec()` маблағи дурустро мустақиман ҷудо мекунад ва онро дақиқ пур мекунад.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): бо cfg(test) усули хосаи `[T]::to_vec`, ки барои ин таърифи усул зарур аст, дастрас нест.
    // Ба ҷои ин, функсияи `slice::to_vec`-ро истифода баред, ки танҳо бо cfg(test) NB дастрас аст, барои маълумоти бештар нигаред ба модули slice::hack дар slice.rs
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}