#![stable(feature = "wake_trait", since = "1.51.0")]
//! Намудҳо ва Traits барои кор бо вазифаҳои асинхронӣ.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Амалӣ намудани иҷрои вазифа дар назди иҷрокунанда.
///
/// Ин trait метавонад барои сохтани [`Waker`] истифода шавад.
/// Иҷрокунанда метавонад татбиқи ин trait-ро муайян кунад ва бо истифода аз он барои сохтани Вейкер ба вазифаҳое, ки дар он иҷрокунанда иҷро мешаванд, истифода барад.
///
/// Ин trait алтернативаи бехатар барои хотира ва эргономикии сохтани [`RawWaker`] мебошад.
/// Он тарҳи иҷрокунандаи маъмулро дастгирӣ мекунад, ки дар он маълумот барои бедор кардани вазифа дар [`Arc`] нигоҳ дошта мешавад.
/// Баъзе иҷрокунандагон (алахусус онҳое, ки барои системаҳои дарунсохт) наметавонанд ин API-ро истифода баранд, аз ин рӯ [`RawWaker`] ҳамчун алтернатива барои он системаҳо мавҷуд аст.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Функсияи асосии `block_on`, ки future-ро мегирад ва онро дар риштаи ҷорӣ ба итмом мерасонад.
///
/// **Note:** Ин мисол дурустиро барои соддагӣ савдо мекунад.
/// Бо мақсади пешгирии бастани бандҳо, амалисозии дараҷаи истеҳсолот инчунин бояд зангҳои мобайнӣ ба `thread::unpark` ва инчунин даъватномаҳои лона дошта бошанд.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Бедоре, ки ҳангоми даъват риштаи ҷориро бедор мекунад.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// future-ро барои ба итмом расонидани риштаи ҷорӣ иҷро кунед.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future-ро пинҳон кунед, то он пурсида шавад.
///     let mut fut = Box::pin(fut);
///
///     // Як контексти нав эҷод кунед, ки ба future гузаронида шавад.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future-ро ба итмом расонед.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Ин вазифаро бедор кунед.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Ин вазифаро бе истеъмоли вакей бедор кунед.
    ///
    /// Агар иҷрокунанда роҳи арзонтари бедоршударо бидуни истеъмоли вакей дастгирӣ кунад, бояд ин усулро бекор кунад.
    /// Бо нобаёнӣ, он [`Arc`]-ро клон мекунад ва дар клон [`wake`]-ро даъват мекунад.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // БЕХАТАР: : Ин бехатар аст, зеро raw_waker бехатар месозад
        // як RawWaker аз Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ин функсияи хусусӣ барои сохтани RawWaker истифода мешавад, на
// дохил кардани ин ба имлои `From<Arc<W>> for RawWaker`, барои он, ки бехатарии `From<Arc<W>> for Waker` аз фиристодани trait дуруст вобаста набошад, ба ҷои ин ҳарду ин функсияро мустақиман ва возеҳ меноманд.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Барои клонидани он, ҳисобкунии истиноди камонро зиёд кунед.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Аз рӯи қимат бедор шавед ва камонро ба вазифаи Wake::wake интиқол диҳед
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Бо истинод бедор шавед, стаканро ба ManuallyDrop печонед, то тарки он нашавад
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Ҳисоби истинод ба камон кам карда шавад
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}