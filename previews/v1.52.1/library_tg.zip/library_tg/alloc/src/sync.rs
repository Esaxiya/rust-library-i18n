#![stable(feature = "rust1", since = "1.0.0")]

//! Нишондиҳандаҳои ҳисобкунии истинод барои бехатарии ришта.
//!
//! Барои тафсилоти бештар ба ҳуҷҷатҳои [`Arc<T>`][Arc] нигаред.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Маҳдудияти нарм дар ҳаҷми истинодҳое, ки метавонанд ба `Arc` дода шаванд.
///
/// Аз ин маҳдудият гузаштан барномаи шуморо қатъ мекунад (ҳарчанд ҳатмӣ нест) дар истинодҳои _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer деворҳои хотираро дастгирӣ намекунад.
// Барои роҳ надодан ба ҳисоботи мусбии бардурӯғ дар татбиқи Arc/Weak, ба ҷои он бори атомиро барои ҳамоҳангсозӣ истифода баред.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Нишондиҳандаи ҳисобкунии истинод барои бехатарии ришта.'Arc' маънои "Маълумоти ҳастаӣ ҳисоб карда шудааст"-ро дорад.
///
/// Навъи `Arc<T>` моликияти муштараки арзиши навъи `T`-ро, ки дар теппа ҷудо карда шудааст, таъмин менамояд.Даъват кардани [`clone`][clone] дар `Arc` як мисоли нави `Arc`-ро ба вуҷуд меорад, ки он ба ҳамон тақсимот дар теппае, ки манбаи `Arc` дорад, ишора мекунад ва дар айни замон шумораи истинодро зиёд мекунад.
/// Вақте ки нишоннамои охирини `Arc` ба тақсимоти додаҳо нест карда мешаванд, арзиши дар ин тақсимот ҳифзшуда (аксар вақт "inner value" номида мешавад) низ партофта мешавад.
///
/// Истинодҳои муштарак дар Rust мутатсияро бо нобаёнӣ манъ мекунанд ва `Arc` истисно нест: шумо наметавонед ба таври умум истиноди тағиршавандаро ба чизе дар дохили `Arc` ба даст оред.Агар ба шумо лозим ояд, ки тавассути `Arc` мутатсия кунед, [`Mutex`][mutex], [`RwLock`][rwlock] ё яке аз намудҳои [`Atomic`][atomic]-ро истифода баред.
///
/// ## Бехатарии ришта
///
/// Баръакси [`Rc<T>`], `Arc<T>` амалҳои атомиро барои ҳисобкунии истинод истифода мебарад.Ин маънои онро дорад, ки он бехатар аст.Камбудӣ дар он аст, ки амалиётҳои атомӣ нисбат ба дастрасии оддии хотира гаронтаранд.Агар шумо тақсимоти ҳисобшудаи истинодро дар байни риштаҳо тақсим накунед, истифодаи [`Rc<T>`] барои хароҷоти камтарро дида бароед.
/// [`Rc<T>`] бо нобаёнӣ бехатар аст, зеро тартибдиҳанда кӯшиши фиристодани [`Rc<T>`] байни риштаҳоро хоҳад гирифт.
/// Аммо, китобхона метавонад `Arc<T>`-ро интихоб кунад, то ба истеъмолкунандагони китобхона чандирии бештар диҳад.
///
/// `Arc<T>` то он даме, ки `T` [`Send`] ва [`Sync`]-ро татбиқ мекунад, [`Send`] ва [`Sync`]-ро амалӣ мекунад.
/// Чаро шумо наметавонед навъи `T`-ро барои риштаи бехатари `Arc<T>` барои риштаи бехатар ҷойгир кунед?Ин метавонад дар аввал каме муқовимат бошад: пас оё нуқтаи бехатарии риштаи `Arc<T>` нест?Калид ин аст: `Arc<T>` риштаи бехатарро ба моликияти якхела доштани як маълумот медиҳад, аммо он ба маълумоти худ амнияти риштаро илова намекунад.
///
/// "Arc <" ["RefCell<T>"]">".
/// [`RefCell<T>`] [`Sync`] нест ва агар `Arc<T>` ҳамеша [`Send`] бошад, "Arc <" [`RefCell<T>"]">"инчунин мебуд.
/// Аммо пас аз он мо мушкилот дорем:
/// [`RefCell<T>`] ришта бехатар нест;он ҳисобкунии қарзҳоро бо истифода аз амалиётҳои ғайриатомӣ назорат мекунад.
///
/// Дар ниҳоят, ин маънои онро дорад, ки ба шумо лозим аст, ки `Arc<T>`-ро бо ягон намуди [`std::sync`], одатан [`Mutex<T>`][mutex] ҷуфт кунед.
///
/// ## Танаффус давраҳо бо `Weak`
///
/// Усули [`downgrade`][downgrade] метавонад барои сохтани нишонаи [`Weak`] ғайри соҳибӣ истифода шавад.Нишондиҳандаи [`Weak`] метавонад [`upgrade '][upgrade] d ба `Arc` бошад, аммо ин [`None`]-ро бармегардонад, агар арзиши дар ҷудокунишуда сабтшуда аллакай партофта шуда бошад.
/// Ба ибораи дигар, нишондиҳандаҳои `Weak` арзиши дохили тақсимотро зинда нигоҳ намедоранд;аммо, онҳо тақсимотро (мағозаи пуштибонӣ барои арзиш) зинда нигоҳ медоранд.
///
/// Давраи байни нишондиҳандаҳои `Arc` ҳеҷ гоҳ тақсим карда намешавад.
/// Аз ин сабаб, [`Weak`] барои шикастани давраҳо истифода мешавад.Масалан, дарахт метавонад нишондиҳандаҳои пурқуввати `Arc` аз гиреҳи волидайн ба кӯдакон ва [`Weak`] нишондиҳандаҳои кӯдакон ба волидайн дошта бошад.
///
/// # Клонидани маълумотномаҳо
///
/// Сохтани истиноди нав аз нишоннамои мавҷудаи ҳисобшуда бо истифодаи `Clone` trait, ки барои [`Arc<T>`][Arc] ва [`Weak<T>`][Weak] татбиқ карда мешавад, анҷом дода мешавад.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Ду синтаксиси дар поён овардашуда баробаранд.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b ва foo ҳама аркҳо мебошанд, ки ба як макони хотира ишора мекунанд
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ба тариқи худкор ба `T` муроҷиат мекунад (тавассути [`Deref`][deref] trait), бинобар ин шумо метавонед усулҳои "T"-ро бо арзиши навъи `Arc<T>` занг занед.Барои роҳ надодан ба бархӯрдҳои номӣ бо усулҳои "T", усулҳои худи `Arc<T>` вазифаҳои алоқаманд мебошанд, ки истифодаи [fully qualified syntax] номида мешаванд:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// "Камон<T>Татбиқи traits, ба монанди `Clone`, инчунин бо истифода аз синтаксиси пурихтисос номида мешавад.
/// Баъзе одамон истифодаи синтаксиси пурихтисосро афзал медонанд, дигарон бошанд истифодаи синтаксиси усули даъватро афзал медонанд.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Усули зангзанӣ
/// let arc2 = arc.clone();
/// // Синтаксиси пурраи тахассусӣ
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ба `T` худкор тағир намедиҳад, зеро арзиши дохилӣ аллакай партофта шудааст.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Мубодилаи баъзе маълумоти тағирнашаванда байни риштаҳо:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Аҳамият диҳед, ки мо ин санҷишҳоро **дар инҷо** иҷро намекунем.
// Сохтмончиёни windows аз он бадбахт мешаванд, ки агар ришта аз риштаи асосӣ умр ба сар барад ва ҳамзамон берун ояд (чизе баста мешавад), аз ин рӯ мо танҳо бо истифода аз ин озмоишҳо аз ин пешгирӣ мекунем.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Мубодилаи [`AtomicUsize`] тағирёбанда:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Барои мисолҳои бештари ҳисобкунии истинод дар маҷмӯъ ба [`rc` documentation][rc_examples] нигаред.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` версияи [`Arc`] мебошад, ки истиноди ғайримуқаррарӣ ба ҷудошавии идорашаванда дорад.
/// Ба ҷудокунӣ тавассути даъвати [`upgrade`] дар нишоннамои `Weak`, ки ["Опсия"] "<" [`Arc`]"-ро бар мегардонад, дастрас аст.<T>>`.
///
/// Азбаски истиноди `Weak` нисбати моликият ба ҳисоб гирифта намешавад, он арзиши афтодани ҷудокунандаро пешгирӣ намекунад ва худи `Weak` дар бораи арзиши ҳанӯз мавҷудбуда кафолат намедиҳад.
///
/// Ҳамин тариқ, он метавонад [`None`]-ро баргардонад, вақте ки [`такмил '] d.
/// Аммо дар хотир доред, ки истиноди `Weak` * имкон намедиҳад, ки худи тақсимот (мағозаи пуштибонӣ) тақсим карда шавад.
///
/// Нишондиҳандаи `Weak` барои нигоҳ доштани истиноди муваққатӣ ба тақсимоти аз ҷониби [`Arc`] идорашаванда бе пешгирӣ аз афтодани арзиши ботинии он муфид аст.
/// Он инчунин барои пешгирии истинодҳои даврӣ дар байни нишондиҳандаҳои [`Arc`] истифода мешавад, зеро истинодҳои мутақобила ҳеҷ гоҳ намегузоранд, ки [`Arc`] партофта шавад.
/// Масалан, дарахт метавонад нишондиҳандаҳои пурқуввати [`Arc`] аз гиреҳҳои волидайн ба кӯдакон ва `Weak` нишондиҳандаҳо аз кӯдакон ба волидайн дошта бошад.
///
/// Усули маъмулии ба даст овардани нишоннамои `Weak` занг задан ба [`Arc::downgrade`] мебошад.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ин `NonNull` аст, то имкон медиҳад, ки андозаи ин навъи оптимизатсия оптимизатсия карда шавад, аммо он ҳатман нишоннамои дуруст нест.
    //
    // `Weak::new` онро ба `usize::MAX` муқаррар мекунад, то ки дар тӯда ҷой ҷудо кардан лозим набошад.
    // Ин як аҳамияти нишоннамои воқеӣ нест, зеро RcBox ҳадди аққал ҳамоҳанг мекунад.
    // Ин танҳо вақте имконпазир аст, ки `T: Sized`;`T` беандоза ҳеҷ гоҳ намерасад.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Ин repr(C) ба future-бар зидди фармоиши эҳтимолии майдон аст, ки ба [into|from]_raw() дар акси ҳол бехатар дар намудҳои дохилии трансмутатсионӣ халал мерасонанд.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // арзиши usize::MAX ҳамчун посбон барои муваққатан "locking" қобилияти нав кардани нишондиҳандаҳои заиф ё паст кардани нишонаҳои қавӣ амал мекунад;ин барои пешгирӣ кардани нажодҳо дар `make_mut` ва `get_mut` истифода мешавад.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// `Arc<T>` нав месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Ҳисобкунии сустро ҳамчун 1 оғоз кунед, ки нишондиҳандаи заиф аст, ки онро ҳамаи нишондиҳандаҳои пурқувват (kinda) нигоҳ медоранд, барои маълумоти бештар нигаред ба std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Бо истифода аз истиноди суст ба худ як `Arc<T>` нав месозад.
    /// Кӯшиши такмил додани истиноди суст пеш аз баргардонидани ин функсия, арзиши `None` хоҳад овард.
    /// Аммо, истиноди заифро озодона клонидан ва барои истифода дертар нигоҳ доштан мумкин аст.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Бо як истиноди сусти ботинӣ дар ҳолати "uninitialized" созед.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Муҳим аст, ки мо аз соҳибӣ ба нишондиҳандаи заиф даст накашем, вагарна пас аз бозгашти `data_fn` хотира метавонад халос шавад.
        // Агар мо воқеан мехостем соҳиби моликият шавем, метавонистем барои худ нишондиҳандаи заифи дигаре эҷод кунем, аммо ин боиси навсозиҳои иловагӣ ба ҳисоби истинодҳои заъиф хоҳад шуд, ки дар акси ҳол лозим нестанд.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Ҳоло мо метавонем арзиши ботиниро дуруст оғоз кунем ва истиноди сусти худро ба истиноди қавӣ табдил диҳем.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Навиштаи дар боло овардашуда ба майдони додаҳо бояд барои ҳар як риштае, ки ҳисобкунии пурқувватро риоя мекунанд, намоён бошад.
            // Аз ин рӯ, ба мо ҳадди аққал фармоиш лозим аст, то бо `compare_exchange_weak` дар `Weak::upgrade` ҳамоҳанг шавем.
            //
            // "Acquire" фармоиш талаб карда намешавад.
            // Ҳангоми баррасии рафтори эҳтимолии `data_fn` мо бояд танҳо ба он назар афканем, ки он метавонад бо истинод ба `Weak`-и навсозишаванда чӣ кор карда метавонад:
            //
            // - Он метавонад `Weak`-ро *клон кунад*, миқдори заифи истинодро афзоиш диҳад.
            // - Он метавонад ин клонҳоро афтонад ва шумораи истинодҳои заифро коҳиш диҳад (аммо ҳеҷ гоҳ ба сифр).
            //
            // Ин таъсири манфӣ ба мо ҳеҷ гуна таъсир намерасонанд ва танҳо бо рамзи бехатар дигар таъсироти дигар имконнопазиранд.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Истинодҳои қавӣ бояд дар якҷоягӣ истиноди сусти муштарак дошта бошанд, бинобар ин, деструктори истиноди сусти кӯҳнаи моро иҷро накунед.
        //
        mem::forget(weak);
        strong
    }

    /// Сохтани `Arc` нав бо мундариҷаи uninitialized.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Arc`-и навро бо мундариҷаи номаълум сохта, бо хотира бо байтҳои `0` месозад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Pin<Arc<T>>` нав месозад.
    /// Агар `T` `Unpin`-ро татбиқ накунад, он гоҳ `data` дар хотира пинҳон хоҳад шуд ва ҳаракат кардан ғайриимкон аст.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Сохтани `Arc<T>` нав, баргардонидани хато, агар ҷудошавӣ ноком шавад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Ҳисобкунии сустро ҳамчун 1 оғоз кунед, ки нишондиҳандаи заиф аст, ки онро ҳамаи нишондиҳандаҳои пурқувват (kinda) нигоҳ медоранд, барои маълумоти бештар нигаред ба std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Сохтани `Arc` нав бо мундариҷаи номаълум, хаторо бармегардонад, агар ҷудошавӣ ноком шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Сохтани `Arc` нав бо мундариҷаи номаълум, бо хотира бо байтҳои `0` пур карда мешавад, агар хато ҷудо нашавад, хаторо бармегардонад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Арзиши дохилиро бармегардонад, агар `Arc` дақиқан як истиноди қавӣ дошта бошад.
    ///
    /// Дар акси ҳол, [`Err`] бо ҳамон `Arc`, ки дар гузашта буд, баргардонида мешавад.
    ///
    ///
    /// Ин муваффақ хоҳад шуд, ҳатто агар маълумотномаҳои заиф мавҷуд бошанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Барои тоза кардани истиноди номувофиқи заиф нишонаи заиф созед
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Як буридаи нави аз ҷиҳати атом истинодшударо бо мундариҷаи номаълум месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Як буридаи нави аз ҷиҳати атом истинодшударо бо мундариҷаи ношинос месозад, ва хотираи он бо байтҳои `0` пур карда мешавад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Ба `Arc<T>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], занг задан ба он аст, ки арзиши ботинӣ воқеан дар ҳолати ибтидоӣ бошад.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Ба `Arc<[T]>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], занг задан ба он аст, ки арзиши ботинӣ воқеан дар ҳолати ибтидоӣ бошад.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc`-ро истеъмол мекунад, ва нишоннамои парпечшударо бармегардонад.
    ///
    /// Барои роҳ надодан ба ифшои хотира, нишондиҳанда бояд бо истифода аз [`Arc::from_raw`] ба `Arc` гузаронида шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ба маълумот нишондиҳандаи хом медиҳад.
    ///
    /// Ҳисобҳо ба ҳеҷ ваҷҳ таъсир намерасонанд ва `Arc` истеъмол карда намешавад.
    /// Нишондиҳанда то он даме амал мекунад, ки дар `Arc` ҳисобҳои қавӣ вуҷуд дошта бошанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // БЕХАТАР This: Ин наметавонад тавассути Deref::deref ё RcBoxPtr::inner гузарад, зеро
        // ин барои нигоҳ доштани raw/mut исботшуда зарур аст, масалан
        // `get_mut` метавонад тавассути нишондиҳанда пас аз барқарор шудани Rc тавассути `from_raw` нависад.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Аз нишоннамои хом `Arc<T>` месозад.
    ///
    /// Нишондиҳандаи хом бояд қаблан тавассути занг ба [`Arc<U>::into_raw`][into_raw] баргардонида шуда бошад, ки дар он `U` бояд бо андозаи `T` баробар ва мутобиқ бошад.
    /// Агар `U` `T` бошад, ин хеле ночиз аст.
    /// Дар хотир доред, ки агар `U` `T` набошад, аммо ҳаҷм ва ҳамоҳангии якхела дошта бошад, ин асосан ба тарҷумаи истинодҳои намудҳои гуногун монанд аст.
    /// Барои маълумоти бештар дар бораи кадом маҳдудиятҳо дар ин ҳолат, ба [`mem::transmute`][transmute] нигаред.
    ///
    /// Истифодабарандаи `from_raw` бояд боварӣ ҳосил кунад, ки арзиши мушаххаси `T` танҳо як маротиба афтидааст.
    ///
    /// Ин вазифа хатарнок аст, зеро истифодаи номатлуб метавонад боиси бехатарии хотира гардад, ҳатто агар ба `Arc<T>` баргашта ҳеҷ гоҳ дастрас нашавад.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Ба `Arc` баргардед, то пешгирӣ аз ихроҷ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Зангҳои минбаъда ба `Arc::from_raw(x_ptr)` барои хотира хатарнок хоҳанд буд.
    /// }
    ///
    /// // Вақте ки `x` аз доираи боло баромад, хотира озод карда шуд, бинобар ин `x_ptr` ҳоло овезон аст!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Барои ёфтани ArcInner аслӣ ҷубронро баръакс кунед.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ба ин ҷудокунӣ нишоннамои нави [`Weak`] месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Ин Relaxed хуб аст, зеро мо арзиши CAS-и зеринро тафтиш карда истодаем.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // санҷед, ки оё ҳисобкунаки заиф айни замон "locked" аст;агар ҳа, чарх занед.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ин рамз айни замон имкони пур шудани обро нодида мегирад
            // ба usize::MAX;дар маҷмӯъ ҳам Rc ва ҳам Arc бояд барои мубориза бо изофа танзим карда шаванд.
            //

            // Баръакси Clone(), ба мо лозим аст, ки ин як хариди хониш бошад, то бо навиштаи аз `is_unique` омада синхронизатсия карда шавад, то ҳодисаҳои қабл аз навиштан пеш аз хондан рӯй диҳанд.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Боварӣ ҳосил кунед, ки мо Заи сустро эҷод намекунем
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Миқдори нишондиҳандаҳои [`Weak`]-ро ба ин тақсимот меорад.
    ///
    /// # Safety
    ///
    /// Ин усул худ аз худ бехатар аст, аммо истифодаи дурусти он ғамхории иловагиро талаб мекунад.
    /// Риштаи дигар метавонад ҳисоби заифро дар ҳар лаҳза тағйир диҳад, аз ҷумла эҳтимолан дар байни даъват кардани ин усул ва амал кардан ба натиҷа.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ин тасдиқ детерминист, зеро мо `Arc` ё `Weak`-ро дар байни риштаҳо тақсим накардаем.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Агар ҳоло ҳисоби заиф баста бошад, арзиши ҳисоб танҳо пеш аз гирифтани қулф 0 буд.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Шумораи нишондиҳандаҳои пурқуввати (`Arc`)-ро ба ин тақсимот меорад.
    ///
    /// # Safety
    ///
    /// Ин усул худ аз худ бехатар аст, аммо истифодаи дурусти он ғамхории иловагиро талаб мекунад.
    /// Риштаи дигар метавонад ҳисоби пурқувватро ҳар вақт тағир диҳад, аз ҷумла эҳтимолан дар байни даъват кардани ин усул ва амал кардан ба натиҷа.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ин изҳорот муайянкунанда аст, зеро мо `Arc`-ро байни риштаҳо тақсим накардаем.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Ҳисоби қавии истинодҳоро ба `Arc<T>`, ки бо нишоннамои додашуда алоқаманд аст, як ба як меафзояд.
    ///
    /// # Safety
    ///
    /// Нишондиҳанда бояд тавассути `Arc::into_raw` гирифта шуда бошад ва мисоли `Arc` алоқаманд бояд эътибор дошта бошад (яъне.)
    /// ҳисоби қавӣ бояд ҳадди аққал 1) дар тӯли ин усул бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ин изҳорот муайянкунанда аст, зеро мо `Arc`-ро байни риштаҳо тақсим накардаем.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc-ро нигоҳ доред, аммо бо ҳисобкунии ManuallyDrop ба ҳисоби дубора даст нарасонед
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Акнун ҳисоби ҳисобро афзоиш диҳед, аммо ҳисобкунии навро низ напартоед
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Ҳисоби қавии истинод ба `Arc<T>`-ро, ки бо нишоннамои додашуда алоқаманд аст, якбора кам мекунад.
    ///
    /// # Safety
    ///
    /// Нишондиҳанда бояд тавассути `Arc::into_raw` гирифта шуда бошад ва мисоли `Arc` алоқаманд бояд эътибор дошта бошад (яъне.)
    /// ҳангоми истифодаи ин усул шумораи қавӣ бояд ҳадди аққал 1) бошад.
    /// Ин усул метавонад барои баровардани `Arc` ниҳоӣ ва захираи пуштибонӣ истифода шавад, аммо **пас аз баровардани `Arc` ниҳоӣ набояд** даъват карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ин изҳоротҳо детерминикӣ мебошанд, зеро мо `Arc`-ро дар байни риштаҳо тақсим накардаем.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ин бехатарӣ хуб аст, зеро вақте ки ин камон зинда аст, мо кафолат медиҳем, ки нишоннамои ботинӣ дуруст аст.
        // Ғайр аз ин, мо медонем, ки худи сохтори `ArcInner` `Sync` аст, зеро маълумоти дохилӣ низ `Sync` аст, бинобар ин мо хуб ҳастем, ки ба ин мундариҷа нишоннамои тағирнопазир диҳем.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Қисми ғайримуқаррарии `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Дар айни замон, маълумотро нобуд кунед, гарчанде ки мо худи қуттии қуттиро озод карда наметавонем (то ҳол нишондиҳандаҳои заиф дар атрофи он ҷойгиранд).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Тарки рефҳои заифро дар якҷоягӣ бо ҳама маълумотномаҳои қавӣ нигоҳ доред
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true`-ро бармегардонад, агар ду Arc` ба як тақсимот ишора кунанд (дар раги монанд ба [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>`-ро бо фазои кофӣ барои арзиши ботинии эҳтимолан номуайян ҷудо мекунад, ки дар он арзиш тарҳбандӣ шудааст.
    ///
    /// Функсияи `mem_to_arcinner` бо нишоннамои додаҳо даъват карда мешавад ва бояд барои `ArcInner<T>` нишоннамои (эҳтимолан чарб) баргардад.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Тарҳро бо истифода аз тарҳбандии арзиши додашуда ҳисоб кунед.
        // Пештар, тарҳ дар ифодаи `&*(ptr as* const ArcInner<T>)` ҳисоб карда мешуд, аммо ин истиноди нодурустро ба вуҷуд овард (ниг. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>`-ро бо фазои кофӣ барои арзиши ботинии эҳтимолан ҷудокардашуда, ки дар он арзиши тарҳбандӣ пешбинӣ шудааст, ҷудо мекунад ва дар сурати қатъ нашудани хато.
    ///
    ///
    /// Функсияи `mem_to_arcinner` бо нишоннамои додаҳо даъват карда мешавад ва бояд барои `ArcInner<T>` нишоннамои (эҳтимолан чарб) баргардад.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Тарҳро бо истифода аз тарҳбандии арзиши додашуда ҳисоб кунед.
        // Пештар, тарҳ дар ифодаи `&*(ptr as* const ArcInner<T>)` ҳисоб карда мешуд, аммо ин истиноди нодурустро ба вуҷуд овард (ниг. #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner-ро оғоз кунед
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// `ArcInner<T>`-ро бо фазои кофӣ барои арзиши ботинии беандоза ҷудо мекунад.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Бо истифода аз арзиши додашуда барои `ArcInner<T>` ҷудо кунед.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Арзишро ҳамчун байт нусхабардорӣ кунед
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Ҷудокуниро бидуни тарки мундариҷа озод кунед
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// `ArcInner<[T]>`-ро бо дарозии додашуда тақсим мекунад.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Нусхабардории унсурҳо аз бурида ба Arc-и нав ҷудошуда <\[T\]>
    ///
    /// Хатарнок аст, зеро зангзан бояд ё соҳиби моликият шавад ё `T: Copy`-ро бандад.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>` месозад, аз iterator маълум аст, ки андозаи муайян дорад.
    ///
    /// Рафтор номуайян аст, агар андоза нодуруст бошад.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Посбони Panic ҳангоми клонидани унсурҳои Т.
        // Дар сурати пайдо шудани panic, унсурҳое, ки ба ArcInner нав навишта шудаанд, партофта мешаванд ва хотираи онҳо холӣ мешавад.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Нишондиҳанда ба унсури аввал
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Ҳама равшан.Посбонро фаромӯш кунед, то он ArcInner навро озод накунад.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Ихтисоси trait, ки барои `From<&[T]>` истифода мешавад.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Клони нишоннамои `Arc` месозад.
    ///
    /// Ин нишондиҳандаи дигарро ба ҳамон тақсимот эҷод мекунад ва шумораи истиноди қавӣро афзоиш медиҳад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Истифодаи фармоиши осуда дар ин ҷо хуб аст, зеро донистани истиноди аслӣ риштаҳои дигарро ба хато ҳазф кардани объект пешгирӣ мекунад.
        //
        // Тавре ки дар [Boost documentation][1] шарҳ дода шудааст, зиёд кардани ҳисобкунии истинод ҳамеша метавонад бо memory_order_relaxed амалӣ карда шавад: Истинодҳои нав ба объект танҳо аз як истиноди мавҷуда ташаккул дода мешаванд ва интиқоли истиноди мавҷуда аз як ришта ба риштаи дигар бояд аллакай ҳамоҳангсозии лозимаро таъмин кунад.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Бо вуҷуди ин, мо бояд аз ҳисоби барасмиятдарории азим эҳтиёт шавем, агар касе Arcs "mem: : unut" кунад.
        // Агар мо ин корро накунем, ҳисоб метавонад пур шавад ва корбарон пас аз ройгон истифода баранд.
        // Мо ба `isize::MAX` нажодпарастона чунин мепиндорем, ки агар ~2 миллиард ришта вуҷуд надорад, ки шумораи истинодро якбора афзоиш диҳад.
        //
        // Ин branch ҳеҷ гоҳ дар ягон барномаи воқеӣ гирифта намешавад.
        //
        // Мо исқоти ҳамл мекунем, зеро чунин барнома бениҳоят таназзул дорад ва мо ба дастгирии он парво надорем.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Ба `Arc` додашуда истиноди тағирпазир медиҳад.
    ///
    /// Агар дигар `Arc` ё [`Weak`] нишондиҳандаҳои ба ҳамин тақсимот мавҷуд бошанд, пас `make_mut` ҷудокунии нав эҷод мекунад ва ба арзиши дохилӣ [`clone`][clone]-ро даъват мекунад, то соҳиби беназир гардад.
    /// Ин инчунин ҳамчун клони навиштан номида мешавад.
    ///
    /// Дар хотир доред, ки ин аз рафтори [`Rc::make_mut`] фарқ мекунад, ки ҳама нишондиҳандаҳои боқимондаи `Weak`-ро ҷудо мекунад.
    ///
    /// Инчунин ба [`get_mut`][get_mut] нигаред, ки ба ҷои клонкунӣ, ноком мешавад.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ҳеҷ чизро клон намекунад
    /// let mut other_data = Arc::clone(&data); // Маълумоти дохилиро клон намекунанд
    /// *Arc::make_mut(&mut data) += 1;         // Маълумоти дохилиро клон мекунад
    /// *Arc::make_mut(&mut data) += 1;         // Ҳеҷ чизро клон намекунад
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ҳеҷ чизро клон намекунад
    ///
    /// // Ҳоло `data` ва `other_data` ба тақсимоти гуногун ишора мекунанд.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Дар хотир доред, ки мо ҳам истиноди қавӣ ва ҳам истиноди суст дорем.
        // Ҳамин тариқ, озод кардани истиноди қавии мо танҳо худ аз худ боиси тақсимоти хотира нахоҳад шуд.
        //
        // Acquire-ро истифода баред, то боварӣ ҳосил намоем, ки мо ба `weak` ҳар гуна навиштаҳоро мебинем, ки пеш аз озод шудан ба `strong` (яъне коҳишҳо) рӯй медиҳанд.
        // Азбаски мо ҳисоби заиф дорем, имкони тақсимоти худи ArcInner вуҷуд надорад.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Боз як нишоннамои қавӣ мавҷуд аст, бинобар ин мо бояд клон кунем.
            // Хотираро пешакӣ ҷудо кунед, то ки арзиши мустақиман нависед.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Дар боло гуфтаҳо оромиш кофист, зеро ин комилан оптимизатсия аст: мо ҳамеша бо сабқат нишондиҳандаҳои сустро партофта истодаем.
            // Бадтарин ҳолат, мо ночизе камони навро ҷудо кардем.
            //

            // Мо охирин рефи пурқувватро бартараф кардем, аммо refҳои сусти иловагӣ боқӣ мондаанд.
            // Мо мундариҷаро ба камони нав интиқол медиҳем ва дигар радифони сустро беэътибор мекунем.
            //

            // Дар хотир доред, ки барои хониши `weak` ба даст овардани usize::MAX имконнопазир аст (яъне қуфл шудааст), зеро ҳисоби заифро танҳо тавассути ришта бо истиноди қавӣ бастан мумкин аст.
            //
            //

            // Нишондиҳандаи ноаёни заифи худро ба кор дароред, то он метавонад ArcInner-ро дар ҳолати зарурӣ тоза кунад.
            //
            let _weak = Weak { ptr: this.ptr };

            // Метавонад танҳо маълумотро бидуздад, танҳо заифҳо боқӣ мондаанд
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Мо ягона истинод аз ҳар навъ будем;баргаштан ба ҳисоби пурраи реф.
            //
            this.inner().strong.store(1, Release);
        }

        // Тавре ки дар `get_mut()`, бехатарӣ хуб аст, зеро истиноди мо беназир буд ва ё баъд аз клон кардани мундариҷа шуд.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Истиноди тағиршавандаро ба `Arc` додашуда бармегардонад, агар дигар нишондиҳандаҳои `Arc` ё [`Weak`] ба ҳамон тақсимот набошанд.
    ///
    ///
    /// Дар акси ҳол, [`None`]-ро бармегардонад, зеро mutate кардани арзиши муштарак бехатар нест.
    ///
    /// Инчунин ба [`make_mut`][make_mut] нигаред, ки ҳангоми мавҷудияти нишондиҳандаҳои дигар арзиши ботиниро [`clone`][clone] хоҳад кард.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ин бехатарӣ хуб аст, зеро ба мо кафолат дода мешавад, ки нишоннамои баргашта *ягона* нишондиҳандаест, ки ҳамеша ба T баргардонида мешавад.
            // Ҳисоби истинодии мо дар ин лаҳза 1 хоҳад буд ва мо аз худ камонро талаб кардем, ки `mut` бошад, бинобар ин мо танҳо истиноди имконпазирро ба маълумоти дохилӣ бармегардонем.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Истиноди тағиршавандаро ба `Arc` додашуда бе ягон чек бармегардонад.
    ///
    /// Инчунин нигаред ба [`get_mut`], ки бехатар аст ва санҷишҳои мувофиқро анҷом медиҳад.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Ҳама нишондиҳандаҳои дигари `Arc` ё [`Weak`], ки ба ҳамин тақсимот мансубанд, набояд дар давоми қарзи баргардонида шаванд.
    ///
    /// Ин ҳолат ночиз аст, агар чунин нишондиҳандаҳо мавҷуд набошанд, масалан фавран пас аз `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Мо эҳтиёткор ҳастем, ки истинодеро дар бар гирад, ки соҳаҳои "count"-ро фароҳам орад *, зеро ин бо дастрасии ҳамзамон ба ҳисобҳои истинод тахаллус хоҳад кард (масалан.
        // аз ҷониби `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Муайян кунед, ки оё ин истиноди беназир аст (аз ҷумла ишораҳои заиф) ба маълумоти асосӣ.
    ///
    ///
    /// Дар хотир доред, ки ин бастани ҳисобкунии сусти талабро талаб мекунад.
    fn is_unique(&mut self) -> bool {
        // ҳисоб кардани нишондиҳандаҳои сустро маҳкам кунед, агар мо ягона дорандаи нишоннамои заиф бошем.
        //
        // Нишони харид дар ин ҷо муносибати пеш аз рухдодаро бо ҳама гуна навиштаҳо ба `strong` (алахусус дар `Weak::upgrade`) пеш аз кам кардани шумори `weak` (тавассути `Weak::drop`, ки релизро истифода мебарад) таъмин мекунад.
        // Агар рефи сусти такмилёфта ҳеҷ гоҳ сарнагун карда нашавад, CAS дар инҷо ноком хоҳад шуд, аз ин рӯ барои мо ҳамоҳангсозӣ фарқ надорад.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Ин бояд `Acquire` бошад, то ки бо кам шудани ҳисобкунии `strong` дар `drop` ҳамоҳанг карда шавад-ягона дастрасие, ки ҳангоми истироҳат, вале истиноди охирин рух медиҳад.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Нашри нав дар инҷо бо хониш дар `downgrade` ҳамоҳанг мешавад ва самаранок пешгирӣ кардани хондани дар боло зикршудаи `strong` пас аз навиштан мебошад.
            //
            //
            self.inner().weak.store(1, Release); // қулфро озод кунед
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Тарки `Arc`.
    ///
    /// Ин ҳисобҳои пурқувватро коҳиш медиҳад.
    /// Агар ҳисобҳои қавии истинод ба сифр расанд, пас танҳо истинодҳои дигар (агар бошанд) [`Weak`] мебошанд, аз ин рӯ мо арзиши ботиниро `drop` мекунем.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ҳеҷ чизро чоп намекунад
    /// drop(foo2);   // "dropped!" чоп мекунад
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Азбаски `fetch_sub` аллакай атом аст, ба мо лозим нест, ки бо дигар риштаҳо ҳамоҳанг шавем, агар мо объектро нест накунем.
        // Худи ҳамин мантиқ ба `fetch_sub` дар зер ба ҳисоби `weak` дахл дорад.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ин девор барои пешгирии азнавбарқароркунии истифодаи маълумот ва нест кардани маълумот лозим аст.
        // Азбаски он бо `Release` ишора шудааст, кам шудани шумораи истинод бо ин девор `Acquire` ҳамоҳанг мешавад.
        // Ин маънои онро дорад, ки истифодаи маълумот пеш аз кам шудани шумори истинод, ки пеш аз ин девор рух медиҳад, пеш аз нест кардани маълумот ба амал меояд.
        //
        // Тавре ки дар [Boost documentation][1] шарҳ дода шудааст,
        //
        // > Ҳама гуна дастрасии имконпазир ба объектро дар як чиз таъмин кардан муҳим аст
        // > ришта (тавассути истиноди мавҷуда) то * пеш аз нест кардан рӯй диҳад
        // > ашё дар риштаи дигар.Ин тавассути "release" ба даст оварда мешавад
        // > амалиёт пас аз партофтани истинод (ҳама гуна дастрасӣ ба объект
        // > ба воситаи ин истинод, бешубҳа, пеш аз он рух дода буд), ва
        // > "acquire" амалиёт пеш аз нест кардани объект.
        //
        // Аз ҷумла, дар ҳоле, ки мундариҷаи Arc одатан тағирнопазир аст, имкон дорад, ки интерьерҳо ба чизе монанди Mutex нависанд<T>.
        // Азбаски Мутекс ҳангоми нобуд шуданаш ба даст оварда намешавад, мо наметавонем ба мантиқи ҳамоҳангсозии он такя намоем, то навиштаҳои дар риштаи А навишташударо ба деструктори дар риштаи B коршаванда намоён созем.
        //
        //
        // Инчунин қайд кунед, ки девори Acquire дар инҷо эҳтимолан бо бори Acquire иваз карда шавад, ки метавонад дар ҳолатҳои пурихтилоф иҷрои онро беҳтар кунад.[2] нигаред.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Кӯшиши паст кардани `Arc<dyn Any + Send + Sync>` ба намуди мушаххас.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Сохтани `Weak<T>` нав, бе тақсим кардани ягон хотира.
    /// Даъват кардани [`upgrade`] дар арзиши баргардонидан ҳамеша [`None`] медиҳад.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Ёрнавис барои расонидани дастрасӣ ба истинод бидуни ҳеҷ гуна изҳорот дар бораи майдони маълумот ҳисоб кунед.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Нишондиҳандаи хомро ба объекти `T`, ки бо ин `Weak<T>` ишора шудааст, бармегардонад.
    ///
    /// Нишондиҳанда танҳо дар сурате эътибор дорад, ки агар баъзе истинодҳои қавӣ вуҷуд дошта бошанд.
    /// Нишондиҳанда метавонад овезон, номувофиқ ё ҳатто [`null`] бошад, дар акси ҳол.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ҳарду ба як ашё ишора мекунанд
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Қавӣ дар ин ҷо онро зинда нигоҳ медорад, бинобар ин мо метавонем ба объект дастрасӣ пайдо кунем.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Аммо дигар не.
    /// // Мо метавонем weak.as_ptr() кор кунем, аммо дастрасӣ ба нишондиҳанда ба рафтори номуайян оварда мерасонад.
    /// // assert_eq! ("салом", хатарнок {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Агар нишоннамо овезон бошад, мо посбонро мустақиман бармегардонем.
            // Ин суроғаи бори эътибор буда наметавонад, зеро бори ҳадди аққал ба андозаи ArcInner (usize) мувофиқат мекунад.
            ptr as *const T
        } else {
            // БЕХАТАР: : агар is_dangling false баргардад, пас нишоннамо мустақим аст.
            // Маблағи пардохт метавонад дар ин лаҳза коҳиш ёбад ва мо бояд собитро нигоҳ дорем, бинобар ин манипулясияи хомро истифода баред.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>`-ро истеъмол мекунад ва онро ба нишондиҳандаи хом табдил медиҳад.
    ///
    /// Ин нишондиҳандаи сустро ба нишондиҳандаи хом табдил медиҳад ва ҳамзамон моликияти як истиноди сустро нигоҳ медорад (ҳисоби заиф бо ин амал тағир дода намешавад).
    /// Онро бо [`from_raw`] ба `Weak<T>` баргардонидан мумкин аст.
    ///
    /// Худи ҳамон маҳдудиятҳои дастрасӣ ба ҳадафи нишоннамо бо [`as_ptr`] амал мекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Нишондиҳандаи хомро, ки қаблан [`into_raw`] сохта буд, ба `Weak<T>` бармегардонад.
    ///
    /// Ин метавонад барои ба даст овардани истиноди қавӣ (бо занг задан ба [`upgrade`] дертар) ё тақсим кардани ҳисоби заиф бо тарки `Weak<T>` истифода шавад.
    ///
    /// Он моликияти як истиноди заифро мегирад (ба истиснои нишондиҳандаҳое, ки [`new`] сохтаанд, зеро инҳо чизе надоранд; метод то ҳол дар онҳо кор мекунад).
    ///
    /// # Safety
    ///
    /// Нишондиҳанда бояд аз [`into_raw`] сарчашма гирифта бошад ва то ҳол бояд истиноди сусти эҳтимолии худро дошта бошад.
    ///
    /// Иҷозат дода шудааст, ки шумораи пурзӯр дар вақти даъват ба 0 бошад.
    /// Бо вуҷуди ин, ин моликияти як истиноди заифро, ки ҳоло ҳамчун нишоннамои хом муаррифӣ шудааст, ба худ мегирад (ҳисоби заиф бо ин амал тағир дода намешавад) ва аз ин рӯ он бояд бо як даъвати қаблӣ ба [`into_raw`] ҷуфт карда шавад.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Ҳисоби охирини заифро коҳиш диҳед.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Барои контекст дар бораи чӣ гуна ба даст овардани нишоннамои вуруд ба Weak::as_ptr нигаред.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ин як сусти сустист.
            ptr as *mut ArcInner<T>
        } else {
            // Дар акси ҳол, мо кафолат медиҳем, ки нишондиҳанда аз як сусти нолозим баромадааст.
            // БЕХАТАР: : data_offset барои занг задан бехатар аст, зеро ptr ба T воқеӣ (эҳтимолан афтода) муроҷиат мекунад.
            let offset = unsafe { data_offset(ptr) };
            // Ҳамин тариқ, мо ҷубронро бармегардонем, то тамоми RcBox гирем.
            // БЕХАТАР: : нишоннамо аз заиф сарчашма мегирад, бинобар ин ин ҷуброн бехатар аст.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // БЕХАТАР: : мо ҳоло нишоннамои аслии Заифро барқарор кардем, пас метавонем Заифҳоро эҷод кунем.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Кӯшишҳои баланд бардоштани нишоннамои `Weak` ба [`Arc`], ба таъхир афтодани арзиши ботиниро дар сурати муваффақ шудан.
    ///
    ///
    /// [`None`]-ро бармегардонад, агар арзиши дохилӣ аз он пас афтода бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ҳама нишондиҳандаҳои пурқувватро нест кунед.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Мо як ҳалқаи CAS-ро барои афзоиши шумори қавӣ ба ҷои fetch_add истифода мебарем, зеро ин функсия ҳеҷ гоҳ ҳисобкунии истинодро аз сифр ба як набарорад.
        //
        //
        let inner = self.inner()?;

        // Боркунии ором, зеро ҳама гуна навиштаҳои 0, ки мо онро мушоҳида карда метавонем, майдонро дар ҳолати доимии сифр мегузорад (аз ин рӯ хониши "stale" 0 хуб аст) ва арзиши дигар тавассути CAS дар поён тасдиқ карда мешавад.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Шарҳҳоро дар `Arc::clone` бинед, ки чаро мо ин корро мекунем (барои `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed барои парвандаи нокомӣ хуб аст, зеро мо дар бораи давлати нав ҳеҷ интизор надорем.
            // Харидорӣ барои ҳамоҳангсозии парвандаи муваффақият бо `Arc::new_cyclic` зарур аст, вақте ки арзиши дохилиро пас аз эҷод кардани истинодҳои `Weak` оғоз кардан мумкин аст.
            // Дар ин ҳолат, мо интизорем, ки арзиши пурраи оғозшударо риоя кунем.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // дар боло санҷида шудааст
                Err(old) => n = old,
            }
        }
    }

    /// Шумораи нишондиҳандаҳои пурқуввати (`Arc`)-ро, ки ба ин тақсимот ишора мекунанд, меорад.
    ///
    /// Агар `self` бо истифодаи [`Weak::new`] сохта шуда бошад, ин 0 бармегардад.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Миқдори нишондиҳандаҳои `Weak`-ро, ки ба ин тақсимот ишора мекунанд, тахмин меорад.
    ///
    /// Агар `self` бо истифода аз [`Weak::new`] сохта шуда бошад, ё нишондиҳандаҳои қавии боқимонда набошанд, ин 0 бармегардад.
    ///
    /// # Accuracy
    ///
    /// Бо сабаби тафсилоти татбиқ, арзиши баргардондашуда метавонад ба 1 дар ҳарду самт хомӯш карда шавад, вақте ки риштаҳои дигар ҳама гуна Arc`s ё`Weak`-ро ба ҳамон тақсимот ишора мекунанд.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Азбаски мо мушоҳида кардем, ки пас аз хондани ҳисобҳои заиф ҳадди аққал як нишоннамои қавӣ мавҷуд аст, мо медонем, ки истиноди номуайяни заиф (ҳангоме ки ягон истиноди қавӣ мавҷуд аст) вақте ки мо шумораи заифро мушоҳида кардем, дар атрофи он буд ва аз ин рӯ метавон онро ба таври бехатар коҳиш дод.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Вақте ки нишоннамо овезон аст ва `ArcInner` ҷудошуда вуҷуд надорад, бармегардад `None`, (яъне вақте ки ин `Weak` аз ҷониби `Weak::new` сохта шудааст).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Мо эҳтиёткор ҳастем, ки истинодеро дар бар гирад, ки майдони "data"-ро фароҳам орад *, зеро майдон метавонад ҳамзамон мутатсия шавад (масалан, агар `Arc` охирин партофта шавад, майдони маълумот дар ҷои худ партофта мешавад).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true`-ро бармегардонад, агар ҳардуи "Заиф" ба тақсимоти якхела ишора кунанд (ба [`ptr::eq`] монанд), ё агар ҳарду ба ягон ҷудошавӣ ишора накунанд (зеро онҳо бо `Weak::new()`) сохта шудаанд).
    ///
    ///
    /// # Notes
    ///
    /// Азбаски ин нишондиҳандаҳоро муқоиса мекунад, ин маънои онро дорад, ки `Weak::new()` бо ҳам баробар хоҳанд шуд, гарчанде ки онҳо ба ягон тақсимот ишора намекунанд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Муқоисаи `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Клони нишоннамои `Weak` месозад, ки ба ҳамон тақсимот ишора мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Шарҳҳоро дар Arc::clone() бинед, ки чаро ин ором шудааст.
        // Ин метавонад як fetch_add-ро истифода барад (беэътиноӣ ба қулф), зеро ҳисоби заиф танҳо дар он ҷое баста мешавад, ки * ягон нишондиҳандаи заиф мавҷуд набошад.
        //
        // (Пас, мо наметавонем ин рамзро дар ин ҳолат иҷро кунем).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Шарҳҳоро дар Arc::clone() бинед, ки чаро мо ин корро мекунем (барои mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Сохтани `Weak<T>` нав, бе тақсим кардани хотира.
    /// Даъват кардани [`upgrade`] дар арзиши баргардонидан ҳамеша [`None`] медиҳад.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Нишондиҳандаи `Weak`-ро афтондааст.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ҳеҷ чизро чоп намекунад
    /// drop(foo);        // "dropped!" чоп мекунад
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Агар мо фаҳмем, ки мо охирин нишоннамои заиф будем, пас вақти он барои тақсимоти маълумот пурра аст.Баҳсро дар Arc::drop() дар бораи фармоишҳои хотира бубинед
        //
        // Ҳолати баста дар инҷоро тафтиш кардан лозим нест, зеро ҳисоби сустро танҳо дар ҳолате баста шудан мумкин аст, ки дақиқ як refи суст вуҷуд дошта бошад, яъне тарки он метавонад баъдан ON-ро дар он refи сусти боқимонда иҷро кунад, ки он танҳо пас аз баровардани блок рух дода метавонад.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Мо ин ихтисосро дар ин ҷо анҷом медиҳем, на ҳамчун оптимизатсияи умумӣ дар `&T`, зеро дар акси ҳол он ба ҳама санҷишҳои баробарӣ дар refs хароҷот илова мекунад.
/// Мо тахмин мезанем, ки "Arc`s" барои нигоҳ доштани арзишҳои калон истифода мешаванд, ки суст клон мешаванд, аммо барои тафтиши баробарӣ вазнинанд ва ин хароҷотро ба осонӣ пардохт мекунад.
///
/// Инчунин эҳтимол дорад, ки ду клони `Arc`, ки ба ҳамон арзиш ишора мекунанд, нисбат ба ду "T".
///
/// Мо инро танҳо вақте иҷро карда метавонем, ки `T: Eq` ҳамчун `PartialEq` дидаву дониста ғайри қобили ислоҳ бошад.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Баробарӣ барои ду 'Arc`.
    ///
    /// Ду 'Arc` баробаранд, агар қиматҳои дохилии онҳо баробар бошанд, ҳатто агар онҳо дар тақсимоти гуногун нигоҳ дошта шаванд.
    ///
    /// Агар `T` инчунин `Eq`-ро татбиқ кунад (инъикоскунандаи баробарӣ), ду 'Arc`, ки ба ҳамон тақсимот ишора мекунанд, ҳамеша баробаранд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Нобаробарӣ барои ду 'Arc`.
    ///
    /// Ду 'Arc` нобаробаранд, агар қиматҳои дохилии онҳо нобаробар бошанд.
    ///
    /// Агар `T` инчунин `Eq`-ро татбиқ кунад (инъикоскунандаи баробарии онро дар назар дорад), ду 'Arc`, ки ба ҳамон қимат ишора мекунанд, ҳеҷ гоҳ нобаробар нестанд.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Муқоисаи қисман барои ду "Arc`".
    ///
    /// Ҳарду бо занг задан ба `partial_cmp()` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Камтар аз муқоиса барои ду "Arc`".
    ///
    /// Ҳарду бо занг задан ба `<` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Муқоисаи ду "Arc`" камтар ё баробар ".
    ///
    /// Ҳарду бо занг задан ба `<=` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Бузургтар аз муқоиса барои ду "Arc`".
    ///
    /// Ҳарду бо занг задан ба `>` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Муқоисаи ду "Arc` аз"зиёд ё баробар".
    ///
    /// Ҳарду бо занг задан ба `>=` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Муқоиса барои ду Arc`.
    ///
    /// Ҳарду бо занг задан ба `cmp()` дар арзишҳои дохилии худ муқоиса карда мешаванд.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `Arc<T>` навро бо арзиши `Default` барои `T` месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Як буридаи ҳисобшудаи истинодро ҷудо кунед ва онро бо клонидани ҷузъҳои "v" пур кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// `str`-ро бо истинод ҳисоб кунед ва `v`-ро ба он нусхабардорӣ кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// `str`-ро бо истинод ҳисоб кунед ва `v`-ро ба он нусхабардорӣ кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Объекти қуттиро ба тақсимоти нави ҳисобшуда интиқол диҳед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Буридаи ҳисобшудаи истинодро ҷудо кунед ва ҷузъҳои "v"-ро ба он дохил кунед.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Ба Vec иҷозат диҳед, ки хотираи худро озод кунад, аммо мундариҷаро нобуд накунад
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Ҳар як элементро дар `Iterator` мегирад ва онро ба `Arc<[T]>` ҷамъ мекунад.
    ///
    /// # Хусусиятҳои иҷрои
    ///
    /// ## Парвандаи умумӣ
    ///
    /// Дар ҳолати умумӣ, ҷамъоварӣ ба `Arc<[T]>` бо роҳи ҷамъоварӣ ба `Vec<T>` анҷом дода мешавад.Яъне, ҳангоми навиштани инҳо:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ин тавре рафтор мекунад, ки гӯё навиштаем:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Маҷмӯи якуми тақсимот дар ин ҷо рух медиҳад.
    ///     .into(); // Тақсимоти дуюм барои `Arc<[T]>` дар ин ҷо рух медиҳад.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Ин барои сохтани `Vec<T>` чанд маротиба лозим аст ва он гоҳ як маротиба барои табдил додани `Vec<T>` ба `Arc<[T]>` ҷудо мекунад.
    ///
    ///
    /// ## Итераторҳои дарозии маълум
    ///
    /// Вақте ки `Iterator`-и шумо `TrustedLen`-ро амалӣ мекунад ва андозаи дақиқ дорад, барои `Arc<[T]>` тақсимоти ягона дода мешавад.Барои намуна:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Дар ин ҷо танҳо як тақсимоти ягона рух медиҳад.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Ихтисоси trait, ки барои ҷамъоварӣ ба `Arc<[T]>` истифода мешавад.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ин барои як iterator `TrustedLen` аст.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // БЕХАТАР We: Мо бояд кафолат диҳем, ки даврзананда дарозии дақиқ дорад ва мо дорем.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Бозгаштан ба татбиқи муқаррарӣ.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Дар зарфи `ArcInner` ҷубронро барои бори паси нишоннамо гиред.
///
/// # Safety
///
/// Нишондиҳанда бояд ба мисоли қаблан дурусти T ишора кунад (ва метамаълумотҳои дуруст дошта бошад), аммо T-ро партофтан иҷозат дода мешавад.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Арзиши андозаи номуайянро то охири ArcInner мутобиқ кунед.
    // Азбаски RcBox repr(C) аст, он ҳамеша охирин майдон дар хотира хоҳад буд.
    // БЕХАТАР: : азбаски ягона намудҳои номатлуб имконпазиранд, иловаро, объектҳои trait,
    // ва намудҳои экстерн, талаботи бехатарии вуруд дар ҳоли ҳозир барои қонеъ кардани талаботи align_of_val_raw кифоя аст;ин ҷузъиёти татбиқи забон аст, ки берун аз std ба он эътимод кардан мумкин нест.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}