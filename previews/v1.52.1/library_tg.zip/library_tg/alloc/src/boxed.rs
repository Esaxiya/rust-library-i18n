//! Намуди нишоннамо барои тақсим кардани теппа.
//!
//! [`Box<T>`], ба таври тасодуфӣ ҳамчун 'box' номида мешавад, соддатарин шакли тақсимоти теппаҳоро дар Rust таъмин мекунад.Қуттиҳо моликияти ин тақсимотро фароҳам меоранд ва вақте ки онҳо аз доираи амал берун мераванд, мундариҷаи онро партоянд.Қуттиҳо инчунин кафолат медиҳанд, ки онҳо ҳеҷ гоҳ беш аз `isize::MAX` байт ҷудо намекунанд.
//!
//! # Examples
//!
//! Арзишро аз стака ба теппа бо роҳи эҷоди [`Box`] интиқол диҳед:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Арзишро аз [`Box`] ба стака тавассути [dereferencing] интиқол диҳед:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Таъсиси сохтори маълумотҳои рекурсивӣ:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Ин чоп мекунад `Cons (1, Cons(2, Nil))`.
//!
//! Сохторҳои рекурсивӣ бояд қуттӣ карда шаванд, зеро агар таърифи `Cons` чунин менамуд:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Ин кор нахоҳад кард.Зеро андозаи `List` аз он вобаста аст, ки дар рӯйхат чӣ қадар элемент мавҷуд аст ва аз ин рӯ мо намедонем, ки барои `Cons` чӣ қадар хотира ҷудо кунем.Бо ҷорӣ кардани [`Box<T>`], ки андозаи муайян дорад, мо медонем, ки `Cons` бояд чӣ қадар калон бошад.
//!
//! # Тарҳбандии хотира
//!
//! Барои арзишҳои андозаи нулӣ, [`Box`] ҷудокунандаи [`Global`]-ро барои тақсимоти худ истифода мебарад.Табдил додани ҳарду роҳи байни [`Box`] ва нишоннамои хом, ки бо ҷудокунандаи [`Global`] ҷудо карда шудааст, эътибор дорад, бо назардошти он, ки [`Layout`] бо ҷудокунанда барои намуд дуруст аст.
//!
//! Дақиқтараш, `value:*mut T`, ки бо тақсимкунандаи [`Global`] бо `Layout::for_value(&* value)` ҷудо шудааст, метавонад бо истифода аз [`Box::<T>::from_raw(value)`] ба қуттӣ табдил дода шавад.
//! Ва баръакс, хотираи пуштибони `value:*mut T`, ки аз [`Box::<T>::into_raw`] ба даст оварда шудааст, метавонад бо истифодаи [`Global`] ҷудокунанда бо [`Layout::for_value(&* value)`] тақсим карда шавад.
//!
//! Барои арзишҳои андозаи сифр, нишоннамои `Box` ҳанӯз барои хондан ва навиштан бояд [valid] бошад ва ба дараҷаи кофӣ ҳамоҳанг карда шавад.
//! Аз ҷумла, ба нишондиҳандаи хом андохтани ҳар як адади бутуни нулӣ мутобиқшуда нишондиҳандаи дуруст меорад, аммо нишондиҳандае, ки ба хотираи қаблан ҷудошуда ишора мекунад, ки аз он замон озод шудааст, эътибор надорад.
//! Усули тавсияшудаи сохтани Box ба ZST, агар `Box::new`-ро истифода бурдан ғайриимкон аст, истифодаи [`ptr::NonNull::dangling`] аст.
//!
//! То он даме, ки `T: Sized`, як `Box<T>` кафолат дода мешавад, ки ҳамчун нишоннамои ягона муаррифӣ мешавад ва инчунин ABI бо нишондиҳандаҳои C мувофиқ аст (яъне навъи C `T*`).
//! Ин маънои онро дорад, ки агар шумо функсияҳои "C" Rust-и экстернӣ дошта бошед, ки аз C даъват карда мешаванд, шумо метавонед он функсияҳои Rust-ро бо истифодаи намудҳои `Box<T>` муайян кунед ва `T*`-ро ҳамчун намуди мувофиқ дар канори C истифода баред.
//! Ҳамчун мисол, ин сарлавҳаи C-ро дида мебароем, ки вазифаҳоеро фароҳам меорад, ки ягон намуди арзиши `Foo` эҷод мекунанд ва нобуд мекунанд:
//!
//! ```c
//! /* Сарлавҳаи C */
//!
//! /* Моликиятро ба зангзада бармегардонад */
//! struct Foo* foo_new(void);
//!
//! /* Моликиятро аз шахси даъваткунанда мегирад;вақте ки бо NULL даъват карда мешавад, ғайриимкон аст */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Ин ду вазифаро дар Rust ба тариқи зайл татбиқ кардан мумкин аст.Дар ин ҷо, навъи `struct Foo*` аз C ба `Box<Foo>` тарҷума шудааст, ки маҳдудиятҳои моликиятро фаро мегирад.
//! Инчунин қайд кунед, ки далели ночиз ба `foo_delete` дар Rust ҳамчун `Option<Box<Foo>>` муаррифӣ шудааст, зеро `Box<Foo>` наметавонад ночиз бошад.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Гарчанде ки `Box<T>` ҳамон нишондиҳанда ва C ABI-ро бо нишондиҳандаи C дорад, ин маънои онро надорад, ки шумо метавонед `T*` ихтиёриро ба `Box<T>` табдил диҳед ва интизори кор шудани чизе бошед.
//! `Box<T>` арзишҳо ҳамеша пурра мутобиқ карда мешаванд, нишондиҳандаҳо бо сифр.Гузашта аз ин, деструктори `Box<T>` кӯшиш мекунад, ки арзиши худро бо ҷудокунандаи глобалӣ озод кунад.Умуман, таҷрибаи беҳтарини истифодаи `Box<T>` танҳо барои нишоннамоҳое мебошад, ки аз ҷудокунандаи глобалӣ сарчашма гирифтаанд.
//!
//! **Муҳим.** Ҳадди аққал, дар айни замон, шумо бояд аз истифодаи намудҳои `Box<T>` барои функсияҳои дар C муайяншуда, вале аз Rust истинод бигиред.Дар ин ҳолатҳо, шумо бояд бевосита намудҳои C-ро то ҳадди имкон инъикос кунед.
//! Истифодаи намудҳое, ба монанди `Box<T>`, ки таърифи C танҳо `T*`-ро истифода мебарад, метавонад ба рафтори номуайян оварда расонад, ки дар [rust-lang/unsafe-code-guidelines#198][ucg#198] тасвир шудааст.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Намуди нишоннамо барои тақсим кардани теппа.
///
/// Барои маълумоти бештар ба [module-level documentation](../../std/boxed/index.html) нигаред.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Хотираро дар теппа ҷудо мекунад ва сипас ба он `x` мегузорад.
    ///
    /// Ин воқеан ҷудо намекунад, агар `T` андозаи сифр дошта бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Қуттии навро бо мундариҷаи номаълум месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `Box`-и навро бо мундариҷаи номаълум сохта, бо хотира бо байтҳои `0` месозад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// `Pin<Box<T>>` нав месозад.
    /// Агар `T` `Unpin`-ро татбиқ накунад, он гоҳ `x` дар хотира пинҳон хоҳад шуд ва ҳаракат кардан ғайриимкон аст.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Хотираро дар теппа ҷудо мекунад ва баъд `x`-ро ба он ҷойгир мекунад, агар хато ҷудо нашавад, хато бармегардонад
    ///
    ///
    /// Ин воқеан ҷудо намекунад, агар `T` андозаи сифр дошта бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Қуттии наверо бо мундариҷаи номаълум дар теппа месозад ва хаторо бармегардонад, агар ҷудокунӣ ноком шавад
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Сохтани `Box` нав бо мундариҷаи номаълум, бо хотира бо байтҳои `0` дар теппа пур карда мешавад
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Хотирро дар ҷудокунандаи додашуда тақсим мекунад ва сипас ба он `x` мегузорад.
    ///
    /// Ин воқеан ҷудо намекунад, агар `T` андозаи сифр дошта бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Хотирро дар ҷудокунандаи додашуда тақсим мекунад ва пас `x`-ро ба он ҷойгир мекунад, агар хато ҷудо нашавад, хато бармегардонад
    ///
    ///
    /// Ин воқеан ҷудо намекунад, агар `T` андозаи сифр дошта бошад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Қуттии навро бо мундариҷаи номаълум дар ҷудокунандаи пешбинишуда месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Мувофиқатро аз unwrap_or_else бартарӣ диҳед, зеро пӯшида баъзан ғайримуқаррарӣ нест.
        // Ин андозаи кодро калонтар мекунад.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Қуттиҳои навро бо мундариҷаи ношинос дар ҷудокунандаи пешбинишуда месозад ва хатогиро бармегардонад, агар тақсимот ноком шавад
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Сохтани `Box` нав бо мундариҷаи номаълум, бо хотира бо байтҳои `0` дар ҷудокунандаи пешбинишуда пур карда мешавад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Мувофиқатро аз unwrap_or_else бартарӣ диҳед, зеро пӯшида баъзан ғайримуқаррарӣ нест.
        // Ин андозаи кодро калонтар мекунад.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Сохтани `Box` нав бо мундариҷаи номаълум, бо хотира бо байтҳои `0` дар ҷудокунандаи пешбинишуда пур карда мешавад, агар хато ҷудо нашавад, хаторо бармегардонад,
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// `Pin<Box<T, A>>` нав месозад.
    /// Агар `T` `Unpin`-ро татбиқ накунад, он гоҳ `x` дар хотира пинҳон хоҳад шуд ва ҳаракат кардан ғайриимкон аст.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>`-ро ба `Box<[T]>` табдил медиҳад
    ///
    /// Ин табдилдиҳӣ дар теппа ҷудо намешавад ва дар ҷои худ ба амал меояд.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box`-ро истеъмол мекунад, арзиши парпечро бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Як буридаи нави қуттӣ бо мундариҷаи номаълум месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Як буридаи нави қуттии дорои мундариҷаи номаълумро месозад, ки хотира бо байтҳои `0` пур карда мешавад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Як буридаи нави қуттиеро бо мундариҷаи номатлуб дар ҷудокунандаи пешбинишуда месозад.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Як буридаи нави қуттиеро бо мундариҷаи номаълум дар ҷудокунандаи пешбинишуда месозад, ва хотираи он бо байтҳои `0` пур карда мешавад.
    ///
    ///
    /// Барои мисолҳои истифодаи дуруст ва нодурусти ин усул ба [`MaybeUninit::zeroed`][zeroed] нигаред.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Ба `Box<T, A>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], кафолат додани он, ки арзиш воқеан дар ҳолати ибтидоӣ аст, ба шахси зангзада вобаста аст.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Ба `Box<[T], A>` мубаддал мешавад.
    ///
    /// # Safety
    ///
    /// Тавре ки бо [`MaybeUninit::assume_init`], занг задан аст, то кафолат диҳад, ки арзишҳо воқеан дар ҳолати ибтидоӣ қарор доранд.
    ///
    /// Вақте ки мундариҷа ҳанӯз пурра ба кор дароварда нашудааст, ин занг задан боиси рафтори фаврии номуайян мегардад.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Ибтидоии ба таъхир гузошташуда:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Қуттиеро аз нишоннамои хом месозад.
    ///
    /// Пас аз даъват кардани ин функсия, нишоннамои хом ба `Box` дар натиҷа тааллуқ дорад.
    /// Махсусан, деструктори `Box` ба деструктори `T` занг мезанад ва хотираи ҷудошударо озод мекунад.
    /// Барои бехатарии он, хотира бояд мувофиқи [memory layout], ки `Box` истифода мекунад, ҷудо карда шуда бошад.
    ///
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро истифодаи нодуруст метавонад боиси мушкилоти хотира гардад.
    /// Масалан, дар сурате, ки функсия ду маротиба дар як нишоннамои хом ду маротиба даъват карда шавад, метавонад дучанди озод ба амал ояд.
    ///
    /// Шароити бехатарӣ дар боби [memory layout] тасвир шудааст.
    ///
    /// # Examples
    ///
    /// `Box`-ро, ки қаблан бо истифода аз [`Box::into_raw`] ба нишоннамои хом табдил дода шуда буд, эҷод кунед:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Бо истифодаи тақсимоти глобалӣ дастӣ `Box`-ро аз сифр эҷод кунед:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Умуман, .write талаб карда мешавад, ки аз кӯшиши вайрон кардани мундариҷаи қаблии `ptr` пешгирӣ карда шавад, гарчанде ки барои ин мисоли оддӣ `*ptr = 5` низ кор мекард.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Дар нишондиҳандаи хом дар ҷудокунандаи додашуда қуттӣ месозад.
    ///
    /// Пас аз даъват кардани ин функсия, нишоннамои хом ба `Box` дар натиҷа тааллуқ дорад.
    /// Махсусан, деструктори `Box` ба деструктори `T` занг мезанад ва хотираи ҷудошударо озод мекунад.
    /// Барои бехатарии он, хотира бояд мувофиқи [memory layout], ки `Box` истифода мекунад, ҷудо карда шуда бошад.
    ///
    ///
    /// # Safety
    ///
    /// Ин вазифа хатарнок аст, зеро истифодаи нодуруст метавонад боиси мушкилоти хотира гардад.
    /// Масалан, дар сурате, ки функсия ду маротиба дар як нишоннамои хом ду маротиба даъват карда шавад, метавонад дучанди озод ба амал ояд.
    ///
    /// # Examples
    ///
    /// `Box`-ро, ки қаблан бо истифода аз [`Box::into_raw_with_allocator`] ба нишоннамои хом табдил дода шуда буд, эҷод кунед:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Бо истифода аз тақсимоти система дастӣ `Box`-ро аз сифр эҷод кунед:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Умуман, .write талаб карда мешавад, ки аз кӯшиши вайрон кардани мундариҷаи қаблии `ptr` пешгирӣ карда шавад, гарчанде ки барои ин мисоли оддӣ `*ptr = 5` низ кор мекард.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box`-ро истеъмол мекунад, ва нишоннамои хоми парпечшударо бармегардонад.
    ///
    /// Нишондиҳанда дуруст ҳамҷоя ва ночиз хоҳад буд.
    ///
    /// Пас аз занг задан ба ин функсия, даъваткунанда барои хотираи қаблан аз ҷониби `Box` идорашаванда масъул аст.
    /// Аз ҷумла, даъваткунанда бояд `T`-ро дуруст нобуд кунад ва хотираро бо назардошти [memory layout], ки `Box` истифода мебарад, озод кунад.
    /// Роҳи осонтарини ин кор табдил додани нишоннамои хом ба `Box` бо функсияи [`Box::from_raw`] мебошад, ки ба деструктори `Box` иҷозати тоза карданро медиҳад.
    ///
    ///
    /// Note: ин функсияи алоқаманд аст, ки маънои онро дорад, ки шумо бояд онро ба ҷои `b.into_raw()` ҳамчун `Box::into_raw(b)` хонед.
    /// Ин барои он аст, ки ҳеҷ гуна ихтилоф бо усули навъи дохилӣ вуҷуд надошта бошад.
    ///
    /// # Examples
    /// Табдил додани нишоннамои хом ба `Box` бо [`Box::from_raw`] барои тозакунии автоматӣ:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Тозакунии дастӣ тавассути кушодани деструктори ва тақсим кардани хотира:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box`-ро истеъмол мекунад, нишондиҳандаи хоми парпечшуда ва ҷудокунандаро бармегардонад.
    ///
    /// Нишондиҳанда дуруст ҳамҷоя ва ночиз хоҳад буд.
    ///
    /// Пас аз занг задан ба ин функсия, даъваткунанда барои хотираи қаблан аз ҷониби `Box` идорашаванда масъул аст.
    /// Аз ҷумла, даъваткунанда бояд `T`-ро дуруст нобуд кунад ва хотираро бо назардошти [memory layout], ки `Box` истифода мебарад, озод кунад.
    /// Роҳи осонтарини ин кор табдил додани нишоннамои хом ба `Box` бо функсияи [`Box::from_raw_in`] мебошад, ки ба деструктори `Box` имкон медиҳад, ки тозакуниро анҷом диҳад.
    ///
    ///
    /// Note: ин функсияи алоқаманд аст, ки маънои онро дорад, ки шумо бояд онро ба ҷои `b.into_raw_with_allocator()` ҳамчун `Box::into_raw_with_allocator(b)` хонед.
    /// Ин барои он аст, ки ҳеҷ гуна ихтилоф бо усули навъи дохилӣ вуҷуд надошта бошад.
    ///
    /// # Examples
    /// Табдил додани нишоннамои хом ба `Box` бо [`Box::from_raw_in`] барои тозакунии автоматӣ:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Тозакунии дастӣ тавассути кушодани деструктори ва тақсим кардани хотира:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box ҳамчун "unique pointer" аз ҷониби Stroed Borrows эътироф карда мешавад, аммо дар дохили он ин нишондиҳандаи хом барои системаи навъи аст.
        // Табдил додани он ба нишоннамои хом ҳамчун "releasing" нишондиҳандаи беназир барои иҷозати дастрасии хоми тахаллус эътироф карда намешавад, аз ин рӯ ҳамаи усулҳои нишоннамои хом бояд аз `Box::leak` гузаранд.
        //
        // Табдил додан *ки* ба нишондиҳандаи хом рафтори дуруст мекунад.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Истинод ба ҷудосози аслиро бармегардонад.
    ///
    /// Note: ин функсияи алоқаманд аст, ки маънои онро дорад, ки шумо бояд онро ба ҷои `b.allocator()` ҳамчун `Box::allocator(&b)` хонед.
    /// Ин барои он аст, ки ҳеҷ гуна ихтилоф бо усули навъи дохилӣ вуҷуд надошта бошад.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box`-ро истеъмол мекунад ва ихроҷ мекунад, истиноди тағиршавандаро бармегардонад, `&'a mut T`.
    /// Дар хотир доред, ки навъи `T` бояд аз умри интихобкардаи `'a` умр ба сар барад.
    /// Агар ин навъи он танҳо истинодҳои статикӣ дошта бошад, ё умуман вуҷуд надошта бошад, пас ин метавонад `'static` интихоб карда шавад.
    ///
    /// Ин функсия асосан барои маълумоте муфид аст, ки дар тамоми ҳаёти боқимондаи барнома зиндагӣ мекунад.
    /// Партофтани истиноди баргашта боиси ихроҷи хотира мегардад.
    /// Агар ин қобили қабул набошад, истинод бояд аввал бо функсияи [`Box::from_raw`], ки `Box` истеҳсол мекунад, печонида шавад.
    ///
    /// Он гоҳ ин `Box`-ро партофтан мумкин аст, ки он `T`-ро дуруст нобуд мекунад ва хотираи ҷудошударо озод мекунад.
    ///
    /// Note: ин функсияи алоқаманд аст, ки маънои онро дорад, ки шумо бояд онро ба ҷои `b.leak()` ҳамчун `Box::leak(b)` хонед.
    /// Ин барои он аст, ки ҳеҷ гуна ихтилоф бо усули навъи дохилӣ вуҷуд надошта бошад.
    ///
    /// # Examples
    ///
    /// Истифодаи оддӣ:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Маълумоти беандоза:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>`-ро ба `Pin<Box<T>>` табдил медиҳад
    ///
    /// Ин табдилдиҳӣ дар теппа ҷудо намешавад ва дар ҷои худ ба амал меояд.
    ///
    /// Ин инчунин тавассути [`From`] дастрас аст.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Ҳангоми `T: !Unpin` интиқол додан ё иваз кардани дохили `Pin<Box<T>>` ғайриимкон аст, бинобар ин мустақиман бе ягон талаботи иловагӣ пинҳон кардан бехатар аст.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Ҳеҷ кор накунед, дар айни замон таркиш аз ҷониби компилятор иҷро карда мешавад.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// `Box<T>` месозад, бо арзиши `Default` барои T
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Қуттии навро бо `clone()` аз мундариҷаи ин қуттӣ бармегардонад.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Арзиш якхела аст
    /// assert_eq!(x, y);
    ///
    /// // Аммо онҳо ашёи беназиранд
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Хотираро пешакӣ ҷудо кунед, то ки арзиши мустақиман нависед.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Мундариҷаи манбаъро ба `self` бидуни эҷоди ҷудокунии нав нусхабардорӣ мекунад.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Арзиш якхела аст
    /// assert_eq!(x, y);
    ///
    /// // Ва ҳеҷ тақсимоте рух надод
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // ин нусхаи маълумотро месозад
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Табдил медиҳад намуди умумии `T` ба `Box<T>`
    ///
    /// Табдилдиҳӣ дар теппа ҷудо мешавад ва `t`-ро аз анбор ба он интиқол медиҳад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>`-ро ба `Pin<Box<T>>` табдил медиҳад
    ///
    /// Ин табдилдиҳӣ дар теппа ҷудо намешавад ва дар ҷои худ ба амал меояд.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]`-ро ба `Box<[T]>` табдил медиҳад
    ///
    /// Ин табдилдиҳӣ дар теппа ҷудо карда мешавад ва нусхаи `slice`-ро иҷро мекунад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &[u8] созед, ки барои сохтани Box <[u8]> истифода мешавад
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str`-ро ба `Box<str>` табдил медиҳад
    ///
    /// Ин табдилдиҳӣ дар теппа ҷудо карда мешавад ва нусхаи `s`-ро иҷро мекунад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>`-ро ба `Box<[u8]>` табдил медиҳад
    /// Ин табдилдиҳӣ дар теппа ҷудо намешавад ва дар ҷои худ ба амал меояд.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // Қуттӣ эҷод кунед<str>ки барои сохтани Box <[u8]> истифода мешавад
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &[u8] созед, ки барои сохтани Box <[u8]> истифода мешавад
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]`-ро ба `Box<[T]>` табдил медиҳад
    /// Ин табдилдиҳӣ массивро ба хотираи навтаъсис интиқол медиҳад.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Кӯшиши афтондани қуттӣ ба навъи бетонӣ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Кӯшиши афтондани қуттӣ ба навъи бетонӣ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Кӯшиши афтондани қуттӣ ба навъи бетонӣ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Берун кардани Uniq-и дарунӣ мустақиман аз қуттӣ ғайриимкон аст, ба ҷои ин мо онро ба * const мепартоем, ки Unique-ро тахаллус медиҳад
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Ихтисос барои I-ҳои андозае, ки ба ҷои пешфарз татбиқи I-и `last()`-ро истифода мебарад.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}