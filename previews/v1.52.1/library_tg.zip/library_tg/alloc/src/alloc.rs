//! API-ҳои тақсимоти хотира

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Ин рамзҳои ҷодугарӣ барои ҷудокунандаи глобалӣ мебошанд.rustc онҳоро барои занг задан ба `__rg_alloc` ва ғайра тавлид мекунад.
    // агар атрибути `#[global_allocator]` мавҷуд бошад (рамзи васеъкунандаи он атрибутро ин функсияҳоро тавлид мекунад) ё даъват кардани амалҳои пешфарз дар libstd (`__rdl_alloc` ва ғайра).
    //
    // дар `library/std/src/alloc.rs`) дар акси ҳол.
    // rustc fork аз LLVM инчунин ҳолатҳои махсуси ин номҳои функсияро доранд, то онҳоро мутаносибан `malloc`, `realloc` ва `free` оптимизатсия кунанд.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Ҷудокунандаи хотираи ҷаҳонӣ.
///
/// Ин намуд [`Allocator`] trait-ро тавассути фиристодани зангҳо ба ҷудокунандаи дар атрибути `#[global_allocator]` ба қайд гирифташуда иҷро мекунад, ё агар он бо нобаёнӣ `std` crate бошад.
///
///
/// Note: дар ҳоле, ки ин навъи ноустувор аст, функсияе, ки онро таъмин мекунад, тавассути [free functions in `alloc`](self#functions) дастрас аст.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Бо ҷудокунандаи глобалӣ хотира ҷудо кунед.
///
/// Ин функсия зангҳоро ба усули [`GlobalAlloc::alloc`]-и ҷудокунандаи ба қайд гирифташуда бо атрибути `#[global_allocator]`, агар мавҷуд бошад, ё бо нобаёнӣ `std` crate.
///
///
/// Ин функсия интизор меравад, ки ба манфиати усули `alloc` навъи [`Global`] ҳангоми устувор шудани он ва [`Allocator`] trait бекор карда шавад.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] нигаред.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Бо тақсимоти глобалӣ тақсим кардани хотира.
///
/// Ин функсия зангҳоро ба усули [`GlobalAlloc::dealloc`]-и ҷудокунандаи ба қайд гирифташуда бо атрибути `#[global_allocator]`, агар мавҷуд бошад, ё бо нобаёнӣ `std` crate.
///
///
/// Интизор меравад, ки ин функсия ба фоидаи усули `dealloc`-и навъи [`Global`], вақте ки он ва [`Allocator`] trait устувор мешаванд, коҳиш дода шаванд.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] нигаред.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Тақсимоти хотира бо ҷудокунандаи глобалӣ.
///
/// Ин функсия зангҳоро ба усули [`GlobalAlloc::realloc`]-и ҷудокунандаи ба қайд гирифташуда бо атрибути `#[global_allocator]`, агар мавҷуд бошад, ё бо нобаёнӣ `std` crate.
///
///
/// Интизор меравад, ки ин функсия ба фоидаи усули `realloc`-и навъи [`Global`], вақте ки он ва [`Allocator`] trait устувор мешаванд, коҳиш дода шаванд.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] нигаред.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Бо ҷудокунандаи глобалӣ хотираи бо сифр оғозшударо ҷудо кунед.
///
/// Ин функсия зангҳоро ба усули [`GlobalAlloc::alloc_zeroed`]-и ҷудокунандаи ба қайд гирифташуда бо атрибути `#[global_allocator]`, агар мавҷуд бошад, ё бо нобаёнӣ `std` crate.
///
///
/// Интизор меравад, ки ин функсия ба фоидаи усули `alloc_zeroed`-и навъи [`Global`], вақте ки он ва [`Allocator`] trait устувор мешаванд, коҳиш дода шаванд.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] нигаред.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // БЕХАТАР: : `layout` андозааш сифр аст,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // БЕХАТАР: : Ҳамон тавре ки `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // БЕХАТАР: : `new_size` нолӣ аст, зеро `old_size` аз `new_size` бузургтар ё баробар аст
            // тавре ки шароити бехатарӣ талаб мекунад.Шартҳои дигарро бояд шахси зангзада риоя кунад
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` эҳтимол `new_size >= old_layout.size()` ё чизи ба ин монандро месанҷад.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЕХАТАР: : зеро `new_layout.size()` бояд аз `old_size` зиёд ё баробар бошад,
            // ҳам тақсимоти кӯҳна ва ҳам нав барои хондан ва навиштан барои байтҳои `old_size` эътибор доранд.
            // Инчунин, азбаски тақсимоти кӯҳна ҳанӯз тақсим карда нашудааст, он наметавонад `new_ptr`-ро такрор кунад.
            // Ҳамин тариқ, занг ба `copy_nonoverlapping` бехатар аст.
            // Шартномаи бехатарӣ барои `dealloc` бояд аз ҷониби шахси зангзада риоя карда шавад.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // БЕХАТАР: : `layout` андозааш сифр аст,
            // шартҳои дигарро бояд шахси занг зоҳир кунад
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕХАТАР: : бояд ҳамаи шартҳоро шахси зангзада риоя кунад
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // БЕХАТАР: : бояд ҳамаи шартҳоро шахси зангзада риоя кунад
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // БЕХАТАР: : шартҳо бояд аз ҷониби шахси зангзада риоя карда шавад
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // БЕХАТАР: : `new_size` ғайри сифр аст.Шартҳои дигарро бояд шахси зангзада риоя кунад
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` эҳтимол `new_size <= old_layout.size()` ё чизи ба ин монандро месанҷад.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // БЕХАТАР: : зеро `new_size` бояд аз `old_layout.size()` хурд ё ба он баробар бошад,
            // ҳам тақсимоти кӯҳна ва ҳам нав барои хондан ва навиштан барои байтҳои `new_size` эътибор доранд.
            // Инчунин, азбаски тақсимоти кӯҳна ҳанӯз тақсим карда нашудааст, он наметавонад `new_ptr`-ро такрор кунад.
            // Ҳамин тариқ, занг ба `copy_nonoverlapping` бехатар аст.
            // Шартномаи бехатарӣ барои `dealloc` бояд аз ҷониби шахси зангзада риоя карда шавад.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Тақсимкунандаи нишондиҳандаҳои беназир.
// Ин вазифа набояд кушояд.Агар ин тавр шавад, codegen MIR кор намекунад.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Ин имзо бояд бо `Box` баробар бошад, вагарна ICE рух медиҳад.
// Вақте ки як параметри иловагӣ ба `Box` илова карда мешавад (ба монанди `A: Allocator`), ин бояд дар ин ҷо низ илова карда шавад.
// Масалан, агар `Box` ба `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` иваз карда шавад, ин функсия бояд ба `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` низ тағир дода шавад.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Муносибати хатогии тақсимот

extern "Rust" {
    // Ин рамзи ҷодугарӣ барои даъват кардани сарукоргари хатогии глобалӣ мебошад.
    // rustc онро тавлид мекунад, ки дар сурати мавҷуд будани `#[alloc_error_handler]` ба `__rg_oom` занг занад ё амалисозии пешфарзро дар зери (`__rdl_oom`), дар акси ҳол хонад.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Аборт дар хатои ҷудокунии хотира ё нокомии.
///
/// Зангирони API-ҳои тақсимоти хотира, ки мехоҳанд ҳисобро дар посух ба хатои ҷудокунӣ қатъ кунанд, тавсия дода мешавад, ки ин функсияро даъват кунанд, на ба таври мустақим аз `panic!` ва ё ба он монанд.
///
///
/// Рафтори пешфарзии ин функсия чоп кардани паём ба хатогии стандартӣ ва қатъ кардани раванд мебошад.
/// Онро бо [`set_alloc_error_hook`] ва [`take_alloc_error_hook`] иваз кардан мумкин аст.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Барои озмоиши `std::alloc::handle_alloc_error` мустақиман истифода бурдан мумкин аст.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // тавассути `__rust_alloc_error_handler` тавлидшуда даъват карда мешавад

    // агар `#[alloc_error_handler]` набошад
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // агар `#[alloc_error_handler]` бошад
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Клонҳоро ба хотираи қаблан ҷудошуда, uninitiized махсус гардонед.
/// `Box::clone` ва `Rc`/`Arc::make_mut` истифода мебаранд.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Ҷудо кардани *аввал* метавонад ба оптимизатор имкон диҳад, ки арзиши клондонидашударо дар ҷои худ эҷод карда, локалро гузарад ва ҳаракат кунад.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Мо ҳамеша метавонем дар ҷои худ нусхабардорӣ кунем, бе он ки арзиши маҳаллӣ дошта бошад.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}