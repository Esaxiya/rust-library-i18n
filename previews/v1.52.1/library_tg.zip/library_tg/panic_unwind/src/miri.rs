//! Зер кардани panics барои Мири.
use alloc::boxed::Box;
use core::any::Any;

// Намуди сарборӣ, ки муҳаррики Miri тавассути кушодани мо паҳн мекунад.
// Бояд андозаи нишоннамо бошад.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Функсияи extern, ки бо Miri пешниҳод шудааст, барои кушодан сар мекунад.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Маблағи фоидаоваре, ки мо ба `miri_start_panic` мегузарем, маҳз далели дар `cleanup` дар поён овардашуда хоҳад буд.
    // Ҳамин тавр, мо онро танҳо як бор ба сандуқ медарорем, то чизе ба андозаи нишоннамо гирем.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // `Box`-и аслиро барқарор кунед.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}