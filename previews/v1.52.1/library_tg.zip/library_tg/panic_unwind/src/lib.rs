//! Татбиқи panics тавассути кушодани стака
//!
//! Ин crate татбиқи panics дар Rust бо истифода аз механизми кушодани стеллажи "most native" платформа мебошад, ки барои он тартиб дода мешавад.
//! Ин аслан ба се сатил тақсим карда мешавад:
//!
//! 1. Ҳадафҳои MSVC SEH-ро дар файли `seh.rs` истифода мебаранд.
//! 2. Emscripten истисноҳои C++ -ро дар файли `emcc.rs` истифода мебарад.
//! 3. Ҳама ҳадафҳои дигар libunwind/libgcc-ро дар файли `gcc.rs` истифода мебаранд.
//!
//! Ҳуҷҷатҳои бештар дар бораи ҳар як татбиқро дар модули дахлдор пайдо кардан мумкин аст.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` бо Мири истифода нашудааст, бинобар ин ҳушдорҳоро хомӯш кунед.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Объектҳои оғозёбии вақти кории Rust аз ин аломатҳо вобастаанд, бинобар ин онҳоро дастрас намоед.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Ҳадафҳое, ки кушодани онҳоро дастгирӣ намекунанд.
        // - arch=wasm32
        // - os=none (ҳадафҳои "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Вақти кории Miri-ро истифода баред.
        // Мо бояд ҳамзамон вақти кории муқаррариро ба боло бор кунем, зеро rustc интизор аст, ки баъзе ҷойҳо аз он ҷо муайян карда мешаванд.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Вақти воқеии кориро истифода баред.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler дар libstd ҳангоми берун аз `catch_unwind` партофтани объекти panic даъват карда мешавад.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler дар libstd ҳангоми истиснои хориҷӣ даъват карда мешавад.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Нуқтаи вуруд барои истиснои истисно, танҳо вакилон ба татбиқи платформаи мушаххас.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}