#![feature(no_core)]
#![no_core]

// Барои дидани ин crate ба rustc-std-workpace-core нигаред.

// crate-ро тағир диҳед, то бо модули ҷудокунанда дар liballoc мухолифат накунед.
extern crate alloc as foo;

pub use foo::*;