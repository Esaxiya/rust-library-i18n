// rsbegin.o ва rsend.o ба ном "compiler runtime startup objects" мебошанд.
// Онҳо кодҳоеро дар бар мегиранд, ки барои дуруст оғоз кардани вақти кории тартибдиҳанда заруранд.
//
// Вақте ки тасвири иҷрошаванда ё диблӣ алоқаманд аст, ҳамаи рамзҳо ва китобхонаҳои корбар байни ин ду файли ашё "sandwiched" мебошанд, бинобар ин рамз ё маълумот аз rsbegin.o дар қисматҳои дахлдори тасвир аввал мешаванд, дар ҳоле ки рамзҳо ва маълумотҳо аз rsend.o охиринҳо мешаванд.
// Ин эффект метавонад барои ҷойгир кардани рамзҳо дар аввал ё охири қисм, инчунин гузоштани ҳама сарлавҳаҳо ва ё сарлавҳаҳои зарурӣ истифода шавад.
//
// Дар хотир доред, ки нуқтаи воқеии вуруди модул дар объекти оғозёбии вақти кории C ҷойгир аст (одатан `crtX.o` номида мешавад), ки пас аз бозгашти дубораи ҷузъҳои дигари вақти кор даъват карда мешавад (тавассути як бахши дигари тасвири махсус ба қайд гирифта шудааст).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Оғози фасли кушодани фрейми стекро қайд мекунад
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Фазои харошида барои баҳисобгирии дохилии беморон.
    // Ин ҳамчун `struct object` дар $ GCC/unwind-dw2-fde.h муайян карда шудааст.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Маълумоти кушодани реҷаи registration/deregistration.
    // Ҳуҷҷатҳои libpanic_unwind-ро бинед.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // дар бораи оғози модул маълумоти сабти номро сабт кунед
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // сабти ном дар бораи қатъ
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-мушаххаси бақайдгирии мунтазами init/uninit
    pub mod mingw_init {
        // Объектҳои оғозёбии MinGW (crt0.o/dllcrt0.o) конструкторони глобалиро дар бахшҳои .ctors ва .dtors дар оғоз ва баромадан даъват мекунанд.
        // Дар мавриди DLL, ин ҳангоми боркунӣ ва фаровардани DLL анҷом дода мешавад.
        //
        // Пайвасткунанда бахшҳоро ба навъҳо ҷудо мекунад, ки он зангҳои моро дар охири рӯйхат ҷойгир мекунад.
        // Азбаски конструкторҳо бо тартиби баръакс иҷро мешаванд, ин кафолат медиҳад, ки бозгашти мо аввалин ва охирин мебошад.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: бозгашти C оғозёбӣ
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Бозгашти қатъкунии C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}