use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Барои ба аннотацияҳои `#[assert_instr]` мо гуфтан истифода мешавад, ки ҳамаи интриникҳои симд барои санҷидани кодгенҳои онҳо дастрасанд, зеро баъзеҳо дар паси `-Ctarget-feature=+unimplemented-simd128` изофӣ истодаанд, ки ҳозир дар `#[target_feature]` ягон муодила надоранд.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}