`core::arch` - Асосҳои меъмории меъмории асосии китобхонаи Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Модули `core::arch` intrinsics-и вобаста ба меъмориро татбиқ мекунад (масалан, SIMD).

# Usage 

`core::arch` ҳамчун як қисми `libcore` дастрас аст ва он аз ҷониби `libstd` дубора содир карда мешавад.Истифодаи онро тавассути `core::arch` ё `std::arch` афзалтар аз ин crate.
Хусусиятҳои ноустувор аксар вақт дар Rust шабона тавассути `feature(stdsimd)` дастрасанд.

Истифодаи `core::arch` тавассути ин crate шабона Rust талаб мекунад ва он метавонад зуд-зуд вайрон шавад (ва мекунад).Ягона ҳолатҳое, ки шумо бояд истифодаи онро тавассути ин crate баррасӣ кунед:

* агар ба шумо лозим ояд, ки `core::arch`-ро худатон аз нав тартиб диҳед, масалан, бо хусусиятҳои махсуси мақсаднок, ки барои `libcore`/`libstd` фаъол нестанд.
Note: агар ба шумо лозим ояд, ки онро барои ҳадафи ғайристандартӣ дубора тартиб диҳед, лутфан истифодаи `xargo` ва тарҷумаи `libcore`/`libstd`-ро ба ҷои истифодаи ин crate афзалтар донед.
  
* истифодаи баъзе хусусиятҳое, ки ҳатто дар паси хусусиятҳои ноустувори Rust мавҷуд нестанд.Мо мекӯшем, ки инҳоро ҳадди аққал нигоҳ дорем.
Агар ба шумо баъзе аз ин хусусиятҳоро истифода кардан лозим ояд, лутфан масъаларо кушоед, то мо онҳоро дар шабонаи Rust ошкор кунем ва шумо метавонед онҳоро аз он ҷо истифода баред.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` пеш аз ҳама тибқи шартҳои ҳам литсензияи MIT ва ҳам иҷозатномаи Apache (Version 2.0) тақсим карда мешавад, ки қисматҳояш бо литсензияҳои гуногуни ба BSD монанд мебошанд.

Барои тафсилот ба LICENSE-APACHE ва LICENCE-MIT нигаред.

# Contribution

Агар шумо ба таври возеҳ изҳор накардед, ҳама гуна саҳмҳое, ки шумо барои дохил кардан ба `core_arch` аз ҷониби шумо, ки дар литсензияи Apache-2.0 муайян шудааст, қасдан пешниҳод кардаед, бидуни ҳеҷ гуна шарту шароити иловагӣ дугона литсензия карда мешаванд.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












