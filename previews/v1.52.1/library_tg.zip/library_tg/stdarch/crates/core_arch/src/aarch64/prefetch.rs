#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) нигаред.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Хати кэшро, ки дорои суроғаи `p` мебошад, бо истифода аз `rw` ва `locality`-и додашуда кашед.
///
/// `rw` бояд яке аз инҳо бошад:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): префетч ба хондан омода мешавад.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): префетч ба навиштан омода мешавад.
///
/// `locality` бояд яке аз инҳо бошад:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Ҷойивазкунӣ ё пешакии муваққатӣ, барои маълумоте, ки танҳо як маротиба истифода мешавад.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Ба кэши сатҳи 3 ворид шавед.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Ба кэши сатҳи 2 ворид шавед.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Ба кэши сатҳи 1 ворид шавед.
///
/// Дастурҳои хотираи пешакӣ ба системаи хотира сигнал медиҳанд, ки эҳтимолан дар суроғаи муайян дастрасӣ ба хотира дар наздикии future рух медиҳад.
/// Системаи хотира метавонад бо амалҳое амал кунад, ки ҳангоми ба вуҷуд омадани онҳо интизор меравад, ки дастрасии хотираро метезонанд, ба монанди пешакӣ бор кардани суроғаи муайяншуда ба як ё якчанд кэш.
///
/// Азбаски ин сигналҳо танҳо ишораҳо мебошанд, барои CPU мушаххас муносибат кардани ҳама ё ҳама дастурҳои пешакӣ ҳамчун NOP эътибор дорад.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Мо instrinsic `llvm.prefetch`-ро бо `cache type` =1 (кэши маълумот) истифода мебарем.
    // `rw` ва `strategy` ба параметрҳои функсия асос ёфтаанд.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}