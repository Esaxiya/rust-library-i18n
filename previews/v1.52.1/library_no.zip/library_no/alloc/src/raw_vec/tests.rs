use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Å skrive en test av integrasjon mellom tredjepartsallokatorer og `RawVec` er litt vanskelig fordi `RawVec` API ikke avslører feilbare tildelingsmetoder, så vi kan ikke sjekke hva som skjer når tildeleren er utmattet (utover å oppdage en panic).
    //
    //
    // I stedet sjekker dette bare at `RawVec`-metodene i det minste går gjennom Allocator API når den reserverer lagring.
    //
    //
    //
    //
    //

    // En dum tildeler som bruker en fast mengde drivstoff før tildelingsforsøk begynner å mislykkes.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (forårsaker en reallokering, og bruker dermed 50 + 150=200 enheter drivstoff)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // For det første tildeler `reserve` som `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 er mer enn det dobbelte av 7, så `reserve` skal fungere som `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 er mindre enn halvparten av 12, så `reserve` må vokse eksponentielt.
        // I skrivende stund er denne vekstfaktoren 2, så ny kapasitet er 24, men vekstfaktoren på 1.5 er også OK.
        //
        // Derav `>= 18` påstått.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}