#![stable(feature = "rust1", since = "1.0.0")]

//! Trådsikre pekere for referansetelling.
//!
//! Se [`Arc<T>`][Arc]-dokumentasjonen for mer informasjon.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// En myk grense for antall referanser som kan gjøres til en `Arc`.
///
/// Hvis du går over denne grensen, avbrytes programmet ditt (men ikke nødvendigvis) ved _exactly_ `MAX_REFCOUNT + 1`-referanser.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer støtter ikke minnegjerder.
// For å unngå falske positive rapporter i Arc/Weak-implementering, bruk atombelastninger for synkronisering i stedet.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// En trådsikker referanseteller.'Arc' står for 'Atomically Reference Counted'.
///
/// Typen `Arc<T>` gir delt eierskap av en verdi av typen `T`, tildelt i bunken.Å påkalle [`clone`][clone] på `Arc` produserer en ny `Arc`-forekomst, som peker på samme tildeling på bunken som kilden `Arc`, samtidig som referansen teller.
/// Når den siste `Arc`-pekeren til en gitt tildeling blir ødelagt, faller også verdien som er lagret i den tildelingen (ofte referert til som "inner value").
///
/// Delte referanser i Rust tillater ikke mutasjon som standard, og `Arc` er ikke noe unntak: du kan vanligvis ikke få en mutbar referanse til noe i en `Arc`.Hvis du trenger å mutere gjennom en `Arc`, kan du bruke [`Mutex`][mutex], [`RwLock`][rwlock] eller en av [`Atomic`][atomic]-typene.
///
/// ## Trådsikkerhet
///
/// I motsetning til [`Rc<T>`] bruker `Arc<T>` atomoperasjoner for referansetelling.Dette betyr at den er trådsikker.Ulempen er at atomoperasjoner er dyrere enn vanlig minnetilgang.Hvis du ikke deler referanse-tellede tildelinger mellom tråder, bør du vurdere å bruke [`Rc<T>`] for lavere overhead.
/// [`Rc<T>`] er en sikker standard, fordi kompilatoren vil fange ethvert forsøk på å sende en [`Rc<T>`] mellom tråder.
/// Imidlertid kan et bibliotek velge `Arc<T>` for å gi bibliotekforbrukere mer fleksibilitet.
///
/// `Arc<T>` vil implementere [`Send`] og [`Sync`] så lenge `T` implementerer [`Send`] og [`Sync`].
/// Hvorfor kan du ikke sette en ikke-trådsikker type `T` i en `Arc<T>` for å gjøre den trådsikker?Dette kan være litt kontraintuitivt i begynnelsen: Tross alt er ikke poenget med `Arc<T>` trådsikkerhet?Nøkkelen er denne: `Arc<T>` gjør det trådsikkert å ha flere eierskap av de samme dataene, men det gir ikke trådsikkerhet til dataene.
///
/// Vurder `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] er ikke [`Sync`], og hvis `Arc<T>` alltid var [`Send`], er `Arc <` [`RefCell<T>`]`>`ville være det også.
/// Men så hadde vi et problem:
/// [`RefCell<T>`] er ikke trådsikker;det holder rede på lånetellingen ved hjelp av ikke-atomiske operasjoner.
///
/// Til slutt betyr dette at du kanskje trenger å koble `Arc<T>` med en slags [`std::sync`]-type, vanligvis [`Mutex<T>`][mutex].
///
/// ## Brytesykluser med `Weak`
///
/// [`downgrade`][downgrade]-metoden kan brukes til å lage en ikke-eier [`Weak`]-peker.En [`Weak`]-peker kan være ["oppgradering"][oppgradering] d til en `Arc`, men denne vil returnere [`None`] hvis verdien som er lagret i tildelingen allerede er sluppet.
/// Med andre ord holder ikke `Weak`-pekere levende i tildelingen;de *holder imidlertid* tildelingen (backingbutikken for verdien) i live.
///
/// En syklus mellom `Arc`-pekere vil aldri bli fordelt.
/// Av denne grunn brukes [`Weak`] til å bryte sykluser.For eksempel kan et tre ha sterke `Arc`-pekere fra foreldrenoder til barn, og [`Weak`]-pekere fra barn tilbake til foreldrene.
///
/// # Kloningsreferanser
///
/// Å lage en ny referanse fra en eksisterende referanseteltet peker gjøres ved hjelp av `Clone` trait implementert for [`Arc<T>`][Arc] og [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De to syntaksen nedenfor er ekvivalente.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b og foo er alle buer som peker til samme minneplassering
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatisk referanser til `T` (via [`Deref`][deref] trait), slik at du kan ringe `T`s metoder på en verdi av typen `Arc<T>`.For å unngå navnekollisjon med `T`s metoder, er metodene til `Arc<T>` i seg selv tilknyttede funksjoner, kalt ved bruk av [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>implementeringer av traits som `Clone` kan også kalles ved bruk av fullstendig syntaks.
/// Noen foretrekker å bruke fullt kvalifisert syntaks, mens andre foretrekker å bruke metodesamtalsyntaks.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metodesamtalsyntaks
/// let arc2 = arc.clone();
/// // Fullt kvalifisert syntaks
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] gjør ikke autodereferanse til `T`, fordi den indre verdien allerede kan ha blitt tapt.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Deling av uforanderlige data mellom tråder:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Merk at vi **ikke** kjører disse testene her.
// windows-byggere blir veldig misfornøyde hvis en tråd overlever hovedtråden og deretter går ut samtidig (noe fastlåst), så vi unngår dette helt ved ikke å kjøre disse testene.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Deling av en muterbar [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Se [`rc` documentation][rc_examples] for flere eksempler på referansetelling generelt.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` er en versjon av [`Arc`] som inneholder en ikke-eier referanse til den administrerte tildelingen.
/// Du får tilgang til tildelingen ved å ringe [`upgrade`] på `Weak`-pekeren, som returnerer en [`Option`]`<`[`Arc ']`<T>> `.
///
/// Siden en `Weak`-referanse ikke teller med på eierskap, vil den ikke forhindre at verdien som er lagret i tildelingen blir droppet, og `Weak` i seg selv gir ingen garantier for at verdien fortsatt er til stede.
///
/// Dermed kan den returnere [`None`] når [`upgrade`] d.
/// Merk imidlertid at en `Weak`-referanse *forhindrer* allokering av selve tildelingen (backing-butikken).
///
/// En `Weak`-peker er nyttig for å holde en midlertidig referanse til tildelingen administrert av [`Arc`] uten å forhindre at den indre verdien faller.
/// Den brukes også til å forhindre sirkulære referanser mellom [`Arc`]-pekere, siden gjensidige eierreferanser aldri vil tillate at noen av [`Arc`] slippes.
/// For eksempel kan et tre ha sterke [`Arc`]-pekere fra foreldrenoder til barn, og `Weak`-pekere fra barn tilbake til foreldrene.
///
/// Den typiske måten å få tak i en `Weak`-peker er å ringe [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dette er en `NonNull` som muliggjør optimalisering av størrelsen på denne typen i enums, men det er ikke nødvendigvis en gyldig peker.
    //
    // `Weak::new` setter dette til `usize::MAX` slik at det ikke trenger å tildele plass på dyngen.
    // Det er ikke en verdi en ekte peker noen gang vil ha fordi RcBox har justering minst 2.
    // Dette er bare mulig når `T: Sized`;unsized `T` dingler aldri.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dette er repr(C) til future-bevis mot mulig feltbestilling, noe som vil forstyrre ellers sikker [into|from]_raw() av transmuterbare indre typer.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // verdien usize::MAX fungerer som en vaktpost for midlertidig "locking" muligheten til å oppgradere svake pekere eller nedgradere sterke;dette brukes for å unngå løp i `make_mut` og `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruerer en ny `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Start den svake pekeren som 1, som er den svake pekeren som holdes av alle de sterke pekerne (kinda), se std/rc.rs for mer info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruerer en ny `Arc<T>` ved å bruke en svak referanse til seg selv.
    /// Forsøk på å oppgradere den svake referansen før denne funksjonen returnerer, vil resultere i en `None`-verdi.
    /// Imidlertid kan den svake referansen klones fritt og lagres for bruk på et senere tidspunkt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruer det indre i "uninitialized"-tilstand med en enkelt svak referanse.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Det er viktig at vi ikke gir opp eierskapet til den svake pekeren, ellers kan minnet bli frigjort når `data_fn` kommer tilbake.
        // Hvis vi virkelig ønsket å passere eierskap, kunne vi lage en ekstra svak peker for oss selv, men dette vil resultere i ytterligere oppdateringer av det svake referansetallet som ellers ikke er nødvendig.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nå kan vi initialisere den indre verdien riktig og gjøre vår svake referanse til en sterk referanse.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ovennevnte skriv til datafeltet må være synlig for alle tråder som observerer et ikke-null antall.
            // Derfor trenger vi minst "Release"-bestilling for å synkronisere med `compare_exchange_weak` i `Weak::upgrade`.
            //
            // "Acquire" bestilling er ikke nødvendig.
            // Når vi vurderer den mulige oppførselen til `data_fn`, trenger vi bare å se på hva den kan gjøre med en referanse til en ikke-oppgraderbar `Weak`:
            //
            // - Det kan *klone*`Weak`, noe som øker det svake referansetallet.
            // - Det kan slippe disse klonene, og redusere det svake referansetallet (men aldri til null).
            //
            // Disse bivirkningene påvirker oss ikke på noen måte, og ingen andre bivirkninger er mulig med sikker kode alene.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Sterke referanser bør samlet ha en delt svak referanse, så ikke kjør ødeleggeren for vår gamle svake referanse.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruerer en ny `Arc` med ikke-initialisert innhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Arc` med ikke-initialisert innhold, hvor minnet fylles med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Pin<Arc<T>>`.
    /// Hvis `T` ikke implementerer `Unpin`, blir `data` festet i minnet og kan ikke flyttes.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruerer en ny `Arc<T>` og returnerer en feil hvis tildelingen mislykkes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Start den svake pekeren som 1, som er den svake pekeren som holdes av alle de sterke pekerne (kinda), se std/rc.rs for mer info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruerer en ny `Arc` med ikke-initialisert innhold, og returnerer en feil hvis tildelingen mislykkes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruerer en ny `Arc` med ikke-initialisert innhold, hvor minnet fylles med `0` byte, og returnerer en feil hvis tildelingen mislykkes.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Returnerer den indre verdien hvis `Arc` har nøyaktig en sterk referanse.
    ///
    /// Ellers returneres en [`Err`] med samme `Arc` som ble sendt inn.
    ///
    ///
    /// Dette vil lykkes selv om det er fremragende svake referanser.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Lag en svak peker for å rydde opp i den implisitte sterk-svake referansen
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruerer et nytt atomisk referansetelt stykke med uinitialisert innhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsatt initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruerer et nytt atomreferansetelt stykke med ikke-initialisert innhold, med minnet fylt med `0` byte.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på riktig og feil bruk av denne metoden.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konverterer til `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`], er det opp til innringeren å garantere at den indre verdien virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker umiddelbar udefinert oppførsel.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Utsatt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konverterer til `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`], er det opp til innringeren å garantere at den indre verdien virkelig er i en initialisert tilstand.
    ///
    /// Å kalle dette når innholdet ennå ikke er fullstendig initialisert, forårsaker umiddelbar udefinert oppførsel.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Utsatt initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Forbruker `Arc` og returnerer den innpakkede pekeren.
    ///
    /// For å unngå minnelekkasje må pekeren konverteres tilbake til en `Arc` ved hjelp av [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Gir en rå peker til dataene.
    ///
    /// Tellerne påvirkes ikke på noen måte, og `Arc` forbrukes ikke.
    /// Pekeren er gyldig så lenge det er sterke teller i `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SIKKERHET: Dette kan ikke gå gjennom Deref::deref eller RcBoxPtr::inner fordi
        // dette kreves for å beholde raw/mut herkomst slik at f.eks
        // `get_mut` kan skrive gjennom pekeren etter at Rc er gjenopprettet gjennom `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruerer en `Arc<T>` fra en rå peker.
    ///
    /// Råpekeren må ha blitt returnert tidligere av en samtale til [`Arc<U>::into_raw`][into_raw] der `U` må ha samme størrelse og justering som `T`.
    /// Dette er trivielt sant hvis `U` er `T`.
    /// Merk at hvis `U` ikke er `T`, men har samme størrelse og justering, er dette i utgangspunktet som å transmittere referanser av forskjellige typer.
    /// Se [`mem::transmute`][transmute] for mer informasjon om hvilke begrensninger som gjelder i dette tilfellet.
    ///
    /// Brukeren av `from_raw` må sørge for at en spesifikk verdi på `T` bare slippes en gang.
    ///
    /// Denne funksjonen er usikker fordi feil bruk kan føre til usikkerhet i minnet, selv om den returnerte `Arc<T>` aldri er tilgjengelig.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konverter tilbake til en `Arc` for å forhindre lekkasje.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ytterligere anrop til `Arc::from_raw(x_ptr)` vil være minne-utrygt.
    /// }
    ///
    /// // Minnet ble frigjort da `x` gikk utenfor omfanget ovenfor, så `x_ptr` dingler nå!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Snu forskyvningen for å finne den originale ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Oppretter en ny [`Weak`]-peker til denne tildelingen.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dette Avslappet er OK fordi vi sjekker verdien i CAS nedenfor.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // sjekk om den svake telleren for tiden er "locked";snur i så fall.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: denne koden ignorerer for øyeblikket muligheten for overløp
            // inn i usize::MAX;generelt må både Rc og Arc justeres for å takle overløp.
            //

            // I motsetning til Clone(), trenger vi dette for å være en anskaffelseslesning for å synkronisere med skrivingen som kommer fra `is_unique`, slik at hendelsene før skrivingen skjer før denne lesingen.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Forsikre deg om at vi ikke lager en dinglende svak
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Får antall [`Weak`]-pekere til denne tildelingen.
    ///
    /// # Safety
    ///
    /// Denne metoden er i seg selv trygg, men å bruke den riktig krever ekstra forsiktighet.
    /// En annen tråd kan når som helst endre det svake antallet, inkludert potensielt mellom å kalle denne metoden og å handle på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Denne påstanden er deterministisk fordi vi ikke har delt `Arc` eller `Weak` mellom tråder.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Hvis den svake tellingen for øyeblikket er låst, var verdien av tellingen 0 like før du tok låsen.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Får antall sterke (`Arc`)-pekere til denne tildelingen.
    ///
    /// # Safety
    ///
    /// Denne metoden er i seg selv trygg, men å bruke den riktig krever ekstra forsiktighet.
    /// En annen tråd kan når som helst endre det sterke antallet, inkludert potensielt mellom å kalle denne metoden og å handle på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Denne påstanden er deterministisk fordi vi ikke har delt `Arc` mellom tråder.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Øker den sterke referansetellingen på `Arc<T>` assosiert med den medfølgende pekeren en.
    ///
    /// # Safety
    ///
    /// Pekeren må ha blitt hentet gjennom `Arc::into_raw`, og den tilknyttede `Arc`-forekomsten må være gyldig (dvs.
    /// det sterke antallet må være minst 1) så lenge denne metoden varer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Denne påstanden er deterministisk fordi vi ikke har delt `Arc` mellom tråder.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behold Arc, men ikke berør reftelling ved å pakke inn ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Nå øker reftellingen, men ikke slipper ny refanteller heller
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Reduserer den sterke referansetellingen på `Arc<T>` assosiert med den medfølgende pekeren en.
    ///
    /// # Safety
    ///
    /// Pekeren må ha blitt hentet gjennom `Arc::into_raw`, og den tilknyttede `Arc`-forekomsten må være gyldig (dvs.
    /// det sterke antallet må være minst 1) når man påkaller denne metoden.
    /// Denne metoden kan brukes til å frigjøre den endelige `Arc`-og backinglagringen, men **bør ikke** ringes opp etter at den endelige `Arc` er utgitt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Disse påstandene er deterministiske fordi vi ikke har delt `Arc` mellom tråder.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Denne usikkerheten er ok, for mens vi ser denne buen er vi garantert at den indre pekeren er gyldig.
        // Videre vet vi at selve `ArcInner`-strukturen er `Sync` fordi de indre dataene også er `Sync`, så det er ok å låne ut en uforanderlig peker til dette innholdet.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ikke-innebygd del av `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ødelegg dataene på dette tidspunktet, selv om vi kanskje ikke frigjør selve boksallokeringen (det kan fortsatt være svake pekere som ligger rundt).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Slipp den svake dommeren samlet av alle sterke referanser
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnerer `true` hvis de to `Arc`ene peker på samme tildeling (i en vene som ligner på [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tildeler en `ArcInner<T>` med tilstrekkelig plass til en mulig ikke-størrelse indre verdi der verdien har oppsettet.
    ///
    /// Funksjonen `mem_to_arcinner` kalles med datapekeren og må returnere en (potensielt fett)-peker for `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Beregn layout med den gitte verdilayouten.
        // Tidligere ble layout beregnet på uttrykket `&*(ptr as* const ArcInner<T>)`, men dette skapte en feiljustert referanse (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tildel en `ArcInner<T>` med tilstrekkelig plass til en muligens ikke-størrelse indre verdi der verdien har oppsettet, og returnerer en feil hvis tildelingen mislykkes.
    ///
    ///
    /// Funksjonen `mem_to_arcinner` kalles med datapekeren og må returnere en (potensielt fett)-peker for `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Beregn layout med den gitte verdilayouten.
        // Tidligere ble layout beregnet på uttrykket `&*(ptr as* const ArcInner<T>)`, men dette skapte en feiljustert referanse (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiser ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Tildeler en `ArcInner<T>` med tilstrekkelig plass til en ikke-størrelse indre verdi.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tildel til `ArcInner<T>` med den gitte verdien.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopier verdien som byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Gratis tildelingen uten å slippe innholdet
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tildeler en `ArcInner<[T]>` med gitt lengde.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopier elementer fra skive til nylig tildelt Arc <\[T\]>
    ///
    /// Usikkert fordi den som ringer må enten ta eierskap eller binde `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruerer en `Arc<[T]>` fra en iterator som er kjent for å være av en viss størrelse.
    ///
    /// Atferd er udefinert hvis størrelsen skulle være feil.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic vakt mens du kloner T-elementer.
        // I tilfelle panic vil elementer som er skrevet inn i den nye ArcInner bli droppet, så frigjør minnet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Peker til første element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Alt klart.Glem vakten slik at den ikke frigjør nye ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Spesialisering trait brukt til `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Gjør en klon av `Arc`-pekeren.
    ///
    /// Dette skaper en annen peker til samme tildeling, og øker den sterke referansen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Å bruke en avslappet bestilling er greit her, da kunnskap om den opprinnelige referansen forhindrer at andre tråder feilaktig sletter objektet.
        //
        // Som forklart i [Boost documentation][1], kan økning av referanseteller alltid gjøres med memory_order_relaxed: Nye referanser til et objekt kan bare dannes fra en eksisterende referanse, og overføring av en eksisterende referanse fra en tråd til en annen må allerede gi enhver nødvendig synkronisering.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Imidlertid må vi beskytte oss mot massive refteller i tilfelle noen er `mem: : glemmer` buer.
        // Hvis vi ikke gjør dette, kan tellingen flyte over, og brukerne vil bruke gratis.
        // Vi metter raskt til `isize::MAX` under antagelse om at det ikke er ~2 milliarder tråder som øker referansetellingen på en gang.
        //
        // Denne branch vil aldri bli tatt i noe realistisk program.
        //
        // Vi avbryter fordi et slikt program er utrolig utartet, og vi bryr oss ikke om å støtte det.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Gjør en foranderlig referanse til den gitte `Arc`.
    ///
    /// Hvis det er andre `Arc`-eller [`Weak`]-pekere til samme tildeling, vil `make_mut` opprette en ny tildeling og påkalle [`clone`][clone] på den indre verdien for å sikre unikt eierskap.
    /// Dette blir også referert til som klon-på-skriv.
    ///
    /// Merk at dette skiller seg fra oppførselen til [`Rc::make_mut`] som adskiller eventuelle gjenværende `Weak`-pekere.
    ///
    /// Se også [`get_mut`][get_mut], som vil mislykkes i stedet for kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Vil ikke klone noe
    /// let mut other_data = Arc::clone(&data); // Vil ikke klone indre data
    /// *Arc::make_mut(&mut data) += 1;         // Kloner indre data
    /// *Arc::make_mut(&mut data) += 1;         // Vil ikke klone noe
    /// *Arc::make_mut(&mut other_data) *= 2;   // Vil ikke klone noe
    ///
    /// // Nå peker `data` og `other_data` på forskjellige tildelinger.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Merk at vi har både en sterk referanse og en svak referanse.
        // Å frigjøre vår sterke referanse bare vil ikke i seg selv føre til at minnet blir fordelt.
        //
        // Bruk Acquire for å sikre at vi ser eventuelle skrivinger til `weak` som skjer før utgivelsen skriver (dvs. reduksjoner) til `strong`.
        // Siden vi har en svak telling, er det ingen sjanse for at ArcInner selv kan bli fordelt.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // En annen sterk peker eksisterer, så vi må klone.
            // Forhåndsallokere minne slik at du kan skrive den klonede verdien direkte.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Avslappet er tilstrekkelig i ovennevnte fordi dette i utgangspunktet er en optimalisering: vi kjører alltid med svake pekere som blir droppet.
            // I verste fall tildelte vi en ny Arc unødvendig.
            //

            // Vi fjernet den siste sterke dommeren, men det er flere svake dommer igjen.
            // Vi flytter innholdet til en ny lysbue, og ugyldiggjør de andre svake ref.
            //

            // Merk at det ikke er mulig for avlesningen av `weak` å gi usize::MAX (dvs. låst), siden det svake antallet bare kan låses av en tråd med sterk referanse.
            //
            //

            // Materialiser vår egen implisitte svake peker, slik at den kan rydde opp i ArcInner etter behov.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kan bare stjele dataene, alt som er igjen er Svake
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Vi var den eneste referansen av begge slags;støt tilbake den sterke ref-tellingen.
            //
            this.inner().strong.store(1, Release);
        }

        // Som med `get_mut()` er usikkerheten ok fordi referansen vår var unik til å begynne med, eller ble en etter kloning av innholdet.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Returnerer en mutbar referanse til den gitte `Arc`, hvis det ikke er noen andre `Arc`-eller [`Weak`]-pekere til den samme tildelingen.
    ///
    ///
    /// Returnerer [`None`] ellers, fordi det ikke er trygt å mutere en delt verdi.
    ///
    /// Se også [`make_mut`][make_mut], som vil [`clone`][clone] den indre verdien når det er andre pekere.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Denne usikkerheten er ok fordi vi er garantert at pekeren som returneres er den *eneste* pekeren som noen gang vil bli returnert til T.
            // Referansetallet vårt er garantert 1 på dette tidspunktet, og vi krevde at selve buen var `mut`, så vi returnerer den eneste mulige referansen til de indre dataene.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Returnerer en foranderlig referanse til den gitte `Arc`, uten noen kontroll.
    ///
    /// Se også [`get_mut`], som er trygt og foretar passende kontroller.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Andre `Arc`-eller [`Weak`]-pekere til den samme tildelingen må ikke refereres så lenge lånet returneres.
    ///
    /// Dette er trivielt tilfelle hvis det ikke finnes noen slike pekere, for eksempel umiddelbart etter `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Vi er forsiktige med å *ikke* lage en referanse som dekker "count"-feltene, da dette vil alias med samtidig tilgang til referansetellene (f.eks.
        // av `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bestem om dette er den unike referansen (inkludert svake ref) til de underliggende dataene.
    ///
    ///
    /// Merk at dette krever låsing av den svake ref-tellingen.
    fn is_unique(&mut self) -> bool {
        // låse antall svake pekere hvis vi ser ut til å være den eneste svake pekerholderen.
        //
        // Anskaffelsesetiketten her sørger for at det skjer før forholdet til skriving til `strong` (spesielt i `Weak::upgrade`) før nedgang i `weak`-antall (via `Weak::drop`, som bruker utgivelse).
        // Hvis den oppgraderte svake ref aldri ble droppet, vil CAS her mislykkes, så vi bryr oss ikke om å synkronisere.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dette må være en `Acquire` for å synkronisere med reduseringen av `strong`-telleren i `drop`-den eneste tilgangen som skjer når noen, bortsett fra den siste referansen, slippes.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Utgivelsesskrivingen her synkroniseres med en avlesning i `downgrade`, og forhindrer effektivt at ovennevnte avlesning av `strong` skjer etter skrivingen.
            //
            //
            self.inner().weak.store(1, Release); // løsne låsen
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Dropper `Arc`.
    ///
    /// Dette vil redusere den sterke referansetellingen.
    /// Hvis det sterke referansetallet når null, er de eneste andre referansene (hvis noen) [`Weak`], så vi `drop` den indre verdien.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Skriver ikke ut noe
    /// drop(foo2);   // Skriver ut "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Fordi `fetch_sub` allerede er atomisk, trenger vi ikke å synkronisere med andre tråder med mindre vi skal slette objektet.
        // Den samme logikken gjelder under `fetch_sub` til `weak`-antallet.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dette gjerdet er nødvendig for å forhindre omorganisering av bruk av dataene og sletting av dataene.
        // Fordi den er merket `Release`, synkroniseres reduksjonen av referansetellingen med dette `Acquire`-gjerdet.
        // Dette betyr at bruk av data skjer før du reduserer referansetellingen, som skjer før dette gjerdet, som skjer før sletting av dataene.
        //
        // Som forklart i [Boost documentation][1],
        //
        // > Det er viktig å håndheve all mulig tilgang til objektet i ett
        // > tråd (gjennom en eksisterende referanse) til *skje før* sletting
        // > objektet i en annen tråd.Dette oppnås med en "release"
        // > operasjon etter å ha sluppet en referanse (all tilgang til objektet
        // > gjennom denne referansen må åpenbart skje før), og en
        // > "acquire" operasjonen før du sletter objektet.
        //
        // Spesielt, mens innholdet i en bue vanligvis er uforanderlig, er det mulig å få interiør til å skrive noe som en Mutex<T>.
        // Siden en Mutex ikke anskaffes når den slettes, kan vi ikke stole på synkroniseringslogikken for å gjøre skrifter i tråd A synlige for en destruktør som kjører i tråd B.
        //
        //
        // Vær også oppmerksom på at Acquire-gjerdet her sannsynligvis kan erstattes med en Acquire-belastning, noe som kan forbedre ytelsen i svært omstridte situasjoner.Se [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Forsøk å nedstøte `Arc<dyn Any + Send + Sync>` til en konkret type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruerer en ny `Weak<T>` uten å tildele noe minne.
    /// Å ringe [`upgrade`] på returverdien gir alltid [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hjelpertype for å tillate tilgang til referansetellene uten å gjøre noen påstander om datafeltet.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Returnerer en rå peker til objektet `T` pekt på av denne `Weak<T>`.
    ///
    /// Pekeren er bare gyldig hvis det er noen sterke referanser.
    /// Pekeren kan være dinglende, ujustert eller til og med [`null`] ellers.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Begge peker på det samme objektet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Den sterke her holder den i live, slik at vi fremdeles kan få tilgang til objektet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men ikke nå lenger.
    /// // Vi kan gjøre weak.as_ptr(), men tilgang til pekeren vil føre til udefinert oppførsel.
    /// // assert_eq! ("hei", usikre {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Hvis pekeren henger, returnerer vi sentinellen direkte.
            // Dette kan ikke være en gyldig nyttelastadresse, siden nyttelasten er minst like justert som ArcInner (usize).
            ptr as *const T
        } else {
            // SIKKERHET: Hvis is_dangling returnerer false, kan pekeren avvises.
            // Nyttelasten kan bli droppet på dette punktet, og vi må opprettholde herkomst, så bruk rå pekermanipulasjon.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Forbruker `Weak<T>` og gjør den til en rå peker.
    ///
    /// Dette konverterer den svake pekeren til en rå peker, mens du fremdeles bevarer eierskapet til en svak referanse (det svake antallet endres ikke av denne operasjonen).
    /// Den kan gjøres om til `Weak<T>` med [`from_raw`].
    ///
    /// De samme begrensningene for tilgang til pekermålet som med [`as_ptr`] gjelder.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverterer en rå peker som tidligere ble opprettet av [`into_raw`] tilbake til `Weak<T>`.
    ///
    /// Dette kan brukes til å trygt få en sterk referanse (ved å ringe [`upgrade`] senere) eller for å plassere det svake antallet ved å slippe `Weak<T>`.
    ///
    /// Det tar eierskap til en svak referanse (med unntak av pekere opprettet av [`new`], da disse ikke eier noe; metoden fungerer fortsatt på dem).
    ///
    /// # Safety
    ///
    /// Pekeren må ha sitt utspring fra [`into_raw`] og må fremdeles eie sin potensielle svake referanse.
    ///
    /// Det er tillatt for den sterke tellingen å være 0 når du kaller dette.
    /// Likevel tar dette eierskap til en svak referanse som for øyeblikket er representert som en rå peker (det svake antallet er ikke modifisert av denne operasjonen), og derfor må den sammenkobles med en tidligere samtale til [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Reduser den siste svake tellingen.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Se Weak::as_ptr for kontekst om hvordan inngangspekeren blir avledet.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dette er en dinglende svak.
            ptr as *mut ArcInner<T>
        } else {
            // Ellers er vi garantert at pekeren kom fra en svak svindel.
            // SIKKERHET: data_offset er trygt å ringe, da ptr refererer til en ekte (potensielt droppet) T.
            let offset = unsafe { data_offset(ptr) };
            // Dermed reverserer vi forskyvningen for å få hele RcBox.
            // SIKKERHET: pekeren stammer fra en svak, så denne forskyvningen er trygg.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIKKERHET: vi har nå gjenopprettet den opprinnelige svake pekeren, slik at vi kan opprette den svake.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Forsøker å oppgradere `Weak`-pekeren til en [`Arc`], og forsinker å slippe den indre verdien hvis den lykkes.
    ///
    ///
    /// Returnerer [`None`] hvis den indre verdien siden har blitt sluppet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ødelegg alle sterke pekere.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Vi bruker en CAS-løkke for å øke den sterke tellingen i stedet for en fetch_add, da denne funksjonen aldri skal ta referansetellingen fra null til en.
        //
        //
        let inner = self.inner()?;

        // Avslappet belastning fordi enhver skriving av 0 som vi kan observere, etterlater feltet i permanent nullstatus (så en "stale"-lesing av 0 er greit), og enhver annen verdi bekreftes via CAS nedenfor.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Se kommentarer i `Arc::clone` for hvorfor vi gjør dette (for `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Avslappet er greit for feilsaken fordi vi ikke har noen forventninger til den nye staten.
            // Erverve er nødvendig for at suksesssaken skal synkroniseres med `Arc::new_cyclic`, når den indre verdien kan initialiseres etter at `Weak`-referanser allerede er opprettet.
            // I så fall forventer vi å observere den fullinitialiserte verdien.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null sjekket ovenfor
                Err(old) => n = old,
            }
        }
    }

    /// Får antall sterke (`Arc`)-pekere som peker på denne tildelingen.
    ///
    /// Hvis `self` ble opprettet ved hjelp av [`Weak::new`], vil dette returnere 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Får en tilnærming til antall `Weak`-pekere som peker på denne tildelingen.
    ///
    /// Hvis `self` ble opprettet ved hjelp av [`Weak::new`], eller hvis det ikke er noen gjenværende sterke pekere, vil dette returnere 0.
    ///
    /// # Accuracy
    ///
    /// På grunn av detaljer om implementering kan den returnerte verdien være av med 1 i begge retninger når andre tråder manipulerer noen ``Arc '' eller`` Svake '' som peker på samme tildeling.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Siden vi observerte at det var minst en sterk peker etter å ha lest den svake tellingen, vet vi at den implisitte svake referansen (til stede når noen sterke referanser er i live) fortsatt var rundt da vi observerte den svake tellingen, og kan derfor trygt trekke den fra.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Returnerer `None` når pekeren henger og det ikke er tildelt `ArcInner`, (dvs. når denne `Weak` ble opprettet av `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Vi er forsiktige med å *ikke* opprette en referanse som dekker "data"-feltet, da feltet kan bli mutert samtidig (for eksempel hvis den siste `Arc` blir droppet, vil datafeltet bli droppet på plass).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnerer `true` hvis de to svake peker på samme tildeling (ligner på [`ptr::eq`]), eller hvis begge ikke peker på noen tildeling (fordi de ble opprettet med `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Siden dette sammenligner pekere, betyr det at `Weak::new()` vil like hverandre, selv om de ikke peker på noen tildeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Sammenligning av `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Gjør en klon av `Weak`-pekeren som peker på samme tildeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Se kommentarer i Arc::clone() for hvorfor dette er avslappet.
        // Dette kan bruke en fetch_add (ignorerer låsen) fordi det svake antallet bare er låst der *ingen andre* svake pekere eksisterer.
        //
        // (Så vi kan ikke kjøre denne koden i så fall).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Se kommentarer i Arc::clone() for hvorfor vi gjør dette (for mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruerer en ny `Weak<T>` uten å tildele minne.
    /// Å ringe [`upgrade`] på returverdien gir alltid [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Dropper `Weak`-pekeren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Skriver ikke ut noe
    /// drop(foo);        // Skriver ut "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Hvis vi finner ut at vi var den siste svake pekeren, er det på tide å distribuere dataene helt.Se diskusjonen i Arc::drop() om minnebestillingene
        //
        // Det er ikke nødvendig å sjekke om den låste tilstanden her, fordi den svake tellingen bare kan låses hvis det var nettopp en svak ref, noe som betyr at fall bare senere kan kjøre PÅ den gjenværende svake ref, som bare kan skje etter at låsen er utløst.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Vi gjør denne spesialiseringen her, og ikke som en mer generell optimalisering på `&T`, fordi det ellers ville lagt til en kostnad for alle likhetskontroller på ref.
/// Vi antar at `Arc`s brukes til å lagre store verdier, som er sakte å klone, men også tunge for å sjekke for likhet, noe som får denne kostnaden til å betale seg lettere.
///
/// Det er også mer sannsynlig å ha to `Arc`-kloner, som peker på samme verdi, enn to `&T`er.
///
/// Vi kan bare gjøre dette når `T: Eq` som `PartialEq` kan være bevisst irrefleksiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Likhet for to `Arc`s.
    ///
    /// To `Arc`s er like hvis deres indre verdier er like, selv om de er lagret i annen tildeling.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet av likhet), er to `Arc`er som peker på samme tildeling alltid like.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ulikhet for to `Arc`s.
    ///
    /// To `Arc`s er ulik hvis deres indre verdier er ulik.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet av likhet), er to `Arc`s som peker på samme verdi aldri ulik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Delvis sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `partial_cmp()` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mindre enn sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `<` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Mindre enn eller lik' sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `<=` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Større enn sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `>` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Større enn eller lik' sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `>=` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved å kalle `cmp()` på sine indre verdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Oppretter en ny `Arc<T>`, med `Default`-verdien for `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tildel et referansetelt stykke og fyll det ved å klone ``v`s elementer.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tildel en referansetelling `str` og kopier `v` inn i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tildel en referansetelling `str` og kopier `v` inn i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Flytt et objekt i boks til en ny, referansetelt tildeling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tildel et referansetelt stykke og flytt `v`-elementene inn i det.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // La Vec frigjøre hukommelsen, men ikke ødelegge innholdet
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Tar hvert element i `Iterator` og samler det inn i en `Arc<[T]>`.
    ///
    /// # Ytelsesegenskaper
    ///
    /// ## Den generelle saken
    ///
    /// Generelt sett samles det i `Arc<[T]>` ved først å samle inn i en `Vec<T>`.Det vil si når du skriver følgende:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dette oppfører seg som om vi skrev:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Det første settet med tildelinger skjer her.
    ///     .into(); // En annen tildeling for `Arc<[T]>` skjer her.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dette tildeles så mange ganger som nødvendig for å konstruere `Vec<T>`, og deretter vil det tildeles en gang for å gjøre `Vec<T>` til `Arc<[T]>`.
    ///
    ///
    /// ## Iteratorer av kjent lengde
    ///
    /// Når `Iterator` implementerer `TrustedLen` og har en nøyaktig størrelse, vil det bli gitt en enkelt tildeling for `Arc<[T]>`.For eksempel:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Bare en enkelt tildeling skjer her.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Spesialisering trait brukt til å samle inn `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dette er tilfelle for en `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIKKERHET: Vi må sørge for at iteratoren har en nøyaktig lengde, og det har vi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Fall tilbake til normal implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Få forskyvningen innen en `ArcInner` for nyttelasten bak en peker.
///
/// # Safety
///
/// Pekeren må peke på (og ha gyldige metadata for) en tidligere gyldig forekomst av T, men T er tillatt å slippe.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Juster den usikre verdien til slutten av ArcInner.
    // Fordi RcBox er repr(C), vil det alltid være det siste feltet i minnet.
    // SIKKERHET: siden de eneste mulige typene er skiver, trait-objekter,
    // og eksterne typer, er sikkerhetskravet for inngang for tiden nok til å tilfredsstille kravene til align_of_val_raw;dette er en implementeringsdetalj av språket som ikke kan stole på utenfor std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}